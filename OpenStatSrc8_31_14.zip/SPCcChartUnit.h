//---------------------------------------------------------------------------

#ifndef SPCcChartUnitH
#define SPCcChartUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSPCcChartForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label3;
     TEdit *MeasEdit;
     TRadioGroup *SigmaOpts;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TEdit *SigmaEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormActivate(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean,
                             TObject *Sender);

private:	// User declarations
public:		// User declarations
     __fastcall TSPCcChartForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSPCcChartForm *SPCcChartForm;
//---------------------------------------------------------------------------
#endif
