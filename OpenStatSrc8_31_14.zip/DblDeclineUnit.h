//---------------------------------------------------------------------------

#ifndef DblDeclineUnitH
#define DblDeclineUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TDblDeclineForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TEdit *CostEdit;
     TEdit *LifeEdit;
     TEdit *EndEdit;
     TEdit *PeriodEdit;
     TButton *ComputeBtn;
     TLabel *Label5;
     TEdit *DeprecEdit;
     TButton *ReturnBtn;
     TButton *ResetBtn;
     TMemo *Memo1;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TDblDeclineForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDblDeclineForm *DblDeclineForm;
//---------------------------------------------------------------------------
#endif
