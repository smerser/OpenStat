//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "mainUnit.h"
#include "ItemAnal.h"
#include "ItemSpecs.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "GraphUnit.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "functions.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TTestAnalForm *TestAnalForm;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
int *NumberKey;
char *LetterKey;
char **WordKey;
double *ItemWeight;

//---------------------------------------------------------------------------
__fastcall TTestAnalForm::TTestAnalForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::CancelBtnClick(TObject *Sender)
{
    TestAnalForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::ComputeBtnClick(TObject *Sender)
{
    N = NoCases;
    if (CheckBox11->Checked == true) // one scale, first record is key
    {
        NoScales = 1;
        N = NoCases - 1;
        selected = ScaleListBox->Items->Count;
        if (selected < 1)
        {
           ShowMessage("ERROR! Select 1 or more items for this scale.");
           return;
        }

        NoItems = selected;
        for (int i = 0; i < selected; i++)
        {
                for (int j = 0; j < NoVariables; j++)
                {
                        if (MainForm->Grid->Cells[j+1][0] == ScaleListBox->Items->Strings[i])
                           ItemNoArray[i] = j+1;
                }
        }

        for (int i = 0; i < selected; i++)
            ScaleItems[NoScales-1][i] = ItemNoArray[i];
        noselected[NoScales-1] = selected;
        for (int i = 0; i < selected; i++) //get key record
        {
            int itemno = ItemNoArray[i];
            Key[itemno-1] = atoi(MainForm->Grid->Cells[itemno][1].c_str());
        }
        ScoringDefined = true;
    }

   else
   {
        if (ScoringDefined == false)
        {
            selected = ScaleListBox->Items->Count;
            if (selected < 1)
            {
               ShowMessage("ERROR! Select 1 or more items for this scale.");
              return;
            }
            NoItems += selected;
            for (int i = 0; i < selected; i++)
                ScaleItems[NoScales-1][i] = ItemNoArray[i];
            noselected[NoScales-1] = selected;
            ItemScoreForm->NoItemsEdit->Text = noselected[NoScales-1];
            ItemScoreForm->UpDown1->Max = short(noselected[NoScales-1]);
            ItemScoreForm->UpDown1->Min = 1;
            ItemScoreForm->ItemNoEdit->Text = 1;
            ItemScoreForm->ScaleNoEdit->Text = NoScales;
            if (CheckBox18->Checked == false) {
                ItemScoreForm->Label7->Enabled = false;
                ItemScoreForm->WeightEdit->Enabled = false;
            }
            else  {
                ItemScoreForm->Label7->Enabled = true;
                ItemScoreForm->WeightEdit->Enabled = true;
            }
            ItemScoreForm->ShowModal();
            // store key values for the scale just entered
            for (int i = 0; i < ScaleListBox->Items->Count; i++)
            {
                int itemno = ScaleItems[NoScales-1][i];
                if (RadioButton1->Checked == true) // numeric key
                    Key[itemno-1] = NumberKey[i];
                if (RadioButton2->Checked == true) // letter
                    Key[itemno-1] = LetterKey[i];
                if (RadioButton5->Checked == true) // word key
                    Key[itemno-1] = WordKey[i];
            }
            ScoringDefined = true;
        }
   }
   Analyze(this);
//   TestAnalForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::Analyze(TObject *Sender)
{
    int size;
    int startcase;
    int itemno;
    int index;
    int nocases = 0;
    int oldNoVariables = NoVariables;
    char Title[81];
    char outline[121];

    if (NoScales > 1)
    {
        NoItems = 0;
        for (int i = 0; i < NoScales; i++)
            NoItems += noselected[i];
    }

    if (NoScales > 1) size = NoItems + NoScales + 1; // No. of variables selected + scores
    else size = NoItems + 1;
    if (size <= 1)
    {
        ShowMessage("ERROR! No items were selected.");
        return;
    }
    
    // Allocate space for total test and subscale totals
    try
    {
        RowLabels = new AnsiString[NoCases];
        ColLabels = new AnsiString[size];
        // The data array holds the scored items for each subject
        Data = new int*[NoCases]; // Rows correspond to subjects
        for (int i = 0; i < NoCases; i++)
            Data[i] = new int[size]; // Columns correspond to items
        // Allocate space for means, variances, standard deviations, and
        // interitem correlations for items, subscores and total score.
        Matrix = new double*[size];  // set up item rows
        for (int j = 0; j < size; j++) Matrix[j] = new double[size];
        Means = new double[size];
        StdDevs = new double[size];
        Variances = new double[size];
    }
    catch (...)
    {
        Application->MessageBox("Could not allocate memory.","OUT OF MEMORY",MB_OK);
        return;
    }
    // We have space!  Now analyze and report results for the scale
    // First, read the data and score the items for the subscores.  Place
    // results in the Data array.

    // Initialize the Data matrix
    for (int i = 0; i < NoCases; i++)
        for (int j = 0; j < size; j++) Data[i][j] = 0.0;

    //Now, load item responses in the Data matrix
    startcase = 1;
    if (CheckBox11->Checked == true) startcase = 2;
    index = 0;  //counter for items stored in Data matrix
    for (int scale = 0; scale < NoScales; scale++)
    {
        for (int j = 0; j < noselected[scale]; j++) // no. items in scale
        {
            for (int i = 0; i < N; i++) // subject loop
            {
                if (FilterOn)
                {
                   if (MainForm->Grid->Cells[FilterCol][i+startcase] == "NO") continue;
                }
                itemno = ScaleItems[scale][j];
                AnsiString cellvalue = MainForm->Grid->Cells[itemno][i+startcase];
                int val1 = floor(StrToFloat(cellvalue));
                if (val1 == Key[itemno-1])
                {
                    Data[i][index] = 1 * ItemWeight[itemno-1];
                    Data[i][NoItems+scale]+= 1 * ItemWeight[itemno-1];
                    if (NoScales > 1) Data[i][size-1]+= 1 * ItemWeight[itemno-1];
                }
                else Data[i][index] = 0;
            } // next case
            index++; // next item position in data matrix
        } // next item
    }  // next scale

    // Now calculate sums, sums of squares and cross-products
    // Initialize arrays
    for (int i = 0; i < size; i++)
    {
        Means[i] = 0.0;
        Variances[i] = 0.0;
        StdDevs[i] = 0.0;
        for (int j = 0; j < size; j++)  {
            Matrix[i][j] = 0.0;
        }
    }

    for (int i = 0; i < NoCases; i++) // subject loope
    {
        if (FilterOn)
        {
            if (MainForm->Grid->Cells[FilterCol][i+1] == "NO") continue;
        }
        for (int j = 0; j < size; j++) //item loop
        {
            Means[j] += Data[i][j];
            Variances[j] += Data[i][j] * Data[i][j];
            for (int k = 0; k < size; k++)
            {
                Matrix[j][k] += Data[i][j] * Data[i][k];
            }
        }
    }

    // get actual no of cases if filtering on
    if (FilterOn)
    {
       for (int i = 0; i < NoCases; i++)
       {
            if (MainForm->Grid->Cells[FilterCol][i+1] == "YES") nocases++;
       }
    }
    else nocases = N;

    // Complete calculation of means, variances, correlations
    for (int i = 0; i < size; i++)
    {
        // Note: Means is currently the sum of X's
        Variances[i] = Variances[i] - ( (Means[i] * Means[i]) / double(nocases));
        Variances[i] /= double(nocases-1);
        StdDevs[i] = sqrt(Variances[i]);
    }
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            Matrix[i][j] = Matrix[i][j] - ((Means[i] * Means[j]) / double(nocases));
            Matrix[i][j] = Matrix[i][j] / double (nocases - 1); // covariance
            if ((StdDevs[i] > 0) && (StdDevs[j] > 0))
                Matrix[i][j] /= (StdDevs[i] * StdDevs[j]); // Correlations
            else
            {
                Matrix[i][j] = 0.0;
                Application->MessageBox("A std.dev. of 0 encountered-correlation set to 0.",
                   "0 VARIANCE!",MB_OK);
            }
        }
    }
    for (int i = 0; i < size; i++) Means[i] /= double (nocases);

    strcpy(outline,"                       Classical Test Analysis Results\n");
    FrmOutPut->RichOutPut->Lines->Add(outline);

    //Build labels for variables and cases
    for (int i = 0; i < NoCases; i++)
        RowLabels[i]=MainForm->Grid->Cells[0][i+startcase];
    index = 0;
    for (int scale = 0; scale < NoScales; scale++)
    {
        for (int i = 0; i < noselected[scale]; i++)
        {
            int itemno = ScaleItems[scale][i];
            ColLabels[index] = MainForm->Grid->Cells[itemno][0];
            index++;
        }
        ColLabels[NoItems+scale] = ScaleNamePtr[scale];
    }
    ColLabels[size-1] = "TOTAL";

    if (PrntScrs->Checked == true) ScoreReport(this);
/*    {
        // print data matrix
        strcpy(Title,"Item Scores and Subscores");
        IntArrayPrint(Data, NoCases, size, "Items and Subscores",
           RowLabels, ColLabels, Title);
    }
*/
    if (GridScrsChkBox->Checked == true) // put scores in the data grid
    {
        if (NoScales > 1)
        {
            for (int i = 0; i <= NoScales; i++)
            {
                int position = size - NoScales - 1 + i;
                AnsiString collabel = ColLabels[NoItems+i];
                MainForm->Grid->ColCount++;
                MainForm->Grid->Cells[NoVariables+1+i][0] = collabel;
                for (int j = 0; j < NoCases; j++)
                {
                    if (CheckBox11->Checked == true)
                        MainForm->Grid->Cells[NoVariables+i+1][j+2] = Data[j][position];
                    else
                        MainForm->Grid->Cells[NoVariables+i+1][j+1] = Data[j][position];
                }
            }
            for (int i = 0; i <= NoScales; i++) // define new values
            {
                int gridcol = NoVariables+1;
                NewVar(gridcol,false);
                MainForm->NoVarsEdit->Text = NoVariables;
            }
        }
        else
        {
            int position = NoItems;
            AnsiString collabel = ColLabels[NoItems];
            MainForm->Grid->ColCount++;
            MainForm->Grid->Cells[NoVariables+1][0] = collabel;
            for (int j = 0; j < NoCases; j++)
            {
                if (CheckBox11->Checked == true)
                    MainForm->Grid->Cells[NoVariables+1][j+2] = Data[j][position];
                else
                    MainForm->Grid->Cells[NoVariables+1][j+1] = Data[j][position];
            }
            // Add definition data
            int gridcol = NoVariables+1;
            NewVar(gridcol,false);
            MainForm->NoVarsEdit->Text = NoVariables;
        }
    }

    if (CheckBox8->Checked == true) // Print Intercorrelation Matrix
    {
        // Build Title for printout
        strcpy(Title,"Intercorrelations of items and scores");
        //Print correlation matrix
        ArrayPrint(Matrix, size, size, "Items and Subscores",
            ColLabels, ColLabels, Title);
    }

    if (CheckBox1->Checked == true) //Print Means
    {
        strcpy(Title,"Means for Items, Sub-Scores, Total Score");
        VPrint(Means,size,ColLabels,Title);
    }

    if (CheckBox2->Checked == true)//Print Variances
    {
        strcpy(Title,"Variances for Items, Sub-Scores, Total Score");
        VPrint(Variances,size,ColLabels,Title);
    }

    if (CheckBox3->Checked == true)//Print Standard Deviations
    {
        strcpy(Title,"Standard Deviations for Items, Sub-Scores and Total Score");
        VPrint(StdDevs,size,ColLabels,Title);
    }

    //Calculate and print reliability estimates for Subscores and Total test
    if (CheckBox15->Checked == true) //Alpha
    {
        index = 0;
        for (int scale = 0; scale < NoScales; scale++)
        {
            double Alpha = 0.0;
            double SEMeas = 0.0;
            for (int i = 0; i < noselected[scale]; i++)
            {
                Alpha += Variances[index]; // sum of item variances
                index++;
            }
            Alpha /= Variances[NoItems+scale];
            Alpha = 1.0 - Alpha;
            Alpha = (double(noselected[scale]) /
                   (double(noselected[scale])-1.0)) * Alpha;
            SEMeas = StdDevs[NoItems+scale] * sqrt(1.0 - Alpha);
            sprintf(outline,"Alpha Reliability Estimate for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),Alpha,SEMeas);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }

    if (CheckBox14->Checked == true) // KR#21
    {
        for (int scale = 0; scale < NoScales; scale++)
        {
            double KR21 = (Means[NoItems+scale] * (noselected[scale]-
                Means[NoItems+scale])) / (noselected[scale] * Variances[NoItems+scale]);
            double SEMeas = 0.0;
            KR21 = 1.0 - KR21;
            KR21 *= (double(noselected[scale]) / (double(noselected[scale])-1.0));
            SEMeas = StdDevs[NoItems+scale] * sqrt(1.0 - KR21);
            sprintf(outline,"KR#21 Reliability Estimate for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),KR21,SEMeas);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }

    if (CheckBox13->Checked == true) //KR#20
    {
        index = 0;
        for (int scale = 0; scale < NoScales; scale++) // scale loop
        {
            double KR20 = 0.0;
            double SEMeas = 0.0;
            double sumpq = 0.0;
            for (int i = 0; i < noselected[scale]; i++) // item loop
            {
                double p = 0.0;
                double q = 0.0;
                //itemno = ScaleItems[scale][i];
                for (int k = 0; k < N; k++) //subject loop
                {
                    if (FilterOn)
                    {
                        if (MainForm->Grid->Cells[FilterCol][k+1] == "NO") continue;
                    }
                    p += Data[k][index];
                }
                p /= double(nocases);
                q = 1.0 - p;
                sumpq += ((double(nocases) / (double(nocases)-1))*(p * q));
                index++;
            }
            KR20 = 1.0 - (sumpq / Variances[NoItems+scale]);
            KR20 *= (double(noselected[scale]) / (double(noselected[scale])-1.0));
            SEMeas = StdDevs[NoItems+scale] * sqrt(1.0 - KR20);
            sprintf(outline,"KR#20 Reliability Estimate for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),KR20,SEMeas);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }

    if (CheckBox16->Checked == true) //Hoyt reliability estimates by ANOVA
    {
        index = 0;
        for (int scale = 0; scale < NoScales; scale++) // scale loop
        {
            double Hoyt1 = 0.0;
            double Hoyt2 = 0.0;
            double Hoyt3 = 0.0;
            double Hoyt4 = 0.0;
            double SEMeas1 = 0.0;
            double SEMeas2 = 0.0;
            double SEMeas3 = 0.0;
            double SEMeas4 = 0.0;
            double SSError = 0.0;
            double SSCases = 0.0;
            double SSItems = 0.0;
            double SSWithin = 0.0;
            double TotalSS = 0.0;
            double TotalX = 0.0;
            double Constant = 0.0;
            for (int i = 0; i < noselected[scale]; i++) // item loop
            {
                double ItemTotal = 0.0;
                for (int k = 0; k < N; k++) //subject loop
                {
                    if (FilterOn)
                    {
                        if (MainForm->Grid->Cells[FilterCol][k+1] == "NO") continue;
                    }
                    ItemTotal += Data[k][index];
                    TotalSS += (Data[k][index] * Data[k][index]);
                }
                TotalX += ItemTotal;
                SSItems += (ItemTotal * ItemTotal) / double(nocases);
                index++;
            }
            for (int k = 0; k < N; k++) // subject loop
            {
                if (FilterOn)
                {
                   if (MainForm->Grid->Cells[FilterCol][k+1] == "NO") continue;
                }
                double value = Data[k][NoItems+scale];
                SSCases += (value * value);
            }
            SSCases /= noselected[scale];
            Constant = (TotalX * TotalX) / double(nocases * noselected[scale]);
            SSCases -= Constant;
            TotalSS -= Constant;
            SSWithin = TotalSS - SSCases;
            SSItems -= Constant;
            SSError = SSWithin - SSItems;
            double MSWithin = SSWithin / double(nocases * (noselected[scale]-1));
            double MSTotal = TotalSS / (double(nocases * noselected[scale])-1.0);
            double MSCases = SSCases / (double(nocases) - 1.0);
            double MSError = SSError / ((double(nocases) - 1.0) * (noselected[scale]-1.0));
            Hoyt1 = 1.0 - (MSWithin / MSCases);
            Hoyt2 = (MSCases - MSError) / MSCases;
            Hoyt4 = (MSCases - MSError) /
                (MSCases + double(noselected[scale]-1)*MSError);
            Hoyt3 = (MSCases - MSWithin) /
                (MSCases + double(noselected[scale]-1) * MSWithin);
            SEMeas1 = StdDevs[NoItems+scale] * sqrt(1.0 - Hoyt1);
            sprintf(outline,"Hoyt Unadjusted Test Rel. for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),Hoyt1,SEMeas1);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            SEMeas2 = StdDevs[NoItems+scale] * sqrt(1.0 - Hoyt2);
            sprintf(outline,"Hoyt Adjusted Test Rel. for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),Hoyt2,SEMeas2);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            SEMeas3 = StdDevs[NoItems+scale] * sqrt(1.0 - Hoyt3);
            sprintf(outline,"Hoyt Unadjusted Item Rel. for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),Hoyt3,SEMeas3);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            SEMeas4 = StdDevs[NoItems+scale] * sqrt(1.0 - Hoyt4);
            sprintf(outline,"Hoyt Adjusted Item Rel. for scale %s = %6.4f  S.E. of Measurement = %8.3f\n",
                ColLabels[NoItems+scale].c_str(),Hoyt4,SEMeas4);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }

    if (CheckBox17->Checked == true) //stepwise reliability
    {
        for (int scale = 0; scale < NoScales; scale++)
        {
            StepKR(scale,this);
        }
    }
    FrmOutPut->ShowModal();

    //Item Characteristic Curves
    if (CheckBox6->Checked == true)
    {
        for (int scale=0; scale < NoScales; scale++)
        {
            ICCurves(scale,this);
        }
    }

    N = nocases;
    if (SimultChk->Checked) SimMR(this);
    if (PlotScoresChk->Checked) PlotScores(this);
    if (PlotMeansChk->Checked) PlotMeans(this);
    
    // delete the arrays for the total test
    delete[] Variances;
    delete[] StdDevs;
    delete[] Means;
    for (int i = 0; i < size; i++) delete[] Matrix[i];
    delete[] Matrix;
    for (int i = 0; i < NoCases; i++) delete[] Data[i];
    delete[] Data;
    delete[] ColLabels;
    delete[] RowLabels;

    // now delete the initial allocated storage
    for (int i = 0; i < 11; i++) delete[] ScaleNamePtr[i];
    delete[] ScaleNamePtr;
    delete[] Key;
    for (int i = 0; i < 10; i++) delete[] ScaleItems[i];
    delete[] ScaleItems;
    delete[] noselected;
    delete[] ItemNoArray;
    delete[] ItemWeight;
    for (int i = 0; i < oldNoVariables; i++) delete[] WordKey[i];
    delete[] WordKey;
    delete[] LetterKey;
    delete[] NumberKey;
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::FormShow(TObject *Sender)
{
    NoScales = 1;
    NoItems = 0;
    selected = 0;
    ScoringDefined = false;
    VarListBox->Clear();
    ScaleListBox->Clear();
    ScaleNoEdit->Text = 1;
    ScaleNameEdit->Text = "Scale1";
    LastOutBtn->Visible = false;
    FirstOutBtn->Visible = false;
    IDOutBtn->Visible = false;
    LastInBtn->Visible = true;
    FirstInBtn->Visible = true;
    IDInBtn->Visible = true;
    CheckBox1->Checked = false;
    CheckBox2->Checked = false;
    CheckBox3->Checked = false;
    CheckBox6->Checked = false;
    CheckBox8->Checked = false;
    CheckBox11->Checked = true;
    CheckBox12->Checked = false;
    CheckBox13->Checked = false;
    CheckBox14->Checked = false;
    CheckBox15->Checked = false;
    CheckBox16->Checked = false;
    CheckBox17->Checked = false;
    CheckBox18->Checked = false;
    CheckBox18->Visible = false;
    SimultChk->Checked = false;
    PlotScoresChk->Checked = false;
    PlotMeansChk->Checked = false;
    LastNameEdit->Text = "";
    FirstNameEdit->Text = "";
    IDEdit->Text = "";
    Label3->Visible = false;
    ScaleNoEdit->Visible = false;
    Label4->Visible = false;
    ScaleNameEdit->Visible = false;
    NextScaleBtn->Visible = false;
    NewScaleBtn->Visible = false;
    PrntScrs->Checked = false;
    GridScrsChkBox->Checked = false;
    RadioButton1->Checked = false;
    RadioButton2->Checked = false;
    RadioButton5->Checked = false;
    for (int i = 1; i <= NoVariables; i++) //load variables in list
    {
        AnsiString cellstring = MainForm->Grid->Cells[i][0];
        VarListBox->Items->Add(cellstring);
    }
    try
    {
        NumberKey = new int[NoVariables];
        LetterKey = new char[NoVariables];
        WordKey = new char*[NoVariables];
        for (int i = 0; i < NoVariables; i++) WordKey[i] = new char[21];
        ItemWeight = new double[NoVariables];
        ItemNoArray = new int[NoVariables];
        noselected = new int[10];
        ScaleItems = new int*[10];
        for (int i = 0; i < 10; i++) ScaleItems[i] = new int[NoVariables];
        Key = new AnsiString[NoVariables];
        ScaleNamePtr = new char*[11];
        for (int i = 0; i < 11; i++) ScaleNamePtr[i] = new char[21];
    }
    catch (...) // This block entered only if xalloc is thrown.
    {
    	Application->MessageBox("Could not allocate memory.","OUT OF MEMORY",MB_OK);
        TestAnalForm->Hide();
	}
    for (int i = 0; i < NoVariables; i++)
    {
        ItemNoArray[i] = 0;
        ItemWeight[i] = 1.0;
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::NextScaleBtnClick(TObject *Sender)
{
    //Get new scale specifications
    if (CheckBox11->Checked == true)
    {
       Application->MessageBox("This option only available when prompting for correct answers!","ERROR!",MB_OK);
       ResetBtnClick(this);
       return;
    }
    ScaleNoEdit->Text = NoScales;
    selected = ScaleListBox->Items->Count;
    for (int i = 0; i < selected; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            AnsiString cellstring = MainForm->Grid->Cells[j+1][0];
            if (cellstring == ScaleListBox->Items->Strings[i])
                ItemNoArray[i] = j+1;// Grid column no of item selected
        }
    }
    for (int i = 0; i < selected; i++)
        ScaleItems[NoScales-1][i] = ItemNoArray[i]; //grid location of item
    noselected[NoScales-1] = selected;
    strcpy(ScaleNamePtr[NoScales-1],ScaleNameEdit->Text.c_str());
    ItemScoreForm->NoItemsEdit->Text = noselected[NoScales-1];
    ItemScoreForm->UpDown1->Max = short(noselected[NoScales-1]);
    ItemScoreForm->UpDown1->Min = 1;
    ItemScoreForm->ItemNoEdit->Text = 1;
    ItemScoreForm->ScaleNoEdit->Text = NoScales;
    if (CheckBox18->Checked == false) {
        ItemScoreForm->Label7->Visible = false;
        ItemScoreForm->WeightEdit->Visible = false;
    }
    else  {
        ItemScoreForm->Label7->Visible = true;
        ItemScoreForm->WeightEdit->Visible = true;
    }
    ItemScoreForm->ShowModal();
    // store key values for the scale just entered
    for (int i = 0; i < ScaleListBox->Items->Count; i++)
    {
        int itemno = ScaleItems[NoScales-1][i];
        if (RadioButton1->Checked == true) // numeric key
            Key[itemno-1] = NumberKey[i];
        if (RadioButton2->Checked == true) // letter
            Key[itemno-1] = LetterKey[i];
        if (RadioButton5->Checked == true) // word key
            Key[itemno-1] = WordKey[i];
    }
    NoItems += selected;
    ScoringDefined = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::EnterBitBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = VarListBox->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (VarListBox->Selected[i])
         {
            cellstring = VarListBox->Items->Strings[i];
            ScaleListBox->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < VarListBox->Items->Count; i++)
           {
               if (VarListBox->Selected[i])
               {
                  VarListBox->Items->Delete(i);
                  count--;
               }
           }
     }
     ExitBitBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::ResetBtnClick(TObject *Sender)
{
    if (NumberKey != NULL) delete[] NumberKey;
    if (LetterKey != NULL) delete[] LetterKey;
    for (int i = 0; i < NoVariables; i++)
       if (WordKey[i] != NULL) delete[] WordKey[i];
    if (WordKey != NULL) delete[]WordKey;
    if (ItemWeight != NULL) delete[] ItemWeight;
    if (ItemNoArray != NULL) delete[] ItemNoArray;
    if (noselected != NULL) delete[] noselected;
    for (int i = 0; i < 10; i++)
        if (ScaleItems[i] != NULL) delete[] ScaleItems[i];
    if (ScaleItems != NULL) delete[] ScaleItems;
    if (Key != NULL) delete[] Key;
    for (int i = 0; i < 11; i++)
        if (ScaleNamePtr[i] != NULL) delete[] ScaleNamePtr[i];
    if (ScaleNamePtr != NULL) delete[] ScaleNamePtr;
    FormShow(this);
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::ScaleNameEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key != 13) return;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::AllBtnClick(TObject *Sender)
{
    selected = 0;
    for (int i = 0; i < VarListBox->Items->Count; i++)
    {
        ItemNoArray[selected] = i+1;// Grid column no of item selected
        AnsiString cellstring = VarListBox->Items->Strings[i];
        ScaleListBox->Items->Add(cellstring);
        selected++;
    }
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::CheckBox11Click(TObject *Sender)
{
    if (CheckBox11->Checked == true)
    {
        CheckBox12->Checked = false;
        RadioButton1->Checked = false;
        RadioButton2->Checked = false;
        RadioButton5->Checked = false;
        CheckBox18->Checked = false;
        CheckBox18->Visible = false;
        Label3->Visible = false;
        ScaleNoEdit->Visible = false;
        Label4->Visible = false;
        ScaleNameEdit->Visible = false;
        NextScaleBtn->Visible = false;
        NewScaleBtn->Visible = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::NewScaleBtnClick(TObject *Sender)
{
    NoScales++;
    ScaleNameEdit->Text = "Scale";
    ScaleNameEdit->Text = ScaleNameEdit->Text + NoScales;
    if (NoScales > 10)  {
       Application->MessageBox("A maximum of 10 scales is permitted.",
           "MAX SCALES ERROR!",MB_OK);
       NoScales--;
       return;
    }
    selected = 0;
    ScaleListBox->Clear();
//    ScaleNameEdit->Text = "";
    ScaleNoEdit->Text = NoScales;
}
//---------------------------------------------------------------------------
void __fastcall TTestAnalForm::ICCurves(int scale,TObject *Sender)
{
    int Temp;
    int xvalue;
//    char outline[81];

    // Alocate storage for a sorted scale total, group score and frequency arrays
    try  {
        X = new int[NoCases];
        GroupScore = new int[NoItems+1];
        GroupFreq = new int[NoItems+1];
        ScoreGroup = new double[NoItems+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory!","ALLOCATION ERROR!",MB_OK);
        return;
    }

    // Initialize arrays
    for (int i = 0; i < NoItems+1; i++)
    {
        ScoreGroup[i] = 0.0;
        GroupScore[i] = 0.0;
        GroupFreq[i] = 0.0;
    }

    // store the subscores in the X array for sorting
    for (int i = 0; i < NoCases; i++) X[i] = Data[i][NoItems+scale];
    // sort the scores
    for (int i = 0; i < NoCases-1; i++)
    {
        for (int j = i+1; j < NoCases; j++)
        {
            if (X[i] > X[j])
            {
                Temp = X[i];
                X[i] = X[j];
                X[j] = Temp;
            }
        }
    }

    //Get number of unique scoregroups and count of scores in those groups
    int j = 0;
    xvalue = 0.0;  // Total score of a case. Max = no. of items, Min = 0
    GroupScore[0] = xvalue;
    for (int i = 0; i < NoCases; i++)
    {
        if (X[i] > xvalue)
        {
            j++;
            GroupScore[j] = X[i]; //Total score value in group j
            GroupFreq[j]++;
            xvalue = X[i];
        }
        else if (X[i] == xvalue) GroupFreq[j]++;
    }
    int NoGroups = j+1;

    //For each item, obtain the frequency of subjects passing the item
    //in each score group
    for (int i = 0; i < NoItems; i++)
    {
        for (int j = 0; j < NoGroups; j++)
        {
            for (int k = 0; k < NoCases; k++)
            {
                if ((Data[k][i] == 1) && (Data[k][NoItems+scale] == GroupScore[j]))
                    ScoreGroup[j] = ScoreGroup[j] + 1.0;
            }
        }

        //Convert frequency of no. in groups to proportions
        for (int j = 0; j < NoGroups; j++)
        {
            if (GroupFreq[j] > 0) ScoreGroup[j] = ScoreGroup[j] / GroupFreq[j];
            else ScoreGroup[j] = 0.0;
        }

        // Plot the line
        // Allocate space for point sets of means
        GetDblMatMem(GraphForm->Xpoints,1,NoGroups);
        GetDblMatMem(GraphForm->Ypoints,1,NoGroups);
        char Title[81];
        sprintf(Title,"ITEM NO. %d and Scale %d",i+1,scale+1);
        GraphForm->Heading = Title;
        GraphForm->XTitle = "SCORE";
        GraphForm->YTitle = "PROPORTION";
        GraphForm->nosets = 1;
        GraphForm->nbars = NoGroups;
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = true;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clLtGray;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowLeftWall = true;
        GraphForm->ShowRightWall = true;
        GraphForm->ShowBottomWall = true;
        GraphForm->ShowBackWall = true;
        GraphForm->miny = 0.0;
        GraphForm->maxy = 0.0;
        GraphForm->GraphType = 6;  // 2D Line graph
        GraphForm->PtLabels = false;
        for (int k = 0; k < NoGroups; k++)
        {
                GraphForm->Ypoints[0][k] = ScoreGroup[k];
                GraphForm->Xpoints[0][k] = k;
        }
        GraphForm->ShowModal();
        // clean up the heap
        ClearDblMatMem(GraphForm->Xpoints,1);
        ClearDblMatMem(GraphForm->Ypoints,1);
    } // next i

    delete[] ScoreGroup;
    delete[] GroupFreq;
    delete[] GroupScore;
}
//-----------------------------------------------------------------------
void __fastcall TTestAnalForm::StepKR(int scale,TObject *Sender)
{
    double *bi;
    double t;
    double t1;
    double t2;
    double t4;
    double kr20;
    double vv;
    double hv;
    int *invalues;
    int incount;
    int v1;
    int v2;
    int FirstItem;
    int NItems;
    bool done;
    char outline[72];
    int start;

    try  {
        invalues = new int[NoItems];
        bi = new double[NoItems];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in stepkr routine.","ERROR",MB_OK);
        return;
    }

    if (CheckBox11->Checked) start = 1;
    else start = 0;
    //Get beginning and end item indexes for this scale
    int index = 0;
    for (int i = 0; i < NoScales; i++)
    {
        for (int j = 0; j < noselected[i]; j++)
        {
            if (scale == i)
            {
                FirstItem = index;
                break;
            }
            else index++;
        }
    }
    NItems = noselected[scale];

    //Label the output for this scale
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"STEPWISE KR#20 FOR SCALE %s",ColLabels[NoItems+scale].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);

    //Get item involved in highest item inter-correlation
    hv = -1;
    for (int j = FirstItem; j < FirstItem + NItems-1; j++)
    {
        for (int j1 = j+1; j1 < FirstItem + NItems; j1++)
        {
            if (Matrix[j][j1] > hv)
            {
                hv = Matrix[j][j1];
                v1 = j;
                v2 = j1;
            }
        }
    }
    invalues[0] = v1;
    invalues[1] = v2;
    incount = 2;

    // get count of unfiltered cases
    int count = 0;
    if (FilterOn)
    {
       for (int i = start; i < NoCases; i++)
           if (MainForm->Grid->Cells[FilterCol][i+1] == "YES") count++;
    }
    else
    {
        if (CheckBox11->Checked) count = NoCases - 1;
        else count = NoCases;
    }

    // Now, add items based on highest biserials with the new subscores
    done = false;
    while (!done)
    {
        t1 = 0.0;
        t2 = 0.0;
        t4 = 0.0;
        for (int j = 0; j < NItems; j++) bi[j] = 0.0; //initialize array
        // Get total of entered items and cross-product of that total with
        // each item in the scale
        for (int i = 0; i < count; i++)
        {
            t = 0.0;
            for (int j = 0; j < incount; j++)
            {
                t = t + (double)Data[i][invalues[j]];
            }
            // Above is total of the items entered for a case (score on this set)
            t1 = t1 + t; // Sum of scores for the cases
            t2 = t2 + (t * t); //Sum of squared squared scores for the cases
            for (int j = 0; j < NItems; j++)
                bi[j] = bi[j] + (double)Data[i][FirstItem+j] * t; //Item-score cross-prod.
        }
        t1 = t1 / double(count); // Mean of scores (for items entered)
        for (int j = 0; j < NItems; j++) // Get bivariate correlations
        {
            if (Variances[FirstItem+j] > 0.0)
            {
                 bi[j] = bi[j] / double(count) - (t1 * Means[FirstItem+j]);
                 bi[j] = bi[j] * (double(count) / double(count-1));
            }
        }
        vv = t2 / double(count) - (t1 * t1);
        vv = vv * (double(count) / double(count-1));
        for (int j = 0; j < NItems; j++)
        {
            if ((vv > 0.0) && (Variances[FirstItem+j] > 0.0))
                bi[j] = bi[j] / sqrt(vv * Variances[FirstItem+j]);
            else bi[j] = 0.0;
        }
        for (int j = 0; j < incount; j++) t4 = t4 + Variances[invalues[j]];
        kr20 = (double(incount) / double(incount - 1)) * (1.0 - t4 / vv);
        sprintf(outline,"KR#20 = %6.3f, Mean = %6.3f, Variance = %6.3f",
                kr20,t1,vv);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"ITEM        MEAN   VARIANCE   Pt.Bis. Correlation");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int j = 0; j < incount; j++)
        {
            sprintf(outline,"%10s %6.3f  %6.3f     %6.4f",
                    ColLabels[invalues[j]].c_str(),Means[invalues[j]],
                    Variances[invalues[j]],bi[invalues[j]]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        if (incount == NItems) done = true;
        else
        {
            hv = -1.0;
            //Eliminate current entered items from consideration for next one
            for (int j = 0; j < incount; j++)
            {
                int k = invalues[j];
                bi[k] = -2.0;
            }
            //Of the remaining scale items, select the one with the highest pt.bis
            for (int j = 0; j < NItems; j++)
            {
                if (bi[j] > hv)
                {
                    v1 = FirstItem + j;// points to a Matrix item of the scale
                    hv = bi[j];
                }
            }
            incount++;
            invalues[incount-1] = v1;
        }
    } // while not done

   try  {
        delete[] bi;
        delete[] invalues;
    }
    catch (...)
    {
        Application->MessageBox("Error in deleting a vector.","ERROR",MB_OK);
    }

}
//-----------------------------------------------------------------------
void __fastcall TTestAnalForm::ExitBitBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ScaleListBox->ItemIndex;
     cellstring = ScaleListBox->Items->Strings[index];
     VarListBox->Items->Add(cellstring);
     ScaleListBox->Items->Delete(index);    

}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::CheckBox12Click(TObject *Sender)
{
        CheckBox11->Checked = false;
        RadioButton1->Checked = true;
        Label3->Visible = true;
        ScaleNoEdit->Visible = true;
        Label4->Visible = true;
        ScaleNameEdit->Visible = true;
        NextScaleBtn->Visible = true;
        NewScaleBtn->Visible = true;
        CheckBox18->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::CheckBox18Click(TObject *Sender)
{
    if (CheckBox18->Checked == true) CheckBox6->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::SimMR(TObject *Sender)
{
    int i, j;
    double determinant, df1, df2, StdErr, x;
    char outline[121];
    char valstring[81];
    double **CorrMat, **ProdMat;
    double *R2s, *W, *FProbs;
    bool errorcode;
    AnsiString title;

    GetDblMatMem(CorrMat,NoVariables+1,NoVariables+1);
    R2s = new double[NoVariables];
    W = new double[NoVariables];
    FProbs = new double[NoVariables];
    GetDblMatMem(ProdMat,NoVariables+1,NoVariables+1);

    FrmOutPut->RichOutPut->Clear();
    //  get elements of the matrix
//    determinant = 0.0;
    for (i = 0; i < NoItems; i++)
        for (j = 0; j < NoItems; j++)
            CorrMat[i][j] = Matrix[i][j];
    determinant = Determ(CorrMat,NoItems);
    if (determinant < 0.000001)
    {
        ShowMessage("ERROR! Item Intercorrelation matrix is singular!");
        goto cleanup;
    }
    sprintf(outline,"Determinant of correlation matrix = %8.4f",determinant);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (i = 0; i < NoItems; i++)
        for (j = 0; j < NoItems; j++)
            CorrMat[i][j] = Matrix[i][j];
    SVDinverse(CorrMat,NoItems);

    FrmOutPut->RichOutPut->Lines->Add("Multiple Correlation Coefficients for Each Variable");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%10s%8s%10s%10s%12s%5s%5s","Variable","R","R2","F","Prob.>F","DF1","DF2");
    FrmOutPut->RichOutPut->Lines->Add(outline);

    df1 = (double)NoItems - 1.0;
    df2 = (double) (N - NoItems);

    for (i = 0; i < NoItems; i++)
    {   // R squared values
        R2s[i] = 1.0 - (1.0 / CorrMat[i][i]);
        W[i] = (R2s[i] / df1) / ((1.0-R2s[i]) / df2);
        FProbs[i] =ftest(df1,df2,W[i]);
        sprintf(valstring,"%10s",ColLabels[i]);
        sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%5.0f%5.0f",
        		valstring,sqrt(R2s[i]),R2s[i],W[i],FProbs[i],df1,df2);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (j = 0; j < NoItems; j++)
        {  // betas
        	ProdMat[i][j] = -CorrMat[i][j] / CorrMat[j][j];
        }
    }
    ArrayPrint(ProdMat, NoItems, NoItems, "ITEMS", RowLabels, ColLabels, "Betas in Columns");
    FrmOutPut->RichOutPut->Lines->Add("Standard Errors of Prediction");
    FrmOutPut->RichOutPut->Lines->Add("Variable     Std.Error");
    for (i = 0; i < NoItems; i++)
    {
    	StdErr = double(N-1) * Variances[i] * (1.0 / CorrMat[i][i]);
        StdErr = sqrt(StdErr / (double)(N - NoItems));
        sprintf(valstring,"%10s",ColLabels[i]);
        sprintf(outline,"%10s%10.3f",valstring,StdErr);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    for (i = 0; i < NoItems; i++)
    	for (j = 0; j < NoItems; j++)
        	if (i != j)  ProdMat[i][j] = ProdMat[i][j] * (StdDevs[j]/StdDevs[i]);
    ArrayPrint(ProdMat, NoItems, NoItems, "ITEMS", RowLabels, ColLabels, "Raw Regression Coefficients");
    FrmOutPut->RichOutPut->Lines->Add("Variable   Constant");
    for (i = 0; i < NoItems; i++)
    {
    	x = 0.0;
        for (j = 0; j < NoItems; j++)
        {
        	if (i != j)  x = x + (ProdMat[j][i] * Means[j]);
        }
        x = Means[i] - x;
        sprintf(valstring,"%10s",ColLabels[i]);
        sprintf(outline,"%10s%10.3f",valstring,x);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

cleanup:
    GetDblMatMem(CorrMat,NoVariables+1,NoVariables+1);
    R2s = new double[NoVariables];
    W = new double[NoVariables];
    FProbs = new double[NoVariables];
    GetDblMatMem(ProdMat,NoVariables+1,NoVariables+1);
    ClearDblMatMem(ProdMat,NoVariables+1);
//    ProdMat = NULL;
    delete[] FProbs;
//    FProbs = NULL;
    delete[] W;
//    W = NULL;
    delete[] R2s;
//    R2s = NULL;
    ClearDblMatMem(CorrMat,NoVariables+1);
//    CorrMat = NULL;
    FrmOutPut->ShowModal();
}
//-------------------------------------------------------------------

void __fastcall TTestAnalForm::PlotScores(TObject *Sender)
{
       double *rowvar, *totscrs;
       int i, j;
       double temp;

       rowvar = new double[NoCases];
       totscrs = new double[NoCases];
       // use rowvar to hold case no.
       for (i = 1; i <= N; i++) rowvar[i-1] = i;
       // use totscrs to hold total subject scores
       for (i = 1; i <= N; i++) totscrs[i-1] = Data[i-1][NoItems];
       // sort into ascending order
       for (i = 1; i < N; i++)
       {
            for (j = i + 1; j <= N; j++)
            {
                 if (totscrs[i-1] > totscrs[j-1]) // swap
                 {
                      temp = totscrs[j-1];
                      totscrs[j-1] = totscrs[i-1];
                      totscrs[i-1] = temp;
                      temp = rowvar[j-1];
                      rowvar[j-1] = rowvar[i-1];
                      rowvar[i-1] = temp;
                 }
            }
       }
       GetDblMatMem(GraphForm->Ypoints,1,NoCases);
       GetDblMatMem(GraphForm->Xpoints,1,NoCases);
       for (i = 1; i <= N; i++)
       {
            GraphForm->Ypoints[0][i-1] = totscrs[i-1];
            GraphForm->Xpoints[0][i-1] = rowvar[i-1];
       }
       GraphForm->nosets = 1;
       GraphForm->nbars = N;
       GraphForm->Heading = "DISTRIBUTION OF TOTAL SCORES";
       GraphForm->XTitle = "Case";
       GraphForm->YTitle = "Score";
       GraphForm->barwideprop = 0.5;
       GraphForm->AutoScale = true;
       GraphForm->GraphType = 3; // 3d Vertical Bar Chart
       GraphForm->BackColor = clYellow;
       GraphForm->WallColor = clBlack;
       GraphForm->FloorColor = clLtGray;
       GraphForm->ShowBackWall = true;
       GraphForm->ShowModal();

       ClearDblMatMem(GraphForm->Xpoints,1);
       GraphForm->Xpoints = NULL;
       ClearDblMatMem(GraphForm->Ypoints,1);
       GraphForm->Ypoints = NULL;
       delete[] rowvar;
//       rowvar = NULL;
       delete[] totscrs;
//       totscrs = NULL;
}
//-------------------------------------------------------------------

void __fastcall TTestAnalForm::PlotMeans(TObject *Sender)
{
       double *rowvar;
       int i;

       rowvar = new double[NoItems];
       GetDblMatMem(GraphForm->Ypoints,1,NoItems);
       GetDblMatMem(GraphForm->Xpoints,1,NoItems);
       // use rowvar to hold variable no.
       for (i = 1; i <= NoItems; i++)
       {
            rowvar[i-1] = i;
            GraphForm->Xpoints[0][i-1] = i;
            GraphForm->Ypoints[0][i-1] = Means[i-1];
       }
       GraphForm->nosets = 1;
       GraphForm->nbars = NoItems;
       GraphForm->Heading = "ITEM MEANS";
       GraphForm->XTitle = "Item No.";
       GraphForm->YTitle = "Mean";
       GraphForm->barwideprop = 0.5;
       GraphForm->AutoScale = true;
       GraphForm->GraphType = 3; // 3d Vertical Bar Chart
       GraphForm->BackColor = clYellow;
       GraphForm->WallColor = clBlack;
       GraphForm->FloorColor = clLtGray;
       GraphForm->ShowBackWall = true;
       GraphForm->ShowModal();

       ClearDblMatMem(GraphForm->Xpoints,1);
       GraphForm->Xpoints = NULL;
       ClearDblMatMem(GraphForm->Ypoints,1);
       GraphForm->Ypoints = NULL;
       delete[] rowvar;
//       rowvar = NULL;
}
//-------------------------------------------------------------------


void __fastcall TTestAnalForm::LastInBtnClick(TObject *Sender)
{
     int index = VarListBox->ItemIndex;
     if (index < 0) return;
     LastNameEdit->Text = VarListBox->Items->Strings[index];
     VarListBox->Items->Delete(index);
     LastInBtn->Visible = false;
     LastOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::LastOutBtnClick(TObject *Sender)
{
     VarListBox->Items->Add(LastNameEdit->Text);
     LastNameEdit->Text = "";
     LastOutBtn->Visible = false;
     LastInBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::FirstInBtnClick(TObject *Sender)
{
     int index = VarListBox->ItemIndex;
     if (index < 0) return;
     FirstNameEdit->Text = VarListBox->Items->Strings[index];
     VarListBox->Items->Delete(index);
     FirstInBtn->Visible = false;
     FirstOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::FirstOutBtnClick(TObject *Sender)
{
     VarListBox->Items->Add(FirstNameEdit->Text);
     FirstNameEdit->Text = "";
     FirstOutBtn->Visible = false;
     FirstInBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::IDInBtnClick(TObject *Sender)
{
     int index = VarListBox->ItemIndex;
     if (index < 0) return;
     IDEdit->Text = VarListBox->Items->Strings[index];
     VarListBox->Items->Delete(index);
     IDInBtn->Visible = false;
     IDOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::IDOutBtnClick(TObject *Sender)
{
     VarListBox->Items->Add(IDEdit->Text);
     IDEdit->Text = "";
     IDOutBtn->Visible = false;
     IDInBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TTestAnalForm::ScoreReport(TObject *Sender)
{

     int i, start, count, col, FNameCol, LNameCol, IDCol;
     char outline[121], namestr[81];

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("TEST SCORING REPORT");
     FrmOutPut->RichOutPut->Lines->Add("");
     if (CheckBox11->Checked)  start = 2;
     else start = 1;
     strcpy(outline,"");
     if (IDEdit->Text != "")
     {
        strcat(outline,"PERSON ID NUMBER ");
        // get column no. of ID
        for (i = 1; i <= NoVariables; i++)
           if (IDEdit->Text == MainForm->Grid->Cells[i][0]) IDCol = i;
     }
     else strcat(outline,"CASE            ");
     if (FirstNameEdit->Text != "")
     {
        strcat(outline,"FIRST NAME ");
        // get column no. of first name
        for (i = 1; i <= NoVariables; i++)
           if (FirstNameEdit->Text == MainForm->Grid->Cells[i][0]) FNameCol = i;
     }
     if (LastNameEdit->Text != "")
     {
        strcat(outline,"LAST NAME ");
        // get column no. of last name
        for (i = 1; i <= NoVariables; i++)
           if (LastNameEdit->Text == MainForm->Grid->Cells[i][0]) LNameCol = i;
     }
     strcat(outline,"TEST SCORE");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     count = 0;
     for (i = start; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ItemNoArray,selected))  continue;
          count = count + 1;
          strcpy(outline,"");
          if (IDEdit->Text != "")
          {
               col = IDCol;
               sprintf(namestr,"%16s",MainForm->Grid->Cells[col][i].c_str());
//               strcpy(namestr,MainForm->Grid->Cells[col][i].c_str());
               strcat(outline,namestr);
          }
          else
          {
               sprintf(namestr,"%16s ",MainForm->Grid->Cells[0][i].c_str());
               strcat(outline,namestr);
          }
          if (FirstNameEdit->Text != "")
          {
               col = FNameCol;
               sprintf(namestr,"%10s ",MainForm->Grid->Cells[col][i].c_str());
               strcat(outline,namestr);
          }
          if (LastNameEdit->Text != "")
          {
               col = LNameCol;
               sprintf(namestr,"%10s ",MainForm->Grid->Cells[col][i].c_str());
               strcat(outline,namestr);
          }
          sprintf(namestr,"%6d",Data[count-1][NoItems]);
          strcat(outline,namestr);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->ShowModal();
}
//-------------------------------------------------------------------

