//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "KohonenUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKohononForm *KohononForm;
//---------------------------------------------------------------------------
__fastcall TKohononForm::TKohononForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
