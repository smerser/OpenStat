//---------------------------------------------------------------------------

#ifndef PlotUnitH
#define PlotUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TPlotForm : public TForm
{
__published:	// IDE-managed Components
   TImage *Image1;
   TPanel *Panel1;
   TButton *ReturnBtn;
   TButton *PrintBtn;
   TButton *SaveBtn;
   TSaveDialog *SaveDialog1;
   void __fastcall PrintBtnClick(TObject *Sender);
   void __fastcall SaveBtnClick(TObject *Sender);
   void __fastcall FormResize(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TPlotForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPlotForm *PlotForm;
//---------------------------------------------------------------------------
#endif
