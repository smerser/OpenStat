//---------------------------------------------------------------------------

#ifndef RChartUnitH
#define RChartUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmRChart : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TEdit *GroupEdit;
    TLabel *Label3;
    TEdit *MeasEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TGroupBox *GroupBox1;
    TRadioButton *Sigma3Btn;
    TRadioButton *Sigma2Btn;
    TRadioButton *Sigma1Btn;
    TRadioButton *SigmaXBtn;
    TEdit *SigmaXEdit;
    TGroupBox *GroupBox2;
    TCheckBox *HiSpecChkBox;
    TEdit *HiSpecEdit;
    TCheckBox *LowSpecChkBox;
    TEdit *LowSpecEdit;
    TCheckBox *TargetChkBox;
    TEdit *TargetEdit;
    TGroupBox *GroupBox3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *DeltaEdit;
    TEdit *AlphaEdit;
    TEdit *BetaEdit;
     TRadioGroup *TypeGrp;
     TBitBtn *GrpInBtn;
     TBitBtn *MeasInBtn;
     TBitBtn *GrpOutBtn;
     TBitBtn *MeasOutBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall pChart(TObject *Sender);
    void __fastcall VCharts(TObject *Sender);
     void __fastcall GrpInBtnClick(TObject *Sender);
     void __fastcall GrpOutBtnClick(TObject *Sender);
     void __fastcall MeasInBtnClick(TObject *Sender);
     void __fastcall MeasOutBtnClick(TObject *Sender);
     void __fastcall TypeGrpClick(TObject *Sender);
private:	// User declarations
    int Type;
public:		// User declarations
    __fastcall TFrmRChart(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmRChart *FrmRChart;
//---------------------------------------------------------------------------
#endif
