//---------------------------------------------------------------------------

#ifndef TwoCorrsUnitH
#define TwoCorrsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTwoCorrsForm : public TForm
{
__published:	// IDE-managed Components
   TRadioGroup *RadioGroup1;
   TRadioGroup *RadioGroup2;
   TPanel *Panel2;
   TLabel *Label9;
   TLabel *Label10;
   TLabel *Label11;
   TLabel *Label12;
   TListBox *VarList;
   TEdit *Xvar;
   TEdit *Yvar;
   TEdit *Grp;
   TMemo *Memo1;
   TLabel *Label13;
   TEdit *CInterval;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *ContinueBtn;
   TPanel *Panel1;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TLabel *Label4;
   TEdit *rxy1;
   TEdit *Size1;
   TEdit *rxy2;
   TEdit *Size2;
   TLabel *Label5;
   TLabel *Label6;
   TLabel *Label7;
   TEdit *rxy;
   TEdit *rxz;
   TEdit *ryz;
   TLabel *Label8;
   TEdit *SampSize;
   TLabel *Label14;
   TEdit *Zvar;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall RadioGroup1Click(TObject *Sender);
   void __fastcall RadioGroup2Click(TObject *Sender);
   void __fastcall ContinueBtnClick(TObject *Sender);
   void __fastcall VarListClick(TObject *Sender);
private:	// User declarations
    bool independent;
    bool griddata;

public:		// User declarations
   __fastcall TTwoCorrsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTwoCorrsForm *TwoCorrsForm;
//---------------------------------------------------------------------------
#endif
