//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MatManUnit.h"
#include "stdio.h"
#include "ScriptEditUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmScriptEditor *FrmScriptEditor;
//---------------------------------------------------------------------------
__fastcall TFrmScriptEditor::TFrmScriptEditor(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmScriptEditor::FormShow(TObject *Sender)
{
     EditLabel->Visible = false;
     LineEdit->Text = "";
     LineEdit->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::SaveBtnClick(TObject *Sender)
{

     int i, Count; //, CurrentObjType;
     AnsiString edititem;
     bool done = false;

     Count = ScriptList->Items->Count;
     if (Count < 1) return;
     MatManForm->ScriptList->Clear();
     for (i = 0; i < Count; i++)
     {
        edititem = ScriptList->Items->Strings[i];
        MatManForm->ScriptList->Items->Add(edititem);
     }
     MatManForm->Save2Click(this);

     MatManForm->ScriptList->Clear();
     for (i = 0; i < Count; i++)
     {
             edititem = ScriptList->Items->Strings[i];
             MatManForm->ScriptList->Items->Add(edititem);
     }
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::EditOptionsClick(TObject *Sender)
{
     FILE *SaveFile;
     int CurrentObjType;
     AnsiString CurrentObjName, cellstring;
     int Count, i;
     char astring[121];

     EditOption = EditOptions->ItemIndex + 1;
     switch (EditOption)
     {
        case 1 :  // delete a line
               EditLabel->Visible = false;
               LineEdit->Visible = false;
               ScriptList->Items->Delete(index);
               ScriptList->SetFocus();
               EditOptions->ItemIndex = -1;
               break;
        case 2 :  // insert a line
               EditLabel->Visible = true;
               EditLabel->Caption = "Enter a new line. End by pressing the Enter key.";
               LineEdit->Visible = true;
               LineEdit->Text = "";
               LineEdit->SetFocus();
               EditOptions->ItemIndex = -1;
               break;
        case 3 :  // edit a line
               EditLabel->Visible = true;
               EditLabel->Caption = "Edit the line. End by pressing the Enter key.";
               LineEdit->Visible = true;
               if (index >= 0)
               {
                    LineEdit->Text = ScriptList->Items->Strings[index];
                    ScriptList->Items->Delete(index);
                    LineEdit->SetFocus();
               }
               EditOptions->ItemIndex = -1;
               break;
        case 4 :   // append another script file
                OpenDialog1->DefaultExt = ".SCP";
                OpenDialog1->Filter = "Script (*.SCP)|*.SCP|All (*.*)|*.*";
                OpenDialog1->FilterIndex = 1;
                if (OpenDialog1->Execute())
                {
                     SaveFile = fopen(OpenDialog1->FileName.c_str(),"r");
                     fread(&CurrentObjType,sizeof(CurrentObjType),1,SaveFile);
                     if (CurrentObjType != 5)
                     {
                          ShowMessage("Not a script file!");
                          fclose(SaveFile);
                          return;
                     }
                     fread(astring,sizeof(astring),1,SaveFile);
                     CurrentObjName = astring;
                     fread(&Count,sizeof(Count),1,SaveFile);
                     for (i = 0; i < Count; i++)
                     {
                          fread(astring,sizeof(astring),1,SaveFile);
                          cellstring = astring;
                          ScriptList->Items->Add(cellstring);
                     }
                     fclose(SaveFile);
                }
                break; // end case 4
     } // end switch
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::ScriptListClick(TObject *Sender)
{
     index = ScriptList->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::LineEditKeyPress(TObject *Sender,
      char &Key)
{
      if (Key == 13)
      {
          ScriptList->Items->Insert(index,LineEdit->Text);
          LineEdit->Text = "";
          LineEdit->Visible = false;
          EditLabel->Visible = false;
      }
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::DirectoryListBox1Change(TObject *Sender)
{
     FileListBox1->Directory = DirectoryListBox1->Directory;
}
//---------------------------------------------------------------------------

void __fastcall TFrmScriptEditor::FileListBox1Click(TObject *Sender)
{
     AnsiString delfile, prmptstr, info;
     int index;

     index = FileListBox1->ItemIndex;
     delfile = FileListBox1->Items->Strings[index];
     prmptstr = "Delete " + delfile + "?";
     info = InputBox("DELETE?",prmptstr,"Y");
     if (info != "Y") return;
     else DeleteFile(delfile);
     FileListBox1->Update();
}
//---------------------------------------------------------------------------

