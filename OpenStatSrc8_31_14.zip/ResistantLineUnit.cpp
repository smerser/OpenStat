//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "PlotUnit.h"
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "OutPut.h"
#include "math.h"
#include "functions.h"
#include "ResistantLineUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TResistantLineForm *ResistantLineForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TResistantLineForm::TResistantLineForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::ResetBtnClick(TObject *Sender)
{
        XInBtn->Visible = true;
        XOutBtn->Visible = false;
        YInBtn->Visible = true;
        YOutBtn->Visible = false;
        XEdit->Text = "";
        YEdit->Text = "";
        StdCorChk->Checked = false;
        GridChk->Checked = false;
        VarList->Clear();
        ConfEdit->Text = "95.0";
        Options->Visible = false;
        for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::XInBtnClick(TObject *Sender)
{
        int index;

        index = VarList->ItemIndex;
        XEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        XOutBtn->Visible = true;
        XInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::YInBtnClick(TObject *Sender)
{
        int index;

        index = VarList->ItemIndex;
        YEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        YOutBtn->Visible = true;
        YInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::XOutBtnClick(TObject *Sender)
{
        VarList->Items->Add(XEdit->Text);
        XEdit->Text = "";
        XInBtn->Visible = true;
        XOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::YOutBtnClick(TObject *Sender)
{
        VarList->Items->Add(YEdit->Text);
        YEdit->Text = "";
        YInBtn->Visible = true;
        YOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::StdCorChkClick(TObject *Sender)
{
        if (StdCorChk->Checked) Options->Visible = true;
        else Options->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TResistantLineForm::ComputeBtnClick(TObject *Sender)
{
        bool savescores = false;
        bool plotmedians = true;

        if (StdCorChk->Checked) stdcorr = true;
        else stdcorr = false;

        // Do standard pm correlation and if requested show outputs
        StandardPM(this);

        // Do the Resistant Line
        ResistLine(this);
}
//---------------------------------------------------------------------------

void __fastcall TResistantLineForm::StandardPM(TObject *Sender)
{
        // standard product-moment correlation procedure
        ColNoSelected = new int[3];
        XScores = new double[NoCases];
        YScores = new double[NoCases];
        GetDblVecMem(UpConf,NoCases+1);  //SetLength(UpConf,NoCases + 1);
        GetDblVecMem(lowConf,NoCases+1); //SetLength(lowConf,NoCases + 1);

        for (int j = 1; j <= NoVariables; j++)
        {
                if (MainForm->Grid->Cells[j][0] == XEdit->Text) XCol = j;
                if (MainForm->Grid->Cells[j][0] == YEdit->Text) YCol = j;
        }
        Nsize = 0;
        ColNoSelected[0] = XCol;
        ColNoSelected[1] = YCol;
        pmcor = 0.0;
        XMean = 0.0;
        YMean = 0.0;
        XVariance = 0.0;
        YVariance = 0.0;
        Xmax = -1.0e20;
        Xmin = 1.0e20;
        Ymax = -1.0e20;
        Ymin = 1.0e20;

        for (int i = 0; i < NoCases; i++)
        {
                XScores[i] = 0.0;
                YScores[i] = 0.0;
        }
        for (int i = 1; i <= NoCases; i++)
        {
                if (!ValidRecord(i,ColNoSelected,2)) continue;
                XScores[Nsize] = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                YScores[Nsize] = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                Nsize = Nsize + 1;
        }
        XLabel = XEdit->Text;
        YLabel = YEdit->Text;

        // sort on the X values
        for (int i = 0; i < Nsize-1; i++)
        {
                for (int j = i + 1; j <= Nsize-1; j++)
                {
                        if (XScores[i] > XScores[j]) // swap
                        {
                                Tempx = XScores[i];
                                Tempy = YScores[i];
                                XScores[i] = XScores[j];
                                XScores[j] = Tempx;
                                YScores[i] = YScores[j];
                                YScores[j] = Tempy;
                        }
                }
        }
        // calculate the statistics
        for (int i = 0; i < Nsize; i++)
        {
                XMean += XScores[i];
                YMean += YScores[i];
                XVariance += (XScores[i] * XScores[i]);
                YVariance += (YScores[i] * YScores[i]);
                pmcor += (XScores[i] * YScores[i]);
                if (XScores[i] > Xmax) Xmax = XScores[i];
                if (XScores[i] < Xmin) Xmin = XScores[i];
                if (YScores[i] > Ymax) Ymax = YScores[i];
                if (YScores[i] < Ymin) Ymin = YScores[i];
        }
        pmcor -= (XMean * YMean) / Nsize;
        pmcor /= (Nsize-1);
        XVariance -= (XMean * XMean / Nsize);
        SSx = XVariance;
        XVariance /= (Nsize - 1);
        YVariance -= (YMean * YMean / Nsize);
        YVariance /= (Nsize - 1);
        XStdDev = sqrt(XVariance);
        YStdDev = sqrt(YVariance);
        XMean /= Nsize;
        YMean /= Nsize;
        pmcor /= (XStdDev * YStdDev);
        if ((Nsize > 0) && (pmcor < 1.0))
        {
                z = fabs(pmcor) * (sqrt((Nsize)/(1.0 - (pmcor * pmcor))));
                rprob = tprob(z,Nsize-2);
        }
        else
        {
                z = 999.9;
                rprob = 0.0;
        }
        Slope = pmcor * YStdDev / XStdDev;
        Intercept = YMean - Slope * XMean;
        SEPred = sqrt(1.0 - (pmcor * pmcor)) * YStdDev;
        SEPred = SEPred * sqrt((Nsize - 1) / (Nsize - 2));

        if (stdcorr)
        {
                FrmOutPut->RichOutPut->Clear();
                sprintf(outstring,"%s vs %s",XLabel,YLabel);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                sprintf(outstring,"Correlation = %6.4f, N Cases = %d",pmcor,Nsize);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                sprintf(outstring,"t value with %d degrees of freedom = %8.4f with prob. > t = %6.4f",
                      Nsize-2,z,rprob);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->RichOutPut->Lines->Add("Variable     Mean   Variance  Std.Dev.");
                sprintf(outstring,"%-10s%8.2f  %8.2f  %8.2f",XEdit->Text.c_str(),XMean,XVariance,XStdDev);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                sprintf(outstring,"%-10s%8.2f  %8.2f  %8.2f",YEdit->Text.c_str(),YMean,YVariance,YStdDev);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                sprintf(outstring,"Correlation = %6.4f, Slope = %8.2f, Intercept = %8.2f",
                        pmcor, Slope, Intercept);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
                sprintf(outstring,"Standard Error of Estimate = %8.2f",SEPred);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
        }

        // get upper and lower confidence points for each X value
        if (ConfChk->Checked)
        {
          ConfBand = StrToFloat(ConfEdit->Text) / 100.0;
          DF = Nsize - 2;
          t = inverset(ConfBand,DF);
          for (int i = 0; i < Nsize; i++)
          {
               X = XScores[i];
               predicted = Slope * X + Intercept;
               sedata = SEPred * sqrt(1.0 + (1.0 / Nsize) + ((X - XMean) * (X - XMean) / SSx));
               UpConf[i] = predicted + (t * sedata);
               lowConf[i] = predicted - (t * sedata);
               if (UpConf[i] > Ymax) Ymax = UpConf[i];
               if (lowConf[i] < Ymin)Ymin = lowConf[i];
          }
        }
        else ConfBand = 0.0;
        if (stdcorr) FrmOutPut->ShowModal();

        // plot the values (and optional line and confidence band if elected)
        if (stdcorr)
        {
                plotxy(XScores, YScores, UpConf, lowConf, ConfBand, XMean, YMean, pmcor,
                  Slope, Intercept, Xmax, Xmin, Ymax, Ymin, Nsize,1);
                PlotForm->ShowModal();
        }
        // cleanup
        delete[] lowConf;
        delete[] UpConf;
        delete[] YScores;
        delete[] XScores;
        delete[] ColNoSelected;
}
//--------------------------------------------------------------------------

void __fastcall TResistantLineForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double *UpConf,
                                      double *LowConf,
                                      double ConfBand,
                                      double Xmean,
                                      double Ymean,
                                      double R,
                                      double Slope,
                                      double Intercept,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N,
                                      int PlotNo)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     double YU, YL, XU, XL;
     AnsiString Title;
     char outline[121];

     if (PlotNo == 1)
     {
        Title = "X versus Y PLOT Using File: " + MainForm->FileNameEdit->Text;
        PlotForm->Caption = Title;
     }
     else
     {
        Title = "Median Plot for three groups";
        PlotForm->Caption = Title;
     }
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw Means
     if (DescChk->Checked)
     {
          ypos = ceil(vhi * ( (Ymax - Ymean) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + YEdit->Text;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

          xpos = ceil(hwide * ( (Xmean - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          ypos = vtop;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = vbottom;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + XEdit->Text;
          strhi = PlotForm->Image1->Canvas->TextWidth(Title);
          xpos = xpos - strhi / 2;
          ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw slope line
     if (LineChk->Checked)
     {
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          Yvalue = (Xpoints[0] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[0]- Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          Yvalue = (Xpoints[N-1] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[N-1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit->Text) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XEdit->Text);
     sprintf(outline,"R(X,Y) = %5.3f, Slope = %6.2f, Intercept = %6.2f",
              R,Slope,Intercept);
     Title = outline;
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
     ypos = ypos + 15;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // Draw vertical axis
     Title = YEdit->Text;
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YEdit->Text);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clYellow;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
          if ((PlotNo == 2) && (i == 0))
          {
                PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
                PlotForm->Image1->Canvas->TextOutA(xpos,ypos,"M1");
          }
          if ((PlotNo == 2) && (i > 0))
          {
                PlotForm->Image1->Canvas->LineTo(xpos,ypos);
                sprintf(outline,"M%d",i+1);
                PlotForm->Image1->Canvas->TextOutA(xpos,ypos,outline);
          }
     }
     if ((PlotNo == 2) && (i > 0)) // draw slope line
     {
        PlotForm->Image1->Canvas->Pen->Color = clRed;
        ypos = floor(vhi * ((Ymax - Ypoints[0]) / (Ymax - Ymin)));
        ypos = ypos + vtop;
        xpos = floor(hwide * ((Xpoints[0] - Xmin) / (Xmax - Xmin)));
        xpos = xpos + hleft;
        PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
        YL = Ypoints[0];
        XL = Xpoints[0];
        ypos = floor(vhi * ((Ymax - Ypoints[2]) / (Ymax - Ymin)));
        ypos = ypos + vtop;
        xpos = floor(hwide * ((Xpoints[2] - Xmin) / (Xmax - Xmin)));
        xpos = xpos + hleft;
        PlotForm->Image1->Canvas->LineTo(xpos,ypos);
        YU = Ypoints[2];
        XU = Xpoints[2];
        Slope = (YU - YL) / (XU - XL);
        ypos = vbottom + 20;
        PlotForm->Image1->Canvas->Brush->Color = clYellow;
        sprintf(outline,"Slope = %6.2f",Slope);
        xpos = hleft + (hwide / 2) - PlotForm->Image1->Canvas->TextWidth(outline) / 2;
        ypos = ypos + 15;
        PlotForm->Image1->Canvas->TextOutA(xpos,ypos,outline);
     }
     // draw confidence bands if requested
     if (ConfBand != 0.0)
     {
          PlotForm->Image1->Canvas->Pen->Color = clRed;
          ypos = ceil(vhi * ((Ymax - UpConf[0]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[0] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 1; i < N; i++)
          {
               ypos = ceil(vhi * ((Ymax - UpConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
          ypos = ceil(vhi * ((Ymax - LowConf[0]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[0] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 1; i < N; i++)
          {
               ypos = ceil(vhi * ((Ymax - LowConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
     }
}
//-------------------------------------------------------------------

void __fastcall TResistantLineForm::ResistLine(TObject *Sender)
{
// Resistance Line Analysis
        int size, size1, size2, size3, j;
        int *GrpSize;
        double *XMedians, *YMedians, *XVector, *YVector;
        double slope1, slope2, slope, tempx, c, c1, c2, c3;

        GrpSize = new int[3];
        XMedians = new double[3];
        YMedians = new double[3];
        XVector = new double[Nsize];
        YVector = new double[Nsize];

        size = Nsize / 3;
        size1 = size;
        size3 = size;
        size2 = Nsize - size1 - size3;
        GrpSize[0] = size1;
        GrpSize[1] = size2;
        GrpSize[2] = size3;
        FrmOutPut->RichOutPut->Clear();
        // Get median for each group of x and y values
        // First group
        for (int i = 0; i < size1; i++)
        {
                XVector[i] = XScores[i];
                YVector[i] = YScores[i];
        }
        XMedians[0] = Median(XVector,size1);
        YMedians[0] = Median(YVector,size1);
        // second group
        j = 0;
        for (int i = size1; i < (size1 + size2); i++)
        {
                XVector[j] = XScores[i];
                YVector[j] = YScores[i];
                j = j +1;
        }
        XMedians[1] = Median(XVector,size2);
        YMedians[1] = Median(YVector,size2);
        // third group
        j = 0;
        for (int i = (size1 + size2); i <= Nsize; i++)
        {
                XVector[j] = XScores[i];
                YVector[j] = YScores[i];
                j = j + 1;
        }
        XMedians[2] = Median(XVector,size3);
        YMedians[2] = Median(YVector,size3);

        FrmOutPut->RichOutPut->Lines->Add("Group   X Median    Y Median    Size");
        for (int i = 0; i <= 2; i++)
        {
                sprintf(outstring,"%3d     %5.3f     %5.3f     %d",i+1,XMedians[i],
                   YMedians[i], GrpSize[i]);
                FrmOutPut->RichOutPut->Lines->Add(outstring);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        slope1 = (YMedians[1] - YMedians[0]) / (XMedians[1] - XMedians[0]);
        slope2 = (YMedians[2] - YMedians[1]) / (XMedians[2] - XMedians[1]);
        slope = (YMedians[2] - YMedians[0]) / (XMedians[2] - XMedians[0]);
        c1 = slope * XMedians[0] - YMedians[0];
        c2 = slope * XMedians[1] - YMedians[1];
        c3 = slope * XMedians[2] - YMedians[2];
        c = (c1 + c2 + c3) / 3.0;
        sprintf(outstring,"Half Slopes = %9.3f and %9.3f",slope1,slope2);
        FrmOutPut->RichOutPut->Lines->Add(outstring);
        sprintf(outstring,"Slope = %9.3f",slope);
        FrmOutPut->RichOutPut->Lines->Add(outstring);
        tempx = slope2 / slope1;
        sprintf(outstring,"Ratio of half slopes = %9.3f",tempx);
        FrmOutPut->RichOutPut->Lines->Add(outstring);
        sprintf(outstring,"Equation: y = %9.3f * X + (%9.3f)",slope,c);
        FrmOutPut->RichOutPut->Lines->Add(outstring);
        FrmOutPut->ShowModal();

        // check for saving predicted and residuals
        if (GridChk->Checked == true)
        {
                int col = NoVariables + 1;
                NewVar(col,false);
                MainForm->Grid->Cells[col][0] = "Predicted";
                DictionaryForm->DGrid->Cells[1][col] = "Predicted";
                col = NoVariables + 1;
                NewVar(col,false);
                MainForm->Grid->Cells[col][0] = "Residual";
                DictionaryForm->DGrid->Cells[1][col] = "Residual";
                MainForm->Grid->ColCount += 2;
                for (int i = 1; i <= NoCases; i++)
                {
                        if (!ValidRecord(i,ColNoSelected,2)) continue;
                        X = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                        Y = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                        if (c >= 0.0) predicted = slope * X + c;
                        else predicted = slope * X - c;
                        Y = Y - predicted;
                        sprintf(outstring,"%9.3f",predicted);
                        MainForm->Grid->Cells[NoVariables-1][i] = outstring;
                        sprintf(outstring,"%9.3f",Y);
                        MainForm->Grid->Cells[NoVariables][i] = outstring;
                }
        }
        MainForm->Grid->ColCount = NoVariables + 1;
        Intercept = c;
        ConfBand = 0.0;
        // check for plotting medians
        if (PlotMediansChk->Checked == true)
        {
                plotxy(XMedians,YMedians,UpConf,lowConf,ConfBand,XMean,YMean,pmcor,
                   slope, Intercept, Xmax, Xmin, Ymax, Ymin, 3, 2);
                PlotForm->ShowModal();
        }

        // cleanup
        delete[] YVector;
        delete[] XVector;
        delete[] YMedians;
        delete[] XMedians;
        delete[] GrpSize;
}
//---------------------------------------------------------------------

double TResistantLineForm::Median(double *x, int size)
{
// procedure to obtain the median of x values with n = size
        int midpt;
        double median, value;

        if (size > 2)
        {
                midpt = size / 2;
                if ((2 * midpt) == size) // even no. of values
                        value = (x[midpt - 1] + x[midpt]) / 2;
                else value = x[midpt];
                median = value;
        }
        else if (size == 2) median = (x[0] + x[1]) / 2;
        return (median);
}

