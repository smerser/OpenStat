//---------------------------------------------------------------------------

#ifndef BestRegUnitH
#define BestRegUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TBestRegForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TBitBtn *DepInBtn;
     TBitBtn *DepOutBtn;
     TBitBtn *IndInBtn;
     TBitBtn *IndOutBtn;
     TBitBtn *AllBtn;
     TOpenDialog *OpenDialog1;
     TLabel *Label2;
     TEdit *DepEdit;
     TLabel *Label3;
     TListBox *SelList;
     TSaveDialog *SaveDialog1;
     TGroupBox *GroupBox1;
     TCheckBox *MatInChk;
     TCheckBox *SaveCorrsChk;
     TCheckBox *PredictChk;
     TCheckBox *CrossProdChk;
     TCheckBox *CovarChk;
     TCheckBox *CorrsChk;
     TCheckBox *InverseChk;
     TCheckBox *MeansChk;
     TCheckBox *VariancesChk;
     TCheckBox *StdDevsChk;
     TGroupBox *GroupBox2;
     TLabel *Label4;
     TLabel *Label5;
     TEdit *InProbEdit;
     TEdit *OutProbEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TCheckBox *ShowComboChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall DepInBtnClick(TObject *Sender);
     void __fastcall DepOutBtnClick(TObject *Sender);
     void __fastcall IndInBtnClick(TObject *Sender);
     void __fastcall IndOutBtnClick(TObject *Sender);
     void __fastcall AllBtnClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
     void __fastcall MatInChkClick(TObject *Sender);
private:	// User declarations
   AnsiString *pred_labels, *RowLabels, *ColLabels;
   int y_ptr, v, ii, jj, pointer, sets, last_set, first_pt, testval;
   int *Selected, *Max_Set, *ColNoSelected, df_reg, df_res, df1, df_tot;
   int errorcode, NCases, NoVars, DepVarCol, no_predictors;
   double **cross_prod;
   double **ind_mat;
   bool end_of_set, all_done, more_to_do, errcode;
   double *sumx, *mean, *stddev, *variance, *xycross, *raw_b;
   double count, b_zero, stop_prob, mult_R2, biggest_R2, last_R2, f_test;
   double t, beta, ss_res, ms_res, ss_reg, ms_reg;
   double prob_f, ss_total, seb, R2_diff, prout;
   void __fastcall INIT(TObject *Sender);
   void __fastcall REGRESS(TObject *Sender);
   void __fastcall BEST_SET_STATS(TObject *Sender);
   void __fastcall bump_one(TObject *Sender);
   void __fastcall start_set(TObject *Sender);
   void __fastcall re_set(TObject *Sender);

public:		// User declarations
     __fastcall TBestRegForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBestRegForm *BestRegForm;
//---------------------------------------------------------------------------
#endif
