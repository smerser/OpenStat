//---------------------------------------------------------------------------

#ifndef PrevFileUnitH
#define PrevFileUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TPrevFileForm : public TForm
{
__published:	// IDE-managed Components
   TStringGrid *Grid;
   TLabel *Label1;
   TButton *Return;
   TOpenDialog *OpenDialog1;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall ReturnClick(TObject *Sender);
   void __fastcall GridClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TPrevFileForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPrevFileForm *PrevFileForm;
//---------------------------------------------------------------------------
#endif
