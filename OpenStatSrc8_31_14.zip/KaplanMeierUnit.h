//---------------------------------------------------------------------------

#ifndef KaplanMeierUnitH
#define KaplanMeierUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TKaplanMeierForm : public TForm
{
__published:	// IDE-managed Components
    TListBox *VarList;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *TimeEdit;
    TEdit *EndpointEdit;
    TEdit *GroupEdit;
    TGroupBox *GroupBox1;
    TCheckBox *SurvivalChk;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TCheckBox *PrintChk;
    TBitBtn *TimeInBtn;
    TBitBtn *TimeOutBtn;
    TBitBtn *EventInBtn;
    TBitBtn *EventOutBtn;
    TBitBtn *GroupInBtn;
    TBitBtn *GroupOutBtn;
    TLabel *Label6;
    TMemo *Memo1;
        TLabel *Label5;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall TimeInBtnClick(TObject *Sender);
    void __fastcall TimeOutBtnClick(TObject *Sender);
    void __fastcall EventInBtnClick(TObject *Sender);
    void __fastcall EventOutBtnClick(TObject *Sender);
    void __fastcall GroupInBtnClick(TObject *Sender);
    void __fastcall GroupOutBtnClick(TObject *Sender);
private:	// User declarations
    int *SurvivalTimes;
    int *ExpCnt;
    int *CntrlCnt;
    int *TotalatRisk;
    double *ExpatRisk;
    double *CntrlatRisk;
    int *Deaths;
    int *Group;
    int *Censored;
    double *ExpProp;
    double *CntrlProp;
    double *CumPropExp;
    double *CumPropCntrl;
    int TotalN;
    AnsiString *ColLabels;
    bool ConfInterval;
    bool Graph1;
    bool Graph2;
    bool TwoGroups;  // if two groups are used
    AnsiString TimeLabel;
    AnsiString DeathsLabel;
    AnsiString GroupLabel;
    int TimeCol;
    int DeathsCol;
    int CensoredCol;
    int GroupCol;
    void plotxy(int *Xpoints, double *Ypoints, int *Dropped, int *Dropped2,
                double Xmax, double Xmin, double Ymax, double Ymin, int N,
                char *XEdit, char *YEdit, int curveno);

public:		// User declarations
    __fastcall TKaplanMeierForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKaplanMeierForm *KaplanMeierForm;
//---------------------------------------------------------------------------
#endif
