//---------------------------------------------------------------------------
#ifndef BreakDownH
#define BreakDownH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmBrkDwn : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TListBox *ListBox2;
    TLabel *Label3;
    TEdit *DepVarEdit;
    TGroupBox *GroupBox1;
    TLabel *Label4;
    TBitBtn *VarInBtn;
    TBitBtn *VarOutBtn;
    TButton *AllBtn;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TGroupBox *GroupBox2;
    TCheckBox *AnovaChkBox;
        TBitBtn *ContInBtn;
        TBitBtn *ContOutBtn;void __fastcall VarInBtnClick(TObject *Sender);
    void __fastcall VarOutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall ListBox2Click(TObject *Sender);
        void __fastcall ContInBtnClick(TObject *Sender);
        void __fastcall ContOutBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmBrkDwn(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmBrkDwn *FrmBrkDwn;
//---------------------------------------------------------------------------
#endif
int Index_Pos(int *X, int *displace, int ListSize);
