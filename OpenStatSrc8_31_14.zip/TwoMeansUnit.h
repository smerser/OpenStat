//---------------------------------------------------------------------------

#ifndef TwoMeansUnitH
#define TwoMeansUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTwoMeansForm : public TForm
{
__published:	// IDE-managed Components
   TRadioGroup *RadioGroup1;
   TRadioGroup *RadioGroup2;
   TPanel *Panel1;
   TPanel *Panel2;
   TLabel *Label9;
   TLabel *Label10;
   TLabel *Label11;
   TLabel *Label12;
   TListBox *VarList;
   TEdit *Var1;
   TEdit *Var2;
   TEdit *Grp;
   TMemo *Memo1;
   TLabel *Label13;
   TEdit *CInterval;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *ContinueBtn;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TLabel *Label4;
   TLabel *Label5;
   TLabel *Label6;
   TEdit *Mean1;
   TEdit *Mean2;
   TEdit *SD1;
   TEdit *SD2;
   TEdit *N1;
   TEdit *N2;
   TLabel *Label7;
   TLabel *Label8;
   TEdit *Grp1;
   TEdit *Grp2;
   TLabel *Label14;
   TEdit *Cor12;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall VarListClick(TObject *Sender);
   void __fastcall RadioGroup1Click(TObject *Sender);
   void __fastcall RadioGroup2Click(TObject *Sender);
   void __fastcall ContinueBtnClick(TObject *Sender);
private:	// User declarations
    bool independent;
    bool griddata;
public:		// User declarations
   __fastcall TTwoMeansForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTwoMeansForm *TwoMeansForm;
//---------------------------------------------------------------------------
#endif
