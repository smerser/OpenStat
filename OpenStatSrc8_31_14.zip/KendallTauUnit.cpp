//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "KendallTauUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKendallTauForm *KendallTauForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TKendallTauForm::TKendallTauForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::ResetBtnClick(TObject *Sender)
{
     XEdit->Text = "";
     YEdit->Text = "";
     ZEdit->Text = "";
     XInBtn->Visible = true;
     XOutBtn->Visible = false;
     YInBtn->Visible = true;
     YOutBtn->Visible = false;
     ZInBtn->Visible = true;
     ZOutBtn->Visible = false;
     ShowRanksChk->Checked = false;
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::XInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     XEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     XInBtn->Visible = false;
     XOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::XOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(XEdit->Text);
     XEdit->Text = "";
     XOutBtn->Visible = false;
     XInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::YInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     YEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     YInBtn->Visible = false;
     YOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::YOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(YEdit->Text);
     YEdit->Text = "";
     YOutBtn->Visible = false;
     YInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::ZInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     ZEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ZInBtn->Visible = false;
     ZOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::ZOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ZEdit->Text);
     ZEdit->Text = "";
     ZOutBtn->Visible = false;
     ZInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TKendallTauForm::ComputeBtnClick(TObject *Sender)
{
    int i, j, k, itemp, NoTies, NoTieGroups, NoSelected, col1, col2, col3, NCases;
    int **index;
    double Probability, Temp, TieSum, Avg, t, SumT, r, z, denominator, df, stddev;
    double **Ranks, **X;
    AnsiString cellstring, title;
    char outline[121];
    int *ColNoSelected;
    AnsiString *ColLabels, *RowLabels;
    double Tau, TauXY, TauXZ, TauYZ, Tx, Ty, Tz,Term1, Term2, PartialTau;
    int TiesX, TiesY, TiesZ;
    int result, intvalue;
    double dblvalue, concordant, discordant, variance;
    AnsiString strvalue;
    double v0 = 0.0;
    double vt = 0.0;
    double vu = 0.0;
    double v1 = 0.0;
    double v2 = 0.0;

    // Allocate memory
    GetIntMatMem(index,NoCases,3);
    GetDblMatMem(Ranks,NoCases,3);
    GetDblMatMem(X,NoCases,3);
    ColLabels = new AnsiString[3];
    RowLabels = new AnsiString[NoCases];
    ColNoSelected = new int[NoVariables];

    Tx = 0.0;
    Ty = 0.0;
    Tz = 0.0;
    for (i = 0; i < 2; i++) ColNoSelected[i] = 0;
    
    // Get column numbers and labels of variables selected
    NoSelected = 0;
    for (j = 1; j <= NoVariables; j++)
    {
         cellstring = MainForm->Grid->Cells[j][0];
         if (cellstring == XEdit->Text)
         {
              ColNoSelected[0] = j;
              ColLabels[0] = cellstring;
              NoSelected = NoSelected + 1;
         }
         if (cellstring == YEdit->Text)
         {
              ColNoSelected[1] = j;
              ColLabels[1] = cellstring;
              NoSelected = NoSelected + 1;
         }
         if (cellstring == ZEdit->Text)
         {
              ColNoSelected[2] = j;
              ColLabels[2] = cellstring;
              NoSelected = NoSelected + 1;
         }
    }
    if ((ColNoSelected[0] == 0) || (ColNoSelected[1] == 0))
    {
        ShowMessage("ERROR! One or more variables not defined.");
        goto cleanup;
    }
    // Get scores
    NCases = 0;
    for (i = 1; i <= NoCases; i++)
    {
        if ( ! ValidRecord(i,ColNoSelected,NoSelected)) continue;
        NCases = NCases + 1;
        col1 = ColNoSelected[0];
        col2 = ColNoSelected[1];
        if (NoSelected == 3) col3 = ColNoSelected[2];
        X[NCases-1][0] = StrToFloat(Trim(MainForm->Grid->Cells[col1][i]));
//        Ranks[NCases-1][0] = NCases-1; // X[NCases-1][0];
        X[NCases-1][1] = StrToFloat(Trim(MainForm->Grid->Cells[col2][i]));
//        Ranks[NCases-1][1] = NCases-1; //X[NCases-1][1];
        if (NoSelected == 3)
        {
           X[NCases-1][2] = StrToFloat(Trim(MainForm->Grid->Cells[col3][i]));
//           Ranks[NCases-1][2] = NCases - 1; // X[NCases-1][2];
        }
        // save original sequence of values in an index matrix
        index[NCases-1][0] = NCases;
        index[NCases-1][1] = NCases;
        if (NoSelected == 3) index[NCases-1][2] = NCases;
    }

    for (i = 0; i < NCases; i++) RowLabels[i] = IntToStr(i+1);
    // Sort the first variable (X) and corresponding index
    for (i = 0; i < NCases - 1; i++)
    {
         for (j = i + 1; j < NCases; j++)
         {
            if (X[i][0] > X[j][0]) // swap
            {
                Temp = X[i][0];
                X[i][0] = X[j][0];
                X[j][0] = Temp;
                itemp = index[i][0];
                index[i][0] = index[j][0];
                index[j][0] = itemp;
            }
        }
    }

    // Assign ranks to the sorted values
    for (i = 0; i < NCases; i++) Ranks[i][0] = i+1;

    // Check for ties in each
    i = 1;
    while (i < NCases)
    {
        j = i+1;
        TieSum = 0.0;
        NoTies = 0;
        while (j <= NCases)
        {
            if (X[j-1][0] > X[i-1][0]) goto Check1;
            if (X[j-1][0] == X[i-1][0])
            {
                TieSum = TieSum + Ranks[j-1][0];
                NoTies = NoTies + 1;
            }
            j = j + 1;
        }
Check1:
        if (NoTies > 0) // at least one tie found
        {
            TieSum = TieSum + Ranks[i-1][0];
            NoTies = NoTies + 1;
            Avg = TieSum / NoTies;
            for (j = i; j < i + NoTies; j++) Ranks[j-1][0] = Avg;
            i = i + (NoTies-1);
            Tx = Tx + NoTies *(NoTies-1);
        }
        i = i + 1;
    }
    Tx = Tx / 2.0;

    // Repeat sort for second variable Y
    for (i = 0; i < NCases - 1; i++)
    {
        for (j = i + 1; j < NCases; j++)
        {
            if (X[i][1] > X[j][1]) // swap
            {
                Temp = X[i][1];
                X[i][1] = X[j][1];
                X[j][1] = Temp;
                itemp = index[i][1];
                index[i][1] = index[j][1];
                index[j][1] = itemp;
            }
        }
    }

    // Assign ranks
    for (i = 0; i < NCases; i++) Ranks[i][1] = i+1;

    // Check for ties in each
    i = 1;
    while (i < NCases)
    {
        j = i+1;
        TieSum = 0.0;
        NoTies = 0;
        while (j <= NoCases)
        {
            if (X[j-1][1] > X[i-1][1]) goto Check2;
            if (X[j-1][1] == X[i-1][1])
            {
                TieSum = TieSum + Ranks[j-1][1];
                NoTies = NoTies + 1;
            }
            j = j + 1;
        }
Check2:
        if (NoTies > 0) // at least one tie found
        {
            TieSum = TieSum + Ranks[i-1][1];
            NoTies = NoTies + 1;
            Avg = TieSum / NoTies;
            for (j = i; j < i + NoTies; j++) Ranks[j-1][1] = Avg;
            i = i + (NoTies-1);
            Ty = Ty + NoTies * (NoTies - 1);
        }
        i = i + 1;
    }
    Ty = Ty / 2.0;

    // Repeat for z variable
    if (NoSelected > 2) // z was entered
    {
         for (i = 0; i < NCases - 1; i++)
         {
              for (j = i + 1; j < NCases; j++)
              {
                   if (X[i][2] > X[j][2]) // swap
                   {
                        Temp = X[i][2];
                        X[i][2] = X[j][2];
                        X[j][2] = Temp;
                        itemp = index[i][2];
                        index[i][2] = index[j][2];
                        index[j][2] = itemp;
                   }
              }
         }

         // Assign ranks
         for (i = 0; i < NCases; i++) Ranks[i][2] = i+1;

         // Check for ties in each
         i = 1;
         while (i < NCases)
         {
              j = i+1;
              TieSum = 0.0;
              NoTies = 0;
              while (j <= NoCases)
              {
                   if (X[j-1][2] > X[i-1][2]) goto Check3;
                   if (X[j-1][2] == X[i-1][2])
                   {
                        TieSum = TieSum + Ranks[j-1][2];
                        NoTies = NoTies + 1;
                   }
                   j = j + 1;
              }
Check3:
              if (NoTies > 0) // at least one tie found
              {
                   TieSum = TieSum + Ranks[i-1][2];
                   NoTies = NoTies + 1;
                   Avg = TieSum / NoTies;
                   for (j = i; j < i + NoTies; j++) Ranks[j-1][2] = Avg;
                   i = i + (NoTies-1);
                   Tz = Tz + NoTies * (NoTies - 1);
              }
              i = i + 1;
         }
         Tz = Tz / 2.0;
    }

    // Rearrange ranks into original score order
    for (k = 1; k <= 3; k++)
    {
         for (i = 1; i < NCases; i++)
         {
              for (j = i + 1; j <= NCases; j++)
              {
                   if (index[i-1][k-1] > index[j-1][k-1]) // swap
                   {
                        itemp = index[i-1][k-1];
                        index[i-1][k-1] = index[j-1][k-1];
                        index[j-1][k-1] = itemp;
                        Temp = Ranks[i-1][k-1];
                        Ranks[i-1][k-1] = Ranks[j-1][k-1];
                        Ranks[j-1][k-1] = Temp;
                        Temp = X[i-1][k-1];
                        X[i-1][k-1] = X[j-1][k-1];
                        X[j-1][k-1] = Temp;
                   }
              }
         }
    }

    // print data matrix if option is elected
    FrmOutPut->RichOutPut->Lines->Add("Kendall Tau for File: " + MainForm->FileNameEdit->Text);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Kendall Tau for variables " + ColLabels[0] + " and " + ColLabels[1]);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("     SCORE     RANK      SCORE     RANK");
    for (i = 0; i < NCases; i++)
    {
        sprintf(outline,"%10.2f%10.2f%10.2f%10.2f",
                X[i][0], Ranks[i][0], X[i][1], Ranks[i][1]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    if (NoSelected == 3)
    {
        FrmOutPut->RichOutPut->Lines->Add("SCORES AND RANKS FOR PARTIALED VARIABLE");
        FrmOutPut->RichOutPut->Lines->Add("     SCORE     RANK");
        for (i = 0; i < NCases; i++)
        {
                sprintf(outline,"%10.2f%10.2f",
                        X[i][2], Ranks[i][2]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    
    // compute Tau for X and Y
    // sort on X and obtain SumT for Y ranks
    SumT = 0.0;
    concordant = 0.0;
    discordant = 0.0;
    for (i = 0; i < NCases - 1; i++)
    {
         for (j = i + 1; j < NCases; j++)
         {
            if (Ranks[i][0] > Ranks[j][0]) // swap
            {
                Temp = Ranks[i][0];
                Ranks[i][0] = Ranks[j][0];
                Ranks[j][0] = Temp;
                Temp = Ranks[i][1];
                Ranks[i][1] = Ranks[j][1];
                Ranks[j][1] = Temp;
                if (NoSelected == 3)
                {
                     Temp = Ranks[i][2];
                     Ranks[i][2] = Ranks[j][2];
                     Ranks[j][2] = Temp;
                }
                itemp = index[i][0];
                index[i][0] = index[j][0];
                index[j][0] = itemp;
            }
        }
    }
    for (i = 0; i < NCases - 1; i++)
    {
         for (j = i + 1; j < NCases; j++)
         {
              if (Ranks[i][1] < Ranks[j][1])
              {
                SumT = SumT + 1.0;
                concordant = concordant + 1.0;
              }
              else if (Ranks[i][1] > Ranks[j][1])
              {
                SumT = SumT - 1.0;
                discordant = discordant + 1.0;
              }
         }
    }
    Tau = (concordant - discordant) / (((double)NCases * ((double)NCases-1.0))/2.0);
    if ( (Tx == 0) && (Ty == 0)) // // get variance for Tau-A
    {
        variance = (2.0 * (2.0 * (double)NCases + 5.0)) / (9.0 * (double)NCases * ((double)NCases - 1.0));
        stddev = sqrt(variance);
        z = Tau / stddev;
        Probability = 1.0 - normalprob(z);
        sprintf(outline,"Tau = %6.3f, z = %8.3f, Prob. > z = %8.3f",Tau,z,Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
    }
    else // get Tau-B
    {
        Term1 = ((double)(NCases * (NCases-1)) / 2.0) - (Tx*(Tx-1.0)/2.0);
        Term2 = ((double)(NCases * (NCases-1)) / 2.0) - (Ty*(Ty-1.0)/2.0);
        denominator = sqrt(Term1 * Term2);
        TauXY = SumT / denominator;
//        v0 = (double)NCases * ((double)NCases-1.0) * (2.0 * (double)NCases + 5);
//        Probability = 1.0 - normalprob(z);
        sprintf(outline,"Tau-B = %6.3f",TauXY);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
    }

    if (NoSelected > 2) // get tau values for partial
    {
         // Get TauXZ
         SumT = 0.0;
         for (i = 0; i < NCases - 1; i++)
         {
             for (j = i + 1; j < NCases; j++)
             {
                 if (Ranks[i][2] < Ranks[j][2]) SumT = SumT + 1.0;
                 else if (Ranks[i][2] > Ranks[j][2]) SumT = SumT - 1.0;
             }
         }
         Term1 = sqrt((NCases * (NCases-1)) / 2.0 - Tx);
         Term2 = sqrt((NCases * (NCases-1)) / 2.0 - Tz);
         denominator = Term1 * Term2;
         TauXZ = SumT / denominator;

         // get back to original order then sort on Y
         for (i = 0; i < NCases - 1; i++)
         {
              for (j = i + 1; j < NCases; j++)
              {
                   if (index[i][0] > index[j][0]) // swap
                   {
                        Temp = Ranks[i][0];
                        Ranks[i][0] = Ranks[j][0];
                        Ranks[j][0] = Temp;
                        Temp = Ranks[i][1];
                        Ranks[i][1] = Ranks[j][1];
                        Ranks[j][1] = Temp;
                        Temp = Ranks[i][2];
                        Ranks[i][2] = Ranks[j][2];
                        Ranks[j][2] = Temp;
                        itemp = index[i][0];
                        index[i][0] = index[j][0];
                        index[j][0] = itemp;
                   }
              }
         }

         // Get TauYZ
         for (i = 0; i < NCases - 1; i++) // sort on Y variable
         {
              for (j = i + 1; j < NCases; j++)
              {
                   if (Ranks[i][1] > Ranks[j][1]) // swap
                   {
                        Temp = Ranks[i][1];
                        Ranks[i][1] = Ranks[j][1];
                        Ranks[j][1] = Temp;
                        Temp = Ranks[i][2];
                        Ranks[i][2] = Ranks[j][2];
                        Ranks[j][2] = Temp;
                        itemp = index[i][1];
                        index[i][1] = index[j][1];
                        index[j][1] = itemp;
                   }
              }
         }

         SumT = 0.0;
         concordant = 0.0;
         discordant = 0.0;
         for (i = 0; i < NCases - 1; i++)
         {
             for (j = i + 1; j < NCases; j++)
             {
                 if (Ranks[i][2] < Ranks[j][2])
                 {
                        SumT = SumT + 1.0;
                        concordant = concordant + 1.0;
                 }
                 else if (Ranks[i][2] > Ranks[j][2])
                 {
                        SumT = SumT - 1.0;
                        discordant = discordant + 1.0;
                 }
             }
         }
         Tau = (concordant - discordant) / (((double)NCases * ((double)NCases-1.0))/2.0);

         Term1 = sqrt((double)(NCases * (NCases-1)) / 2.0 - Ty);
         Term2 = sqrt((double)(NCases * (NCases-1)) / 2.0 - Tz);
         denominator = Term1 * Term2;
         TauYZ = SumT / denominator;
         PartialTau = (TauXY - TauXZ * TauYZ) /
            (sqrt(1.0 - sqr(TauXZ)) * sqrt(1.0 - sqr(TauYZ)));
    }

    // do significance tests
    stddev = sqrt( (2.0 * ( 2.0 * (double)NCases + 5.0)) / (9.0 * (double) NCases * ((double)NCases - 1.0)));
//    FrmOutPut->RichOutPut->Clear();
    z = fabs(TauXY / stddev);
    Probability = 1.0 - probz(z);
    sprintf(outline,"Tau = %8.4f  z = %8.3f probability > |z| = %4.3f",TauXY,z,Probability);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (NoSelected > 2)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         z = fabs(TauXZ / stddev);
         Probability = 1.0 - probz(z);
         FrmOutPut->RichOutPut->Lines->Add("Kendall Tau for variables " + ColLabels[0] + " and " + ColLabels[2]);
         sprintf(outline,"Tau = %8.4f  z = %8.3f probability > |z| = %4.3f",TauXZ,z,Probability);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         z = fabs(TauYZ / stddev);
         Probability = 1.0 - probz(z);
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("Kendall Tau for variables " + ColLabels[1] + " and " + ColLabels[2]);
         sprintf(outline,"Tau = %8.4f  z = %8.3f probability > |z| = %4.3f",TauYZ,z,Probability);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"Partial Tau = %8.4f",PartialTau);
         FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("NOTE: Probabilities are for large N (>10)");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

cleanup:
    delete[] ColNoSelected;
    delete[] RowLabels;
    delete[] ColLabels;
    ClearDblMatMem(X,NoCases);
    ClearDblMatMem(Ranks,NoCases);
    ClearIntMatMem(index,NoCases);
}
//---------------------------------------------------------------------------
