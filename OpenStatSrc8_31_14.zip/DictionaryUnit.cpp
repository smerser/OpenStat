//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDictionaryForm *DictionaryForm;
extern int NoVariables;
//---------------------------------------------------------------------------
__fastcall TDictionaryForm::TDictionaryForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDictionaryForm::FormShow(TObject *Sender)
{
   DGrid->ColCount = 7;
   DGrid->ColWidths[0] = 40;
   DGrid->ColWidths[1] = 80;
   DGrid->ColWidths[2] = 160;
   DGrid->ColWidths[3] = 40;
   DGrid->ColWidths[4] = 60;
   DGrid->ColWidths[5] = 60;
   DGrid->ColWidths[6] = 60;
   DGrid->Cells[0][0] = "No.";
   DGrid->Cells[0][1] = IntToStr(1);
   DGrid->Cells[1][0] = "Short Name";
   DGrid->Cells[2][0] = "Long Name";
   DGrid->Cells[3][0] = "Type";
   DGrid->Cells[4][0] = "Integers";
   DGrid->Cells[5][0] = "Decimals";
   DGrid->Cells[6][0] = "Missing";
}
//---------------------------------------------------------------------------
void __fastcall TDictionaryForm::DGridKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
   int row = DGrid->Row;
	if (Key == 40) // downarrow
   {
      if (row == DGrid->RowCount-1)
      {
      	 DGrid->RowCount = DGrid->RowCount + 1;
         DGrid->Cells[0][row+1] = IntToStr(row+1);
         NewVar(NoVariables+1,false);
      }
   }
}
//---------------------------------------------------------------------------
void __fastcall TDictionaryForm::DelRowBtnClick(TObject *Sender)
{
	int row = DGrid->Row;

   for (int i = 0; i < 8; i++) DGrid->Cells[i][row] = "";
   DGrid->RowCount = DGrid->RowCount - 1;
   DGrid->Row = row - 1;	
}
//---------------------------------------------------------------------------
void __fastcall TDictionaryForm::TypeComboClick(TObject *Sender)
{
	int row = TypeCombo->ItemIndex;
   int grow = DGrid->Row;
   switch (row)
   {
   	case 0:
   		DGrid->Cells[3][grow] = "0";
         break;
      case 1:
         DGrid->Cells[3][grow] = "1";
         break;
      case 2:
         DGrid->Cells[3][grow] = "2";
         break;
      case 3:
         DGrid->Cells[3][grow] = "3";
         break;
      case 4:
         DGrid->Cells[3][grow] = "4";
         break;
   }
}
//---------------------------------------------------------------------------
void __fastcall TDictionaryForm::ReturnBtnClick(TObject *Sender)
{
   MainForm->Grid->ColCount = DGrid->RowCount;
   MainForm->NoVarsEdit->Text = IntToStr(DGrid->RowCount-1);
	for (int i = 1; i <= DGrid->RowCount-1; i++)
   	MainForm->Grid->Cells[i][0] = DGrid->Cells[1][i];
}
//---------------------------------------------------------------------------

void __fastcall TDictionaryForm::DefaultBtnClick(TObject *Sender)
{
     NewVar(NoVariables+1,false);
}
//---------------------------------------------------------------------------

