//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "RootMethodUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmRootMethod *FrmRootMethod;
//---------------------------------------------------------------------------
__fastcall TFrmRootMethod::TFrmRootMethod(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmRootMethod::RadioGroup1Click(TObject *Sender)
{
     Choice = RadioGroup1->ItemIndex + 1;     
}
//---------------------------------------------------------------------------
void __fastcall TFrmRootMethod::FormShow(TObject *Sender)
{
     Choice = 1;     
}
//---------------------------------------------------------------------------
