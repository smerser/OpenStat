//---------------------------------------------------------------------------

#ifndef LoanUnitH
#define LoanUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TLoanForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TLabel *Label2;
     TEdit *MonthEdit;
     TLabel *Label3;
     TEdit *DayEdit;
     TLabel *Label4;
     TEdit *YearEdit;
     TLabel *Label5;
     TEdit *AmountEdit;
     TLabel *Label6;
     TEdit *RepayEdit;
     TLabel *Label7;
     TEdit *PayPerYrEdit;
     TLabel *Label8;
     TEdit *InterestEdit;
     TLabel *Label9;
     TEdit *NameEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall Heading(void);
//     double __fastcall REALRAISE(double base, double power);
private:	// User declarations
public:		// User declarations
     __fastcall TLoanForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLoanForm *LoanForm;
//---------------------------------------------------------------------------
#endif
