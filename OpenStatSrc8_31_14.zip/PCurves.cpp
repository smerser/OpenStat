//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "OutPut.h"
#include "math.h"
#include "stdio.h"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
#include "PCurves.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPowCurvs *PowCurvs;
//---------------------------------------------------------------------------
__fastcall TPowCurvs::TPowCurvs(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPowCurvs::BtnCancelClick(TObject *Sender)
{
     PowCurvs->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TPowCurvs::BtnOKClick(TObject *Sender)
{
     double mean;
     double stddev;
     double N;
     double alphas[6];
     double zalphas[6];
     double increment;
     double althyp;
     double xalphas[6];
     double power;
     double zbeta;
     double beta;
     double YPlotPts[6][80];
     double XPlotPts[80];
     double StdErr;
     double XMax = 0.0;
     double Offset;
     int NoPlots = 0;
     int SetNo = 0;
     char LabelStr[21];
     char outline[121];

     mean = atof(PowCurvs->TxtMean->Text.c_str());
     stddev = atof(PowCurvs->TxtStdDev->Text.c_str());
     N = atof(PowCurvs->TxtSize->Text.c_str());
     StdErr = stddev / sqrt(N);  // standard error of mean;
     increment = 4.0 * StdErr / 80.0;  //scale for 80 points

     // Initialize alternative type I error arrays
     for (int i = 0; i < 6; i++)
     {
         alphas[i] = 0.0;
         zalphas[i] = 0.0;
         xalphas[i] = 0.0;
     }

     // Get the desired alpha (Beta) curve options
     if (PowCurvs->Chk01->Checked)  alphas[0] = 0.01;
     if (PowCurvs->Chk025->Checked) alphas[1] = 0.025;
     if (PowCurvs->Chk05->Checked)  alphas[2] = 0.05;
     if (PowCurvs->Chk075->Checked) alphas[3] = 0.075;
     if (PowCurvs->Chk10->Checked)  alphas[4] = 0.10;
     if (PowCurvs->Chk20->Checked)  alphas[5] = 0.20;
     TCursor oldCursor = Screen->Cursor;
     Screen->Cursor = TCursor(crHourGlass);
     // For curves selected, obtain corresponding z and x values
     for (int i = 0; i < 6; i++)
     {
         if (alphas[i] != 0.0)
         {
            zalphas[i] = inversez(1.0 - alphas[i]);
            xalphas[i] = (zalphas[i] * StdErr) + mean;
            if (xalphas[i] > XMax) XMax = xalphas[i];
         }
     }

     // For each curve, obtain and plot 80 alternative hypotheses and
     // their corresponding probabilities
     for (int i = 0; i < 6; i++) // possible curves
     {
         if (alphas[i] != 0.0)   // curve selected?
         {
            Offset = 0.0;
            for (int j = 0; j < 80; j++)  //get points to plot
            {
                althyp = mean + Offset;
                zbeta = (xalphas[i] - althyp ) / StdErr;
                if ( fabs(zbeta) < 5.0) beta = zcumsimp(zbeta);
                else beta = 0.0;
                power = 1.0 - beta;
                XPlotPts[j] = althyp;
                YPlotPts[NoPlots][j] = power;
                Offset += increment;
            }
            NoPlots++;
         }
     } // next curve
     // Plot the points
     // Allocate space for point sets of means
     try
     {
         GetDblMatMem(GraphForm->Xpoints,NoPlots,80);
         GetDblMatMem(GraphForm->Ypoints,NoPlots,80);
     }
     catch (...)
     {
            ShowMessage("Memory Error in obtaining graphing space.");
            return;
     }
     char xTitle[51];
     char yTitle[15];
     sprintf(outline,"z-Test Power. Pop. Mean = %6.2f, Sigma = %6.2f, N = %2.0f",mean,stddev,N);
     GraphForm->Heading = outline;
     sprintf(xTitle,"%6.2f x INCREMENT ABOVE HYPOTHESIZED MEAN",increment);
     GraphForm->XTitle = xTitle;
     sprintf(yTitle,"PROBABILITIES");
     GraphForm->YTitle = yTitle;
     GraphForm->nosets = NoPlots;
     GraphForm->nbars = 80;
     GraphForm->barwideprop = 0.5;
     GraphForm->miny = 0.0;
     GraphForm->maxy = 1.0;
     GraphForm->GraphType = 6;  // Line graph
     GraphForm->AutoScale = false;
     GraphForm->ShowLeftWall = true;
     GraphForm->ShowRightWall = true;
     GraphForm->ShowBottomWall = true;
     GraphForm->ShowBackWall = true;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clLtGray;
     GraphForm->FloorColor = clLtGray;
     GraphForm->PtLabels = true;
     for (int i = 0; i < 6; i++)
     {
         if (alphas[i] != 0.0)
         {
            sprintf(LabelStr,"%4.2f",alphas[i]);
            GraphForm->SetLabels[SetNo] = LabelStr;
            for (int j = 0; j < 80; j++)
            {
                GraphForm->Ypoints[SetNo][j] = YPlotPts[SetNo][j];
                GraphForm->Xpoints[SetNo][j] = XPlotPts[j];
            }
            // end for setting 80 points on the curve
            SetNo++;
         } // end if this curve selected
     } // end for all possible curves
     Screen->Cursor = oldCursor;
     GraphForm->ShowModal();

     // clean up the heap
     ClearDblMatMem(GraphForm->Ypoints,NoPlots);
     ClearDblMatMem(GraphForm->Xpoints,NoPlots);

//     FrmOutPut->Show();
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Power of the z-test for Alternate Hypotheses");
     FrmOutPut->RichOutPut->Lines->Add("");
     strcpy(outline,"Alpha Levels: ");
     for (int i = 0; i < 6; i++)
     {
         if (alphas[i] != 0.0)
         {
            sprintf(LabelStr," %4.2f ",alphas[i]);
            strcat(outline,LabelStr);
         }
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     strcpy(outline,"");
     for (int i = 0; i < 80; i++)
     {
         sprintf(outline,"X = %6.2f    ",XPlotPts[i]);
         SetNo = 0;
         for (int j = 0; j < 6; j++)
         {
             if (alphas[j] != 0.0)
             {
                sprintf(LabelStr,"%4.3f ",YPlotPts[SetNo][i]);
                strcat(outline,LabelStr);
                SetNo++;
             }
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
         strcpy(outline,"");
     }
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TPowCurvs::TxtMeanPress(TObject *Sender, char &Key)
{
     if (Key == 13) // enter key
     {
         TxtStdDev->SetFocus();
         Key = 0;
     }
}
//---------------------------------------------------------------------------

void __fastcall TPowCurvs::TxtSDPress(TObject *Sender, char &Key)
{
     if (Key == 13) // enter key
     {
         TxtSize->SetFocus();
         Key = 0;
     }

}
//---------------------------------------------------------------------------

void __fastcall TPowCurvs::TxtSizePress(TObject *Sender, char &Key)
{
     if (Key == 13) // enter key
     {
         BtnOK->SetFocus();
         Key = 0;
     }

}
//---------------------------------------------------------------------------

