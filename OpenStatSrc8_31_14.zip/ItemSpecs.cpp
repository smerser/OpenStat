//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdlib.h>
#include "ItemSpecs.h"
#include "ItemAnal.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TItemScoreForm *ItemScoreForm;
extern int *NumberKey;
extern char *LetterKey;
extern char **WordKey;
extern double *ItemWeight;

//---------------------------------------------------------------------------
__fastcall TItemScoreForm::TItemScoreForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TItemScoreForm::UpDown1Click(TObject *Sender,
      TUDBtnType Button)
{
    int itemno = atoi(ItemNoEdit->Text.c_str());
    if (Button == 0 ) // up button
    {
        if (itemno < UpDown1->Max)
        {
            itemno++;
            ItemNoEdit->Text = itemno;
            CorrectEdit->SetFocus();
        }
    }
    if (Button == 1) // down button
    {
        if (itemno > 1)
        {
            itemno--;
            ItemNoEdit->Text = itemno;
            CorrectEdit->SetFocus();
        }
    }
    if (TestAnalForm->RadioButton1->Checked == true) // number
            CorrectEdit->Text = NumberKey[itemno-1];
    if (TestAnalForm->RadioButton2->Checked == true) // letter
            CorrectEdit->Text = LetterKey[itemno-1];
    if (TestAnalForm->RadioButton5->Checked == true) // word key
            CorrectEdit->Text = WordKey[itemno-1];
    if (TestAnalForm->CheckBox18->Checked == true)
            WeightEdit->Text = ItemWeight[itemno-1];
}
//---------------------------------------------------------------------------
void __fastcall TItemScoreForm::CorrectEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key != 13) return;
    int value;
    int itemno = atoi(ItemNoEdit->Text.c_str());
    // check for correct type of key value
    if (TestAnalForm->RadioButton1->Checked == true) // number
    {
        value = CorrectEdit->Text.ToIntDef(-9);
        if (value == -9) {
           Application->MessageBox("Not a number.","ERROR",MB_OK);
           return;
        }
        else // save key value in numeric KeyArray;
        {
           int itemno = atoi(ItemNoEdit->Text.c_str());
           NumberKey[itemno-1] = value;
        }
    }
    if (TestAnalForm->RadioButton2->Checked == true) // letter
    {
        char astring[5];
        strcpy(astring,CorrectEdit->Text.c_str());
        char letter = astring[0];
        if ((isalpha(letter)) > 0) { // first character is a letter
           LetterKey[itemno-1] = letter;
        }
        else {
           Application->MessageBox("Key value is not a character.","ERROR",MB_OK);
           return;
        }
    }
    if (TestAnalForm->RadioButton5->Checked == true) // word key
    {
        strcpy(WordKey[itemno-1],CorrectEdit->Text.c_str());
        if (CorrectEdit->Text == "")
        {
            Application->MessageBox("Blank not acceptable.","ERROR",MB_OK);
            return;
        }
    }

    if (TestAnalForm->CheckBox18->Checked != true)
    {
        if (itemno == UpDown1->Max)
        {
            OKBtn->SetFocus();
            return;
        }
//        CorrectEdit->Text = "";
//        WeightEdit->Text = "";
        itemno++;
        ItemNoEdit->Text = itemno;
    }
    else WeightEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TItemScoreForm::OKBtnClick(TObject *Sender)
{
    ItemScoreForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TItemScoreForm::WeightEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key != 13) return;
    int value;
    int itemno;
    // check for correct type of key value
    try  {
        value = WeightEdit->Text.ToDouble();
    }
    catch (...)
    {
        Application->MessageBox("Not a numeric weight-default 1.0 assigned.","ERROR",MB_OK);
        value = 1.0;
    }
    itemno = atoi(ItemNoEdit->Text.c_str());
    ItemWeight[itemno-1] = value;
    if (CorrectEdit->Text == "")
    {
        CorrectEdit->SetFocus();
        return;
    }
    if (itemno == UpDown1->Max)
    {
        OKBtn->SetFocus();
        return;
    }
    CorrectEdit->Text = "";
    WeightEdit->Text = "";
    itemno++;
    ItemNoEdit->Text = itemno;
    CorrectEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TItemScoreForm::FormShow(TObject *Sender)
{
    int noitems = atoi(NoItemsEdit->Text.c_str());

    for (int i = 0; i < noitems; i++)
    {
        NumberKey[i] = 1;
        LetterKey[i] = 'A';
        strcpy(WordKey[i],"");
    }
    if (TestAnalForm->CheckBox18->Checked == true)
    {
        for (int i = 0; i < noitems; i++) ItemWeight[i] = 1.0;
    }
    if (TestAnalForm->RadioButton1->Checked == true) // number
            CorrectEdit->Text = NumberKey[0];
    if (TestAnalForm->RadioButton2->Checked == true) // letter
            CorrectEdit->Text = LetterKey[0];
    if (TestAnalForm->RadioButton5->Checked == true) // word key
            CorrectEdit->Text = WordKey[0];
    if (TestAnalForm->CheckBox18->Checked == true) // weights entered
    {
            WeightEdit->Text = ItemWeight[0];
            WeightEdit->Visible = true;
            Label7->Visible = true;
            Label10->Visible = true;
    }
    else
    {
        Label7->Visible = false;
        Label10->Visible = false;
        WeightEdit->Visible = false;
    }

    CorrectEdit->SetFocus();
}
//---------------------------------------------------------------------------


