//---------------------------------------------------------------------------

#ifndef LinProUnitH
#define LinProUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TLinProForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TEdit *FileNameEdit;
        TLabel *Label2;
        TEdit *NoVarsEdit;
        TLabel *Label3;
        TStringGrid *ObjectiveGrid;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TStringGrid *MaxConstraintsGrid;
        TStringGrid *MaxGrid;
        TLabel *Label7;
        TLabel *Label8;
        TStringGrid *MinConstraintsGrid;
        TStringGrid *MinGrid;
        TLabel *Label9;
        TLabel *Label10;
        TStringGrid *EqualConstraintsGrid;
        TStringGrid *EqualGrid;
        TRadioGroup *MinMaxGrp;
        TLabel *Label11;
        TEdit *ResultsEdit;
        TButton *LoadBtn;
        TButton *SaveBtn;
        TButton *CancelBtn;
        TButton *ResetBtn;
        TButton *ReturnBtn;
        TButton *ComputeBtn;
        TEdit *NoMaxEdit;
        TEdit *NoMinEdit;
        TEdit *NoEqualEdit;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall NoVarsEditExit(TObject *Sender);
        void __fastcall NoMaxEditExit(TObject *Sender);
        void __fastcall NoMinEditExit(TObject *Sender);
        void __fastcall NoEqualEditExit(TObject *Sender);
        void __fastcall CancelBtnClick(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
        void __fastcall SaveBtnClick(TObject *Sender);
        void __fastcall NoVarsEditKeyPress(TObject *Sender, char &Key);
        void __fastcall NoMaxEditKeyPress(TObject *Sender, char &Key);
        void __fastcall NoMinEditKeyPress(TObject *Sender, char &Key);
        void __fastcall NoEqualEditKeyPress(TObject *Sender, char &Key);
        void __fastcall LoadBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        int NoVars, NoMax, NoMin, NoEql, MinMax, NoCoefs;
        double *Objective;
        double *MaxConstraints;
        double *MinConstraints;
        double *EqlConstraints;
        double **Coefficients;
        void LoadArrayData(TObject *Sender);
//        void simp3(float **a, int i1, int k1, int ip, int kp);
//        void simp2(float **a, int n, int l2[], int nl2, int *ip, int kp, float *q1);
//        void simp1(float **a, int mm, int ll[], int nll, int iabf, int *kp, float *bmax);
//        void simplx(float **a, int m, int n, int m1, int m2, int m3,
//      int icase, int *izrov, int *iposv);
        void simplx(double **a, int m, int n, int mp, int np, int m1,
                int m2, int m3, int& icase, int *izrov, int *iposv);
        void simp1(double **a, int mp, int np, int mm,
                int *ll, int nll, int iabf, int& kp, double& bmax);
        void simp2(double **a, int m, int n, int mp, int np,
                int *l2, int nl2, int& ip, int kp, double& q1);
        void simp3(double **a, int mp, int np, int i1, int k1, int ip, int kp);
public:		// User declarations
        __fastcall TLinProForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLinProForm *LinProForm;
//---------------------------------------------------------------------------
#endif
