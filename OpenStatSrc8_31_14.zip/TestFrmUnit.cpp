//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "TestFrmUnit.h"
#include "testadmunit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestFrm *TestFrm;
//---------------------------------------------------------------------------
__fastcall TTestFrm::TTestFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestFrm::ContBtnClick(TObject *Sender)
{
     TestFrm->Hide();
//    TestFrm->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TTestFrm::ShowItem(void)
{
   char astring[501];
   int Xpos, Ypos;
   int LineHeight;
   AnsiString response;
   Graphics::TBitmap *Bitmap1 = new Graphics::TBitmap();

   Xpos = 10;
   Ypos = 50;
   TRect rectangle;
   rectangle = Rect(Xpos,Ypos,Xpos+480,Ypos+360);
   Canvas->FrameRect(rectangle);
   LineHeight = Canvas->TextHeight("A");
   if (strlen(BMPFile) > 1) // bitmap file exists - display it first
   {
      try
      {
          Bitmap1->LoadFromFile(BMPFile);
          Canvas->StretchDraw(rectangle,Bitmap1);
          Ypos += 370;
      }
      catch (...)
      {
          MessageBeep(0);
      }
   }
   sprintf(astring,"DIRECTIONS:");
   Canvas->TextOut(Xpos,Ypos,astring);
   Ypos += LineHeight;
   if (itemtype == 0) // multiple choice
   {
       sprintf(astring,"    Select the one best answer for each question or statement below.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"Place the letter of your choice in the 'Your Answer Box' above.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 1) // true false
   {
       sprintf(astring,"    If the statement is true, enter T int the 'Your Answer Box'above.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"If the statement is false enter F in the box.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 2) // single word
   {
       sprintf(astring,"Enter the word when requested that best completes the sentence");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"or answers the question.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 3) //phrase
   {
       sprintf(astring,"On seperate paper enter the item no. and the phrase, when requested, that best completes the sentence");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"or answers the question.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 4) //sentence completion
   {
       sprintf(astring,"On seperate paper enter the item no. and the phrase that best completes the sentence");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"or answers the question.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 5) //essay
   {
       sprintf(astring,"Write your response to the following essay assignment on a ");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"seperate piece of paper.  Turn any papers in at the end of the test.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }
   if (itemtype == 6) // sketch
   {
       sprintf(astring,"Create a sketch on a seperate piece of paper that reflects the ");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += LineHeight;
       sprintf(astring,"following ideas.  Turn any papers in at the end of the test.");
       Canvas->TextOut(Xpos,Ypos,astring);
       Ypos += 2 * LineHeight;
   }

   sprintf(astring,"ITEM %d. ",itemno);
   strcat(astring,Stem[0]);
   Canvas->TextOut(Xpos,Ypos,astring);
   Ypos += LineHeight;
   for (int i = 1; i < stemlines; i++)
   {
       Canvas->TextOut(Xpos,Ypos,Stem[i]);
       Ypos += LineHeight;
   }

   // write the choices
   if (itemtype < 2) // for multiple choice or true-false items
   {
       for (int k = 0; k < nochoices; k++)
       {
           strcpy(astring,"");
           astring[0] = char('A'+ k);
           astring[1] = '.';
           astring[2] = '\0';
           for (int L = 0; L < foillines[k]; L++)
           {
               if (L == 0)
               {
                   strcat(astring,"   ");
                   strcat(astring,Foil[k][L]);
                   Canvas->TextOut(Xpos,Ypos,astring);
               }
               else Canvas->TextOut(Xpos,Ypos,Foil[k][L]);
           }
           Ypos += LineHeight;
       } // next choice
   }
   if (itemtype == 2)
   {
       AnsiString response = InputBox("ANSWER","Your answer:","?");
       AnsiString TheAnswer = answer;
       if (response.UpperCase() == TheAnswer.UpperCase())
       {
           TotalScore++;
           ScoreEdit->Text = TotalScore;
           AnswerEdit->Text = response.UpperCase();
           CorrEdit->Text = TheAnswer.UpperCase();
       }
   }
    AnswerEdit->SetFocus();
    Bitmap1->Dormant();           // Free up GDI resources
    Bitmap1->FreeImage();         // Free up Memory.
    Bitmap1->ReleaseHandle();       // This will actually lose the bitmap;
    delete Bitmap1;
    if (itemtype > 2) ContBtn->SetFocus();
    else AnswerEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TTestFrm::AnswerEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        char astring[5];
        AnsiString response;
        strcpy(astring,"");
        astring[0] = char('A'+ (correctno-1));
        astring[1] = '\0';
        response = astring;
        if (response == AnswerEdit->Text.UpperCase()) TotalScore++;
        CorrEdit->Text = response;
        ScoreEdit->Text = TotalScore;
        AnswerEdit->Text = "";

        ContBtn->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestFrm::FormShow(TObject *Sender)
{
    TotalScore = 0;
    stemlines = TestAdminFrm->stemlines;
    nochoices = TestAdminFrm->NoFoils;
    for (int i = 0; i < stemlines; i++) strcpy(Stem[i],TestAdminFrm->Stem[i]);
    for (int i = 0; i < 10; i++) foillines[i] = TestAdminFrm->foillines[i];
    for (int i = 0; i < nochoices; i++)
        for (int j = 0; j < foillines[i]; j++)
            strcpy(Foil[i][j],TestAdminFrm->Foil[i][j]);
    correctno = TestAdminFrm->corchoice;
    AnswerEdit->Text = "";
    TotalScore = TestAdminFrm->TotalScore;
    ScoreEdit->Text = TotalScore;
    CorrEdit->Text = "";
    strcpy(BMPFile,TestAdminFrm->BMPfile);
    ShowBtn->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TTestFrm::ShowBtnClick(TObject *Sender)
{
    ShowItem();
}
//---------------------------------------------------------------------------


void __fastcall TTestFrm::FormActivate(TObject *Sender)
{
    ShowBtnClick(this);    
}
//---------------------------------------------------------------------------

