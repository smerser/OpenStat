//---------------------------------------------------------------------------
#ifndef VarSelectH
#define VarSelectH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmVarSel : public TForm
{
__published:	// IDE-managed Components
	TListBox *LstBoxVars;
	TListBox *LstBoxSelected;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnHelp;
	TLabel *Label1;
	TCheckBox *ChkBox;
	TButton *BtnReset;
    TLabel *Label2;
    TLabel *Label3;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TButton *AllBtn;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnResetClick(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall BtnHelpClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TFrmVarSel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFrmVarSel *FrmVarSel;
//---------------------------------------------------------------------------
#endif
