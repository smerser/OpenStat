//---------------------------------------------------------------------------

#ifndef PredictUnitH
#define PredictUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TPredictForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TEdit *NoPredEdit;
   TLabel *Label2;
   TEdit *NoLay1Edit;
   TLabel *Label3;
   TEdit *NoLay2Edit;
   TLabel *Label4;
   TEdit *NoDepEdit;
   TButton *CancelBtn;
   TButton *OKBtn;
   TLabel *Label5;
   TEdit *TrainNameEdit;
   TLabel *Label6;
   TLabel *Label7;
   TEdit *AnalysisNameEdit;
   TEdit *OutFileEdit;
   TLabel *Label8;
   TEdit *WghtNameEdit;
private:	// User declarations
public:		// User declarations
   __fastcall TPredictForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPredictForm *PredictForm;
//---------------------------------------------------------------------------
#endif
