//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ItemStem.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStemEditFrm *StemEditFrm;
//---------------------------------------------------------------------------
__fastcall TStemEditFrm::TStemEditFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TStemEditFrm::FormShow(TObject *Sender)
{
    StemMemo->SetFocus();
}
//---------------------------------------------------------------------------

