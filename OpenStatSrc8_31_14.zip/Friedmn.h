//---------------------------------------------------------------------------
#ifndef FriedmnH
#define FriedmnH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFriedmanFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
     TListBox *VarList;
    TLabel *Label2;
     TEdit *GrpVar;
    TLabel *Label3;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
     TListBox *TreatVars;
     TButton *ComputeBtn;
     TMemo *Memo1;
     TBitBtn *GrpIn;
     TBitBtn *GrpOut;
     TBitBtn *TrtIn;
     TBitBtn *TrtOut;
        TGroupBox *OptionsBox;
        TCheckBox *SaveRanksChk;
        TCheckBox *PlotAvgRanksChk;
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
     void __fastcall GrpInClick(TObject *Sender);
     void __fastcall GrpOutClick(TObject *Sender);
     void __fastcall TrtInClick(TObject *Sender);
     void __fastcall TrtOutClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFriedmanFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFriedmanFrm *FriedmanFrm;
//---------------------------------------------------------------------------
#endif
