//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <math.h>
#include <stdio.h>
#include "functions.h"
#include "DateFunc.h"
#include "DictionaryUnit.h"
#include "TransfAllUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTransfAllForm *TransfAllForm;
extern int NoVariables;
extern int NoCases;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TTransfAllForm::TTransfAllForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::CancelBtnClick(TObject *Sender)
{
    TransfAllForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::FormShow(TObject *Sender)
{
     AnsiString cellstring;

     ListBox1->Clear();
     Var1Edit->Text = "";
     Var2Edit->Text = "";
     ConstantEdit->Text = "";
     SelectEdit->Text = "";
     Var1Out->Enabled = false;
     Var2Out->Enabled = false;
     TIndex = 0;
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::Var1InClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox1->ItemIndex;
     if (index >= 0)
     {
         cellstring = ListBox1->Items->Strings[index];
         Var1Edit->Text = cellstring;
         ListBox1->Items->Delete(index);
         Var1Out->Enabled = true;
     }        
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::Var1OutClick(TObject *Sender)
{
    ListBox1->Items->Add(Var1Edit->Text);
    Var1Edit->Text = "";
    Var1Out->Enabled = false;        
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::Var2InClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox1->ItemIndex;
     if (index >= 0)
     {
         cellstring = ListBox1->Items->Strings[index];
         Var2Edit->Text = cellstring;
         ListBox1->Items->Delete(index);
         Var2Out->Enabled = true;
     }        
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::Var2OutClick(TObject *Sender)
{
    ListBox1->Items->Add(Var2Edit->Text);
    Var2Edit->Text = "";
    Var2Out->Enabled = false;        
}
//---------------------------------------------------------------------------
void __fastcall TTransfAllForm::TrnsfrmLstClick(TObject *Sender)
{
     TIndex = TrnsfrmLst->ItemIndex;
     SelectEdit->Text = TrnsfrmLst->Items->Strings[TIndex];
}
//---------------------------------------------------------------------------

double * Rank(int v1col)
{
    double *Values;
    double *pcntiles;
    int *freq;
    double *CatValues;
    double Temp;
    int nocats = 0;

    try  {
        Values = new double[NoCases];
        freq = new int[NoCases];
        pcntiles = new double[NoCases];
        CatValues = new double[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory!","ERROR!",MB_OK);
        return (NULL);
    }

    // get values to be sorted into values vector
    for (int i = 0; i < NoCases; i++)
        Values[i] = StrToFloat(MainForm->Grid->Cells[v1col][i+1]);

    // sort the values
    for (int i = 0; i < NoCases - 1; i++) //order from high to low
    {
        for (int j = i + 1; j < NoCases; j++)
        {
            if (Values[i] < Values[j]) // swap
            {
                Temp = Values[i];
                Values[i] = Values[j];
                Values[j] = Temp;
            }
        }
    }

    // now get no. of unique values and frequency of each
    for (int i = 0; i < NoCases; i++) freq[i] = 0;
    Temp = Values[0];
    CatValues[0] = Temp;
    for (int i = 0; i < NoCases; i++)
    {
        if (Temp == Values[i]) freq[nocats]++;
        else // new value
        {
            nocats++;
            freq[nocats]++;
            Temp = Values[i];
            CatValues[nocats] = Temp;
        }
    }

    // get ranks
    double cumfreq = 0.0;
    for (int i = 0; i <= nocats; i++)
    {
        double upper = NoCases-cumfreq;
        cumfreq += freq[i];
        double lower = NoCases-cumfreq+1;
        pcntiles[i] = (upper-lower)/ 2.0 + lower;
    }

    // convert original values to their corresponding ranks
    for (int i = 0; i < NoCases; i++)
    {
        Temp = StrToFloat(MainForm->Grid->Cells[v1col][i+1]);
        for (int j = 0; j <= nocats; j++)
        {
            if (Temp == CatValues[j]) Values[i] = pcntiles[j];
        }
    }

    // clean up the heap
    delete[] CatValues;
    delete[] pcntiles;
    delete[] freq;

    return Values;
}
//--------------------------------------------------------------------

double * PRank(int v1col)
{
    double *Values;
    double *pcntiles;
    int *freq;
    int *cumf;
    double *cumfm;
    double *CatValues;
    double Temp;
    int nocats = 0;

    try  {
        Values = new double[NoCases];
        freq = new int[NoCases];
        pcntiles = new double[NoCases];
        cumf = new int[NoCases];
        cumfm = new double[NoCases];
        CatValues = new double[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory!","ERROR!",MB_OK);
        return (NULL);
    }

    // get values to be sorted into values vector
    for (int i = 0; i < NoCases; i++)
        Values[i] = StrToFloat(MainForm->Grid->Cells[v1col][i+1]);

    // sort the values
    for (int i = 0; i < NoCases - 1; i++) //order from high to low
    {
        for (int j = i + 1; j < NoCases; j++)
        {
            if (Values[i] < Values[j]) // swap
            {
                Temp = Values[i];
                Values[i] = Values[j];
                Values[j] = Temp;
            }
        }
    }

    // now get no. of unique values and frequency of each
    for (int i = 0; i < NoCases; i++) freq[i] = 0;
    Temp = Values[0];
    CatValues[0] = Temp;
    for (int i = 0; i < NoCases; i++)
    {
        if (Temp == Values[i]) freq[nocats]++;
        else // new value
        {
            nocats++;
            freq[nocats]++;
            Temp = Values[i];
            CatValues[nocats] = Temp;
        }
    }

    // now get cumulative frequencies
    cumf[nocats] = freq[nocats];
    for (int i = nocats-1; i >= 0; i--) cumf[i] = freq[i] + cumf[i+1];

    // get cumulative frequences to midpoints and percentile ranks
    cumfm[nocats] = double(freq[nocats]);
    pcntiles[nocats] = (double(cumf[nocats])/ 2.0) / double(NoCases);
    for (int i = nocats-1; i >= 0; i--)
    {
        cumfm[i] = double(freq[i])/2.0 + cumf[i+1];
        pcntiles[i] = (cumfm[i] / double(NoCases));
    }

    // convert original values to their corresponding percentile ranks
    for (int i = 0; i < NoCases; i++)
    {
        Temp = atof(MainForm->Grid->Cells[v1col][i+1].c_str());
        for (int j = 0; j <= nocats; j++)
        {
            if (Temp == CatValues[j]) Values[i] = pcntiles[j];
        }
    }

    // clean up the heap
    delete[] CatValues;
    delete[] cumfm;
    delete[] cumf;
    delete[] pcntiles;
    delete[] freq;

    return Values;
}
//--------------------------------------------------------------------
void __fastcall TTransfAllForm::OKBtnClick(TObject *Sender)
{
    int v1col, v2col, gridcol, nvars;
    double * index = NULL;
    AnsiString cellstring, newcell;
    bool TwoArgs = false;
    double constant = 0.0;
    double X, Y, Z;
    double mean, stddev, N;
    double *pcntile = NULL;
    char valstr[10];
    AnsiString NewVar;

    if (SelectEdit->Text == "")
    {
        Application->MessageBox("First click on the desired transformation.",
                                "ERROR!",MB_OK);
        return;
    }
    if (Var1Edit->Text == "")
    {
        Application->MessageBox("First click on a variable to transform.",
                                "ERROR!",MB_OK);
        return;
    }

    // Check to see if the transformation requires two variables
    if ((TIndex > 4) && (TIndex < 10))
    {
        TwoArgs = true;
        if (Var2Edit->Text == "")
        {
            Application->MessageBox("Select a variable for the V2 arguement.",
                                    "ERROR!",MB_OK);
            return;
        }
    }

    // loop through all variables for the v1col.  Skip if = v2.
    nvars = NoVariables;
    for (int ii = 1; ii <= nvars; ii++)
    {
        Var1Edit->Text = MainForm->Grid->Cells[ii][0];
        if (Var1Edit->Text == Var2Edit->Text) continue;
        NewVar = "T" + Var1Edit->Text;

        // Find column of variable one and two (if selected)
        cellstring = Var1Edit->Text;
        for (int i = 1; i <= NoVariables; i++)
        {
            if (MainForm->Grid->Cells[i][0] == cellstring)
            {
               v1col = i;
               continue;
            }
        }
        if (TwoArgs)
        {
           cellstring = Var2Edit->Text;
           for (int i = 1; i < MainForm->Grid->ColCount; i++)
           {
               if (MainForm->Grid->Cells[i][0] == cellstring)
               {
                  v2col = i;
                  continue;
               }
           }
        }

        // Check for a constant
        if (ConstantEdit->Text != "")
           constant = StrToFloat(ConstantEdit->Text);

        // Do the appropriate transformation
        if (TIndex == 21) index = Rank(v1col); // get ranks

        if ((TIndex == 22)|| (TIndex == 24)) pcntile = PRank(v1col); // get percentile ranks

        if ((TIndex == 20)||(TIndex == 23)) // z transformation - need mean and stddev
        {
           mean = 0.0;
           stddev = 0.0;
           for (int i = 1; i <= NoCases; i++)
           {
               X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
               mean += X;
               stddev += (X * X);
           }
           N = NoCases;
           stddev = stddev - (mean * mean) / N;
           stddev /= (N - 1.0);
           stddev = sqrt(stddev);
           mean /= N;
        }
        MainForm->Grid->ColCount++;
        gridcol = NoVariables + 1; // new variable column
        NoVariables++;
        MainForm->NoVarsEdit->Text = NoVariables;

        for (int i = 1; i <= NoCases; i++) // cases
        {
            switch (TIndex)
            {
                   case 0: // V1 + C
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Z = X + constant;
                    break;
                   }
                   case 1: // V1 - C
                   {
                     X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                     Z = X - constant;
                     break;
                   }
                   case 2: // V1 * C
                   {
                     X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                     Z = X * constant;
                     break;
                   }
                   case 3: // V1 / C
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Z = X / constant;
                    break;
                   }
                   case 4: // v1 ** C
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Z = pow(X,constant);
                    break;
                   }
                   case 5: // V1 + V2
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Y = StrToFloat(MainForm->Grid->Cells[v2col][i]);
                    Z = X + Y;
                    break;
                   }
                   case 6: // V1 - V2
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Y = StrToFloat(MainForm->Grid->Cells[v2col][i]);
                    Z = X - Y;
                    break;
                   }
                   case 7: // V1 * V2
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Y = StrToFloat(MainForm->Grid->Cells[v2col][i]);
                    Z = X * Y;
                    break;
                   }
                   case 8: // V1 / V2
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Y = StrToFloat(MainForm->Grid->Cells[v2col][i]);
                    Z = X / Y;
                    break;
                   }
                   case 9: // V1 ** V2
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Y = StrToFloat(MainForm->Grid->Cells[v2col][i]);
                    Z = pow(X,Y);
                    break;
                   }
                   case 10: // ln(V1)
                   {
                    X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                    Z = log(X);
                    break;
                   }
                   case 11: // log(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = log10(X);
                        break;
                   }
                   case 12: // exp(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = exp(X);
                        break;
                   }
                   case 13: // exp(V1) base 10
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = pow(10.0,X);
                        break;
                   }
                   case 14: // sin(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = sin(X);
                        break;
                   }
                   case 15: // cos(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = cos(X);
                        break;
                   }
                   case 16: // tan(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = tan(X);
                        break;
                   }
                   case 17: // arcsin(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = asin(X);
                        break;
                   }
                   case 18: // arccos(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = acos(X);
                        break;
                   }
                   case 19: // arctan(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = atan(X);
                        break;
                   }
                   case 20: // z(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = (X - mean) / stddev;
                        break;
                   }
                   case 21: // Rank(V1)
                   {
                        if (index != NULL) Z = index[i-1];
                        break;
                   }
                   case 22: // %ilerank(V1)
                   {
                        if (pcntile != NULL) Z = pcntile[i-1] * 100.0;
                        break;
                   }
                   case 23: // probz(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Y = (X - mean) / stddev;
                        Z = normalprob(Y);
                        break;
                   }
                   case 24: // inversez(V1) - convert to %ile ranks first
                   {
                        Y = pcntile[i-1]; // y is %ile rank of X
                        Z = inversez(Y);
                        break;
                   }
                   case 25: // absolute value of V1: (fabs(V1)
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = fabs(X);
                        break;
                   }
                   case 26: // New = C
                   {
                        Z = constant;
                        break;
                   }
                   case 27: // New = C - V1
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = constant - X;
                        break;
                   }
                   case 28: // New = C / V1
                   {
                        X = StrToFloat(MainForm->Grid->Cells[v1col][i]);
                        Z = constant / X;
                        break;
                   }
                   case 29: // Date to Month
                   {
                        newcell = FormatDateTime("mm",MainForm->Grid->Cells[v1col][i]);
                        Z = atoi(newcell.c_str());
                        break;
                   }
                   case 30: // Date to Year
                   {
                        newcell = FormatDateTime("yyyy",MainForm->Grid->Cells[v1col][i]);
                        Z = atoi(newcell.c_str());
                        break;
                   }
                   case 31: // Date to Day
                   {
                        newcell = FormatDateTime("dd",MainForm->Grid->Cells[v1col][i]);
                        Z = atoi(newcell.c_str());
                        break;
                   }
                   case 32: // Date to number in year
                   {
                        newcell = FormatDateTime("mm",MainForm->Grid->Cells[v1col][i]);
                        int month = floor(StrToFloat(newcell));
                        newcell = FormatDateTime("yy",MainForm->Grid->Cells[v1col][i]);
                        int year = floor(StrToFloat(newcell));
                        newcell = FormatDateTime("dd",MainForm->Grid->Cells[v1col][i]);
                        int day = floor(StrToFloat(newcell));
                        long int dateno = ymd_to_date(year,month,day);
                        Z = dateno;
                        break;
                   }
                   case 33 : // Day of Week
                   {
                        newcell = FormatDateTime("mm",MainForm->Grid->Cells[v1col][i]);
                        int month = floor(StrToFloat(newcell));
                        newcell = FormatDateTime("yy",MainForm->Grid->Cells[v1col][i]);
                        int year = floor(StrToFloat(newcell));
                        newcell = FormatDateTime("dd",MainForm->Grid->Cells[v1col][i]);
                        int day = floor(StrToFloat(newcell));
                        long int dateno = ymd_to_date(year,month,day);
                        if (dateno == 0) Z = - 1;
                        else Z = (dateno + 4) % 7;
                        break;
                   }
            } // end switch
//              sprintf(valstr,"%8.4f",Z);
            MainForm->Grid->Cells[gridcol][i] = Z;
        } // next i
        MainForm->Grid->Cells[gridcol][0] = NewVar;
        // Add definition data
        DictionaryForm->DGrid->Cells[1][gridcol] = NewVar;
        DictionaryForm->DGrid->Cells[2][gridcol] = NewVar;
        DictionaryForm->DGrid->Cells[0][gridcol] = IntToStr(gridcol);
        DictionaryForm->DGrid->Cells[3][gridcol] = ops.format;
        DictionaryForm->DGrid->Cells[4][gridcol] = ops.gridfldwidth;
        DictionaryForm->DGrid->Cells[5][gridcol] = ops.gridnodecimals;
        DictionaryForm->DGrid->Cells[6][gridcol] = ops.missval;
        if (gridcol+1 > DictionaryForm->DGrid->RowCount)
           DictionaryForm->DGrid->RowCount = gridcol + 1;
        NoVariables = DictionaryForm->DGrid->RowCount-1;
        if (NoVariables + 1 > MainForm->Grid->ColCount)
           MainForm->Grid->ColCount = NoVariables + 1;
        MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
        MainForm->Grid->Col = gridcol;
    } // next ii

    // cleanup
    if (TIndex == 21) delete[] index;
    if ((TIndex == 22)||(TIndex == 24)) delete[] pcntile;
    TransfAllForm->Hide();
}
//---------------------------------------------------------------------------
