//---------------------------------------------------------------------------
#ifndef FrmSelRangeH
#define FrmSelRangeH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
class TSelRange : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TEdit *TxtFirstCase;
	TEdit *TxtLastCase;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnHelp;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
    void __fastcall BtnHelpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TSelRange(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TSelRange *SelRange;
//---------------------------------------------------------------------------
#endif
