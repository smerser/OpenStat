//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "OptionsUnit.h"
#include "MainUnit.h"
#include "DirectoryUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDirectoryForm *DirectoryForm;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TDirectoryForm::TDirectoryForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDirectoryForm::DriveComboDblClick(TObject *Sender)
{
        DirectoryList->Drive = DriveCombo->Drive;
        FileListBox1->Drive = DriveCombo->Drive;
}
//---------------------------------------------------------------------------
void __fastcall TDirectoryForm::DirectoryListDblClick(TObject *Sender)
{
        FileListBox1->Directory = DirectoryList->Directory;
        PathEdit->Text = "";
        PathEdit->Text = DirectoryList->Directory;
        strcpy(ops.DataPath,PathEdit->Text.c_str());
        OptionsForm->DataPathEdit->Text = PathEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TDirectoryForm::FormShow(TObject *Sender)
{
        PathEdit->Text = DirectoryList->Directory;
}
//---------------------------------------------------------------------------

void __fastcall TDirectoryForm::DriveComboChange(TObject *Sender)
{
        DriveComboDblClick(this);        
}
//---------------------------------------------------------------------------

void __fastcall TDirectoryForm::ReturnBtnClick(TObject *Sender)
{
        SetCurrentDir(DirectoryForm->PathEdit->Text);
        OptionsForm->DriveCombo->Drive = DriveCombo->Drive;
}
//---------------------------------------------------------------------------

