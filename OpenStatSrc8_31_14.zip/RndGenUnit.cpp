//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include <math.h>
#include <Math.hpp>
#include <stdio.h>
#include "cdflib.h"
#include "RndGenUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRndGenFrm *RndGenFrm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern bool openfile;
//---------------------------------------------------------------------------
__fastcall TRndGenFrm::TRndGenFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRndGenFrm::CancelBtnClick(TObject *Sender)
{
    RndGenFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TRndGenFrm::OKBtnClick(TObject *Sender)
{
    double X, SumX1, SumX2;
    int XI;
    char cellstring[11];

    NoCases = atoi(NoObsEdit->Text.c_str());
    if (NoCases == 0) return;
    if (MainForm->Grid->RowCount < NoCases)
    {
        MainForm->Grid->RowCount = NoCases;
        MainForm->NoCasesEdit->Text = NoCases;
    }
//    NoVariables++;
    if (MainForm->Grid->Cells[1][1] != "") MainForm->Grid->ColCount++;
    else
    {
        for (int i = 0; i < NoCases; i++)
        {
            sprintf(cellstring,"CASE %d",i+1);
            MainForm->Grid->Cells[0][i+1] = cellstring;
        }
    }
    MainForm->Grid->RowCount = NoCases+1;
    randomize();
    int col = MainForm->Grid->ColCount-1;
    MainForm->NoCasesEdit->Text = NoCases;
    MainForm->NoVarsEdit->Text = NoVariables;
    bool checklabel = LabelOK(LabelEdit->Text);
    if (( LabelEdit->Text == "") || (checklabel == false))
    {
        ShowMessage("Select a different label for the variable");
        return;
    }
    MainForm->Grid->Cells[col][0] = LabelEdit->Text;
    NewVar(col,true);
    for (int i = 0; i < NoCases; i++)
    {
        switch (btn)
        {
            case 1: // flat integer between 0 and maxint
                XI = random(maxint+1);
                if (XI < minint) XI = minint;
                MainForm->Grid->Cells[col][i+1] = XI;
                break;
            case 2: // flat real between 0 and maxreal
                X = random(10001);
                X /= 10000.0;
                X *= maxreal;
                if (X < minreal) X = minreal;
                sprintf(cellstring,"%8.3f",X);
                MainForm->Grid->Cells[col][i+1] = cellstring;
                break;
            case 3: // normally distributed z with mean=meanz, sd = sdz
                X = RandG(meanz,sdz);
                sprintf(cellstring,"%8.3f",X);
                MainForm->Grid->Cells[col][i+1] = cellstring;
                break;
            case 4: // chi-square with deg freedom = df1
                SumX1 = 0.0;
                for (int j = 0; j < df1; j++)
                {
                    X = RandG(0.0,1.0);
                    SumX1 += (X * X);
                }
                X = SumX1;
                sprintf(cellstring,"%8.3f",X);
                MainForm->Grid->Cells[col][i+1] = cellstring;
                break;
            case 5: // F statistic with degrees of freedom df1 and df2
                SumX1 = 0.0;
                SumX2 = 0.0;
                for (int j = 0; j < df1; j++)
                {
                    X = RandG(0.0,1.0);
                    SumX1 += (X * X);
                }
                for (int j = 0; j < df2; j++)
                {
                    X = RandG(0.0,1.0);
                    SumX2 += (X * X);
                }
                X = SumX1 / SumX2;
                sprintf(cellstring,"%8.3f",X);
                MainForm->Grid->Cells[col][i+1] = cellstring;
                break;
            case 6: // Poisson
                int which = 2, status;
                double p, q, s, xlam, bound;
                xlam = meanz;
                p = RandG(0.0,1.0);
                q = 1.0 - p;
                cdfpoi(&which,&p,&q,&s,&xlam,&status,&bound);
                sprintf(cellstring,"%8.3f",s);
                MainForm->Grid->Cells[col][i+1] = cellstring;
                break;
        } // end switch
    } // next case i
    MainForm->NoCasesEdit->Text = IntToStr(NoCases);
    for (int i = 1; i < MainForm->Grid->RowCount; i++)
    {
        sprintf(cellstring,"CASE %d",i);
        MainForm->Grid->Cells[0][i] = cellstring;
    }
    if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "RndomData.TEX";
    openfile = true;
    RndGenFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TRndGenFrm::RadioGroup1Click(TObject *Sender)
{
    AnsiString response;
    btn = RadioGroup1->ItemIndex + 1;
    switch (btn)
    {
        case 1:
            response = InputBox("MIN. INTEGER","MIN = ","0");
            minint = atoi(response.c_str());
            response = InputBox("MAX. INTEGER","MAX = ","100");
            maxint = atoi(response.c_str());
            break;
        case 2:
            response = InputBox("MIN. REAL","MIN = ","0.0");
            minreal = atof(response.c_str());
            response = InputBox("MAX. REAL","MAX = ","100.0");
            maxreal = atof(response.c_str());
            break;
        case 3:
            response = InputBox("MEAN","MEAN = ","0.0");
            meanz = atof(response.c_str());
            response = InputBox("STDDEV","Standard Deviation = ","1.0");
            sdz = atof(response.c_str());
            break;
        case 4:
            response = InputBox("DF","DEG. FREEDOM = ","5");
            df1 = atoi(response.c_str());
            break;
        case 5:
            response = InputBox("NUM.DF","NUMERATOR DEG. FREEDOM = ","5");
            df1 = atoi(response.c_str());
            response = InputBox("DEN.DF","DENOMINATOR DEG. FREEDOM = ","10");
            df2 = atoi(response.c_str());
            break;
        case 6:
            response = InputBox("MEAN","MEAN = ","10.0");
            meanz = atof(response.c_str());
            break;
    }
}
//---------------------------------------------------------------------------
void __fastcall TRndGenFrm::FormShow(TObject *Sender)
{
        RadioGroup1->ItemIndex = -1;        
}
//---------------------------------------------------------------------------

