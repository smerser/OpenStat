//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <stdio.h>
#include "MemMgrUnit.h"
//#include "PlotUnit.h"
#include "AvgLinkUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAvgLinkForm *AvgLinkForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TAvgLinkForm::TAvgLinkForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAvgLinkForm::FormShow(TObject *Sender)
{
     RadioGroup1->ItemIndex = 0;    
}
//---------------------------------------------------------------------------
void __fastcall TAvgLinkForm::OKBtnClick(TObject *Sender)
{
     //-----------------------------------------------------------------------
     //  Reference:  Anderberg, M. R. (1973).  Cluster analysis for
     //              applications.  New York:  Academic press.
     //
     //  Almost any text on cluster analysis should have a good
     //  description of the average-linkage hierarchical clustering
     //  algorithm.   The algorithm begins with an initial similarity
     //  or dissimilarity matrix between pairs of objects.  The
     //  algorithm proceeds in an iterative way.  At each iteration
     //  the two most similar (we assume similarities for explanation)
     //  objects are combined into one group.  At each successive
     //  iteration, the two most similar objects or groups of objects are
     //  merged.  Similarity between groups is defined as the average
     //  similarity between objects in one group with objects in the other.
     //
     //     INPUT:   A correlation matrix (or some other similarity or
     //              dissimilarity matrix) in a file named MATRIX.DAT
     //              This must contain all the elements of a full
     //              (n x n), symmetrical matrix.  Any format is
     //              allowable, as long as numbers are separated by
     //              blanks.
     //
     //     OUTPUT:  Output consists of a cluster history and a tree
     //              diagram (dendogram).  The cluster history
     //              indicates, for each iteration, the objects
     //              or clusters merged, and the average pairwise
     //              similarity or dissimilarity in the resulting
     //              cluster.
     //
     //  Author:    John Uebersax
     //-----------------------------------------------------------------------
     if (NoVariables <= 0)
     {
        ShowMessage("ERROR! You must first load a matrix into the grid.");
        return;
     }
    double **X; // similarity or dissimilarity matrix
    int **KLUS;
    int *LST;
    double RX, SAV, SAV2;
    int *NIN, *NVAR, I, J, NI, NJ, In, ICOL, K, L, M, MN, N, CRIT, ITR;
    int INEND, JCOL, JPRE, JEND, NHOLD, MSH, KSH, NLINES, INDX;
    AnsiString *ROWS, DIS, Title;
    char outline[201];
    int nvalues = NoVariables;

    GetDblMatMem(X,nvalues+1,nvalues+1);
    GetIntMatMem(KLUS,nvalues+1,3);
    GetIntVecMem(LST,nvalues+1);
    GetIntVecMem(NIN,nvalues+1);
    GetIntVecMem(NVAR,nvalues+1);

    Title = "Average Linkage Cluster Analysis.  Adopted from ClusBas by John S. Uebersax";

    // This section does the cluster analysis, taking data from the Main Form.
    // Parameters controlling the analysis are obtained from the dialog form.
    DIS = "DIS";
    FrmOutPut->RichOutPut->Lines->Add(Title);
    FrmOutPut->RichOutPut->Lines->Add("");
    M = nvalues;
    CRIT = RadioGroup1->ItemIndex; // 0 = Similarity, 1 = dissimilarity

    // get matrix of data from mainform
    for (int i = 1; i <= NoVariables; i++)
    {
        for (int j = 1; j <= NoVariables; j++)
            X[i][j] = atof(MainForm->Grid->Cells[i][j].c_str());
    }

    int LIMIT = M - 1;
    for (int i = 1; i <= M; i++)
    {
        NVAR[i] = i;
        NIN[i] = 1;
    }

    // cluster analysis
    ITR = 0;

label300:
    ITR = ITR + 1;
    //
    // determine groups to be merged this iteration
    //
    if (CRIT == 1) // (BSCAN) dissimilarity matrix
    {
         // This section looks for the minimum dissimilarity.  It finds
         // element (K, L), where K and L are the most dissimilar objects
         // or groups.
         //
         N = 1;
         double RRRMIN = 1000000.0;
         MN = M - 1;
         for (int i = 1; i <= MN; i++)
         {
             N = N + 1;
             for (int j = N; j <= M; j++)
             {
                 if (RRRMIN < 0.0) continue;
                 K = i;
                 L = j;
                 RRRMIN = X[i][j];
             }
         }
        RX = RRRMIN;
    }
    else // SCAN procedure
    {
        // This section looks for the maximum similarity.  It finds
        // element (K, L), where K and L are the most similar objects or
        // groups.
        //
        N = 1;
        RX = -10000.0;
        for (int i = 1; i <= M; i++)
        {
            N = N + 1;
            for (int j = N; j <= M; j++)
            {
                if (RX - X[i][j] > 0.0) continue;
                K = i;
                L = j;
                RX = X[i][j];
            }
        }
    }

    // ARRANGE
    //
    // This section updates the similarity or dissimilarity matrix.
    // If two objects/groups K and L are merged, it calculates the
    // similarity or dissimilarity of the new group with all other objects
    // or groups.  It does this by averaging the elements in row K of
    // X() with those in row L, and similarly for columns K and L.
    // The new elements are put in row K and column L (K < L).  Row K
    // and column L are deleted.  Columns and rows greater than L are
    // shifted up one column or row to fill in the gap.  The resulting
    // matrix X() thus has one less column and row then at the beginning
    // of the subroutine.

    MN = M - 1;
    SAV = X[K][L];
    SAV2 = X[K][K];
    // Calculate similarity or dissimilarity of group formed by merging I
    // and J to all other groups by averaging the similarities or
    // dissimilarities of I and J with other groups
    for (int I = 1; I <= M; I++)
    {
        X[I][K] = (X[I][K] * NIN[K] + X[I][L] * NIN[L]) / (NIN[K] + NIN[L]);
        X[K][I] = X[I][K];
    }
    X[K][K] = SAV2 * NIN[K] * (NIN[K] - 1) + X[L][L] * NIN[L] * (NIN[L] - 1);
    X[K][K] = X[K][K] + SAV * 2 * NIN[K] * NIN[L];
    X[K][K] = X[K][K] / ((NIN[K] + NIN[L]) * (NIN[K] + NIN[L] - 1));
    if (L == M) goto label60;
    for (int I = 1; I <= M; I++)
    {
        // Shift columns after J up one place
        for (int J = L; J <= MN; J++) X[I][J] = X[I][J+1];
    }
    for (int I = L; I <= MN; I++)
    {
        // Shift rows after J up one place
        for (int J = 1; J <= M; J++) X[I][J] = X[I+1][J];
    }
    NIN[K] = NIN[K] + NIN[L];
    for (int I = L; I <= MN; I++) NIN[I] = NIN[I+1];
    goto label70;
label60:
    // Update number of objects in each cluster
    NIN[K] = NIN[K] + NIN[L];
label70: // end of ARRANGE procedure

    // continuation of CLUSV1 procedure
    // OUTPUT
    if (CRIT == 0)
    {
        sprintf(outline,"Group %3d is joined by group %3d. N is %3d ITER = %3d SIM = %10.3f",
            NVAR[K], NVAR[L],NIN[K],ITR,RX);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    else
    {
        sprintf(outline,"Group %3d is joined by group %3d. N is %3d ITER = %3d DIS = %10.3f",
            NVAR[K], NVAR[L],NIN[K],ITR,RX);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    KLUS[ITR][1] = NVAR[K]; // save in KLUS rather than write out to file as in
    KLUS[ITR][2] = NVAR[L]; // original program
    if (L != M)
    {
        MN = M - 1;
        for (int i = L; i <= MN; i++) NVAR[i] = NVAR[i+1];
    }
    M = M - 1;
    if (ITR < LIMIT) goto label300;
    FrmOutPut->RichOutPut->Lines->Add("");
    // End of CLUSV1 procedure

    // do pre-tree processing
    PreTree(nvalues, CRIT, LST, KLUS);

    // do TREE procedure
    TreePlot(KLUS,LST,nvalues);
    FrmOutPut->ShowModal();

    // cleanup
    delete[] NVAR;
    delete[] NIN;
    delete[] LST;
    ClearIntMatMem(KLUS,nvalues+1);
    ClearDblMatMem(X,nvalues+1);

}
//---------------------------------------------------------------------------

void TAvgLinkForm::TreePlot(int **Clusters, int *Lst, int NoPoints)
{
     char outline[501];
     char valstr[21];
     AnsiString plotline;
     char star = '*';
     char blank = ' ';
     int *ColPos;
     int col1, col2, colpos1, colpos2;
     int noparts, startcol, endcol;
     AnsiString *Results;
     int linecount = 0;
     ColPos = new int[NoPoints+1];
     Results = new AnsiString[NoPoints*2+3];

     FrmOutPut->RichOutPut->Lines->Add("");

     // store initial column positions of vertical linkages
     for (int i = 1; i <= NoPoints; i++) ColPos[Lst[i]] = 4 + (i * 5);

     // create column heading indented 10 spaces
     strcpy(outline,"UNIT ");
     for (int i = 1; i <= NoPoints; i++)
     {
         sprintf(valstr,"%5d",Lst[i]);
         strcat(outline,valstr);
     }
     Results[linecount] = outline;
     linecount++;

     // create beginning of vertical linkages
     plotline = "STEP ";
     for (int i = 1; i <= NoPoints; i++) plotline += "    *";
     Results[linecount] = plotline;
     linecount++;

     // start dendoplot
     for (int i = 1; i < NoPoints; i++)
     {
         strcpy(outline,"");
         sprintf(valstr,"%3d  ",i); // put node no. first
         strcat(outline,valstr);
         // clear remainder of outline
         for (int j = 5; j <= (5 + NoPoints * 5); j++) outline[j] = blank;
         outline[6 + NoPoints * 5] = '\0';
         col1 = Clusters[i][1];
         col2 = Clusters[i][2];
         for (int j = 1; j <= NoPoints; j++) // check for grouping
         {
             if (col2 == j) // match - place points between these columns
             {
                 // find column positions for each variable
                 colpos1 = ColPos[col1];
                 colpos2 = ColPos[col2];
                 for (int k = colpos1; k <= colpos2; k++) outline[k] = star;
                 // change column positions 1/2 way between the matched ones
                 int newcol = ColPos[col1] + ((colpos2 - colpos1) / 2);
                 for (int k = 1; k <= NoPoints; k++)
                 if ((ColPos[k] == colpos1) || (ColPos[k] == colpos2))
                     ColPos[k] = newcol;
                 for (int k = 1; k <= NoPoints; k++)
                 {
                     int L = ColPos[k];
                     if ((L != colpos1) && (L != colpos2)) outline[L] = star;
                 }
             }
             else // place a star in ith and jth column position
             {
                    for (int k = 1; k <= NoPoints; k++)
                    {
                        int L = ColPos[k];
                        outline[L] = star;
                    }
             }
         }
         Results[linecount] = outline;
         linecount++;

         // add a line of connectors to next grouping
         strcpy(outline,"     ");
         for (int j = 5; j <= (5 + NoPoints * 5); j++) outline[j] = blank;
         for (int j = 1; j <= NoPoints; j++)
         {
             colpos1 = ColPos[j];
             outline[colpos1] = star;
         }
         Results[linecount] = outline;
         linecount++;
     } // next node

     // output the Results in parts
     // determine number of pages needed for whole plot
     noparts = 0;
     int howlong = strlen(Results[1].c_str());
     noparts = howlong / 70;
     if (noparts <= 0) noparts = 1;

     if (noparts == 1) // simply print the list
     {
         for (int i = 0; i < linecount; i++)
         {
             FrmOutPut->RichOutPut->Lines->Add(Results[i]);
         }
     }
     else // break lines into strings of 15 units
     {
         startcol = 1;
         endcol = 70;
         for (int i = 1; i <= noparts+1; i++)
         {
             sprintf(outline,"PART %d OUTPUT",i);
             FrmOutPut->RichOutPut->Lines->Add(outline);
             char aline[101];
             for (int j = 1; j <= 70; j++) aline[j] = ' ';

             for (int j = 0; j < linecount; j++)
             {
                 int count = 0;
                 strcpy(outline,Results[j].c_str());
                 for (int k = startcol; k <= endcol; k++)
                 {
                     aline[count] = outline[k];
                     count++;
                 }
                 aline[count+1] = '\0';
                 FrmOutPut->RichOutPut->Lines->Add(aline);
             }
             FrmOutPut->RichOutPut->Lines->Add("");
             startcol = endcol + 1;
             endcol = endcol + 70;
             if (endcol > howlong) endcol = howlong;
         }
     }
     delete[] Results;
     delete[] ColPos;
}
//---------------------------------------------------------------------------

void TAvgLinkForm::PreTree(int NN, int CRIT, int *LST, int **KLUS)
{
    int I, J, NI, NJ, L, N, In, INEND, NHOLD, NLINES, INDX, ICOL, JCOL;
    int KSH, JEND, MSH;
    int *JHOLD, *NIN1;
    char outline[201];

    // PRETRE procedure
    JHOLD = new int[NN+1];
    NIN1 = new int[NN+1];
//    int NN = nvalues;
    N = NN - 1;
    sprintf(outline,"No. of objects = %3d",NN);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (CRIT == 0) sprintf(outline,"Matrix defined similarities among objects.");
    else sprintf(outline,"Matrix defined dissimilarities among objects.");
    FrmOutPut->RichOutPut->Lines->Add(outline);

    for (int I = 1; I <= NN; I++)
    {
        LST[I] = I;
        NIN1[I] = 1;
    }

    for (int II = 1; II <= N; II++)
    {
        // name tabs
        I = KLUS[II][1];
        J = KLUS[II][2];
        NI = NIN1[I];
        NJ = NIN1[J];
        L = 1;
label2015:
        if (LST[L] == I) goto label2020;
        L = L + 1;
        if (L <= NN) goto label2015;
label2020:
        ICOL = L;
        In = ICOL + NI;
        INEND = In + NJ - 1;
        L = L + 1;
label2030:
        if (LST[L] == J) goto label2040;
        L = L + 1;
        if (L <= NN) goto label2030;
label2040:
        JCOL = L;
        JEND = JCOL + NJ - 1;
        NHOLD = 1;

        // remove J vector and store in HOLD
        for (int M = JCOL; M <= JEND; M++)
        {
            JHOLD[NHOLD] = LST[M];
            NHOLD = NHOLD + 1;
        }

        // shift
        MSH = JEND;
label2055:
        if (MSH == INEND) goto label2060;
        KSH = MSH - NJ;
        LST[MSH] = LST[KSH];
        MSH = MSH - 1;
        goto label2055;

        // insert hold vector
label2060:
        NHOLD = 1;
        for (int M = In; M <= INEND; M++)
        {
            LST[M] = JHOLD[NHOLD];
            NHOLD = NHOLD + 1;
        }
        NIN1[I] = NI + NJ;
    }

    NLINES = ((float)NN / 20.0) + 1;
    INDX = 0;
    char outvalue[31];
    for (int I = 1; I <= NLINES; I++)
    {
        strcpy(outline,"      ");
        for (int J = 1; J <= 20; J++)
        {
            INDX = INDX + 1;
            if (INDX <= NN)
            {
                 sprintf(outvalue," %3d",LST[INDX]);
                 strcat(outline,outvalue);
            }
        }
    }
    delete[] NIN1;
    delete[] JHOLD;
    // End of PRETRE procedure
}
