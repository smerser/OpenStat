//---------------------------------------------------------------------------

#ifndef MemMgrUnitH
#define MemMgrUnitH
//---------------------------------------------------------------------------
#endif
int GetDblQuadMem(double ****&matrix, int Nrows, int Ncols, int Nslices, int Nblocks);
void ClearDblQuadMem(double ****&matrix, int Nrows, int Ncols, int Nslices);
int GetDblCubeMem(double ***&matrix, int Nrows, int Ncols, int Nslices);
void ClearDblCubeMem(double ***&matrix, int Nrows, int Ncols);
int GetIntCubeMem(int ***&matrix, int Nrows, int Ncols, int Nslices);
void ClearIntCubeMem(int ***&matrix, int Nrows, int Ncols);
int GetDblMatMem(double **&matrix, int Nrows, int Ncols);
void ClearDblMatMem(double **&matrix, int Nrows);
int GetDblVecMem(double *&vector, int Nrows);
void ClearDblVecMem(double *&vector);
int GetIntMatMem(int **&matrix, int Nrows, int Ncols);
void ClearIntMatMem(int **&matrix, int Nrows);
int GetIntVecMem(int *&vector, int Nrows);
void ClearIntVecMem(int *&vector);
int GetLongDblMatMem(long double **&matrix, int Nrows, int Ncols);
int GetLongDblVecMem(long double *&vector, int Nrows);
void ClearLongDblVecMem(long double *&vector);
void ClearLongDblMatMem(long double **&matrix, int Nrows);
