//---------------------------------------------------------------------------

#ifndef InterruptedUnitH
#define InterruptedUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TInterruptedForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label2;
     TLabel *Label3;
     TListBox *PreList;
     TListBox *PostList;
     TCheckBox *ShowChk;
     TButton *CancelBtn;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TBitBtn *PreInBtn;
     TBitBtn *PreOutBtn;
     TBitBtn *PostInBtn;
     TBitBtn *PostOutBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall PreInBtnClick(TObject *Sender);
     void __fastcall PostInBtnClick(TObject *Sender);
     void __fastcall PreOutBtnClick(TObject *Sender);
     void __fastcall PostOutBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
   double *z;
   double *y;
   double **x;
   double **x1, **x2, *x3, *t, *p, *p1, **ii3, *p2, *s, *t2, **b, **x4, **d;
   double *r, **x5, *a1, *a2, *r2, *e, **f2;
   AnsiString pl, f1s, g1s, g2s, g3s, g4s, g5s, g6s, g7s, g8s;
   double c9, g, c, g1, t3, t4, t5, t6, f4, n7, d7, y1, xx3, f1, f2x, s1;
   double s3, s4, h, f3, y2, a, det, amax;
   int col, n, n1, n2, n4, n5, n6, m, l1, l2, i2, i3, t1, NoGoodCases;
   int n3, j1, m1, i1, R1;
   void __fastcall PlotFuncs(TObject *Sender);
   void __fastcall plotit(TObject *Sender);
   void __fastcall matinverse(TObject *Sender);

public:		// User declarations
     __fastcall TInterruptedForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TInterruptedForm *InterruptedForm;
//---------------------------------------------------------------------------
#endif
