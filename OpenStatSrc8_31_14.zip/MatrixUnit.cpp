//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "Printers.hpp"
#include "math.h"
#include "stdio.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "functions.h"
#include "RegSelUnit.h"
#include "MatrixUnit.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];

//--------------------------------------------------------------------------

void ArrayPrint(double **Matrix, int Nrows, int Ncols, char *ColHeader,\
     AnsiString *RowLabels, AnsiString *ColLabels, char *Title)
{
	char outline[121];
        char valstring[121];
        int startvar;
        int endvar;
        bool done;
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"%s\n",Title);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    	startvar = 0;
        endvar = Ncols-1;
        done = false;
        do
        {
	    if (endvar - startvar + 1 > 6) endvar = startvar + 5;
            if (endvar == Ncols -1) done = true;
            strcpy(outline,"");
            sprintf(outline,"             %s",ColHeader);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            // Build column labels
            strcpy(outline,"");
            for (int i = startvar; i <= endvar; i++)
            {
                sprintf(valstring,"%18s ",ColLabels[i].c_str());
                strcat(outline,valstring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);

            // Print matrix rows for columns startvar to endvar
            for (int i = 0; i < Nrows; i++)
            {
            	strcpy(outline,"");
        	for (int j = startvar; j <= endvar; j++)
            	{
                	sprintf(valstring,"%18.4f ",Matrix[i][j]);
                	strcat(outline,valstring);
            	}
            	FrmOutPut->RichOutPut->Lines->Add(outline);
            }
            startvar = endvar + 1;
            endvar = Ncols-1;
        } while (!done);
}
//----------------------------------------------------------------
void IntArrayPrint(int **Matrix, int Nrows, int Ncols, char *ColHeader,\
     AnsiString *RowLabels, AnsiString *ColLabels, char *Title)
{
	char outline[73];
   char valstring[21];
   int startvar;
   int endvar;
   bool done;

   sprintf(outline,"%s\n",Title);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   startvar = 0;
   endvar = Ncols-1;
   done = false;
   do
   {
     if (endvar - startvar + 1 > 6) endvar = startvar + 5;
     if (endvar == Ncols -1) done = true;
     strcpy(outline,"");
     sprintf(outline,"             %s",ColHeader);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     // Build column labels
     strcpy(outline,"          ");
     for (int i = startvar; i <= endvar; i++)
     {
         sprintf(valstring,"%10s",ColLabels[i].c_str());
         strcat(outline,valstring);
     }
     strcat(outline,"\n");
     FrmOutPut->RichOutPut->Lines->Add(outline);

     // Print matrix rows for columns startvar to endvar
     for (int i = 0; i < Nrows; i++)
     {
         strcpy(outline,"");
         sprintf(valstring,"%10s",RowLabels[i].c_str());
         strcat(outline,valstring);
         for (int j = startvar; j <= endvar; j++)
         {
             sprintf(valstring,"%10d",Matrix[i][j]);
             strcat(outline,valstring);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     startvar = endvar + 1;
     endvar = Ncols-1;
   }	while (!done);
}
//---------------------------------------------------------------
void VPrint(double *vector, int Ncols, AnsiString*Labels, char *Title)
{
    char outline[121];
    char valstring[121];
    int startvar;
    int endvar;
    bool done;

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%s\n",Title);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    startvar = 0;
    endvar = Ncols-1;
    done = false;
    do
    {
        if (endvar - startvar + 1 > 6) endvar = startvar + 5;
        if (endvar == Ncols -1) done = true;
        strcpy(outline,"");
        strcat(outline,"Variables ");
        // Build column labels
        for (int i = startvar; i <= endvar; i++)
        {
            sprintf(valstring,"%10s  ",Labels[i].c_str());
            strcat(outline,valstring);
        }
//        strcat(outline,"\n");
        FrmOutPut->RichOutPut->Lines->Add(outline);

        // Print vector for columns startvar to endvar
        strcpy(outline,"");
        sprintf(valstring,"           ");
        strcat(outline,valstring);
        for (int j = startvar; j <= endvar; j++)
        {
            sprintf(valstring,"%10.3f  ",vector[j]);
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        startvar = endvar + 1;
        endvar = Ncols-1;
    }	while (!done);
    FrmOutPut->RichOutPut->Lines->Add("");
}
//--------------------------------------------------------------------------
void IntVPrint(int *vector, int Ncols, AnsiString*Labels, char *Title)
{
    char outline[121];
    char valstring[121];
    int startvar;
    int endvar;
    bool done;

    sprintf(outline,"%s\n",Title);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    startvar = 0;
    endvar = Ncols-1;
    done = false;
    do
    {
        if (endvar - startvar + 1 > 6) endvar = startvar + 5;
        if (endvar == Ncols -1) done = true;
        strcpy(outline,"");
        strcat(outline,"Variables ");
        // Build column labels
        for (int i = startvar; i <= endvar; i++)
        {
            sprintf(valstring,"%10s",Labels[i].c_str());
            strcat(outline,valstring);
        }
        strcat(outline,"\n");
        FrmOutPut->RichOutPut->Lines->Add(outline);

        // Print vector for columns startvar to endvar
        strcpy(outline,"");
        sprintf(valstring,"          ");
        strcat(outline,valstring);
        for (int j = startvar; j <= endvar; j++)
        {
            sprintf(valstring,"%10.3f",vector[j]);
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        startvar = endvar + 1;
        endvar = Ncols-1;
    }	while (!done);
}
//--------------------------------------------------------------------------
void matsub(double **ResultMat, double **FirstMat, double **SecdMat, int rows, int cols)
{
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            ResultMat[i][j] = FirstMat[i][j] - SecdMat[i][j];
}
//--------------------------------------------------------------------------

void OPRINC(double *S, int M, int IA, double *EVAL, double **EVEC,
            double **COMP, double *VAR, double *CL, double *CU, int IER)
{
    // Adapted from the IMSL routine OPRINC.  S contains the lower half of a
    // covariance or correlation matrix (including the diagonal values.)
    // It returns eigenvalues in the EVAL vector, eigenvectors in the matrix
    // EVEC from the analysis of S.  The order of the matrix is M and IA roots
    // roots are extracted.  Comp is a returned M by M component correlation
    // matrix.  VAR of length M contains percentages of total variance
    // associated with the components, in the order of the eigenvalues.  On
    // entry, CL is the number of subjects on which S is based.  On return it
    // contains the left 95% confidence bounds on the eigenvalues.  CU returns
    // the right 95% confidence bounds on the eigenvalues. IER is the error
    // flag returned and is zero if there is no error.
    // NOTE!! Counting starts at 1, not 0!

    int i, j, k;
    double zero = 0.0, one = 1.0, rnine = 9.0, hund = 100.0,
           scale = 2.7718585822513, an, sum, sumr, anp, anm;

    IER = 0;
    an = CL[1];
    for (i = 1; i <= M; i++)
    {
        for (j = 1; j <=M; j++) EVEC[i][j] = 0.0;
        EVEC[i][i] = 1.0;
    }
    k = 0;
    for (i = 1; i <=M; i++)
    {
        k = k + i;
        CL[i] = sqrt(S[k]);
    }
    EHOUSS(S, M, EVAL, VAR, CU);
    EQRT2S(EVAL, VAR, M, EVEC, IA, IER);
    if (IER != 0)
    {
        UERTST(IER,"OPRINC");
        return;
    }
    EHOBKS(S, M, 1, M, EVEC, IA);
    sum = zero;
    for (i = 1; i <=M; i++)
    {
        if (EVAL[i] < zero) EVAL[i] = 0;
        sum += EVAL[i];
    }
    sumr = hund / sum;
    for (i = 1; i <=M; i++) VAR[i] = EVAL[i] * sumr;
    // compute COMP (correlations) matrix
    for (i = 1; i <=M; i++)
    {
        sumr = one / CL[i];
        for (j = 1; j <=M; j++) COMP[i][j] = sqrt(EVAL[j]) * EVEC[i][j] * sumr;
    }
    if (an < rnine)
    {
        an = rnine;
        IER = 34;
    }
    an = sqrt(an-one);
    // Compute vector CL
    anp = an / (an + scale);
    anm = an / (an - scale);
    for (i = 1; i <= M; i++)
    {
        CL[i] = EVAL[i] * anp;
        CU[i] = EVAL[i] * anm;
    }
    if (IER != 0) UERTST(IER,"OPRINC");
}
//---------------------------------------------------------------------------

void EHOUSS(double *A, int N, double *D, double *E, double *E2)
{
    //Called by OPRINC for obtaining eigenvalues and vectors
    // Adapted from the IMSL routine by the same name
    //NOTE! Subscripts start at 1, not 0!

    double zero = 0.0, h, scale, f, g, hh;
    int np1, nn, nbeg, ii, i, j, L, nk, k, jk1, ik, jk, jp1;

    np1 = N + 1;
    nn = (N * np1) / 2 - 1;
    nbeg = nn + 1 - N;
    for (ii = 1; ii <= N; ii++) // major loop
    {
        i = np1 - ii;
        L = i - 1;
        h = zero;
        scale = zero;
        if (L >= 1)
        {
            nk = nn;
            for (k = 1; k <= L; k++)
            {
                scale += fabs(A[nk]);
                nk--;
            }
            if (scale != 0.0) goto fifteen;
        }
        E[i] = zero;
        E2[i] = zero;
        goto sixtyfive;
        fifteen: nk = nn;
        for (k = 1; k <= L; k++)
        {
            A[nk] = A[nk] / scale;
            h += (A[nk] * A[nk]);
            nk--;
        }
        E2[i] = scale * scale * h;
        f = A[nn];
        g = -DSIGN(sqrt(h),f);
        E[i] = scale * g;
        h -= f * g;
        A[nn] = f - g;
        if (L != 1)
        {
            f = zero;
            jk1 = 1;
            for (j = 1; j <= L; j++)
            {
                g = zero;
                ik = nbeg + 1;
                jk = jk1;
                // form element of A * U
                for(k = 1; k <= j; k++)
                {
                    g += A[jk] * A[ik];
                    jk++;
                    ik++;
                }
                jp1 = j + 1;
                if (L >= jp1)
                {
                    jk += j - 1;
                    for (k = jp1; k <= L; k++)
                    {
                        g += A[jk] * A[ik];
                        jk += k;
                        ik++;
                    }
                }
                E[j] = g / h;
                f += E[j] * A[nbeg + j];
                jk1 += j;
            } // 40
            hh = f / (h + h);
            // form reduced A
            jk = 1;
            for (j = 1; j <= L; j++)
            {
                f = A[nbeg + j];
                g = E[j] - hh * f;
                E[j] = g;
                for (k = 1; k <= j; k++)
                {
                    A[jk] = A[jk] - (f * E[k]) - (g * A[nbeg + k]);
                    jk++;
                }
            }
        } // end if L != 1
        for (k = 1; k <= L; k++) A[nbeg+k] *= scale;
        sixtyfive: D[i] = A[nbeg+i];
        A[nbeg+i] = h * scale * scale;
        nbeg = nbeg - i + 1;
        nn -= i;
    } // 70
}
//---------------------------------------------------------------------------

double DSIGN(double X, double Y)
{
    if (Y < 0.0) return -fabs(X);
    return fabs(X);
}
//---------------------------------------------------------------------------


void EQRT2S(double *D, double *E, int N, double **Z, int IZ, int IER)
{
    // Adapted from the IMSL routine by the same name
    // NOTE! Subscripts start at 1, not 0!
    // On input, the vector D of length N contains the diagonal elements
    // of the symmetric tridiagonal matrix T.  On output, D contains the
    // eigenvalues of T in ascending order.
    // On input, the vector e of length N contains the sub-diagonal elements
    // of T in position 2,...,N. On output, E is destroyed.
    // N -order of tridiagonal matrix T. (input)
    // Z -On input, z contains the identity matrix of order N.  On output,
    // Z contains the eigenvector in column J of Z corresponding to the
    // eigenvalue D[j].
    // -Input row dimension of matrix Z exactly as specified in the calling
    // program.  If IZ is less than N, the eigenvectors are not computed.  In
    // this case, Z is not used.
    // IER - Error parameter.

    double B, C, F, G, H, P, R, S, RDELP = 0.222045E-15, ONE = 1.0, ZERO = 0.0;
    int I, II, J, K, L, L1, M, MM1, MM1PL, IP1;

    // Move the last N-1 elements of E into the first N-1 locations
//    IER = 0;
    if (N == 1) return;
    for (int i = 2; i <= N; i++) E[i-1] = E[i];
    E[N] = ZERO;
    B = ZERO;
    F = ZERO;
    for (L = 1; L <= N; L++)
    {
        J = 0;
        H = RDELP * (fabs(D[L]) + fabs(E[L]));
        if (B < H) B = H;
        // Look for small sub-diagonal element
        for (M = 1; M <= N; M++)
        {
            K = M;
            if (fabs(E[K]) <= B) continue;
        }
        M = K;
        if (M == L) goto fiftyfive;
twenty: if (J == 30)
        {
            IER = 128 + L;
            UERTST(IER,"EQR2S");
            return;
        }
        J++;
        L1 = L + 1;
        G = D[L];
        P = (D[L1] - G) / (E[L] + E[L]);
        R = fabs(P);
        if (RDELP * fabs(P) < 1.0) R = sqrt(P * P + ONE);
        D[L] = E[L] / (P + DSIGN(R,P));
        H = G - D[L];
        for (I = L1; I <= N; I++) D[I] = D[I] - H;
        F = F + H;
        // QL Transformation
        P = D[M];
        C = ONE;
        S = ZERO;
        MM1 = M - 1;
        MM1PL = MM1 + L;
        if (L > MM1) goto fifty;
        for (II = L; II <= MM1; II++)
        {
            I = MM1PL - II;
            G = C * E[I];
            H = C * P;
            if (fabs(P) >= fabs(E[I]))
            {
                C = E[I] / P;
                R = sqrt(C * C + ONE);
                E[I + 1] = S * P * R;
                S = C / R;
                C = ONE / R;
                goto thirtyfive;
            }
            C = P / E[I];
            R = sqrt(C * C + ONE);
            E[I + 1] = S * E[I] * R;
            S = ONE / R;
            C = C * S;
thirtyfive: P = C * D[I] - S * G;
            D[I + 1] = H + S * (C * G + S * D[I]);
            if (IZ >= N)
            {
                // Form vector
                for (K = 1; K <=N; K++)
                {
                    H = Z[K][I+1];
                    Z[K][I+1] = S * Z[K][I] + C * H;
                    Z[K][I] = C * Z[K][I] - S * H;
                }
            }
        } // next II
fifty:  E[L] = S * P;
        D[L] = C * P;
        if (fabs(E[L]) > B) goto twenty;
fiftyfive: D[L] += F;
    } // next L
    // Order Eigenvalues and Eigenvectors
    for (I = 1; I <= N; I++)
    {
        K = I;
        P = D[I];
        IP1 = I + 1;
        if (IP1 <= N)
        {
            for (J = IP1; J <= N; J++)
            {
                if (D[J] >= P) continue;
                K = J;
                P = D[J];
            }
        }
        if (K == I) return;
        D[K] = D[I];
        D[I] = P;
        if (IZ < N) return;
        for (J = 1; J <= N; J++)
        {
            P = Z[J][I];
            Z[J][I] = Z[J][K];
            Z[J][K] = P;
        }
    } // next I
    return;
}
//---------------------------------------------------------------------------

void EHOBKS(double *A, int N, int M1, int M2, double **Z, int IZ)
{
    // IMSL routine by the same name

    double H, S;
    int I, L, J, K, IA;

    if (N == 1) return;
    for (I = 2; I <= N; I++)
    {
        L = I - 1;
        IA = (I * L) / 2;
        H = A[IA+I];
        if (H == 0.0) return;
        // Derives eigenvectors M1 to M2 of the original matrix from
        // M1 to M2 of the symmetric tridiagonal matrix
        for (J = M1; J <= M2; J++)
        {
            S = 0.0;
            for (K = 1; K <= L; K++) S += (A[IA+K] * Z[K][J]);
            S /= H;
            for (K = 1; K <= L; K++) Z[K][J] -= (S * A[IA+K]);
        }
    }
}
//---------------------------------------------------------------------------

void UERTST(int IER, char *NAME)
{
    // Substitute for the IMSL routine by the same name
    // IER is input error parameter where IER = I + J where
    // I = 128 implies terminal error message,
    // I = 64 implies warning with fix message,
    // I = 32 implies warning message,
    // J = error code relevant to calling routine.
    // NAME is a character string providing the name of the calling routine
    // output is displayed as an application message box
/*
    int I, IEQDF = 0, LEVEL = 4, LEVOLD, NIN, NMTB;
    char IEQ[2] = "=";
    char NAMSET[7] = "UERSET";
    char NAMUPK[7];
    char NAMEQ[7] = "      ";

    strcpy(NAMUPK,NAME);
    if (IER <= 999)
    {
        if (LEVEL < 4)
        {
            IEQDF = 0;
            return;
        }
    }
    if (IER < -32)
    {
        IEQDF = 1;
        strcpy(NAMEQ,NAMUPK);
        return;
    }
    if (IER < 128)
    {

    }
*/

    AnsiString astring = "Routine ";
    astring = astring + NAME;
    astring = astring + " called UERTST with the error code = ";
    astring = astring + IER;
    Application->MessageBox(astring.c_str(),"WARNING!",MB_OK);
}
//---------------------------------------------------------------------------

void tred2(double **a, int n, double *d, double *e)
{
// Householder reduction of a real, symetric matrix a[1..n][1..n].  On output
// a is replaced by the orthogonal matrix Q effecting the transformation.
// d[1..n] returns the diagonal elements of the tridiagonal matrix, and e[1..n]
// the off-diagonal elements, with e[0] = 0.  The routine is designed to be
// used with the routine tqli.

   int L,k,j,i;
   double scale,hh,h,g,f;

   if (n > 1)
   {
      for (i = n-1; i >= 1; i--)
      {
         L = i-1;
         h = 0.0;
         scale = 0.0;
         if (L > 0)
         {
            for (k = 0; k <= L; k++) scale = scale + fabs(a[i][k]);
            if (scale == 0.0) e[i] = a[i][L];
            else
            {
               for (k = 0; k <= L; k++)
               {
                  a[i][k] = a[i][k] / scale;
                  h = h + sqr(a[i][k]);
               }
               f = a[i][L];
               g = -sign(sqrt(h),f);
               e[i] = scale * g;
               h = h-f * g;
               a[i][L] = f - g;
               f = 0.0;
               for (j = 0; j <= L; j++)
               {
                  // Next statement can be omitted if eigenvectors not wanted
                  a[j][i] = a[i][j] / h;
                  g = 0.0;
                  for (k = 0; k <= j; k++) g = g + a[j][k] * a[i][k];
                  if (L > j) for (k = j+1; k <= L; k++) g = g + a[k][j] * a[i][k];
                  e[j] = g / h;
                  f = f + e[j]* a[i][j];
               }
               hh = f / (h+h);
               for (j = 0; j <= L; j++)
               {
                  f = a[i][j];
                  g = e[j] - hh * f;
                  e[j] = g;
                  for (k = 0; k <= j; k++) a[j][k] = a[j][k] - (f * e[k] + g * a[i][k]);
               }
            }
         }
         else e[i] = a[i][L];
         d[i] = h;
      }
   }
   // Next statement can be omitted if eigenvectors not wanted
   d[0] = 0.0;
   e[0] = 0.0;
   for (i = 0; i < n; i++)
   {
       // Contents of this loop can be omitted if eigenvectors not wanted,
       //   except for statement d[i] = a[i,i];
      L = i - 1;
      if (d[i] != 0.0)
      {
         for (j = 0; j <= L; j++)
         {
            g = 0.0;
            for (k = 0; k <= L; k++) g = g + a[i][k] * a[k][j];
            for (k = 0; k <= L; k++) a[k][j] = a[k][j] - g * a[k][i];
         }
      }
      d[i] = a[i][i];
      a[i][i] = 1.0;
      if (L >= 0)
      {
         for (j = 0; j <= L; j++)
         {
            a[i][j] = 0.0;
            a[j][i] = 0.0;
         }
      }
   }
}
//-------------------------------------------------------------------

void tqli(double *d, double *e, int n, double **z)
{
// QL algorithm with implicit shifts, to determine the eigenvalues and
// eigenvectors of a real, symmetric matrix, or of a real, symmetric matrix
// previously reduced by tred2.  On input, d[1..n] contains the diagonal
// elements of the tridiagonal matrix.  On output, it returns the eigenvalues.
// The vector e[1..n] inputs the subdiagonal elements of the tridiagonal matrix,
// with e[0] arbitrary.  On output e is destroyed. If the eignevectors of a
// tridiagonal matrix are desired, the matrix z[1..n][1..n] is input as the
// identify matrix.  If the eigenvectors of a matrix that has been reduced
// by tred2 are required, then z is input as the matrix output of tred2.  In
// either case, the kth column of z returns the normalized eigenvector
// corresponding to d[k]. 

     int m,L,iter,i,k;
     double s,r,p,g,f,dd,c,b;

   if  (n > 1)
   {
      for (i = 1; i < n; i++)  e[i-1] = e[i];
      e[n-1] = 0.0;
      for (L = 0; L < n; L++)
      {
           iter = 0;
L1:         for (m = L; m <= n-2; m++)
           {
               dd = fabs(d[m]) + fabs(d[m+1]);
               if  ((fabs(e[m]) + dd) == dd) goto L2;
           }
           m = n-1;
L2:         if (m != L)
           {
               if (iter == 30)
               {
                    ShowMessage("Too many iterations in routine tqli-returning");
                    return;
               }
               iter = iter+1;
               g = (d[L+1]-d[L])/(2.0*e[L]);
               r = sqrt(sqr(g)+1.0);
               g = d[m]-d[L]+e[L]/(g+sign(r,g));
               s = 1.0;
               c = 1.0;
               p = 0.0;
               for (i = m-1; i >= L; i--)
               {
                   f = s*e[i];
                   b = c*e[i];
                   if (fabs(f) >= fabs(g))
                   {
                       c = g/f;
                       r = sqrt(sqr(c)+1.0);
                       e[i+1] = f*r;
                       s = 1.0/r;
                       c = c*s;
                   }
                   else {
                       s = f/g;
                       r = sqrt(sqr(s)+1.0);
                       e[i+1] = g*r;
                       c = 1.0/r;
                       s = s*c;
                   }
                   g = d[i+1]-p;
                   r = (d[i]-g)*s+2.0*c*b;
                   p = s*r;
                   d[i+1] = g+p;
                   g = c*r-b;
                   // Next loop can be omitted if eigenvectors not wanted
                   for (k = 0; k < n; k++)
                   {
                       f = z[k][i+1];
                       z[k][i+1] = s*z[k][i]+c*f;
                       z[k][i] = c*z[k][i]-s*f;
                   }
               }
              d[L] = d[L]-p;
              e[L] = g;
              e[m] = 0.0;
              goto L1;
           }
      }
   }
}
//-------------------------------------------------------------------

void xtqli(double **a, int NP, double *d, double *f, double *e)
{
// Obtains the eigenvectors and eigenvalues of a real symetric matrix a.
// Upon completion, the matrix a contains the columns of normalized vectors
// and the eigenvalues are returned in d.  The vector f is a work vector.

     int i;
     double sum;

     sum = 0.0;
     tred2(a, NP, d, e);
     tqli(d, e, NP, a);
     for (i = 0; i < NP; i++)
     {
          f[i] = 0.0;
          sum = sum + d[i];
     }
     for (i = 0; i < NP; i++) f[i] = (d[i] / sum) * 100.0;
}
//---------------------------------------------------------------------------

double pythag(double a, double b)
{
    // (C) Copr. 1986-92 Numerical Recipes Software 7'-#1.35,wa.

	double absa,absb;
   	absa=fabs(a);
	absb=fabs(b);
	if (absa > absb) return absa*sqrt(1.0+SQR(absb/absa));
	else return (absb == 0.0 ? 0.0 : absb*sqrt(1.0+SQR(absa/absb)));
}

//-------------------------------------------------------------------------

double SQR(double a)
{
    if (a == 0.0) return (0.0);
    return (a * a);
}
//-------------------------------------------------------------------------

int Correlations(double *means, double *stddevs, double **corr, int NoSelected,
    int *ColNoSelected, int & NSUBS, int mattype, bool Augment, int prtopts)
{
    // Computes the correlation matrix
    // and the means and standard deviations of the NoSelected variables read
    // from the grid where the NoSelected variables are selected from grid
    // columns stored in ColNoSelected.  Results are returned in the vector
    // corr.
    // The number of valid subjects (grid rows) is returned in NSUBS which
    // originally contains the number of cases in the grid.
    // If Augment is true, the columns of the data matrix are augmented with
    // a vector of 1's (used for calculating the intercept and intercept std.err.)
    // NOTE!  If the matrix is to be augmented, be sure and obtain memory for
    // the matrix and vectors one larger than the no. of variables selected!
    // If mattype = 1, raw cross-products are returned.
    // If mattype = 2, covariances are returned.
    // If mattype = 3, correlations returned.
    // If prtopts = 0, no printing desired.
    // If prtopts = 1, means, standard deviations and matrix are printed.
    // If prtopts = 2, only the matrix is printed.
    // If prtopts = 3, only means and standard deviations are printed.
    // IER returned = 0 if OK, 1 if a variance = 0 encountered

    int IER = 0, colx, coly, count = 0, novars;
    double X, Y;
    char outline[81];
    double **data;
    AnsiString *varlabels;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    if (Augment) novars = NoSelected + 1;
    else novars = NoSelected;
    GetDblMatMem(data,NoCases,novars);
    varlabels = new AnsiString[novars];

    // Initialize arrays
    for (int i = 0; i < novars; i++)
    {
        means[i] = 0.0;
        stddevs[i] = 0.0;
        varlabels[i] = "";
        for (int j = 0; j < novars; j++) corr[i][j] = 0.0;
    }

    // get the data
    for (int i = 0; i < NSUBS; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (int j = 0; j < NoSelected; j++)
        {
            colx = ColNoSelected[j];
//            if (! ValidValue(i+1,colx)) goto ab;
            X = StrToFloat(MainForm->Grid->Cells[colx][i+1]);
/*            result = GetValue(i+1,colx,intvalue,dblvalue,strvalue);
            if (result == 1) X = 0.0;
            else X = dblvalue; */
            data[count][j] = X;
        }
        count++;
ab: }
    NSUBS = count;
    if (count < 2)
    {
       ShowMessage("Less than 2 valid cases found - terminating...");
       IER = 1;
       return (IER);
    }

    // get the variable labels
    for (int j = 0; j < NoSelected; j++)
    {
        coly = ColNoSelected[j];
        varlabels[j] = MainForm->Grid->Cells[coly][0];
    }

    // augment if requested
    if (Augment)
    {
       for (int i = 0; i < count; i++) data[i][novars-1] = 1.0;
       varlabels[novars-1] = "Intercept";
    }

    // Get sums for the means
    for (int i = 0; i < NSUBS; i++)
    {
        for (int j = 0; j < novars; j++)
        {
                means[j] += data[i][j];
        }
    }

    // get raw cross-products
    for (int i = 0; i < NSUBS; i++)
    {
        for (int j = 0; j < novars; j++)
        {
            for (int k = 0; k < novars; k++)
            {
                X = data[i][j];
                Y = data[i][k];
                corr[j][k] += (X * Y);
            }
        }
    }

    if (mattype == 1) // raw cross-products wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            ArrayPrint(corr, novars, novars, "Cross-Products",
               varlabels,varlabels, "Raw Cross-Products Matrix");
        for (int i = 0; i < novars; i++) // get std. dev.s
        {
            if (count > 1)
            {
               stddevs[i] = corr[i][i] - (means[i] * means[i] / double(count));
               stddevs[i] /= double(count-1);
            }
            else stddevs[i] = 0.0;
            if (stddevs[i] > 0.0) stddevs[i] = sqrt(stddevs[i]);
            else
            {
                stddevs[i] = 0.0;
                IER = 1;
            }
        }
        for (int i = 0; i < novars; i++) // get means
        {
            if (count > 0) means[i] /= double(count);
            else means[i] = 0.0;
        }
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            VPrint(means, novars, varlabels, "Means");
            VPrint(stddevs, novars, varlabels, "Standard Deviations");
        }
        return (IER);
    }

    // get variance-covariance matrix
    for (int i = 0; i < novars; i++)
    {
        for (int j = 0; j < novars; j++)
        {
            if (count > 1)
            {
               corr[i][j] = corr[i][j] - (means[i] * means[j] / double(count));
               corr[i][j] /= double(count - 1);
            }
            else corr[i][j] = -99.9;
        }
    }

    // Since diagonal values are variances, grab them
    for (int i = 0; i < novars; i++)
    {
        stddevs[i] = corr[i][i]; // variances on diagonal
        if (stddevs[i] <= 0.0) IER = 1;
    }

    // Divide sums to get means and square root of variances for std. dev.'s
    for (int i = 0; i < novars; i++)
    {
        if (count > 0) means[i] /= double(count);
        if (stddevs[i] > 0.0) stddevs[i] = sqrt(stddevs[i]);
        else stddevs[i] = 0.0;
    }

    if (mattype == 2) // covariance matrix wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            ArrayPrint(corr, novars, novars, "Covariances",
               varlabels,varlabels, "COVARIANCE MATRIX");
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            VPrint(means, novars, varlabels, "Means");
            VPrint(stddevs, novars, varlabels, "Standard Deviations");
        }
        NSUBS = count;
        return (IER);
    }

    // Get correlations
    for (int i = 0; i < novars; i++)
    {
        for (int j = 0; j < novars; j++)
        {
            if ((stddevs[i] > 0.0) && (stddevs[j] > 0.0))
                corr[i][j] /= (stddevs[i] * stddevs[j]);
            else
            {
                corr[i][j] = 0.0;
                IER = 1;
            }
        }
    }
    if (mattype == 3) // correlations wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            ArrayPrint(corr, novars, novars, "Correlations",varlabels,
                varlabels, "CORRELATION MATRIX");
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            VPrint(means, novars, varlabels, "Means");
            VPrint(stddevs, novars, varlabels, "Standard Deviations");
        }
    }
//    sprintf(outline,"Results based on a total of %d observations.",count);
//    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (prtopts != 0)
    {
        sprintf(outline,"No. of valid cases = %d",count);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
    }
    return (IER);
}
//---------------------------------------------------------------------------

void eigsrt(double d[], double **v, int n)
{
    //(C) Copr. 1986-92 Numerical Recipes Software 7'-#1.35,wa. */
    // sorts eigenvalues and vectors (d and v) with n and n x n elements

	int k,j,i;
	double p;

	for (i=1;i<n;i++) {
		p=d[k=i];
		for (j=i+1;j<=n;j++)
			if (d[j] >= p) p=d[k=j];
		if (k != i) {
			d[k]=d[i];
			d[i]=p;
			for (j=1;j<=n;j++) {
				p=v[j][i];
				v[j][i]=v[j][k];
				v[j][k]=p;
			}
		}
	}
}
//----------------------------------------------------------------------

void vectorprint(double *vector, int *selected, int Ncols, char *Title)
{
	char outline[73];
    char valstring[21];
    int startvar;
    int endvar;
    bool done;

    sprintf(outline,"\n\n%s\n",Title);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    startvar = 0;
    endvar = Ncols-1;
    done = false;
    do
    {
        if (endvar - startvar + 1 > 6) endvar = startvar + 5;
        if (endvar == Ncols -1) done = true;
        strcpy(outline,"");
        strcat(outline,"Variables ");
        // Build column labels
        for (int i = startvar; i <= endvar; i++)
        {
            sprintf(valstring,"%10s",MainForm->Grid->Cells[selected[i]][0].c_str());
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);

        // Print vector for columns startvar to endvar
        strcpy(outline,"");
        sprintf(valstring,"          ");
        strcat(outline,valstring);
        for (int j = startvar; j <= endvar; j++)
        {
            sprintf(valstring,"%10.3f",vector[j]);
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        startvar = endvar + 1;
        endvar = Ncols-1;
    }	while (!done);
}
//-----------------------------------------------------------------------

void MatPrint(double **Matrix, int Nrows, int Ncols, int *selected, char *Title)
{
	char outline[121];
    char valstring[121];
    int startvar;
    int endvar;
    bool done;

    sprintf(outline,"\n\n");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"%s\n",Title);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    startvar = 0;
    endvar = Ncols-1;
    done = false;
    do
    {
    	if (endvar - startvar + 1 > 6) endvar = startvar + 5;
      if (endvar == Ncols -1) done = true;
      strcpy(outline,"");
      strcat(outline,"Variables ");
      // Build column labels
      for (int i = startvar; i <= endvar; i++)
      {
      	sprintf(valstring,"%10s  ",MainForm->Grid->Cells[selected[i]][0].c_str());
         strcat(outline,valstring);
      }
      strcat(outline,"\n");
      FrmOutPut->RichOutPut->Lines->Add(outline);

      // Print matrix rows for columns startvar to endvar
      for (int i = 0; i < Nrows; i++)
      {
      	strcpy(outline,"");
         sprintf(valstring,"%10s ",MainForm->Grid->Cells[selected[i]][0].c_str());
         strcat(outline,valstring);
         for (int j = startvar; j <= endvar; j++)
         {
         	sprintf(valstring,"%10.3f  ",Matrix[i][j]);
            strcat(outline,valstring);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
      }
      startvar = endvar + 1;
      endvar = Ncols-1;
    }	while (!done);
}

// -------------------------------------------------------------------------
double Determ(double **a, int rows)
{
    int i;
    int *indx;
    double Det = 0.0;

    indx = new int[rows+1];
    ludcmp(a, rows, indx, Det);
    for (i = 0; i < rows; i++) Det = Det * a[i][i];
    delete[] indx;
    return Det;
}

//-------------------------------------------------------------------------------------

void ludcmp(double **a, int n, int *indx, double &d)
{
   double tiny = 1.0e-20;
   int k,j,imax,i;
   double sum,dum,big;
   double *vv;

   vv = new double[n];
   d = 1.0;
   for (i = 0; i < n; i++)
   {
      big = 0.0;
      for (j = 0; j < n; j++)   if (fabs(a[i][j]) > big) big = fabs(a[i][j]);
      if (big == 0.0)
      {
         ShowMessage("Error - Singular matrix!");
         delete[] vv;
         return;
      }
      vv[i] = 1.0 / big;
   }
   for (j = 0; j < n; j++)
   {
      if (j > 0)
      {
         for (i = 0; i < j; i++)
         {
            sum = a[i][j];
            if (i > 0)
            {
               for (k = 0; k < i; k++) sum = sum-a[i][k] * a[k][j];
               a[i][j] = sum;
            }
         }
      }
      big = 0.0;
      for (i = j; i < n; i++)
      {
         sum = a[i][j];
         if (j > 0)
         {
            for (k = 0; k < j; k++) sum = sum - a[i][k] * a[k][j];
            a[i][j] = sum;
         }
         dum = vv[i] * fabs(sum);
         if (dum >= big)
         {
            big = dum;
            imax = i;
         }
      }
      if (j != imax)
      {
         for (k = 0; k < n; k++)
         {
            dum = a[imax][k];
            a[imax][k] = a[j][k];
            a[j][k] = dum;
         }
         d = -d;
         vv[imax] = vv[j];
      }
      indx[j] = imax;
      if (a[j][j] == 0.0) a[j][j] = tiny;
      if (j != n-1)
      {
         dum = 1.0 / a[j][j];
         for (i = j+1; i < n; i++) a[i][j] = a[i][j] * dum;
      }
   }
   if (a[n-1][n-1] == 0.0) a[n-1][n-1] = tiny;
   delete[] vv;
}
//-------------------------------------------------------------------

void mreg(int Noindep, int *IndepCols, int DepCol, AnsiString *RowLabels,
               double *Means, double *Variances,double *StdDevs,
               double *BWeights, double *BetaWeights, double *BStdErrs,
               double *Bttests,double *tprobs, double &R2, double &F, double &stderrest,
               int &NCases, bool &errorcode, bool PrintDesc, bool PrintCorrs,
               bool PrintInverse, bool PrintCoefs, bool SaveCorrs)
{
   int i, j, k, N;
   double **X;
   double **XT;
   double **XTX;
   double *XTY;
   double *Y;
   int *indx;
   double D, Prob, value, SSY, SSres, resvar, SSreg, VarY, SDY, MeanY;
   double TOL, VIF;
   AnsiString *ColLabels;
   char title[121];
   AnsiString deplabel;
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;

   GetDblMatMem(X,NoCases,Noindep+1); // augmented independent var. matrix
   GetDblMatMem(XT,Noindep+1,NoCases); // transpose of independent var"s
   GetDblMatMem(XTX,Noindep+1,Noindep+1); // product of transpose X times X
   GetDblVecMem(Y,NoCases+1); // Y variable values
   GetDblVecMem(XTY,Noindep+1); // X transpose time Y
   indx = new int[Noindep+1];
   ColLabels = new AnsiString[NoCases];

   // initialize
   for (i = 0; i <= Noindep; i++)
   {
        indx[i] = 0;
        XTY[i] = 0.0;
        tprobs[i] = 0.0;
        Means[i] = 0.0;
        Variances[i] = 0.0;
        StdDevs[i] = 0.0;
        BWeights[i] = 0.0;
        BetaWeights[i] = 0.0;
        for (j = 0; j <= Noindep; j++)  XTX[i][j] = 0.0;
   }
   SSY = 0.0;
   VarY = 0.0;
   SDY = 0.0;
   MeanY = 0.0;
   for (i = 0; i < NCases; i++)
   {
       ColLabels[i] = "Case " + IntToStr(i+1);
       Y[i] = 0.0;
   }

   // get independent matrix and Y vector from the grid
   NCases = 0;
   N = Noindep + 1;
   for (i = 1; i <= NoCases; i++)
   {
        for (j = 0; j < Noindep; j++)
        {
             value = StrToFloat(Trim(MainForm->Grid->Cells[IndepCols[j]][i]));
             X[NCases][j] = value;
             Means[j] = Means[j] + value;
             Variances[j] = Variances[j] + (value * value);
        }
        value = StrToFloat(Trim(MainForm->Grid->Cells[DepCol][i]));
        Y[NCases] = value;
        MeanY = MeanY + value;
        SSY = SSY + (value * value);
        NCases = NCases + 1;
   }
   deplabel = MainForm->Grid->Cells[DepCol][0];
   RowLabels[Noindep] = "Intercept";
   VarY = SSY - (MeanY * MeanY / NCases);
   VarY = VarY / (NCases - 1);
   SDY = sqrt(VarY);

   // augment the matrix
   for (i = 1; i <= NCases; i++)  X[i-1][Noindep] = 1.0;
   Y[NCases] = 1.0;

   // get transpose of augmented X matrix
   MATTRN(XT,X,NCases,N);
/*
   if (PrintAll)
   {
        ArrayPrint(XT,N,NCases,"VARIABLES",RowLabels,ColLabels,"XT MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
   }
*/
   // get product of the augmented X transpose times augmented X
   MATAxB(XTX,XT,X,N,NCases,NCases,N,errorcode);
/*
   if (PrintAll)
   {
        ArrayPrint(XTX,N,N,"VARIABLE",RowLabels,RowLabels,"XTX MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
   }
*/
   // Get means, variances, standard deviations
   errorcode = false;
   for (i = 0; i < N; i++)
   {
        Variances[i] = XTX[i][i] - (sqr(XTX[i][N-1]) / NCases);
        Variances[i] = Variances[i] / (NCases - 1);
        if (Variances[i] > 0.0)  StdDevs[i] = sqrt(Variances[i]);
        else errorcode = true;
        Means[i] = XTX[N-1][i] / NCases;
   }
/*
   if (PrintAll)
   {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Means,N,RowLabels,"MEANS");
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Variances,N,RowLabels,"VARIANCES");
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(StdDevs,N,RowLabels,"STD. DEV.S");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
   }
*/
   // get product of the augmented X transpose matrix times the Y vector
   for (i = 0; i < N; i++)
        for (j = 0; j < NCases; j++)
             XTY[i] = XTY[i] + XT[i][j] * Y[j];
/*
  if (PrintAll)
   {
        VPrint(XTY,N,RowLabels,"XTY VECTOR");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
   }
*/
   // get inverse of the augmented cross products matrix among independent variables
   SVDinverse(XTX,N);
/*
   if (PrintAll)
   {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(XTX,N,N,"VARIABLE",RowLabels,RowLabels,"XTX MATRIX INVERSE");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
   }
*/
   // multiply augmented inverse matrix times the XTY vector
   // result is bweights with the intercept last
   for (i = 0; i < N; i++)
        for (j = 0; j < N; j++)
             BWeights[i] = BWeights[i] + XTX[i][j] * XTY[j];

   // get Beta weights
   for (i = 0; i < N-1; i++)
       BetaWeights[i] = BWeights[i] * StdDevs[i] / SDY;

   // get standard errors, squared multiple correlation, tests of signif.
   SSres = 0.0;
   for (i = 0; i <= Noindep; i++)
   {
       SSres = SSres + BWeights[i] * XTY[i];
   }
   SSres = SSY - SSres;
   resvar = SSres / (NCases - N);
   if (resvar > 0.0)  stderrest = sqrt(resvar);
   for (i = 0; i < N; i++)  // standard errors and t-test values for weights
   {
        BStdErrs[i] = sqrt(resvar * XTX[i][i]);
        Bttests[i] = BWeights[i] / BStdErrs[i];
        tprobs[i] = tprob(Bttests[i],NCases-N);
   }
   SSY = VarY * (NCases-1);
   SSreg = SSY - SSres;
   R2 = SSreg / SSY;
   F = (SSreg / (N - 1)) / (SSres / (NCases - N));
   Prob = ftest((N-1),(NCases-N),F);
   double AdjR2 = 1.0 - (1.0 - R2) * (NCases - 1) / (NCases-N);
   // get intercorrelation of all variables
   int prtopts = 0;
   if (PrintDesc) prtopts = 3;
   int Nvars = Noindep + 1;
   IndepCols[Nvars-1] = DepCol;
   Correlations(Means,StdDevs,XTX,Nvars,IndepCols,NoCases,3,false,prtopts);
   for (int i = 0; i < Nvars; i++) Variances[i] = sqr(StdDevs[i]);
   RowLabels[Nvars-1] = deplabel;
   if (PrintCorrs)
   {
      FrmOutPut->RichOutPut->Lines->Add("");
      ArrayPrint(XTX,Nvars,Nvars,"VARIABLE",RowLabels,RowLabels,"CORRELATION MATRIX");
   }
   if (SaveCorrs) SaveSqrMat(XTX, Nvars, NCases, RowLabels, Means, StdDevs);
   SVDinverse(XTX,Noindep);
   if (PrintInverse)
   {
      FrmOutPut->RichOutPut->Lines->Add("");
      ArrayPrint(XTX,Noindep,Noindep,"VARIABLE",RowLabels,RowLabels,"INVERSE OF CORRELATION MATRIX");
   }
   if (PrintCoefs)
   {
      FrmOutPut->RichOutPut->Lines->Add("");
      FrmOutPut->RichOutPut->Lines->Add("Dependent variable: " + deplabel);
      FrmOutPut->RichOutPut->Lines->Add("");
   }
   RowLabels[N-1] = "Intercept";
   if (PrintCoefs)
      FrmOutPut->RichOutPut->Lines->Add("Variable       Beta      B         Std.Err.  t         Prob.>t   VIF       TOL");
   for (int i = 0; i < Noindep; i++)
   {
       VIF = XTX[i][i];
       if (VIF > 0.0) TOL = 1.0 / VIF;
       else TOL = 0.0;
       sprintf(title,"%10s%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f",
              RowLabels[i], BetaWeights[i] ,BWeights[i], BStdErrs[i], Bttests[i],
              tprobs[i], VIF, TOL);
       if (PrintCoefs)
           FrmOutPut->RichOutPut->Lines->Add(title);
   }
   sprintf(title,"%10s%10.3f%10.3f%10.3f%10.3f%10.3f",
                RowLabels[Noindep], BetaWeights[Noindep] ,BWeights[Noindep],
                BStdErrs[Noindep], Bttests[Noindep], tprobs[Noindep]);
   if (PrintCoefs)
       FrmOutPut->RichOutPut->Lines->Add(title);
   if (PrintCoefs)
   {
      FrmOutPut->RichOutPut->Lines->Add("");
      FrmOutPut->RichOutPut->Lines->Add("SOURCE      DF        SS        MS        F      Prob.>F");
      sprintf(title,"Regression%3d  %9.3f %9.3f %9.3f     %6.4f",N-1,SSreg,SSreg /(N-1),F,Prob);
      FrmOutPut->RichOutPut->Lines->Add(title);
      sprintf(title,"Residual  %3d  %9.3f %9.3f",(NCases-N),SSres,SSres /(NCases-N));
      FrmOutPut->RichOutPut->Lines->Add(title);
      sprintf(title,"Total     %3d  %9.3f",NCases-1,SSY);
      FrmOutPut->RichOutPut->Lines->Add(title);
      FrmOutPut->RichOutPut->Lines->Add("");
      sprintf(title,"R2 = %6.4f, F = %8.2f, D.F. = %d %d, Prob>F = %6.4f",
                 R2,F,N-1,NCases-N,Prob);
      FrmOutPut->RichOutPut->Lines->Add(title);
      sprintf(title,"Adjusted R2 = %6.4f",AdjR2);
      FrmOutPut->RichOutPut->Lines->Add(title);
      FrmOutPut->RichOutPut->Lines->Add("");
      sprintf(title,"Standard Error of Estimate = %8.2f",stderrest);
      FrmOutPut->RichOutPut->Lines->Add(title);
   }
//   FrmOutPut->ShowModal();
//   FrmOutPut->RichOutPut->Clear();

   // clean up the heap
   delete[] ColLabels;
   delete[] indx;
   delete[] XTY;
   delete[] Y;
   ClearDblMatMem(XTX,Noindep+1);
   ClearDblMatMem(XT,Noindep+1);
   ClearDblMatMem(X,NoCases);
}
//----------------------------------------------------------------------------------------

void MATAxB(double ** a, double **b, double **c, int brows, int bcols, int crows,
            int ccols, bool &errorcode)
{
     // Product of matrix b times c with results returned in a
     int i, j, k;

     errorcode = false;
     for (i = 0; i < brows; i++)
     {
        for (j = 0; j < ccols; j++) a[i][j] = 0.0;
     }
     if (bcols != crows) errorcode = true;
     else
     {
          for (i = 0; i < brows; i++)
          {
              for (j = 0; j < ccols; j++)
              {
                  for (k = 0; k < crows; k++)
                      a[i][j] = a[i][j] + b[i][k] * c[k][j];
              }
         }
     }
} // end of MATAxB

//-------------------------------------------------------------------

bool MATTRN(double ** a, double **b, int brows, int bcols)
{
     // transpose the b matrix and return it in a
     int i, j;
     bool errorcode;

     errorcode = false;
     if ((brows == 1) && (bcols == 1))  errorcode = true;
     else
     {
          for (i = 0; i < brows; i++)
              for (j = 0; j < bcols; j++) a[j][i] = b[i][j];
     }
     return (errorcode);
} // end of mattrn
//-------------------------------------------------------------------

int matinv(double **a, int N, double **ainverse, double **v, double *W)
{
    // adapted from the singular value decomposition of a matrix
    // a is a symetric matrix with the inverse returned in ainverse.
    // W is a diagonal matrix of singular variables returned as a vector.
    // v is an orthogonal matrix of the transformation and a is replaced by
    // U, another orthogonal matrix from: [a] = [U] [W] [V]
    // See Numerical Recipes.  The Art of Scientific Computing by William H.
    // Press, Brian P. Flannery, Saul A. Teukolsky and William T. Vetterling
    // Cambridge University Press, Cambridge, 1987

    int M, nm, L, k, j, jj, its, i, flag;
    int IER = 0;
    double z, y, X, scal, s, H, g, f, C, anorm;
    double **vtimesw, *rv1;

    try
    {
    	vtimesw = new double*[N+1];
    	for (i = 0; i < N+1; i++) vtimesw[i] = new double[N+1];
    	rv1 = new double[N+1];
    }
    catch (...) // This block entered only if xalloc is thrown.
    {
    	Application->MessageBox("Could not allocate memory.","OUT OF MEMORY",MB_OK);
        IER = 3;
        return(IER);
	}

   M = N;
   g = 0.0;
   scal = 0.0;
   anorm = 0.0;
   for (i = 1; i <= N; i++)
   {
      L = i + 1;
      rv1[i] = scal * g;
      g = 0.0;
      s = 0.0;
      scal = 0.0;
      if (i <= M)
      {
         for (k = i; k <= M; k++) scal += fabs(a[k][i]);
         if (scal)
         {
            for (k = i; k <= M; k++)
            {
               a[k][i] /= scal;
               s += a[k][i] * a[k][i];
            }
            f = a[i][i];
            g = -sign(sqrt(s), f);
            H = f * g - s;
            a[i][i] = f - g;
            if (i != N)
            {
               for (j = L; j <= N; j++)
               {
                  for (s=0.0,k = i; k <= M; k++) s += a[k][i] * a[k][j];
                  f = s / H;
                  for (k = i; k <= M; k++) a[k][j] +=  f * a[k][i];
               }
            }
            for (k = i; k <= M; k++) a[k][i] *= scal;
         }
      }

      W[i] = scal * g;
      g = 0.0;
      s = 0.0;
      scal = 0.0;
      if ((i <= M) && (i != N))
      {
         for (k = L; k <= N; k++) scal += fabs(a[i][k]);
         if (scal)
         {
            for (k = L; k <= N; k++)
            {
               a[i][k] /= scal;
               s += a[i][k] * a[i][k];
            }
            f = a[i][L];
            g = -sign(sqrt(s), f);
            H = f * g - s;
            a[i][L] = f - g;
            for (k = L; k <= N; k++) rv1[k] = a[i][k] / H;
            if (i != M)
            {
               for (j = L; j <= M; j++)
               {
                  for (s=0.0,k = L; k <= N; k++) s += a[j][k] * a[i][k];
                  for (k = L; k <= N; k++) a[j][k] += s * rv1[k];
               }
            }
            for (k = L; k <= N; k++) a[i][k] *= scal;
         }
      }
      anorm = max(anorm, (fabs(W[i]) + fabs(rv1[i])));
   }

   // Accumulation of right-hand transformations
   for (i = N; i >= 1; i--)
   {
      if (i < N)
      {
         if (g)
         {
            for (j = L; j <= N; j++) v[j][i] = (a[i][j] / a[i][L]) / g;
            for (j = L; j <= N; j++)
            {
               for (s=0.0,k = L; k <= N; k++) s += a[i][k] * v[k][j];
               for (k = L; k <= N; k++) v[k][j] += s * v[k][i];
            }
         }
         for (j = L; j <= N; j++)
         {
            v[i][j] = 0.0;
            v[j][i] = 0.0;
         }
      }
      v[i][i] = 1.0;
      g = rv1[i];
      L = i;
   }

   // Accumulation of left-hand transformations
   for (i = N; i >= 1; i--)
   {
      L = i + 1;
      g = W[i];
      if (i < N)
      {
         for (j = L; j <= N; j++) a[i][j] = 0.0;
      }
      if (g)
      {
         g = 1.0 / g;
         if (i != N)
         {
            for (j = L; j <= N; j++)
            {
               for (s=0.0,k = L; k <= M; k++) s += a[k][i] * a[k][j];
               f = (s / a[i][i]) * g;
               for (k = i; k <= M; k++) a[k][j] += f * a[k][i];
            }
         }
         for (j = i; j <= M; j++) a[j][i] *= g;
      }
      else
      {
         for (j = i; j <= M; j++) a[j][i] = 0.0;
      }
      ++a[i][i];
   }

   //Diagonalization of the bidiagonal form.
   for (k = N; k >= 1; k--)
   {
      for (its = 1; its <= 60; its++)
      {
         flag = 1;
         for (L = k; L >= 1; L--)
         {
            nm = L - 1;
            if ((fabs(rv1[L]) + anorm) == anorm)
            {
               flag = 0;
               break;
            }
            if ((fabs(W[nm]) + anorm) == anorm) break;
         }
         if (flag)
         {
            s = 1.0;
            for (i = L; i <= k; i++)
            {
               f = s * rv1[i];
               if ((fabs(f) + anorm) != anorm)
               {
                  g = W[i];
                  H = sqrt((f * f) + (g * g));
                  W[i] = H;
                  H = 1.0 / H;
                  C = (g * H);
                  s = (-f * H);
                  for (j = 1; j <= M; j++)
                  {
                     y = a[j][nm];
                     z = a[j][i];
                     a[j][nm] = (y * C) + (z * s);
                     a[j][i] = (z * C) - (y * s);
                  }
               }
            }
         }
         z = W[k];
         if (L == k)
         {
            if (z < 0.0)
            {
               W[k] = -z;
               for (j = 1; j <= N; j++) v[j][k] = (-v[j][k]);
            }
            break;
         }
         if (its == 60)
         {
            Application->MessageBox ("no convergence in 60 SVDCMP iterations","PROBLEM!",MB_OK);
            IER = 2;
            return(IER);
         }
         X = W[L];
         nm = k - 1;
         y = W[nm];
         g = rv1[nm];
         H = rv1[k];
         f = ((y - z) * (y + z) + (g - H) * (g + H)) / (2.0 * H * y);
         g = sqrt((f * f) + 1.0);
         f = ((X - z) * (X + z) + H * ((y / (f + sign(g, f))) - H)) / X;

         // Next QR transformation
         C = 1.0;
         s = 1.0;
         for (j = L; j <= nm; j++)
         {
            i = j + 1;
            g = rv1[i];
            y = W[i];
            H = s * g;
            g = C * g;
            z = sqrt((f * f) + (H * H));
            rv1[j] = z;
            C = f / z;
            s = H / z;
            f = (X * C) + (g * s);
            g = (g * C) -(X * s);
            H = y * s;
            y = y * C;
            for (jj = 1; jj <= N; jj++)
            {
               X = v[jj][j];
               z = v[jj][i];
               v[jj][j] = (X * C) + (z * s);
               v[jj][i] = (z * C) -(X * s);
            }
            z = sqrt((f * f) + (H * H));
            W[j] = z;
            if (z)
            {
               z = 1.0 / z;
               C = f * z;
               s = H * z;
            }
            f = (C * g) + (s * y);
            X = (C * y) - (s * g);
            for (jj = 1; jj <= M; jj++)
            {
               y = a[jj][j];
               z = a[jj][i];
               a[jj][j] = (y * C) + (z * s);
               a[jj][i] = (z * C) - (y * s);
            }
         }
         rv1[L] = 0.0;
         rv1[k] = f;
         W[k] = X;
      }
   }
   // end of decomposition
   // Now, construct the inverse of A as A = V * diag(1/w(j)) * U transpose
     for (i = 1; i <= N; i++)
     {
         for (j = 1; j <= N; j++)
         {
              if (W[j] < 0.00000001) vtimesw[i][j] = 0.0;
              else vtimesw[i][j] = v[i][j] * (1.0 / W[j]);
         }
     }
     for (i = 1; i <= M; i++)
     {
         for (j = 1; j <= N; j++)
         {
             ainverse[i][j] = 0.0;
             for (k = 1; k <= M; k++)
                   ainverse[i][j] = ainverse[i][j] + vtimesw[i][k] * a[j][k];
         }
      }
     delete[] rv1;
     for (i = 0; i < N+1; i++) delete[] vtimesw[i];
     delete[] vtimesw;
     return(IER);
}
//-------------------------------------------------------------------

int SVDinverse(double ** a, int N)
{
     // a shorter version of the matinv routine that ignores v, w, and vtimes w
     // matrices in the singular value decompensation inverse procedure
     double **v, *w, **vtimesw, **ainverse, **amat;
     int IER = 0;

     // allocate heap space
     w = new double[N+1];
     GetDblMatMem(v,N+1,N+1);
     GetDblMatMem(vtimesw,N+1,N+1);
     GetDblMatMem(ainverse,N+1,N+1);
     GetDblMatMem(amat,N+1,N+1);

     // copy a to amat up 1 subscript
     for (int i=0; i < N; i++)
         for (int j=0; j < N; j++) amat[i+1][j+1] = a[i][j];

     IER = matinv(amat, N, ainverse, v, w);

     // return the results in a
     for (int i = 0; i < N; i++)
         for (int j = 0; j < N; j++) a[i][j] = ainverse[i+1][j+1];

     // clean up the heap
     ClearDblMatMem(ainverse,N+1);
     ClearDblMatMem(vtimesw,N+1);
     ClearDblMatMem(v,N+1);
     ClearDblMatMem(amat,N+1);
     delete[] w;
     return(IER);
}
//-------------------------------------------------------------------

void nonsymroots(double **a, int nv, int &nf, double c,double **v,double *e, double *x,\
                      double &t, double &ev)
{
/* roots and vectors of a non symetric matrix.  a is square matrix entered
  and is destroyed in process.  nv is number of variables (rows and columns )
  of a.  nf is the number of factors to be extracted - is output as the number
  which exceeded c, the minimum eigenvalue to be extracted.  v is the output
  matrix of column vectors of loadings.  e is the output vector of roots.  x
  is the percentages of trace for factors. t is the trace of the matrix and
  ev is the percent of trace extracted
*/


   double *y = NULL;
   double *z = NULL;
   double ek;
   double e2 = 0.0;
   double d;
   int i, j, k, m;

   try
   {
     y = new double[nv];
     z = new double[nv];
   }
   catch (...)
   {
	Application->MessageBox("Out of Memory","ERROR!",MB_OK);
      exit (-1);
   }

     t = 0.0;
     for (i = 0; i < nv; i++) t += a[i][i];
     for (k = 0; k < nf; k++)
     {
          for (i = 0; i < nv; i++)
          {
               x[i] = 1.0;
               y[i] = 1.0;
          }
          e[k] = 1.0;
          ek = 1.0;
          for (m = 0; m < 100; m++)
          {
               for (i = 0; i < nv; i++)
               {
                    v[i][k] = x[i] / e[k];
                    z[i] = y[i] / ek;
               }
               for (i = 0; i < nv; i++)
               {
                    x[i] = 0.0;
                    for (j = 0; j < nv; j++) x[i] = x[i] + a[i][j] * v[j][k];
                    y[i] = 0.0;
                    for (j = 0; j < nv; j++) y[i] = y[i] + a[j][i] * z[j];
               }
               e2 = 0.0;
               for (j = 0; j < nv; j++) e2 = e2 + x[j] * v[j][k];
               e[k] = sqrt(fabs(e2));
               ek = 0.0;
               for (j = 0; j < nv; j++) ek = ek + y[j] * z[j];
               ek = sqrt(fabs(ek));
          }
          if (e2 >= (c * c))
          {
               d = 0.0;
               for (j = 0; j < nv; j++) d = d + v[j][k] * z[j];
               d = e[k] / d;
               for (i = 0; i < nv; i++)
                   for (j = 0; j < nv; j++)
                       a[i][j] = a[i][j] - v[i][k] * z[j] * d;
          }
          else
          {
               nf = k - 1;
               goto endit;
          }
     }
     endit:
     for (i = 0; i < nf; i++) x[i] = e[i] / t * 100.0;
     ev = 0.0;
     for (i = 0; i < nf; i++) ev = ev + x[i];
     delete[] z;
     delete[] y;
} // end of procedure nonsymroots

//--------------------------------------------------------------------------

double Partial(double **Rmat, int Candidate, int Size, int N,
               double &Prob, double &F, double &df1, double &df2)
{
    // Rmat is a correlation matrix with the dependent variable last and
    // a row and column representing a candidate variable for which the
    // partial correlation is desired.  The program obtains the
    // partial correlation of the candidate variable with the dependent variable
    // after partialing out the other independent variables.
    // Size is the size of the matrix, N is the number of cases on
    // which the correlations are based and Prob is returned as the
    // probability of the partical correlation (which is the same as
    // the semipartial r or beta.)

    if (Size < 3) return (0.0); // must be 3 or larger
    double **InverseMat, **TempMat, **v;
    double *W;
    double R2P, R2, P;

    try  {
        W = new double[Size+1];
        v = new double *[Size+1];
        for (int i = 0; i < Size+1; i++) v[i] = new double[Size+1];
        InverseMat = new double *[Size+1];
        for (int i = 0; i < Size+1; i++) InverseMat[i] = new double[Size+1];
        TempMat = new double *[Size+1];
        for (int i = 0; i < Size+1; i++) TempMat[i] = new double[Size+1];
    }
    catch (...)
    {
        Application->MessageBox("Memory allocation error.","ERROR!",MB_OK);
        return (0);
    }

    // Get the multiple correlation of the dependent variable with all but
    // the candidate variable
    int L = 1;
    int M;
    for (int i = 0; i < Size; i++)
    {
        if (i != Candidate)
        {
            M = 1;
            for (int j = 0; j < Size; j++)
            {
                if (j != Candidate)
                {
                    TempMat[L][M] = Rmat[i][j];
                    M++;
                }
            }
            L++;
        }
    }
    matinv(TempMat,Size-1,InverseMat,v,W);
    R2P = 1.0 - (1.0 / InverseMat[Size-1][Size-1]);

    // Get the multiple correlation of the first variable with all
    // remaining variables
    for (int i = 0; i < Size; i++)
        for (int j = 0; j < Size; j++)
            TempMat[i+1][j+1] = Rmat[i][j];
    matinv(TempMat,Size,InverseMat,v,W);
    R2 = 1.0 - (1.0 / InverseMat[Size][Size]);

    P = sqrt((R2 - R2P) / (1.0 - R2P));
    df1 = 1.0;
    df2 = double(N - Size);
    F = ((R2 - R2P) * df2) / (1.0 - R2);
    Prob = ftest(df1,df2,F);

    // Clean up the heap
    for (int i = 0; i < Size+1; i++) delete[] TempMat[i];
    delete[] TempMat;
    for (int i = 0; i < Size+1; i++) delete[] InverseMat[i];
    delete[] InverseMat;
    for (int i = 0; i < Size+1; i++) delete[] v[i];
    delete[] v;
    delete[] W;

    return (P);
}
//---------------------------------------------------------------------------

void SaveSqrMat(double **Matrix, int Nvars, int NCases, AnsiString *RowLabels,
                double *Means, double *StdDevs)
{
      double value;
      AnsiString response = InputBox("SAVE MATRIX","Save correlation matrix in:","RMatrix.MAT");
      if (response != "")
      {
         FILE *outfile;
         char FileName[121];
         char cellstring[21];
         strcpy(FileName,response.c_str());
         outfile = fopen(FileName,"wb");
         fwrite(&Nvars,sizeof(Nvars),1,outfile);
         fwrite(&NCases,sizeof(NCases),1,outfile);
         // write grid values
         for (int i = 0; i < Nvars; i++)
         {
            for (int j = 0; j < Nvars; j++)
            {
                value = Matrix[i][j];
                fwrite(&value,sizeof(value),1,outfile);
            }
         }
         // write means
         for (int i = 0; i < Nvars; i++)
         {
             value = Means[i];
             fwrite(&value,sizeof(value),1,outfile);
         }
         // write standard deviations
         for (int i = 0; i < Nvars; i++)
         {
             value = StdDevs[i];
             fwrite(&value,sizeof(value),1,outfile);
         }
         // write row labels
         for (int i = 0; i < Nvars; i++)
         {
            strcpy(cellstring,RowLabels[i].c_str());
            fwrite(&cellstring,sizeof(cellstring),1,outfile);
         }
         // write column labels
         for (int j = 0; j < Nvars; j++)
         {
            strcpy(cellstring,RowLabels[j].c_str());
            fwrite(&cellstring,sizeof(cellstring),1,outfile);
         }
         fclose(outfile);
      }
}
//--------------------------------------------------------------------------

void OpenSqrMat(char *FileName, double **Matrix, int Nvars, int NCases, AnsiString *RowLabels,
					 double *Means, double *StdDevs)
{
      double value;
      FILE *outfile;
      char cellstring[21];
      outfile = fopen(FileName,"rb");
      fread(&Nvars,sizeof(Nvars),1,outfile);
      fread(&NCases,sizeof(NCases),1,outfile);
      // read grid values
      for (int i = 0; i < Nvars; i++)
      {
            for (int j = 0; j < Nvars; j++)
            {
                fread(&value,sizeof(value),1,outfile);
                Matrix[i][j] = value;
            }
      }
      // read means
      for (int i = 0; i < Nvars; i++)
      {
             fread(&value,sizeof(value),1,outfile);
             Means[i] = value;
      }
      // read standard deviations
      for (int i = 0; i < Nvars; i++)
      {
             fread(&value,sizeof(value),1,outfile);
             StdDevs[i] = value;
      }
      // read row labels
      for (int i = 0; i < Nvars; i++)
      {
            fread(&cellstring,sizeof(cellstring),1,outfile);
            RowLabels[i] = cellstring;
      }
      // read column labels
      for (int j = 0; j < Nvars; j++)
      {
            fread(&cellstring,sizeof(cellstring),1,outfile);
            RowLabels[j] = cellstring;
      }
      fclose(outfile);
}
//--------------------------------------------------------------------------

void Predict(int *ColNoSelected, int *IndepIndex, int NoVars, double **IndepInverse,
             double *Means, double *StdDevs,double *BetaWeights, double *BWeights,
             double constant, double StdErrEst,  int NoIndepVars)
{
   // routine obtains predicted raw and standardized scores and their
   // residuals.  It is assumed that the dependent variable is last in the
   // list of variable column pointers stored in the ColNoSelected vector.

   int col, i, j, k, Index, IndexX, IndexY;
   double predicted, zpredicted, z1, z2, resid, Term1, Term2;
   double StdErrPredict, t95, Hi95, Low95;
   char astring[121];

   // Get the z predicted score and its residual
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Pred.z";
   NewVar(col,true);
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "z Resid.";
   NewVar(col,true);
   MainForm->Grid->ColCount += 2;
   for (i = 1; i <= NoCases; i++)
   {
       zpredicted = 0.0;
       int y = ColNoSelected[NoVars-1];
       for (j = 0; j < NoIndepVars; j++)
       {
           k = IndepIndex[j]-1;
           int m = ColNoSelected[k];
           z1 = (atof(MainForm->Grid->Cells[m][i].c_str()) -
                               Means[k]) / StdDevs[k];
           zpredicted = zpredicted + (z1 * BetaWeights[j]);
       }
       sprintf(astring,"%8.4f",zpredicted);
       MainForm->Grid->Cells[col-1][i] = astring;
       Index = ColNoSelected[NoVars-1];
       z2 = atof(MainForm->Grid->Cells[Index][i].c_str());
       z2 = (z2 - Means[NoVars-1]) / StdDevs[NoVars-1]; // z score
       sprintf(astring,"%8.4f",z2 - zpredicted);  // z residual
       MainForm->Grid->Cells[col][i] = astring;
   }

   // Get raw predicted and residuals
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Pred.Raw";
   NewVar(col,true);
   // calculate raw predicted scores and store in grid at col
   for (i = 1; i <= NoCases; i++)
   {
        predicted = 0.0;
       for (j = 0; j < NoIndepVars; j++)
       {
           k = IndepIndex[j]-1;
           int col = ColNoSelected[k];
           double raw = atof(MainForm->Grid->Cells[col][i].c_str());
           double B = BetaWeights[j] * StdDevs[NoVars-1] / StdDevs[k];
           predicted = predicted + (raw * B);
       }
       predicted = predicted + constant;
       sprintf(astring,"%8.3f",predicted);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // Calculate residuals of predicted raw scores }
   col = NoVariables +1;
   MainForm->Grid->Cells[col][0] = "Raw Resid.";
   NewVar(col,true);
   for (i = 1; i <= NoCases; i++)
   {
       Index = ColNoSelected[NoVars-1];
//       resid = atof(MainForm->Grid->Cells[col-1][i].c_str()) -
//                           atof(MainForm->Grid->Cells[Index][i].c_str());
       resid = atof(MainForm->Grid->Cells[Index][i].c_str()) -
               atof(MainForm->Grid->Cells[col-1][i].c_str());
       sprintf(astring,"%8.3f",resid);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // Calculate Confidence Interval for raw predicted score
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "StdErrPred";
   NewVar(col,true);
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Low 95%";
   NewVar(col,true);
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Top 95%";
   NewVar(col,true);
   for (i = 1; i <= NoCases; i++)
   {
       // get term1 of the std. err. prediction
       Term1 = 0.0;
       for (j = 1; j <= NoIndepVars; j++)
       {
           col = ColNoSelected[j-1];
           z1 = atof(MainForm->Grid->Cells[col][i].c_str());
           z1 = (z1 - Means[j-1]) / StdDevs[j-1];
           z1 = (z1 * z1) * IndepInverse[j-1][j-1];
           Term1 = Term1 + z1;
       }
       // get term2 of the std err. of prediction
       Term2 = 0.0;
       for (j = 1; j <= NoIndepVars - 1; j++)
       {
           for (k = j + 1; j <= NoIndepVars; j++)
           {
               col = ColNoSelected[j-1];
               z1 = atof(MainForm->Grid->Cells[col][i].c_str());
               col = ColNoSelected[k-1];
               z2 = atof(MainForm->Grid->Cells[col][i].c_str());
               z1 = (z1 - Means[j-1]) / StdDevs[j-1];
               z2 = (z2 - Means[k-1]) / StdDevs[k-1];
               Term2 = Term2 + IndepInverse[j-1][k-1] * z1 * z2;
           }
       }
       Term2 = 2.0 * Term2;
       StdErrPredict = sqrt(NoCases + 1 + Term1 + Term2);
       StdErrPredict = (StdErrEst / sqrt(NoCases)) * StdErrPredict;
       t95 = inverset(0.975,NoCases-NoIndepVars-1);
       Low95 = atof(MainForm->Grid->Cells[NoVars+4][i].c_str());
       Hi95 = Low95;
       Low95 = Low95 - (t95 * StdErrPredict);
       Hi95 = Hi95 + (t95 * StdErrPredict);
       sprintf(astring,"%8.3f",Hi95);
       MainForm->Grid->Cells[NoVariables][i] = astring;
       sprintf(astring,"%8.3f",Low95);
       MainForm->Grid->Cells[NoVariables-1][i] = astring;
       sprintf(astring,"%8.3f",StdErrPredict);
       MainForm->Grid->Cells[NoVariables-2][i] = astring;
   } // next case
}
//--------------------------------------------------------------------------

void MReg2(int NCases, int NoVars, int &NoIndepVars, int *IndepIndex,
           double **corrs, double **IndepCorrs, AnsiString *RowLabels,
           double &R2, double *BetaWeights, double *Means, double *Variances,
           int &errorcode, double &StdErrEst, double &constant,
           double probout, bool Printit, bool TestOut, bool PrintInv)
{
/*
  The following routine obtains multiple regression results for a
  correlation matrix consisting of 1 to NoVars.  The last variable
  represents the dependent variable.  The number of independent
  variables is passed as NoIndepVars.  The inverse matrix of independent
  variables may be obtained by the calling program using the variable
  IndepCorrs.  The user may request printing of the inverse using the
  boolean variable Printit.
*/

     int i, j, k, l, outcount, IndexX, IndexY;
     AnsiString *IndRowLabels, *IndColLabels;
     double *XYCorrs;
     double df1, df2, df3, SSt, SSres, SSreg, VarEst, F, FprobF;
     AnsiString  valstring, title, deplabel;
     char outline[121];
     double sum, B, Beta, SSx, StdErrB, AdjR2, VIF, TOL;
     int *varsout;

     IndRowLabels = new AnsiString[NoVars];
     IndColLabels = new AnsiString[NoVars];
     XYCorrs = new double[NoVars];
     varsout = new int[NoVars];

     errorcode = 0;
     outcount = 0;
     VIF = 0.0;
     deplabel = RowLabels[NoVars-1];
     for (i = 0; i < NoIndepVars; i++)
     {
          IndexX = IndepIndex[i];
          for (j = 0; j < NoIndepVars; j++)
          {
               IndexY = IndepIndex[j];
               IndepCorrs[i][j] = corrs[IndexX-1][IndexY-1];
          }
     }
     for (i = 0; i < NoIndepVars; i++)
     {
          IndRowLabels[i] = RowLabels[IndepIndex[i]-1];
          IndColLabels[i] = RowLabels[IndepIndex[i]-1];
          XYCorrs[i] = corrs[IndepIndex[i]-1][NoVars-1];
     }
     SVDinverse(IndepCorrs,NoIndepVars);
     title = "Inverse of independent variables matrix";
     if (PrintInv == true)
        ArrayPrint(IndepCorrs, NoIndepVars, NoIndepVars, "VARIABLES",
           IndRowLabels, IndColLabels, "Inverse of independent variables matrix");
     // Get product of inverse matrix times vector of correlations
     //   between independent and dependent variables
     R2 = 0.0;
     for (i = 0; i < NoIndepVars; i++)
     {
         BetaWeights[i] = 0.0;
         for (j = 0; j < NoIndepVars; j++)
              BetaWeights[i] = BetaWeights[i] + IndepCorrs[i][j] * XYCorrs[j];
         R2 = R2 + BetaWeights[i] * XYCorrs[i];
     }
     df1 = NoIndepVars;
     df2 = NCases - NoIndepVars - 1;
     df3 = NCases - 1;
     SSt = (double)(NCases-1) * Variances[NoVars-1];
     SSres = SSt * (1.0 - R2);
     SSreg = SSt - SSres;
     VarEst = SSres / df2;
     if (VarEst > 0.0)  StdErrEst = sqrt(VarEst);
     else
     {
         ShowMessage("ERROR! Error in computing variance estimate.");
         StdErrEst = 0.0;
     }
     if ( (df1 <= 0) || (df2 <= 0) ) goto cleanup;
     if ((R2 < 1.0) && (df2 > 0.0) && (df1 > 0.0))  F = (R2 / df1) / ((1.0-R2)/ df2);
     else F = 0.0;
     FprobF = ftest(df1,df2,F);
     if (Printit)
     {
        FrmOutPut->RichOutPut->Lines->Add("SOURCE    DF        SS      MS        F        Prob.>F");
        sprintf(outline,"Regression %3.0f %9.3f %9.3f %9.3f %9.3f",df1,SSreg,SSreg/df1,F,FprobF);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Residual   %3.0f %9.3f %9.3f",df2,SSres,SSres/df2);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Total      %3.0f %9.3f",df3,SSt);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
     }
     AdjR2 = 1.0 - (1.0 - R2) * (double)(NCases - 1) / df2;
     if (Printit == true)
     {
          FrmOutPut->RichOutPut->Lines->Add("Dependent Variable: " + deplabel);
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"%8s%10s%10s%12s%5s%5s","R","R2","F","Prob.>F","DF1","DF2");
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"%8.3f%10.3f%10.3f%10.3f%5.0f%5.0f",
                       		sqrt(R2),R2,F,FprobF,df1,df2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Adjusted R Squared = %5.3f",AdjR2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Std. Error of Estimate = %10.3f",StdErrEst);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("Variable       Beta      B         Std.Error t         Prob.>t   VIF       TOL");
     }
     df1 = 1.0;
     df2 = NCases - NoIndepVars - 1;
     sum = 0.0;
     for (i = 0; i < NoIndepVars; i++)
     {
         Beta = BetaWeights[i];
         B = Beta * sqrt(Variances[NoVars-1]) / sqrt(Variances[IndepIndex[i]-1]);
         sum  = sum + B * Means[IndepIndex[i]-1];
         SSx = (NCases-1) * Variances[IndepIndex[i]-1];
         if ((IndepCorrs[i][i] > 0.0) && (VarEst > 0.0))
         {
            StdErrB = sqrt(VarEst / (SSx * (1.0 / IndepCorrs[i][i])));
            F = B / StdErrB;
            FprobF = ftest(df1,df2,F*F);
            VIF = IndepCorrs[i][i];
            TOL = 1.0 / VIF;
         }
         else
         {
              ShowMessage("ERROR! Error in estimating std.err. of a B");
              StdErrB = 0.0;
              F = 0.0;
              FprobF = 0.0;
         }
         if (Printit == true)
         {
              sprintf(outline,"%10s",IndRowLabels[i]);
              valstring = outline;
              sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f%10.3f",
                      valstring.c_str(), Beta ,B, StdErrB, F, FprobF, VIF, TOL);
              if (FprobF > probout)  strcat(outline," Exceeds limit - to be removed.");
              FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (FprobF > probout)
         {
              outcount = outcount + 1;
              varsout[outcount-1] = IndepIndex[i];
         }
     }
     if (Printit == true)  FrmOutPut->RichOutPut->Lines->Add("");
     // Get constant
     constant = Means[NoVars-1] - sum;
     if (Printit == true)
     {
          sprintf(outline,"Constant = %10.3f",constant);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     // Now remove any variables that exceed tolerance
     if ((outcount > 0) && (TestOut == true))
     {
          for (i = 0; i < outcount; i++)
          {
               k = varsout[i]; // variable to eliminate
               for (j = 0; j < NoIndepVars; j++)
               {
                    if (IndepIndex[j] == k)  //eliminate this one
                    {
                         for (l = j; j < NoIndepVars-1; j++)
                             IndepIndex[l] = IndepIndex[l+1];
                    }
               }
          }
          NoIndepVars = NoIndepVars - outcount;
          errorcode = outcount;
     }
cleanup:
     delete[] varsout;
     delete[] XYCorrs;
     delete[] IndColLabels;
     delete[] IndRowLabels;
}
//-------------------------------------------------------------------------

void MatOffset(double **MatA, double **MatB, int matsize)
{ // Matrix B returned has values offset by 1 row and column from Matrix A
  // Used for routines such as matinv which starts matrix operations at 1, not 0
     for (int i=0; i<matsize; i++)
         for (int j=0; j < matsize; j++)
             MatB[i+1][j+1] = MatA[i][j];
}

//--------------------------------------------------------------------------
void MatOnset(double **MatA, double **MatB, int matsize)
{  //Matrix A returned is a copy of Matrix B but starts at 0 instead of 1
   // in the rows and columns.  Use to un-offset inverse matrices returned from
   // matinv
     for (int i=0; i < matsize; i++)
         for (int j = 0; j < matsize; j++)
             MatA[i][j] = MatB[i+1][j+1];
}

//-------------------------------------------------------------------------

int SEVS(int nv, int nf, double C,double **r, double **v, double *e, double *p, int nd)
{
     // extracts roots and denormal vectors from a symetric matrix. Veldman, 1967, page 209
     double t, ee, ev, sum;
     int i, j, k, M;

     t = 0.0;
     for (i = 0; i < nv; i++) t = t + r[i][i];
     for (k = 0; k < nf; k++) // compute roots in e(k) and vector in v (.k)
     {
          for (i = 0; i < nv; i++) p[i] = 1.0;
          e[k] = 1.0;
          for (M = 0; M < 100; M++)
          {
             for (i = 0; i < nv; i++) v[i][k] = p[i] / e[k];
             for (i = 0; i < nv; i++)
             {
                 sum = 0.0;
                 for (j = 0; j < nv; j++)
                 {
                     sum += r[i][j] * v[j][k];
                 }
                 p[i] = sum;
             }
             ee = 0.0;
             for (j = 0; j < nv; j++) ee = ee + p[j] * v[j][k];
             e[k] = sqrt(fabs(ee));
          }
          if (ee < (C * C)) goto label1;
          for (i = 0; i < nv; i++)
          {
                for (j = 0; j < nv; j++) r[i][j] = r[i][j] - (v[i][k] * v[j][k]);
          }
     }
     goto label2;
label1:
     nf = k - 1;
label2:
     for (i = 0; i < nf; i++) p[i] = e[i] / t * 100.0;
     ev = 0.0;
     for (i = 0; i < nf; i++) ev = ev + p[i];
     //outform.list1.AddItem "Trace = " & fmtstring(t, 6, 3) & " " & fmtstring(ev, 6, 3) & " Pct. of trace extracted by " & fmtstring(nf, 3, 0) & " roots."
     //lineno = lineno + 1
     return nf;
} // end of SEVS procedure

//---------------------------------------------------------------------------------------------

void SymMatRoots(double **A, int M, double *E, double **V)
{
     int L, IT, j, k;
     double Test, sum1, sum2;
     double *X, *Y, *Z;

//  Adapted from: "Multivariate Data Analysis" by William W. Cooley and Paul
//  R. Lohnes, 1971, page 121
     X = new double[M];
     Y = new double[M];
     Z = new double[M];
     sum2 = 0.0;
     L = 0;
     Test = 0.00000001;
one:
     IT = 0;
     for (j = 0; j < M; j++) Y[j] = 1.0;
three:
     IT = IT + 1;
     for (j = 0; j < M; j++)
     {
          X[j] = 0.0;
          for (k = 0; k < M; k++)
          {
          	X[j] = X[j] + (A[j][k] * Y[k]);
          }
     }
     E[L] = X[0];
     sum1 = 0.0;
     for (j = 0; j < M; j++)
     {
          V[j][L] = X[j] / X[0];
          sum1 = sum1 + fabs(Y[j] - V[j][L]);
          Y[j] = V[j][L];
     }
     if ((IT - 10) != 0) goto nine;
     if ((sum2 - sum1) > 0) goto nine;
     else
     {
          ShowMessage("Root not converging. Exiting.");
          delete[] Z;
          delete[] Y;
          delete[] X;
          return;
     }
nine:
     sum2 = sum1;
     if ((sum1 - Test) > 0) goto three;
     sum1 = 0.0;
     for (j = 0; j < M; j++) sum1 = sum1 + (V[j][L] * V[j][L]);
     sum1 = sqrt(sum1);
     for (j = 0; j < M; j++) V[j][L] = V[j][L] / sum1;
     for (j = 0; j < M; j++)
         for (k = 0; k < M; k++)
             A[j][k] = A[j][k] - (V[j][L] * V[k][L] * E[L]);
     if (((M-1)-L) <= 0) goto fifteen;
     L = L + 1;
     goto one;
fifteen:
     delete[] Z;
     delete[] Y;
     delete[] X;
}
//-------------------------------------------------------------------

void Roots(double **RMat, int NITEMS, double *EIGENVAL, double **EIGENVEC)
{
    int i, j, L, IER, size, size2, NSUBS;
    double *EVAL, *DCORR, *PERVAR, *ICL, *CU;
    double **COMP, **EVEC;
    AnsiString response;

    size = ((NITEMS * (NITEMS - 1)) / 2) + NITEMS + 1;
    size2 = (NITEMS + 1) * (NITEMS + 1);
    DCORR = new double[size];
    EVAL = new double[size];
    PERVAR = new double[size];
    ICL = new double[size];
    CU = new double[size];
    GetDblMatMem(COMP,size2,size2);
    GetDblMatMem(EVEC,size2,size2);
    // Move values up one subscript in array since the roots routine
    // counts from 1, not zero. Store only lower half matrix
    L = 1;
    response = InputBox("Sample Size","No. of cases :","1000");
    NSUBS = StrToInt(response); // number of cases
    for (i = 0; i < NITEMS; i++)
    {
        for (j = 0; j <= i; j++)
        {
            DCORR[L] = RMat[i][j];
            L = L + 1;
        }
    }
    DCORR[0] = 0.0;

    // Get the iegenvalues and vectors of the correlation matrix.
    // EVAL holds the values and EVEC holds the vectors
    ICL[1] = NSUBS;
    OPRINC(DCORR,NITEMS,NITEMS,EVAL,EVEC,COMP,PERVAR,ICL,CU,IER);
    for (i = 1; i <= NITEMS; i++)
    {
         EIGENVAL[i-1] = EVAL[i];
         for (j = 1; j <= NITEMS; j++) EIGENVEC[i-1][j-1] = EVEC[i][j];
    }
    ClearDblMatMem(EVEC,size2);
    ClearDblMatMem(COMP,size2);
    delete[] CU;
    delete[]ICL;
    delete[]PERVAR;
    delete[]DCORR;
    delete[]EVAL;
}
//-------------------------------------------------------------------

void OpenMatrixFile(char FileName[])
{
     FILE *infile;
     int NoRows;
     int NoCols;
     int NoObs;
     double value;
     char cellstring[21];

     infile = fopen(FileName,"rb");
     fread(&NoRows,sizeof(NoRows),1,infile);
     fread(&NoCols,sizeof(NoCols),1,infile);
     fread(&NoObs,sizeof(NoObs),1,infile);
     NoVariables = NoCols;
     MainForm->Grid->RowCount = NoRows+1;
     MainForm->Grid->ColCount = NoCols+1;
     MainForm->NoVarsEdit->Text = NoCols;
     NoCases = NoObs;
     MainForm->NoCasesEdit->Text = NoCases;
     for (int i = 0; i < NoRows; i++)
     {
     		for (int j = 0; j < NoCols; j++)
         {
         	fread(&value,sizeof(value),1,infile);
            MainForm->Grid->Cells[j+1][i+1] = value;
         }
     }
     fclose(infile);
     MainForm->FileNameEdit->Text = FileName;
}
//---------------------------------------------------------------------------

void SaveMatrixFile(char FileName[])
{
     FILE *outfile;
     int NoRows;
     int NoCols;
     int NoObs;
     double value;
     char cellstring[21];
     AnsiString n;

     outfile = fopen(FileName,"wb");
     NoRows = MainForm->Grid->ColCount - 1;
     NoCols = MainForm->Grid->ColCount - 1;
     NoObs = NoCases;
     if (NoCases <= 0)
     {
        n = InputBox("CASES","Number of observations used to create matrix?","100");
        NoObs = atoi(n.c_str());
     }
     fwrite(&NoRows,sizeof(NoRows),1,outfile);
     fwrite(&NoCols,sizeof(NoCols),1,outfile);
     fwrite(&NoObs,sizeof(NoObs),1,outfile);
     // write grid values
     for (int i = 0; i < NoRows; i++)
     {
     		for (int j = 0; j < NoCols; j++)
         {
                value = atof(MainForm->Grid->Cells[j+1][i+1].c_str());
                fwrite(&value,sizeof(value),1,outfile);
         }
     }
     fclose(outfile);
}
//---------------------------------------------------------------------

void svd(double **A, int M, int N, double **U, double **S, double **V)
{
        // Decomposes A = USVT where
        // A is the original input matrix
        // U is the left vectors
        // S is the diagonal matrix of singular values
        // VT is the transpose of the right vectors V

        double **AT, **ATA, **SInverse, **Vectors, **AV, **Work, *roots, *p;
        double c = 0.0;
        int *order;
        int i, j, k, larger;
        bool errorcode, debug;
        AnsiString astring;

        debug = false;
        if (M > N) larger = M;
        if (N > M) larger = N;
        if (N == M) larger = M;
        GetDblMatMem(AT,larger,larger);
        GetDblMatMem(ATA,larger,larger);
        GetDblMatMem(SInverse,larger,larger);
        GetDblMatMem(Vectors,larger,larger);
        GetDblMatMem(AV,larger,larger);
        GetDblVecMem(roots,larger);
        GetIntVecMem(order,larger);
        GetDblMatMem(Work,larger,larger);
        GetDblVecMem(p,larger);

        // Get transpose of A
        for (i = 0; i < M; i++)
                for (j = 0; j < N; j++) AT[j][i] = A[i][j];
        if (debug)
        {
                FrmOutPut->RichOutPut->Lines->Add("A Transpose");
                astring = "";
                for (i = 0; i < N; i++) // rows
                {
                        for (j = 0; j < M; j++) // columns
                                astring = astring + "   " + FloatToStr(AT[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // multiply A transpose times A
        MATAxB(ATA, AT, A, N, M, M, N, errorcode);
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("A Transpose times A");
                for (i = 0; i < N; i++) // rows
                {
                        for (j = 0; j < N; j++)
                                astring = astring + "   " + FloatToStr(ATA[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // get eigenvalues and vectors of ATA
//        Roots(ATA, N, roots, Vectors);
        for (i = 0; i < N; i++)
                for (j = 0; j < N; j++)
                        Work[i][j] = ATA[i][j];
        SEVS(N,N,c,ATA,Vectors,roots,p,N);
        // normalize columns of Vectors
        for (j = 0; j < N; j++) // column
        {
                double L = 0.0;
                for (i = 0; i < N; i++) L = L + sqr(Vectors[i][j]);
                L = sqrt(L);
                for (i = 0; i < N; i++) Vectors[i][j] = Vectors[i][j] / L;
        }
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("Roots of ATA");
                for (i = 0; i < N; i++) // column
                        astring = astring + "   " + FloatToStr(roots[i]);
                FrmOutPut->RichOutPut->Lines->Add(astring);
                FrmOutPut->ShowModal();
        }

        // get order of Roots
        for (i = 0; i < N; i++) order[i] = i;
        for (i = 0; i < N-1; i++)
        {
                for (j = i+1; j < N; j++)
                {
                        if (roots[i] < roots[j]) // swap
                        {
                                double temp = roots[i];
                                roots[i] = roots[j];
                                roots[j] = temp;
                                int tempi = order[i];
                                order[i] = order[j];
                                order[j] = tempi;
                        }
                }
        }

        // create S diagonal matrix with square root of Roots
        for (i = 0; i < N; i++)
        {
                for (j = 0; j < N; j++)
                {
                        if (i != j) S[i][j] = 0.0;
                        else S[i][j] = sqrt(roots[i]);
                }
        }
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("S Matrix");
                for (i = 0; i < N; i++) // rows
                {
                        for (j = 0; j < N; j++) // columns
                                astring = astring + "   " + FloatToStr(S[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // order the corresponding eigenvectors
        for (i = 0; i < N; i++)
        {
                k = order[i];
                for (j = 0; j < N; j++) V[i][j] = Vectors[k][j];
        }
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("Ordered Eigenvectors of ATA");
                for (i = 0; i < N; i++)
                {
                        for (j = 0; j < N; j++)
                                astring = astring + "   " + FloatToStr(V[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // Get S inverse
        for (i = 0; i < N; i++)
        {
                for (j = 0; j < N; j++)
                {
                        if (i != j) SInverse[i][j] = 0.0;
                        else
                        {
                                SInverse[i][j] = 1.0 / S[i][j];
                        }
                }
        }
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("S Inverse");
                for (i = 0; i < N; i++)
                {
                        for (j = 0; j < N; j++)
                                astring = astring + "   " + FloatToStr(SInverse[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }
        // Get U = A x V x SInverse - first, get AV
        MATAxB(AV, A, V, M, N, N, N, errorcode);
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("A Times V");
                for (i = 0; i < M; i++)
                {
                        for (j = 0; j < N; j++)
                                astring = astring + "   " + FloatToStr(AV[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }
        // now get U
        MATAxB(U,AV,SInverse,M,N,N,N,errorcode);
        if (debug)
        {
                astring = "";
                FrmOutPut->RichOutPut->Lines->Add("U Matrix");
                for (i = 0; i < M; i++)
                {
                        for (j = 0; j < N; j++)
                                astring = astring + "   " + FloatToStr(U[i][j]);
                        FrmOutPut->RichOutPut->Lines->Add(astring);
                        astring = "";
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // cleanup
        delete[] p;
        ClearDblMatMem(Work,larger);
        delete[] order;
        delete[] roots;
        ClearDblMatMem(AV,larger);
        ClearDblMatMem(Vectors,larger);
        ClearDblMatMem(SInverse,larger);
        ClearDblMatMem(ATA,larger);
        ClearDblMatMem(AT,larger);
}

//----------------------------------------------------------------------------------------

void InvertMat(double ** matrix, int n)
{
        // Obtain the inverse of a symetric matrix by dividing the adjoint
        // matrix by the determinant of the matrix.  Results returned in
        // place of original matrix.
        double det;
        double **b, **adjoint;
        int i, j;

        GetDblMatMem(b,n,n);
        GetDblMatMem(adjoint,n,n);
        // get the determinant of the matrix
        det = Determ(matrix,n);
        CoFactor(matrix,n,b);
        // transpose the cofactor matrix to get the adjoint matrix
        MATTRN(adjoint,b,n,n);
        // divide the adjoint by the determinant
        for (i = 0; i < n; i++)
        {
                for (j = 0; j < n; j++)
                {
                        adjoint[i][j] = adjoint[i][j] / det;
                        matrix[i][j] = adjoint[i][j];
                }
        }
        ClearDblMatMem(adjoint,n);
        ClearDblMatMem(b,n);
}
//----------------------------------------------------------------------------------------

void CoFactor(double **a,int n,double **b)
{
   // Obtains the cofactor of symetric matrix a and returns in in matrix b

   int i,j,ii,jj,i1,j1;
   double det;
   double **c;

   GetDblMatMem(c,n,n);
   for (j=0;j<n;j++) {
      for (i=0;i<n;i++) {

         /* Form the adjoint a_ij */
         i1 = 0;
         for (ii=0;ii<n;ii++) {
            if (ii == i) continue;
            j1 = 0;
            for (jj=0;jj<n;jj++) {
               if (jj == j) continue;
               c[i1][j1] = a[ii][jj];
               j1++;
            }
            i1++;
         }

         /* Calculate the determinate */
         det = Determ(c,n-1);

         /* Fill in the elements of the cofactor */
         b[i][j] = pow(-1.0,i+j+2.0) * det;
      }
   }
   ClearDblMatMem(c,n);
}

