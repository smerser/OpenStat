//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "DataFuncs.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "stdio.h"
#include "DictionaryUnit.h"
#include "NormalityUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TNormalityForm *NormalityForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TNormalityForm::TNormalityForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNormalityForm::ResetBtnClick(TObject *Sender)
{
     TestVarEdit->Text = "";
     WEdit->Text = "";
     ProbEdit->Text = "";
     ConclusionEdit->Text = "";
     SkewEdit->Text = "";
     KurtosisEdit->Text = "";
     StatEdit->Text = "";
     OutBtn->Visible = false;
     InBtn->Visible = true;
     VarList->Items->Clear();
     for (int i = 1; i <= NoVariables; i++)
          VarList->Items->Add(MainForm->Grid->Cells[i][0]);

}
//---------------------------------------------------------------------------

void __fastcall TNormalityForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);   
}
//---------------------------------------------------------------------------

void __fastcall TNormalityForm::InBtnClick(TObject *Sender)
{
   int i;

   i = VarList->ItemIndex;
   if (i < 0) return;
   TestVarEdit->Text = VarList->Items->Strings[i];
   VarList->Items->Delete(i);
   InBtn->Visible = false;
   OutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TNormalityForm::OutBtnClick(TObject *Sender)
{
     if (TestVarEdit->Text == "") return;
     VarList->Items->Add(TestVarEdit->Text);
     TestVarEdit->Text = "";
     OutBtn->Visible = false;
     InBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TNormalityForm::ComputeBtnClick(TObject *Sender)
{
// computes two tests of normality.  Note - while C language usually starts at
// a subscript of zero for arrays, these functions were converted from FORTRAN
// which subscripts from 1.  Therefore the 0th value is not used.

   double temp, w, pw, skew, kurtosis;
   double mean, variance, stddev, deviation, devsqr, M2, M3, M4;
   int i, j, n, n1, n2, ier;
   AnsiString varlabel, msg;
   int selcol, noselected;
   double *data, *a, *z, *x;
   int *freq;
   double *fval, *jval, *DP;
   double F1, DPP, D, D1, A0, C1, D15, D10, D05, D025, t2;
   bool init;
   char outline[121];
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;
   int *selected;
   
   init = false;
   n = 0;
   selcol = 0;
   for (i = 1; i <= NoVariables; i++)
        if (MainForm->Grid->Cells[i][0] == TestVarEdit->Text)  selcol = i;
   //result = VarTypeChk(selcol,0);
   //if (result == 1) return;
   if (selcol != 0)
   {
        noselected = 1;
        selected = new int[1];
        selected[0] = selcol;
        varlabel = TestVarEdit->Text;
        // place values into the data array
        data = new double[NoCases+1]; // arrays start at 1
        a = new double [NoCases+1];
        freq = new int[NoCases+1];
        z = new double[NoCases+1];
        x = new double[NoCases+1];
        fval = new double[NoCases+1];
        jval = new double[NoCases+1];
        DP = new double[NoCases+1];
        for (i = 1; i <= NoCases; i++)
        {
             if (!ValidRecord(i,selected,noselected)) continue;
             if (! ValidValue(i,selcol))  continue;
             n = n + 1;
             data[n] = StrToFloat(MainForm->Grid->Cells[selcol][i]);
         }
        n1 = n;
        n2 = n / 2;
        // sort into ascending order
        for (i = 1; i <= n - 1; i++)
        {
             for (j = i + 1; j <= n; j++)
             {
                  if (data[i] > data[j])
                  {
                       temp = data[i];
                       data[i] = data[j];
                       data[j] = temp;
                  }
             }
        }
        // call Shapiro-Wilks function
        swilk(init, data, n, n1, n2, a, w, pw, ier);
        if (ier != 0)
        {
             msg = "Error encountered = " + IntToStr(ier);
             ShowMessage(msg);
             delete[] DP;
             delete[] jval;
             delete[] fval;
             delete[] data;
             delete[] a;
             delete[] freq;
             delete[] z;
             delete[] x;
             return;
        }
        sprintf(outline,"%8.4f",w);
        WEdit->Text = outline;

        sprintf(outline,"%8.4f",pw);
        ProbEdit->Text = outline;
        // Now do Lilliefors
        // get unique scores and their frequencies
        n1 = 1;
        i = 1;
        freq[1] = 1;
        x[1] = data[1];
again:  for (j = i + 1;j <= n; j++)
        {
             if (data[j] == x[n1])  freq[n1] = freq[n1] + 1;
        }
        i = i + freq[n1];
        if (i <= n)
        {
             n1 = n1 + 1;
             x[n1] = data[i];
             freq[n1] = 1;
             goto again;
        }
        // now get skew and kurtosis of scores
        mean = 0.0;
        variance = 0.0;
        for (i = 1; i <= n; i++)
        {
             mean = mean + data[i];
             variance = variance + (data[i] * data[i]);
        }
        variance = variance - (mean * mean) / n;
        variance = variance / (n - 1);
        stddev = sqrt(variance);
        mean = mean / n;
        // obtain skew, kurtosis and z scores
        M2 = 0.0;
        M3 = 0.0;
        M4 = 0.0;
        for (i = 1; i <= n; i++)
        {
             deviation = data[i] - mean;
             devsqr = deviation * deviation;
             M2 = M2 + devsqr;
             M3 = M3 + (deviation * devsqr);
             M4 = M4 + (devsqr * devsqr);
             z[i] = (data[i] - mean) / stddev;
        }
        for (i = 1; i <= n1; i++) x[i] = (x[i] - mean) / stddev;
        skew = (n * M3) / ((n - 1) * (n - 2) * stddev * variance);
        kurtosis = (n * (n + 1) * M4) - (3 * M2 * M2 * (n - 1));
        kurtosis = kurtosis /( (n - 1) * (n - 2) * (n - 3) * (variance * variance) );
        sprintf(outline,"%8.3f",skew);
        SkewEdit->Text = outline;
        sprintf(outline,"%8.3f",kurtosis);
        KurtosisEdit->Text = outline;
        // obtain the test statistic
        for (i = 1; i <= n1; i++)
        {
             F1 = Norm(x[i]);
             if (x[i] >= 0)  fval[i] = 1.0 - (F1 / 2.0);
             else fval[i] = F1 / 2.0;
        }
        // cumulative proportions
        jval[1] = (double) freq[1] / (double) n;
        for (i = 2; i <= n1;i++) jval[i] = jval[i-1] + (double) freq[i] / (double) n;
        for (i = 1; i <= n1; i++) DP[i] = fabs(jval[i] - fval[i]);
        // sort DP
        for (i = 1; i <= n1-1;i++)
        {
             for (j = i+1; j <= n1; j++)
             {
                  if (DP[j] < DP[i])
                  {
                       temp = DP[i];
                       DP[i] = DP[j];
                       DP[j] = temp;
                  }
             }
        }
/*
        // output test data
        FrmOutPut->RichOutPut->Lines->Add("freq      jval      DP");
        for (i = 1; i <= n1; i++)
        {
            sprintf(outline,"%8d  %8.2f  %8.2f",freq[i],jval[i],DP[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
*/
        DPP = DP[n1];
        D = DPP;
//        D1 = D;
        sprintf(outline,"%8.3f",D);
        StatEdit->Text = outline;
        A0 = sqrt(n);
        C1 = A0 - 0.01 + (0.85 / A0);
        D15 = 0.775 / C1;
        D10 = 0.819 / C1;
        D05 = 0.895 / C1;
        D025 = 0.995 / C1;
        t2 = D;
        if (t2 > D025)  ConclusionEdit->Text = "Strong evidence against normality.";
        else if ((t2 <= D025) && (t2 > D05)) ConclusionEdit->Text = "Sufficient evidence against normality.";
        else if ((t2 <= D05) && (t2 > D10))  ConclusionEdit->Text = "Suggestive evidence against normality.";
        else if ((t2 <= D10) && (t2 > D15))  ConclusionEdit->Text = "Little evidence against normality.";
        else if (t2 <= D15)  ConclusionEdit->Text = "No evidence against normality.";
        else ConclusionEdit->Text = "Strong evidence against normality.";
   }
   delete[] DP;
   delete[] jval;
   delete[] fval;
   delete[] data;
   delete[] a;
   delete[] freq;
   delete[] z;
   delete[] x;
}
//---------------------------------------------------------------------------

void __fastcall TNormalityForm::PrintBtnClick(TObject *Sender)
{
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("NORMALITY TESTS FOR "+ TestVarEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Shapiro-Wilkes W = " + WEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("Shapiro-Wilkes Prob. = " + ProbEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Skew = " + SkewEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("Kurtosis = " + KurtosisEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("Lilliefors Test Statistic = " + StatEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("Conclusion: " + ConclusionEdit->Text);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

double __fastcall TNormalityForm::Norm(double z)
{
     double p;

     z = fabs(z);
     p = 1.0 + z * (0.04986735 + z * (0.02114101 + z * (0.00327763 +
          z * (0.0000380036 + z * (0.0000488906 + z * 0.000005383)))));
     p = p * p;
     p = p * p;
     p = p * p;
     return (1.0 / (p * p));
}
//-------------------------------------------------------------------

double __fastcall TNormalityForm::CalcNr(double pn)
{
   double z;

   z = ANorm(pn);
   return (z);
}
//-------------------------------------------------------------------

double __fastcall TNormalityForm::ANorm(double p)
{
     double v, dv, z;

     v = 0.5;
     dv = 0.5;
     z = 0.0;
     while (dv > 1.0e-6)
     {
          z = 1.0 / v - 1.0;
          dv = dv / 2.0;
          if (Norm(z) > p)  v = v - dv;
          else v = v + dv;
     }
     return (z);
}
//-------------------------------------------------------------------


