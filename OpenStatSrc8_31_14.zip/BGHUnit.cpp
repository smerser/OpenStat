//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "FrmFDSpecs.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "Math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "GraphUnit.h"
#include "BGHUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
TBGHForm *BGHForm;
//---------------------------------------------------------------------------
__fastcall TBGHForm::TBGHForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     DepVarEdit->Text = "";
     Factor1Edit->Text = "";
     Factor2Edit->Text = "";
     if (ops.format == 0)
     {
        OverAllEdit->Text = "0.05";
     }
     else
     {
        OverAllEdit->Text = "0,05";
      }
     OptionsBox->ItemIndex = 3;
     DepOutBtn->Visible = false;
     Factor1OutBtn->Visible = false;
     Factor2OutBtn->Visible = false;
     DepInBtn->Visible = true;
     Factor1InBtn->Visible = true;
     Factor2InBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::DepInBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              DepVarEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::Factor1InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              Factor1Edit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Factor1OutBtn->Visible = true;
     Factor1InBtn->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::Factor2InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              Factor2Edit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Factor2OutBtn->Visible = true;
     Factor2InBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::Factor1OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Factor1Edit->Text);
     Factor1Edit->Text = "";
     Factor1InBtn->Visible = true;
     Factor1OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::Factor2OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Factor2Edit->Text);
     Factor2Edit->Text = "";
     Factor2InBtn->Visible = true;
     Factor2OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TBGHForm::getlevels(TObject *Sender)
{
     int i, result, anintvalue;
     double dblvalue;
     AnsiString strvalue;

     minf1 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][1])));
     maxf1 = minf1;
     for (i = 2; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //intvalue = anintvalue;
          if (intvalue > maxf1)  maxf1 = intvalue;
          if (intvalue < minf1)  minf1 = intvalue;
     }
     Nf1cells = maxf1 - minf1 + 1;
     if (nofactors > 1)
     {
          minf2 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][1])));
          maxf2 = minf2;
          for (i = 2; i <= NoCases; i++)
          {
               if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
               intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
               //intvalue = anintvalue;
               if (intvalue > maxf2)  maxf2 = intvalue;
               if (intvalue < minf2)  minf2 = intvalue;
          }
          Nf2cells = maxf2 - minf2 + 1;
     }
}
//---------------------------------------------------------------------------

void __fastcall TBGHForm::Calc2Way(TObject *Sender)
{
     int i, j, grpA, grpB;
     int anintvalue;
     int result;
     double dblvalue;
     AnsiString strvalue;
     double Constant, RowsTotCnt, ColsTotCnt, SSCells;

     CompError = false;
     // initialize matrix values
     NoGrpsA = maxf1 - minf1 + 1;
     NoGrpsB = maxf2 - minf2 + 1;
     for (i = 1; i <= NoGrpsA; i++)
     {
          RowSums[i-1] = 0.0;
          RowCount[i-1] = 0.0;
          for (j = 1; j <= NoGrpsB; j++)
          {
               counts[i-1][j-1] = 0.0;
               sums[i-1][j-1] = 0.0;
               vars[i-1][j-1] = 0.0;
          }
     }
     for (i = 1; i <= NoGrpsB; i++)
     {
          ColCount[i-1] = 0.0;
          ColSums[i-1] = 0.0;
     }
     N = 0;
     MeanDep = 0.0;
     SSDep = 0.0;
     SSCells = 0.0;
     RowsTotCnt = 0.0;
     ColsTotCnt = 0.0;
     // get working totals
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          grpA = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpA = anintvalue;
          grpB = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
          //result = GetValue(i, F2Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpB = anintvalue;
          X = StrToFloat(Trim(MainForm->Grid->Cells[DepVarCol][i]));
          //result = GetValue(i, DepVarCol, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //X = dblvalue;
          grpA = grpA - minf1 + 1;
          grpB = grpB - minf2 + 1;
          counts[grpA-1][grpB-1] = counts[grpA-1][grpB-1] + 1;
          sums[grpA-1][grpB-1] = sums[grpA-1][grpB-1] + X;
          vars[grpA-1][grpB-1] = vars[grpA-1][grpB-1] + (X * X);
          RowSums[grpA-1] = RowSums[grpA-1] + X;
          ColSums[grpB-1] = ColSums[grpB-1] + X;
          RowCount[grpA-1] = RowCount[grpA-1] + 1.0;
          ColCount[grpB-1] = ColCount[grpB-1] + 1.0;
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }

     // Calculate results
     for (i = 0; i < NoGrpsA; i++)
     {
          SSF1 = SSF1 + ((RowSums[i] * RowSums[i]) / RowCount[i]);
          RowsTotCnt = RowsTotCnt + RowCount[i];
     }
     for (j = 0; j < NoGrpsB; j++)
     {
          SSF2 = SSF2 + ((ColSums[j] * ColSums[j]) / ColCount[j]);
          ColsTotCnt = ColsTotCnt + ColCount[j];
     }
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
              if (counts[i,j] > 0)
                 SSCells = SSCells + ((sums[i][j] * sums[i][j]) / counts[i][j]);
     }
     if (N > 0)  Constant = (MeanDep * MeanDep) / (double)N;
     else Constant = 0.0;
     SSF1 = SSF1 - Constant;
     SSF2 = SSF2 - Constant;
     SSF1F2 = SSCells - SSF1 - SSF2 - Constant;
     SSErr = SSDep - SSCells;
     SSDep = SSDep - Constant;

     if ((SSF1F2 < 0) || (SSF1 < 0) || (SSF2 < 0))
     {
          ShowMessage("ERROR! A negative SS found. Unbalanced design? Ending analysis.");
          CompError = true;
          return;
     }
     DFTot = N - 1;
     DFF1 = NoGrpsA - 1;
     DFF2 = NoGrpsB - 1;
     DFF1F2 = DFF1 * DFF2;
     DFErr = DFTot - DFF1 - DFF2 - DFF1F2;
     MSF1 = SSF1 / DFF1;
     MSF2 = SSF2 / DFF2;
     MSF1F2 = SSF1F2 / DFF1F2;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     OmegaF1 = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     OmegaF2 = (SSF2 - DFF2 * MSErr) / (SSDep + MSErr);
     OmegaF1F2 = (SSF1F2 - DFF1F2 * MSErr) / (SSDep + MSErr);
     Omega = OmegaF1 + OmegaF2 + OmegaF1F2;
     MeanDep = MeanDep / N;
     // f tests for fixed effects
          FF1 = fabs(MSF1 / MSErr);
          FF2 = fabs(MSF2 / MSErr);
          FF1F2 = fabs(MSF1F2 / MSErr);
          ProbF1 = ftest(DFF1,DFErr,FF1);
          ProbF2 = ftest(DFF2,DFErr,FF2);
          ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
      // f tests if both factors are ranm
     if (ProbF1 > 1.0)  ProbF1 = 1.0;
     if (ProbF2 > 1.0)  ProbF2 = 1.0;
     if (ProbF1F2 > 1.0)  ProbF1F2 = 1.0;

     // Obtain omega squared (proportion of dependent variable explained)
     if (OmegaF1 < 0.0)  OmegaF1 = 0.0;
     if (OmegaF2 < 0.0)  OmegaF2 = 0.0;
     if (OmegaF1F2 < 0.0)  OmegaF1F2 = 0.0;
     //Omega = ( (SSF1 + SSF2 + SSF1F2) - (DFF1 + DFF2 + DFF1F2) * MSErr) / (SSDep + MSErr);
     if (Omega < 0.0)  Omega = 0.0;
}
//---------------------------------------------------------------------------

void __fastcall TBGHForm::TwoWayTable(TObject *Sender)
{
     int i, j, groupsize;
     double MinVar, MaxVar, sumvars, sumDFrecip, XBar, V, S, RowSS, ColSS;
     double sumfreqlogvar, c, bartlett, cochran, hartley, chiprob, H, ProbH;
     char astring[121];

     if (CompError) return;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Two Way Analysis of Variance");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Variable analyzed: %s",DepVarEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Factor A (rows) variable: %s",Factor1Edit->Text.c_str());
     strcat(astring," (Fixed Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor B (columns) variable: %s",Factor2Edit->Text.c_str());
     strcat(astring," (Fixed Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE         D.F.    SS        MS         F      PROB.> F   Omega Sqr.   H    Prob.> H");
     FrmOutPut->RichOutPut->Lines->Add("");
     H = SSF1 / MSDep;
     ProbH = 1.0 - chisquaredprob(H,DFF1);
     sprintf(astring,"Among Rows     %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f     %6.3f     %6.3f",
          DFF1,SSF1,MSF1,FF1,ProbF1,OmegaF1, H, ProbH);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     H = SSF2 / MSDep;
     ProbH = 1.0 - chisquaredprob(H,DFF2);
     sprintf(astring,"Among Columns  %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f     %6.3f     %6.3f",
          DFF2,SSF2,MSF2,FF2,ProbF2,OmegaF2, H, ProbH);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     H = SSF1F2 / MSDep;
     ProbH = 1.0 - chisquaredprob(H,DFF1F2);
     sprintf(astring,"Interaction    %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f     %6.3f     %6.3f",
          DFF1F2,SSF1F2,MSF1F2,FF1F2,ProbF1F2,OmegaF1F2, H, ProbH);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Within Groups  %4.0f  %8.3f  %8.3f",
          DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Total          %4.0f  %8.3f  %8.3f",
          DFTot,SSDep,MSDep);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Omega squared for combined effects = %8.3f",Omega);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Note: Denominator of F ratio is MSErr");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("GROUP Row Col.  N     MEAN   VARIANCE  STD.DEV.");
     groupsize = ceil(counts[0][0]);
     equal_grp = true;
     MaxVar = 0.0;
     MinVar = 1e20;
     sumvars = 0.0;
     sumfreqlogvar = 0.0;
     sumDFrecip = 0.0;

     // Display cell means, variances, standard deviations
     V = 0.0;
     XBar = 0.0;
     S = 0.0;
     for (i = 0;i < NoGrpsA;i++)
     {
          for (j = 0;j < NoGrpsB;j++)
          {
               if (counts[i][j] > 1)
               {
                    XBar = sums[i][j] / counts[i][j];
                    V = vars[i][j] - ( (sums[i][j] * sums[i][j]) / counts[i][j]);
                    V = V / (counts[i][j] - 1.0);
                    S = sqrt(V);
                    sumvars  = sumvars + V;
                    if (V > MaxVar)  MaxVar = V;
                    if (V < MinVar)  MinVar = V;
                    sumDFrecip = sumDFrecip + (1.0 / (counts[i][j] - 1.0));
                    sumfreqlogvar = sumfreqlogvar + ((counts[i][j] - 1.0) * log(V));
                    if (counts[i][j] != groupsize) equal_grp = false;
               }
               sprintf(astring,"Cell %3d %3d  %3.0f  %8.3f  %8.3f  %8.3f",
                   minf1+i,minf2+j,counts[i][j],XBar,V,S);
               FrmOutPut->RichOutPut->Lines->Add(astring);
          }
     }

     //Display Row means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          XBar = RowSums[i] / RowCount[i];
          OrdMeansA[i] = XBar;
          RowSS = 0.0;
          for (j = 0; j < NoGrpsB; j++) RowSS = RowSS + vars[i][j];
          V = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
          V = V / (RowCount[i] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Row  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
               minf1+i,RowCount[i],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          XBar = ColSums[j] / ColCount[j];
          OrdMeansB[j] = XBar;
          ColSS = 0.0;
          for (i = 0; i < NoGrpsA; i++) ColSS = ColSS + vars[i][j];
          if (ColCount[j] > 0) V = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
          if (ColCount[j] > 1) V = V / (ColCount[j] - 1.0);
          if (V > 0.0) S = sqrt(V);
          sprintf(astring,"Col  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
             minf2+j,ColCount[j],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     sprintf(astring,"TOTAL         %3d  %8.3f  %8.3f  %8.3f",
          N,MeanDep,MSDep,sqrt(MSDep));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
     c = 1.0 + (1.0 / (3.0 * NoGrpsA * NoGrpsB - 1.0)) * (sumDFrecip - (1.0 / DFErr));
     bartlett = (2.303 / c) * ((DFErr * log(MSErr)) - sumfreqlogvar);
     chiprob = 1.0 - chisquaredprob(bartlett,ceil(NoGrpsA * NoGrpsB - 1));
     cochran = MaxVar / sumvars;
     hartley = MaxVar / MinVar;
     FrmOutPut->RichOutPut->Lines->Add("TESTS FOR HOMOGENEITY OF VARIANCE");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(astring,"Hartley Fmax test statistic = %10.2f with deg.s freem: %d and %d.",
          hartley, (NoGrpsA*NoGrpsB),(groupsize-1));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Cochran C statistic = %10.2f with deg.s freem: %d and %d.",
          cochran, (NoGrpsA*NoGrpsB), (groupsize - 1));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Bartlett Chi-square statistic = %10.2f with %4d D.F. Prob. larger value = %6.3f",
          bartlett, (NoGrpsA*NoGrpsB - 1), chiprob);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
}
//---------------------------------------------------------------------------

void __fastcall TBGHForm::TwoWayPlot(TObject *Sender)
{
     int i, j;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     if (CompError)  return;
     XValue = new double[Nf1cells+Nf2cells];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          RowSums[i-1] = RowSums[i-1] / RowCount[i-1];
          GraphForm->Ypoints[0][i-1] = RowSums[i-1];
          if (RowSums[i-1] > maxmean)  maxmean = RowSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = Factor1Edit->Text;
     title =  Factor1Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf2cells);
     for (i = 1; i <= Nf2cells; i++)
     {
          ColSums[i-1] = ColSums[i-1] / ColCount[i-1];
          GraphForm->Ypoints[0][i-1] = ColSums[i-1];
          if (ColSums[i-1] > maxmean)  maxmean = ColSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = Factor2Edit->Text;
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor A x B Interaction next
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf2cells);
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          setstring = Factor1Edit->Text + " " + IntToStr(i);
          GraphForm->SetLabels[i] = setstring;
          for (j = 1; j <= Nf2cells;j++)
          {
               XBar = sums[i-1][j-1] / counts[i-1][j-1];
               if (XBar > maxmean)  maxmean = XBar;
               GraphForm->Ypoints[i-1][j-1] = XBar;
          }
     }
     for (j = 1; j <= Nf2cells;j++)
     {
        XValue[j-1] = minf2 + j - 1;
        GraphForm->Xpoints[0][j-1] = XValue[j-1];
     }

     GraphForm->nosets = Nf1cells;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = "Factor A x Factor B";
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     delete[] XValue;
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
}
//---------------------------------------------------------------------------
void __fastcall TBGHForm::OKBtnClick(TObject *Sender)
{
     int result;

     FrmOutPut->RichOutPut->Clear();
     // initialize values
     ColNoSelected = new int[NoVariables];
     DepVarCol = 0;
     F1Col = 0;
     F2Col = 0;
     SSDep = 0.0;
     SSF1 = 0.0;
     SSF2 = 0.0;
     SSF1F2 = 0.0;
     MeanDep = 0.0;
     MeanF1 = 0.0;
     MeanF2 = 0.0;
     Nf1cells = 0;
     Nf2cells = 0;
     N = 0;
     NoSelected = 0;
     minf1 = 0;
     maxf1 = 0;
     minf2 = 0;
     maxf2 = 0;

     //  Get column numbers of dependent variable and factors
     for (int i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == DepVarEdit->Text)
          {
               DepVarCol = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = DepVarCol;
          }
          if (cellstring == Factor1Edit->Text)
          {
               F1Col = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F1Col;
          }
          if (cellstring == Factor2Edit->Text)
          {
               F2Col = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F2Col;
          }
     }
     nofactors = 2;
     OverallAlpha = StrToFloat(OverAllEdit->Text);
     // get min and max of each factor code
     getlevels(this);

     // allocate space
     cellcnts = new double[totcells];  // array of cell counts
     cellvars = new double[totcells];  // arrray of cell sums of squares  variances
     cellsums = new double[totcells];  // array of cell sums  means

     // initialize array values
     for (int i = 1; i <= totcells; i++)
     {
          cellsums[i-1] = 0.0;
          cellvars[i-1] = 0.0;
          cellcnts[i-1] = 0;
     }

     //  analysis
     switch (nofactors)
     {
       case 2 : // two-way anova
       {
            GetDblMatMem(counts,Nf1cells,Nf2cells); // matrix for 2-way containing cell sizes
            GetDblMatMem(sums,Nf1cells,Nf2cells);  // matrix for 2-way containing cell sums
            GetDblMatMem(vars,Nf1cells,Nf2cells);  // matrix for 2-way containing sums of squares
            RowSums = new double[Nf1cells];  // 2 way row sums
            ColSums = new double[Nf2cells];  // 2 way col sums
            RowCount = new double[Nf1cells]; // 2 way row count
            ColCount = new double[Nf2cells]; // 2 way col count
            OrdMeansA = new double[Nf1cells]; // ordered means for factor 1
            OrdMeansB = new double[Nf2cells]; // ordered means for factor 2

            Calc2Way(this);
            if (CompError)  goto nexttwo;
            TwoWayTable(this);
            FrmOutPut->ShowModal();
            if (OptionsBox->ItemIndex >= 0)  TwoWayPlot(this);
nexttwo:    delete[] OrdMeansB;
            delete[] OrdMeansA;
            delete[] ColCount;
            delete[] RowCount;
            delete[] ColSums;
            delete[] RowSums;
            ClearDblMatMem(vars,Nf1cells);
            ClearDblMatMem(sums,Nf1cells);
            ClearDblMatMem(counts,Nf1cells);
       }    break;
     } // end switch
cleanit:
     delete[] cellcnts;
     delete[] cellvars;
     delete[] cellsums;
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------
