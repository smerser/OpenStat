//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "RecodeUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern int NoVariables;
extern int NoCases;
extern struct Options ops;

TFrmRecode *FrmRecode;

//---------------------------------------------------------------------------
__fastcall TFrmRecode::TFrmRecode(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmRecode::FormShow(TObject *Sender)
{
    IntoRadioGrp->ItemIndex = 0;
    OldValEdit->Text = "";
    LowRangeEdit->Text = "";
    HiRangeEdit->Text = "";
    TopRangeEdit->Text = "";
    DownToEdit->Text = "";
    AllButEdit->Text = "";
    NewNameEdit->Text = "";
    NewValueBtn->Checked = true;
    NewValueEdit->Text = "";
    Label2->Visible = false;
    NewNameEdit->Visible = false;
    OldColNo = MainForm->Grid->Col;
    NewColNo = -1;
    newmade = false;
    AllVars = false;
    VarNameEdit->Text = MainForm->Grid->Cells[OldColNo][0];
    OldValEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFrmRecode::IntoRadioGrpClick(TObject *Sender)
{
    if (IntoRadioGrp->ItemIndex == 1)
    {
        Label2->Visible = true;
        NewNameEdit->Visible = true;
        NewNameEdit->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::CancelBtnClick(TObject *Sender)
{
    FrmRecode->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::ApplyBtnClick(TObject *Sender)
{
    AnsiString astring;

    if ((NewColNo != OldColNo+1) && (IntoRadioGrp->ItemIndex == 1))
    {
        if (newmade == false)
        {
             NewColNo = MainForm->Grid->ColCount;
             astring = MainForm->Grid->Cells[OldColNo][0];
             astring = astring + "RECODE";
             MainForm->Grid->Cells[NewColNo][0] = astring;
             NewVar(NewColNo,true);
             newmade = true;
             NewNameEdit->Text = astring;
        }
    }
    if (IntoRadioGrp->ItemIndex == 0) NewColNo = OldColNo;
    if (ValueBtn->Checked) BtnNo = 0;
    if (BlanksBtn->Checked)BtnNo = 1;
    if (RangeBtn->Checked) BtnNo = 2;
    if (LowestToBtn->Checked) BtnNo = 3;
    if (DownToBtn->Checked) BtnNo = 4;
    if (AllButBtn->Checked) BtnNo = 5;
    NoCases = MainForm->Grid->RowCount - 1;
    for (int i = 1; i <= NoCases; i++)
    {
        switch (BtnNo)
        {
            case 0: // look for a value specified in OldValEdit box
            {
                if (Trim(MainForm->Grid->Cells[OldColNo][i]) == Trim(OldValEdit->Text))
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = ops.missval;
                }
            }
            break;
            case 1: // blanks
            {
                if (MainForm->Grid->Cells[OldColNo][i] == "")
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 2: // low and hi range
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XLow = atof(LowRangeEdit->Text.c_str());
                double XHi = atof(HiRangeEdit->Text.c_str());
                if ((X >= XLow) && (X <= XHi))
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 3: // lowest up to specified value
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XHi = atof(TopRangeEdit->Text.c_str());
                if (X < XHi)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 4: // Highest down to specified value
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XLow = atof(DownToEdit->Text.c_str());
                if (X > XLow)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 5: // all but specified value are changed
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double Y = atof(AllButEdit->Text.c_str());
                if (X != Y)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
        } // end switch
    } // next i

}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::AnotherBtnClick(TObject *Sender)
{
    OldValEdit->Text = "";
    NewValueEdit->Text = "";
    NewValueEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::ReturnBtnClick(TObject *Sender)
{
    FrmRecode->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::FormHide(TObject *Sender)
{
//     FormatCells();     
}
//---------------------------------------------------------------------------

void __fastcall TFrmRecode::AllVarBtnClick(TObject *Sender)
{
    AnsiString astring;

  for (int k = 1; k <= NoVariables; k++)
  {
    VarNameEdit->Text = MainForm->Grid->Cells[k][0];
    OldColNo = k;

    if ((NewColNo != OldColNo+1) && (IntoRadioGrp->ItemIndex == 1))
    {
        if (newmade == false)
        {
             NewColNo = MainForm->Grid->ColCount;
             astring = MainForm->Grid->Cells[OldColNo][0];
             astring = astring + "RECODE";
             MainForm->Grid->Cells[NewColNo][0] = astring;
             NewVar(NewColNo,true);
             newmade = true;
             NewNameEdit->Text = astring;
        }
    }
    if (IntoRadioGrp->ItemIndex == 0) NewColNo = OldColNo;
    if (ValueBtn->Checked) BtnNo = 0;
    if (BlanksBtn->Checked)BtnNo = 1;
    if (RangeBtn->Checked) BtnNo = 2;
    if (LowestToBtn->Checked) BtnNo = 3;
    if (DownToBtn->Checked) BtnNo = 4;
    if (AllButBtn->Checked) BtnNo = 5;
    NoCases = MainForm->Grid->RowCount - 1;
    for (int i = 1; i <= NoCases; i++)
    {
        switch (BtnNo)
        {
            case 0: // look for a value specified in OldValEdit box
            {
                if (Trim(MainForm->Grid->Cells[OldColNo][i]) == Trim(OldValEdit->Text))
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = ops.missval;
                }
            }
            break;
            case 1: // blanks
            {
                if (MainForm->Grid->Cells[OldColNo][i] == "")
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 2: // low and hi range
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XLow = atof(LowRangeEdit->Text.c_str());
                double XHi = atof(HiRangeEdit->Text.c_str());
                if ((X >= XLow) && (X <= XHi))
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 3: // lowest up to specified value
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XHi = atof(TopRangeEdit->Text.c_str());
                if (X < XHi)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 4: // Highest down to specified value
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double XLow = atof(DownToEdit->Text.c_str());
                if (X > XLow)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
            case 5: // all but specified value are changed
            {
                double X = atof(MainForm->Grid->Cells[OldColNo][i].c_str());
                double Y = atof(AllButEdit->Text.c_str());
                if (X != Y)
                {
                    if (NewValueBtn->Checked)
                        MainForm->Grid->Cells[NewColNo][i] = NewValueEdit->Text;
                    else MainForm->Grid->Cells[NewColNo][i] = "";
                }
            }
            break;
        } // end switch
    } // next i
  } // next k
}
//---------------------------------------------------------------------------

