//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "stdlib.h"
#include "MemMgrUnit.h"
#include "LinProUnit.h"

#define eps 1.0e-6
#define FREEALL free_ivector(13,1,m);free_ivector(12,1,m);\
    free_ivector(l1,1,n+1);

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern int NoCases;
extern int NoVariables;
extern struct Options ops;

TLinProForm *LinProForm;
//---------------------------------------------------------------------------
__fastcall TLinProForm::TLinProForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLinProForm::ResetBtnClick(TObject *Sender)
{
        NoVarsEdit->Text = "0";
        NoMaxEdit->Text = "";
        NoMinEdit->Text = "";
        NoEqualEdit->Text = "";
        MinMaxGrp->ItemIndex = 0;
        FileNameEdit->Text = "";
        MaxConstraintsGrid->RowCount = 1;
        MaxConstraintsGrid->ColCount = 1;
        MaxConstraintsGrid->Cells[0][0] = "";
        MinConstraintsGrid->RowCount = 1;
        MinConstraintsGrid->ColCount = 1;
        MinConstraintsGrid->Cells[0][0] = "";
        EqualConstraintsGrid->RowCount = 1;
        EqualConstraintsGrid->ColCount = 1;
        EqualConstraintsGrid->Cells[0][0] = "";
        ObjectiveGrid->RowCount = 1;
        ObjectiveGrid->ColCount = 1;
        ObjectiveGrid->Cells[0][0] = "";
        MaxGrid->RowCount = 1;
        MaxGrid->ColCount = 1;
        MaxGrid->Cells[0][0] = "";
        MinGrid->RowCount = 1;
        MinGrid->ColCount = 1;
        MinGrid->Cells[0][0] = "";
        EqualGrid->RowCount = 1;
        EqualGrid->ColCount = 1;
        EqualGrid->Cells[0][0] = "";
        ResultsEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TLinProForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);        
}
//---------------------------------------------------------------------------
void __fastcall TLinProForm::NoVarsEditExit(TObject *Sender)
{
        int value;

        value = StrToInt(NoVarsEdit->Text);
        if (value == 0) return;
        ObjectiveGrid->ColCount = value;
        MaxGrid->ColCount = value;
        MinGrid->ColCount = value;
        EqualGrid->ColCount = value;
        NoVars = value;
        GetDblVecMem(Objective,NoVars + 1);
}
//---------------------------------------------------------------------------
void __fastcall TLinProForm::NoMaxEditExit(TObject *Sender)
{
        int value;

        value = StrToInt(NoMaxEdit->Text);
        if (value == 0) return;
        MaxConstraintsGrid->RowCount = value;
        MaxGrid->RowCount = value;
        NoMax = value;
        GetDblVecMem(MaxConstraints,NoMax + 1);
}
//---------------------------------------------------------------------------
void __fastcall TLinProForm::NoMinEditExit(TObject *Sender)
{
        int value;

        value = StrToInt(NoMinEdit->Text);
        if (value == 0) return;
        MinConstraintsGrid->RowCount = value;
        MinGrid->RowCount = value;
        NoMin = value;
        GetDblVecMem(MinConstraints,NoMin + 1);
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::NoEqualEditExit(TObject *Sender)
{
        int value;

        value = StrToInt(NoEqualEdit->Text);
        if (value == 0) return;
        EqualConstraintsGrid->RowCount = value;
        EqualGrid->RowCount = value;
        NoEql = value;
        GetDblVecMem(EqlConstraints,NoEql + 1);
        NoCoefs = NoMax + NoMin + NoEql;
        GetDblMatMem(Coefficients,NoCoefs+1,NoVars + 1);
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::CancelBtnClick(TObject *Sender)
{
        ClearDblMatMem(Coefficients,NoCoefs+1);
        ClearDblVecMem(EqlConstraints);
        ClearDblVecMem(MinConstraints);
        ClearDblVecMem(MaxConstraints);
        ClearDblVecMem(Objective);
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::ReturnBtnClick(TObject *Sender)
{
        ClearDblMatMem(Coefficients,NoCoefs+1);
        ClearDblVecMem(EqlConstraints);
        ClearDblVecMem(MinConstraints);
        ClearDblVecMem(MaxConstraints);
        ClearDblVecMem(Objective);
        LinProForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::SaveBtnClick(TObject *Sender)
{
        FILE *LinProFile;
        int i, j;
        AnsiString FName;
        char newline = '\n';

        LoadArrayData(this);
        SaveDialog1->DefaultExt = "LPR";
        SaveDialog1->Filter = "Linear Programming File (.LPR)|*.LPR|All Files (*.*)|*.*";
        SaveDialog1->FilterIndex = 1;
        if (SaveDialog1->Execute())
        {
                FName = SaveDialog1->FileName;
                LinProFile = fopen(FName.c_str(),"wt");
                fprintf(LinProFile,"%d%c",NoVars,newline);
                fprintf(LinProFile,"%d%c",NoMax,newline);
                fprintf(LinProFile,"%d%c",NoMin,newline);
                fprintf(LinProFile,"%d%c",NoEql,newline);
                fprintf(LinProFile,"%d%c",MinMax,newline);
                for (i = 1; i <= NoVars; i++)
                        fprintf(LinProFile,"%8.4f%c",Objective[i],newline);
                for (i = 1; i <= NoMax; i++)
                        fprintf(LinProFile,"%8.4f%c",MaxConstraints[i],newline);
                for (i = 1; i <= NoMin; i++)
                        fprintf(LinProFile,"%8.4f%c",MinConstraints[i],newline);
                for (i = 1; i <= NoEql; i++)
                        fprintf(LinProFile,"%8.4f%c",EqlConstraints[i],newline);
                for (i = 1; i <= NoCoefs; i++)
                {
                        for (j = 1; j <= NoVars; j++)
                        {
                                fprintf(LinProFile,"%8.4f%c",Coefficients[i][j],newline);
                        }
                }
                fclose(LinProFile);
        }
}
//---------------------------------------------------------------------------

void TLinProForm::LoadArrayData(TObject *Sender)
{
        int i, j;

        for (i = 1; i <= NoVars; i++)
                Objective[i] = StrToFloat(ObjectiveGrid->Cells[i-1][0]);
        for (i = 1; i <= NoMax; i++)
        {
                MaxConstraints[i] = StrToFloat(MaxConstraintsGrid->Cells[0][i-1]);
                for (j = 1; j <= NoVars; j++)
                        Coefficients[i][j] = StrToFloat(MaxGrid->Cells[j-1][i-1]);
        }
        for (i = 1; i <= NoMin; i++)
        {
                MinConstraints[i] = StrToFloat(MinConstraintsGrid->Cells[0][i-1]);
                for (j = 1; j <= NoVars; j++)
                        Coefficients[i+NoMax][j] = StrToFloat(MinGrid->Cells[j-1][i-1]);
        }
        for (i = 1; i <= NoEql; i++)
        {
                EqlConstraints[i] = StrToFloat(EqualConstraintsGrid->Cells[0][i-1]);
                for (j = 1; j <= NoVars; j++)
                        Coefficients[i+NoMax+NoMin][j] = StrToFloat(EqualGrid->Cells[j-1][i-1]);
        }
        if (MinMaxGrp->ItemIndex == 1) MinMax = 1;
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::NoVarsEditKeyPress(TObject *Sender, char &Key)
{
        if (Key == 13) NoMaxEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::NoMaxEditKeyPress(TObject *Sender, char &Key)
{
        if (Key == 13) NoMinEdit->SetFocus(); 
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::NoMinEditKeyPress(TObject *Sender, char &Key)
{
        if (Key == 13) NoEqualEdit->SetFocus();         
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::NoEqualEditKeyPress(TObject *Sender,
      char &Key)
{
        if (Key == 13) ObjectiveGrid->SetFocus();         
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::LoadBtnClick(TObject *Sender)
{
        FILE *LinProFile;
        int i, j;
        long filestart;
        AnsiString FName;
        char astring[41];

        OpenDialog1->DefaultExt = "LPR";
        OpenDialog1->Filter = "Linear Programming File (.LPR)|*.LPR|All Files (*.*)|*.*";
        OpenDialog1->FilterIndex = 1;
        if (OpenDialog1->Execute())
        {
                FName = OpenDialog1->FileName;
                LinProFile = fopen(FName.c_str(),"rt");
                fgetpos(LinProFile,&filestart);
                fscanf(LinProFile,"%d",&NoVars);
                fscanf(LinProFile,"%d",&NoMax);
                fscanf(LinProFile,"%d",&NoMin);
                fscanf(LinProFile,"%d",&NoEql);
                fscanf(LinProFile,"%d",&MinMax);
                NoCoefs = NoMax + NoMin + NoEql;
                GetDblVecMem(Objective,NoVars + 1);
                GetDblVecMem(MaxConstraints,NoMax + 1);
                GetDblVecMem(MinConstraints,NoMin + 1);
                GetDblVecMem(EqlConstraints,NoEql + 1);
                GetDblMatMem(Coefficients,NoCoefs+1,NoVars + 1);
                for (i = 1; i <= NoVars; i++)
                {
                        StrCopy(astring,"");
                        fscanf(LinProFile,"%s",&astring);
                        Objective[i] = StrToFloat(astring);
                }
                for (i = 1; i <= NoMax; i++)
                {
                        StrCopy(astring,"");
                        fscanf(LinProFile,"%s",&astring);
                        MaxConstraints[i] = StrToFloat(astring);
                }
                for (i = 1; i <= NoMin; i++)
                {
                        StrCopy(astring,"");
                        fscanf(LinProFile,"%s",&astring);
                        MinConstraints[i] = StrToFloat(astring);
                }
                for (i = 1; i <= NoEql; i++)
                {
                        StrCopy(astring,"");
                        fscanf(LinProFile,"%s",&astring);
                        EqlConstraints[i] = StrToFloat(astring);
                }
                for (i = 1; i <= NoCoefs; i++)
                {
                        for (j = 1; j <= NoVars; j++)
                        {
                                StrCopy(astring,"");
                                fscanf(LinProFile,"%s",&astring);
                                Coefficients[i][j] = StrToFloat(astring);
                        }
                }
                fclose(LinProFile);
        }
        FileNameEdit->Text = FName;
        NoVarsEdit->Text = IntToStr(NoVars);
        NoMaxEdit->Text = IntToStr(NoMax);
        NoMinEdit->Text = IntToStr(NoMin);
        NoEqualEdit->Text = IntToStr(NoEql);
        MinMaxGrp->ItemIndex = MinMax;
        MaxConstraintsGrid->RowCount = NoMax;
        MinConstraintsGrid->RowCount = NoMin;
        EqualConstraintsGrid->RowCount = NoEql;
        ObjectiveGrid->ColCount = NoVars;
        MaxGrid->RowCount = NoMax;
        MaxGrid->ColCount = NoVars;
        MinGrid->RowCount = NoMin;
        MinGrid->ColCount = NoVars;
        EqualGrid->RowCount = NoEql;
        EqualGrid->ColCount = NoVars;

     // Place objectives in grid
     for (i = 1; i <= NoVars; i++)
         ObjectiveGrid->Cells[i-1][0] = FloatToStr(Objective[i]);

     // Place Maximum constraints in grid
     for (i = 1; i <= NoMax; i++)
     {
         MaxConstraintsGrid->Cells[0][i-1] = FloatToStr(MaxConstraints[i]);
         for (j = 1; j <= NoVars; j++) MaxGrid->Cells[j-1][i-1] = FloatToStr(Coefficients[i][j]);
     }

     // Place Minimum constraints in grid
     for (i = 1; i <= NoMin; i++)
     {
          MinConstraintsGrid->Cells[0][i-1] = FloatToStr(MinConstraints[i]);
          for (j = 1; j <= NoVars; j++)
              MinGrid->Cells[j-1][i-1] = FloatToStr(Coefficients[NoMax+i][j]);
     }

     // Place Equal constraints in grid
     for (i = 1; i <= NoEql; i++)
     {
          EqualConstraintsGrid->Cells[0][i-1] = FloatToStr(EqlConstraints[i]);
          for (j = 1; j <= NoVars; j++)
              EqualGrid->Cells[j-1][i-1] = FloatToStr(Coefficients[NoMax+NoMin+i][j]);
     }
     ComputeBtn->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TLinProForm::ComputeBtnClick(TObject *Sender)
{
        int m1, m2, m3, m, mp, n, np, nm1m2, i, icase,j;
        int *izrov;
        int *iposv;
        double **a;
        AnsiString *txt;
        AnsiString outline;
        char astring[121];

        n = NoVars;
        m1 = NoMax;
        m2 = NoMin;
        m3 = NoEql;
        m = m1 + m2 + m3;
        np = n+1;   // np >= n+1
        mp = m + 2;   // mp >= m+2
        nm1m2 = n + m1 + m2;
        GetIntVecMem(izrov,n+1);
        GetIntVecMem(iposv,m+1);
        GetDblMatMem(a,mp+1,np+1);
        txt = new AnsiString [nm1m2+1];

   // Initialize labels
   for (i = 1; i <= NoVars; i++) txt[i] = "X" + IntToStr(i);
   for (i = NoVars + 1; i <= nm1m2; i++) txt[i] = "Y" + IntToStr(i-NoVars);

   // Fill array data from grid
   LoadArrayData(this);
   for (i = 1; i <= NoVars; i++) a[1][i+1] = Objective[i];
   a[1][1] = 0.0;
   for (i = 1; i <= NoMax; i++)
   {
        a[i+1][1] = MaxConstraints[i];
        for (j = 1; j <= NoVars; j++) a[i+1][j+1] = Coefficients[i][j];
   }
   for (i = 1; i <= NoMin; i++)
   {
        a[i+1+NoMax][1] = MinConstraints[i];
        for (j = 1; j <= NoVars; j++) a[i+1+NoMax][j+1] = Coefficients[i+NoMax][j];
   }
   for (i = 1; i <= NoEql; i++)
   {
        a[i+1+NoMax+NoMin][1] = EqlConstraints[i];
        for (j = 1; j <= NoVars; j++)
             a[i+1+NoMax+NoMin][j+1] = Coefficients[i+NoMax+NoMin][j];
   }
   if (MinMaxGrp->ItemIndex == 1)
   {
        MinMax = 1;
        for (i = 1; i <= NoVars; i++) a[1][i+1] = -1.0 * a[1][i+1];
   }

   // Do analysis
//        void simplx(double **a, int m, int n, int mp, int np, int m1,
//          int m2, int m3, int icase, int *izrov, int *iposv);
   simplx(a,m,n,mp,np,m1,m2,m3,icase,izrov,iposv);
   if (MinMax == 1) a[1][1] = -a[1][1];

   // Report results
   FrmOutPut->RichOutPut->Clear();
   FrmOutPut->RichOutPut->Lines->Add("Linear Programming Results");
   FrmOutPut->RichOutPut->Lines->Add("");

   outline = "";
   if (icase == 1)
   {
      ResultsEdit->Text = "Unbounded objective function.";
      FrmOutPut->RichOutPut->Lines->Add("Unbounded object function.");
   }
   else if(icase == -1)
   {
      ResultsEdit->Text = "No solutions satisfy constraints given.";
      FrmOutPut->RichOutPut->Lines->Add("No solutions satisfy constraints given");
   }
   else
   {
      ResultsEdit->Text = "Solution found.";
      outline = "           ";
      for (i = 1; i <= n; i++)
      {
         if(izrov[i] <= nm1m2)
         {
            sprintf(astring,"%10s",txt[izrov[i]]);
            outline = outline + astring;
         }
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("");
      outline = "";
      for (i = 1; i <= m+1; i++)
      {
         if (i > 1)
         {
            sprintf(astring,"%3s",txt[iposv[i-1]]);
            outline = outline + astring;
         }
         else
         {
             outline = outline + "  z";
         }
         for (j = 1; j <= (n+1); j++)
         {
            if(j == 1)
            {
               sprintf(astring,"%10.4f",a[i][j]);
               outline = outline + astring;
            }
            if (j > 1)
            {
               if(izrov[j-1] <= nm1m2)
               {
                  sprintf(astring,"%10.4f",a[i][j]);
                  outline = outline + astring;
               }
            }
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
         outline = "";
      }
   }
   FrmOutPut->ShowModal();

//   ShowOutPut(m1, m2, m3, m, n, icase, a, iposv, izrov, Self);

   // cleanup
   delete[] txt;
//   delete[] a;
   ClearDblMatMem(a,mp+1);
   delete[] iposv;
   delete[] izrov;
}
//---------------------------------------------------------------------------

void TLinProForm::simplx(double **a, int m, int n, int mp, int np, int m1,
          int m2, int m3, int& icase, int *izrov, int *iposv)
{
//        label 1, 2, 10, 20, 30, 99;

//        double eps=1.0e-6;
        int nl2,nl1,m12,kp,kh,k,is1,ir,ip,i;
        double q1,bmax;
        int *l1;
        int *l2, *l3;

        GetIntVecMem(l1,np+1);
        GetIntVecMem(l2,mp + 1);
        GetIntVecMem(l3,mp + 1);
        if (m != (m1+m2+m3))
        {
                ShowMessage("pause in routine SIMPLX");
                ShowMessage("bad input constraint counts");
        }
        nl1 = n;
        for ( k = 1; k <= n; k++)
        {
                l1[k] = k;
                izrov[k] = k;
        }
        nl2 = m;
        for ( i = 1; i <= m; i++)
        {
                if (a[i+1][1] < 0.0)
                {
                        ShowMessage("pause in routine SIMPLX");
                        ShowMessage("bad input tableau");
                }
                l2[i] = i;
                iposv[i] = n+i;
        }
        for ( i = 1; i <= m2; i++)
        {
                l3[i] = 1;
        }
        ir = 0;
        if ((m2+m3) == 0)  goto a30;
        ir = 1;
        for ( k = 1; k <= n+1; k++)
        {
                q1 = 0.0;
                for ( i = m1+1; i <= m; i++)
                {
                        q1 = q1+a[i+1][k];
                }
                a[m+2][k] = -q1;
        }
a10:     simp1(a,mp,np,m+1,l1,nl1,0,kp,bmax);
        if ((bmax <= eps) && (a[m+2][1] < -eps))
        {
                icase = -1;
                goto a99;
        }
        else if ((bmax <= eps) && (a[m+2][1] <= eps))
        {
                m12 = m1+m2+1;
                if (m12 <= m)
                {
                        for ( ip = m12; ip <= m; ip++)
                        {
                                if (iposv[ip] == (ip+n))
                                {
                                        simp1(a,mp,np,ip,l1,nl1,1,kp,bmax);
                                        if (bmax > 0.0)  goto a1;
                                }
                        }
                }
                ir = 0;
                m12 = m12-1;
                if ((m1+1) > m12)  goto a30;
                for ( i = m1+1; i <= m12; i++)
                {
                        if (l3[i-m1] == 1)
                        {
                                for ( k = 1; k <= n+1; k++)
                                {
                                        a[i+1][k] = -a[i+1][k];
                                }
                        }
                }
                goto a30;
        }
        simp2(a,m,n,mp,np,l2,nl2,ip,kp,q1);
        if (ip == 0)
        {
                icase = -1;
                goto a99;
        }
a1:      simp3(a,mp,np,m+1,n,ip,kp);
        if (iposv[ip] >= (n+m1+m2+1))
        {
                for ( k = 1; k <= nl1; k++)
                {
                        if (l1[k] == kp)  goto a2;
                }
a2:              nl1 = nl1-1;
                for ( is1 = k; is1 <= nl1; is1++)
                {
                        l1[is1] = l1[is1+1];
                }
        }
        else
        {
                if (iposv[ip] < (n+m1+1))  goto a20;
                kh = iposv[ip]-m1-n;
                if (l3[kh] == 0)  goto a20;
                l3[kh] = 0;
        }
        a[m+2][kp+1] = a[m+2][kp+1]+1.0;
        for ( i = 1; i <= m+2; i++)
        {
                a[i][kp+1] = -a[i][kp+1];
        }
a20:     is1 = izrov[kp];
        izrov[kp] = iposv[ip];
        iposv[ip] = is1;
        if (ir != 0)  goto a10;
a30:     simp1(a,mp,np,0,l1,nl1,0,kp,bmax);
        if (bmax <= 0.0)
        {
                icase = 0;
                goto a99;
        }
//simp2(double **a, int m, int n, int mp, int np,
//      int *l2, int nl2, int ip, int kp, double q1)
        simp2(a,m,n,mp,np,l2,nl2,ip,kp,q1);
        if (ip == 0)
        {
                icase = 1;
                goto a99;
        }
        simp3(a,mp,np,m,n,ip,kp);
        goto a20;
a99:     delete[] l1;
        delete[] l2;
        delete[] l3;
}
//-------------------------------------------------------------------

void TLinProForm::simp1(double **a, int mp, int np, int mm,
      int *ll, int nll, int iabf, int& kp, double& bmax)
{
   int k;
   double test; // : real;

   kp = ll[1];
   bmax = a[mm+1][kp+1];
   if (nll < 2)  goto a99;
   for ( k = 2; k <= nll; k++)
   {
      if (iabf == 0)
      {
         test = a[mm+1][ll[k]+1]-bmax;
      }
      else
      {
         test = fabs(a[mm+1][ll[k]+1])-fabs(bmax);
      }
      if (test > 0.0)
      {
         bmax = a[mm+1][ll[k]+1];
         kp = ll[k];
      }
   }
a99:
}
//-------------------------------------------------------------------

void TLinProForm::simp2(double **a, int m, int n, int mp, int np,
      int *l2, int nl2, int& ip, int kp, double& q1)
{
   int k,ii,i;
   double qp,q0,q;

   ip = 0;
   if (nl2 < 1)  goto a99;
   for ( i = 1; i <= nl2; i++)
   {
      if (a[l2[i]+1][kp+1] < 0.0) goto a2;
   }
   goto a99;
a2:   q1 = -a[l2[i]+1][1] / a[l2[i]+1][kp+1];
   ip = l2[i];
   if ((i+1) > nl2)  goto a99;
   for ( i = i+1; i <= nl2; i++)
   {
      ii = l2[i];
      if (a[ii+1][kp+1] < 0.0)
      {
         q = -a[ii+1][1] / a[ii+1][kp+1];
         if (q < q1)
         {
            ip = ii;
            q1 = q;
         }
         else if (q == q1)
         {
            for ( k = 1; k <= n; k++)
            {
               qp = -a[ip+1][k+1] / a[ip+1][kp+1];
               q0 = -a[ii+1][k+1] / a[ii+1][kp+1];
               if (q0 != qp)  goto a6;
            }
a6:          if (q0 < qp)  ip = ii;
         }
      }
   }
a99:
}

//-------------------------------------------------------------------

void TLinProForm::simp3(double **a, int mp, int np, int i1, int k1, int ip, int kp)
{
/* Programs using routine SIMP3 must define the type
TYPE
   glmpbynp = ARRAY [1..mp,1..np] OF real;
in the main routine. */

   int kk,ii;
   double piv;

   piv = 1.0 / a[ip+1][kp+1];
   if (i1 >= 0)
   {
      for ( ii = 1; ii <= (i1+1); ii++)
      {
         if ((ii-1) != ip)
         {
            a[ii][kp+1] = a[ii][kp+1]*piv;
            for ( kk = 1; kk <= k1+1; kk++)
            {
               if ((kk-1) != kp)
               {
                  a[ii][kk] = a[ii][kk] - (a[ip+1][kk]*a[ii][kp+1]);
               }
            }
         }
      }
   }
   for ( kk = 1; kk <= k1+1; kk++)
   {
      if ((kk-1) != kp)  a[ip+1][kk] = -a[ip+1][kk]*piv;
   }
   a[ip+1][kp+1] = piv;
}
//-------------------------------------------------------------------

