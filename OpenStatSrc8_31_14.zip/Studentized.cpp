//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "Studentized.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStudentizedq *Studentizedq;
//---------------------------------------------------------------------------
__fastcall TStudentizedq::TStudentizedq(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TStudentizedq::FormShow(TObject *Sender)
{
        DF1Edit->Text = "";
        DF2Edit->Text = "";
        CumEdit->Text = "";
        PropGreater->Text = "";
        QEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TStudentizedq::ComputeBtnClick(TObject *Sender)
{
        double cumprob;
        double probgreater;
        double DF1, DF2, Q;

        Q = StrToFloat(QEdit->Text);
        DF1 = StrToFloat(DF1Edit->Text);
        DF2 = StrToFloat(DF2Edit->Text);
        if (DF2 > 120.0) DF2 = 120.0;
        cumprob = prtrng(Q,DF2,DF1);
        probgreater = 1.0 - cumprob;
        CumEdit->Text = FloatToStr(cumprob);
        PropGreater->Text = FloatToStr(probgreater);
}
//---------------------------------------------------------------------------
void __fastcall TStudentizedq::ReturnBtnClick(TObject *Sender)
{
        return;        
}
//---------------------------------------------------------------------------
