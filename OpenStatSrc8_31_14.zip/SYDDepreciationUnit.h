//---------------------------------------------------------------------------

#ifndef SYDDepreciationUnitH
#define SYDDepreciationUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TSYDDepreciationFrm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TEdit *CostEdit;
     TLabel *Label2;
     TEdit *SalvageEdit;
     TLabel *Label3;
     TEdit *LifeEdit;
     TLabel *Label4;
     TEdit *DepreciationEdit;
     TButton *ComputeBtn;
     TButton *ResetBtn;
     TButton *ReturnBtn;
     TLabel *Label5;
     TEdit *PeriodEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TSYDDepreciationFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSYDDepreciationFrm *SYDDepreciationFrm;
//---------------------------------------------------------------------------
#endif
