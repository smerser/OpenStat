//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "PlotUnit.h"
#include "SPCcChartUnit.h"
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSPCcChartForm *SPCcChartForm;
//---------------------------------------------------------------------------
__fastcall TSPCcChartForm::TSPCcChartForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSPCcChartForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     SigmaOpts->ItemIndex = 0;
     SigmaEdit->Text = "";
     MeasEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSPCcChartForm::FormActivate(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TSPCcChartForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     MeasEdit->Text = VarList->Items->Strings[index];
}
//---------------------------------------------------------------------------
void __fastcall TSPCcChartForm::ComputeBtnClick(TObject *Sender)
{
     int i, MeasVar;
     double X, size, UCL, LCL, Sigma, GrandMean, meanc, stddevc;
     double *means;
     AnsiString cellstring;
     char outline[101];

     MeasVar = 1;
     Sigma = 3.0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == MeasEdit->Text) MeasVar = i;
     }

     if (SigmaOpts->ItemIndex == 3) Sigma = StrToFloat(SigmaEdit->Text);
     if (SigmaOpts->ItemIndex == 0)  Sigma = 3.0;
     if (SigmaOpts->ItemIndex == 1)  Sigma = 2.0;
     if (SigmaOpts->ItemIndex == 2)  Sigma = 1.0;

     GetDblVecMem(means,NoCases + 1);
     GrandMean = 0.0;
     size = 0;

     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidValue(i,MeasVar)) continue;
          X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
          means[i-1] = X;
          GrandMean = GrandMean + X;
          size = size + 1;
     }

     meanc = GrandMean / size;
     stddevc = sqrt(meanc);
     UCL = meanc + (Sigma * stddevc);
     LCL = meanc - (Sigma * stddevc);

     // printed results
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Defects c Control Chart Results");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Sample Number of ");
     FrmOutPut->RichOutPut->Lines->Add("       Noncomformities");
     FrmOutPut->RichOutPut->Lines->Add("______ _______________");
     for (i = 1; i <= NoCases; i++)
     {
          sprintf(outline," %3d     %8.2f",i,means[i-1]);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"Total Nonconformities = %8.2f",GrandMean);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"No. of samples = %d",NoCases);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Poisson mean and variance = %8.3f",meanc);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Lower Control Limit = %8.3f, Upper Control Limit = %8.3f",
            LCL, UCL);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();

     // show graph
     PlotMeans(means,NoCases,UCL,LCL,meanc,this);

     ClearDblVecMem(means);
}
//---------------------------------------------------------------------------

void __fastcall TSPCcChartForm::PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean,
                             TObject *Sender)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi;
     double imagehi, maxval, minval, valincr, Yvalue;
     char Title[101];

     maxval = -10000.0;
     minval = 10000.0;
     for (i = 0; i < NoGrps; i++)
     {
          if (means[i] > maxval) maxval = means[i];
          if (means[i] < minval) minval = means[i];
     }
     if (UCL > maxval) maxval = UCL;
     if (LCL < minval) minval = LCL;

     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(hleft,vtop-10,hleft+hwide,vtop+vhi+10);

     // draw Grand Mean
     ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->Brush->Color = clLtGray;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"MEAN");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom + 20);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom + 20);
     for (i = 1; i <= NoGrps; i++)
     {
          ypos = vbottom + 10;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(Title,"%d",i);
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = xpos - offset;
          ypos = ypos + strhi;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = 10;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,"GROUPS:");
     }

     // Draw vertical axis
     valincr = (maxval - minval) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          sprintf(Title,"%8.2f",maxval - ((i-1)*valincr));
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = maxval - (valincr * (i-1));
          ypos = ceil(vhi * ( (maxval - Yvalue) / (maxval - minval)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw lines for means of the groups
     ypos = ceil(vhi * ( (maxval - means[0]) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = ceil((hwide / NoGrps) + hleft);
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     for (i = 2; i <= NoGrps; i++)
     {
          ypos = ceil(vhi * ( (maxval - means[i-1]) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // Draw upper and lower confidence intervals
     ypos = ceil(vhi * ( (maxval - UCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"UCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     ypos = ceil(vhi * ( (maxval - LCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"LCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     strcpy(Title,"DEFECT CONTROL (c) CHART FOR : ");
     strcat(Title,MainForm->FileNameEdit->Text.c_str());
     ypos = PlotForm->Image1->Height - PlotForm->Image1->Canvas->TextHeight(Title);
     xpos = PlotForm->Image1->Width / 2 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     PlotForm->ShowModal();
}
