//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "FileSelUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFileSelFrm *FileSelFrm;
//---------------------------------------------------------------------------
__fastcall TFileSelFrm::TFileSelFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::FormCreate(TObject *Sender)
{
    FilterBox->Filter = "Item Banks (*.bnk)|*.BNK| All files (*.*)|*.*| Text files (*.txt;*.dat)|*.txt;*.dat|Bit Map files (*.bmp)|*.bmp";
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::FilterBoxChange(TObject *Sender)
{
    FileListBox->Mask = FilterBox->Mask;

}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::DriveBoxChange(TObject *Sender)
{
      DirBox->Drive = DriveBox->Drive;
      FileListBox->Drive = DriveBox->Drive;
      FileListBox->Directory = DirBox->Directory;
      FileNameEdit->Text = FileListBox->Directory + "\\";
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::FileListBoxClick(TObject *Sender)
{
    FileNameEdit->Text = FileListBox->FileName;
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::DirBoxChange(TObject *Sender)
{
      FileListBox->Directory = DirBox->Directory;
      FileNameEdit->Text = FileListBox->Directory + "\\";
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::CancelBtnClick(TObject *Sender)
{
   FileSelFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFileSelFrm::OKBtnClick(TObject *Sender)
{
    if (FileNameEdit->Text == "")
        ShowMessage("You must select or enter a file name.");
    else FileSelFrm->Hide(); 
}
//---------------------------------------------------------------------------
