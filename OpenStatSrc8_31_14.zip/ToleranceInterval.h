//---------------------------------------------------------------------------

#ifndef ToleranceIntervalH
#define ToleranceIntervalH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TToleranceIntervalForm : public TForm
{
__published:	// IDE-managed Components
        TButton *ResetBtn;
        TButton *ReturnBtn;
        TButton *ComputeBtn;
        TButton *CancelBtn;
        TRadioGroup *RadioGroup1;
        TLabel *Label1;
        TEdit *MeanEdit;
        TLabel *Label2;
        TEdit *SDEdit;
        TLabel *Label3;
        TEdit *NSizeEdit;
        TLabel *Label4;
        TEdit *CIEdit;
        TLabel *Label5;
        TEdit *TolCIEdit;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *LowMeanCIEdit;
        TLabel *Label8;
        TEdit *HiMeanCIEdit;
        TLabel *Label9;
        TEdit *Left1TailEdit;
        TLabel *Label10;
        TEdit *TwoTailTolLowEdit;
        TLabel *Label11;
        TEdit *TwoTailTolHiEdit;
        TLabel *Label12;
        TLabel *Label13;
        TEdit *LowTolEdit;
        TLabel *Label14;
        TEdit *HiTolEdit;
        TLabel *Label15;
        TListBox *VarList;
        TBitBtn *DepIn;
        TBitBtn *DepOut;
        TLabel *Label16;
        TEdit *DepEdit;
        TLabel *Label17;
        TLabel *Label18;
        TEdit *Right1TailEdit;
        TLabel *Label19;
        TEdit *DesiredPropEdit;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall RadioGroup1Click(TObject *Sender);
        void __fastcall DepInClick(TObject *Sender);
        void __fastcall DepOutClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
 
private:	// User declarations
public:		// User declarations
        __fastcall TToleranceIntervalForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TToleranceIntervalForm *ToleranceIntervalForm;
//---------------------------------------------------------------------------
#endif
