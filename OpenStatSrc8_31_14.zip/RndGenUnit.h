//---------------------------------------------------------------------------
#ifndef RndGenUnitH
#define RndGenUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TRndGenFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *NoObsEdit;
    TLabel *Label2;
    TEdit *LabelEdit;
    TRadioGroup *RadioGroup1;
    TButton *CancelBtn;
    TButton *OKBtn;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall RadioGroup1Click(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    int maxint, minint;
    double maxreal, minreal;
    double meanz;
    double sdz;
    int df1;
    int df2;
    int btn;
    
public:		// User declarations
    __fastcall TRndGenFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRndGenFrm *RndGenFrm;
//---------------------------------------------------------------------------
#endif
