//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "stdio.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "LogRegUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLogisticForm *LogisticForm;
extern int NoCases;
extern int NoVariables;
//---------------------------------------------------------------------------
__fastcall TLogisticForm::TLogisticForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     DepEdit->Text = "";
     DepOutBtn->Visible = false;
     DepInBtn->Visible = true;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
     DescChk->Checked = true;
     ProbsChk->Checked = true;
     ItersChk->Checked = true;
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::DepOutBtnClick(TObject *Sender)
{
     if (DepEdit->Text == "") return;
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLogisticForm::OKBtnClick(TObject *Sender)
{
     int i, j, k, l;
     AnsiString title, cellstring;
     char outline[121];
     int nR;                  // no. independent variables
     int *ColNoSelected;
     int nC;                  // no. cases
     int nP;                  // total no. variables
     AnsiString *RowLabels, *ColLabels;
     int nP1;                 // total no. variables plus 1
     int sY0, sY1;            // sum of cases with dependent of 0 or 1
     int sC;                  // total count of cases with 0 or 1
     double *X;               // data matrix for independent variables
     double *Y0, *Y1;         // data array for dependent data
     double *xM;              // variable means
     double *xSD;             // variable standard deviations
     double *Par;             // work array
     double *SEP;             // work array;
     double *Arr;             // work array;
     int indx, indx2, indx3;  // indexes for arrays
     double value;
     double LLp, LL, LLn;     // log likelihood
     double v, q;             // work values
     double xij, s;           // work value
     double CSq;              // chi square statistic
     double prob;             // probability of chi square
     double ORc, OR1, ORh;    // Odds ratio values
     int iters;
     int Table[3][3];
     int row, col;
     char astring[121];
     int *selected;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Logistic Regression Adapted from John C. Pezzullo");
     FrmOutPut->RichOutPut->Lines->Add("Java program at http://members.aol.com/johnp71/logistic.html");

     // get independent item columns
     nR = SelList->Items->Count;
     nC = NoCases;
     selected = new int[nR+1];
     ColNoSelected = new int[nR + 2];
     RowLabels = new AnsiString[nR + 2];
     ColLabels = new AnsiString[nR + 2];
     if (nR < 1)
     {
          ShowMessage("ERROR! No independent variables selected.");
          goto CleanUp;
     }

     for (i = 1; i <= nR; i++)
     {
         cellstring = SelList->Items->Strings[i-1];
         for (j = 1; j <= NoVariables; j++)
         {
              if (cellstring == MainForm->Grid->Cells[j][0])
              {
                  ColNoSelected[i] = j;
                  selected[i] = j;
/*
                  result = VarTypeChk(j,0);
                  if (result == 1)
                  {
                        delete[] ColLabels;
                        delete[] RowLabels;
                        delete[] ColNoSelected;
                        delete[] selected;
                        return;
                  }
*/
                  RowLabels[i] = cellstring;
                  ColLabels[i] = cellstring;
              }
         }
     }

     // get dependendent variable column
     if (DepEdit->Text == "")
     {
         ShowMessage("ERROR! No Dependent variable selected.");
         delete[] ColLabels;
         delete[] RowLabels;
         delete[] ColNoSelected;
         delete[] selected;
         return;
     }
     nP = nR + 1;
     nP1 = nP + 1;
     for (j = 1; j <= NoVariables; j++)
     {
         if (DepEdit->Text == MainForm->Grid->Cells[j][0])
         {
             ColNoSelected[nP] = j;
             selected[0] = j;
/*
             result = VarTypeChk(j,1);
             if (result == 1)
             {
                delete[] ColLabels;
                delete[] RowLabels;
                delete[] ColNoSelected;
                delete[] selected;
                return;
             }
*/
             RowLabels[nP] = MainForm->Grid->Cells[j][0];
             ColLabels[nP] = RowLabels[nP];
         }
     }

     sY0 = 0;
     sY1 = 0;
     sC = 0;
     X = new double[(nC + 1) * (nR + 1)];
     Y0 = new double[nC + 1];
     Y1 = new double[nC + 1];
     xM = new double[nR + 2];
     xSD = new double[nR + 2];
     Par = new double[nP + 1];
     SEP = new double[nP + 1];
     Arr = new double[(nP + 1) * (nP1 + 1)];

     for (i = 0; i <=nC; i++)
     {
         Y0[i] = 0.0;
         Y1[i] = 0.0;
     }
     for (i = 0; i < nR+2; i++)
     {
         xM[i] = 0.0;
         xSD[i] = 0.0;
     }
     for (i = 0; i < nP+1; i++)
     {
         Par[i] = 0.0;
         SEP[i] = 0.0;
     }
     for (i = 0; i < (nP+1)*(nP1+1); i++) Arr[i] = 0.0;

     // get data
     for (i = 0; i < nC; i++)
     {
          if (!ValidRecord(i+1,selected,nR+1)) continue;
          indx = ix(i,0,nR+1);
          X[indx] = 1;
          for (j = 1; j <= nR; j++)
          {
               indx = ColNoSelected[j];
               value = StrToFloat(Trim(MainForm->Grid->Cells[indx][i+1]));
               //result = GetValue(i+1,indx,intvalue,dblvalue,strvalue);
               //if (result == 1) value = 0.0;
               //else value = dblvalue;
               indx = ix(i,j,nR + 1);
               X[indx] = value;
          }
          indx = ColNoSelected[nP];
          value = StrToFloat(Trim(MainForm->Grid->Cells[indx][i+1]));
          //result = GetValue(i+1,indx,intvalue,dblvalue,strvalue);
          //if (result == 1) value = 0.0;
          //else value = intvalue; // dblvalue;
          if (value == 0.0)
          {
               Y0[i] = 1.0;
               sY0 = sY0 + 1;
          }
          else
          {
               Y1[i] = 1.0;
               sY1 = sY1 + 1;
          }
          sC = sC + ceil(Y0[i] + Y1[i]);
          for (j = 1; j <= nR; j++)
          {
               indx = ix(i,j,nR + 1);
               value = X[indx];
               xM[j] = xM[j] + (Y0[i] + Y1[i]) * value;
               xSD[j] = xSD[j] + (Y0[i] + Y1[i]) * value * value;
          }
     } // next case i

     // print descriptive statistics
     FrmOutPut->RichOutPut->Lines->Add("");
     if (DescChk->Checked)
        FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     sprintf(outline,"%d cases have Y=0; %d cases have Y=1.",sY0,sY1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("Variable  Label            Average     Std.Dev.");
     for (j = 1; j <= nR; j++)
     {
          xM[j] = xM[j] / (double) sC;
          xSD[j] =xSD[j] / (double) sC;
          xSD[j] = sqrt( fabs(xSD[j] - xM[j] * xM[j]));
          if (DescChk->Checked)
          {
               sprintf(outline,"   %3d %15s %10.4f %10.4f",j,RowLabels[j],xM[j],xSD[j]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     xM[0] = 0.0;
     xSD[0] = 1.0;

     // convert independent variable values to z scores
     for (i = 0; i < nC; i++)
     {
          for (j = 1; j <= nR; j++)
          {
               indx = ix(i,j,nR + 1);
               X[indx] = (X[indx] - xM[j]) / xSD[j];
          }
     }

     //  iterations
     iters = 0;
     if (ItersChk->Checked)
        FrmOutPut->RichOutPut->Lines->Add("Iteration History");
     Par[0] = log((double)sY1 / (double)sY0);
     for (j = 1; j <= nR; j++)  Par[j] = 0.0;
     LLp = 2e10;
     LL = 1e10;
     while (fabs(LLp-LL) > 0.0001)
     {
          iters = iters + 1;
          if (iters > StrToInt(MaxItersEdit->Text))  break;
          LLp = LL;
          LL = 0.0;
          for (j = 0; j <= nR; j++)
          {
               for (k = j; k <= nR+1; k++)
               {
                    indx = ix(j,k,nR+2);
                    Arr[indx] = 0.0;
               }
          }
          for (i = 0; i < nC; i++)
          {
               value = Par[0];
               for (j = 1; j <= nR; j++)
               {
                    indx = ix(i,j,nR + 1);
                    value = value + Par[j] * X[indx];
               }
               value = 1.0 / (1.0 + exp(-value));
               q = value * (1.0 - value);
               if ((value < 1.0) && (value > 0))
                        LL = LL - 2.0 * Y1[i] * log(value) - 2.0 * Y0[i] * log(1.0 - value);
               else
               {
                        ShowMessage("ERROR! Attempt to obtain a log of 0 or 1");
                        MaxItersEdit->Text = iters;
//                        break;
               }
               for (j = 0; j <= nR; j++)
               {
                    indx = ix(i,j,nR + 1);
                    xij = X[indx];
                    indx = ix(j,nR + 1, nR + 2);
                    Arr[indx] = Arr[indx] + xij * ( Y1[i] * (1.0 - value) + Y0[i] * (-value));
                    for (k = j; k <= nR; k++)
                    {
                         indx = ix(j,k,nR + 2);
                         indx2 = ix(i,k,nR + 1);
                         Arr[indx] = Arr[indx] + xij * X[indx2] * q * (Y0[i] + Y1[i]);
                    }
               } // next j
          } // next i
          sprintf(outline,"-2 Log Likelihood = %10.4f ",LL);
          if (LLp == 1.0e10)
          {
               LLn = LL;
               strcat(outline," (Null Model)");
          }
          if (ItersChk->Checked) FrmOutPut->RichOutPut->Lines->Add(outline);
          for (j = 1; j <= nR; j++)
          {
               for (k = 0; k <= j-1; k++)
               {
                    indx = ix(j,k,nR + 2);
                    indx2 = ix(k,j,nR + 2);
                    Arr[indx] = Arr[indx2];
               }
          }
          for (i = 0; i <= nR; i++)
          {
               indx = ix(i,i,nR + 2);
               s = Arr[indx];
               Arr[indx] = 1.0;
               for (k = 0; k <= nR + 1; k++)
               {
                    indx = ix(i,k,nR + 2);
                    Arr[indx] = Arr[indx] / s;
               }
               for (j = 0; j <= nR; j++)
               {
                    if (i != j)
                    {
                         indx = ix(j,i,nR + 2);
                         s = Arr[indx];
                         Arr[indx] = 0.0;
                         for (k = 0; k <= nR + 1; k++)
                         {
                              indx2 = ix(j,k,nR + 2);
                              indx3 = ix(i,k,nR + 2);
                              Arr[indx2] = Arr[indx2] - s * Arr[indx3];
                         } // next k
                    } // if i not equal j
               } // next j
          } // next i
          for (j = 0; j <= nR; j++)
          {
               indx = ix(j,nR + 1,nR + 2);
               Par[j] = Par[j] + Arr[indx];
          }
     } // iteration
     FrmOutPut->RichOutPut->Lines->Add("Converged");

     FrmOutPut->RichOutPut->Lines->Add("");
     CSq = LLn - LL;
     prob = ChiSq(CSq,nR);
     sprintf(outline,"Overall Model Fit... Chi Square = %8.4f with df = %3d and prob. = %8.4f",
                       CSq, nR, prob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Coefficients and Standard Errors...");
     FrmOutPut->RichOutPut->Lines->Add("Variable        Label     Coeff.     StdErr     p");
     for (j = 1; j <= nR; j++)
     {
          Par[j] = Par[j] / xSD[j];
          indx = ix(j,j,nP + 1);
          SEP[j] = sqrt(Arr[indx]) / xSD[j];
          Par[0] = Par[0] - Par[j] * xM[j];
          prob = Norm(fabs(Par[j] / SEP[j]));
          sprintf(outline,"  %3d %15s %10.4f %10.4f %10.4f",j,RowLabels[j].c_str(),Par[j],SEP[j],prob);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"Intercept %10.4f",Par[0]);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Odds Ratios and 95% Confidence Intervals...");
     FrmOutPut->RichOutPut->Lines->Add("Variable            O.R.       Low   --   High");
     for (j = 1; j <= nR; j++)
     {
          ORc = exp(Par[j]);
          OR1 = exp(Par[j] - 1.96 * SEP[j]);
          ORh = exp(Par[j] + 1.96 * SEP[j]);
          sprintf(outline,"%15s %10.4f %10.4f %10.4f",RowLabels[j].c_str(),ORc,OR1,ORh);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     for (i = 1; i <= 3; i++)
         for (j = 1; j <= 3; j++)  Table[i-1][j-1] = 0;
     strcpy(outline,"");
     FrmOutPut->RichOutPut->Lines->Add("");
     if (ProbsChk->Checked)
     {
          for (j = 1; j <= nR; j++)  strcat(outline,"      X     ");
          strcat(outline,"   Y       Prob");
          FrmOutPut->RichOutPut->Lines->Add(outline);
          for (i = 0; i < nC; i++)
          {
               value = Par[0];
               strcpy(outline,"");
               for (j = 1; j <= nR; j++)
               {
                    indx = ix(i,j,nR + 1);
                    xij = xM[j] + xSD[j] * X[indx];
                    value = value + Par[j] * xij;
                    sprintf(astring," %10.4f ",xij);
                    strcat(outline,astring);
               }
               value = 1.0 / (1.0 + exp( -value));
               sprintf(astring,"%4.0f %10.4f",Y1[i],value);
               strcat(outline,astring);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               if (ceil(Y1[i]) == 0)  row = 1;
               else row = 2;
               if (value < 0.5)  col = 1;
               else col = 2;
               Table[row-1][col-1] = Table[row-1][col-1] + 1;
          } // next i
     }
     for (i = 1; i <= 2; i++)
     {
          for (j = 1; j <= 2; j++)
          {
               Table[i-1][2] = Table[i-1][2] + Table[i-1][j-1];
               Table[2][j-1] = Table[2][j-1] + Table[i-1][j-1];
          }
     }
     for (i = 1; i <= 2; i++)  Table[2][2] = Table[2][2] + Table[i-1][2];
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Classification Table");
     FrmOutPut->RichOutPut->Lines->Add("           Predicted");
     FrmOutPut->RichOutPut->Lines->Add("        --------------- ");
     FrmOutPut->RichOutPut->Lines->Add("Observed    0      1     Total");
     FrmOutPut->RichOutPut->Lines->Add("        --------------- ");
     for (i = 1; i <= 2; i++)
     {
          sprintf(outline,"   %d    ",i-1);
          for (j = 1; j <= 3; j++)
          {
              sprintf(astring,"| %3d  ",Table[i-1][j-1]);
              strcat(outline,astring);
          }
          strcat(outline,"|");
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("        --------------- ");
     strcpy(outline,"Total   ");
     for (j = 1; j <= 3; j++)
     {
         sprintf(astring,"| %3d  ",Table[2][j-1]);
         strcat(outline,astring);
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("        --------------- ");
     FrmOutPut->ShowModal();

CleanUp:
     delete[] Arr;
     delete[] SEP;
     delete[] Par;
     delete[] xSD;
     delete[] xM;
     delete[] Y1;
     delete[] Y0;
     delete[] X;
     delete[] RowLabels;
     delete[] ColLabels;
     delete[] ColNoSelected;
     delete[] selected;
}
//---------------------------------------------------------------------------

double __fastcall TLogisticForm::ChiSq(double x, int n)
{
     // returns the probability of a chi-square statistic with n deg. freem
     double p, t, a;
     int k;

     p = exp(-0.5 * x);
     if (n % 2 == 1)  p = p * sqrt(2 * x / M_PI);
     k = n;
     while (k >= 2)
     {
          p = p * x / k;
          k = k - 2;
     }
     t = p;
     a = n;
     while (t > 0.000001 * p)
     {
          a = a + 2;
          t = t * x / a;
          p = p + t;
     }
     return(1.0 - p);
}
//---------------------------------------------------------------------------

double __fastcall TLogisticForm::Norm(double z)
{
     // returns the chi-square probability of the squared z score
     return(ChiSq(z * z, 1));
}
//---------------------------------------------------------------------------

int __fastcall TLogisticForm::ix(int j, int k, int nCols)
{
     // returns an integer for the subscript
     return(j * nCols + k);
}
//---------------------------------------------------------------------------


