//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

// Basic package support functions
#include "DictionaryUnit.h"
#include "Clipbrd.hpp"
#include "stdio.h"
#include "DataFuncs.h"
#include "Transforms.h"
#include "TransfAllUnit.h"
#include "VarComboUnit.h"
#include "RecodeUnit.h"
#include "AboutMeUnit.h"
#include "SplashUnit.h"
#include "PrevFileUnit.h"
#include "OptionsUnit.h"
#include "GenNewFileUnit.h"
#include "EquationUnit.h"
#include "OutPut.h"
#include "HugeFileUnit.h"
#include "DirectoryUnit.h"
#include "FileSplitUnit.h"
#include "MergeFilesUnit.h"
#include "Studentized.h"
#include "FUnit.h"
#include "ChiUnit.h"
#include "HyperGeomUnit.h"
#include "CombinationsUnit.h"
#include "ChangeValuesUnit.h"

// Descriptive Statistics Routines
#include "DescriptiveUnit.h"
#include "FreqDistUnit.h"
#include "CrossTabsUnit.h"
#include "BreakDown.h"
#include "BoxPlotUnit.h"
#include "StemLeafUnit.h"
#include "ThreeDPlot.h"
#include "PlotXYUnit.h"
#include "QQPPUnit.h"
#include "NormalityUnit.h"
#include "DistCompareUnit.h"
#include "GroupFreqUnit.h"
#include "BubbleUnit.h"
#include "XvsMultYUnit.h"
#include "MultGrpXYPlotUnit.h"
#include "CorrespondenceUnit.h"
#include "SmoothData.h"
#include "CATROC.h"
#include "ResistantLineUnit.h"
#include "BFEqualVarUnit.h"
#include "SingleValuePlot.h"

// Univariate Analyses
#include "OneSampleUnit.h"
#include "TwoMeansUnit.h"
#include "TwoPropsUnit.h"
#include "TwoCorrsUnit.h"

// Analyses of Variance routines
#include "AnovaUnit.h"
#include "ABCNestedUnit.h"
#include "ABRAnova.h"
#include "LatinSqrUnit.h"
#include "NestedABUnit.h"
#include "WithinAnovaUnit.h"
#include "ANCOVAUnit.h"
#include "TypeI.h"
#include "SSRegUnit.h"
#include "TwoWayRepUnit.h"
#include "OneCaseAnovaUnit.h"
#include "BRownForsythe1WayUnit.h"
#include "Welch1WayUnit.h"

// Correlation Routines
#include "PMCorrUnit.h"
#include "PartialUnit.h"
#include "AutoCorUnit.h"

// Interrupted Time Series Analysis
#include "InterruptedUnit.h"

// Multiple Regression Analyses
#include "RegSelUnit.h"
#include "StepFwdUnit.h"
#include "StepBackUnit.h"
#include "SimultaneousUnit.h"
#include "CoxRegUnit.h"
#include "BestRegUnit.h"
#include "LogRegUnit.h"
#include "WLSUnit.h"
#include "NonLinUnit.h"
#include "TwoSLSUnit.h"
//#include "OLSMRUnit.h"

// Multivariate Analyses
#include "AvgLinkUnit.h"
#include "canon.h"
#include "Hierarch.h"
#include "KMEANSUnit.h"
#include "SingleLinkUnit.h"
#include "Factor.h"
#include "Discrim.h"
#include "PathAnal.h"
#include "LogLinScreenUnit.h"
#include "ABCLogLinUnit.h"
#include "AxBLogLinUnit.h"
#include "BartlettUnit.h"
#include "MedianPolishUnit.h"

// Non-parametric functions
#include "Friedmn.h"
#include "ExactUnit.h"
#include "KruskWall.h"
#include "Binom.h"
#include "RunsTestUnit.h"
#include "NonPar.h"
#include "KendallTauUnit.h"
#include "ChiSqr.h"
#include "KaplanMeierUnit.h"
#include "SensUnit.h"
#include "KolSmiUnit.h"
#include "KappaUnit.h"
#include "WKappaUnit.h"
#include "RIDITUnit.h"
#include "ComboPermuteUnit.h"
#include "BGHUnit.h"
#include "MWUFormUnit.h"
#include "SimpleChiSqrUnit.h"
#include "LifeTableUnit.h"
#include "LTestUnit.h"
#include "JTUnit.h"

// Measurement functions
#include "AttnRelUnit.h"
#include "ClassRelUnit.h"
#include "CompRelUnit.h"
#include "DIFUnit.h"
#include "GUM.h"
#include "ItemAnal.h"
#include "RaschUnit.h"
#include "SuccIntvl.h"
#include "TestGenrUnit.h"
#include "ThreePLUnit.h"
#include "GuttAnalysis.h"
#include "KR21Unit.h"
#include "SpearmanBrownUnit.h"
#include "GradingUnit.h"
#include "BankUpdate.h"
#include "TestSpecUnit.h"
#include "testadmunit.h"
#include "GradeSysUnit.h"

// Matrix Manipulation function
#include "MatManUnit.h"

// Statistical Process Control functions
#include "XBARUnit.h"
#include "SPCcChartUnit.h"
#include "SPCCUMSUMUnit.h"
#include "SPCpChartUnit.h"
#include "SPCRangeUnit.h"
#include "SPCSigmaUnit.h"
#include "SPCUChartUnit.h"

// Financial Routines
#include "DblDeclineUnit.h"
#include "FutureValueUnit.h"
#include "InterestPayUnit.h"
#include "InterestRateUnit.h"
#include "LoanItMain.h"
#include "NetPresentValueUnit.h"
#include "NPeriodsUnit.h"
#include "PaymentUnit.h"
#include "PeriodPayUnit.h"
#include "PresentValueUnit.h"
#include "RateofReturnUnit.h"
#include "SLNDepreciationUnit.h"
#include "SYDDepreciationUnit.h"

// Simulation Routines
#include "DistMain.h"
#include "EvalGenrUnit.h"
#include "GenSeqVals.h"
#include "MultGenUnit.h"
#include "RndGenUnit.h"
#include "Sim2WayUnit.h"
#include "SimCorUnit.h"
#include "SeqValsUnit.h"
#include "PCurves.h"
#include "Plot.h"
#include "ResamplingUnit.h"
#include "ZFunctionUnit.h"
#include "ToleranceInterval.h"

// Neural Network (artificial Intelligence)
//#include "NeuralMainUnit.h"

// Linear Programming unit
#include "LinProUnit.h"

// Utilities
#include "PicViewMain.h"
#include "CalculatorUnit.h"

#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;

int NoVariables, NoCases;
int importopt;
int row, col;
long filestart, fileend, filepos;
AnsiString linebuf[1000];
AnsiString cellstring;
bool openfile;
bool FilterOn;
int FilterCol;
int FileType;
char prtfmt[121];
struct Options ops;
extern bool ReadDiskFile;
extern FILE *datafile;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::FormShow(TObject *Sender)
{
   GetOptions();
   row = 1;
   col = 1;
   NoCasesEdit->Text = 0;
   NoVarsEdit->Text = 0;
   Grid->Cells[0][1] = "CASE 1";
   Grid->Cells[0][0] = "UNITS";
   openfile = false;
   NewVar(col,false);
   ReadDiskFile = false;
   FileNameEdit->Text = "Temporary.TEX";
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Exit1Click(TObject *Sender)
{
   if (openfile)
   {
   	AnsiString response = InputBox("FILE OPEN!","Save File?","Y");
      if (response == "Y") SaveOpenStatFile1Click(this);
   }
//   UpdateOps(FileName);
//   SaveOptions();
   exit(0);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GridKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
   char downarrow = 40;
   char uparrow = 38;
   char rightarrow = 37;
   char leftarrow = 39;
   AnsiString cellstr;
   int oldrow, oldcol;

   KeyEdit->Text = Key;
   if ((Key == 8) || (Key == 46))// backspace or delete
   {
   	  cellstr = Grid->Cells[col][row];
      int howlong = cellstr.Length();
      if (howlong >= 1) Grid->Cells[col][row] = cellstr.SubString(1,howlong-1);
   }
   oldrow = Grid->Row;
   oldcol = Grid->Col;
   if (Key == downarrow)
   {
   	  if (row == Grid->RowCount - 1)
      {
      	 row++;
         Grid->RowCount = Grid->RowCount + 1;
         Grid->Cells[0][row] = IntToStr(row);
      }
      if (oldrow > 0) FmtCell(oldrow,oldcol);
   }
   if ((Key == uparrow)||(Key == leftarrow)||(Key == rightarrow))
   {
      if (Grid->Row > 0) FmtCell(oldrow,oldcol);
      else Grid->Row = 1;
   }
   row = Grid->Row;
   col = Grid->Col;
   RowEdit->Text = row;
   ColEdit->Text = col;
   NoCasesEdit->Text = IntToStr(Grid->RowCount-1);
   NoCases = Grid->RowCount-1;
   if (Key == 13) // return key
   {
      FmtCell(oldrow,oldcol);
      if (col < Grid->ColCount-1)
      {
         col++;
         Grid->Col = col;
         ColEdit->Text = col;
      }
      else if (row < Grid->RowCount-1)
      {
         Grid->Row = row+1;
         row++;
         col = 1;
         Grid->Col = col;
         ColEdit->Text = col;
         RowEdit->Text = row;
      }
   }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Define1Click(TObject *Sender)
{
	DictionaryForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OpenOpenStatFile1Click(TObject *Sender)
{
	OpenOSFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SaveOpenStatFile1Click(TObject *Sender)
{
	SaveOSFile();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::GridKeyPress(TObject *Sender, char &Key)
{
   char chr = Key;
	if (Key > 29) Grid->Cells[col][row] = Grid->Cells[col][row] + chr;
   row = Grid->Row;
   col = Grid->Col;
   RowEdit->Text = row;
   ColEdit->Text = col;
   CellEdit->Text = Grid->Cells[col][row];
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Copy1Click(TObject *Sender)
{
	CopyIt();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Paste1Click(TObject *Sender)
{
	PasteIt();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CloseFile1Click(TObject *Sender)
{
    char FileName[121];
    if (FileNameEdit->Text != "")
    {
        strcpy(FileName,FileNameEdit->Text.c_str());
        CloseFile();
        fclose(datafile);
        if (strlen(FileName) > 1) UpdateOps(FileName);
        SaveOptions();
        FileNameEdit->Text = "";
        ReadDiskFile = false;
    }
    FileNameEdit->Text = "Temporary.TEX";
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OpenTabFileClick(TObject *Sender)
{
   importopt = 1;
   ImportTabFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ImportSpaceFile1Click(TObject *Sender)
{
	importopt = 3;
    ImportTabFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ImportCommaFile1Click(TObject *Sender)
{
	importopt = 2;
    ImportTabFile();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::GridClick(TObject *Sender)
{
   row = Grid->Row;
   col = Grid->Col;
   RowEdit->Text = row;
   ColEdit->Text = col;
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ExportTabFile1Click(TObject *Sender)
{
   importopt = 1;
   SaveCSVFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ExportSpaceFile1Click(TObject *Sender)
{
   importopt = 3;
   SaveCSVFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ExportCommaFile1Click(TObject *Sender)
{
   importopt = 2;
   SaveCSVFile();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PrintGrid1Click(TObject *Sender)
{
     PrintCases();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SortCa1Click(TObject *Sender)
{
     GridSort();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Transform1Click(TObject *Sender)
{
     FrmTransform->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PrintDictionary1Click(TObject *Sender)
{
     PrintDict();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InsertColumn1Click(TObject *Sender)
{
     int col = Grid->Col;
     InsertNewCol(col);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DeleteColumn1Click(TObject *Sender)
{
     int col = Grid->Col;
     DeleteaCol(col);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InsertRow1Click(TObject *Sender)
{
     row = Grid->Row;
     InsertaRow(row);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DeleteRow1Click(TObject *Sender)
{
     int row = Grid->Row;
     CutaRow(row);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CopyaColumn1Click(TObject *Sender)
{
     int col = Grid->Col;
     CopyaCol(col);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PasteaColumn1Click(TObject *Sender)
{
     int col = Grid->Col;
     PasteaCol(col);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CopyaRow1Click(TObject *Sender)
{
     int row = Grid->Row;
     CopyaRow(row);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PasteaRow1Click(TObject *Sender)
{
     int row = Grid->Row;
     PasteaRow(row);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SelectCases1Click(TObject *Sender)
{
     if (!ReadDiskFile) SelectCases();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RecodeValues1Click(TObject *Sender)
{
     FrmRecode->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::About1Click(TObject *Sender)
{
    AboutFrm->ShowModal();     
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PreviousFilesUsed1Click(TObject *Sender)
{
     PrevFileForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SwitchUSAtoEuroorViceVersa1Click(
      TObject *Sender)
{
      ChangeSeparator();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Options1Click(TObject *Sender)
{
     OptionsForm->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::CentralTendencyVariability1Click(
      TObject *Sender)
{
      DescriptiveForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Frequencies1Click(TObject *Sender)
{
     FreqDistFrm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::XVersusYPlot1Click(TObject *Sender)
{
     XvsYPlotForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BoxPlots1Click(TObject *Sender)
{
    BoxPlotForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::StemandLeafPlot1Click(TObject *Sender)
{
     StemLeafForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CrossTabulation1Click(TObject *Sender)
{
     CrossTabForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Breakdown1Click(TObject *Sender)
{
     FrmBrkDwn->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ThreeDimensionRotation1Click(TObject *Sender)
{
     Frm3DPlot->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::QQorPPPlot1Click(TObject *Sender)
{
     QQPPForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::NormalityTests1Click(TObject *Sender)
{
     NormalityForm->ShowModal();         
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CompareObservedtoTheoreticalDistribution1Click(
      TObject *Sender)
{
      DistCompareForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GroupFrequencyHistograms1Click(TObject *Sender)
{
     GroupFreqForm->ShowModal();         
}
//---------------------------------------------------------------------------
/*
void __fastcall TMainForm::GroupFrequencyPieCharts1Click(TObject *Sender)
{
     GroupFreqForm->ShowModal();
}
//---------------------------------------------------------------------------
*/
void __fastcall TMainForm::SingleSampleTests1Click(TObject *Sender)
{
     OneSampleForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Testoftwoproportions1Click(TObject *Sender)
{
     TwoPropsForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Testoftwocorrelations1Click(TObject *Sender)
{
     TwoCorrsForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Testoftwomeans1Click(TObject *Sender)
{
     TwoMeansForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ANOVAClick(TObject *Sender)
{
     AnovaForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AxSClick(TObject *Sender)
{
     FrmRepAnova->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ABRClick(TObject *Sender)
{
     ABRForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ANCOVAClick(TObject *Sender)
{
     ANCOVAFORM->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::LatinSquareDesigns1Click(TObject *Sender)
{
     LatinSqrForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FactorBNestedinFactorA1Click(TObject *Sender)
{
     NestedABForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ABCNestedClick(TObject *Sender)
{
     ABCNestedForm->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ARClick(TObject *Sender)
{
     TypeIFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ProductMomentCorrelations1Click(TObject *Sender)
{
     PMCorrForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PartialandSemiPartialCorrelations1Click(
      TObject *Sender)
{
      FrmPartial->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AutoCorrelations1Click(TObject *Sender)
{
     AutoCorFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InterruptedTimeSeriesAnalysis1Click(
      TObject *Sender)
{
      InterruptedForm->ShowModal();
}

//---------------------------------------------------------------------------
void __fastcall TMainForm::ItemBanking1Click(TObject *Sender)
{
//     ItemBankFrm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BlockEntryMultipleRegression1Click(
      TObject *Sender)
{
      RegSelForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ForwardStepwiseMultipleRegression1Click(
      TObject *Sender)
{
      StepFwdForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BackwardStepwiseMultipleRegression1Click(
      TObject *Sender)
{
      StepBackForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SimultaneousMultipleRegression1Click(
      TObject *Sender)
{
      SimultaneousForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BestFitMultipleRegression1Click(TObject *Sender)
{
     BestRegForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CoxRegression1Click(TObject *Sender)
{
     CoxRegForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::WeightedLeastSquaresMR1Click(TObject *Sender)
{
     WLSForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::NonLinearRegression1Click(TObject *Sender)
{
     EquatParseForm->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BinaryLogisticRegression1Click(TObject *Sender)
{
     LogisticForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SumsofSquaresbyRegression1Click(TObject *Sender)
{
     SSbyRegForm->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::FactorAnalClick(TObject *Sender)
{
     FactorFrm->ShowModal();
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::MANOVAClick(TObject *Sender)
{
     DiscrimForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DiscrimClick(TObject *Sender)
{
     DiscrimForm->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::PathAnalysis1Click(TObject *Sender)
{
     FrmPath->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::HierarchicalClusteringVeldman1Click(
      TObject *Sender)
{
      FrmHier->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SingleLinkClusterAnalysis1Click(TObject *Sender)
{
     SingleLinkForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AverageLinkClusterAnalysis1Click(
      TObject *Sender)
{
      AvgLinkForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KMeansClusterAnalysis1Click(TObject *Sender)
{
     KMEANSForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SumsofSquaresbyRegression2Click(TObject *Sender)
{
     SSbyRegForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CanonicalCorrelation1Click(TObject *Sender)
{
     canon();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BinomialProbabilities1Click(TObject *Sender)
{
        binomial();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FishersExactTest1Click(TObject *Sender)
{
     ExactForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RunsTest1Click(TObject *Sender)
{
     RunsTestForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ChiSquareTest1Click(TObject *Sender)
{
     ChiSFrm->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::KruskalWallaceTest1Click(TObject *Sender)
{
        KWFrm->ShowModal();
//     kwanova();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FriedmanTest1Click(TObject *Sender)
{
     FriedmanFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KendallsTauTest1Click(TObject *Sender)
{
     KendallTauForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::WilcoxonTest1Click(TObject *Sender)
{
     Wilcoxon();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KendallsCoefficientofConcordance1Click(
      TObject *Sender)
{
      Concord();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SignTest1Click(TObject *Sender)
{
     signtest();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MannWhitneyUTest1Click(TObject *Sender)
{
        MWUForm->ShowModal();
//     MWUtest();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::QTest1Click(TObject *Sender)
{
     qtest();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SpearmanRankCorrelation1Click(TObject *Sender)
{
     Spearman();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ClassicalItemAnalysisandReliability1Click(
      TObject *Sender)
{
      TestAnalForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::HoytandCronbachReliability1Click(
      TObject *Sender)
{
     FrmRepAnova->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RaschOneParameterLogisticScaling1Click(
      TObject *Sender)
{
      RaschForm->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ThreeParameterLogisticScaling1Click(
      TObject *Sender)
{
      ThreePLForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GuttmanScaling1Click(TObject *Sender)
{
     Guttman();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SuccessiveIntervalScaling1Click(TObject *Sender)
{
     SuccInt();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DifferentialItemFunctioning1Click(
      TObject *Sender)
{
      DIFForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ReliabilityAdjustedforVariance1Click(
      TObject *Sender)
{
      FrmCorrectedR->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ClassificationReliability1Click(TObject *Sender)
{
     ClassRelForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GeneralizedUnfoldingModel1Click(TObject *Sender)
{
     GUMIT();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateTestItemScores1Click(TObject *Sender)
{
     TestGenrFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MatrixManipulation1Click(TObject *Sender)
{
     MatManForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AddVarBtnClick(TObject *Sender)
{
     int col = Grid->ColCount;
     NewVar(col,false);
     Grid->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::XBARChart1Click(TObject *Sender)
{
     XBARForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SigmaChart1Click(TObject *Sender)
{
     SPCSigmaForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RangeChart1Click(TObject *Sender)
{
     SPCRangeForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::pChart1Click(TObject *Sender)
{
     SPCpChartForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CUMSUMChart1Click(TObject *Sender)
{
     SPCCUMSUMForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::cChart1Click(TObject *Sender)
{
     SPCcChartForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::UChart1Click(TObject *Sender)
{
     SPCUChartForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KuderRichardson21Reliability1Click(
      TObject *Sender)
{
      KR21Form->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CompositeTestReliability1Click(TObject *Sender)
{
     FrmCompRel->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::LoanAmortizationSchedule1Click(TObject *Sender)
{
     LoanItForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SumofYearsDigitsDepreciation1Click(
      TObject *Sender)
{
      SYDDepreciationFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::StraightLineDepreciation1Click(TObject *Sender)
{
     SLNDepreciationFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InternalRateofReturn1Click(TObject *Sender)
{
     RateReturnFrm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PresentValue1Click(TObject *Sender)
{
     PresentValueFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PeriodPayment1Click(TObject *Sender)
{
     PeriodPayForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Payment1Click(TObject *Sender)
{
     PaymentFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::NoofPeriods1Click(TObject *Sender)
{
     NPeriodsFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::NetPresentValue1Click(TObject *Sender)
{
     NetPresentValueFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InterestRate1Click(TObject *Sender)
{
     InterestRateForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::InterestPayment1Click(TObject *Sender)
{
     InterestPayForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FutureValue1Click(TObject *Sender)
{
     FutureValueForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::DoubleDecliningValue1Click(TObject *Sender)
{
     DblDeclineForm->ShowModal();    
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::TheoreticalDistributions1Click(TObject *Sender)
{
     DistMainForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateSequentialValues1Click(TObject *Sender)
{
     GenSeqForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateaMultivariateDistribution1Click(
      TObject *Sender)
{
      MultGenFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateOneofFourTheoreticalDistributions1Click(
      TObject *Sender)
{
      RndGenFrm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Generateincrementedvalues1Click(TObject *Sender)
{
     FrmSeqValues->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SimulateaTwoWayANOVA1Click(TObject *Sender)
{
     FrmSim2Way->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SimulateaProductMomentCorrelation1Click(
      TObject *Sender)
{
      SimCorFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PowerCurvesforHypotheses1Click(TObject *Sender)
{
     PowCurvs->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateanEvaluationReport1Click(
      TObject *Sender)
{
      FrmEvalGen->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PlotazDistribution1Click(TObject *Sender)
{
     FrmPlot->Zdist();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PlotaChiSquareDistribution1Click(
      TObject *Sender)
{
      FrmPlot->ChiSqrDist();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PlotanFDistribution1Click(TObject *Sender)
{
     FrmPlot->Fdistribution();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SampleSizeforazTest1Click(TObject *Sender)
{
     FrmPlot->AltHypothesis();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CellEditKeyPress(TObject *Sender, char &Key)
{
     if (Key == 13) {
        Grid->Cells[col][row] = CellEdit->Text;
        Grid->SetFocus();
     }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RowEditChange(TObject *Sender)
{
     int thisrow = StrToInt(RowEdit->Text);
     int thiscol = StrToInt(ColEdit->Text);
     CellEdit->Text = Grid->Cells[thiscol][thisrow];
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ColEditChange(TObject *Sender)
{
     int thisrow = StrToInt(RowEdit->Text);
     int thiscol = StrToInt(ColEdit->Text);
     CellEdit->Text = Grid->Cells[thiscol][thisrow];
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::OpenanOpenStat4File1Click(TObject *Sender)
{
     OpenOS4();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SaveanOpenStat4File1Click(TObject *Sender)
{
     SaveOS4();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SBProphecyClick(TObject *Sender)
{
     FrmSB->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::Grading1Click(TObject *Sender)
{
     GradeSysFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Contents1Click(TObject *Sender)
{
     Application->HelpContext(100);      
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Screening1Click(TObject *Sender)
{
     LogLinScreenForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AxBLogLinear1Click(TObject *Sender)
{
     AxBLogLinForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AxBxCLogLinear1Click(TObject *Sender)
{
     ABCLogLinForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::TwoStageLSClick(TObject *Sender)
{
     TwoSLSForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KaplanMeierSurvivalTest1Click(TObject *Sender)
{
     KaplanMeierForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SwapRowsandColumns1Click(TObject *Sender)
{
     RowColSwap();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SensClick(TObject *Sender)
{
     SensForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FreqFileClick(TObject *Sender)
{
     GenNewFileForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CombEquationClick(TObject *Sender)
{
     EquationForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ResampleClick(TObject *Sender)
{
     ResamplingForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::TwoWithinClick(TObject *Sender)
{
     TwoWayRepForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OutFormClick(TObject *Sender)
{
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EpidataClick(TObject *Sender)
{
     char FileName[121];

     OpenDialog1->DefaultExt = "REC";
     OpenDialog1->Filter = "EPI *.rec|*.REC|TAB *.tab|*.TAB|Comma *.CSV|*.CSV|Space *.SSV|*.SSV|All *.*|*.*";
     OpenDialog1->FilterIndex = 1;
     if (OpenDialog1->Execute())  {
        strcpy(FileName,OpenDialog1->FileName.c_str());
        OpenEpiDataFile(FileName);
        FileNameEdit->Text = FileName;
        FileType = 1;
//        UpdateOps(FileName);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KSTestClick(TObject *Sender)
{
     KSForm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::KappaClick(TObject *Sender)
{
     KappaForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::WKappaClick(TObject *Sender)
{
     WKappaForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::EnterEditItems1Click(TObject *Sender)
{
     BankUpdateFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Specifyatesttoadminister1Click(TObject *Sender)
{
     TestSpecFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GenerateaTest1Click(TObject *Sender)
{
     TestAdminFrm->ShowModal();    
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::PictureViewer1Click(TObject *Sender)
{
        PicViewForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Calculator1Click(TObject *Sender)
{
        CalculatorForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::WordProcessor1Click(TObject *Sender)
{
        FrmOutPut->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OpenLargeFileClick(TObject *Sender)
{
        HugeFileForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::OneCaseANOVAClick(TObject *Sender)
{
        OneCaseAnovaForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FormatGridValues1Click(TObject *Sender)
{
        FormatCells();        
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::OpenMat1Click(TObject *Sender)
{
        LoadMatrix();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BartletTestClick(TObject *Sender)
{
        BartlettTestForm->ShowModal();        
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::Delete1Click(TObject *Sender)
{
        DeleteIt();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::NewFileClearGrid1Click(TObject *Sender)
{
        CloseFile1Click(this);
        FileNameEdit->Text = "Temporary.TEX";
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ChangeCurrentDirectory1Click(TObject *Sender)
{
        DirectoryForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SplitFileClick(TObject *Sender)
{
        SplitFileForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MergeFilesClick(TObject *Sender)
{
        MergeFilesForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BubblePlotClick(TObject *Sender)
{
        BubbleForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Studentizedq1Click(TObject *Sender)
{
        Studentizedq->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::FTable1Click(TObject *Sender)
{
        Fform->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ChisquareTable1Click(TObject *Sender)
{
        ChiUnitForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::StemandLeafPlot2Click(TObject *Sender)
{
     StemLeafForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BoxPlotsClick(TObject *Sender)
{
        BoxPlotForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::XversusMultipleYPlot1Click(TObject *Sender)
{
        XvsMultYForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MultipleGroupXversusYPlot1Click(TObject *Sender)
{
        MultGrpXYPlot->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::GrpStr2IntClick(TObject *Sender)
{
        bool results, prompt;
        int col, newcol;

        col = Grid->Col;
        prompt = false;
        results = StringsToInt(col,newcol, prompt);
        if (results == false) DeleteaCol(newcol);
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::LinProClick(TObject *Sender)
{
        LinProForm->ShowModal();        
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::RIDITClick(TObject *Sender)
{
        RIDITForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CorrespondenceAnalysis1Click(TObject *Sender)
{
        CorrespondenceForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::TransAllClick(TObject *Sender)
{
       TransfAllForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::CombineValsClick(TObject *Sender)
{
     VarComboForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::TwoDistCompareClick(TObject *Sender)
{
     KSForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SmoothItClick(TObject *Sender)
{
     SmoothForm->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::ComboPermClick(TObject *Sender)
{
        ComboPermutationsFrm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Hypergeometric1Click(TObject *Sender)
{
        HyperGeoForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Combinations1Click(TObject *Sender)
{
        CombinationsForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::zfunctionsClick(TObject *Sender)
{
        ZFunctionsForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ResistantLineAnalysis1Click(TObject *Sender)
{
        ResistantLineForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MedianPolishingAnalysis1Click(TObject *Sender)
{
        MedianPolishForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BGHItemClick(TObject *Sender)
{
        BGHForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::MedianPolishAnalysis1Click(TObject *Sender)
{
        MedianPolishForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ChangeValuesClick(TObject *Sender)
{
        ChangeValuesForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::BFEqualVClick(TObject *Sender)
{
        BFEqualVarTestForm->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::BrownForsythe1wayClick(TObject *Sender)
{
        BrownForsytheForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Welch1WayANOVAClick(TObject *Sender)
{
        Welch1wayANOVAForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SimpChiSqrClick(TObject *Sender)
{
        SimpleChiSqr->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::LifeTableClick(TObject *Sender)
{
        LifeTableForm->ShowModal();        
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::CATROCClick(TObject *Sender)
{
        CatROCFrm->ShowModal();        
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::LTestClick(TObject *Sender)
{
        LTestForm->ShowModal();        
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::JTTestClick(TObject *Sender)
{
        JTForm->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::ToleranceIntervalsforasample1Click(
      TObject *Sender)
{
        ToleranceIntervalForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::SingleValuePlot1Click(TObject *Sender)
{
        SingleValuePlotForm->ShowModal();
}
//---------------------------------------------------------------------------

