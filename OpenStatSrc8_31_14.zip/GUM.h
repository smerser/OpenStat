//---------------------------------------------------------------------------
#ifndef GUMH
#define GUMH
//---------------------------------------------------------------------------
#endif
void CleanGrid(int ICUTOFF, int &NoSelected, int *ColNoSelected);
void GUMIT(void);
void INITVAL(int NITEMS, int NSUBS, double DNCAT, double &LAMBDA,
             double *DMEAN, double *DELTA, double *THETA, double **TAU,
             double **U, int *ColNoSelected);
void BISTHETA(double &Root, int J, int M, int CL, int NITEMS,
              int ICUTOFF, int TRIES, double *DELTA, double **TAU, double **U,
              int *ColNoSelected);
void SWAP(double &A, double &B);
void THETDER1(double POINT, double &DER1, int M, int CL, int NITEMS, int J,
              double &LIKELY, double *DELTA, double **U, double **TAU,
              int *ColNoSelected);
void BRUTE(int NSUBS, int NITEMS, int M, int CL, int ICUTOFF, double *THETA,
           double *DELTA, double **U, double **TAU, int *ColNoSelected);
void DIAGNO(double PARM, int NCAT, int NSUBS, int NITEMS, int M, double FITG,
            double PSGCUT, double ISGCUT, double PERFSH, double ICHPCT,
            double PCHPCT, int CL, double LOCFC);
void PlotTheta(double *THETA, int NSUBS);
void PlotDelta(double *DELTA, int NITEMS);



