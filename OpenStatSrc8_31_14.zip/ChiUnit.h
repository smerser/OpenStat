//---------------------------------------------------------------------------

#ifndef ChiUnitH
#define ChiUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TChiUnitForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label5;
        TEdit *QEdit;
        TLabel *Label1;
        TEdit *DF1Edit;
        TLabel *Label3;
        TEdit *CumEdit;
        TLabel *Label4;
        TEdit *PropGreater;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TChiUnitForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TChiUnitForm *ChiUnitForm;
//---------------------------------------------------------------------------
#endif
