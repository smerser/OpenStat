//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LatinSpecsUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "functions.h"
#include "LatinSqrUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLatinSqrForm *LatinSqrForm;
extern int NoCases;
extern int NoVariables;
//---------------------------------------------------------------------------
__fastcall TLatinSqrForm::TLatinSqrForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLatinSqrForm::OKBtnClick(TObject *Sender)
{

     int Btn = PlanGrp->ItemIndex + 1;
     if (Btn < 0) return;
     switch (Btn)
     {
        case 1 : Plan1(this); break;
        case 2 : Plan2(this); break;
        case 3 : Plan3(this); break;
        case 4 : Plan4(this); break;
        case 5 : Plan5(this); break;
        case 6 : Plan6(this); break;
        case 7 : Plan7(this); break;
        case 8 : Plan9(this); break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan1(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, Ccol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, DataVar, cellstring;
   int i, j, minA, minB, minC, maxA, maxB, maxC, rangeA, rangeB, rangeC;
   int value;
   int **cellcnts;
   double **celltotals;
   double *Ctotals;
   AnsiString **design;
   double G, term1, term2, term3, term4, term5, term6, sumxsqr;
   double sumAsqr, sumBsqr, sumCsqr, sumABCsqr, SSA, SSB, SSC;
   double SSbetween, SSwithin, SSres, SStotal;
   double MSa, MSb, MSc, MSres, MSwithin;
   double data, GrandMean;
   int p, row, col, slice;
   double dfa, dfb, dfc, dfres, dfwithin, dftotal, fa, fb, fc, fpartial;
   double proba, probb, probc, probpartial;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->Label6->Visible = false;
     LatinSpecsFrm->Label7->Visible = false;
     LatinSpecsFrm->DinBtn->Visible = false;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = false;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->GroupCodeEdit->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
     Acol = 0;
     Bcol = 0;
     Ccol = 0;
     DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and C
    minA = 1000;
    minB = 1000;
    minC = 1000;
    maxA = -1000;
    maxB = -1000;
    maxC = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;

    // check for squareness
    if ( (rangeA != rangeB) || (rangeA != rangeC) || (rangeB != rangeC))
    {
         ShowMessage("ERROR! In a Latin square the range of factor levels should all be equal!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetIntMatMem(cellcnts,rangeA+1,rangeB+1);
    GetDblMatMem(celltotals,rangeA+1,rangeB+1);
    Ctotals = new double[rangeC+1];
    design = new AnsiString *[rangeA];
    for (int i = 0; i < rangeA; i++) design[i] = new AnsiString[rangeB];

    // initialize arrays and values
    for (i = 0; i <= rangeA; i++)
    {
        for (j = 0; j <= rangeB; j++)
        {
             cellcnts[i][j] = 0;
             celltotals[i][j] = 0.0;
        }
    }
    for (i = 0; i < rangeC; i++) Ctotals[i] = 0;
    G = 0.0;
    sumxsqr = 0.0;
    sumAsqr = 0.0;
    sumBsqr = 0.0;
    sumCsqr = 0.0;
    sumABCsqr = 0.0;
    term1 = 0.0;
    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    GrandMean = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         slice = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[row-1][col-1] = cellcnts[row-1][col-1] + 1;
         celltotals[row-1][col-1] = celltotals[row-1][col-1] + data;
         Ctotals[slice-1] = Ctotals[slice-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              if (cellcnts[i][j] != n)
              {
                   ShowMessage("cell sizes are not equal!");
                   goto cleanup;
              }
         }
    }

    // calculate values
    for (i = 0; i < p; i++) // get row and column sums
    {
         for (j = 0; j < p; j++)
         {
              celltotals[i][p] = celltotals[i][p] + celltotals[i][j];
              celltotals[p][j] = celltotals[p][j] + celltotals[i][j];
              sumABCsqr = sumABCsqr + (celltotals[i][j] * celltotals[i][j]);
         }
    }
    for (i = 0; i < p; i++) G = G + Ctotals[i];
    term1 = (G * G) / (double)(n * p * p);
    term2 = sumxsqr;
    for (i = 0; i < p; i++) // sum of squared A"s
        sumAsqr = sumAsqr + (celltotals[i][p] * celltotals[i][p]);
    for (i = 0; i < p; i++) // sum of squared B"s
        sumBsqr = sumBsqr + (celltotals[p][i] * celltotals[p][i]);
    for (i = 0; i < p; i++) // sum of squared C"s
        sumCsqr = sumCsqr + (Ctotals[i] * Ctotals[i]);
    term3 = sumAsqr / (double)(n * p);
    term4 = sumBsqr / (double)(n * p);
    term5 = sumCsqr / (double)(n * p);
    term6 = sumABCsqr / (double)n;
    SSA = term3 - term1;
    SSB = term4 - term1;
    SSC = term5 - term1;
//    SSbetween = term6 - term1;
    SSwithin = term2 - term6;
    SSres = term6 - term3 - term4 - term5 + 2.0 * term1;
    SStotal = SSA + SSB + SSC + SSres + SSwithin;
    dfa = (double)(p-1);
    dfb = (double)(p-1);
    dfc = (double)(p-1);
    dfres = (double)((p-1) * (p-2));
    dfwithin = (double)((p * p) * (n - 1));
    dftotal = (double)(n * p * p - 1);
    MSa = SSA / dfa;
    MSb = SSB / dfb;
    MSc = SSC / dfc;
    MSres = SSres / dfres;
    MSwithin = SSwithin / dfwithin;
    fa = MSa / MSwithin;
    fb = MSb / MSwithin;
    fc = MSc / MSwithin;
    fpartial = MSres / MSwithin;
    proba = ftest(dfa,dfwithin,fa);
    probb = ftest(dfb,dfwithin,fb);
    probc = ftest(dfc,dfwithin,fc);
    probpartial = ftest(dfres,dfwithin,fpartial);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Square Analysis Plan 1 Results");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Factor A  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSA,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor B  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSB,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor C  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSC,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Residual  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSres,dfres,MSres,fpartial,probpartial);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Within    ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSwithin, dfwithin, MSwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Experimental Design");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i]));
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i]));
         slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i]));
         design[row-1][col-1] = "C" + IntToStr(slice);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show table cell means
    for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
             celltotals[i][j] = celltotals[i][j] / (double) n;
    for (i = 0; i < p; i++)
    {
         celltotals[i][p] = celltotals[i][p] / (double)(p * n);
         celltotals[p][i] = celltotals[p][i] / (double)(p * n);
    }
    GrandMean = GrandMean / (double)(p * p * n);
    for (i = 0; i < p; i++) Ctotals[i] = Ctotals[i] / (double)(p * n);

    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline," %8.3f ",celltotals[i][j]);
              cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",celltotals[i][p]);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "Total     ";
    for (j = 0; j < p; j++)
    {
        sprintf(outline," %8.3f ",celltotals[p][j]);
        cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorC);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Ctotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->ShowModal();

cleanup:
    for (int i = 0; i < rangeA; i++) delete[]design[i];
    delete[] design;
    delete[] Ctotals;
    ClearDblMatMem(celltotals,rangeA+1);
    ClearIntMatMem(cellcnts,rangeA+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan2(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, Ccol, Dcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, FactorD, DataVar, cellstring;
   int i, j, k, minA, minB, minC, maxA, maxB, maxC;
   int minD, maxD, rangeD, rangeA, rangeB, rangeC, value;
   int ***cellcnts;
   double ***celltotals;
   double *Ctotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7, term8;
   double term9, sumxsqr;
   double sumAsqr, sumBsqr, sumCsqr, sumDsqr, SSA, SSB, SSC, SSD;
   double sumADsqr, sumBDsqr, sumCDsqr;
   double **ADmat, **BDmat, **CDmat;
   double SSAD, SSBD, SSCD, SSbetween, SSwithin, SSres, SStotal;
   double MSa, MSb, MSc, MSd, MSAD, MSBD, MSCD, MSres, MSwithin;
   double data, GrandMean;
   int p, row, col, slice, block;
   double dfa, dfb, dfc, dfres, dfwithin, dftotal, fa, fb, fc, fpartial;
   double dfd, fd, fad, fbd, fcd, fabc, dfad, dfbd, dfcd;
   double proba, probb, probc, probd, probpartial;
   double probad, probbd, probcd, probabc;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = false;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = false;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = false;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     FactorD = LatinSpecsFrm->DCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
     Acol = 0;
     Bcol = 0;
     Ccol = 0;
     Dcol = 0;
     DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == FactorD) Dcol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Dcol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and C
    minA = 1000;
    minB = 1000;
    minC = 1000;
    minD = 1000;
    maxA = -1000;
    maxB = -1000;
    maxC = -1000;
    maxD = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         if (value < minD) minD = value;
         if (value > maxD) maxD = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeD = maxD - minD + 1;

    // check for squareness
    if ( (rangeA != rangeB) || (rangeA != rangeC) || (rangeB != rangeC))
    {
         ShowMessage("ERROR! In a Latin square the range of values should all be equal!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetIntCubeMem(cellcnts,rangeA+1,rangeB+1,rangeD+1);
    GetDblCubeMem(celltotals,rangeA+1,rangeB+1,rangeD+1);
    GetDblMatMem(ADmat,rangeA+1,rangeD+1);
    GetDblMatMem(BDmat,rangeB+1,rangeD+1);
    GetDblMatMem(CDmat,rangeC+1,rangeD+1);
    Ctotals = new double[rangeC+1];
    Design = new AnsiString *[rangeA];
    for (i = 0; i < rangeA; i++) Design[i] = new AnsiString[rangeB];

    // initialize arrays and values
    for (i = 0; i <= rangeA; i++)
    {
        for (j = 0; j <= rangeB; j++)
        {
             for (k = 0; k <= rangeD; k++)
             {
                  cellcnts[i][j][k] = 0;
                  celltotals[i][j][k] = 0.0;
             }
        }
    }
    for (i = 0; i <= rangeA; i++)
        for (j = 0; j <= rangeD; j++)
            ADmat[i][j] = 0.0;
    for (i = 0; i <= rangeB; i++)
        for (j = 0; j <= rangeD; j++)
            BDmat[i][j] = 0.0;
    for (i = 0; i <= rangeC; i++)
        for (j = 0; j <= rangeD; j++)
            CDmat[i][j] = 0.0;
    for (i = 0; i < rangeC; i++) Ctotals[i] = 0.0;
    G = 0.0;
    sumxsqr = 0.0;
    sumAsqr = 0.0;
    sumBsqr = 0.0;
    sumCsqr = 0.0;
    sumDsqr = 0.0;
    sumADsqr = 0.0;
    sumBDsqr = 0.0;
    sumCDsqr = 0.0;
    term1 = 0.0;
//    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    term8 = 0.0;
    term9 = 0.0;
    GrandMean = 0.0;
    SSwithin = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         slice = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         block = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[row-1][col-1][block-1] = cellcnts[row-1][col-1][block-1] + 1;
         celltotals[row-1][col-1][block-1] = celltotals[row-1][col-1][block-1] + data;
         ADmat[row-1][block-1] = ADmat[row-1][block-1] + data;
         BDmat[col-1][block-1] = BDmat[col-1][block-1] + data;
         CDmat[slice-1][block-1] = CDmat[slice-1][block-1] + data;
         Ctotals[slice-1] = Ctotals[slice-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < rangeD; k++)
              {
                   if (cellcnts[i][j][k] != n)
                   {
                        ShowMessage("cell sizes are not equal!");
                        goto cleanup;
                   }
              }
         }
    }

    // calculate values
    for (i = 0; i < p; i++) // get row, column and block sums
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < rangeD; k++)
              {
                   celltotals[i][p][k] = celltotals[i][p][k] + celltotals[i][j][k];
                   celltotals[p][j][k] = celltotals[p][j][k] + celltotals[i][j][k];
                   celltotals[i][j][rangeD] =celltotals[i][j][rangeD] + celltotals[i][j][k];
              }
         }
    }
    // get interaction AD
    for (i = 0; i < rangeA; i++)
    {
         for (j = 0; j < rangeD; j++)
         {
              sumADsqr = sumADsqr + (ADmat[i][j] * ADmat[i][j]);
              ADmat[i][rangeD] = ADmat[i][rangeD] + ADmat[i][j];
              ADmat[rangeA][j] = ADmat[rangeA][j] + ADmat[i][j];
         }
    }
    for (i = 0; i < rangeA; i++)
        sumAsqr = sumAsqr + (ADmat[i][rangeD] * ADmat[i][rangeD]);
    for (i = 0; i < rangeD; i++)
        sumDsqr = sumDsqr + (ADmat[rangeA][i] * ADmat[rangeA][i]);

    // get interaction BD
    for (i = 0; i < rangeB; i++)
    {
         for (j = 0; j < rangeD; j++)
         {
              sumBDsqr = sumBDsqr + (BDmat[i][j] * BDmat[i][j]);
              BDmat[i][rangeD] = BDmat[i][rangeD] + BDmat[i][j];
              BDmat[rangeB][j] = BDmat[rangeB][j] + BDmat[i][j];
         }
    }
    for (i = 0; i < rangeB; i++)
        sumBsqr = sumBsqr + (BDmat[i][rangeD] * BDmat[i][rangeD]);

    // get interaction CD
    for (i = 0; i < rangeC; i++)
    {
         for (j = 0; j < rangeD; j++)
         {
              sumCDsqr = sumCDsqr + (CDmat[i][j] * CDmat[i][j]);
              CDmat[i][rangeD] = CDmat[i][rangeD] + CDmat[i][j];
              CDmat[rangeC][j] = CDmat[rangeC][j] + CDmat[i][j];
         }
    }
    for (i = 0; i < rangeC; i++)
        sumCsqr = sumCsqr + (CDmat[i][rangeD] * CDmat[i][rangeD]);

    G = GrandMean;
    term1 = (G * G) / (double)(n * p * p * rangeD);
//    term2 = sumxsqr;
    term3 = sumAsqr / (double)(n * p * rangeD);
    term4 = sumBsqr / (double)(n * p * rangeD);
    term5 = sumCsqr / (double)(n * p * rangeD);
    term6 = sumADsqr / (double)(n * p);
    term7 = sumBDsqr / (double)(n * p);
    term8 = sumCDsqr / (double)(n * p);
    term9 = sumDsqr / (double)(n * p * p);
    SSA = term3 - term1;
    SSD = term9 - term1;
    SSAD = term6 - term3 - term9 + term1;
    SSB = term4 - term1;
    SSBD = term7 - term4 - term9 + term1;
    SSC = term5 - term1;
    SSCD = term8 - term5 - term9 + term1;

    // get ss within
    for (i = 0; i < rangeA; i++)
         for (j = 0; j < rangeB; j++)
              for (k = 0; k < rangeD; k++)
                   SSwithin = SSwithin + (celltotals[i][j][k] * celltotals[i][j][k]);
    SSwithin = sumxsqr - (SSwithin / n);

    // get SS residual
    SStotal = sumxsqr - term1;
    SSres = SStotal - SSA - SSB - SSC - SSD - SSAD - SSBD - SSCD - SSwithin;
    dfa = (double)p-1;
    dfb = (double)p-1;
    dfc = (double)(p-1);
    dfd = (double)(rangeD - 1);
    dfad = (double)((p-1) * (rangeD - 1));
    dfbd = dfad;
    dfcd = dfad;
    dfres = (double)(rangeD * (p-1) * (p-2));
    dfwithin = (double)((p * p) * rangeD * (n - 1));
    dftotal = (double)(n * p * p * rangeD - 1);
    MSa = SSA / dfa;
    MSb = SSB / dfb;
    MSc = SSC / dfc;
    MSd = SSD / dfd;
    MSAD = SSAD / dfad;
    MSBD = SSBD / dfbd;
    MSCD = SSCD / dfcd;
    MSres = SSres / dfres;
    MSwithin = SSwithin / dfwithin;
    fa = MSa / MSwithin;
    fb = MSb / MSwithin;
    fc = MSc / MSwithin;
    fd = MSd / MSwithin;
    fad = MSAD / MSwithin;
    fbd = MSBD / MSwithin;
    fcd = MSCD / MSwithin;
    fpartial = MSres / MSwithin;
    proba = ftest(dfa,dfwithin,fa);
    probb = ftest(dfb,dfwithin,fb);
    probc = ftest(dfc,dfwithin,fc);
    probd = ftest(dfd,dfwithin,fc);
    probad = ftest(dfad,dfwithin,fad);
    probbd = ftest(dfbd,dfwithin,fbd);
    probcd = ftest(dfcd,dfwithin,fcd);
    probpartial = ftest(dfres,dfwithin,fpartial);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Square Analysis Plan 2 Results");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Factor A  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSA,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor B  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSB,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor C  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSC,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor D  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSD,dfd,MSd,fd,probd);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "A x D     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSAD,dfad,MSAD,fad,probad);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "B x D     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSBD,dfbd,MSBD,fbd,probbd);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "C x D     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSCD,dfcd,MSCD,fcd,probcd);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Residual  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSres,dfres,MSres,fpartial,probpartial);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Within    ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSwithin, dfwithin, MSwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for each block
    for (k = 0; k < rangeD; k++)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"%d",k+1);
         cellstring = "Experimental Design for block ";
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorB);
         cellstring = outline;
         for (i = 1; i <= p; i++)
         {
             sprintf(outline," %3d ",i);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorA);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 1; i <= NoCases; i++)
         {
              row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i]));
              col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i]));
              slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i]));
              block = StrToInt(Trim(MainForm->Grid->Cells[Dcol][i]));
              if (block == minD + k)
                 Design[row-1][col-1] = "C" + IntToStr(slice);
         }
         for (i = 0; i < p; i++)
         {
              sprintf(outline,"   %3d    ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%5s",Design[i][j]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         cellstring = "----------";
         for (i = 0; i < p; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }

    // get cell means
    for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
             for (k = 0; k < rangeD; k++)
             celltotals[i][j][k] = celltotals[i][j][k] / (double)n;
    for (i = 0; i < p; i++)
    {
         for (k = 0; k < rangeD; k++)
         {
              celltotals[i][p][k] = celltotals[i][p][k] / (double)(p * n);
              celltotals[p][i][k] = celltotals[p][i][k] / (double)(p * n);
         }
    }
    GrandMean = GrandMean / (double)(p * p * n * rangeD);
    for (i = 0; i < p; i++) Ctotals[i] = Ctotals[i] / (double)(p * n * rangeD);

    // show table of means for each block
    for (k = 0; k < rangeD; k++)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"BLOCK %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorB);
         cellstring = outline;
         for (i = 1; i <= p; i++)
         {
             sprintf(outline,"   %3d    ",i);
             cellstring = cellstring + outline;
         }
         cellstring = cellstring + "    Total";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorA);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++)
         {
              sprintf(outline,"   %3d    ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline," %8.3f ",celltotals[i][j][k]);
                   cellstring = cellstring + outline;
              }
              sprintf(outline," %8.3f ",celltotals[i][p][k]);
              cellstring = cellstring + outline;
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         cellstring = "Total     ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",celltotals[p][j][k]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",GrandMean);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorC);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Ctotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->ShowModal();

cleanup:
    for (i = 0; i < rangeA; i++) delete[] Design[i];
    delete[] Design;
    delete[] Ctotals;
    ClearDblMatMem(CDmat,rangeC+1);
    ClearDblMatMem(BDmat,rangeB+1);
    ClearDblMatMem(ADmat,rangeA+1);
    ClearDblCubeMem(celltotals,rangeA+1,rangeB+1);
    ClearIntCubeMem(cellcnts,rangeA+1,rangeB+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan3(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, Ccol, Dcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, FactorD, DataVar, cellstring;
   int i, j, k, m, minA, minB, minC, maxA, maxB, maxC;
   int minD, maxD, rangeA, rangeB, rangeC, rangeD;
   int value;
   int ***cellcnts;
   double ****celltotals;
   double **ABmat, **ACmat, **BCmat;
   double ***ABCmat;
   double *Atotals, *Btotals, *Ctotals, *Dtotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7, term8;
   double term9, term10, sumxsqr;
   double sumAsqr, sumBsqr, sumCsqr, sumDsqr, SSA, SSB, SSC, SSD;
   double sumABsqr, sumACsqr, sumBCsqr, sumABCsqr;
   double SSAB, SSAC, SSBC, SSABC, SSbetween, SSwithin, SSres, SStotal;
   double MSa, MSb, MSc, MSd, MSAB, MSAC, MSBC, MSABC, MSres, MSwithin;
   double data, GrandMean;
   int p, row, col, slice, block;
   double dfa, dfb, dfc, dfres, dfwithin, dftotal, fa, fb, fc, fpartial;
   double dfd, fd, fab, fac, fbc, fabc, dfab, dfac, dfbc, dfabc;
   double proba, probb, probc, probd, probpartial;
   double probab, probac, probbc, probabc;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = false;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = false;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = false;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     FactorD = LatinSpecsFrm->DCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
     Acol = 0;
     Bcol = 0;
     Ccol = 0;
     Dcol = 0;
     DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == FactorD) Dcol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Dcol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and C
    minA = 1000;
    minB = 1000;
    minC = 1000;
    minD = 1000;
    maxA = -1000;
    maxB = -1000;
    maxC = -1000;
    maxD = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         if (value < minD) minD = value;
         if (value > maxD) maxD = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeD = maxD - minD + 1;

    // check for squareness
    if ( (rangeA != rangeB) || (rangeA != rangeC) || (rangeB != rangeC) || (rangeA != rangeD) )
    {
         ShowMessage("ERROR! In a Latin square the range of values should all be equal!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetIntCubeMem(cellcnts,p+1,p+1,p+1);
    celltotals = new double ***[p+1];
    for (int i = 0; i < p+1; i++)
    {
             celltotals[i] = new double **[p+1];
             for (int j = 0; j < p+1; j++)
             {
                 celltotals[i][j] = new double *[p+1];
                 for (int k = 0; k < p+1; k++) celltotals[i][j][k] = new double[p+1];
             }
    }
    GetDblMatMem(ABmat,p+1,p+1);
    GetDblMatMem(ACmat,p+1,p+1);
    GetDblMatMem(BCmat,p+1,p+1);
    GetDblCubeMem(ABCmat,p+1,p+1,p+1);
    Atotals = new double[p];
    Btotals = new double[p];
    Ctotals = new double[p];
    Dtotals = new double[p];
    Design = new AnsiString*[p];
    for (i = 0; i < p; i++) Design[i] = new AnsiString[p];

    // initialize arrays and values
    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
             for (k = 0; k <= p; k++)
                  for (m = 0; m <= p; m++)
                       celltotals[i][j][k][m] = 0.0;
    for (i = 0; i <= p; i++)
    {
        for (j = 0; j <= p; j++)
        {
            ABmat[i][j] = 0.0;
            ACmat[i][j] = 0.0;
            BCmat[i][j] = 0.0;
        }
    }
    for (i = 0; i <= p; i++)
    {
        for (j = 0; j <= p; j++)
        {
            for (k = 0; k <= p; k++)
            {
                ABCmat[i][j][k] = 0.0;
                cellcnts[i][j][k] = 0;
            }
        }
    }
    for (i = 0; i < p; i++)
    {
         Atotals[i] = 0.0;
         Btotals[i] = 0.0;
         Ctotals[i] = 0.0;
         Dtotals[i] = 0.0;
    }
    G = 0.0;
    sumxsqr = 0.0;
    sumAsqr = 0.0;
    sumBsqr = 0.0;
    sumCsqr = 0.0;
    sumDsqr = 0.0;
    sumABsqr = 0.0;
    sumACsqr = 0.0;
    sumBCsqr = 0.0;
    sumABCsqr = 0.0;
    term1 = 0.0;
//    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    term8 = 0.0;
    term9 = 0.0;
    term10 = 0.0;
    GrandMean = 0.0;
    SSwithin = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         slice = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         block = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[row-1][col-1][slice-1] = cellcnts[row-1][col-1][slice-1] + 1;
         celltotals[row-1][col-1][slice-1][block-1] = celltotals[row-1][col-1][slice-1][block-1] + data;
         ABmat[row-1][col-1] = ABmat[row-1][col-1] + data;
         ACmat[row-1][slice-1] = ACmat[row-1][slice-1] + data;
         BCmat[col-1][slice-1] = BCmat[col-1][slice-1] + data;
         ABCmat[row-1][col-1][slice-1] = ABCmat[row-1][col-1][slice-1] + data;
         Atotals[row-1] = Atotals[row-1] + data;
         Btotals[col-1] = Btotals[col-1] + data;
         Ctotals[slice-1] = Ctotals[slice-1] + data;
         Dtotals[block-1] = Dtotals[block-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts in ABCmat
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < p; k++)
              {
                   if (cellcnts[i][j][k] != n)
                   {
                        ShowMessage("cell sizes are not  equal!");
                        goto cleanup;
                   }
              }
         }
    }

    // calculate values
    for (i = 0; i < p; i++) // get row, column, slice and block sums
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < p; k++)
              {
                   for (m = 0; m < p; m++)
                   {
                        celltotals[p][j][k][m] = celltotals[p][j][k][m] + celltotals[i][j][k][m];
                        celltotals[i][p][k][m] = celltotals[i][p][k][m] + celltotals[i][j][k][m];
                        celltotals[i][j][p][m] = celltotals[i][j][p][m] + celltotals[i][j][k][m];
                        celltotals[i][j][k][p] = celltotals[i][j][k][p] + celltotals[i][j][k][m];
                   }
              }
         }
    }
    for (i = 0; i < p; i++) // get row, column and slice sums in ABC matrix
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < p; k++)
              {
                   ABCmat[p][j][k] = ABCmat[p][j][k] + ABCmat[i][j][k];
                   ABCmat[i][p][k] = ABCmat[i][p][k] + ABCmat[i][j][k];
                   ABCmat[i][j][p] = ABCmat[i][j][p] + ABCmat[i][j][k];
              }
         }
    }

    // get 2-way interactions
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              sumABsqr = sumABsqr + (ABmat[i][j] * ABmat[i][j]);
              sumACsqr = sumACsqr + (ACmat[i][j] * ACmat[i][j]);
              sumBCsqr = sumBCsqr + (BCmat[i][j] * BCmat[i][j]);
              ABmat[i][p] = ABmat[i][p] + ABmat[i][j];
              ABmat[p][j] = ABmat[p][j] + ABmat[i][j];
              ACmat[i][p] = ACmat[i][p] + ACmat[i][j];
              ACmat[p][j] = ACmat[p][j] + ACmat[i][j];
              BCmat[i][p] = BCmat[i][p] + BCmat[i][j];
              BCmat[p][j] = BCmat[p][j] + BCmat[i][j];
              for (k = 0; k < p; k++)
                  sumABCsqr = sumABCsqr + (ABCmat[i][j][k] * ABCmat[i][j][k]);
         }
    }
    for (i = 0; i < p; i++)
    {
        sumAsqr = sumAsqr + (Atotals[i] * Atotals[i]);
        sumBsqr = sumBsqr + (Btotals[i] * Btotals[i]);
        sumCsqr = sumCsqr + (Ctotals[i] * Ctotals[i]);
        sumDsqr = sumDsqr + (Dtotals[i] * Dtotals[i]);
    }

    G = GrandMean;
    term1 = (G * G) / (double)(n * p * p * p);
//    term2 = sumxsqr;
    term3 = sumAsqr / (double)(n * p * p);
    term4 = sumBsqr / (double)(n * p * p);
    term5 = sumCsqr / (double)(n * p * p);
    term9 = sumDsqr / (double)(n * p * p);
    term6 = sumABsqr / (double)(n * p);
    term7 = sumACsqr / (double)(n * p);
    term8 = sumBCsqr / (double)(n * p);
    term10 = sumABCsqr / (double)n;
    SSA = term3 - term1;
    SSB = term4 - term1;
    SSC = term5 - term1;
    SSD = term9 - term1;
    SSAB = term6 - term3 - term4 + term1;
    SSAC = term7 - term3 - term5 + term1;
    SSBC = term8 - term4 - term5 + term1;
    SSABC = term10 - term6 - term7 - term8 + term3 + term4 + term5 - term1;
    SSABC = SSABC - (term9 - term1);

    // get ss within
    for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
              for (k = 0; k < p; k++)
                  for (m = 0; m < p; m++)
                      SSwithin = SSwithin + (celltotals[i][j][k][m] * celltotals[i][j][k][m]);
    SSwithin = sumxsqr - (SSwithin / (double)n);

    // get SS residual
    SStotal = sumxsqr - term1;
    dfa = (double)(p-1);
    dfb = (double)(p-1);
    dfc = (double)(p-1);
    dfd = (double)(p-1);
    dfab = (double)((p - 1) * (p - 1));
    dfac = dfab;
    dfbc = dfab;
    dfabc = (double)(( (p-1) * (p-1) * (p-1) ) - (p-1));
    dfwithin = (double)(p * p * p * (n - 1));
    dftotal = (double)(n * p * p * p - 1);
    MSa = SSA / dfa;
    MSb = SSB / dfb;
    MSc = SSC / dfc;
    MSd = SSD / dfd;
    MSAB = SSAB / dfab;
    MSAC = SSAC / dfac;
    MSBC = SSBC / dfbc;
    MSABC = SSABC / dfabc;
//    MSres = SSres / dfres;
    MSwithin = SSwithin / dfwithin;
    fa = MSa / MSwithin;
    fb = MSb / MSwithin;
    fc = MSc / MSwithin;
    fd = MSd / MSwithin;
    fab = MSAB / MSwithin;
    fac = MSAC / MSwithin;
    fbc = MSBC / MSwithin;
    fabc = MSABC / MSwithin;
    proba = ftest(dfa,dfwithin,fa);
    probb = ftest(dfb,dfwithin,fb);
    probc = ftest(dfc,dfwithin,fc);
    probd = ftest(dfd,dfwithin,fd);
    probab = ftest(dfab,dfwithin,fab);
    probac = ftest(dfac,dfwithin,fac);
    probbc = ftest(dfbc,dfwithin,fbc);
    probabc = ftest(dfabc,dfwithin,fabc);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Square Analysis Plan 3 Results");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Factor A  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSA,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor B  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSB,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor C  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSC,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor D  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSD,dfd,MSd,fd,probd);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "A x B     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSAB,dfab,MSAB,fab,probab);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "A x C     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSAC,dfac,MSAC,fac,probac);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "B x C     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSBC,dfbc,MSBC,fbc,probbc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "A x B x C ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSABC,dfabc,MSABC,fabc,probabc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Within    ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSwithin, dfwithin, MSwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for each block
    for (k = 0; k < rangeD; k++)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"%d",k+1);
         cellstring = "Experimental Design for block ";
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorB);
         cellstring = outline;
         for (i = 1; i <= p; i++)
         {
             sprintf(outline," %3d ",i);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorA);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 1; i <= NoCases; i++)
         {
              row = floor(StrToFloat(Trim(MainForm->Grid->Cells[Acol][i])));
              col = floor(StrToFloat(Trim(MainForm->Grid->Cells[Bcol][i])));
              slice = floor(StrToFloat(Trim(MainForm->Grid->Cells[Ccol][i])));
              block = floor(StrToFloat(Trim(MainForm->Grid->Cells[Dcol][i])));
              if (block == minD + k)
                 Design[row-1][col-1] = "C" + IntToStr(slice);
         }
         for (i = 0; i < p; i++)
         {
              sprintf(outline,"   %3d    ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%5s",Design[i][j]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }

    // get cell means
    for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
             for (k = 0; k < p; k++)
                 for (m = 0; m < p; m++)
                     celltotals[i][j][k][m] = celltotals[i][j][k][m] / (double)n;
     for (i = 0; i < p; i++)
     {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < p; k++)
              {
                   for (m = 0; m < p; m++)
                   {
                        celltotals[p][j][k][m] = celltotals[p][j][k][m] / (double)(p * n);
                        celltotals[i][p][k][m] = celltotals[i][p][k][m] / (double)(p * n);
                        celltotals[i][j][p][m] = celltotals[i][j][p][m] / (double)(p * n);
                        celltotals[i][j][k][p] = celltotals[i][j][k][p] / (double)(p * n);
                   }
              }
         }
    }
   for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
             for (k = 0; k < p; k++)
                 ABCmat[i][j][k] = ABCmat[i][j][k] / (double)n;
    for (j = 0; j < p; j++)
        for (k = 0; k < p; k++)
                 ABCmat[p][j][k] = ABCmat[p][j][k] / (double)(p * n);
    for (i = 0; i < p; i++)
        for (k = 0; k < p; k++)
                 ABCmat[i][p][k] = ABCmat[i][p][k] / (double)(p * n);
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
                 ABCmat[i][j][p] = ABCmat[i][j][p] / (double)(p * n);

    GrandMean = GrandMean / (double)(p * p * p * n );
    for (i = 0; i < p; i++)
    {
         Atotals[i] = Atotals[i] / (double)(p * p * n);
         Btotals[i] = Btotals[i] / (double)(p * p * n);
         Ctotals[i] = Ctotals[i] / (double)(p * p * n);
         Dtotals[i] = Dtotals[i] / (double)(p * p * n);
    }

    // show table of means for each block
    for (k = 0; k < p; k++)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"BLOCK %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorB);
         cellstring = outline;
         for (i = 1; i <= p; i++)
         {
             sprintf(outline,"   %3d    ",i);
             cellstring = cellstring + outline;
         }
         cellstring = cellstring + "    Total";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         sprintf(outline,"%10s",FactorA);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++)
         {
              sprintf(outline,"   %3d    ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline," %8.3f ",ABCmat[i][j][k]);
                   cellstring = cellstring + outline;
              }
              sprintf(outline," %8.3f ",ABCmat[i][p][k]);
              cellstring = cellstring + outline;
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         cellstring = "Total     ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",ABCmat[p][j][k]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",GrandMean);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "----------";
         for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for each variable");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Atotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Btotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorC);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Ctotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorD);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Dtotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->ShowModal();

cleanup:
    for (i = 0; i < p; i++) delete[] Design[i];
    delete[] Design;
    delete[] Dtotals;
    delete[] Ctotals;
    delete[] Btotals;
    delete[] Atotals;
    ClearDblCubeMem(ABCmat,p+1,p+1);
    ClearDblMatMem(BCmat,p+1);
    ClearDblMatMem(ACmat,p+1);
    ClearDblMatMem(ABmat,p+1);
    ClearDblQuadMem(celltotals,p+1,p+1,p+1);
    ClearIntCubeMem(cellcnts,p+1,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan4(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, Ccol, Dcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, FactorD, DataVar, cellstring;
   int i, j, k, m, minA, minB, minC, maxA, maxB, maxC;
   int minD, maxD, rangeA, rangeB, rangeC, rangeD;
   int value;
   int **cellcnts;
   double **ABmat;
   double ***ABCmat;
   double *Atotals, *Btotals, *Ctotals, *Dtotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7;
   double sumxsqr;
   double sumAsqr, sumBsqr, sumCsqr, sumDsqr, SSA, SSB, SSC, SSD;
   double SSbetween, SSwithin, SSres, SStotal;
   double MSa, MSb, MSc, MSd, MSres, MSwithin;
   double data, GrandMean;
   int p, row, col, slice, block;
   double dfa, dfb, dfc, dfres, dfwithin, dftotal, fa, fb, fc;
   double dfd, fd, fres;
   double proba, probb, probc, probd, probres;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = false;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = false;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = false;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();

     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     FactorD = LatinSpecsFrm->DCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Ccol = 0;
    Dcol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == FactorD) Dcol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Dcol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and C
    minA = 1000;
    minB = 1000;
    minC = 1000;
    minD = 1000;
    maxA = -1000;
    maxB = -1000;
    maxC = -1000;
    maxD = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         if (value < minD) minD = value;
         if (value > maxD) maxD = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeD = maxD - minD + 1;

    // check for squareness
    if ( (rangeA != rangeB) || (rangeA != rangeC) || (rangeB != rangeC) )
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblMatMem(ABmat,p+1,p+1);
    GetDblCubeMem(ABCmat,p+1,p+1,p+1);
    GetIntMatMem(cellcnts,p+1,p+1);
    Atotals = new double[p];
    Btotals = new double[p];
    Ctotals = new double[p];
    Dtotals = new double[p];
    Design = new AnsiString *[p];
    for (i = 0; i < p; i++) Design[i] = new AnsiString[p];

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= p; k++)
                ABCmat[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
    {
        for (j = 0; j <= p; j++)
        {
            cellcnts[i][j] = 0;
            ABmat[i][j] = 0.0;
        }
    }

    for (i = 0; i < p; i++)
    {
         Atotals[i] = 0.0;
         Btotals[i] = 0.0;
         Ctotals[i] = 0.0;
         Dtotals[i] = 0.0;
    }

    G = 0.0;
    sumxsqr = 0.0;
    sumAsqr = 0.0;
    sumBsqr = 0.0;
    sumCsqr = 0.0;
    sumDsqr = 0.0;
    SSwithin = 0.0;
    term1 = 0.0;
    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    GrandMean = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         slice = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         block = floor(StrToFloat(MainForm->Grid->Cells[Dcol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[row-1][col-1] = cellcnts[row-1][col-1] + 1;
         ABCmat[row-1][col-1][slice-1] = ABCmat[row-1][col-1][slice-1] + data;
         Atotals[row-1] = Atotals[row-1] + data;
         Btotals[col-1] = Btotals[col-1] + data;
         Ctotals[slice-1] = Ctotals[slice-1] + data;
         Dtotals[block-1] = Dtotals[block-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // collapse c"s into a x b
    for (k = 0; k <= p; k++)
         for (i = 0; i < p; i++)
              for (j = 0; j < p; j++)
                  ABmat[i][j] = ABmat[i][j] + ABCmat[i][j][k];

    // get sum of squared cells
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            SSwithin = SSwithin + (ABmat[i][j] * ABmat[i][j]);

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              if (cellcnts[i][j] != n)
              {
                   ShowMessage("cell sizes are not  equal!");
                   goto cleanup;
              }
         }
    }

    for (i = 0; i < p; i++)
    {
         sumAsqr = sumAsqr + (Atotals[i] * Atotals[i]);
         sumBsqr = sumBsqr + (Btotals[i] * Btotals[i]);
         sumCsqr = sumCsqr + (Ctotals[i] * Ctotals[i]);
         sumDsqr = sumDsqr + (Dtotals[i] * Dtotals[i]);
    }

    G = GrandMean;
    term1 = (G * G) / (double)(n * p * p);
    term2 = sumxsqr;
    term3 = sumAsqr / (double)(n * p);
    term4 = sumBsqr / (double)(n * p);
    term5 = sumCsqr / (double)(n * p);
    term6 = sumDsqr / (double)(n * p);
    term7 = SSwithin / (double)n;
    SSA = term3 - term1;
    SSB = term4 - term1;
    SSC = term5 - term1;
    SSD = term6 - term1;
    SSres = term7 - term3 - term4 - term5 - term6 + (3.0 * term1);
    SSwithin = term2 - term7;
    SStotal = term2 - term1;

    dfa = (double)(p-1);
    dfb = (double)(p-1);
    dfc = (double)(p-1);
    dfd = (double)(p-1);
    dfres = (double)((p-1) * (p-3));
    dfwithin = (double)(p * p * (n - 1));
    dftotal = (double)(n * p * p - 1);
    MSa = SSA / dfa;
    MSb = SSB / dfb;
    MSc = SSC / dfc;
    MSd = SSD / dfd;
    if (dfres > 0) MSres = SSres / dfres;
    MSwithin = SSwithin / dfwithin;
    fa = MSa / MSwithin;
    fb = MSb / MSwithin;
    fc = MSc / MSwithin;
    fd = MSd / MSwithin;
    if (dfres > 0) fres = MSres / MSwithin;
    proba = ftest(dfa,dfwithin,fa);
    probb = ftest(dfb,dfwithin,fb);
    probc = ftest(dfc,dfwithin,fc);
    probd = ftest(dfd,dfwithin,fd);
    if (dfres > 0) probres = ftest(dfres,dfwithin,fres);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Greco-Latin Square Analysis (No Interactions)");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Factor A  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSA,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Factor B  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSB,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Latin Sqr.";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSC,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Greek Sqr.";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSD,dfd,MSd,fd,probd);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Residual  ";
    if (dfres > 0.0)
    {
         sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSres,dfres,MSres,fres,probres);
         cellstring = cellstring + outline;
    }
    else cellstring = cellstring + "    -         -          -         -         -";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Within    ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSwithin, dfwithin, MSwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for Latin Square
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i]));
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i]));
         slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i]));
         Design[row-1][col-1] = "C" + IntToStr(slice);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",Design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show design for Greek Square
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Greek Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i]));
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i]));
         block = StrToInt(Trim(MainForm->Grid->Cells[Dcol][i]));
         Design[row-1][col-1] = "C" + IntToStr(block);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",Design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    for (i = 0; i < p; i++)
    {
        for (j = 0; j < p; j++)
        {
            ABmat[i][p] = ABmat[i][p] + ABmat[i][j];
            ABmat[p][j] = ABmat[p][j] + ABmat[i][j];
        }
    }

    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            ABmat[i][j] = ABmat[i][j] / (double)n;
    for (i = 0; i < p; i++)
        ABmat[i][p] = ABmat[i][p] / (double)(n * p);
    for (j = 0; j < p; j++)
        ABmat[p][j] = ABmat[p][j] / (double)(n * p);

    GrandMean = GrandMean / (double)(p * p * n );
    for (i = 0; i < p; i++)
    {
         Atotals[i] = Atotals[i] / (double)(p * n);
         Btotals[i] = Btotals[i] / (double)(p * n);
         Ctotals[i] = Ctotals[i] / (double)(p * n);
         Dtotals[i] = Dtotals[i] / (double)(p * n);
    }

    // show table of means for ABmat
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",ABmat[i][j]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",ABmat[i][p]);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "Total     ";
    for (j = 0; j < p; j++)
    {
        sprintf(outline," %8.3f ",ABmat[p][j]);
        cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for each variable");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Atotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Btotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorC);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Ctotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= rangeD + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorD);
    cellstring = outline;
    for (i = 1; i <= rangeD; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= rangeD + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < rangeD; j++)
    {
         sprintf(outline," %8.3f ",Dtotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= rangeD + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->ShowModal();

cleanup:
    for (i = 0; i < p; i++) delete[] Design[i];
    delete[] Design;
    delete[] Dtotals;
    delete[] Ctotals;
    delete[] Btotals;
    delete[] Atotals;
    ClearIntMatMem(cellcnts,p+1);
    ClearDblCubeMem(ABCmat,p+1,p+1);
    ClearDblMatMem(ABmat,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan5(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, SbjCol, Grpcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, SubjectFactor, GroupFactor, DataVar, cellstring;
   int i, j, k, m, minA, minB, minGrp, maxA, maxB, maxGrp;
   int rangeA, rangeGrp;
   int value;
   int **cellcnts;
   double **ABmat;
   double ***ABCmat;
   double **GBmat;
   double *Atotals, *Btotals, *Grptotals;
   double **Subjtotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7;
   double sumxsqr;
   double SSbetsubj, SSgroups, SSsubwGrps, SSwithinsubj, SSa, SSb, SSab;
   double SSerrwithin, SStotal, MSgroups, MSsubwGrps, MSa, MSb, MSab;
   double MSerrwithin, DFbetsubj, DFgroups, DFsubwGrps, DFwithinsubj;
   double DFa, DFb, DFab, DFerrwithin, DFtotal;
   double data, GrandMean;
   int p, row, col, subject, group;
   double proba, probb, probab, probgrps;
   double fa, fb, fab, fgroups;
   AnsiString *RowLabels, *ColLabels;
   AnsiString Title;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = false;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = true;
     LatinSpecsFrm->Label6->Visible = false;
     LatinSpecsFrm->Label7->Visible = true;
     LatinSpecsFrm->DinBtn->Visible = false;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = true;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();

     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     SubjectFactor = LatinSpecsFrm->CCodeEdit->Text;
     GroupFactor = LatinSpecsFrm->GroupCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Grpcol = 0;
    SbjCol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == GroupFactor) Grpcol = i;
        if (cellstring == SubjectFactor) SbjCol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Grpcol == 0) || (SbjCol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and Group
    minA = 1000;
    minB = 1000;
    minGrp = 1000;
    maxA = -1000;
    maxB = -1000;
    maxGrp = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         if (value < minGrp) minGrp = value;
         if (value > maxGrp) maxGrp = value;
    }
    rangeA = maxA - minA + 1;
    rangeGrp = maxGrp - minGrp + 1;

    // check for squareness
    if  (rangeA != rangeGrp)
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblMatMem(ABmat,p+1,p+1);
    GetDblCubeMem(ABCmat,p+1,p+1,n+1);
    GetIntMatMem(cellcnts,p+1,p+1);
    Atotals = new double[p+1];
    Btotals = new double[p+1];
    Grptotals = new double[p+1];
    Design = new AnsiString*[p];
    for (i = 0; i < p; i++) Design[i] = new AnsiString[p];
    GetDblMatMem(Subjtotals,p+1,n+1);
    RowLabels = new AnsiString[p+1];
    ColLabels = new AnsiString[n+1];
    GetDblMatMem(GBmat,p+1,p+1);

    for (i = 0; i < p; i++)
    {
         RowLabels[i] = IntToStr(i+1);
         ColLabels[i] = RowLabels[i];
    }
    RowLabels[p] = "Total";
    ColLabels[p] = "Total";

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= n; k++)
                ABCmat[i][j][k] = 0.0;

     for (i = 0; i <= p; i++)
    {
        for (j = 0; j <= p; j++)
        {
            cellcnts[i][j] = 0;
            ABmat[i][j] = 0.0;
            GBmat[i][j] = 0.0;
        }
    }

     for (i = 0; i <= p; i++)
    {
         Atotals[i] = 0.0;
         Btotals[i] = 0.0;
         Grptotals[i] = 0.0;
    }

     for (i = 0; i <= p; i++)
        for (j = 0; j <= n; j++)
            Subjtotals[i][j] = 0.0;

//    G = 0.0;
    sumxsqr = 0.0;
    term1 = 0.0;
//    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    GrandMean = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         group = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         subject = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[group-1][row-1] = cellcnts[group-1][row-1] + 1;
         ABCmat[group-1][row-1][subject-1] = ABCmat[group-1][row-1][subject-1] + data;
         Subjtotals[group-1][subject-1] = Subjtotals[group-1][subject-1] + data;
         GBmat[group-1][col-1] = GBmat[group-1][col-1] + data;
         Atotals[col-1] = Atotals[col-1] + data;
         Btotals[group-1] = Btotals[group-1] + data;
         Grptotals[group-1] = Grptotals[group-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              if (cellcnts[i][j] != n)
              {
                   ShowMessage("cell sizes are not  equal!");
                   goto cleanup;
              }
         }
    }

    // collapse subjects"s into group x a matrix
    for (i = 0; i < p; i++) // group
         for (j = 0; j < p; j++) // factor a
              for (k = 0; k < n; k++) // subject
                  ABmat[i][j] = ABmat[i][j] + ABCmat[i][j][k];

    // get marginal totals for ABmat and GBmat
    for (i = 0; i < p; i++)
    {
        for (j = 0; j < p; j++)
        {
            ABmat[p][j] = ABmat[p][j] + ABmat[i][j];
            ABmat[i][p] = ABmat[i][p] + ABmat[i][j];
            GBmat[p][j] = GBmat[p][j] + GBmat[i][j];
            GBmat[i][p] = GBmat[i][p] + GBmat[i][j];
        }
    }

    // get grand total for ABmat and GBmat
    for (i = 0; i < p; i++)
    {
         ABmat[p][p] = ABmat[p][p] + ABmat[p][i];
         GBmat[p][p] = GBmat[p][p] + GBmat[p][i];
    }

    // Get marginal totals for Subjtotals
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < n; j++)
         {
              Subjtotals[p][j] = Subjtotals[p][j] + Subjtotals[i][j];
              Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];
         }
    }
    for (i = 0; i < p; i++) Subjtotals[p][n] = Subjtotals[p][n] + Subjtotals[i][n];
    // test block
    FrmOutPut->RichOutPut->Lines->Add("Sums for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Group (rows) times A Factor (columns) sums";
    ArrayPrint(ABmat,p+1, p+1, "Group (rows) times A Factor (columns) sums",
               RowLabels, ColLabels, "ANOVA SUMS");
    cellstring = "Group (rows) times B (cells Factor) sums";
    ArrayPrint(GBmat,p+1, p+1, "Group (rows) times B (cells Factor) sums",
               RowLabels, ColLabels, "ANOVA SUMS");
    Title = "Groups (rows) times Subjects (columns) matrix";
    for (i = 0; i < n; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[n] = "Total";
    ArrayPrint(Subjtotals,p+1, n+1, "Groups (rows) times Subjects (columns) matrix",
               RowLabels, ColLabels, "ANOVA SUMS");
    FrmOutPut->ShowModal();

    // get squared sum of subject"s totals in each group
    for (i = 0; i < p; i++) // group
              term7 = term7 + (Subjtotals[i][n] * Subjtotals[i][n]);
    term7 = term7 / (double)(n*p); // Sum G^2 sub k

    // now square each person score in each group and get sum for group
    for (i = 0; i < p; i++)
        for (j = 0; j < n; j++)
            Subjtotals[i][j] = Subjtotals[i][j] * Subjtotals[i][j];
    for (i = 0; i < p; i++) Subjtotals[i][n] = 0.0;
    for (i = 0; i < p; i++)
        for (j = 0; j < n; j++)
            Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];
    for (i = 0; i < p; i++) term6 = term6 + Subjtotals[i][n];
    SSsubwGrps = term6 / (double)p - term7;

    // get correction term
    term1 = (GrandMean * GrandMean) / (double)(n * p * p);

//    term2 = sumxsqr;

    // get sum of squared a"s for term3
    for (j = 0; j < p; j++)
        term3 = term3 + (ABmat[p][j] * ABmat[p][j]);
    term3 = term3 / (double)(n * p);

    // get sum of squared groups for term4
    for (i = 0; i < p; i++)
        term4 = term4 + (ABmat[i][p] * ABmat[i][p]);
    term4 = term4 / (double)(n * p);

    // get squared sum of b"s (across groups) for term5
    for (j = 0; j < p; j++)
        term5 = term5 + (GBmat[p][j] * GBmat[p][j]);
    term5 = term5 / (double)(n * p);

    SSgroups = term4 - term1;
    SSbetsubj = SSgroups + SSsubwGrps;
    SStotal = sumxsqr - term1;
    SSwithinsubj = SStotal - SSbetsubj;
    SSa = term3 - term1;
    SSb = term5 - term1;

    // get sum of squared AB cells for term6
    term6 = 0.0;
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            term6 = term6 + (ABmat[i][j] * ABmat[i][j]);
    term6 = term6 / (double)n;
    SSab = term6 - term3 - term5 + term1;
    SSab = SSab - SSgroups;
    SSerrwithin = ( sumxsqr - term6) - SSsubwGrps;

    // record degrees of freedom for sources
    DFbetsubj = (double)(n * p - 1);
    DFsubwGrps = (double)(p * (n-1));
    DFgroups = (double)(p - 1);
    DFtotal = (double)(n * p * p - 1);
    DFwithinsubj = (double)(n * p * (p-1));
    DFa = (double)(p - 1);
    DFb = (double)(p - 1);
    DFab = (double)((p - 1) * (p - 2));
    DFerrwithin = (double)(p * (n - 1) * (p - 1));

    MSsubwGrps = SSsubwGrps / DFsubwGrps;
    MSgroups = SSgroups / DFgroups;
    MSa = SSa / DFa;
    MSb = SSb / DFb;
    MSab = SSab / DFab;
    MSerrwithin = SSerrwithin / DFerrwithin;
    fgroups = MSgroups / MSsubwGrps;
    fa = MSa / MSerrwithin;
    fb = MSb / MSerrwithin;
    fab = MSab / MSerrwithin;
    probgrps = ftest(DFgroups,DFsubwGrps,fgroups);
    proba = ftest(DFa,DFerrwithin,fa);
    probb = ftest(DFb,DFerrwithin,fb);
    probab = ftest(DFab,DFerrwithin,fab);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 5 (Partial Interactions)");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Betw.Subj.";
    sprintf(outline,"%9.3f %9.0f",SSbetsubj,DFbetsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Groups   ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSgroups,DFgroups,MSgroups,fgroups,probgrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Subj.w.g.";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSsubwGrps,DFsubwGrps,MSsubwGrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Within Sub";
    sprintf(outline,"%9.3f %9.0f",SSwithinsubj,DFwithinsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor A ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSa,DFa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor B ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSb,DFb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor AB";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSab,DFab,MSab,fab,probab);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Error w. ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSerrwithin,DFerrwithin,MSerrwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, DFtotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for Square
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i])); // A (column) effect
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i])); // B (cell) effect
         group = StrToInt(Trim(MainForm->Grid->Cells[Grpcol][i])); // group (row)
         Design[group-1][row-1] = "B" + IntToStr(col);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",Design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            ABmat[i][j] = ABmat[i][j] / (double)n;
   for (i = 0; i < p; i++)
        ABmat[i][p] = ABmat[i][p] / (double)(n * p);
    for (j = 0; j < p; j++)
        ABmat[p][j] = ABmat[p][j] / (double)(n * p);

    GrandMean = GrandMean / (double)(p * p * n );
    for (i = 0; i < p; i++)
    {
         Atotals[i] = Atotals[i] / (double)(p * n);
         Btotals[i] = Btotals[i] / (double)(p * n);
         Grptotals[i] = Grptotals[i] / (double)(p * n);
//         Dtotals[i] = Dtotals[i] / (p * n);
    }

    // show table of means for ABmat
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",ABmat[i][j]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",ABmat[i][p]);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "Total     ";
    for (j = 0; j < p; j++)
    {
        sprintf(outline," %8.3f ",ABmat[p][j]);
        cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for each variable");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Atotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Btotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Grptotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->ShowModal();

cleanup:
    ClearDblMatMem(GBmat,p+1);
    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(Subjtotals,p+1);
    for (i = 0; i < p; i++) delete[]Design[i];
    delete[] Design;
    delete[] Grptotals;
    delete[] Btotals;
    delete[] Atotals;
    ClearIntMatMem(cellcnts,p+1);;
    ClearDblCubeMem(ABCmat,p+1,p+1);
    ClearDblMatMem(ABmat,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan6(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, SbjCol, Grpcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, SubjectFactor, GroupFactor, DataVar, cellstring;
   int i, j, k, m, minA, minB, minGrp, maxA, maxB, maxGrp;
   int rangeA, rangeB, rangeGrp;
   int value;
   int **cellcnts;
   double **ABmat;
   double ***ABCmat;
   double **GBmat;
   double *Atotals, *Btotals, *Grptotals;
   double **Subjtotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7;
   double sumxsqr;
   double SSbetsubj, SSgroups, SSsubwGrps, SSwithinsubj, SSa, SSb, SSab;
   double SSerrwithin, SStotal, MSgroups, MSsubwGrps, MSa, MSb, MSab;
   double MSerrwithin, dfbetsubj, dfgroups, dfsubwGrps, dfwithinsubj;
   double dfa, dfb, dfab, dferrwithin, dftotal;
   double data, GrandMean;
   int p, row, col, subject, group;
   double proba, probb, probab, probgrps;
   double fa, fb, fab, fgroups;
   AnsiString *RowLabels, *ColLabels;
   AnsiString Title;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = false;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = true;
     LatinSpecsFrm->Label6->Visible = false;
     LatinSpecsFrm->Label7->Visible = true;
     LatinSpecsFrm->DinBtn->Visible = false;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = true;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     SubjectFactor = LatinSpecsFrm->CCodeEdit->Text;
     GroupFactor = LatinSpecsFrm->GroupCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Grpcol = 0;
    SbjCol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == GroupFactor) Grpcol = i;
        if (cellstring == SubjectFactor) SbjCol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Grpcol == 0) || (SbjCol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B and Group
    minA = 1000;
    minB = 1000;
    minGrp = 1000;
    maxA = -1000;
    maxB = -1000;
    maxGrp = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         if (value < minGrp) minGrp = value;
         if (value > maxGrp) maxGrp = value;
    }
    rangeA = maxA - minA + 1;
//    rangeB = maxB - minB + 1;
    rangeGrp = maxGrp - minGrp + 1;

    // check for squareness
    if  (rangeA != rangeGrp)
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblMatMem(ABmat,p+1,p+1);
    GetDblCubeMem(ABCmat,p+1,p+1,n+1);
    GetIntMatMem(cellcnts,p+1,p+1);
    Atotals = new double[p+1];
    Btotals = new double[p+1];
    Grptotals = new double[p+1];
    Design = new AnsiString*[p];
    for (i = 0; i < p; i++) Design[i] = new AnsiString[p];
    GetDblMatMem(Subjtotals,p+1,n+1);
    RowLabels = new AnsiString[p+1];
    ColLabels = new AnsiString[n+1];
    GetDblMatMem(GBmat,p+1,p+1);

    for (i = 0; i < p; i++)
    {
         RowLabels[i] = IntToStr(i+1);
         ColLabels[i] = RowLabels[i];
    }
    RowLabels[p] = "Total";
    ColLabels[p] = "Total";

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= n; k++)
                ABCmat[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
    {
        for (j = 0; j <= p; j++)
        {
            cellcnts[i][j] = 0;
            ABmat[i][j] = 0.0;
            GBmat[i][j] = 0.0;
        }
    }

    for (i = 0; i <= p; i++)
    {
         Atotals[i] = 0.0;
         Btotals[i] = 0.0;
         Grptotals[i] = 0.0;
    }

    for (i = 0; i <= p; i++)
        for (j = 0; j <= n; j++)
            Subjtotals[i][j] = 0.0;

//    G = 0.0;
    sumxsqr = 0.0;
    term1 = 0.0;
//    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    GrandMean = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         group = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         subject = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[group-1][row-1] = cellcnts[group-1][row-1] + 1;
         ABCmat[group-1][row-1][subject-1] = ABCmat[group-1][row-1][subject-1] + data;
         Subjtotals[group-1][subject-1] = Subjtotals[group-1][subject-1] + data;
         GBmat[group-1][col-1] = GBmat[group-1][col-1] + data;
         Atotals[col-1] = Atotals[col-1] + data;
         Btotals[group-1] = Btotals[group-1] + data;
         Grptotals[group-1] = Grptotals[group-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              if (cellcnts[i][j] != n)
              {
                   ShowMessage("cell sizes are not  equal!");
                   goto cleanup;
              }
         }
    }

    // collapse subjects"s into group x a matrix
    for (i = 0; i < p; i++) // group
         for (j = 0; j < p; j++) // factor a
              for (k = 0; k < n; k++) // subject
                  ABmat[i][j] = ABmat[i][j] + ABCmat[i][j][k];

    // get marginal totals for ABmat and GBmat
    for (i = 0; i < p; i++)
    {
        for (j = 0; j < p; j++)
        {
            ABmat[p][j] = ABmat[p][j] + ABmat[i][j];
            ABmat[i][p] = ABmat[i][p] + ABmat[i][j];
            GBmat[p][j] = GBmat[p][j] + GBmat[i][j];
            GBmat[i][p] = GBmat[i][p] + GBmat[i][j];
        }
    }

    // get grand total for ABmat and GBmat
    for (i = 0; i < p; i++)
    {
         ABmat[p][p] = ABmat[p][p] + ABmat[p][i];
         GBmat[p][p] = GBmat[p][p] + GBmat[p][i];
    }

    // Get marginal totals for Subjtotals
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < n; j++)
         {
              Subjtotals[p][j] = Subjtotals[p][j] + Subjtotals[i][j];
              Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];
         }
    }
    for (i = 0; i < p; i++) Subjtotals[p][n] = Subjtotals[p][n] + Subjtotals[i][n];

    // test block
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 6");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sums for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Group - C (rows) times A Factor (columns) sums";
    ArrayPrint(ABmat,p+1, p+1, "ANOVA SUMS", RowLabels, ColLabels,
               "Latin Squares Repeated Analysis Plan 6");
    cellstring = "Group - C (rows) times B (cells Factor) sums";
    ArrayPrint(GBmat,p+1, p+1, "ANOVA SUMS", RowLabels, ColLabels,
               "Group - C (rows) times B (cells Factor) sums");
    Title = "Group - C (rows) times Subjects (columns) matrix";
    for (i = 0; i < n; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[n] = "Total";
    ArrayPrint(Subjtotals,p+1, n+1, "ANOVA SUMS", RowLabels, ColLabels,
               "Group - C (rows) times Subjects (columns) matrix");
    FrmOutPut->ShowModal();

    // get squared sum of subject"s totals in each group
    for (i = 0; i < p; i++) // group
              term7 = term7 + (Subjtotals[i][n] * Subjtotals[i][n]);
    term7 = term7 / (double)(n*p); // Sum G^2 sub k

    // now square each person score in each group and get sum for group
    for (i = 0; i < p; i++)
        for (j = 0; j < n; j++)
            Subjtotals[i][j] = Subjtotals[i][j] * Subjtotals[i][j];
    for (i = 0; i < p; i++) Subjtotals[i][n] = 0.0;
    for (i = 0; i < p; i++)
        for (j = 0; j < n; j++)
            Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];
    for (i = 0; i < p; i++) term6 = term6 + Subjtotals[i][n];
    SSsubwGrps = term6 / (double)p - term7;

    // get correction term
    term1 = (GrandMean * GrandMean) / (double)(n * p * p);

//    term2 = sumxsqr;

    // get sum of squared a"s for term3
    for (j = 0; j < p; j++)
        term3 = term3 + (ABmat[p][j] * ABmat[p][j]);
    term3 = term3 / (double)(n * p);

    // get sum of squared groups for term4
    for (i = 0; i < p; i++)
        term4 = term4 + (ABmat[i][p] * ABmat[i][p]);
    term4 = term4 / (double)(n * p);

    // get squared sum of b"s (across groups) for term5
    for (j = 0; j < p; j++)
        term5 = term5 + (GBmat[p][j] * GBmat[p][j]);
    term5 = term5 / (double)(n * p);

    SSgroups = term4 - term1;
    SSbetsubj = SSgroups + SSsubwGrps;
    SStotal = sumxsqr - term1;
    SSwithinsubj = SStotal - SSbetsubj;
    SSa = term3 - term1;
    SSb = term5 - term1;

    // get sum of squared AB cells for term6
    term6 = 0.0;
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            term6 = term6 + (ABmat[i][j] * ABmat[i][j]);
    term6 = term6 / (double)n;
    SSab = term6 - term3 - term5 + term1;
    SSab = SSab - SSgroups;
    SSerrwithin = ( sumxsqr - term6) - SSsubwGrps;

    // record degrees of freedom for sources
    dfbetsubj = (double)(n * p - 1);
    dfsubwGrps = (double)(p * (n-1));
    dfgroups = (double)(p - 1);
    dftotal = (double)(n * p * p - 1);
    dfwithinsubj = (double)(n * p * (p-1));
    dfa = (double)(p - 1);
    dfb = (double)(p - 1);
    dfab = (double)((p - 1) * (p - 2));
    dferrwithin = (double)(p * (n - 1) * (p - 1));

    MSsubwGrps = SSsubwGrps / dfsubwGrps;
    MSgroups = SSgroups / dfgroups;
    MSa = SSa / dfa;
    MSb = SSb / dfb;
    MSab = SSab / dfab;
    MSerrwithin = SSerrwithin / dferrwithin;
    fgroups = MSgroups / MSsubwGrps;
    fa = MSa / MSerrwithin;
    fb = MSb / MSerrwithin;
    fab = MSab / MSerrwithin;
    probgrps = ftest(dfgroups,dfsubwGrps,fgroups);
    proba = ftest(dfa,dferrwithin,fa);
    probb = ftest(dfb,dferrwithin,fb);
    probab = ftest(dfab,dferrwithin,fab);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 6");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Betw.Subj.";
    sprintf(outline,"%9.3f %9.0f",SSbetsubj,dfbetsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor C ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSgroups,dfgroups,MSgroups,fgroups,probgrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Subj.w.g.";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSsubwGrps,dfsubwGrps,MSsubwGrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Within Sub";
    sprintf(outline,"%9.3f %9.0f",SSwithinsubj,dfwithinsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor A ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSa,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor B ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSb,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Residual ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSab,dfab,MSab,fab,probab);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Error w. ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSerrwithin,dferrwithin,MSerrwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for Square
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "  G    C  ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i])); // A (column) effect
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i])); // B (cell) effect
         group = StrToInt(Trim(MainForm->Grid->Cells[Grpcol][i])); // group (row)
         Design[group-1][row-1] = "B" + IntToStr(col);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"%3d  %3d  ",i+1,i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",Design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            ABmat[i][j] = ABmat[i][j] / (double)n;
    for (i = 0; i < p; i++)
        ABmat[i][p] = ABmat[i][p] / (double)(n * p);
    for (j = 0; j < p; j++)
        ABmat[p][j] = ABmat[p][j] / (double)(n * p);

    GrandMean = GrandMean / (double)(p * p * n );
    for (i = 0; i < p; i++)
    {
         Atotals[i] = Atotals[i] / (double)(p * n);
         Btotals[i] = Btotals[i] / (double)(p * n);
         Grptotals[i] = Grptotals[i] / (double)(p * n);
    }

    // show table of means for ABmat
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",ABmat[i][j]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",ABmat[i][p]);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "Total     ";
    for (j = 0; j < p; j++)
    {
        sprintf(outline," %8.3f ",ABmat[p][j]);
        cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for each variable");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Atotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Btotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Grptotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->ShowModal();

cleanup:
    ClearDblMatMem(GBmat,p+1);
    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(Subjtotals,p+1);
    for (i = 0; i < p; i++) delete[]Design[i];
    delete[] Design;
    delete[] Grptotals;
    delete[] Btotals;
    delete[] Atotals;
    ClearIntMatMem(cellcnts,p+1);
    ClearDblCubeMem(ABCmat,p+1,p+1);
    ClearDblMatMem(ABmat,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan7(TObject *Sender)
{
   int n; // no. of subjects per cell
   int Acol, Bcol, Ccol, SbjCol, Grpcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, SubjectFactor, FactorC, GroupFactor;
   AnsiString DataVar, cellstring;
   int i, j, k, m, minA, minB, minC, minGrp, maxA, maxB, maxC, maxGrp;
   int rangeA, rangeB, rangeC, rangeGrp, value;
   int **cellcnts;
   double **ABmat;
   double ***ABCmat;
   double **GBmat;
   double **GCmat;
   double *Atotals, *Btotals, *Ctotals, *Grptotals;
   double **Subjtotals;
   AnsiString **Design;
   double G, term1, term2, term3, term4, term5, term6, term7, term8, term9;
   double sumxsqr;
   double SSbetsubj, SSgroups, SSsubwGrps, SSwithinsubj, SSa, SSb, SSc, SSab;
   double SSerrwithin, SStotal, MSgroups, MSsubwGrps, MSa, MSb, MSc, MSab;
   double MSerrwithin, dfbetsubj, dfgroups, dfsubwGrps, dfwithinsubj;
   double dfa, dfb, dfc, dfab, dferrwithin, dftotal;
   double data, GrandMean;
   int p, row, col, slice, subject, group;
   double proba, probb, probc, probab, probgrps;
   double fa, fb, fc, fab, fgroups;
   AnsiString *RowLabels, *ColLabels;
   AnsiString Title;
   char outline[121];

     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = true;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = true;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = true;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text));
     if (n <= 0)
     {
          ShowMessage("Please specify the number of cases per cell.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     SubjectFactor = LatinSpecsFrm->DCodeEdit->Text;
     GroupFactor = LatinSpecsFrm->GroupCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Ccol = 0;
    Grpcol = 0;
    SbjCol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == GroupFactor) Grpcol = i;
        if (cellstring == SubjectFactor) SbjCol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Grpcol == 0) || (SbjCol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B, C and Group
    minA = 1000;
    minB = 1000;
    minGrp = 1000;
    maxA = -1000;
    maxB = -1000;
    minC = 1000;
    maxC = -1000;
    maxGrp = -1000;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         if (value < minGrp) minGrp = value;
         if (value > maxGrp) maxGrp = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeGrp = maxGrp - minGrp + 1;

    // check for squareness
    if  ((rangeA != rangeB) || (rangeA != rangeC) || (rangeA != rangeGrp))
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblMatMem(ABmat,p+1,p+1);
    GetDblCubeMem(ABCmat,p+1,p+1,n+1);
    GetIntMatMem(cellcnts,p+1,p+1);
    Atotals = new double[p+1];
    Btotals = new double[p+1];
    Ctotals = new double[p+1];
    Grptotals = new double[p+1];
    Design = new AnsiString *[p];
    for (i = 0; i < p; i++) Design[i] = new AnsiString[p];
    GetDblMatMem(Subjtotals,p+1,n+1);
    RowLabels = new AnsiString[p+1];
    ColLabels = new AnsiString[n+1];
    GetDblMatMem(GBmat,p+1,p+1);
    GetDblMatMem(GCmat,p+1,p+1);

    for (i = 0; i < p; i++)
    {
         RowLabels[i] = IntToStr(i+1);
         ColLabels[i] = RowLabels[i];
    }
    RowLabels[p] = "Total";
    ColLabels[p] = "Total";

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= n; k++)
                ABCmat[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
    {
       for (j = 0; j <= p; j++)
        {
            cellcnts[i][j] = 0;
            ABmat[i][j] = 0.0;
            GBmat[i][j] = 0.0;
            GCmat[i][j] = 0.0;
        }
    }

    for (i = 0; i <= p; i++)
    {
         Atotals[i] = 0.0;
         Btotals[i] = 0.0;
         Ctotals[i] = 0.0;
         Grptotals[i] = 0.0;
    }

    for (i = 0; i <= p; i++)
        for (j = 0; j <= n; j++)
            Subjtotals[i][j] = 0.0;

//    G = 0.0;
    sumxsqr = 0.0;
    term1 = 0.0;
    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    term8 = 0.0;
    term9 = 0.0;
    GrandMean = 0.0;

    //  Read in the data
    for (i = 1; i <= NoCases; i++)
    {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         slice = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         group = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         subject = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][i]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][i]);
         cellcnts[group-1][row-1] = cellcnts[group-1][row-1] + 1;
         ABCmat[group-1][row-1][slice-1] = ABCmat[group-1][row-1][slice-1] + data;
         Subjtotals[group-1][subject-1] = Subjtotals[group-1][subject-1] + data;
         GBmat[group-1][col-1] = GBmat[group-1][col-1] + data;
         GCmat[group-1][slice-1] = GCmat[group-1][slice-1] + data;
         Atotals[row-1] = Atotals[row-1] + data;
         Btotals[col-1] = Btotals[col-1] + data;
         Ctotals[slice-1] = Ctotals[slice-1] + data;
         Grptotals[group-1] = Grptotals[group-1] + data;
         sumxsqr = sumxsqr + (data * data);
         GrandMean = GrandMean + data;
    }

    // check for equal cell counts
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              if (cellcnts[i][j] != n)
              {
                   ShowMessage("cell sizes are not  equal!");
                   goto cleanup;
              }
         }
    }

    // collapse slices into group x a matrix
    // result is the group times A matrix with BC cells containing n cases each
    for (i = 0; i < p; i++) // group
         for (j = 0; j < p; j++) // factor a
              for (k = 0; k < n; k++) // factor c
                  ABmat[i][j] = ABmat[i][j] + ABCmat[i][j][k];

    // get marginal totals for ABmat, GBmat and GCmat
    for (i = 0; i < p; i++)
    {
        for (j = 0; j < p; j++)
        {
            ABmat[p][j] = ABmat[p][j] + ABmat[i][j];
            ABmat[i][p] = ABmat[i][p] + ABmat[i][j];
            GBmat[p][j] = GBmat[p][j] + GBmat[i][j];
            GBmat[i][p] = GBmat[i][p] + GBmat[i][j];
            GCmat[p][j] = GCmat[p][j] + GCmat[i][j];
            GCmat[i][p] = GCmat[i][p] + GCmat[i][j];
        }
    }

    // get grand total for ABmat, GBmat and GCmat
    for (i = 0; i < p; i++)
    {
         ABmat[p][p] = ABmat[p][p] + ABmat[p][i];
         GBmat[p][p] = GBmat[p][p] + GBmat[p][i];
         GCmat[p][p] = GCmat[p][p] + GCmat[p][i];
    }

    // Get marginal totals for Subjtotals
    for (i = 0; i < p; i++) // groups 1-p
    {
         for (j = 0; j < n; j++) // subjects 1-n
         {
              Subjtotals[p][j] = Subjtotals[p][j] + Subjtotals[i][j];
              Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];
         }
    }
    for (i = 0; i < p; i++) Subjtotals[p][n] = Subjtotals[p][n] + Subjtotals[i][n];

    // test block
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 7 (superimposed squares)");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sums for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Group (rows) times A Factor (columns) sums";
    ArrayPrint(ABmat, p+1, p+1, "SUMS", RowLabels, ColLabels,
               "Group (rows) times A Factor (columns) sums");
    cellstring = "Group (rows) times B (cells Factor) sums";
    ArrayPrint(GBmat, p+1, p+1, "SUMS", RowLabels, ColLabels,
               "Group (rows) times B (cells Factor) sums");
    cellstring = "Group (rows) times C (cells Factor) sums";
    ArrayPrint(GCmat, p+1, p+1, "SUMS", RowLabels, ColLabels,
               "Group (rows) times C (cells Factor) sums");
    for (i = 0; i < n; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[n] = "Total";
    Title = "Group (rows) times Subjects (columns) sums";
    ArrayPrint(GCmat, p+1, p+1, "SUMS", RowLabels, ColLabels,
               "Group (rows) times Subjects (columns) sums");
    FrmOutPut->ShowModal();

    // get squared sum of subject"s totals in each group
    for (i = 0; i < p; i++) // group
              term7 = term7 + (Subjtotals[i][n] * Subjtotals[i][n]);
    term7 = term7 / (double)(n*p); // Sum G^2 sub k

    // now square each person score in each group and get sum for group
    for (i = 0; i < p; i++) // groups
        for (j = 0; j < n; j++) // subjects
            Subjtotals[i][j] = Subjtotals[i][j] * Subjtotals[i][j];
    for (i = 0; i < p; i++) Subjtotals[i][n] = 0.0; // clear group totals

    // get sum of squared person scores in each group
    for (i = 0; i < p; i++) // groups
        for (j = 0; j < n; j++) // subjects
            Subjtotals[i][n] = Subjtotals[i][n] + Subjtotals[i][j];

    // get sum of squares for subjects within groups
    for (i = 0; i < p; i++) term6 = term6 + Subjtotals[i][n];
    SSsubwGrps = (term6 / (double)p) - term7;

    // get correction term and term for total sum of squares
    term1 = (GrandMean * GrandMean) / (double)(n * p * p);
    term2 = sumxsqr;

    // get sum of squared groups for term4 of sum of squares for groups
    for (i = 0; i < p; i++)
        term4 = term4 + (Grptotals[i] * Grptotals[i]);
    term4 = term4 / (double)(n * p);

    // get sum of squared a"s for term3
    for (j = 0; j < p; j++) // levels of a
        term3 = term3 + (Atotals[j] * Atotals[j]);
    term3 = term3 / (double)(n * p);

    // get squared sum of b"s (across groups) for term5 of sum of squares b
    for (j = 0; j < p; j++)
        term5 = term5 + (Btotals[j] * Btotals[j]);
    term5 = term5 / (double)(n * p);

    // get squared sum of c"s (across groups) for term8 of SS for c
    for (j = 0; j < p; j++)
        term8 = term8 + (Ctotals[j] * Ctotals[j]);
    term8 = term8 / (double)(n * p);

    SSgroups = term4 - term1;
    SSbetsubj = SSgroups + SSsubwGrps;
    SStotal = term2 - term1;
    SSwithinsubj = SStotal - SSbetsubj;
    SSa = term3 - term1;
    SSb = term5 - term1;
    SSc = term8 - term1;

    // get sum of squared AB cells for term6
    term6 = 0.0;
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            term6 = term6 + (ABmat[i][j] * ABmat[i][j]);
    term9 = term6 / (double)n - term1;
    term6 = sumxsqr - (term6 / (double)n); // SS within cells from sum squared x"s
    SSerrwithin = term6 - SSsubwGrps;
    SSab = term9 - (SSa + SSb + SSc + SSgroups); // residual

    // record degrees of freedom for sources
    dfbetsubj = (double)(n * p - 1);
    dfsubwGrps = (double)(p * (n-1));
    dfgroups = (double)(p - 1);
    dftotal = (double)(n * p * p - 1);
    dfwithinsubj = (double)(n * p * (p-1));
    dfa = (double)(p - 1);
    dfb = (double)(p - 1);
    dfc = (double)(p - 1);
    dfab = (double)((p - 1) * (p - 3));
    dferrwithin = (double)(p * (n - 1) * (p - 1));

    MSsubwGrps = SSsubwGrps / dfsubwGrps;
    MSgroups = SSgroups / dfgroups;
    MSa = SSa / dfa;
    MSb = SSb / dfb;
    MSc = SSc / dfc;
    if (dfab > 0) MSab = SSab / dfab;
    MSerrwithin = SSerrwithin / dferrwithin;
    fgroups = MSgroups / MSsubwGrps;
    fa = MSa / MSerrwithin;
    fb = MSb / MSerrwithin;
    fc = MSc / MSerrwithin;
    if (dfab > 0) fab = MSab / MSerrwithin;
    probgrps = ftest(dfgroups,dfsubwGrps,fgroups);
    proba = ftest(dfa,dferrwithin,fa);
    probb = ftest(dfb,dferrwithin,fb);
    probc = ftest(dfc,dferrwithin,fc);
    probab = ftest(dfab,dferrwithin,fab);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 7 (superimposed squares)");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Betw.Subj.";
    sprintf(outline,"%9.3f %9.0f",SSbetsubj,dfbetsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Groups   ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSgroups,dfgroups,MSgroups,fgroups,probgrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Subj.w.g.";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSsubwGrps,dfsubwGrps,MSsubwGrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Within Sub";
    sprintf(outline,"%9.3f %9.0f",SSwithinsubj,dfwithinsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor A ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSa,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor B ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSb,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor C ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSc,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " residual ";
    if (dfab > 0)
    {
       sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSab,dfab,MSab,fab,probab);
       cellstring = cellstring + outline;
    }
    else
    {
       sprintf(outline,"     -    %9.0f      -",dfab);
       cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Error w. ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSerrwithin,dferrwithin,MSerrwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");

    // show design for Square
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i])); // A (column) effect
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i])); // B (cell) effect
         slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i])); // C (cell) effect
         group = StrToInt(Trim(MainForm->Grid->Cells[Grpcol][i])); // group (row)
         Design[group-1][row-1] = "BC" + IntToStr(col) + IntToStr(slice);
    }
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
              sprintf(outline,"%5s",Design[i][j]);
              cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // get means
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            ABmat[i][j] = ABmat[i][j] / (double)n;
    for (i = 0; i < p; i++)
        ABmat[i][p] = ABmat[i][p] / (double)(n * p);
    for (j = 0; j < p; j++)
        ABmat[p][j] = ABmat[p][j] / (double)(n * p);

    GrandMean = GrandMean / (double)(p * p * n );
    for (i = 0; i < p; i++)
    {
         Atotals[i] = Atotals[i] / (double)(p * n);
         Btotals[i] = Btotals[i] / (double)(p * n);
         Ctotals[i] = Ctotals[i] / (double)(p * n);
         Grptotals[i] = Grptotals[i] / (double)(p * n);
    }

    // show table of means for ABmat
    // means for Groups by A matrix
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Cell means and totals");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for(i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 0; i < p; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline," %8.3f ",ABmat[i][j]);
             cellstring = cellstring + outline;
         }
         sprintf(outline," %8.3f ",ABmat[i][p]);
         cellstring = cellstring + outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "Total     ";
    for (j = 0; j < p; j++)
    {
        sprintf(outline," %8.3f ",ABmat[p][j]);
        cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // show category means
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for each variable");
    FrmOutPut->RichOutPut->Lines->Add("");

    // factor A means
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for(i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Atotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // means for B
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorB);
    cellstring = outline;
    for(i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Btotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // C means
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorC);
    cellstring = outline;
    for(i = 1; i <= p; i++)
    {
        sprintf(outline,"   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline, " %8.3f ",Ctotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++)cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);

    // Group means
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline, "   %3d    ",i);
        cellstring = cellstring + outline;
    }
    cellstring = cellstring + "    Total";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "          ";
    for (j = 0; j < p; j++)
    {
         sprintf(outline," %8.3f ",Grptotals[j]);
         cellstring = cellstring + outline;
    }
    sprintf(outline," %8.3f ",GrandMean);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "----------";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->ShowModal();

cleanup:
    ClearDblMatMem(GCmat,p+1);
    ClearDblMatMem(GBmat,p+1);
    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(Subjtotals,p+1);
    for (i = 0; i < p; i++) delete[] Design[i];
    delete[] Design;
    delete[] Grptotals;
    delete[] Ctotals;
    delete[] Btotals;
    delete[] Atotals;
    ClearIntMatMem(cellcnts,p+1);
    ClearDblCubeMem(ABCmat,p+1,p+1);
    ClearDblMatMem(ABmat,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan8(TObject *Sender)
{
   int row, col, slice, group, index;
   int Acol, Bcol, Ccol, SbjCol, Grpcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, SubjectFactor, GroupFactor;
   AnsiString DataVar, cellstring;
   int i, j, k, m, minA, minB, minC, minGrp, maxA, maxB, maxC, maxGrp;
   int n, subject, nosubjects, rangeA, rangeB, rangeC, rangeGrp;
   int p, q, rows, value;
   double ***ABC, ***AGC;
   double **AB, **AC, **BC, **RC;
   double *A, *B, *C, *Persons, *Gm, *R;
   int *cellcnts;
   AnsiString **Design;
   AnsiString *RowLabels, *ColLabels;
   double G, sumxsqr, sumAsqr, sumBsqr, sumCsqr, sumABsqr, sumACsqr;
   double sumBCsqr, sumABCsqr, sumPsqr, sumGmsqr, sumRsqr;
   double SSbetsubj, SSc, SSgrpswc, SSres, SSsubwgrps, SSwsubj, SSa;
   double SSwithinsubj, SSerrwithin;
   double SSb, SSac, SSbc, SSerrorwithin, SStotal;
   double term1, term2, term3, term4, term5, term6, term7, term8, term9, term10;
   double term11, term12;
   double dfc, dfrows, dfcxrow, dfsubwgrps, dfwithinsubj, dfa, dfb,dfac;
   double dfbc, dfres, dferrwithin, dfgrpswc, dftotal, dfbetsubj;
   double MSbetweensubj, MSc, MSrows, MSsubwgrps, MSwsubj, MSa;
   double MSb, MSac, MSbc, MSgrpswc, MSres, MSerrwithin, MStotal;
   double fc, fgrpswc, fsubwgrps, fa, fb, fac, fbc, fres;
   double probc, probgrpswc, probsubwgrps, proba, probb;
   double probac, probbc, probres;
   double data;
   char outline[121];

     cellstring = LatinSpecsFrm->Label6->Caption; // get current label
     LatinSpecsFrm->Label7->Caption = "Subject No."; // set new label
     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = true;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = true;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = true;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();
     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     LatinSpecsFrm->Label5->Caption = cellstring; // restore label
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text)); // no. persons per cell
     if (n <= 0)
     {
          ShowMessage("Please specify the number of subjects per group.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     SubjectFactor = LatinSpecsFrm->DCodeEdit->Text;
     GroupFactor = LatinSpecsFrm->GroupCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Ccol = 0;
    Grpcol = 0;
    SbjCol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == GroupFactor) Grpcol = i;
        if (cellstring == SubjectFactor) SbjCol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Grpcol == 0) || (SbjCol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B, C and Group
    minA = 1000;
    minB = 1000;
    minGrp = 1000;
    maxA = -1000;
    maxB = -1000;
    minC = 1000;
    maxC = -1000;
    maxGrp = -1000;
    nosubjects = 0;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][i]));
         if (value > nosubjects) nosubjects = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         if (value < minGrp) minGrp = value;
         if (value > maxGrp) maxGrp = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeGrp = maxGrp - minGrp + 1;

    // check for squareness
    if (rangeA != rangeB)
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;
    q = rangeC;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblCubeMem(ABC,p+1,p+1,q+1);
    GetDblCubeMem(AGC,p+1,rangeGrp+1,q+1);
    GetDblMatMem(AB,p+1,p+1);
    GetDblMatMem(AC,p+1,q+1);
    GetDblMatMem(BC,p+1,q+1);
    GetDblMatMem(RC,(rangeGrp / q)+1,q+1);
    A = new double[p+1];
    B = new double[p+1];
    C = new double[q+1];
    Persons = new double[nosubjects+1];
    Gm = new double[rangeGrp+1];
    R = new double[p+1];
    cellcnts = new int[p+1];
    Design = new AnsiString*[rangeGrp];
    for (i = 0; i < rangeGrp; i++) Design[i] = new AnsiString[p];
    RowLabels = new AnsiString[100];
    ColLabels = new AnsiString[100];

    // initialize arrays
    for (i = 0; i < p; i++)
    {
         RowLabels[i] = IntToStr(i+1);
         ColLabels[i] = RowLabels[i];
    }
    RowLabels[p] = "Total";
    ColLabels[p] = "Total";

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= q; k++)
                ABC[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= rangeGrp; j++)
           for (k = 0; k <= q; k++)
                AGC[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
         for (j = 0; j <= p; j++)
              AB[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            AC[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            BC[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            RC[i][j] = 0.0;

    for (i = 0; i <= p; i++) A[i] = 0.0;
    for (i = 0; i <= p; i++) B[i] = 0.0;
    for (i = 0; i <= q; i++) C[i] = 0.0;
    for (i = 0; i <= nosubjects; i++) Persons[i] = 0.0;
    for (i = 0; i <= rangeGrp; i++) Gm[i] = 0.0;
    for (i = 0; i <= p; i++) R[i] = 0.0;
    for (i = 0; i <= p; i++) cellcnts[i] = 0;

    // initialize single values
    G = 0.0;
    sumxsqr = 0.0;
    term1 = 0.0;
    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    term8 = 0.0;
    term9 = 0.0;
    term10 = 0.0;

    //  Read in the data
    for (index = 1; index <= NoCases; index++)
    {
         i = floor(StrToFloat(MainForm->Grid->Cells[Acol][index]));
         j = floor(StrToFloat(MainForm->Grid->Cells[Bcol][index]));
         k = floor(StrToFloat(MainForm->Grid->Cells[Ccol][index]));
         m = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][index]));
         subject = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][index]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][index]);
         cellcnts[j-1] = cellcnts[j-1] + 1;
         ABC[i-1][j-1][k-1] = ABC[i-1][j-1][k-1] + data;
         AGC[i-1][m-1][k-1] = AGC[i-1][m-1][k-1] + data;
         AB[i-1][j-1] = AB[i-1][j-1] + data;
         AC[i-1][k-1] = AC[i-1][k-1] + data;
         BC[j-1][k-1] = BC[j-1][k-1] + data;
         A[i-1] = A[i-1] + data;
         B[j-1] = B[j-1] + data;
         C[k-1] = C[k-1] + data;
         Gm[m-1] = Gm[m-1] + data;
         Persons[subject-1] = Persons[subject-1] + data;
         sumxsqr = sumxsqr + (data * data);
         G = G + data;
    }

    // check for equal cell counts in b treatments
    for (i = 1; i < p; i++)
    {
         if (cellcnts[i-1] != cellcnts[i])
         {
              ShowMessage("cell sizes are not  equal!");
              goto cleanup;
         }
    }

    // get sums in the RC matrix
    rows = rangeGrp / q;
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < q; j++)
        {
            k = i + q * j;
            RC[i][j] = Gm[k];
        }
    }

    // get marginal totals for RC array
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < q; j++)
        {
            RC[i][q] = RC[i][q] + RC[i][j];
            RC[rows][j] = RC[rows][j] + RC[i][j];
        }
    }

    // get marginal totals for arrays ABC and AGC
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < q; k++)
              {
                   ABC[i][j][q] = ABC[i][j][q] + ABC[i][j][k];
                   ABC[i][p][k] = ABC[i][p][k] + ABC[i][j][k];
                   ABC[p][j][k] = ABC[p][j][k] + ABC[i][j][k];
              }
         }
    }

    for (i = 0; i < p; i++)
    {
         for (j = 0; j < rangeGrp; j++)
         {
              for (k = 0; k < q; k++)
              {
                   AGC[i][j][q] = AGC[i][j][q] + AGC[i][j][k];
                   AGC[i][rangeGrp][k] = AGC[i][rangeGrp][k] + AGC[i][j][k];
                   AGC[p][j][k] = AGC[p][j][k] + AGC[i][j][k];
              }
         }
    }

    for (i = 0; i < p; i++)
    {
        for (j = 0; j < q; j++)
        {
            AC[p][j] = AC[p][j] + AC[i][j];
            AC[i][q] = AC[i][q] + AC[i][j];
            BC[p][j] = BC[p][j] + BC[i][j];
            BC[i][q] = BC[i][q] + BC[i][j];
        }
    }

    // get grand total for AC, BC and RC
    for (i = 0; i < q; i++)
    {
         AC[p][q] = AC[p][q] + AC[p][i];
         BC[p][q] = BC[p][q] + BC[p][i];
         RC[p][q] = RC[p][q] + RC[p][i];
    }

    // get margins and totals in AB matrix
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              AB[p][j] = AB[p][j] + AB[i][j];
              AB[i][p] = AB[i][p] + AB[i][j];
         }
    }
    for (i = 0; i < p; i++) AB[p][p] = AB[p][p] + AB[i][p];

    // get total for groups
    for (m = 0; j < rangeGrp; m++) Gm[rangeGrp] = Gm[rangeGrp] + Gm[m];

    // test block
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 8");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sums for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "ABC matrix";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (k = 0; k < q; k++)
    {
         sprintf(outline,"C level %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "          ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"  %3d     ",j+1);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++) // row
         {
              sprintf(outline,"  %3d     ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%9.3f ",ABC[i][j][k]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    cellstring = "AB sums";
    ArrayPrint(AB, p+1, p+1, "ANOVA SUMS", RowLabels, ColLabels,"AB sums");
    cellstring = "AC sums";
    ArrayPrint(AC, p+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"AC sums");
    cellstring = "BC sums";
    ArrayPrint(BC, p+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"BC sums");
    cellstring = "RC sums";
    ArrayPrint(RC, rows+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"RC sums");
    cellstring = "Group totals";
    for (i = 0; i < rangeGrp; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[rangeGrp] = "Total";
    VPrint(Gm, rangeGrp+1, ColLabels, "TOTAL");
    for (i = 0; i < nosubjects; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[nosubjects] = "Total";
    cellstring = "Subjects sums";
    VPrint(Persons, nosubjects+1, ColLabels, "SUBJECT SUMS");
    FrmOutPut->ShowModal();

    term1 = (G * G) / (double)(n * p * p * q);
    term2 = sumxsqr;
    for (i = 0; i < p; i++) term3 = term3 + (A[i] * A[i]);
    term3 = term3 / (double)(n * p * q);
    for (i = 0; i < p; i++) term4 = term4 + (B[i] * B[i]);
    term4 = term4 / (double)(n * p * q);
    for (i = 0; i < q; i++) term5 = term5 + (C[i] * C[i]);
    term5 = term5 / (double)(n * p * p);
    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            term6 = term6 + (AC[i][j] * AC[i][j]);
    term6 = term6 / (double)(n * p);
    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            term7 = term7 + (BC[i][j] * BC[i][j]);
    term7 = term7 / (double)(n * p);
    for (i = 0; i < nosubjects; i++) term8 = term8 + (Persons[i] * Persons[i]);
    term8 = term8 / (double)p;
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < q; k++)
                term9 = term9 + (ABC[i][j][k] * ABC[i][j][k]);
    term9 = term9 / (double)n;
    for (i = 0; i < rangeGrp; i++) term10 = term10 + (Gm[i] * Gm[i]);
    term10 = term10 / (double)(n * p * q);

    // term check
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Computation Terms");
    sprintf(outline,"Term1 = %9.3f",term1);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term2 = %9.3f",term2);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term3 = %9.3f",term3);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term4 = %9.3f",term4);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term5 = %9.3f",term5);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term6 = %9.3f",term6);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term7 = %9.3f",term7);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term8 = %9.3f",term8);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term9 = %9.3f",term9);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"term10 = %9.3f",term10);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // now get sums of squares
    SSbetsubj = term8 - term1;
    SSc = term5 - term1;
    SSgrpswc = term10 - term5;
    SSsubwgrps = term8 - term10;
    SSwithinsubj = term2 - term8;
    SSa = term3 - term1;
    SSb = term4 - term1;
    SSac = term6 - term3 - term5 + term1;
    SSbc = term7 - term4 - term5 + term1;
    SSres = term9 - term10 - term6 - term7 + 2.0 * term5;
    SSerrwithin = term2 - term9 - term8 + term10;
    SStotal = term2 - term1;

    // record degrees of freedom for sources
    dfbetsubj = (double)(n * p * q - 1);
    dfc = (double)(q - 1);
    dfgrpswc = (double)((p-1) * q);
    dfsubwgrps = (double)(p * q * (n-1));
    dfwithinsubj = (double)(n * p * q * (p-1));
    dfa = (double)(p - 1);
    dfb = (double)(p - 1);
    dfac = (double)((p - 1) * (q - 1));
    dfbc = (double)((p - 1) * (q - 1));
    dfres = (double)(p * (p - 1) * (p - 2));
    dferrwithin = (double)(p * q * (n - 1) * (p - 1));
    dftotal = (double)(n * p * p * q  - 1);

    MSc = SSc / dfc;
    MSgrpswc = SSgrpswc / dfgrpswc;
    MSsubwgrps = SSsubwgrps / dfsubwgrps;
    MSa = SSa / dfa;
    MSb = SSb / dfb;
    MSac = SSac / dfac;
    MSbc = SSbc / dfbc;
    MSres = SSres / dfres;
    MSerrwithin = SSerrwithin / dferrwithin;

    fc = MSc / MSsubwgrps;
    fgrpswc = MSgrpswc / MSsubwgrps;
//    fsubwgrps = MSsubwgrps / MSerrwithin;
    fa = MSa / MSerrwithin;
    fb = MSb / MSerrwithin;
    fac = MSac / MSerrwithin;
    fbc = MSbc / MSerrwithin;
    fres = MSres / MSerrwithin;

    probc = ftest(dfc,dfsubwgrps,fc);
    probgrpswc = ftest(dfgrpswc,dfsubwgrps,fgrpswc);
//    probsubwgrps = ftest(dfsubwgrps,dferrwithin,fsubwgrps);
    proba = ftest(dfa,dferrwithin,fa);
    probb = ftest(dfb,dferrwithin,fb);
    probac = ftest(dfac,dferrwithin,fac);
    probbc = ftest(dfbc,dferrwithin,fbc);
    probres = ftest(dfres,dferrwithin,fres);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 8");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Betw.Subj.";
    sprintf(outline,"%9.3f %9.0f",SSbetsubj,dfbetsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor C ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSc,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " GroupswC ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSgrpswc,dfgrpswc,MSgrpswc,fgrpswc,probgrpswc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Subj.w.g.";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSsubwgrps,dfsubwgrps,MSsubwgrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Within Sub";
    sprintf(outline,"%9.3f %9.0f",SSwithinsubj,dfwithinsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor A ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSa,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor B ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSb,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor AC";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSac,dfac,MSac,fac,probac);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor BC";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSbc,dfbc,MSbc,fbc,probbc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Residual ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSres,dfres,MSres,fres,probres);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Error w. ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSerrwithin,dferrwithin,MSerrwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // show design for Squares c1, c2, etc.
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i])); // A (column) effect
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i])); // B (cell) effect
//         slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i])); // C (cell) effect
         group = StrToInt(Trim(MainForm->Grid->Cells[Grpcol][i])); // group (row)
         Design[group-1][row-1] = "B" + IntToStr(col);
    }
    for (i = 0; i < rangeGrp; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"%5s",Design[i][j]);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // get means
    G = G / (double)(p * p * q * n );
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < q; k++)
                ABC[i][j][k] = ABC[i][j][k] / (double)n;

    for (i = 0; i < p; i++)
         for (j = 0; j < p; j++)
            AB[i][j] = AB[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) AB[i][p] = AB[i][p] / (double)(n * p * p);
    for (j = 0; j < p; j++) AB[p][j] = AB[p][j] / (double)(n * p * p);
    AB[p][p] = G;

    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            AC[i][j] = AC[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) AC[i][q] = AC[i][q] / (double)(n * p * p);
    for (j = 0; j < q; j++) AC[p][j] = AC[p][j] / (double)(n * p * p);
    AC[p][q] = G;

    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            BC[i][j] = BC[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) BC[i][q] = BC[i][q] / (double)(n * p * p);
    for (j = 0; j < q; j++) BC[p][j] = BC[p][j] / (double)(n * p * p);
    BC[p][q] = G;

    for (i = 0; i < rows; i++)
        for (j = 0; j < q; j++)
            RC[i][j] = RC[i][j] / (double)(p * n);
    for (i = 0; i < rows; i++) RC[i][q] = RC[i][q] / (double)(p * q * n);
    for (j = 0; j < q; j++) RC[p][j] = RC[p][j] / (double)(q * p * n);
    RC[p][q] = G;

    for (i = 0; i < p; i++)
    {
         A[i] = A[i] / (double)(p * n * q);
         B[i] = B[i] / (double)(p * n * q);
    }
    A[p] = G;
    B[p] = G;

    for (i = 0; i < q; i++) C[i] = C[i] / (double)(p * q * n);
    C[q] = G;

    for (i = 0; i < rangeGrp; i++) Gm[i] = Gm[i] / (double)(p * n);
    Gm[rangeGrp] = G;

    for (i = 0; i < nosubjects; i++) Persons[i] = Persons[i] / (double)n;
    Persons[nosubjects] = G;

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 8");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "ABC matrix";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (k = 0; k < q; k++)
    {
         sprintf(outline,"C level %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "          ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"  %3d     ",j+1);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++) // row
         {
              sprintf(outline,"  %3d     ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%9.3f ",ABC[i][j][k]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    cellstring = "AB Means";
    ArrayPrint(AB, p+1, p+1, "MEANS", RowLabels, ColLabels,"AB MEANS");
    cellstring = "AC Means";
    ArrayPrint(AC, p+1, q+1, "MEANS", RowLabels, ColLabels,"AC MEANS");
    cellstring = "BC Means";
    ArrayPrint(BC, p+1, q+1, "MEANS", RowLabels, ColLabels,"BC MEANS");
    cellstring = "RC Means";
    ArrayPrint(RC, p+1, q+1, "MEANS", RowLabels, ColLabels,"RC MEANS");
    cellstring = "Group Means";
    for (i = 0; i < rangeGrp; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[rangeGrp] = "Total";
    VPrint(Gm, rangeGrp+1, ColLabels, "Group Means");
    for (i = 0; i < nosubjects; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[nosubjects] = "Total";
    cellstring = "Subjects Means";
    VPrint(Persons, nosubjects+1, ColLabels, "Subject Means");
    FrmOutPut->ShowModal();

cleanup:
    delete[] ColLabels;
    delete[] RowLabels;
    for (i = 0; i < rangeGrp; i++) delete[] Design[i];
    delete[] Design;
    delete[] cellcnts;
    delete[] R;
    delete[] Gm;
    delete[] Persons;
    delete[] C;
    delete[] B;
    delete[] A;
    ClearDblMatMem(RC,(rangeGrp / q)+1);
    ClearDblMatMem(BC,p+1);
    ClearDblMatMem(AC,p+1);
    ClearDblMatMem(AB,p+1);
    ClearDblCubeMem(AGC,p+1,rangeGrp+1);
    ClearDblCubeMem(ABC,p+1,p+1);
}
//-------------------------------------------------------------------

void __fastcall TLatinSqrForm::Plan9(TObject *Sender)
{
   int row, col, slice, group, index;
   int Acol, Bcol, Ccol, SbjCol, Grpcol, DataCol; // variable columns in grid
   AnsiString FactorA, FactorB, FactorC, SubjectFactor, GroupFactor, DataVar;
   AnsiString cellstring;
   int i, j, k, m, minA, minB, minC, minGrp, maxA, maxB, maxC, maxGrp;
   int n, subject, nosubjects, rangeA, rangeB, rangeC, rangeGrp;
   int p, q, rows, value;
   double ***ABC, ***AGC;
   double **AB, **AC, **BC, **RC;
   double *A, *B, *C, *Persons, *Gm, *R;
   int *cellcnts;
   AnsiString **Design;
   AnsiString *RowLabels, *ColLabels;
   double G, sumxsqr, sumAsqr, sumBsqr, sumCsqr, sumABsqr, sumACsqr;
   double sumBCsqr, sumABCsqr, sumPsqr, sumGmsqr, sumRsqr;
   double SSbetsubj, SSc, SSrows, SScxrow, SSsubwgrps, SSwsubj, SSa;
   double SSwithinsubj, SSerrwithin;
   double SSb, SSac, SSbc, SSabprime, SSABCprime, SSerrorwithin, SStotal;
   double term1, term2, term3, term4, term5, term6, term7, term8, term9, term10;
   double term11, term12;
   double dfc, dfrows, dfcxrow, dfsubwgrps, dfwithinsubj, dfa, dfb,dfac;
   double dfbc, dfabprime, dfabcprime,dferrwithin, dftotal, dfbetsubj;
   double MSbetweensubj, MSc, MSrows, MScxrow, MSsubwgrps, MSwsubj, MSa;
   double MSb, MSac, MSbc, MSabprime, MSabcprime, MSerrwithin, MStotal;
   double fc, frows, fcxrow, fsubwgrps, fa, fb, fac, fbc, fabprime, fabcprime;
   double probc, probrows, probcxrow, probsubwgrps, proba, probb;
   double probac, probbc, probabprime, probabcprime;
   double data;
   char outline[121];

     cellstring = LatinSpecsFrm->Label6->Caption; // get current label
     LatinSpecsFrm->Label6->Caption = "Subject No."; // set new label
     LatinSpecsFrm->AinBtn->Visible = true;
     LatinSpecsFrm->AoutBtn->Visible = false;
     LatinSpecsFrm->BinBtn->Visible = true;
     LatinSpecsFrm->BoutBtn->Visible = false;
     LatinSpecsFrm->CinBtn->Visible = true;
     LatinSpecsFrm->CoutBtn->Visible = false;
     LatinSpecsFrm->DCodeEdit->Visible = true;
     LatinSpecsFrm->ACodeEdit->Text = "";
     LatinSpecsFrm->BCodeEdit->Text = "";
     LatinSpecsFrm->CCodeEdit->Text = "";
     LatinSpecsFrm->DCodeEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Text = "";
     LatinSpecsFrm->DepVarEdit->Text = "";
     LatinSpecsFrm->NPerCellEdit->Text = "";
     LatinSpecsFrm->GroupCodeEdit->Visible = true;
     LatinSpecsFrm->Label6->Visible = true;
     LatinSpecsFrm->Label7->Visible = true;
     LatinSpecsFrm->DinBtn->Visible = true;
     LatinSpecsFrm->DoutBtn->Visible = false;
     LatinSpecsFrm->GrpInBtn->Visible = true;
     LatinSpecsFrm->GrpOutBtn->Visible = false;
     LatinSpecsFrm->DataInBtn->Visible = true;
     LatinSpecsFrm->DataOutBtn->Visible = false;
     LatinSpecsFrm->ShowModal();

     if (LatinSpecsFrm->ModalResult == mrCancel) return;
     LatinSpecsFrm->Label6->Caption = cellstring; // restore label
     n = StrToInt(Trim(LatinSpecsFrm->NPerCellEdit->Text)); // no. persons per cell
     if (n <= 0)
     {
          ShowMessage("Please specify the number of subjects per group.");
          return;
     }
     FactorA = LatinSpecsFrm->ACodeEdit->Text;
     FactorB = LatinSpecsFrm->BCodeEdit->Text;
     FactorC = LatinSpecsFrm->CCodeEdit->Text;
     SubjectFactor = LatinSpecsFrm->DCodeEdit->Text;
     GroupFactor = LatinSpecsFrm->GroupCodeEdit->Text;
     DataVar = LatinSpecsFrm->DepVarEdit->Text;
    Acol = 0;
    Bcol = 0;
    Ccol = 0;
    Grpcol = 0;
    SbjCol = 0;
    DataCol = 0;
    for (i = 1; i <= NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i][0];
        if (cellstring == FactorA) Acol = i;
        if (cellstring == FactorB) Bcol = i;
        if (cellstring == FactorC) Ccol = i;
        if (cellstring == GroupFactor) Grpcol = i;
        if (cellstring == SubjectFactor) SbjCol = i;
        if (cellstring == DataVar) DataCol = i;
    }
    if ((Acol == 0) || (Bcol == 0) || (Ccol == 0) || (Grpcol == 0) || (SbjCol == 0) || (DataCol == 0))
    {
        ShowMessage("ERROR!  A required variable has not been selected.");
        return;
    }

    // determine no. of levels in A, B, C and Group
    minA = 1000;
    minB = 1000;
    minGrp = 1000;
    maxA = -1000;
    maxB = -1000;
    minC = 1000;
    maxC = -1000;
    maxGrp = -1000;
    nosubjects = 0;
    for (i = 1; i <= NoCases; i++)
    {
         value = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         if (value < minA) minA = value;
         if (value > maxA) maxA = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         if (value < minB) minB = value;
         if (value > maxB) maxB = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Ccol][i]));
         if (value < minC) minC = value;
         if (value > maxC) maxC = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][i]));
         if (value > nosubjects) nosubjects = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][i]));
         if (value < minGrp) minGrp = value;
         if (value > maxGrp) maxGrp = value;
    }
    rangeA = maxA - minA + 1;
    rangeB = maxB - minB + 1;
    rangeC = maxC - minC + 1;
    rangeGrp = maxGrp - minGrp + 1;

    // check for squareness
    if (rangeA != rangeB)
    {
         ShowMessage("ERROR! In a Latin square the range of values should be equal for A,B and C!");
         return;
    }
    p = rangeA;
    q = rangeC;

    // set up an array for cell counts and for cell sums and marginal sums
    GetDblCubeMem(ABC,p+1,p+1,q+1);
    GetDblCubeMem(AGC,p+1,rangeGrp+1,q+1);
    GetDblMatMem(AB,p+1,p+1);
    GetDblMatMem(AC,p+1,q+1);
    GetDblMatMem(BC,p+1,q+1);
    GetDblMatMem(RC,(rangeGrp / q)+1,q+1);
    A = new double[p+1];
    B = new double[p+1];
    C = new double[q+1];
    Persons = new double[nosubjects+1];
    Gm = new double[rangeGrp+1];
    R = new double[p+1];
    cellcnts = new int[p+1];
    Design = new AnsiString *[rangeGrp];
    for (i = 0; i < rangeGrp; i++) Design[i] = new AnsiString[p];
    RowLabels = new AnsiString[100];
    ColLabels = new AnsiString[100];

    // initialize arrays
    for (i = 0; i < p; i++)
    {
         RowLabels[i] = IntToStr(i+1);
         ColLabels[i] = RowLabels[i];
    }
    RowLabels[p] = "Total";
    ColLabels[p] = "Total";

    for (i = 0; i <= p; i++)
        for (j = 0; j <= p; j++)
            for (k = 0; k <= q; k++)
                ABC[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= rangeGrp; j++)
            for (k = 0; k <= q; k++)
                AGC[i][j][k] = 0.0;

    for (i = 0; i <= p; i++)
         for (j = 0; j <= p; j++)
              AB[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            AC[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            BC[i][j] = 0.0;

    for (i = 0; i <= p; i++)
        for (j = 0; j <= q; j++)
            RC[i][j] = 0.0;

    for (i = 0; i <= p; i++) A[i] = 0.0;
    for (i = 0; i <= p; i++) B[i] = 0.0;
    for (i = 0; i <= q; i++) C[i] = 0.0;
    for (i = 0; i <= nosubjects; i++) Persons[i] = 0.0;
    for (i = 0; i <= rangeGrp; i++) Gm[i] = 0.0;
    for (i = 0; i <= p; i++) R[i] = 0.0;
    for (i = 0; i <= p; i++) cellcnts[i] = 0;

    // initialize single values
    G = 0.0;
    sumxsqr = 0.0;
    term2 = 0.0;
    term3 = 0.0;
    term4 = 0.0;
    term5 = 0.0;
    term6 = 0.0;
    term7 = 0.0;
    term8 = 0.0;
    term9 = 0.0;
    term10 = 0.0;
    term11 = 0.0;
    term12 = 0.0;

    //  Read in the data
    for (index = 1; index <= NoCases; index++)
    {
         i = floor(StrToFloat(MainForm->Grid->Cells[Acol][index]));
         j = floor(StrToFloat(MainForm->Grid->Cells[Bcol][index]));
         k = floor(StrToFloat(MainForm->Grid->Cells[Ccol][index]));
         m = floor(StrToFloat(MainForm->Grid->Cells[Grpcol][index]));
         subject = floor(StrToFloat(MainForm->Grid->Cells[SbjCol][index]));
         data = StrToFloat(MainForm->Grid->Cells[DataCol][index]);
         cellcnts[j-1] = cellcnts[j-1] + 1;
         ABC[i-1][j-1][k-1] = ABC[i-1][j-1][k-1] + data;
         AGC[i-1][m-1][k-1] = AGC[i-1][m-1][k-1] + data;
         AB[i-1][j-1] = AB[i-1][j-1] + data;
         AC[i-1][k-1] = AC[i-1][k-1] + data;
         BC[j-1][k-1] = BC[j-1][k-1] + data;
         A[i-1] = A[i-1] + data;
         B[j-1] = B[j-1] + data;
         C[k-1] = C[k-1] + data;
         Gm[m-1] = Gm[m-1] + data;
         Persons[subject-1] = Persons[subject-1] + data;
         sumxsqr = sumxsqr + (data * data);
         G = G + data;
    }

    // check for equal cell counts in b treatments
    for (i = 1; i < p; i++)
    {
         if (cellcnts[i-1] != cellcnts[i])
         {
              ShowMessage("cell sizes are not  equal!");
              goto cleanup;
         }
    }

    // get sums in the RC matrix
    rows = rangeGrp / q;
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < q; j++)
        {
            k = i + q * j;
            RC[i][j] = Gm[k];
        }
    }

    // get marginal totals for RC array
    for (i = 0; i < rows; i++)
    {
        for (j = 0; j < q; j++)
        {
            RC[i][q] = RC[i][q] + RC[i][j];
            RC[rows][j] = RC[rows][j] + RC[i][j];
        }
    }

    // get marginal totals for arrays ABC and AGC
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              for (k = 0; k < q; k++)
              {
                   ABC[i][j][q] = ABC[i][j][q] + ABC[i][j][k];
                   ABC[i][p][k] = ABC[i][p][k] + ABC[i][j][k];
                   ABC[p][j][k] = ABC[p][j][k] + ABC[i][j][k];
              }
         }
    }

    for (i = 0; i < p; i++)
    {
         for (j = 0; j < rangeGrp; j++)
         {
              for (k = 0; k < q; k++)
              {
                   AGC[i][j][q] = AGC[i][j][q] + AGC[i][j][k];
                   AGC[i][rangeGrp][k] = AGC[i][rangeGrp][k] + AGC[i][j][k];
                   AGC[p][j][k] = AGC[p][j][k] + AGC[i][j][k];
              }
         }
    }

    for (i = 0; i < p; i++)
    {
        for (j = 0; j < q; j++)
        {
            AC[p][j] = AC[p][j] + AC[i][j];
            AC[i][q] = AC[i][q] + AC[i][j];
            BC[p][j] = BC[p][j] + BC[i][j];
            BC[i][q] = BC[i][q] + BC[i][j];
        }
    }

    // get grand total for AC, BC and RC
    for (i = 0; i < q; i++)
    {
         AC[p][q] = AC[p][q] + AC[p][i];
         BC[p][q] = BC[p][q] + BC[p][i];
         RC[p][q] = RC[p][q] + RC[p][i];
    }

    // get margins and totals in AB matrix
    for (i = 0; i < p; i++)
    {
         for (j = 0; j < p; j++)
         {
              AB[p][j] = AB[p][j] + AB[i][j];
              AB[i][p] = AB[i][p] + AB[i][j];
         }
    }
    for (i = 0; i < p; i++) AB[p][p] = AB[p][p] + AB[i][p];

    // get total for groups
    for (m = 0; m < rangeGrp; m++) Gm[rangeGrp] = Gm[rangeGrp] + Gm[m];

    // test block
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 9");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sums for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "ABC matrix";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (k = 0; k < q; k++)
    {
         sprintf(outline,"C level %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "          ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"  %3d     ",j+1);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++) // row
         {
              sprintf(outline,"  %3d     ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%9.3f ",ABC[i][j][k]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    cellstring = "AB sums";
    ArrayPrint(AB, p+1, p+1, "ANOVA SUMS", RowLabels, ColLabels,"AB sums");
    cellstring = "AC sums";
    ArrayPrint(AC, p+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"AC sums");
    cellstring = "BC sums";
    ArrayPrint(BC, p+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"BC sums");
    cellstring = "RC sums";
    ArrayPrint(RC, rows+1, q+1, "ANOVA SUMS", RowLabels, ColLabels,"RC sums");
    cellstring = "Group totals";
    for (i = 0; i < rangeGrp; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[rangeGrp] = "Total";
    VPrint(Gm, rangeGrp+1, ColLabels, "TOTAL");
    for (i = 0; i < nosubjects; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[nosubjects] = "Total";
    cellstring = "Subjects sums";
    VPrint(Persons, nosubjects+1, ColLabels, "Subjects sums");
    FrmOutPut->ShowModal();

    term1 = (G * G) / (double)(n * p * p * q);
    term2 = sumxsqr;
    for (i = 0; i < p; i++) term3 = term3 + (A[i] * A[i]);
    term3 = term3 / (double)(n * p * q);
    for (i = 0; i < p; i++) term4 = term4 + (B[i] * B[i]);
    term4 = term4 / (double)(n * p * q);
    for (i = 0; i < q; i++) term5 = term5 + (C[i] * C[i]);
    term5 = term5 / (double)(n * p * p);
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            term6 = term6 + (AB[i][j] * AB[i][j]);
    term6 = term6 / (double)(n * q);
    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            term7 = term7 + (AC[i][j] * AC[i][j]);
    term7 = term7 / (double)(n * p);
    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            term8 = term8 + (BC[i][j] * BC[i][j]);
    term8 = term8 / (double)(n * p);
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < q; k++)
                term9 = term9 + (ABC[i][j][k] * ABC[i][j][k]);
    term9 = term9 / (double)n;
    for (i = 0; i < nosubjects; i++) term10 = term10 + (Persons[i] * Persons[i]);
    term10 = term10 / (double)p;
    for (i = 0; i < rangeGrp; i++) term11 = term11 + (Gm[i] * Gm[i]);
    term11 = term11 / (double)(n * p);
    for (i = 0; i < rows; i++) term12 = term12 + (RC[i][q] * RC[i][q]);
    term12 = term12 / (double)(n * p * q);

    // term check
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Computation Terms");
    sprintf(outline,"Term1 = %9.3f",term1);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term2 = %9.3f",term2);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term3 = %9.3f",term3);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term4 = %9.3f",term4);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term5 = %9.3f",term5);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term6 = %9.3f",term6);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term7 = %9.3f",term7);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term8 = %9.3f",term8);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term9 = %9.3f",term9);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term10 = %9.3f",term10);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term11 = %9.3f",term11);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"Term12 = %9.3f",term12);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // now get sums of squares
    SSbetsubj = term10 - term1;
    SSc = term5 - term1;
    SSrows = term12 - term1;
    SScxrow = term11 - term5 - term12 + term1;
    SSsubwgrps = term10 - term11;
    SSwithinsubj = term2 - term10;
    SSa = term3 - term1;
    SSb = term4 - term1;
    SSac = term7 - term3 - term5 + term1;
    SSbc = term8 - term4 - term5 + term1;
    SSabprime = (term6 - term3 - term4 + term1) - (term12 - term1);
    SSABCprime = (term9 - term6 - term7 - term8 + term3 + term4 + term5 - term1)
         - (term11 - term5 - term12 + term1);
    SSerrwithin = term2 - term10 - term9 + term11;
    SStotal = term2 - term1;

    // record degrees of freedom for sources
    dfbetsubj = (double)(n * p * q - 1);
    dfc = (double)(q - 1);
    dfrows = (double)(p - 1);
    dfcxrow = (double)((p-1) * (q-1));
    dfsubwgrps = (double)(p * q * (n-1));
    dfwithinsubj = (double)(n * p * q * (p-1));
    dfa = (double)(p - 1);
    dfb = (double)(p - 1);
    dfac = (double)((p - 1) * (q - 1));
    dfbc = (double)((p - 1) * (q - 1));
    dfabprime = (double)((p - 1) * (p - 2));
    dfabcprime = (double)((p - 1) * (p - 2) * (q - 1));
    dferrwithin = (double)(p * q * (n - 1) * (p - 1));
    dftotal = (double)(n * p * p * q  - 1);

    MSc = SSc / dfc;
    MSrows = SSrows / dfrows;
    MScxrow = SScxrow / dfcxrow;
    MSsubwgrps = SSsubwgrps / dfsubwgrps;
    MSa = SSa / dfa;
    MSb = SSb / dfb;
    MSac = SSac / dfac;
    MSbc = SSbc / dfbc;
    MSabprime = SSabprime / dfabprime;
    MSabcprime = SSABCprime / dfabcprime;
    MSerrwithin = SSerrwithin / dferrwithin;

    fc = MSc / MSsubwgrps;
    frows = MSrows / MSsubwgrps;
    fcxrow = MScxrow / MSsubwgrps;
//    fsubwgrps = MSsubwgrps / MSerrwithin;
    fa = MSa / MSerrwithin;
    fb = MSb / MSerrwithin;
    fac = MSac / MSerrwithin;
    fbc = MSbc / MSerrwithin;
    fabprime = MSabprime / MSerrwithin;
    fabcprime = MSabcprime / MSerrwithin;

    probc = ftest(dfc,dfsubwgrps,fc);
    probrows = ftest(dfrows,dfsubwgrps,frows);
    probcxrow = ftest(dfcxrow,dfsubwgrps,fcxrow);
//    probsubwgrps = ftest(dfsubwgrps,dferrwithin,fsubwgrps);
    proba = ftest(dfa,dferrwithin,fa);
    probb = ftest(dfb,dferrwithin,fb);
    probac = ftest(dfac,dferrwithin,fac);
    probbc = ftest(dfbc,dferrwithin,fbc);
    probabprime = ftest(dfabprime,dferrwithin,fabprime);
    probabcprime = ftest(dfabcprime,dferrwithin,fabcprime);

    // show ANOVA table results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 9");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source         SS        DF        MS        F      Prob.>F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    cellstring = "Betw.Subj.";
    sprintf(outline,"%9.3f %9.0f",SSbetsubj,dfbetsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor C ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSc,dfc,MSc,fc,probc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Rows     ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSrows,dfrows,MSrows,frows,probrows);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " C x row  ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SScxrow,dfcxrow,MScxrow,fcxrow,probcxrow);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Subj.w.g.";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSsubwgrps,dfsubwgrps,MSsubwgrps);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Within Sub";
    sprintf(outline,"%9.3f %9.0f",SSwithinsubj,dfwithinsubj);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor A ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSa,dfa,MSa,fa,proba);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor B ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSb,dfb,MSb,fb,probb);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor AC";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSac,dfac,MSac,fac,probac);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Factor BC";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSbc,dfbc,MSbc,fbc,probbc);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " AB prime ";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSabprime,dfabprime,MSabprime,fabprime,probabprime);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " ABC prime";
    sprintf(outline,"%9.3f %9.0f %9.3f %9.3f %9.3f",SSABCprime,dfabcprime,MSabcprime,fabcprime,probabcprime);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = " Error w. ";
    sprintf(outline,"%9.3f %9.0f %9.3f",SSerrwithin,dferrwithin,MSerrwithin);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "Total     ";
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%9.3f %9.0f",SStotal, dftotal);
    cellstring = cellstring + outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // show design for Squares c1, c2, etc.
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "Experimental Design for Latin Square ";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",FactorA);
    cellstring = outline;
    for (i = 1; i <= p; i++)
    {
        sprintf(outline," %3d ",i);
        cellstring = cellstring + outline;
    }
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    sprintf(outline,"%10s",GroupFactor);
    cellstring = outline;
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    for (i = 1; i <= NoCases; i++)
    {
         row = StrToInt(Trim(MainForm->Grid->Cells[Acol][i])); // A (column) effect
         col = StrToInt(Trim(MainForm->Grid->Cells[Bcol][i])); // B (cell) effect
//         slice = StrToInt(Trim(MainForm->Grid->Cells[Ccol][i])); // C (cell) effect
         group = StrToInt(Trim(MainForm->Grid->Cells[Grpcol][i])); // group (row)
         Design[group-1][row-1] = "B" + IntToStr(col);
    }
    for (i = 0; i < rangeGrp; i++)
    {
         sprintf(outline,"   %3d    ",i+1);
         cellstring = outline;
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"%5s",Design[i][j]);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
    }
    cellstring = "----------";
    for (i = 1; i <= p + 1; i++) cellstring = cellstring + "-----";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // get means
    G = G / (double)(p * p * q * n );
    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            for (k = 0; k < q; k++)
                ABC[i][j][k] = ABC[i][j][k] / (double)n;

    for (i = 0; i < p; i++)
        for (j = 0; j < p; j++)
            AB[i][j] = AB[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) AB[i][p] = AB[i][p] / (double)(n * p * p);
    for (j = 0; j < p; j++) AB[p][j] = AB[p][j] / (double)(n * p * p);
    AB[p][p] = G;

    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            AC[i][j] = AC[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) AC[i][q] = AC[i][q] / (double)(n * p * p);
    for (j = 0; j < q; j++) AC[p][j] = AC[p][j] / (double)(n * p * p);
    AC[p][q] = G;

    for (i = 0; i < p; i++)
        for (j = 0; j < q; j++)
            BC[i][j] = BC[i][j] / (double)(n * p);
    for (i = 0; i < p; i++) BC[i][q] = BC[i][q] / (double)(n * p * p);
    for (j = 0; j < q; j++) BC[p][j] = BC[p][j] / (double)(n * p * p);
    BC[p][q] = G;

    for (i = 0; i < rows; i++)
        for (j = 0; j < q; j++)
            RC[i][j] = RC[i][j] / (double)(p * n);
    for (i = 0; i < rows; i++) RC[i][q] = RC[i][q] / (double)(p * q * n);
    for (j = 0; j < q; j++) RC[p][j] = RC[p][j] / (double)(q * p * n);
    RC[p][q] = G;

    for (i = 0; i < p; i++)
    {
         A[i] = A[i] / (double)(p * n * q);
         B[i] = B[i] / (double)(p * n * q);
    }
    A[p] = G;
    B[p] = G;

    for (i = 0; i < q; i++) C[i] = C[i] / (double)(p * q * n);
    C[q] = G;

    for (i = 0; i < rangeGrp; i++) Gm[i] = Gm[i] / (double)(p * n);
    Gm[rangeGrp] = G;

    for (i = 0; i < nosubjects; i++) Persons[i] = Persons[i] / (double)n;
    Persons[nosubjects] = G;

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Latin Squares Repeated Analysis Plan 9");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Means for ANOVA Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    cellstring = "ABC matrix";
    FrmOutPut->RichOutPut->Lines->Add(cellstring);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (k = 0; k < q; k++)
    {
         sprintf(outline,"C level %d",k+1);
         cellstring = outline;
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         cellstring = "          ";
         for (j = 0; j < p; j++)
         {
             sprintf(outline,"  %3d     ",j+1);
             cellstring = cellstring + outline;
         }
         FrmOutPut->RichOutPut->Lines->Add(cellstring);
         for (i = 0; i < p; i++) // row
         {
              sprintf(outline,"  %3d     ",i+1);
              cellstring = outline;
              for (j = 0; j < p; j++)
              {
                   sprintf(outline,"%9.3f ",ABC[i][j][k]);
                   cellstring = cellstring + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(cellstring);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    cellstring = "AB Means";
    ArrayPrint(AB, p+1, p+1, "ANOVA MEANS", RowLabels, ColLabels,"AB Means");
    cellstring = "AC Means";
    ArrayPrint(AC, p+1, q+1, "ANOVA MEANS", RowLabels, ColLabels,"AC Means");
    cellstring = "BC Means";
    ArrayPrint(BC, p+1, q+1, "ANOVA MEANS", RowLabels, ColLabels,"BC Means");
    cellstring = "RC Means";
    ArrayPrint(RC, rows+1, q+1, "ANOVA MEANS", RowLabels, ColLabels,"RC Means");
    cellstring = "Group Means";
    for (i = 0; i < rangeGrp; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[rangeGrp] = "Total";
    VPrint(Gm, rangeGrp+1, ColLabels, "TOTAL");
    for (i = 0; i < nosubjects; i++) ColLabels[i] = IntToStr(i+1);
    ColLabels[nosubjects] = "Total";
    cellstring = "Subjects Means";
    VPrint(Persons, nosubjects+1, ColLabels, "Subjects Means");
    FrmOutPut->ShowModal();

cleanup:
    delete[] ColLabels;
    delete[] RowLabels;
    for (i = 0; i < rangeGrp; i++) delete[] Design[i];
    delete[] Design;
    delete[] cellcnts;
    delete[] R;
    delete[] Gm;
    delete[] Persons;
    delete[] C;
    delete[] B;
    delete[] A;
    ClearDblMatMem(RC,(rangeGrp / q)+1);
    ClearDblMatMem(BC,p+1);
    ClearDblMatMem(AC,p+1);
    ClearDblMatMem(AB,p+1);
    ClearDblCubeMem(AGC,p+1,rangeGrp+1);
    ClearDblCubeMem(ABC,p+1,p+1);
}
//-------------------------------------------------------------------

