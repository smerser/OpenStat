//---------------------------------------------------------------------------

#ifndef NormalityUnitH
#define NormalityUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TNormalityForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TListBox *VarList;
   TBitBtn *InBtn;
   TBitBtn *OutBtn;
   TLabel *Label2;
   TEdit *TestVarEdit;
   TGroupBox *GroupBox1;
   TGroupBox *GroupBox2;
   TButton *CancelBtn;
   TButton *ResetBtn;
   TButton *PrintBtn;
   TButton *ComputeBtn;
   TButton *ReturnBtn;
   TLabel *Label3;
   TEdit *WEdit;
   TLabel *Label4;
   TEdit *ProbEdit;
   TLabel *Label5;
   TLabel *Label6;
   TLabel *Label7;
   TEdit *SkewEdit;
   TEdit *KurtosisEdit;
   TEdit *StatEdit;
   TLabel *Label8;
   TEdit *ConclusionEdit;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall InBtnClick(TObject *Sender);
   void __fastcall OutBtnClick(TObject *Sender);
   void __fastcall ComputeBtnClick(TObject *Sender);
   void __fastcall PrintBtnClick(TObject *Sender);
private:	// User declarations
   double __fastcall Norm(double z);
   double __fastcall CalcNr(double pn);
   double __fastcall ANorm(double p);
   
public:		// User declarations
   __fastcall TNormalityForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TNormalityForm *NormalityForm;
//---------------------------------------------------------------------------
#endif
