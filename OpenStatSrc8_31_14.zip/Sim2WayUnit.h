//---------------------------------------------------------------------------

#ifndef Sim2WayUnitH
#define Sim2WayUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmSim2Way : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TEdit *NoLevAEdit;
    TEdit *NoLevBEdit;
    TEdit *NoPerCellEdit;
    TEdit *PopMeanEdit;
    TEdit *PopStdDevEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TLabel *Label9;
    TEdit *ALevEdit;
    TLabel *Label10;
    TEdit *AEffEdit;
    TLabel *Label3;
    TEdit *BLevEdit;
    TLabel *Label4;
    TEdit *BEffEdit;
    TLabel *Label11;
    TEdit *ABLevAEdit;
    TLabel *Label12;
    TEdit *ABLevBEdit;
    TLabel *Label13;
    TEdit *ABEffEdit;
    TMemo *Memo1;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall NoLevAEditKeyPress(TObject *Sender, char &Key);
    void __fastcall AEffEditKeyPress(TObject *Sender, char &Key);
    void __fastcall NoLevBEditKeyPress(TObject *Sender, char &Key);
    void __fastcall BEffEditKeyPress(TObject *Sender, char &Key);
    void __fastcall ABEffEditKeyPress(TObject *Sender, char &Key);
    void __fastcall NoPerCellEditKeyPress(TObject *Sender, char &Key);
    void __fastcall PopMeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall PopStdDevEditKeyPress(TObject *Sender, char &Key);
private:	// User declarations
    double AEffSize[10];
    double BEffSize[10];
    double ABEffSize[10][10];
    int NoLevA, NoLevB, NoPerCell, TotN;
    double PopMean, PopStdDev;
    double X;
    
public:		// User declarations
    __fastcall TFrmSim2Way(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmSim2Way *FrmSim2Way;
//---------------------------------------------------------------------------
#endif
