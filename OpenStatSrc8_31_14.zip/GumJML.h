//---------------------------------------------------------------------------
#ifndef GumJMLH
#define GumJMLH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TGUMForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TEdit *NoCatsEdit;
    TEdit *MaxScrEdit;
    TGroupBox *GroupBox1;
    TCheckBox *RecodeCB;
    TCheckBox *FitStatsCB;
    TCheckBox *PersonFitCB;
    TCheckBox *GridSrchCB;
    TGroupBox *GroupBox2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TEdit *NoFitGrpsEdit;
    TEdit *ItemCOEdit;
    TEdit *ItemAlphaEdit;
    TGroupBox *GroupBox3;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TEdit *PersonCOEdit;
    TEdit *PersonAlphaEdit;
    TEdit *LocalCOEdit;
    TGroupBox *GroupBox4;
    TLabel *Label9;
    TLabel *Label10;
    TGroupBox *GroupBox5;
    TLabel *Label11;
    TLabel *Label12;
    TGroupBox *GroupBox6;
    TLabel *Label13;
    TLabel *Label14;
    TGroupBox *GroupBox7;
    TLabel *Label15;
    TLabel *Label16;
    TEdit *DeltaEndEdit;
    TEdit *DeltaMaxEdit;
    TEdit *TauEndEdit;
    TEdit *TauMaxEdit;
    TEdit *ThetaEndEdit;
    TEdit *ThetaMaxEdit;
    TEdit *AvgAllEdit;
    TEdit *MaxPassEdit;
    TButton *BtnReset;
    TButton *BtnCancel;
    TButton *BtnOK;
    void __fastcall BtnOKClick(TObject *Sender);
    void __fastcall BtnCancelClick(TObject *Sender);
    void __fastcall BtnResetClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TGUMForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGUMForm *GUMForm;
//---------------------------------------------------------------------------
#endif
