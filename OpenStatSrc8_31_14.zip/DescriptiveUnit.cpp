//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "functions.h"
#include "HugeFileUnit.h"
#include "DescriptiveUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
extern bool ReadDiskFile;
extern FILE * datafile; 
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDescriptiveForm *DescriptiveForm;
//---------------------------------------------------------------------------
__fastcall TDescriptiveForm::TDescriptiveForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     ListBox1->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     CaseDelChk->Checked = false;
     zScoresChk->Checked = false;
     PcntileChk->Checked = false;
     QuartilesChk->Checked = false;
     InBtn->Enabled = true;
     OutBtn->Enabled = false;
     if (ops.format == 0) CIEdit->Text = "0.95";
     else CIEdit->Text = "0,95";

}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::InBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              ListBox1->Items->Add(Varlist->Items->Strings[i]);
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::OutBtnClick(TObject *Sender)
{
     int index;

     index = ListBox1->ItemIndex;
     Varlist->Items->Add(ListBox1->Items->Strings[index]);
     ListBox1->Items->Delete(index);
     InBtn->Enabled = true;
     if (ListBox1->Items->Count == 0) OutBtn->Enabled = false;   
}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::AllBtnClick(TObject *Sender)
{
     int count, index;

     count = Varlist->Items->Count;
     for (index = 0; index < count; index++)
         ListBox1->Items->Add(Varlist->Items->Strings[index]);
     Varlist->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::OKBtnClick(TObject *Sender)
{

     int i, j, k, mingrp, maxgrp, G, NoGrps, cnt, nscrgrps, intvalue, result;
     double num, den, cases, ConfInt, CI, dblvalue;
     char outline[121];
     AnsiString *DiskValues;
     double *Scores, *freq, *cumfreq, *prank, *logvalues;
     double X, tenpcnt, ninepcnt, qrtile1, qrtile2, qrtile3, temp;
     double minscr, maxscr, intvlsize, lastX;
     double GeoMean, GeoVar, GeoSD, HarmMean, poscount;
     double tenpcntile, ninetypcntile, lowqrtl, median, hiqrtl;
     AnsiString strvalue;

    if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "TempFile.TEX";
    noselected = ListBox1->Items->Count;
    if (noselected < 0)
    {
        ShowMessage("ERROR!  One or more variables must be selected.");
        return;
    }

    selected = new int[noselected];
    // Get selected variables
    for (i = 1; i <= noselected; i++)
    {
        cellstring = ListBox1->Items->Strings[i-1];
        for (j = 1; j <= NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j][0])
            {
                selected[i-1] = j;
             }
        }
    }

    Scores = new double[2 * NoCases+2];
    freq = new double[2 * NoCases+2];
    cumfreq = new double[2 * NoCases+2];
    prank = new double[2 * NoCases+2];
    logvalues = new double[NoCases+2];
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("DISTRIBUTION PARAMETER ESTIMATES");
    FrmOutPut->RichOutPut->Lines->Add("");

    for (j = 1; j <= noselected; j++)  // loop start for all selected variables
    {
         deviation = 0.0;
         devsqr = 0.0;
         M2 = 0.0;
         M3 = 0.0;
         M4 = 0.0;
         sum = 0.0;
         variance = 0.0;
         stddev = 0.0;
         range = 0.0;
         skew = 0.0;
         kurtosis = 0.0;
         ncases = 0;
         seskew = 0.0;
         kurtosis = 0.0;
         sekurtosis = 0.0;
         ConfInt = 0.0;
         GeoMean =  0.0;
         GeoVar = 0.0;
         HarmMean = 0.0;
         poscount = 0.0;
         k = selected[j-1];
         if ((zScoresChk->Checked)& (!ReadDiskFile)) // add a new column to the grid
         {
              // update definitions and grid
              NoVariables = NoVariables + 1;
              MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
              NewVar(NoVariables,false);
              gridstring = MainForm->Grid->Cells[k][0];
              gridstring = gridstring + 'z';
              DictionaryForm->DGrid->Cells[1][NoVariables] = gridstring;
              MainForm->Grid->Cells[NoVariables][0] = gridstring;
        }

         // Accumulate sums of squares, sums, etc. for variable j
         min = 1.0e20;
         max = -1.0e20;
         if (!ReadDiskFile)
         {
                for (i = 1; i <= NoCases; i++)
                {
                        if ((CaseDelChk->Checked) &&
                                (!ValidRecord(i,selected,noselected))) continue;
                        if (!ValidValue(i,selected[j-1])) continue;
                        value = StrToFloat(MainForm->Grid->Cells[k][i]);
                        ncases = ncases + 1;
                        sum = sum + value;
                        logvalues[i-1] = 0.0;
                        if (value > 0.0)
                        {
                           logvalues[i-1] = log(value);
                           GeoMean += logvalues[i-1];
                           HarmMean += 1.0 / value;
                           poscount += 1.0;
                        }
                        variance = variance + (value * value);
                        if (value < min) min = value;
                        if (value > max) max = value;
                }
         }
         else // get data from the disk file
         {
                DiskValues = new AnsiString[NoVariables];
                for (i = 0; i < NoCases; i++)
                {
                        HugeFileForm->GetDiskValues(DiskValues,NoVariables);
                        value = StrToFloat(DiskValues[k-1]);
                        ncases = ncases + 1;
                        sum = sum + value;
                        variance = variance + (value * value);
                        if (value < min) min = value;
                        if (value > max) max = value;
                }
                fseek(datafile,0,0);
         }

         if (ncases > 0)
         {
              mean = sum / ncases;
              range = max - min;
         }
         if (ncases > 1)
         {
              if (poscount > 0)
              {
                GeoMean = GeoMean / poscount;
                HarmMean = poscount / HarmMean;
              }
              variance = variance - (sum * sum) / ncases;
              variance = variance / (ncases - 1);
              stddev = sqrt(variance);
              semean = sqrt(variance / ncases);
              ConfInt = StrToFloat(CIEdit->Text);
              CI = ConfInt;
              ConfInt = (1.0 - ConfInt) / 2.0;
              ConfInt = 1.0 - ConfInt;
              if (ncases >120) ConfInt = semean * inversez(ConfInt);
              else ConfInt = semean * inverset(ConfInt,float(ncases-1));
              if (poscount > 0)
              {
                for (i = 0; i < NoCases; i++) GeoVar =  GeoVar +
                        sqr(logvalues[i] - GeoMean);
                GeoVar = GeoVar / (poscount-1.0);
                GeoSD = sqrt(GeoVar);
                GeoMean = exp(GeoMean);
              }
         }
         if (ncases > 3) // obtain skew, kurtosis and z scores
         {
              for (i = 1; i <= NoCases; i++)
              {
                   if (!ReadDiskFile)
                   {
                        if ((CaseDelChk->Checked) &&
                                (!ValidRecord(i,selected,noselected))) continue;
                        if (!ValidValue(i,selected[j-1])) continue;
                        if (CaseDelChk->Checked)
                        {
                                if (!ValidValue(i,selected[j-1])) continue;
                        }
                        value = StrToFloat(MainForm->Grid->Cells[k][i]);
                        if (stddev > 0.0)
                        {
                                deviation = value - mean;
                                devsqr = deviation * deviation;
                                M2 = M2 + devsqr;
                                M3 = M3 + (deviation * devsqr);
                                M4 = M4 + (devsqr * devsqr);
                                z = (value - mean) / stddev;
                                if (zScoresChk->Checked)
                                {
                                        sprintf(outline,"%8.5f",z);
                                        MainForm->Grid->Cells[NoVariables][i] = outline;
                                }
                        }
                   }
                   else // read from disk file
                   {
                        HugeFileForm->GetDiskValues(DiskValues,NoVariables);
                        value = StrToFloat(DiskValues[k-1]);
                        if (stddev > 0.0)
                        {
                                deviation = value - mean;
                                devsqr = deviation * deviation;
                                M2 = M2 + devsqr;
                                M3 = M3 + (deviation * devsqr);
                                M4 = M4 + (devsqr * devsqr);
                        }
                   }
              } // next i case
              if (ReadDiskFile) fseek(datafile,0,0);
         } // if ncases > 3
         if (ncases > 2)
         {
                if (variance > 0.0)
                {
                   skew = (ncases * M3) /
                        ((ncases - 1) * (ncases - 2) * stddev * variance);
                   cases = ncases;
                   num = 6.0 * cases * (cases - 1.0);
                   den = (cases - 2.0) * (cases + 1.0) * (cases + 3.0);
                   seskew = sqrt(num / den);
                }
                else
                {
                   skew = 0.0;
                   seskew = 0.0;
                }
         }
         if (ncases > 3)
         {
                if (variance > 0.0)
                {
                   kurtosis = (ncases * (ncases + 1) * M4) -
                        (3 * M2 * M2 * (ncases - 1));
                   kurtosis = kurtosis /
                     ( (ncases - 1) * (ncases - 2) * (ncases - 3) * (variance * variance) );
                   sekurtosis = sqrt( (4.0 * (ncases * ncases - 1) * (seskew * seskew) ) /
                                ( (ncases - 3) * (ncases + 5) ) );
                }
                else
                {
                   kurtosis = 0.0;
                   sekurtosis = 0.0;
                }
         }

         // output results for the kth variable
         cellstring = MainForm->Grid->Cells[k][0];
         FrmOutPut->RichOutPut->Lines->Add("========================================================");
         cellstring = MainForm->Grid->Cells[k][0];
         if (SizeSumChk->Checked)
         {
            sprintf(outline,"%s (N = %d)  Sum = %14.3f",cellstring,ncases,sum);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (MeanVarSDChk->Checked)
         {
            sprintf(outline,"%s (N = %d) Mean = %10.3f  Variance = %10.3f  Std.Dev. = %10.3f",
                 cellstring,ncases, mean, variance, stddev);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (SDMeanChk->Checked)
         {
            sprintf(outline,"Std.Error of Mean = %10.3f",semean);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (CIChk->Checked)
         {
            sprintf(outline," %5.3f Confidence Interval for mean : %10.3f to %10.3f",
                CI, mean - ConfInt, mean + ConfInt);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if ((GeoMeanChk->Checked) && (poscount > 0))
         {
            sprintf(outline,"Geometric Mean = %10.3f  Variance of logs = %10.3f  Std.Dev. of logs = %10.3f",
                 GeoMean, GeoVar, GeoSD);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if ((HarmMeanChk->Checked)&& (poscount > 0))
         {
            sprintf(outline,"Harmonic Mean = %10.3f  N positive values = %10.0f",
                HarmMean, poscount);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (RangeChk->Checked)
         {
            sprintf(outline,"Range = %10.3f  Minimum = %10.3f  Maximum = %10.3f",
             range, min, max);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (SkewChk->Checked)
         {
            sprintf(outline,"Skewness = %10.3f  Std. Error of Skew = %10.3f",
             skew, seskew);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (KurtosisChk->Checked)
         {
            sprintf(outline,"Kurtosis = %10.3f  Std. Error Kurtosis = %10.3f",
             kurtosis, sekurtosis);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }

         if (ncases > 4) // percentile ranks
         {
                // get minimum and maximum scores and score interval
                intvlsize = 10000.0;
                lastX = 0.0;
                X = StrToFloat(MainForm->Grid->Cells[k][1]);
                minscr = X;
                maxscr = X;
                for (i = 1; i <= NoCases; i++)
                {
                        if (!ValidRecord(i,selected,noselected)) continue;
                        if (!ValidValue(i,selected[j-1])) continue;
                        if (CaseDelChk->Checked)
                        {
                                if (!ValidValue(i,selected[j-1])) continue;
                        }
                        value = StrToFloat(MainForm->Grid->Cells[k][i]);
                        X = value;
                        if (X > maxscr) maxscr = X;
                        if (X < minscr) minscr = X;
                        if (i > 1) // get interval size as minimum difference between 2 scores
                        {
                                if ((X != lastX) && (fabs(X - lastX) < intvlsize)) intvlsize = fabs(X - lastX);
                                lastX = X;
                        }
                        else lastX = X;
                }

                //  check for excess no. of intervals and reset if needed
                nscrgrps = ceil(fabs(maxscr - minscr) / intvlsize);
                if (nscrgrps > (2 * NoCases)) intvlsize = (maxscr - minscr) /  NoCases;
                // setup score groups
                bool done = false;
                Scores[0] = minscr - (intvlsize / 2.0);
                nscrgrps = 0;
                lastX = maxscr + intvlsize + (intvlsize / 2.0);

                while (! done)
                {
                        nscrgrps = nscrgrps + 1;
                        Scores[nscrgrps] = minscr + (nscrgrps * intvlsize) - (intvlsize / 2.0);
                        if (Scores[nscrgrps] > lastX) done = true;
                }
                Scores[nscrgrps+1] = Scores[nscrgrps] + intvlsize;
                if (Scores[0] < minscr) minscr = Scores[0];
                if (Scores[nscrgrps] > maxscr) maxscr = Scores[nscrgrps];

                // get score groups for this group j
                for (i = 0; i <= nscrgrps; i++)
                {
                        cumfreq[i] = 0.0;
                        freq[i] = 0.0;
                }
                int cnt = 0;
                for (i = 1; i <= NoCases; i++)
                {   // get scores for this variable j
                        if (!ValidRecord(i,selected,noselected)) continue;
                        if (!ValidValue(i,k)) continue;
                        if (CaseDelChk->Checked)
                        {
                                if (!ValidValue(i,k)) continue;
                        }
                        value = StrToFloat(MainForm->Grid->Cells[k][i]);
                        X = value;
                        cnt = cnt + 1;
                        // find score interval and add to the frequency
                        for (int l = 0; l <= nscrgrps; l++)
                        {
                                if ((X >= Scores[l]) && (X < Scores[l+1]))
                                freq[l] = freq[l] + 1;
                        }
                }

                // get alternative median, quartiles and quartile range
                double *sortedvalues;
                sortedvalues = new double[NoCases+1];
                cnt = 0;
                for (int i = 1; i <= NoCases; i++)
                {
                        if (!ValidRecord(i,selected,noselected)) continue;
                        if (!ValidValue(i,k)) continue;
                        if (CaseDelChk->Checked)
                        {
                                if (!ValidValue(i,k)) continue;
                        }
                        X = StrToFloat(MainForm->Grid->Cells[k][i]);
                        cnt = cnt + 1;
                        sortedvalues[cnt] = X;
                }
                for (int i = 1; i < cnt-1; i++)
                {
                        for (int j = i+1; j <= cnt; j++)
                        {
                                if (sortedvalues[i] > sortedvalues[j])
                                {
                                        double temp = sortedvalues[i];
                                        sortedvalues[i] = sortedvalues[j];
                                        sortedvalues[j] = temp;
                                }
                        }
                }
/*  test block
                sprintf(outline,"%s","Sorted Values");
                FrmOutPut->RichOutPut->Lines->Add(outline);
                for (int i = 0; i <= cnt; i++)
                {
                        sprintf(outline,"%10.3f",sortedvalues[i]);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                }
                FrmOutPut->ShowModal();
*/
                double Q1 = Quartiles(2,0.25,cnt,sortedvalues);
                double Q2 = Quartiles(2,0.5,cnt,sortedvalues);
                double Q3 = Quartiles(2,0.75,cnt,sortedvalues);
                if (MedianChk->Checked)
                {
                   sprintf(outline,"Median = %8.3f",Q2);
                   FrmOutPut->RichOutPut->Lines->Add(outline);
                   sprintf(outline,"Q1 =     %8.3f",Q1);
                   FrmOutPut->RichOutPut->Lines->Add(outline);
                   sprintf(outline,"Q3 =     %8.3f",Q3);
                   FrmOutPut->RichOutPut->Lines->Add(outline);
                   sprintf(outline,"Interquartile range = %8.3f",Q3-Q1);
                   FrmOutPut->RichOutPut->Lines->Add(outline);
                }
//                FrmOutPut->RichOutPut->Lines->Add("========================================================");
                FrmOutPut->RichOutPut->Lines->Add("");


                // accumulate frequencies
                cumfreq[0] = freq[0];
                for (i = 1; i <= nscrgrps-1; i++) cumfreq[i] = cumfreq[i-1] + freq[i];
                cumfreq[nscrgrps] = cumfreq[nscrgrps-1];

                // get percentile ranks
                prank[0] = ((cumfreq[0] / 2.0) / cnt) * 100.0;
                for (i = 1; i <= nscrgrps-1; i++)
                        prank[i] = ((cumfreq[i-1] + (freq[i] / 2.0)) / cnt) * 100.0;

// This next section explores alternative definitions for percentiles
                if (QuartilesChk->Checked)
                {
                        FrmOutPut->RichOutPut->Lines->Add("Alternative Methods for Obtaining Quartiles");
                        FrmOutPut->RichOutPut->Lines->Add("    Method 1    2       3       4       5       6       7       8");
                        FrmOutPut->RichOutPut->Lines->Add("Pcntile");
                        Q1 = Quartiles(1,0.25,cnt,sortedvalues);
                        double Q12 = Quartiles(2,0.25,cnt,sortedvalues);
                        double Q13 = Quartiles(3,0.25,cnt,sortedvalues);
                        double Q14 = Quartiles(4,0.25,cnt,sortedvalues);
                        double Q15 = Quartiles(5,0.25,cnt,sortedvalues);
                        double Q16 = Quartiles(6,0.25,cnt,sortedvalues);
                        double Q17 = Quartiles(7,0.25,cnt,sortedvalues);
                        double Q18 = Quartiles(8,0.25,cnt,sortedvalues);
                        sprintf(outline,"Q1   %8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f",Q1,Q12,Q13,Q14,Q15,Q16,Q17,Q18);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        Q2 = Quartiles(1,0.5,cnt,sortedvalues);
                        double Q22 = Quartiles(2,0.5,cnt,sortedvalues);
                        double Q23 = Quartiles(3,0.5,cnt,sortedvalues);
                        double Q24 = Quartiles(4,0.5,cnt,sortedvalues);
                        double Q25 = Quartiles(5,0.5,cnt,sortedvalues);
                        double Q26 = Quartiles(6,0.5,cnt,sortedvalues);
                        double Q27 = Quartiles(7,0.5,cnt,sortedvalues);
                        double Q28 = Quartiles(8,0.5,cnt,sortedvalues);
                        sprintf(outline,"Q2   %8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f",Q2,Q22,Q23,Q24,Q25,Q26,Q27,Q28);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        Q3 = Quartiles(1,0.75,cnt,sortedvalues);
                        double Q32 = Quartiles(2,0.75,cnt,sortedvalues);
                        double Q33 = Quartiles(3,0.75,cnt,sortedvalues);
                        double Q34 = Quartiles(4,0.75,cnt,sortedvalues);
                        double Q35 = Quartiles(5,0.75,cnt,sortedvalues);
                        double Q36 = Quartiles(6,0.75,cnt,sortedvalues);
                        double Q37 = Quartiles(7,0.75,cnt,sortedvalues);
                        double Q38 = Quartiles(8,0.75,cnt,sortedvalues);
                        sprintf(outline,"Q3   %8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f%8.3f",Q3,Q32,Q33,Q34,Q35,Q36,Q37,Q38);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        FrmOutPut->RichOutPut->Lines->Add("NOTES:");
                        FrmOutPut->RichOutPut->Lines->Add("Method 1 is the weighted average at X[np] where n is no. of cases, p is percentile / 100");
                        FrmOutPut->RichOutPut->Lines->Add("Method 2 is the weighted average at X[(n+1)p] This is used in this program.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 3 is the empirical distribution function.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 4 is called the empirical distribution function - averaging.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 5 is called the empirical distribution function = Interpolation.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 6 is the closest observation method.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 7 is from the TrueBasic Statistics Graphics Toolkit.");
                        FrmOutPut->RichOutPut->Lines->Add("Method 8 was used in an older Microsoft Excel version.");
                        FrmOutPut->RichOutPut->Lines->Add("See the internet site http://www.xycoon.com/ for the above.");
                        FrmOutPut->RichOutPut->Lines->Add("========================================================");
                        FrmOutPut->RichOutPut->Lines->Add("");
                }  // end of experimental alternatives

                if (PcntileChk->Checked)
                {
                        double midval;
                        FrmOutPut->RichOutPut->Lines->Add("PERCENTILE RANKS");
                        FrmOutPut->RichOutPut->Lines->Add("Score Value    Interval Range    Frequency   Cum.Freq. Percentile Rank");
                        FrmOutPut->RichOutPut->Lines->Add("___________  _________ _________ __________  __________ ______________");
                        for (i = 0; i <= nscrgrps-1; i++)
                        {
                                midval = (Scores[i+1] - Scores[i]) / 2.0 + Scores[i];
                                sprintf(outline,"  %8.3f   %6.2f - %6.2f     %6.2f     %6.2f      %6.2f",
                                        midval, Scores[i],Scores[i+1],freq[i],cumfreq[i],prank[i]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                        FrmOutPut->RichOutPut->Lines->Add("");
                }
                delete[] sortedvalues;
         } // if ncases > 4
   } // next j variable
   FrmOutPut->ShowModal();

finish:
   delete[] logvalues;
   delete[] prank;
   delete[] cumfreq;
   delete[] freq;
   delete[] Scores;
   delete[] selected;
}
//---------------------------------------------------------------------------
void __fastcall TDescriptiveForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------


