//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FrmFDSpecs.h"

//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFDSpecs *FDSpecs;

//---------------------------------------------------------------------------
__fastcall TFDSpecs::TFDSpecs(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFDSpecs::BtnOKClick(TObject *Sender)
{
	FDSpecs->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFDSpecs::BtnCancelClick(TObject *Sender)
{
	FDSpecs->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFDSpecs::TxtIntSizeKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
     double noints, intsize, range;
     if (Key == 13)
     {
        range = StrToFloat(TxtRange->Text);
        intsize = StrToFloat(TxtIntSize->Text);
        noints = range / intsize;
        TxtNoIntervals->Text = FloatToStr(noints);
        TxtNoIntervals->SetFocus();
     }
}
//---------------------------------------------------------------------------

