//---------------------------------------------------------------------------

#ifndef KappaUnitH
#define KappaUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TKappaForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TBitBtn *CatIn;
    TBitBtn *CatOut;
    TLabel *Label3;
    TEdit *RaterEdit;
    TBitBtn *RaterIn;
    TBitBtn *RaterOut;
    TEdit *CatEdit;
    TBitBtn *ObjIn;
    TBitBtn *ObjOut;
    TEdit *ObjectEdit;
    TLabel *Label4;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CatInClick(TObject *Sender);
    void __fastcall CatOutClick(TObject *Sender);
    void __fastcall ObjInClick(TObject *Sender);
    void __fastcall ObjOutClick(TObject *Sender);
    void __fastcall RaterInClick(TObject *Sender);
    void __fastcall RaterOutClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    int NoRaters, NoCats, NoObjects;
    double compute_term1(int ***R, int i, int j, int k);
    double compute_term2(int ***R, int i, int j, int k);
    double compute_denom(int ***R);
    double compute_partial_pchance(int ***R, int i, int j, double denom);
    double compute_partial_pobs(int ***R, int k, int l);
    double KappaVariance(int ***R,int n, int m, int K);

public:		// User declarations
    __fastcall TKappaForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKappaForm *KappaForm;
//---------------------------------------------------------------------------
#endif
