//---------------------------------------------------------------------------

#ifndef TwoWayRepUnitH
#define TwoWayRepUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTwoWayRepForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TListBox *VarList;
    TBitBtn *SubjInBtn;
    TBitBtn *SubjOutBtn;
    TBitBtn *FactAInBtn;
    TBitBtn *FactAOutBtn;
    TBitBtn *FactBInBtn;
    TBitBtn *FactBOutBtn;
    TBitBtn *MeasInBtn;
    TBitBtn *MeasOutBtn;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TEdit *SubjectEdit;
    TEdit *FactorAEdit;
    TEdit *FactorBEdit;
    TEdit *MeasurementEdit;
    TGroupBox *GroupBox1;
    TCheckBox *PlotAChk;
    TCheckBox *PlotBChk;
    TCheckBox *PlotABChk;
    TCheckBox *PostHocChk;
    TLabel *Label6;
    TEdit *SigLevelEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TRadioGroup *OptionsBox;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall SubjInBtnClick(TObject *Sender);
    void __fastcall SubjOutBtnClick(TObject *Sender);
    void __fastcall FactAInBtnClick(TObject *Sender);
    void __fastcall FactAOutBtnClick(TObject *Sender);
    void __fastcall FactBInBtnClick(TObject *Sender);
    void __fastcall FactBOutBtnClick(TObject *Sender);
    void __fastcall MeasInBtnClick(TObject *Sender);
    void __fastcall MeasOutBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TTwoWayRepForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTwoWayRepForm *TwoWayRepForm;
//---------------------------------------------------------------------------
#endif
