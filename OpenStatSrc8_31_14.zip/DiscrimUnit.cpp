//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DiscrimUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TNeuralDiscrimForm *NeuralDiscrimForm;
//---------------------------------------------------------------------------
__fastcall TNeuralDiscrimForm::TNeuralDiscrimForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
