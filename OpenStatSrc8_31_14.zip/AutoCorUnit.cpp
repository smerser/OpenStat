//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "functions.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "AutoPlotUnit.h"
#include "Printers.hpp"
#include <math.h>
#include "MovAvgUnit.h"
#include "AutoCorUnit.h"
#include "PointsUnit.h"
#include "ExpSmoothUnit.h"
#include "FFTUnit.h"
#include "DifferenceUnit.h"
#include "PolyFitUnit.h"
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAutoCorFrm *AutoCorFrm;
#define SWAP(a,b) tempr=(a);(a)=(b);(b)=tempr

extern int NoVariables;
extern int NoCases;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TAutoCorFrm::TAutoCorFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::ResetBtnClick(TObject *Sender)
{
    VarList->Clear();
    if (ColBtn->Checked)
    {
        for (int i = 0; i < NoVariables; i++) VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
        MaxLagEdit->Text = NoCases;
    }
    else
    {
        for (int i = 0; i < NoCases; i++) VarList->Items->Add(MainForm->Grid->Cells[0][i+1]);
        MaxLagEdit->Text = NoVariables;
    }
    DepVarEdit->Text = "";
    if (ops.format == 0) ConfidenceEdit->Text = "0.95";
    else ConfidenceEdit->Text = "0,95";
    PlotCorsChk->Checked = false;
    PrtPartialsChk->Checked = false;
    MeanOutChk->Checked = false;
    PrtCorsChk->Checked = false;
    YuleWalkerChk->Checked = false;
    MoveAvgChk->Checked = false;
    ExpSmoothChk->Checked = false;
    FourierSmoothChk->Checked = false;
    DifferenceChk->Checked = false;
    PolyChk->Checked = false;
    FromCasesEdit->Text = "";
    ToCasesEdit->Text = "";
    ColBtn->Checked = true;
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::CancelBtnClick(TObject *Sender)
{
    AutoCorFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::ReturnBtnClick(TObject *Sender)
{
    AutoCorFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::VarListClick(TObject *Sender)
{
    int ItemIndex = VarList->ItemIndex;
    DepVarEdit->Text = VarList->Items->Strings[ItemIndex];
}
//---------------------------------------------------------------------------
void __fastcall TAutoCorFrm::ComputeBtnClick(TObject *Sender)
{
    double **correlations, **Inverse, *Means, *StdDevs, *PartCors;
    double **v, *W, **a, *betas, *rxy, *pts, *avg, *residual;
    double mean, X, Y, alpha, mean1, mean2, var1, var2, sd1, sd2, uplimit, lowlimit;
    double r2full, r2restrict, covzero, Yhat, Constant;
    int count, npoints, DepVar, maxlag, N, nvalues, NoPts;
    int noproj = 0;
    int *ColNoSelected;
    AnsiString cellstring;
    char outline[101];
    AnsiString *RowLabels;
    AnsiString *ColLabels;
    char Title[81];
    bool negative;
    AnsiString Message;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    // get column of the selected variable if reading columns
    if (ColBtn->Checked)
    {
        // Allocate space for column no. selected
        ColNoSelected = new int [1];
        DepVar = 0;
        for (int i = 0; i < NoVariables; i++)
            if (MainForm->Grid->Cells[i+1][0] == DepVarEdit->Text) DepVar = i+1;
        if (DepVar == 0)
        {
            Application->MessageBox("No variable selected to analyze.","ERROR!",MB_OK);
            delete[] ColNoSelected;
            return;
        }
        ColNoSelected[0] = DepVar;
        //result = VarTypeChk(DepVar,0);
        //if (result == 1)
        //{
        //        delete[] ColNoSelected;
        //        return;
        //}
        NoPts = NoCases;
    }
    else
    {
        // Allocate space for column no. selected
        ColNoSelected = new int [1];
        // get row of the selected case to analyze
        DepVar = 0;
        for (int i = 0; i < NoCases; i++)
            if (MainForm->Grid->Cells[0][i+1] == DepVarEdit->Text) DepVar = i+1;
            if (DepVar == 0)
            {
                Application->MessageBox("No case selected to analyze.","ERROR!",MB_OK);
                delete[] ColNoSelected;
                return;
            }
        ColNoSelected[0] = DepVar;
        NoPts = NoVariables;
    }

    // Get the alpha level and the maximum lag values
    alpha = 1.0 - atof(ConfidenceEdit->Text.c_str());
    // Get no. of points to project, if any
    if (ProjectChk->Checked) noproj = floor(StrToFloat(ProjPtsEdit->Text));
    // Get maximum lag specified by user
    maxlag = floor(StrToFloat(MaxLagEdit->Text));
    if (maxlag > NoPts / 2) maxlag = maxlag / 2;
    if (floor(StrToFloat(MaxLagEdit->Text)) > maxlag) MaxLagEdit->Text = maxlag;
    npoints = maxlag + 2;

    // allocate space for covariance and correlation matrices, etc.
    correlations = new double *[npoints];
    for (int i = 0; i < npoints; i++) correlations[i] = new double[npoints];
    Means = new double[npoints];
    StdDevs = new double[npoints];
    RowLabels = new AnsiString[npoints];
    ColLabels = new AnsiString[npoints];
    PartCors = new double[npoints];
    Inverse = new double *[npoints];
    for (int i = 0; i < npoints; i++) Inverse[i] = new double[npoints];
    v = new double *[npoints];
    for (int i = 0; i < npoints; i++) v[i] = new double[npoints];
    W = new double[npoints];
    a = new double *[npoints];
    for (int i = 0; i < npoints; i++) a[i] = new double[npoints];
    betas = new double[npoints];
    rxy = new double[npoints];
    pts = new double[NoPts+noproj+10];
    avg = new double[NoPts+noproj+10];
    residual = new double[NoPts+noproj+10];

    // Initialize arrays
    for (int i = 0; i < npoints; i++)
    {
        for (int j = 0; j < npoints; j++)
        {
            correlations[i][j] = 0.0;
            Inverse[i][j] = 0.0;
            v[i][j] = 0.0;
            a[i][j] = 0.0;
        }
        Means[i] = 0.0;
        StdDevs[i] = 0.0;
        cellstring = "Lag ";
        cellstring = cellstring + i;
        RowLabels[i] = cellstring;
        ColLabels[i] = RowLabels[i];
        PartCors[i] = 0.0;
        W[i] = 0.0;
        betas[i] = 0.0;
    }
    uplimit = 0.0;
    lowlimit = 0.0;
    covzero = 0.0;

    // Get points to analyze
    if (ColBtn->Checked)
    {
        if (AllCasesBtn->Checked)
        {
            for (int i = 0; i < NoPts; i++)
            {
                //result = GetValue(i+1,DepVar,intvalue,dblvalue,strvalue);
                //if (result == 1) pts[i] = 0.0;
                //else pts[i] = dblvalue;
                pts[i] = StrToFloat(MainForm->Grid->Cells[DepVar][i+1]);
            }
        }
        else
        {
            NoPts = 0;
            int frompt = floor(StrToFloat(AutoCorFrm->FromCasesEdit->Text));
            int topt = floor(StrToFloat(AutoCorFrm->ToCasesEdit->Text));
            for (int i = frompt; i <= topt; i++)
            {
                pts[NoPts] = StrToFloat(MainForm->Grid->Cells[DepVar][i+1]);
                //result = GetValue(i+1,DepVar,intvalue,dblvalue,strvalue);
                //if (result == 1) pts[NoPts] = 0.0;
                //else pts[NoPts] = dblvalue;
                NoPts++;
            }
        }
    }
    else // reading values for a case
    {
        if (AllCasesBtn->Checked)
        {
            for (int i = 0; i < NoPts; i++)
            {
                pts[i] = StrToFloat(MainForm->Grid->Cells[i+1][DepVar]);
                //result = GetValue(DepVar,i+1,intvalue,dblvalue,strvalue);
                //if (result == 1) pts[i] = 0.0;
                //else pts[i] = dblvalue;
            }
        }
        else
        {
            NoPts = 0;
            int frompt = floor(StrToFloat(AutoCorFrm->FromCasesEdit->Text));
            int topt = floor(StrToFloat(AutoCorFrm->ToCasesEdit->Text));
            for (int i = frompt; i <= topt; i++)
            {
                pts[NoPts] = StrToFloat(MainForm->Grid->Cells[i+1][DepVar]);
                //result = GetValue(DepVar,i+1,intvalue,dblvalue,strvalue);
                //if (result == 1) pts[NoPts] = 0.0;
                //else pts[NoPts] = dblvalue;
                NoPts++;
            }
        }
    }

    // Calculate mean of all values
    mean = 0.0;
    count = NoPts;
    for (int i = 1; i <= NoPts; i++) mean += pts[i-1];

    correlations[0][0] = 1.0;
    mean = mean / count;

    // Remove mean from all observations if elected
    if (MeanOutChk->Checked)
        for (int i = 0; i < NoPts; i++) pts[i] = pts[i] - mean;

    // Do differencing if checked
    if (DifferenceChk->Checked)
    {
        if (DifferenceFrm->ShowModal() == mrOk)
        {
            int lag = floor(StrToFloat(DifferenceFrm->LagEdit->Text));
            int order = floor(StrToFloat(DifferenceFrm->OrderEdit->Text));
            // Store original points temporarily in residual vector
            for (int i = 0; i < NoPts; i++) residual[i] = pts[i];
            for (int j = 0; j < order; j++) // no. of times to repeat differencing
            {
                // get differences for lag difference specified
                for (int i = 0; i < NoPts-lag; i++) avg[i] = pts[i+lag] - pts[i];
                // Replace original points with the differences obtained
                for (int i = 0; i < NoPts-lag; i++) pts[i] = avg[i];
                NoPts = NoPts-lag; // Reset no. of points to reflect differencing
            }
            // restore original points (up to new no. of points)
            for (int i = 0; i < NoPts; i++) pts[i] = residual[i];
            // plot the original and differenced values
            PointsFrm->pts = pts;
            PointsFrm->avg = avg;
            PointsFrm->NoCases = NoPts;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Differenced");
            Message = "No. points = ";
            Message = Message + NoPts;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->Title,"Smoothed by Differencing");
            PointsFrm->Caption = "Smoothing by Differencing";
            PointsFrm->ShowModal();
            if (ResidPlotChk->Checked) // calculate and plot residuals;
            {
                double varresid = 0.0;
                double StdErr;
                for (int i = 0; i < NoPts; i++)
                {
                    residual[i] = pts[i] - avg[i];
                    varresid += (residual[i] * residual[i]);
                }
                varresid /= NoPts;
                StdErr = sqrt(varresid);
                // plot the residuals
                PointsFrm->pts = pts;
                PointsFrm->avg = residual;
                PointsFrm->NoCases = NoPts;
                Message = "Std. Err. Residuals = ";
                Message = Message + StdErr;
                PointsFrm->MsgEdit->Text = Message;
                strcpy(PointsFrm->LabelOne,"Original");
                strcpy(PointsFrm->LabelTwo,"Residuals");
                strcpy(PointsFrm->Title,"Residuals from Differences");
                PointsFrm->Caption = "Differencing Residuals";
                PointsFrm->ShowModal();
            }
            // replace original points with smoothed values
            for (int i = 0; i < NoPts; i++) pts[i] = avg[i];
        }
    }

    if (MoveAvgChk->Checked)
    {
        MoveAvgFrm->ShowModal();
        nvalues = MoveAvgFrm->order;
        if (nvalues > 0)
        {
            // plot the original points and the smoothed average
            for (int i = nvalues; i < NoPts-nvalues; i++)
            {
                avg[i] = pts[i] * MoveAvgFrm->W[0]; // middle value
                for (int j = 1; j <= nvalues; j++) // left values
                    avg[i] += (pts[i-j] * MoveAvgFrm->W[j]);
                for (int j = 1; j <= nvalues; j++) // right values
                    avg[i] += (pts[i+j] * MoveAvgFrm->W[j]);
            }
            // fill in unestimable averages with original points
            for (int i = 0; i < nvalues; i++) // left values
            {
                avg[i] = pts[i] * MoveAvgFrm->W[0];
                for (int j = 1; j <=nvalues; j++)
                    avg[i] += (pts[i+j] * 2.0 * MoveAvgFrm->W[j]);
            }
            for (int i = NoPts-nvalues; i < NoPts; i++) //right values
            {
                avg[i] = pts[i] * MoveAvgFrm->W[0];
                for (int j = 1; j <=nvalues; j++)
                    avg[i] += (pts[i-j] * 2.0 * MoveAvgFrm->W[j]);
            }
            if (ProjectChk->Checked)
            {
                for (int i = 0; i < noproj; i++)
                {
                    avg[NoPts+i] = avg[NoPts-1];
                    pts[NoPts+i] = pts[NoPts-1];
                }
            }
            // plot the points
            PointsFrm->pts = pts;
            PointsFrm->avg = avg;
            PointsFrm->NoCases = NoPts + noproj;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Smoothed");
            Message = "No. points = ";
            Message = Message + NoPts;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->Title,"Moving Average Smoothed");
            PointsFrm->Caption = "Moving Average Smoothing";
            PointsFrm->ShowModal();
        }
        if (ResidPlotChk->Checked) // calculate and plot residuals;
        {
            double varresid = 0.0;
            double StdErr;
            for (int i = 0; i < NoPts; i++)
            {
                residual[i] = pts[i] - avg[i];
                varresid += (residual[i] * residual[i]);
            }
            varresid /= NoPts;
            StdErr = sqrt(varresid);
            // plot the residuals
            PointsFrm->pts = pts;
            PointsFrm->avg = residual;
            PointsFrm->NoCases = NoPts;
            Message = "Std. Err. Residuals = ";
            Message = Message + StdErr;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Residuals");
            strcpy(PointsFrm->Title,"Residuals from Moving Average");
            PointsFrm->Caption = "Moving Average Residuals";
            PointsFrm->ShowModal();
        }
        // replace original points with smoothed values
        for (int i = 0; i < NoPts+noproj; i++) pts[i] = avg[i];
    }

    // do exponential smoothing if requested
    if (ExpSmoothChk->Checked)
    {
        ExpSmoothFrm->ShowModal();
        double alpha = ExpSmoothFrm->alpha;
        avg[0] = pts[0]; // set first value = to observed
        for (int t = 1; t < NoPts; t++ ) // case pointer
        {
            avg[t] = alpha * pts[t];
            avg[t] = avg[t] + (1.0 - alpha) * avg[t-1];
        }
        if (ProjectChk->Checked)
        {
            for (int i = 0; i < noproj; i++)
            {
                avg[NoPts+i] = alpha * pts[NoPts+i-1];
                avg[NoPts+i] += ((1.0 - alpha) * avg[NoPts+i-1]);
                pts[NoPts+i] = avg[NoPts+i];
            }
        }
        // plot the points
        PointsFrm->pts = pts;
        PointsFrm->avg = avg;
        PointsFrm->NoCases = NoPts+noproj;
        strcpy(PointsFrm->LabelOne,"Original");
        strcpy(PointsFrm->LabelTwo,"Smoothed");
        strcpy(PointsFrm->Title,"Exponential Smoothed");
        PointsFrm->Caption = "Exponential Smoothing";
        PointsFrm->ShowModal();
        if (ResidPlotChk->Checked) // calculate and plot residuals;
        {
            double varresid = 0.0;
            double StdErr;
            for (int i = 0; i < NoPts; i++)
            {
                residual[i] = pts[i] - avg[i];
                varresid += (residual[i] * residual[i]);
            }
            varresid /= NoPts;
            StdErr = sqrt(varresid);
            // plot the residuals
            PointsFrm->pts = pts;
            PointsFrm->avg = residual;
            PointsFrm->NoCases = NoPts;
            Message = "Std. Err. Residuals = ";
            Message = Message + StdErr;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Residuals");
            strcpy(PointsFrm->Title,"Residuals from Exponential Smoothing");
            PointsFrm->Caption = "Exponential Residuals";
            PointsFrm->ShowModal();
        }
        // replace original points with smoothed values
        for (int i = 0; i < NoPts+noproj; i++) pts[i] = avg[i];
    }

    // Fast Fourier smoothing, if requested
    if (FourierSmoothChk->Checked)
    {
        for (int i = 0; i < NoPts; i++) avg[i] = pts[i];
        if (ProjectChk->Checked)
        {
            for (int i = 0; i < noproj; i++)
            {
                avg[i] = pts[NoPts-1-noproj+i];
                pts[i] = avg[i];
            }
        }
        FFTFrm->NptsEdit->Text = NoPts+noproj;
        FFTFrm->ShowModal();
        nvalues = atoi(FFTFrm->NptsEdit->Text.c_str());
        fourier(avg,NoPts+noproj,nvalues);
        PointsFrm->pts = pts;
        PointsFrm->avg = avg;
        PointsFrm->NoCases = NoPts+noproj;
        strcpy(PointsFrm->LabelOne,"Original");
        strcpy(PointsFrm->LabelTwo,"Smoothed");
        strcpy(PointsFrm->Title,"Fourier Smoothed");
        PointsFrm->Caption = "Fourier Smoothing";
        PointsFrm->ShowModal();
        if (ResidPlotChk->Checked) // calculate and plot residuals;
        {
            double varresid = 0.0;
            double StdErr;
            for (int i = 0; i < NoPts; i++)
            {
                residual[i] = pts[i] - avg[i];
                varresid += (residual[i] * residual[i]);
            }
            varresid /= NoPts;
            StdErr = sqrt(varresid);
            // plot the residuals
            PointsFrm->pts = pts;
            PointsFrm->avg = residual;
            PointsFrm->NoCases = NoPts;
            Message = "Std. Err. Residuals = ";
            Message = Message + StdErr;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Residuals");
            strcpy(PointsFrm->Title,"Residuals from Fourier Smoothing");
            PointsFrm->Caption = "Fourier Residuals";
            PointsFrm->ShowModal();
        }
        // replace original points with smoothed values
        for (int i = 0; i < NoPts+noproj; i++) pts[i] = avg[i];
    }

    // Get polynomial regression smoothing if elected
    if (PolyChk->Checked)
    {
        if (PolyRegFitFrm->ShowModal() == mrOk)
        {
            if (ProjectChk->Checked)
            {
                for (int i = 0; i < noproj; i++)
                {
                    avg[i] = pts[NoPts-1-noproj+i];
                    pts[i] = avg[i];
                }
            }
            PolyFit(pts,avg,NoPts+noproj);
            // Plot original and smoothed values
            PointsFrm->pts = pts;
            PointsFrm->avg = avg;
            PointsFrm->NoCases = NoPts+noproj;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Smoothed");
            strcpy(PointsFrm->Title,"Polynomial Smoothed");
            PointsFrm->Caption = "Polynomial Smoothing";
            Message = "Polynomial smoothing of order ";
            Message = Message + PolyRegFitFrm->OrderEdit->Text;
            PointsFrm->MsgEdit->Text = Message;
            PointsFrm->ShowModal();

            // Plot residuals if checked
            if (ResidPlotChk->Checked) // calculate and plot residuals;
            {
                double varresid = 0.0;
                double StdErr;
                for (int i = 0; i < NoPts; i++)
                {
                    residual[i] = pts[i] - avg[i];
                    varresid += (residual[i] * residual[i]);
                }
                varresid /= NoPts;
                StdErr = sqrt(varresid);
                // plot the residuals
                PointsFrm->pts = pts;
                PointsFrm->avg = residual;
                PointsFrm->NoCases = NoPts;
                Message = "Std. Err. Residuals = ";
                Message = Message + StdErr;
                PointsFrm->MsgEdit->Text = Message;
                strcpy(PointsFrm->LabelOne,"Original");
                strcpy(PointsFrm->LabelTwo,"Residuals");
                strcpy(PointsFrm->Title,"Residuals from Polynomial Smoothing");
                PointsFrm->Caption = "Polynomial Residuals";
                PointsFrm->ShowModal();
            }
            // replace original points with smoothed values
            for (int i = 0; i < NoPts+noproj; i++) pts[i] = avg[i];
        } // if polyregfrm clicked ok
    } // if polychk checked

    // get mean and variance of (transformed?) points
    mean = 0.0;
    covzero = 0.0;
    for (int i = 0; i < NoPts; i++) mean += pts[i];
    mean /= NoPts;
    for (int i = 1; i <= NoPts; i++)
    {
        X = pts[i-1];
        if (MeanOutChk->Checked) covzero += (X * X);
        else covzero += ((X - mean) * (X - mean));
    }
    covzero /= count;

    sprintf(outline,"Overall mean = %8.3f, variance = %8.3f",mean,covzero);
    FrmOutPut->RichOutPut->Lines->Add(outline);

     // get correlations for each lag 0 to maxlag
     double r, vx,vy,mx,my,sx,sy,Count, StdErr, zconf, UCL, LCL, samptrans, z;
     double confidence = alpha;
     double upper[300];
     double lower[300];
     int ncors = 0, lagvalue[300];
     FrmOutPut->RichOutPut->Lines->Add("Lag      Rxy      MeanX     MeanY    Std.Dev.X Std.Dev.Y    Cases     LCL       UCL");
     FrmOutPut->RichOutPut->Lines->Add("");
     if (maxlag > NoPts - 3)
     {
         maxlag = NoPts - 3;
         MaxLagEdit->Text = IntToStr(maxlag);
     }
     for (int lag = 0; lag <= maxlag; lag++)
     {
          r = 0.0;
          vx = 0.0;
          vy = 0.0;
          mx = 0.0;
          my = 0.0;
          Count = 0.0;
          lagvalue[lag] = lag;
          for (int i = 1; i <= (NoPts - lag); i++)
          {
               X = pts[i-1];
               Y = pts[i-1+lag];
               if (MeanOutChk->Checked) r += (X * Y);
               else r = r + ((X - mean) * (Y - mean));
               vx = vx + (X * X);
               vy = vy + (Y * Y);
               mx = mx + X;
               my = my + Y;
               Count = Count + 1.0;
          }
          r = r / (double)NoPts;
          vx = vx - (mx * mx / (double)Count);
          vx = vx / ((double)Count - 1.0);
          sx = sqrt(vx);
          vy = vy - (my * my / (double)Count);
          vy = vy / ((double)Count - 1.0);
          sy = sqrt(vy);
          mx = mx / (double)Count;
          my = my / (double)Count;
          r /= covzero;
          if (fabs(r) < 1.0) samptrans = log((1.0 + r) / (1.0 - r)) / 2.0;
          // if above failed, r = 1.0
          StdErr = sqrt(1.0 / (NoPts - 3.0));
          zconf = fabs(inversez(confidence / 2.0));
          if (fabs(r) < 1.0)
          {
//               z = samptrans / StdErr;
               UCL = samptrans + (zconf * StdErr);
               LCL = samptrans - (zconf * StdErr);
               UCL = (exp(2.0 * UCL) - 1.0) / (exp(2.0 * UCL) + 1.0);
               LCL = (exp(2.0 * LCL) - 1.0) / (exp(2.0 * LCL) + 1.0);
          }
          else
          {
               UCL = 1.0;
               LCL = 1.0;
          }
          upper[lag] = UCL;
          lower[lag] = LCL;
          sprintf(outline,"%4d %9.4f %9.4f %9.4f %9.4f %9.4f %9.0f %9.4f %9.4f",
                  lag, r, mx, my, sx, sy, Count, LCL, UCL);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          ncors = ncors + 1;
          correlations[0][lag] = r;
          correlations[lag][0] = r;
     }
     FrmOutPut->ShowModal();
    for (int i = 0; i <= maxlag; i++) correlations[i][i] = 1.0;
    for (int i = 1; i <= maxlag; i++)
    {
        for (int j = i+1; j <= maxlag; j++)
        {
            correlations[i][j] = correlations[0][j-i];
            correlations[j][i] = correlations[i][j];
        }
    }

    // Print the correlation matrix if elected
    if (PrtCorsChk->Checked)
    {
        strcpy(Title,"Autocorrelation Matrix of Lagged Variable: ");
        strcat(Title,DepVarEdit->Text.c_str());
        ArrayPrint(correlations,maxlag+1,maxlag+1,"LAG",RowLabels,ColLabels,Title);
        FrmOutPut->ShowModal();
    }

    // Calculate partial correlations
    PartCors[0] = 1.0;
    for (int i = 1; i <= maxlag; i++) // start at lag 1
    {
        for (int j = 1; j <= i; j++)
        {
            for (int k = 1; k <= i; k++)
            {
                a[j][k] = correlations[j][k];
            }
            rxy[j-1] = correlations[0][j];
        }
        matinv(a, i, Inverse,v,W); // Note: matinv subscripts start at 1, not 0
        for (int j = 0; j < i; j++)
            for (int k = 0; k < i; k++)
                a[j][k] = Inverse[j+1][k+1];
        // get betas as product of inverse times vector
        for (int j = 1; j <= i; j++)
        {
            betas[j-1] = 0.0;
            for (int k = 1; k <= i; k++)
                betas[j-1] = betas[j-1] + a[j-1][k-1] * rxy[k-1];
        }
        // get regression constant.  Note: B's = Betas since = variances
        Constant = 0.0;
        if (MeanOutChk->Checked == false)
        {
            for (int j = 1; j <= i; j++) Constant += betas[j-1] * mean;
            Constant = mean - Constant;
        }
        // calculate predicted value and residual
        // Note - the dependent variable predicted is the next value in
        // the time series using each of the previous time period values
        // as predictors
        Yhat = 0.0;
        for (int j = 0; j < i; j++)
        {
            Yhat += (betas[j] * pts[j]);
        }
        Yhat += Constant;
        avg[i] = Yhat;
        residual[i] = pts[i] - Yhat;
        // print betas if elected
        if (YuleWalkerChk->Checked == true)
        {
            FrmOutPut->RichOutPut->Clear();
            sprintf(Title,"Yule-Walker Coefficients for lag %d",i);
            VPrint(betas,maxlag+1,ColLabels,Title);
            sprintf(outline,"Constant = %10.3f",Constant);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->ShowModal();
        }

        PartCors[i] = betas[i-1];
//        for (int j = 0; j < i; j++) betas[j] = 0.0;
    } // next i

    // print partial correlations if elected
    if (PrtPartialsChk->Checked)
    {
        strcpy(Title,"Partial Correlation Coefficients");
        VPrint(PartCors,maxlag+1,ColLabels,Title);
        FrmOutPut->ShowModal();
    }

    // plot correlations if elected
    uplimit = 1.96 * (1.0 / sqrt(count));
    lowlimit = -1.96 * (1.0 / sqrt(count));

    if (PlotCorsChk->Checked)
    {
        AutoPlotFrm->correlations = correlations[0];
        AutoPlotFrm->PlotLimits = true;
        AutoPlotFrm->PlotPartCors = true;
        AutoPlotFrm->partcors = PartCors;
        AutoPlotFrm->uplimit = uplimit;
        AutoPlotFrm->lowlimit = lowlimit;
        AutoPlotFrm->npoints = maxlag+1;
        AutoPlotFrm->DepVarEdit = DepVarEdit->Text;
        AutoPlotFrm->ShowModal();
    }

    // calculate predicted value and residual for remaining points
    // Note - the dependent variable predicted is the next value in
    // the time series using each of the previous time period values
    // as predictors
    for (int i = maxlag+1; i < NoPts; i++)
    {
        Yhat = 0.0;
        for (int j = 0; j < maxlag; j++)
        {
        		Yhat += betas[j] * pts[j];
        }
        Yhat += Constant;
        avg[i] = Yhat;
        residual[i] = pts[i] - Yhat;
    }
    if (ProjectChk->Checked)
    {
//        for (int i = 0; i < noproj; i++) pts[NoPts+i] = pts[NoPts-1-noproj+i];
//        for (int i = 0; i < noproj; i++) pts[NoPts+i] = pts[NoPts-1];
        for (int i = 0; i < noproj; i++)
        {
            Yhat = 0.0;
            for (int j = 0; j < maxlag+1; j++) Yhat += (pts[NoPts+j] * betas[j]);
            Yhat += Constant;
            avg[NoPts+i] = Yhat;
        }
    }

    // plot points smoothed by autoregression
    avg[0] = pts[0];
    PointsFrm->pts = pts;
    PointsFrm->avg = avg;
    PointsFrm->NoCases = NoPts+noproj;
    Message = "Point Smoothing by Regression";
    PointsFrm->MsgEdit->Text = Message;
    strcpy(PointsFrm->LabelOne,"Original");
    strcpy(PointsFrm->LabelTwo,"Smoothed");
    strcpy(PointsFrm->Title,"Autoregressive Smoothed");
    PointsFrm->Caption = "Autoregressive Smoothing";
    PointsFrm->ShowModal();

    //  plot residuals if elected
    if (ResidPlotChk->Checked)
    {
            double varresid = 0.0;
            double StdErr;
            residual[0] = 0.0;
            for (int i = 0;i < maxlag+1; i++)
            {
                try
                {
                    varresid += (residual[i] * residual[i]);
                }
                catch(...)
                {
                    char astr[81];
                    sprintf(astr,"Error in calc. residual for point %d",i);
                    Application->MessageBox(astr,"ERROR!",MB_OK);
                }
            }
            varresid /= maxlag;
            StdErr = sqrt(varresid);
            // plot the residuals
            PointsFrm->pts = pts;
            PointsFrm->avg = residual;
            PointsFrm->NoCases = NoPts;
            Message = "Std. Err. Residuals = ";
            Message = Message + StdErr;
            PointsFrm->MsgEdit->Text = Message;
            strcpy(PointsFrm->LabelOne,"Original");
            strcpy(PointsFrm->LabelTwo,"Residuals");
            strcpy(PointsFrm->Title,"Residuals from Autoregression Smoothing");
            PointsFrm->Caption = "Autoregressive Residuals";
            PointsFrm->ShowModal();
    }

    // clean up the heap
    delete[] residual;
    delete[] avg;
    delete[] pts;
    delete[] rxy;
    delete[] betas;
    for (int i = 0; i < npoints; i++) delete[] a[i];
    delete[] a;
    delete[] W;
    for (int i = 0; i < npoints; i++) delete[] v[i];
    delete[] v;
    for (int i = 0; i < npoints; i++) delete[] Inverse[i];
    delete[] Inverse;
    delete[] PartCors;
    delete[] ColLabels;
    delete[] RowLabels;
    delete[] StdDevs;
    delete[] Means;
    for (int i = 0; i < npoints; i++) delete[] correlations[i];
    delete[] correlations;
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------


void TAutoCorFrm::four1(double *data,unsigned long nn,int isign)
{
	unsigned long n,mmax,m,j,istep,i;
	double wtemp,wr,wpr,wpi,wi,theta;
	float tempr,tempi;

	n=nn << 1;
	j=1;
	for (i=1;i<n;i+=2) {
		if (j > i) {
			SWAP(data[j],data[i]);
			SWAP(data[j+1],data[i+1]);
		}
		m=n >> 1;
		while (m >= 2 && j > m) {
			j -= m;
			m >>= 1;
		}
		j += m;
	}
	mmax=2;
	while (n > mmax) {
		istep=mmax << 1;
		theta=isign*(6.28318530717959/mmax);
		wtemp=sin(0.5*theta);
		wpr = -2.0*wtemp*wtemp;
		wpi=sin(theta);
		wr=1.0;
		wi=0.0;
		for (m=1;m<mmax;m+=2) {
			for (i=m;i<=n;i+=istep) {
				j=i+mmax;
				tempr=wr*data[j]-wi*data[j+1];
				tempi=wr*data[j+1]+wi*data[j];
				data[j]=data[i]-tempr;
				data[j+1]=data[i+1]-tempi;
				data[i] += tempr;
				data[i+1] += tempi;
			}
			wr=(wtemp=wr)*wpr-wi*wpi+wr;
			wi=wi*wpr+wtemp*wpi+wi;
		}
		mmax=istep;
	}
}

//----------------------------------------------------------------------------
void TAutoCorFrm::realft(double *data,unsigned long n,int isign)
{
	unsigned long i,i1,i2,i3,i4,np3;
	float c1=0.5,c2,h1r,h1i,h2r,h2i;
	double wr,wi,wpr,wpi,wtemp,theta;

	theta=3.141592653589793/(double) (n>>1);
	if (isign == 1) {
		c2 = -0.5;
		four1(data,n>>1,1);
	} else {
		c2=0.5;
		theta = -theta;
	}
	wtemp=sin(0.5*theta);
	wpr = -2.0*wtemp*wtemp;
	wpi=sin(theta);
	wr=1.0+wpr;
	wi=wpi;
	np3=n+3;
	for (i=2;i<=(n>>2);i++) {
		i4=1+(i3=np3-(i2=1+(i1=i+i-1)));
		h1r=c1*(data[i1]+data[i3]);
		h1i=c1*(data[i2]-data[i4]);
		h2r = -c2*(data[i2]+data[i4]);
		h2i=c2*(data[i1]-data[i3]);
		data[i1]=h1r+wr*h2r-wi*h2i;
		data[i2]=h1i+wr*h2i+wi*h2r;
		data[i3]=h1r-wr*h2r+wi*h2i;
		data[i4] = -h1i+wr*h2i+wi*h2r;
		wr=(wtemp=wr)*wpr-wi*wpi+wr;
		wi=wi*wpr+wtemp*wpi+wi;
	}
	if (isign == 1) {
		data[1] = (h1r=data[1])+data[2];
		data[2] = h1r-data[2];
	} else {
		data[1]=c1*((h1r=data[1])+data[2]);
		data[2]=c1*(h1r-data[2]);
		four1(data,n>>1,-1);
	}
}
//-------------------------------------------------------------------------

void TAutoCorFrm::fourier(double *data,int n, int npts)
{
    int nmin, m = 2, mo2, k, j;
    float yn, y1, rn1, fac, cnst;
    double *y;

    nmin = n + (2 * npts);
    while (m < nmin) m *= 2;
    cnst = npts / m, cnst = cnst * cnst;
    y = new double[m+1];
    for (int i = 0; i < n; i++) y[i+1] = data[i];
    y1 = y[1];
    yn = y[n];
    rn1 = 1.0 / (n - 1);
    for (j = 1; j <= n; j++) y[j] += (-rn1 * (y1 * (n - j) + y1 * (j - 1)));
    for (j = n+1; j <= m; j++) y[j] = 0.0;
    mo2 = m >> 1;
    realft(y,mo2,1);
    y[1] /= mo2;
    fac = 1.0;
    for (j = 1; j < mo2; j++)
    {
        k = 2 * j + 1;
        if (fac)
        {
            if ( (fac = (1.0 - cnst * j * j) / mo2) < 0.0) fac = 0.0;
            y[k] = fac * y[k];
            y[k + 1] = fac * y[k + 1];
        }
        else y[k + 1] = y[k] = 0.0;
    }
    if ( (fac = (1.0 - 0.25 * npts * npts) / mo2) < 0.0) fac = 0.0;
    y[2] *= fac;
    realft(y,mo2,-1);
    for (j = 1; j <= n; j++)
        y[j] += rn1 * (y1 * (n - j) + yn * (j - 1));
    for (j = 0; j < n; j++) data[j] = y[j+1];
    delete[] y;
}

//----------------------------------------------------------------------

void __fastcall TAutoCorFrm::RowBtnClick(TObject *Sender)
{
    VarList->Clear();
    for (int i = 0; i < NoCases; i++)
        VarList->Items->Add(MainForm->Grid->Cells[0][i+1]);
    Label2->Caption = "Selected Case:";
    MaxLagEdit->Text = NoVariables;
}
//---------------------------------------------------------------------------

void __fastcall TAutoCorFrm::ColBtnClick(TObject *Sender)
{
    VarList->Clear();
    for (int i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
    Label2->Caption = "Selected Variable:";
    MaxLagEdit->Text = NoCases;
}
//---------------------------------------------------------------------------

void TAutoCorFrm::PolyFit(double *pts, double *avg, int NoPts)
{
    double **X;
    double *XY;
    double **XTX;
    double **Inverse;
    double **v;
    double *Beta;
    double *W;
    double t, Yhat;
    int i, j, k, order;
    AnsiString *ColLabels;
    AnsiString *RowLabels;
    char Title[81];

    order = atoi(PolyRegFitFrm->OrderEdit->Text.c_str());
    X = new double*[NoPts];
    for (i = 0; i < NoPts; i++) X[i] = new double[order+2];
    XTX = new double*[order+2];
    for (i = 0; i < order+2; i++) XTX[i] = new double[order+2];
    Inverse = new double*[order+2];
    for (i = 0; i < order+2; i++) Inverse[i] = new double[order+2];
    v = new double*[order+2];
    for (i = 0; i < order+2; i++) v[i] = new double[order+2];
    XY = new double[order+2];
    Beta = new double[order+2];
    W = new double[order+2];
/*
    ColLabels = new AnsiString[order+2];
    RowLabels = new AnsiString[NoPts];

    for (i = 0; i <= order; i++)
    {
        ColLabels[i] = "Order";
        ColLabels[i] = ColLabels[i] + i;
    }

    for (i = 0; i < NoPts; i++)
    {
        RowLabels[i] = "Point";
        RowLabels[i] = RowLabels[i] + (i+1);
    }
*/
    for (j = 0; j <= order; j++)
    {
        for (i = 0; i < NoPts; i++) X[i][j] = 0.0;
        for (i = 0; i <= order; i++) XTX[i][j] = 0.0;
        XY[j] = 0.0;
        Beta[j] = 0.0;
    }

    for (i = 0; i < NoPts; i++)
    {
        t = i + 1;
        for (j = 0; j <= order; j++)
        {
            X[i][j] = pow(t,j);
        }
    }
/*
    // print the X matrix
    FrmOutPut->RichOutPut->Clear();
    strcpy(Title,"X Matrix");
    ArrayPrint(X,NoPts,order+1,"order",RowLabels,ColLabels,Title);
    FrmOutPut->ShowModal();
*/
    // Get X transpose times X (offset by 1 for inverse routine)
    for (j = 0; j <= order; j++)
    {
        for (k = 0; k <= order; k++)
        {
            XTX[j+1][k+1] = 0.0;
            for (i = 0; i < NoPts; i++) XTX[j+1][k+1] += (X[i][j] * X[i][k]);
        }
    }
/*
    // print the X'X matrix
    for (i = 0; i <= order+1; i++)
    {
        ColLabels[i] = "Order";
        ColLabels[i] = ColLabels[i] + i;
    }
    FrmOutPut->RichOutPut->Clear();
    strcpy(Title,"X'X Matrix (Offset by 1)");
    ArrayPrint(XTX,order+2,order+2,"order",ColLabels,ColLabels,Title);
    FrmOutPut->ShowModal();
*/
    // Get X transpose times Y
    for (j = 0; j <= order; j++)
        for (i = 0; i < NoPts; i++)
            XY[j] += (X[i][j] * pts[i]);
/*
    // print the XY vector
    strcpy(Title,"XY Vector");
    FrmOutPut->RichOutPut->Clear();
    VPrint(XY,order+1,ColLabels,Title);
    FrmOutPut->ShowModal();
*/
    // Get inverse of XTX
    matinv(XTX, order+1, Inverse, v, W);
/*
    FrmOutPut->RichOutPut->Clear();
    strcpy(Title,"X'X Inverse Matrix (Offset by 1)");
    ArrayPrint(Inverse,order+2,order+2,"order",ColLabels,ColLabels,Title);
    FrmOutPut->ShowModal();
*/
    // Get beta values
    for (j = 0; j <= order; j++)
    {
        for (k = 0; k <= order; k++)
        {
            Beta[j] += (Inverse[j+1][k+1] * XY[k]);
        }
    }
/*
    // print beta values
    sprintf(Title,"Polynomial Regression Coefficients of order %d",order);
    FrmOutPut->RichOutPut->Clear();
    VPrint(Beta,order+1,ColLabels,Title);
    FrmOutPut->ShowModal();
*/
    // Get predicted values
    for (i = 0; i < NoPts; i++)
    {
        Yhat = 0.0;
        t = i + 1;
        for (j = 0; j <= order; j++) Yhat += (Beta[j] * pow(t,j));
        avg[i] = Yhat;
    }

    // clean up heap
/*
    delete[] RowLabels;
    delete[] ColLabels;
*/
    delete[] W;
    delete[] Beta;
    delete[] XY;
    for (i = 0; i < order+2; i++) delete[] v[i];
    delete[] v;
    for (i = 0; i < order+2; i++) delete[] Inverse[i];
    delete[] Inverse;
    for (i = 0; i < order+2; i++) delete[] XTX[i];
    delete[] XTX;
    for (i = 0; i < NoPts; i++) delete[] X[i];
    delete[] X;
}
//---------------------------------------------------------------------------

