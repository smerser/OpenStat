//---------------------------------------------------------------------------
#ifndef BankUpdateH
#define BankUpdateH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <stdio.h>
#include <Menus.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TBankUpdateFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TPanel *Panel2;
    TLabel *Label1;
    TEdit *BankEdit;
    TLabel *Label2;
    TEdit *NoInEdit;
    TLabel *Label3;
    TEdit *ItemNoEdit;
    TLabel *Label4;
    TEdit *ItemTypeEdit;
    TLabel *Label5;
    TEdit *MajCodeEdit;
    TLabel *Label6;
    TEdit *MinCodeEdit;
    TLabel *Label7;
    TEdit *ParmTypeEdit;
    TRichEdit *StemREdit;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TEdit *NoFoilsEdit;
    TLabel *Label11;
    TEdit *CorrectEdit;
    TRichEdit *FoilEdit;
    TLabel *Label12;
    TScrollBar *ItemScroll;
    TButton *ReviseBtn;
    TLabel *Label14;
    TEdit *NewNoEdit;
    TRadioGroup *RadioGroup1;
    TRadioGroup *RadioGroup2;
    TLabel *Label15;
    TEdit *BMPFileEdit;
    TButton *BMPNoneBtn;
    TButton *BMPBrowseBtn;
    TComboBox *MajorCombo;
    TLabel *Label16;
    TComboBox *MinorCombo;
    TLabel *Label17;
    TGroupBox *GroupBox1;
    TLabel *Label18;
    TLabel *Label19;
    TLabel *Label20;
    TLabel *Label21;
    TEdit *MeanEdit;
    TEdit *DiffEdit;
    TEdit *SlopeEdit;
    TEdit *ChanceEdit;
    TButton *ItemTextBtn;
    TButton *ExitBtn;
    TButton *CancelBtn;
    TOpenDialog *OpenDialog1;
    TSaveDialog *SaveDialog1;
    TButton *OpenOldBtn;
    TButton *OpenNewBtn;
    TLabel *Label13;
    TEdit *ItemFileEdit;
    TOpenPictureDialog *OpenPictureDialog1;
    TButton *SaveItemBtn;
    TButton *AddNewBtn;
    TPanel *Panel3;
    TLabel *Label22;
    TEdit *NoChoicesEdit;
    TLabel *Label23;
    TEdit *CorFoilEdit;
    TButton *DeleteBtn;
    TLabel *Label24;
    TScrollBar *UpDown1;
    TLabel *Label25;
    TLabel *Label26;
    TEdit *FoilNoEdit;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OpenNewBtnClick(TObject *Sender);
    void __fastcall OpenOldBtnClick(TObject *Sender);
    void __fastcall ReviseBtnClick(TObject *Sender);
    void __fastcall MajorComboKeyPress(TObject *Sender, char &Key);
    void __fastcall MajorComboClick(TObject *Sender);
    void __fastcall MinorComboKeyPress(TObject *Sender, char &Key);
    void __fastcall MinorComboClick(TObject *Sender);
    void __fastcall RadioGroup1Click(TObject *Sender);
    void __fastcall RadioGroup2Click(TObject *Sender);
    void __fastcall MeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall DiffEditKeyPress(TObject *Sender, char &Key);
    void __fastcall SlopeEditKeyPress(TObject *Sender, char &Key);
    void __fastcall ChanceEditKeyPress(TObject *Sender, char &Key);
    void __fastcall BMPBrowseBtnClick(TObject *Sender);
    void __fastcall SaveItemBtnClick(TObject *Sender);
    void __fastcall AddNewBtnClick(TObject *Sender);
    void __fastcall ItemTextBtnClick(TObject *Sender);
    
    void __fastcall ItemScrollChange(TObject *Sender);
    
    void __fastcall MajorComboDblClick(TObject *Sender);
    void __fastcall MinorComboDblClick(TObject *Sender);
    void __fastcall DeleteBtnClick(TObject *Sender);
    void __fastcall UpDown1Change(TObject *Sender);
private:	// User declarations
    struct header  {
        char bankname[81]; // name of file holding items
        char majorfile[81]; // name of file holding major combo codes
        char minorfile[81]; // name of file holding minor combo codes
        unsigned int NoItems;
        long int ItemStart[500];
    };
    header *hdrptr;
    header bankhdr;

    struct itemdesc  { // fixed elements of each item
        unsigned int ItemNo; // no. of the item in the item bank
        int itemtype;      // MC, TF, matching, word, phrase, essay
        int difftype;      // classical or 1, 2, 3 parameter IRT
        int majorcode;     // major code of the item (user supplied)
        int minorcode;     // minor code of the item (user supplied)
        double mean;       // classical theory item mean
        double difficulty; // 1 to 3 parameter IRT item difficulty parameter
        double slope;      // 2 or 3 IRT parameter of item slope
        double chance;     // 3 parameter IRT chance parameter
        int correctno;     // no. of the correct choice (if any)
        int stemlines;     // no. of text lines for the stem
        int nofoils;       // no. of choices for the item
        int foillines[10]; // no. of lines in each foil (up to 10)
        char BMPfile[81];  // file of bitmap image used in the item
        char Stem[30][81];     // up to 30 lines of memo lines for an item stem
        char Foil[10][10][81]; // up to 10 choices of 10 lines for each choice
    };
    itemdesc *descptr;     // pointer to one items fixed elements
    itemdesc fixeditem;    // one item's fixed elements
    FILE *hdrfileptr;      // handle to index file for the item bank
    FILE *bankfileptr;     // handle to item bank definition file
    FILE *majorptr;        // handle to associated major codes combo box
    FILE *minorptr;        // handle to associated minor codes combo box
    char filename[81];     // basic name of the item bank header
    char bankname[81];     // name of the header plus .ITM
    char majorfile[81];    // name of the header plus .MAJ
    char minorfile[81];    // name of the header plus .MIN
    bool fileopen;         // switch 0 or 1 for item bank files open or closed
    int MaxItemNo;         // maximum no. of items in the bank
    char Stem[30][81];     // up to 30 lines of memo lines for an item stem
    char Foil[10][10][81]; // up to 10 choices of 10 lines for each choice
    int stemlines;         // number of lines in an item stem
    int foillines[10];         // number of lines in an item choice
    int nochoices;         // number of choices for an item
    bool itemsaved;        // switch for whether or not last item was saved
    bool reviseitem;       // switch to indicate whether current item under revision
    int __fastcall opennewbank(TObject *Sender);
    int __fastcall openoldbank(TObject *Sender);
    void __fastcall getitem(int ino);

public:		// User declarations
    __fastcall TBankUpdateFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBankUpdateFrm *BankUpdateFrm;
//---------------------------------------------------------------------------
#endif
