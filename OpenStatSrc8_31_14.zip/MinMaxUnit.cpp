//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include "MemMgrUnit.h"

#include "MinMaxUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMinMaxForm *MinMaxForm;
extern int NoCases;
extern int NoVariables;
extern struct Options ops;

//---------------------------------------------------------------------------
__fastcall TMinMaxForm::TMinMaxForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     DepEdit->Text = "";
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     DepOutBtn->Visible = false;
     DepInBtn->Visible = true;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::DepOutBtnClick(TObject *Sender)
{
     if (DepEdit->Text == "") return;
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;    
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMinMaxForm::OKBtnClick(TObject *Sender)
{
     int i, j, k, k1, col, N, M, NDIM, MDIM, IFAULT;
     AnsiString cellstring, valstring, title;
     char outline[121];
     double **X;
     double *Y;
     double *Means;
     double *Variances;
     double *StdDevs;
     double *BETA;
     double Z;
     int *ColNoSelected;
     AnsiString *RowLabels;
     AnsiString *ColLabels;
     AnsiString *IndRowLabels;
     AnsiString *IndColLabels;
     AnsiString filename;

     MDIM = SelList->Items->Count + 1; // total no. of variables in the analysis
     M = MDIM - 1; // no. of independent variables;
     N = NoCases;
     NDIM = N;
     GetDblMatMem(X,N+1,MDIM+1);
     GetDblVecMem(Y,N+1);
     GetDblVecMem(BETA,M+1);
     Means = new double[MDIM];
     Variances = new double[MDIM];
     StdDevs = new double[MDIM];
     RowLabels = new AnsiString[MDIM];
     ColLabels = new AnsiString[MDIM];
     ColNoSelected = new int[MDIM];

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Min-Max Multiple Regression");

     // get independent item columns
     if (M < 1)
     {
         ShowMessage("ERROR! No independent variables selected.");
         goto CleanUp;
     }
     for (i = 0; i < M; i++)
     {
          cellstring = SelList->Items->Strings[i];
          for (j = 1; j <= NoVariables; j++)
          {
               if (cellstring == MainForm->Grid->Cells[j][0])
               {
                    ColNoSelected[i] = j;
                    RowLabels[i] = cellstring;
                    ColLabels[i] = cellstring;
               }
          }
     }

     // get dependendent variable column
     if (DepEdit->Text == "")
     {
          ShowMessage("ERROR! No Dependent variable selected.");
          goto CleanUp;
     }
     for (j = 1; j <= NoVariables; j++)
     {
          if (DepEdit->Text == MainForm->Grid->Cells[j][0])
          {
               ColNoSelected[M] = j;
               RowLabels[M] = DepEdit->Text;
               ColLabels[M] = DepEdit->Text;
          }
     }

     // Get values
     for (j = 0; j < MDIM; j++)
     {
         col = ColNoSelected[j];
         for (i = 0; i < N; i++)
         {
             X[i][j] = StrToFloat(MainForm->Grid->Cells[col][i+1]);
         }
     }
     for (i = 0; i < N; i++) Y[i+1] = X[i][M]; // dependent values

     // Get means, variances and standard deviations
     for (i = 0; i < MDIM; i++)
     {
         Means[i] = 0.0;
         Variances[i] = 0.0;
     }
     for (i = 0; i < MDIM; i++)
     {
         for (j = 0; j < N; j++)
         {
             Means[i] += X[j][i];
             Variances[i] += (X[j][i] * X[j][i]);
         }
         Variances[i] = Variances[i] - (Means[i] * Means[i] / double(N));
         Variances[i] /= (double)(N - 1);
         Means[i] /= (double) N;
         StdDevs[i] = sqrt(Variances[i]);
     }

     if (MeansChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Means,MDIM,ColLabels,"Means");
     }
     if (VariancesChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Variances,MDIM,ColLabels,"Variances");
     }
     if (StdDevsChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(StdDevs,MDIM,ColLabels,"Standard Deviations");
     }
     FrmOutPut->ShowModal();

     // Get Betas - first shift X values to index from 1
     for (j = MDIM-1; j >= 0; j--)
     {
         for (i = 0; i < N; i++)
         {
             X[i+1][j+1] = X[i][j];
         }
     }

     LFNORM(NDIM, MDIM, N, M, X, Y, BETA, Z, IFAULT);
     // shift betas back one
     for (i = 0; i < M; i++) BETA[i] = BETA[i+1];
     VPrint(BETA,M,ColLabels,"Betas");

     FrmOutPut->ShowModal();

CleanUp:
     delete[] ColNoSelected;
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
     delete[] BETA;
     delete[] Y;
     ClearDblMatMem(X,NDIM+1);
}
//---------------------------------------------------------------------------
