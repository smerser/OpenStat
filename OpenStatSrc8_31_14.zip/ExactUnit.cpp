//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include "NonPar.h"
#include "ExactUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TExactForm *ExactForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
__fastcall TExactForm::TExactForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Clear();
     RowEdit->Text = "";
     ColEdit->Text = "";
     DepEdit->Text = "";
     DepEdit->Visible = false;
     RowIn->Visible = true;
     RowOut->Visible = false;
     ColIn->Visible = true;
     ColOut->Visible = false;
     DepIn->Visible = false;
     DepOut->Visible = false;
     NCasesEdit->Text = "";
     NCasesEdit->Visible = false;
     Label4->Visible = false;
     Label5->Visible = false;
     InputGroup->ItemIndex = 0;
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     Panel1->Visible = true;
     Panel2->Visible = false;
     Row1Edit->Text = "1";
     Row2Edit->Text = "2";
     Col1Edit->Text = "1";
     Col2Edit->Text = "2";
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::InputGroupClick(TObject *Sender)
{
     int index;

     index = InputGroup->ItemIndex;
     if (index == 3)
     {
        Panel2->Visible = true;
        Panel1->Visible = false;
     }
     else
     {
         Panel1->Visible = true;
         Panel2->Visible = false;
     }

     if (index == 2)  // only proportions available - get N size
     {
          Label4->Visible = true;
          NCasesEdit->Visible = true;
          NCasesEdit->SetFocus();
          DepIn->Visible = true;
          DepOut->Visible = false;
          DepEdit->Visible = true;
          Label5->Visible = true;
     }
     if (index == 1)  // frequencies available for each row and column combo
     {
         Label4->Visible = true;
         NCasesEdit->Visible = false;
         DepIn->Visible = true;
         DepOut->Visible = false;
         DepEdit->Visible = true;
         Label5->Visible = false;
     }
     if (index == 0)  // have to count cases in each row and col. combination
     {
          NCasesEdit->Visible = false;
          DepIn->Visible = false;
          DepOut->Visible = false;
          DepEdit->Visible = false;
          Label4->Visible = false;
          Label5->Visible = false;
     }
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::RowInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     RowEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RowIn->Visible = false;
     RowOut->Visible = true;     
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::RowOutClick(TObject *Sender)
{
     VarList->Items->Add(RowEdit->Text);
     RowEdit->Text = "";
     RowIn->Visible = true;
     RowOut->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::ColInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     ColEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ColIn->Visible = false;
     ColOut->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::ColOutClick(TObject *Sender)
{
     VarList->Items->Add(ColEdit->Text);
     ColEdit->Text = "";
     ColIn->Visible = true;
     ColOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::DepInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepIn->Visible = false;
     DepOut->Visible = true;     
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::DepOutClick(TObject *Sender)
{
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TExactForm::ComputeBtnClick(TObject *Sender)
{
   int i, j, row, col, caserow, casecol, A, b, C, d, Largest;
   int N, APlusB, APlusC, BPlusD, CPlusD, NoSelected, dep;
   int RowLev1, RowLev2, ColLev1, ColLev2;
   double FirstP, p, SumProb, Tocher, Alpha, X, A1, B1, C1, D1;
   int obs[4][4];
   double expected[3][3];
   double observed[4][4];
   int *ColNoSelected;
   bool done;
   AnsiString cellstring, response;
   char outline[101];
   int NoErrRecords = 0;
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;

    Randomize(); // initialize random number generator
    row = 0;
    col = 0;
    dep = 0;

    // get column no.s of row and col variables
    if (InputGroup->ItemIndex != 3)
    {
         for (i = 1; i <= NoVariables; i++)
         {
              cellstring = RowEdit->Text;
              if (cellstring == MainForm->Grid->Cells[i][0]) row = i;
              cellstring = ColEdit->Text;
              if (cellstring == MainForm->Grid->Cells[i][0]) col = i;
              if ((InputGroup->ItemIndex == 1) || (InputGroup->ItemIndex == 2))
              {
                   cellstring = DepEdit->Text;
                   if (cellstring == MainForm->Grid->Cells[i][0]) dep = i;
              }
         }
         if ((row == 0) || (col == 0))
         {
                ShowMessage("Row or column variable not found!");
                return;
         }
         //result = VarTypeChk(row,1);
         //if (result == 1) return;
         //result = VarTypeChk(col,1);
         //if (result == 1) return;
         if ((InputGroup->ItemIndex == 1) || (InputGroup->ItemIndex == 2))
         {
            if (dep == 0)
            {
                ShowMessage("No dependent variable identified.");
                return;
            }
         }
         //if (InputGroup->ItemIndex == 1) // frequencies
         //{
         //       result = VarTypeChk(dep,1);
         //       if (result == 1) return;
         //}
         //if (InputGroup->ItemIndex == 2) // proportions
         //{
         //       result = VarTypeChk(dep,0);
         //       if (result == 1) return;
         //}
    }
    GetIntVecMem(ColNoSelected,3);
    ColNoSelected[0] = row;
    ColNoSelected[1] = col;
    if ((InputGroup->ItemIndex == 1) || (InputGroup->ItemIndex == 2))
    {
         ColNoSelected[2] = dep;
         NoSelected = 3;
    }
    else NoSelected = 2;

    // get coding values for rows and columns
    RowLev1 = StrToInt(Row1Edit->Text);
    RowLev2 = StrToInt(Row2Edit->Text);
    ColLev1 = StrToInt(Col1Edit->Text);
    ColLev2 = StrToInt(Col2Edit->Text);

    //initialize observed matrix
    for (i = 1; i <= 3; i++)
        for (j = 1; j <= 3; j++) obs[i][j] = 0;

    if (InputGroup->ItemIndex == 3)  // get freq. from form
    {
         obs[1][1] = StrToInt(RC11Edit->Text);
         obs[1][2] = StrToInt(RC12Edit->Text);
         obs[2][1] = StrToInt(RC21Edit->Text);
         obs[2][2] = StrToInt(RC22Edit->Text);
    }

    if (InputGroup->ItemIndex == 0)  // count no. in row/col combinations
    {
         for (j = 1; j <= NoCases; j++)
         {
              if (! ValidRecord(j,ColNoSelected,NoSelected))  continue;
              caserow = floor(StrToFloat(Trim(MainForm->Grid->Cells[row][j])));
              //result = GetValue(j,row,intvalue,dblvalue,strvalue);
              //if (result == 1) caserow = 0;
              //else caserow = intvalue;
              if (caserow == RowLev1) caserow = 1;
              else if (caserow == RowLev2) caserow = 2;
              casecol = floor(StrToFloat(Trim(MainForm->Grid->Cells[col][j])));
              //result = GetValue(j,col,intvalue,dblvalue,strvalue);
              //if (result == 1) casecol = 0;
              //else casecol = intvalue;
              if (casecol == ColLev1) casecol = 1;
              else if (casecol == ColLev2) casecol = 2;
              if ((caserow > 2) || (caserow < 1))
              {
//                   ShowMessage("ERROR! Incorrect row value found. Case ignored.");
                   NoErrRecords++;
                   continue;
              }
              if ((casecol > 2) || (casecol < 1))
              {
//                   ShowMessage("ERROR! Incorrect column value found. Case ignored.");
                   NoErrRecords++;
                   continue;
              }
              obs[caserow][casecol] = obs[caserow][casecol] + 1;
         }
    }

    if ((InputGroup->ItemIndex == 1) || (InputGroup->ItemIndex == 2))  // Grid has frequencies for row/col
    {
         for (j = 1; j <= NoCases; j++)
         {
              if (! ValidRecord(j,ColNoSelected,NoSelected))  continue;
              caserow = floor(StrToFloat(Trim(MainForm->Grid->Cells[row][j])));
              if (caserow == RowLev1) caserow = 1;
              else if (caserow == RowLev2) caserow = 2;
              casecol = floor(StrToFloat(Trim(MainForm->Grid->Cells[col][j])));
              if (casecol == ColLev1) casecol = 1;
              else if (casecol == ColLev2) casecol = 2;
              if ((caserow > 2) || (caserow < 1))
              {
//                   ShowMessage("ERROR! Incorrect row value found. Case ignored.");
                   NoErrRecords++;
                   continue;
              }
              if ((casecol > 2) || (casecol < 1))
              {
//                   ShowMessage("ERROR! Incorrect column value found. Case ignored.");
                   NoErrRecords++;
                   continue;
              }
              if (InputGroup->ItemIndex == 1) // frequencies
              {
                  obs[caserow][casecol] = floor(StrToFloat(Trim(MainForm->Grid->Cells[dep][j])));
                  //result = GetValue(j,dep,intvalue,dblvalue,strvalue);
                  //if (result == 1) obs[caserow][casecol] = 0;
                  //else obs[caserow][casecol] = intvalue;
              }
              if (InputGroup->ItemIndex == 2)
              {
                 obs[caserow][casecol] = floor(StrToFloat(Trim(MainForm->Grid->Cells[dep][j])));
                 //result = GetValue(j,dep,intvalue,dblvalue,strvalue);
                 //if (result == 1) obs[caserow][casecol] = 0;
                 //else
                 //{
                 //       double X = dblvalue * StrToInt(NCasesEdit->Text);
                 //       obs[caserow][casecol] = ceil(X);
                 //}
                 obs[caserow][casecol] = obs[caserow][casecol] * StrToInt(NCasesEdit->Text);
              }
         }
    }

    if (NoErrRecords > 0)
    {
       sprintf(outline,"%d records did not have specified row or column values.",NoErrRecords);
       ShowMessage(outline);
    }

    //Find LARGEST value
    A = obs[1][1];
    b = obs[1][2];
    C = obs[2][1];
    d = obs[2][2];
    A1 = A;
    B1 = b;
    C1 = C;
    D1 = d;
    APlusB = A + b;
    CPlusD = C + d;
    BPlusD = b + d;
    APlusC = A + C;
    N = A + b + C + d;
    obs[1][3] = APlusB;
    obs[2][3] = CPlusD;
    obs[3][1] = APlusC;
    obs[3][2] = BPlusD;
    obs[3][3] = N;
    observed[1][1] = obs[1][1];
    observed[1][2] = obs[1][2];
    observed[1][3] = obs[1][3];
    observed[2][1] = obs[2][1];
    observed[2][2] = obs[2][2];
    observed[2][3] = obs[2][3];
    observed[3][1] = obs[3][1];
    observed[3][2] = obs[3][2];
    observed[3][3] = obs[3][3];
    expected[1][1] = (double) (obs[1][3] * obs[3][1] ) / (double) N;
    expected[1][2] = (double) (obs[1][3] * obs[3][2] ) / (double) N;
    expected[2][1] = (double) (obs[2][3] * obs[3][1] ) / (double) N;
    expected[2][2] = (double) (obs[2][3] * obs[3][2] ) / (double) N;
    Largest = 1;
    if (b > A)  Largest = 2;
    if ((b > A) && (b > C) && (b > d))  Largest = 2;
    if ((C > A) && (C > b) && (C > d))  Largest = 3;
    if ((d > A) && (d > b) && (d > C))  Largest = 4;

    //Ready output
    FrmOutPut->RichOutPut->Clear();
    SumProb = 0.0;
    FrmOutPut->RichOutPut->Lines->Add("Fisher Exact Probability Test");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Accumulating Values of the Hypergeometric Distribution");
    FrmOutPut->RichOutPut->Lines->Add("");

    //Get first probability
    FirstP = combos(A, APlusC) * combos(b, BPlusD) / combos(APlusB, N);
    SumProb = SumProb + FirstP;
    FisherTable(A, b, C, d, FirstP, SumProb);

    //Get more extreme probabilities
    done = false;
    while (! done)
    {
        switch (Largest)
        {
           case 1:
           { // top row, first col
                if (A == APlusB) done = true;
                else {
                     A = A + 1;
                     b = b - 1;
                     C = C - 1;
                     d = d + 1;
                     if ( (A < 0) || (b < 0) || (C < 0) || (d < 0)) done = true;
                }
                break;
           }
           case 2:
           { // top row, second column
                if (b == APlusB) done = true;
                else {
                     A = A - 1;
                     b = b + 1;
                     C = C + 1;
                     d = d - 1;
                     if ( (A < 0) || (b < 0) || (C < 0) || (d < 0)) done = true;
                }
                break;
           }
           case 3:
           { // second row, first column
                if (C == CPlusD) done = true;
                else {
                     A = A - 1;
                     b = b + 1;
                     C = C + 1;
                     d = d - 1;
                     if ( (A < 0) || (b < 0) || (C < 0) || (d < 0)) done = true;
                }
                break;
           }
           case 4:
           { // second row, second column
                if (d == CPlusD) done = true;
                else {
                     A = A + 1;
                     b = b - 1;
                     C = C - 1;
                     d = d + 1;
                     if ( (A < 0) || (b < 0) || (C < 0) || (d < 0)) done = true;
                }
                break;
           }
        } // end switch
        if (! done)
        {
            p = combos(A, APlusC) * combos(b, BPlusD) / combos(APlusB, N);
            SumProb = SumProb + p;
            FisherTable(A, b, C, d, p, SumProb);
        }
    }

    //Tocher"s modification
    response =
        InputBox( "ALPHA","Enter your Alpha (Type I Error rate) : ", "0.05");
    Alpha = StrToFloat(response);
    if ((SumProb - FirstP) > Alpha)  //Extreme values > alpha - accept null hypothesis
        FrmOutPut->RichOutPut->Lines->Add("Null hypothesis accepted.");
    else
    {//Extreme values significant - is total probability significant?
        if (SumProb >= Alpha) //No, so apply Tocher"s rule
        {
            Tocher = ( Alpha - (SumProb - FirstP)) / FirstP;
            X = random(1000) / 1000.0; //Select a random value between 0 and num - 1
            sprintf(outline,"Tocher ratio computed: %5.3f",Tocher);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            if (X < Tocher)  //Call it significant
            {
                sprintf(outline,"A random value of %5.3f selected was less than the Tocher value.",X);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                FrmOutPut->RichOutPut->Lines->Add("Conclusion: Reject the null Hypothesis");
            }
            else
            { //Call it non-significant
                sprintf(outline,"A random value of %5.3f selected was greater than the Tocher value.",X);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                FrmOutPut->RichOutPut->Lines->Add("Conclusion: Accept the null Hypothesis");
            }
        }
        else
        { //Total probability < alpha - reject null
            FrmOutPut->RichOutPut->Lines->Add("Probability less than alpha - reject null hypothesis.");
        } // end if-else
    } // end if-else

    // get log of odds ratio
   FrmOutPut->RichOutPut->Lines->Add("");
    double chisquare = 0.0;
    for (int i = 1; i < 3; i++)
        for (int j = 1; j < 3; j++)
            chisquare += (observed[i][j] - expected[i][j]) *
            (observed[i][j] - expected[i][j]) / expected[i][j];
    double chiprob = 1.0 - chisquaredprob(chisquare,1);
    sprintf(outline,"Chi-squared = %8.3f with 1 d.f. and prob. > chi-square = %6.4f",
            chisquare,chiprob);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();
    double logodds = log(A1) - log(B1) - log(C1) + log(D1);
    sprintf(outline,"Log Odds = %8.3f",logodds);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double RelativeRisk = (A1 * (C1 + D1)) / (C1 * (A1 + B1));
    sprintf(outline,"Relative Risk = %8.3f",RelativeRisk);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double liklihood = 0.0;
    for (int i = 1; i < 3; i++)
        for (int j = 1; j < 3; j++)
            liklihood += observed[i][j] * (log(expected[i][j] / observed[i][j]));
    liklihood = -2.0 * liklihood;
    double probliklihood = 1.0 - chisquaredprob(liklihood,1);
    sprintf(outline,"Liklihood Ratio = %8.3f with prob. > value = %6.4f",
            liklihood,probliklihood);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double phi = sqrt(chisquare / (double) N);
    sprintf(outline,"phi correlation = %6.4f",phi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double MantelHaenszel = (double) (N-1) * (phi * phi);
    double MHprob = 1.0 - chisquaredprob(MantelHaenszel,1);
    sprintf(outline,"Mantel-Haenszel Test of Linear Association = %8.3f with probability > value = %6.4f",
            MantelHaenszel, MHprob);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double CoefCont = sqrt(chisquare / (chisquare + (double) N));
    sprintf(outline,"The coefficient of contingency = %8.3f",CoefCont);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    double CramerV = sqrt(chisquare / (double) N);
    sprintf(outline,"Cramer's V = %8.3f",CramerV);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();
    delete[] ColNoSelected;
}
//----------------------------------------------------------------------------

void __fastcall TExactForm::FisherTable(int A, int b, int C, int d,
                                        double p, double SumP)
{
    char outline[101];

    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Contingency Table for Fisher Exact Test");
    FrmOutPut->RichOutPut->Lines->Add("                 Column");
    FrmOutPut->RichOutPut->Lines->Add("Row             1          2");
    sprintf(outline," 1     %10d %10d",A, b);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline," 2     %10d %10d",C, d);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Probability = %6.4f",p);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Cumulative Probability = %6.4f",SumP);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
}
//-------------------------------------------------------------------




