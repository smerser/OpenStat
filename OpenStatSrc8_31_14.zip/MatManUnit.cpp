//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MatManUnit.h"
#include "stdio.h"
#include "OutPut.h"
#include "MemMgrUnit.h"
#include "MatrixUnit.h"
#include "MainUnit.h"
#include "ScriptEditUnit.h"
#include "RootMethodUnit.h"
#include "functions.h"

extern struct Options ops;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMatManForm *MatManForm;
//---------------------------------------------------------------------------
__fastcall TMatManForm::TMatManForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ResetGrids(TObject *Sender)
{
       int i, j;

       Rows1 = 4;
       Cols1 = 4;
       Grid1->RowCount = 5;
       Grid1->ColCount = 5;
       for (i = 0; i <= Rows1; i++)
           for (j = 0; j <= Cols1; j++)
               Grid1->Cells[j][i] = "";
       Grid1->Cells[0][0] = "Row/Col";
       for (i = 0; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
       for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col " + IntToStr(i);

       Rows2 = 4;
       Cols2 = 4;
       Grid2->RowCount = 5;
       Grid2->ColCount = 5;
       for (i = 0; i <= Rows2; i++)
           for (j = 0; j <= Cols2; j++)
               Grid2->Cells[j][i] = "";
       Grid2->Cells[0][0] = "Row/Col";
       for (i = 0; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
       for (i = 0; i <= Cols2; i++) Grid2->Cells[i][0] = "Col " + IntToStr(i);

       Rows3 = 4;
       Cols3 = 4;
       Grid3->RowCount = 5;
       Grid3->ColCount = 5;
       for (i = 0; i <= Rows3; i++)
           for (j = 0; j <= Cols3; j++)
               Grid3->Cells[j][i] = "";
       Grid3->Cells[0][0] = "Row/Col";
       for (i = 0; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
       for (i = 0; i <= Cols3; i++) Grid3->Cells[i][0] = "Col " + IntToStr(i);

       Rows4 = 4;
       Cols4 = 4;
       Grid4->RowCount = 5;
       Grid4->ColCount = 5;
       for (i = 0; i <= Rows4; i++)
           for (j = 0; j <= Cols4; j++)
               Grid4->Cells[j][i] = "";
       Grid4->Cells[0][0] = "Row/Col";
       for (i = 0; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
       for (i = 0; i <= Cols4; i++) Grid4->Cells[i][0] = "Col " + IntToStr(i);

     ScriptList->Clear();
     CurrentObjName = "";
     CurrentGrid = 1;
     CurrentObjType = 1;
     OperationEdit->Text = "";
     Operand1Edit->Text = "";
     Operand2Edit->Text = "";
     Operand3Edit->Text = "";
     Obj1NameEdit->Text = "";
     Obj2NameEdit->Text = "";
     Obj3NameEdit->Text = "";
     Obj4NameEdit->Text = "";
     MatCount = 0;
     ColVecCount = 0;
     RowVecCount = 0;
     ScaCount = 0;
     Saved = true;
     ScriptOp = false;
     LastScript = 0;
     LastGridNo = 1;
     GridNoEdit->Text = "1";
     MatrixCombo->Clear();
     MatrixCombo->Text = "Matrices";
     ColCombo->Clear();
     ColCombo->Text = "Col.Vectors";
     RowCombo->Clear();
     RowCombo->Text = "RowVectors";
     ScalerCombo->Clear();
     ScalerCombo->Text = "Scalers";
     FrmOutPut->RichOutPut->Clear();
};
//-------------------------------------------------------------------

void __fastcall TMatManForm::FormShow(TObject *Sender)
{
     int count, index;
     AnsiString filename, matext, cvecext, rvecext, scaext, extstr;
     FILE *scriptopts;
     int checked;

     ResetGrids(this);
     Clear1Click(this);
     filename = GetCurrentDir();
     FrmScriptEditor->DirectoryListBox1->Directory = filename;
     matext = ".MTX";
     cvecext = ".CVE";
     rvecext = ".RVE";
     scaext = ".SCA";
     count = FrmScriptEditor->FileListBox1->Items->Count;
     for (index = 0; index < count; index++)
     {
          filename = FrmScriptEditor->FileListBox1->Items->Strings[index];
          filename = ExtractFileName(filename);
          extstr = copy(filename,filename.Length()-3,4);
          if (extstr == matext) MatrixCombo->Items->Add(filename);
          if (extstr == cvecext) ColCombo->Items->Add(filename);
          if (extstr == rvecext) RowCombo->Items->Add(filename);
          if (extstr == scaext) ScalerCombo->Items->Add(filename);
     }
}
//---------------------------------------------------------------------------


void __fastcall TMatManForm::mnuSaveClick(TObject *Sender)
{
     FILE *SaveFile;
     int i, j;
     AnsiString OpStr;
     AnsiString BackUpName;
     char astring[121];
     char tabchar = '\t';
     char newline = '\n';

     switch (CurrentGrid)
     {
        case 1 : Grid1Click(this); break;
        case 2 : Grid2Click(this); break;
        case 3 : Grid3Click(this); break;
        case 4 : Grid4Click(this); break;
     }

     SaveDialog1->Filter = "Matrix (*.mtx)|*.MTX|Col.Vector (*.CVE)|*.CVE|RowVector (*.RVE)|*.RVE|Scaler (*.scl)|*.SCA|All (*.*)|*.*";
     SaveDialog1->FilterIndex = CurrentObjType;
     switch (CurrentObjType)
     {
         case 1 : SaveDialog1->DefaultExt = ".MTX"; break;
         case 2 : SaveDialog1->DefaultExt = ".CVE"; break;
         case 3 : SaveDialog1->DefaultExt = ".RVE"; break;
         case 4 : SaveDialog1->DefaultExt = ".SCA"; break;
     }
     BackUpName = ExtractFileName(CurrentObjName);
     SaveDialog1->FileName = BackUpName;

     if (SaveDialog1->Execute())
     {
          Operand1Edit->Text = SaveDialog1->FileName;
          CurrentObjName = ExtractFileName(SaveDialog1->FileName);
          OperationEdit->Text = "FileSave";
          Operand2Edit->Text = "";
          Operand3Edit->Text = "";
          SaveFile = fopen(SaveDialog1->FileName.c_str(),"wt");
          fprintf(SaveFile,"%d%c",CurrentObjType,newline);
          strcpy(astring,CurrentObjName.c_str());
          fprintf(SaveFile,"%s%c",astring,newline);
          OpStr = IntToStr(CurrentGrid) + "-";
          OpStr = OpStr + "FileSave:" + IntToStr(CurrentGrid) + "-" + CurrentObjName;

          switch (CurrentGrid)
          {
             case 1 :
                Obj1NameEdit->Text = CurrentObjName;
                fprintf(SaveFile,"%d%c",Rows1,tabchar);
                fprintf(SaveFile,"%d%c",Cols1,newline);
                for (i = 1; i <= Rows1; i++)
                {
                  for (j = 1; j <= Cols1; j++)
                  {
                      strcpy(astring,Grid1->Cells[j][i].c_str());
                      fprintf(SaveFile,"%s%c",astring,tabchar);
                  }
                  fprintf(SaveFile,"%c",newline);
                }
                break;
             case 2 :
                Obj2NameEdit->Text = CurrentObjName;
                fprintf(SaveFile,"%d%c",Rows2,tabchar);
                fprintf(SaveFile,"%d%c",Cols2,newline);
                for (i = 1; i <= Rows2; i++)
                {
                  for (j = 1; j <= Cols2; j++)
                  {
                      strcpy(astring,Grid2->Cells[j][i].c_str());
                      fprintf(SaveFile,"%s%c",astring,tabchar);
                  }
                  fprintf(SaveFile,"%c",newline);
                }
                break;
             case 3 :
                Obj3NameEdit->Text = CurrentObjName;
                fprintf(SaveFile,"%d%c",Rows3,tabchar);
                fprintf(SaveFile,"%d%c",Cols3,newline);
                for (i = 1; i <= Rows3; i++)
                {
                  for (j = 1; j <= Cols3; j++)
                  {
                      strcpy(astring,Grid3->Cells[j][i].c_str());
                      fprintf(SaveFile,"%s%c",astring,tabchar);
                  }
                  fprintf(SaveFile,"%c",newline);
                }
                break;
             case 4 :
                Obj4NameEdit->Text = CurrentObjName;
                fprintf(SaveFile,"%d%c",Rows4,tabchar);
                fprintf(SaveFile,"%d%c",Cols4,newline);
                for (i = 1; i <= Rows4; i++)
                {
                  for (j = 1; j <= Cols4; j++)
                  {
                      strcpy(astring,Grid4->Cells[j][i].c_str());
                      fprintf(SaveFile,"%s%c",astring,tabchar);
                  }
                  fprintf(SaveFile,"%c",newline);
                }
                break;
          } // end switch
          fclose(SaveFile);
          Saved = true;
          if (NoSaveChk->Checked == false) ScriptList->Items->Add(OpStr);
     } // if savedialog1 executed
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::GetFile(TObject *Sender)
{
     OpenDialog1->Filter = "Matrix (*.mtx)|*.MTX|Col.Vector (*.CVE)|*.CVE|RowVector (*.RVE)|*.RVE|Scaler (*.scl)|*.SCA|All (*.*)|*.*";
     OpenDialog1->FilterIndex = CurrentObjType;
     switch (CurrentObjType)
     {
          case 1 : OpenDialog1->DefaultExt = ".MTX"; break;
          case 2 : OpenDialog1->DefaultExt = ".CVE"; break;
          case 3 : OpenDialog1->DefaultExt = ".RVE"; break;
          case 4 : OpenDialog1->DefaultExt = ".SCA"; break;
          default: OpenDialog1->DefaultExt = ".MTX";
     }
     GridNoEdit->Text = IntToStr(CurrentGrid);
     GetGridData(CurrentGrid);
}
//-----------------------------------------------------------------------------

void __fastcall TMatManForm::KeyMatClick(TObject *Sender)
{
     AnsiString instr;
     int i, j;

     instr = InputBox("GRID?","Which grid no. (1-4):","1");
     CurrentGrid = StrToInt(instr);
     if ((CurrentGrid < 1) || (CurrentGrid > 4)) CurrentGrid = 1;
     GridNoEdit->Text = IntToStr(CurrentGrid);
     instr = InputBox("NAME","Object name:","AMatrix");
     CurrentObjName = instr;
     instr = InputBox("ROWS","No. of Rows = ","3");
     Rows = StrToInt(instr);
     instr = InputBox("COLS","No. of Columns = ","3");
     Cols = StrToInt(instr);
     switch (CurrentGrid)
     {
         case 1 :
              Rows1 = Rows;
              Cols1 = Cols;
              Obj1NameEdit->Text = CurrentObjName;
              Grid1->RowCount = Rows1 + 1;
              Grid1->ColCount = Cols1 + 1;
              for (i = 0; i <= Rows1; i++)
                  for (j = 0; j <= Cols1; j++)
                      Grid1->Cells[j][i] = "";
              for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row" + IntToStr(i);
              break;
         case 2 :
              Rows2 = Rows;
              Cols2 = Cols;
              Obj2NameEdit->Text = CurrentObjName;
              Grid2->RowCount = Rows2 + 1;
              Grid2->ColCount = Cols2 + 1;
              for (i = 0; i <= Rows2; i++)
                  for (j = 0; j <= Cols2; j++)
                      Grid2->Cells[j][i] = "";
              for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row" + IntToStr(i);
              break;
         case 3 :
              Rows3 = Rows;
              Cols3 = Cols;
              Obj3NameEdit->Text = CurrentObjName;
              Grid3->RowCount = Rows3 + 1;
              Grid3->ColCount = Cols3 + 1;
              for (i = 0; i <= Rows3; i++)
                  for (j = 0; j <= Cols3; j++)
                      Grid3->Cells[j][i] = "";
              for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row" + IntToStr(i);
              break;
         case 4 :
              Rows4 = Rows;
              Cols4 = Cols;
              Obj4NameEdit->Text = CurrentObjName;
              Grid4->RowCount = Rows4 + 1;
              Grid4->ColCount = Cols4 + 1;
              for (i = 0; i <= Rows4; i++)
                  for (j = 0; j <= Cols4; j++)
                      Grid4->Cells[j][i] = "";
              for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row" + IntToStr(i);
              break;
     } // end switch
     CurrentObjType = 1;
     MatCount = MatCount + 1;
     OperationEdit->Text = "KeyMatInput";
     Operand1Edit->Text = CurrentObjName;
     Operand2Edit->Text = "";
     Operand3Edit->Text = "";
     switch (CurrentGrid)
     {
          case 1 : Grid1->SetFocus(); break;
          case 2 : Grid2->SetFocus(); break;
          case 3 : Grid3->SetFocus(); break;
          case 4 : Grid4->SetFocus(); break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::KeyVectClick(TObject *Sender)
{
     AnsiString instr;
     int i, j;

     instr = InputBox("GRID?","Which grid no. (1-4):","1");
     CurrentGrid = StrToInt(instr);
     if ((CurrentGrid < 1) || (CurrentGrid > 4)) CurrentGrid = 1;
     GridNoEdit->Text = IntToStr(CurrentGrid);
     instr = InputBox("TYPE","Row or Column Vector","Column");
     if (instr == "Column") CurrentObjType = 2;
     else CurrentObjType = 3;
     if (CurrentObjType == 3) // row vector
     {
          instr = InputBox("NAME","Object name:","ARowVector");
          CurrentObjName = instr;
          Rows = 1;
          instr = InputBox("RowVector","No. of elements = ","3");
          Cols = StrToInt(instr);
          RowVecCount = RowVecCount + 1;
          RowCombo->Items->Add(CurrentObjName);
          switch (CurrentGrid)
          {
             case 1 :
                   Rows1 = Rows;
                   Cols1 = Cols;
                   Grid1->ColCount = Cols1 + 1;
                   Grid1->RowCount = 2;
                   Obj1NameEdit->Text = CurrentObjName;
                   for (i = 0; i <= Rows1; i++)
                       for (j = 0; j <= Cols1; j++)
                           Grid1->Cells[j][i] = "";
                   for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row" + IntToStr(i);
                   break;
             case 2 :
                   Rows2 = Rows;
                   Cols2 = Cols;
                   Grid2->ColCount = Cols2 + 1;
                   Grid2->RowCount = 2;
                   Obj2NameEdit->Text = CurrentObjName;
                   for (i = 0; i <= Rows2; i++)
                       for (j = 0; j <= Cols2; j++)
                           Grid2->Cells[j][i] = "";
                   for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row" + IntToStr(i);
                   break;
             case 3 :
                   Rows3 = Rows;
                   Cols3 = Cols;
                   Grid3->ColCount = Cols3 + 1;
                   Grid3->RowCount = 2;
                   Obj3NameEdit->Text = CurrentObjName;
                   for (i = 0; i <= Rows3; i++)
                       for (j = 0; j <= Cols3; j++)
                           Grid3->Cells[j][i] = "";
                   for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row" + IntToStr(i);
                   break;
             case 4 :
                   Rows4= Rows;
                   Cols4= Cols;
                   Grid4->ColCount = Cols4+ 1;
                   Grid4->RowCount = 2;
                   Obj4NameEdit->Text = CurrentObjName;
                   for (i = 0; i <= Rows4; i++)
                       for (j = 0; j <= Cols4; j++)
                           Grid4->Cells[j][i] = "";
                   for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row" + IntToStr(i);
                   break;
          } // end switch
          OperationEdit->Text = "RowVecInput";
          Operand1Edit->Text = CurrentObjName;
          Operand2Edit->Text = "";
          Operand3Edit->Text = "";
     }
     else // column vector input
     {
          instr = InputBox("NAME","Object name:","AColVector");
          CurrentObjName = instr;
          Cols = 1;
          instr = InputBox("ColumnVector","No. of elements = ","3");
          Rows = StrToInt(instr);
          switch (CurrentGrid)
          {
              case 1 :
                   Obj1NameEdit->Text = CurrentObjName;
                   Cols1 = Cols;
                   Rows1 = Rows;
                   Grid1->ColCount = 2;
                   Grid1->RowCount = Rows1 + 1;
                   for (i = 0; i <= Rows1; i++)
                       for (j = 0; j <= Cols1; j++)
                           Grid1->Cells[j][i] = "";
                   for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row" + IntToStr(i);
                   break;
              case 2 :
                   Obj2NameEdit->Text = CurrentObjName;
                   Cols2 = Cols;
                   Rows2 = Rows;
                   Grid2->ColCount = 2;
                   Grid2->RowCount = Rows2 + 1;
                   for (i = 0; i <= Rows2; i++)
                       for (j = 0; j <= Cols2; j++)
                           Grid2->Cells[j][i] = "";
                   for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row" + IntToStr(i);
                   break;
              case 3 :
                   Obj3NameEdit->Text = CurrentObjName;
                   Cols3 = Cols;
                   Rows3 = Rows;
                   Grid3->ColCount = 2;
                   Grid3->RowCount = Rows3 + 1;
                   for (i = 0; i <= Rows3; i++)
                       for (j = 0; j <= Cols3; j++)
                           Grid3->Cells[j][i] = "";
                   for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row" + IntToStr(i);
                   break;
              case 4 :
                   Obj4NameEdit->Text = CurrentObjName;
                   Cols4 = Cols;
                   Rows4 = Rows;
                   Grid4->ColCount = 2;
                   Grid4->RowCount = Rows4 + 1;
                   for (i = 0; i <= Rows4; i++)
                       for (j = 0; j <= Cols4; j++)
                           Grid4->Cells[j][i] = "";
                   for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col."+ IntToStr(i);
                   for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row" + IntToStr(i);
                   break;
          } // end switch
          ColVecCount = ColVecCount + 1;
          ColCombo->Items->Add(CurrentObjName);
          OperationEdit->Text = "ColVecInput";
          Operand1Edit->Text = CurrentObjName;
          Operand2Edit->Text = "";
          Operand3Edit->Text = "";
     }
     switch (CurrentGrid)
     {
          case 1 : Grid1->SetFocus(); break;
          case 2 : Grid2->SetFocus(); break;
          case 3 : Grid3->SetFocus(); break;
          case 4 : Grid4->SetFocus(); break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::KeyScalarClick(TObject *Sender)
{
     AnsiString instr;

     instr = InputBox("GRID?","Which grid no. (1-4):","1");
     CurrentGrid = StrToInt(instr);
     if ((CurrentGrid < 1) || (CurrentGrid > 4)) CurrentGrid = 1;
     GridNoEdit->Text = IntToStr(CurrentGrid);
     ScaCount = ScaCount + 1;
     instr = InputBox("Scaler Name","Object name:","Ascaler");
     CurrentObjName = instr;
     CurrentObjType = 4;
     switch (CurrentGrid)
     {
        case 1 :
              Rows1 = 1;
              Cols1 = 1;
              Grid1->RowCount = 2;
              Grid1->ColCount = 2;
              Grid1->Cells[1][0] = "Col.1";
              Grid1->Cells[0][1] = "Row.1";
              Grid1->Cells[1][1] = "";
              Obj1NameEdit->Text = CurrentObjName;
              break;
        case 2 :
              Rows2 = 1;
              Cols2 = 1;
              Grid2->RowCount = 2;
              Grid2->ColCount = 2;
              Grid2->Cells[1][0] = "Col.1";
              Grid2->Cells[0][1] = "Row.1";
              Grid2->Cells[1][1] = "";
              Obj2NameEdit->Text = CurrentObjName;
              break;
        case 3 :
              Rows3 = 1;
              Cols3 = 1;
              Grid3->RowCount = 2;
              Grid3->ColCount = 2;
              Grid3->Cells[1][0] = "Col.1";
              Grid3->Cells[0][1] = "Row.1";
              Grid3->Cells[1][1] = "";
              Obj3NameEdit->Text = CurrentObjName;
              break;
        case 4 :
              Rows4 = 1;
              Cols4 = 1;
              Grid4->RowCount = 2;
              Grid4->ColCount = 2;
              Grid4->Cells[1][0] = "Col.1";
              Grid4->Cells[0][1] = "Row.1";
              Grid4->Cells[1][1] = "";
              Obj4NameEdit->Text = CurrentObjName;
              break;
     } // end switch
     switch (CurrentGrid)
     {
          case 1 : Grid1->SetFocus(); break;
          case 2 : Grid2->SetFocus(); break;
          case 3 : Grid3->SetFocus(); break;
          case 4 : Grid4->SetFocus(); break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::mnuOpenClick(TObject *Sender)
{
     GetFile(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid1KeyPress(TObject *Sender, char &Key)
{
     AnsiString instr;

     if (Key == 13) // return pressed
     {
          if ((Grid1->Row == Rows) && (Grid1->Col == Cols))
          {
               instr = InputBox("SAVE","Save object?","Yes");
               if (instr == "Yes") mnuSaveClick(this);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid2KeyPress(TObject *Sender, char &Key)
{
     AnsiString instr;

     CurrentGrid = 2;
     if (Key == 13)  // return pressed
     {
          if ((Grid2->Row == Rows) && (Grid2->Col == Cols))
          {
               instr = InputBox("SAVE","Save object?","Yes");
               if (instr == "Yes") mnuSaveClick(this);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid3KeyPress(TObject *Sender, char &Key)
{
     AnsiString instr;

     CurrentGrid = 3;
     if (Key == 13) // return pressed
     {
          if ((Grid3->Row == Rows) && (Grid3->Col == Cols))
          {
               instr = InputBox("SAVE","Save object?","Yes");
               if (instr == "Yes") mnuSaveClick(this);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid4KeyPress(TObject *Sender, char &Key)
{
     AnsiString instr;

     CurrentGrid = 4;
     if (Key == 13) // return pressed
     {
          if ((Grid4->Row == Rows) && (Grid4->Col == Cols))
          {
               instr = InputBox("SAVE","Save object?","Yes");
               if (instr == "Yes") mnuSaveClick(this);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Save2Click(TObject *Sender)
{
     FILE *SaveFile;
     int i, Count;
     char filename[121];
     char editline[121];
     char newline = '\n';
     bool done = false;

     Count = 0;
     Count = ScriptList->Items->Count;
     if (Count < 1) return;

     CurrentObjType = 5; // a script file
     SaveDialog1->FileName = "Script";
     SaveDialog1->Filter = "Script (*.SCP)|*.SCP|(*.*)|*.*";
     SaveDialog1->DefaultExt = "SCP";
     if (SaveDialog1->Execute())
     {
         strcpy(filename,SaveDialog1->FileName.c_str());
         SaveFile = fopen(filename,"wt");
         CurrentObjName = ExtractFileName(SaveDialog1->FileName);
         fprintf(SaveFile,"%d%c",CurrentObjType,newline);
         fprintf(SaveFile,"%s%c",CurrentObjName,newline);
         fprintf(SaveFile,"%d%c",Count,newline);
         for (i = 0; i < Count; i++)
         {
             strcpy(editline,ScriptList->Items->Strings[i].c_str());
             fprintf(SaveFile,"%s%c",editline,newline);
         }
         fclose(SaveFile);
         OperationEdit->Text = "SaveScript";
         Operand1Edit->Text = SaveDialog1->FileName;
         Operand2Edit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Load1Click(TObject *Sender)
{
     FILE *SaveFile;
     int i, Count;
     AnsiString cellstring;
     AnsiString ScriptName;
     char filename[221];
     char editline[221];

     OpenDialog1->FileName = "Script";
     OpenDialog1->Filter = "Script (*.SCP)|*.SCP|(*.*)|*.*";
     OpenDialog1->DefaultExt = "SCP";
     if (OpenDialog1->Execute())
     {
          ScriptName = ExtractFileName(OpenDialog1->FileName);
          ScriptList->Clear();
          FrmScriptEditor->ScriptList->Clear();
          FrmScriptEditor->ScriptFileEdit->Text = OpenDialog1->FileName;
          strcpy(filename,OpenDialog1->FileName.c_str());
          SaveFile = fopen(filename,"rt");
          fscanf(SaveFile,"%d",&CurrentObjType);
          if (CurrentObjType != 5)
          {
               ShowMessage("Not a script file!");
               fclose(SaveFile);
               return;
          }
          fscanf(SaveFile,"%s",&editline);
          CurrentObjName = editline;
          Operand1Edit->Text = OpenDialog1->FileName;
          fscanf(SaveFile,"%d",&Count);
          for (i = 0; i < Count; i++)
          {
               fscanf(SaveFile,"%s",&editline);
               cellstring = editline; // filename;
               if (cellstring != "")
               {
                  ScriptList->Items->Add(cellstring);
                  FrmScriptEditor->ScriptList->Items->Add(cellstring);
               }
          }
          fclose(SaveFile);
          OperationEdit->Text = "OpenScript";
          Operand2Edit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Execute1Click(TObject *Sender)
{
   int i, Count;
   int parseresult;
   int Opergrid, Op1grid, Op2grid, Op3grid;

   Count = ScriptList->Items->Count;
   if (Count < 1)
   {
        ShowMessage("No script loaded to execute!");
        return;
   }
   ScriptOp = true;
   for (i = 0; i < Count; i++)
   {
        OpStr = ScriptList->Items->Strings[i];

        parseresult = OpParse( Opergrid, Op1grid, Op2grid, Op3grid);
        if (parseresult == 0)
        {
             ShowMessage("Operation code not found in a script entry.");
             ScriptOp = false;
             return;
        }

        // Now, execute the operation
        OperExec(); //(Operation, Op1, Op2, Op3, Opergrid, Op1grid, Op2grid, Op3grid);
        if (i == Count - 1) ScriptOp = false;
        LastScript = i;
   } // next i
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::RowAugment1Click(TObject *Sender)
{
   int i;
   AnsiString opstr, prmptstr, info;

   if (CurrentObjType != 1)
   {
        ShowMessage("Error - Grid does not contain a matrix.");
        return;
   }
   if (CurrentGrid == 0) return;
   switch (CurrentGrid)
   {
      case 1 :
            Rows1 = Rows1 + 1;
            Grid1->RowCount = Rows1 + 1;
            Grid1->Cells[0][Rows1] = "Row" + IntToStr(Rows1);
            for (i = 1; i <= Cols1; i++) Grid1->Cells[i][Rows1] = FloatToStr(1.0);
            Operand1Edit->Text = Obj1NameEdit->Text;
            break;
      case 2 :
            Rows2 = Rows2 + 1;
            Grid2->RowCount = Rows2 + 1;
            Grid2->Cells[0][Rows2] = "Row" + IntToStr(Rows2);
            for (i = 1; i <= Cols2; i++) Grid2->Cells[i][Rows2] = FloatToStr(1.0);
            Operand1Edit->Text = Obj2NameEdit->Text;
            break;
      case 3 :
            Rows3 = Rows3 + 1;
            Grid3->RowCount = Rows3 + 1;
            Grid3->Cells[0][Rows3] = "Row" + IntToStr(Rows3);
            for (i = 1; i <= Cols3; i++) Grid3->Cells[i][Rows3] = FloatToStr(1.0);
            Operand1Edit->Text = Obj3NameEdit->Text;
            break;
      case 4 :
            Rows4 = Rows4 + 1;
            Grid4->RowCount = Rows4 + 1;
            Grid4->Cells[0][Rows4] = "Row" + IntToStr(Rows4);
            for (i = 1; i <= Cols4; i++) Grid4->Cells[i][Rows4] = FloatToStr(1.0);
            Operand1Edit->Text = Obj4NameEdit->Text;
            break;
   } // end switch
   OperationEdit->Text = "RowAugment";
   CurrentObjType = 1;
   opstr = IntToStr(CurrentGrid) + "-";
   Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
   opstr = opstr + "RowAugment:" + Operand1Edit->Text;
   if (ScriptOp == false)
   {
       prmptstr = "Save result as: ";
       info = InputBox("SAVE AS",prmptstr,"RowAugMat");
       if (info.Length() > 0) Operand2Edit->Text = info;
       else Operand2Edit->Text = "RowAugMat";
       switch (CurrentGrid)
       {
          case 1 : Obj1NameEdit->Text = Operand2Edit->Text; break;
          case 2 : Obj2NameEdit->Text = Operand2Edit->Text; break;
          case 3 : Obj3NameEdit->Text = Operand2Edit->Text; break;
          case 4 : Obj4NameEdit->Text = Operand2Edit->Text; break;
       }
       opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
       ScriptList->Items->Add(opstr);
       CurrentObjName = Operand2Edit->Text;
       CurrentObjType = 1;
       mnuSaveClick(this);
       ComboAdd(CurrentObjName);
   }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid1Click(TObject *Sender)
{
     CurrentGrid = 1;
     CurrentObjName = Obj1NameEdit->Text;
     GridNoEdit->Text = IntToStr(1);
     if ((Rows1 >= 2) && (Cols1 >= 2)) CurrentObjType = 1;
     if ((Rows1 >= 2) && (Cols1 == 1)) CurrentObjType = 2;
     if ((Rows1 == 1) && (Cols1 >= 2)) CurrentObjType = 3;
     if ((Rows1 == 1) && (Cols1 == 1)) CurrentObjType = 4;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid2Click(TObject *Sender)
{
     CurrentGrid = 2;
     CurrentObjName = Obj2NameEdit->Text;
     GridNoEdit->Text = IntToStr(2);
     if ((Rows1 >= 2) && (Cols1 >= 2)) CurrentObjType = 1;
     if ((Rows1 >= 2) && (Cols1 == 1)) CurrentObjType = 2;
     if ((Rows1 == 1) && (Cols1 >= 2)) CurrentObjType = 3;
     if ((Rows1 == 1) && (Cols1 == 1)) CurrentObjType = 4;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid3Click(TObject *Sender)
{
     CurrentGrid = 3;
     CurrentObjName = Obj3NameEdit->Text;
     GridNoEdit->Text = IntToStr(3);
     if ((Rows1 >= 2) && (Cols1 >= 2)) CurrentObjType = 1;
     if ((Rows1 >= 2) && (Cols1 == 1)) CurrentObjType = 2;
     if ((Rows1 == 1) && (Cols1 >= 2)) CurrentObjType = 3;
     if ((Rows1 == 1) && (Cols1 == 1)) CurrentObjType = 4;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid4Click(TObject *Sender)
{
     CurrentGrid = 4;
     CurrentObjName = Obj4NameEdit->Text;
     GridNoEdit->Text = IntToStr(4);
     if ((Rows1 >= 2) && (Cols1 >= 2)) CurrentObjType = 1;
     if ((Rows1 >= 2) && (Cols1 == 1)) CurrentObjType = 2;
     if ((Rows1 == 1) && (Cols1 >= 2)) CurrentObjType = 3;
     if ((Rows1 == 1) && (Cols1 == 1)) CurrentObjType = 4;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ColumnAugment1Click(TObject *Sender)
{
   int i;
   AnsiString opstr, prmptstr, info;

   if (CurrentObjType != 1)
   {
        ShowMessage("Error - Grid does not contain a matrix.");
        return;
   }
   if (CurrentGrid == 0) return;
   switch (CurrentGrid)
   {
      case 1 :
            Cols1 = Cols1 + 1;
            Grid1->ColCount = Cols1 + 1;
            Grid1->Cells[Cols1][0] = "Col" + IntToStr(Cols1);
            for (i = 1; i <= Rows1; i++) Grid1->Cells[Cols1][i] = FloatToStr(1.0);
            Operand1Edit->Text = Obj1NameEdit->Text;
            break;
      case 2 :
            Cols2 = Cols2 + 1;
            Grid2->ColCount = Cols2 + 1;
            Grid2->Cells[Cols2][0] = "Col" + IntToStr(Cols2);
            for (i = 1; i <= Rows2; i++) Grid1->Cells[Cols2][i] = FloatToStr(1.0);
            Operand1Edit->Text = Obj2NameEdit->Text;
            break;
      case 3 :
            Cols3 = Cols3 + 1;
            Grid3->ColCount = Cols3 + 1;
            Grid3->Cells[Cols3][0] = "Col" + IntToStr(Cols3);
            for (i = 1; i <= Rows3; i++) Grid3->Cells[Cols3][i] = FloatToStr(1.0);
            Operand1Edit->Text = Obj3NameEdit->Text;
            break;
      case 4 :
            Cols4 = Cols4 + 1;
            Grid4->ColCount = Cols4 + 1;
            Grid4->Cells[Cols4][0] = "Col" + IntToStr(Cols4);
            for (i = 1; i <= Rows4; i++) Grid4->Cells[Cols4][i] = FloatToStr(1.0);
            Operand1Edit->Text = Obj4NameEdit->Text;
            break;
   } // end switch
   Operand3Edit->Text = "";
   OperationEdit->Text = "ColAugment";
   CurrentObjType = 1;
   if (ScriptOp == false)
   {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"ColAugMat");
          if (info.Length() > 0) Operand2Edit->Text = ":" + IntToStr(CurrentGrid) + "-" + info;
          else Operand2Edit->Text = "";
          opstr = IntToStr(CurrentGrid) + "-";
          opstr = opstr + "ColAugment:" + Operand1Edit->Text;
          opstr = opstr + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          if (info.Length() > 0)
          {
               CurrentObjName = info;
               CurrentObjType = 1;
               mnuSaveClick(this);
          }
          ComboAdd(CurrentObjName);
          if (info.Length() > 0)
          {
               switch (CurrentGrid)
               {
                  case 1 : Obj1NameEdit->Text = info; break;
                  case 2 : Obj2NameEdit->Text = info; break;
                  case 3 : Obj3NameEdit->Text = info; break;
                  case 4 : Obj4NameEdit->Text = info; break;
               }
          }
   }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::mnuDelRowClick(TObject *Sender)
{
   int i, j;
   int delrow;
   AnsiString opstr, prmptstr, info;

   if (CurrentObjType != 1)
   {
        ShowMessage("Error - Grid does not contain a matrix.");
        return;
   }
   if (CurrentGrid == 0) return;
   switch (CurrentGrid)
   {
      case 1 :
            delrow = Grid1->Row;
            for (i = delrow + 1; i < Grid1->RowCount; i++)
                for (j = 1; j < Grid1->ColCount; j++)
                    Grid1->Cells[j][i-1] = Grid1->Cells[j][i];
            Grid1->RowCount = Grid1->RowCount - 1;
            Rows1 = Rows1 - 1;
            Operand1Edit->Text = Obj1NameEdit->Text;
            break;
      case 2 :
            delrow = Grid2->Row;
            for (i = delrow + 1; i < Grid2->RowCount; i++)
                for (j = 1; j < Grid2->ColCount; j++)
                    Grid2->Cells[j][i-1] = Grid2->Cells[j][i];
            Grid2->RowCount = Grid2->RowCount - 1;
            Rows2 = Rows2 - 1;
            Operand1Edit->Text = Obj2NameEdit->Text;
            break;
      case 3 :
            delrow = Grid3->Row;
            for (i = delrow + 1; i < Grid3->RowCount; i++)
                for (j = 1; j < Grid3->ColCount; j++)
                    Grid3->Cells[j][i-1] = Grid3->Cells[j][i];
            Grid3->RowCount = Grid3->RowCount - 1;
            Rows3 = Rows3 - 1;
            Operand1Edit->Text = Obj3NameEdit->Text;
            break;
      case 4 :
            delrow = Grid4->Row;
            for (i = delrow + 1; i < Grid4->RowCount; i++)
                for (j = 1; j < Grid4->ColCount; j++)
                    Grid4->Cells[j][i-1] = Grid4->Cells[j][i];
            Grid4->RowCount = Grid4->RowCount - 1;
            Rows4 = Rows4 - 1;
            Operand1Edit->Text = Obj4NameEdit->Text;
            break;
   }
   OperationEdit->Text = "DeleteRow";
   CurrentObjType = 1;
   if (ScriptOp == false)
   {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"RowDeleted");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else Operand2Edit->Text = "RowDeleted";
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          opstr = opstr + "DeleteRow:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = Operand2Edit->Text;
          CurrentObjType = 1;
          mnuSaveClick(this);
          ComboAdd(CurrentObjName);
          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = Operand2Edit->Text; break;
             case 2 : Obj2NameEdit->Text = Operand2Edit->Text; break;
             case 3 : Obj3NameEdit->Text = Operand2Edit->Text; break;
             case 4 : Obj4NameEdit->Text = Operand2Edit->Text; break;
          }
   }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::mnuDelColumnClick(TObject *Sender)
{
   int i, j;
   int delcol;
   AnsiString opstr, prmptstr, info;

   if (CurrentObjType != 1)
   {
        ShowMessage("Error - Grid does not contain a matrix.");
        return;
   }
   if (CurrentGrid == 0) return;
   switch (CurrentGrid)
   {
      case 1 :
            delcol = Grid1->Col;
            for (i = delcol + 1; i < Grid1->ColCount; i++)
                for (j = 1; j < Grid1->RowCount; j++)
                    Grid1->Cells[i-1][j] = Grid1->Cells[i][j];
            Grid1->ColCount = Grid1->ColCount - 1;
            Cols1 = Cols1 - 1;
            Operand1Edit->Text = Obj1NameEdit->Text;
            break;
      case 2 :
            delcol = Grid2->Col;
            for (i = delcol + 1; i < Grid2->ColCount; i++)
                for (j = 1; j < Grid2->RowCount; j++)
                    Grid2->Cells[i-1][j] = Grid2->Cells[i][j];
            Grid2->ColCount = Grid2->ColCount - 1;
            Cols2 = Cols2 - 1;
            Operand1Edit->Text = Obj2NameEdit->Text;
            break;
      case 3 :
            delcol = Grid3->Col;
            for (i = delcol + 1; i < Grid3->ColCount; i++)
                for (j = 1; j < Grid3->RowCount; j++)
                    Grid3->Cells[i-1][j] = Grid3->Cells[i][j];
            Grid3->ColCount = Grid3->ColCount - 1;
            Cols3 = Cols3 - 1;
            Operand1Edit->Text = Obj3NameEdit->Text;
            break;
      case 4 :
            delcol = Grid4->Col;
            for (i = delcol + 1; i < Grid4->ColCount; i++)
                for (j = 1; j < Grid4->RowCount; j++)
                    Grid4->Cells[i-1][j] = Grid4->Cells[i][j];
            Grid4->ColCount = Grid4->ColCount - 1;
            Cols4 = Cols4 - 1;
            Operand1Edit->Text = Obj4NameEdit->Text;
            break;
   }
   OperationEdit->Text = "DeleteCol";
   CurrentObjType = 1;
   if (ScriptOp == false)
   {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"ColDel");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else Operand2Edit->Text = "ColDel";
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          opstr = opstr + "DeleteCol:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = Operand2Edit->Text;
          CurrentObjType = 1;
          mnuSaveClick(this);
          ComboAdd(CurrentObjName);
          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = Operand2Edit->Text; break;
             case 2 : Obj2NameEdit->Text = Operand2Edit->Text; break;
             case 3 : Obj3NameEdit->Text = Operand2Edit->Text; break;
             case 4 : Obj4NameEdit->Text = Operand2Edit->Text; break;
          }
   }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::SVDInverse1Click(TObject *Sender)
{
     int size, gridchoice;
     int i, j;
     AnsiString opstr, prmptstr, info;

     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }
     switch (CurrentGrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              if (Rows3 != Cols3) goto emsg;
              size = Rows3;
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }

     // allocate memory
     GetDblMatMem(Matrix1,size,size);
     switch (CurrentGrid)
     {
        case 1 :
             for (i = 0; i < size; i++)
                 for (j = 0; j < size; j++)
                     Matrix1[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
             break;
        case 2 :
             for (i = 0; i < size; i++)
                 for (j = 0; j < size; j++)
                     Matrix1[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
             break;
        case 3 :
             for (i = 0; i < size; i++)
                 for (j = 0; j < size; j++)
                     Matrix1[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
             break;
        case 4 :
             for (i = 0; i < size; i++)
                 for (j = 0; j < size; j++)
                     Matrix1[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
             break;
     }
     SVDinverse(Matrix1,size);
     // Place results in the selected grid
     prmptstr = InputBox("WHERE","Place results in which Grid?","1");
     gridchoice = StrToInt(prmptstr);
     switch (gridchoice)
     {
        case 1:
             Grid1->RowCount = size + 1;
             Grid1->ColCount = size + 1;
             Rows1 = size;
             Cols1 = size;
             Obj1NameEdit->Text = "Inverse";
             for (i = 0; i < size; i++)
                 for (j = 0; j <  size; j++)
                   Grid1->Cells[j+1][i+1] = FloatToStr(Matrix1[i][j]);
             break;
        case 2:
             Grid2->RowCount = size + 1;
             Grid2->ColCount = size + 1;
             Rows2 = size;
             Cols2 = size;
             Obj2NameEdit->Text = "Inverse";
             for (i = 0; i < size; i++)
                 for (j = 0; j <  size; j++)
                   Grid2->Cells[j+1][i+1] = FloatToStr(Matrix1[i][j]);
             break;
        case 3:
             Grid3->RowCount = size + 1;
             Grid3->ColCount = size + 1;
             Rows3 = size;
             Cols3 = size;
             Obj3NameEdit->Text = "Inverse";
             for (i = 0; i < size; i++)
                 for (j = 0; j <  size; j++)
                   Grid3->Cells[j+1][i+1] = FloatToStr(Matrix1[i][j]);
             break;
        case 4:
             Grid4->RowCount = size + 1;
             Grid4->ColCount = size + 1;
             Rows4 = size;
             Cols4 = size;
             Obj4NameEdit->Text = "Inverse";
             for (i = 0; i < size; i++)
                 for (j = 0; j <  size; j++)
                   Grid4->Cells[j+1][i+1] = FloatToStr(Matrix1[i][j]);
             break;
     }

     OperationEdit->Text = "SVDInverse";
     if (ScriptOp == false)
     {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"");
          if (info.Length() > 0) Obj1NameEdit->Text = info;
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          Operand1Edit->Text = IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + "SVDInverse:" + Operand1Edit->Text;
          if (info.Length() > 0) Operand2Edit->Text = ":" + IntToStr(1) + "-" + info;
          else Operand2Edit->Text = "";
          opstr = opstr + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          if (info.Length() > 0)
          {
               CurrentObjName = info;
               CurrentObjType = 1;
               CurrentGrid = 1;
               mnuSaveClick(this);
          }
          ComboAdd(CurrentObjName);
     }
     // deallocate memory
     ClearDblMatMem(Matrix1,size);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::MATxMATClick(TObject *Sender)
{
     int i, j, k;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "Multiply the pre-matrix in grid ";
          info = InputBox("PRE MAT GRID",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "Times the post-matrix in grid";
          info = InputBox("POST MAT GRID",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else
     { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }
     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }
     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj4NameEdit->Text;
              break;
     }

     GetDblMatMem(prodmat,prerows,postcols);
     for (i = 0; i < prerows; i++)
     {
         for (j = 0; j < postcols; j++)
         {
             prodmat[i][j] = 0.0;
             for (k = 0; k < precols; k++)
                 prodmat[i][j] = prodmat[i][j] + (premat[i][k] * postmat[k][j]);
         }
     }

     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= prerows; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= postcols; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= prerows; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= postcols; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= prerows; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= postcols; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= prerows; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= postcols; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              break;
     }
     OperationEdit->Text = "PreMatxPostMat";
     if (ScriptOp == false)
     {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"");
          if (info.Length() > 0)
          {
               Operand3Edit->Text = info;
               Operand3Edit->Text = IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          }
          else Operand3Edit->Text = "";
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          Operand1Edit->Text = IntToStr(pregrid) + "-" + Operand1Edit->Text;
          opstr = opstr + "PreMatxPostMat:"+ Operand1Edit->Text;
          Operand2Edit->Text = ExtractFileName(Operand2Edit->Text);
          Operand2Edit->Text = IntToStr(postgrid) + "-" + Operand2Edit->Text;
          opstr = opstr + ":" + Operand2Edit->Text;
          if (info.Length() > 0) opstr = opstr + ":" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          if (info.Length() > 0)
          {
               switch (resultgrid)
               {
                  case 1 : Obj1NameEdit->Text = info; break;
                  case 2 : Obj2NameEdit->Text = info; break;
                  case 3 : Obj3NameEdit->Text = info; break;
                  case 4 : Obj4NameEdit->Text = info; break;
               }
               CurrentObjName = info;
               CurrentObjType = 1;
               CurrentGrid = resultgrid;
               mnuSaveClick(this);
          }
          ComboAdd(CurrentObjName);
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Reset1Click(TObject *Sender)
{
     ResetGrids(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::MatrixComboClick(TObject *Sender)
{
     AnsiString matstr;
     AnsiString answer;
     int indexno;
     int gridno;

     indexno = MatrixCombo->ItemIndex;
     if (indexno < 0) return;
     matstr = MatrixCombo->Items->Strings[indexno];
     answer = InputBox("PLACEMENT","Place in which Grid?","1");
     gridno = StrToInt(answer);
     if ((gridno < 1) || (gridno > 4))
     {
          ShowMessage("Error - Grid number must be between 1 and 4.");
          return;
     }
     CurrentGrid = gridno;
     CurrentObjType = 1;
     CurrentObjName = matstr;
     OpenDialog1->FileName = matstr;
     GetFile(this);
}
//---------------------------------------------------------------------------

bool TMatManForm::DuplicateMat(AnsiString str)
{
     int itemcnt;
     int i;
     bool rslt;

     rslt = false;
     itemcnt = MatrixCombo->Items->Count;
     if (itemcnt > 0)
     {
          for (i = 0; i < itemcnt; i++)
              if (MatrixCombo->Items->Strings[i] == str) rslt = true;
     }
     return(rslt);
}
//-------------------------------------------------------------------

bool TMatManForm::DuplicateColVec(AnsiString str)
{
     int itemcnt;
     int i;
     bool rslt;

     rslt = false;
     itemcnt = ColCombo->Items->Count;
     if (itemcnt > 0)
     {
          for (i = 0; i < itemcnt; i++)
              if (ColCombo->Items->Strings[i] == str) rslt = true;
     }
     return(rslt);
}
//-------------------------------------------------------------------

bool TMatManForm::DuplicateRowVec(AnsiString str)
{
     int itemcnt;
     int i;
     bool rslt;

     rslt = false;
     itemcnt = RowCombo->Items->Count;
     if (itemcnt > 0)
     {
          for (i = 0; i < itemcnt; i++)
              if (RowCombo->Items->Strings[i] == str) rslt = true;
     }
     return(rslt);
}
//-------------------------------------------------------------------

void __fastcall TMatManForm::ColComboClick(TObject *Sender)
{
     AnsiString vecstr, answer;
     int indexno, gridno;

     indexno = ColCombo->ItemIndex;
     if (indexno < 0) return;
     vecstr = ColCombo->Items->Strings[indexno];
     answer = InputBox("PLACEMENT","Place in which Grid?","1");
     gridno = StrToInt(answer);
     if ((gridno < 1) || (gridno > 4))
     {
          ShowMessage("Error - Grid number must be between 1 and 4.");
          return;
     }
     CurrentGrid = gridno;
     CurrentObjType = 2;
     CurrentObjName = vecstr;
     OpenDialog1->FileName = vecstr;
     GetFile(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::RowComboClick(TObject *Sender)
{
     AnsiString vecstr, answer;
     int indexno, gridno;

     indexno = RowCombo->ItemIndex;
     if (indexno < 0) return;
     vecstr = RowCombo->Items->Strings[indexno];
     answer = InputBox("PLACEMENT","Place in which Grid?","1");
     gridno = StrToInt(answer);
     if ((gridno < 1) || (gridno > 4))
     {
          ShowMessage("Error - Grid number must be between 1 and 4.");
          return;
     }
     CurrentGrid = gridno;
     CurrentObjType = 3;
     CurrentObjName = vecstr;
     OpenDialog1->FileName = vecstr;
     GetFile(this);
}
//---------------------------------------------------------------------------

bool TMatManForm::DuplicateScaler(AnsiString str)
{
     int itemcnt;
     int i;
     bool rslt;

     rslt = false;
     itemcnt = ScalerCombo->Items->Count;
     if (itemcnt > 0)
     {
          for (i = 0; i < itemcnt; i++)
              if (ScalerCombo->Items->Strings[i] == str) rslt = true;
     }
     return(rslt);
}
//-------------------------------------------------------------------

void __fastcall TMatManForm::ScalerComboClick(TObject *Sender)
{
     AnsiString scalerstr, answer;
     int indexno, gridno;

     indexno = ScalerCombo->ItemIndex;
     if (indexno < 0) return;
     scalerstr = ScalerCombo->Items->Strings[indexno];
     answer = InputBox("PLACEMENT","Place in which Grid?","1");
     gridno = StrToInt(answer);
     if ((gridno < 1) || (gridno > 4))
     {
          ShowMessage("Error - Grid number must be between 1 and 4.");
          return;
     }
     CurrentGrid = gridno;
     CurrentObjType = 4;
     CurrentObjName = scalerstr;
     OpenDialog1->FileName = scalerstr;
     GetFile(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Tridiagonalize1Click(TObject *Sender)
{
     int size, i, j;
     AnsiString opstr, prmptstr, info;
     double *avector, *bvector;

     if (CurrentGrid == 0) return;
     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }
     switch (CurrentGrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              if (Rows3 != Cols3) goto emsg;
              size = Rows3;
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     // allocate memory
     GetDblMatMem(Matrix1,size,size);
     GetDblMatMem(Matrix2,size,size);
     avector = new double[size];
     bvector = new double[size];

     // store data in Matrix1 to be inverted
     switch (CurrentGrid)
     {
        case 1 :
            for (i = 0; i < size; i++)
               for (j = 0; j < size; j++)
                  Matrix1[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
            break;
        case 2 :
            for (i = 0; i < size; i++)
               for (j = 0; j < size; j++)
                  Matrix1[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
            break;
        case 3 :
            for (i = 0; i < size; i++)
               for (j = 0; j < size; j++)
                  Matrix1[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
            break;
        case 4 :
            for (i = 0; i < size; i++)
               for (j = 0; j < size; j++)
                  Matrix1[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
            break;
     }
     tred2(Matrix1, size, avector, bvector);
     for (i = 0; i < size; i++)
     {
          for (j = 0; j < size; j++)
          {
               Matrix2[i][j] = 0.0;
               if (i == j) Matrix2[i][j] = avector[i];
               if (i < size-1) Matrix2[i][i+1] = bvector[i+1];
               if (i > 0) Matrix2[i][i-1] = bvector[i];
          }
     }

     // Replace original matrix with tridiagonalized matrix
     switch (CurrentGrid)
     {
        case 1 :
               for (i = 0; i < size; i++)
                   for (j = 0; j < size; j++)
                       Grid1->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
               break;
        case 2 :
               for (i = 0; i < size; i++)
                   for (j = 0; j < size; j++)
                       Grid2->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
               break;
        case 3 :
               for (i = 0; i < size; i++)
                   for (j = 0; j < size; j++)
                       Grid3->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
               break;
        case 4 :
               for (i = 0; i < size; i++)
                   for (j = 0; j < size; j++)
                       Grid4->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
               break;
     }

     OperationEdit->Text = "Tridiagonalize";
     opstr = IntToStr(CurrentGrid) + "-";
     Operand1Edit->Text = Operand1Edit->Text;
     opstr = opstr + "Tridiagonalize:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save result as: ";
          info = InputBox("SAVE AS",prmptstr,"TriDiag");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else Operand2Edit->Text = "TriDiag";
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = Operand2Edit->Text;
          CurrentObjType = 1;
          mnuSaveClick(this);
          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = Operand2Edit->Text; break;
             case 2 : Obj2NameEdit->Text = Operand2Edit->Text; break;
             case 3 : Obj3NameEdit->Text = Operand2Edit->Text; break;
             case 4 : Obj4NameEdit->Text = Operand2Edit->Text; break;
          }
          ComboAdd(CurrentObjName);
     }
     // deallocate memory
     delete[] bvector;
     delete[] avector;
     ClearDblMatMem(Matrix2,size);
     ClearDblMatMem(Matrix1,size);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::UpLowDecompClick(TObject *Sender)
{
     int size,i, j;
     AnsiString opstr, prmptstr, info;
     int *intvector;
     double scaler;
     AnsiString lowername, uppername;

     if (CurrentGrid == 0) return;
     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }
     switch (CurrentGrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              if (Rows3 != Cols3)goto emsg;
              size = Rows3;
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }

     // allocate memory
     GetDblMatMem(Matrix1,size,size);
     GetDblMatMem(Matrix2,size,size);
     GetDblMatMem(Matrix3,size,size);
     GetDblMatMem(Matrix4,size,size);
     intvector = new int[size];

     // store data to be decomposed in Matrix1
     switch (CurrentGrid)
     {
        case 1 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
         break;
        case 2 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
         break;
       case 3 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
         break;
       case 4 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
         break;
     }

     // decompose
     ludcmp(Matrix1, size, intvector, scaler);
     for (i = 0; i < size; i++)
         for (j = 0; j < size; j++)
             Matrix2[i][j] = Matrix1[i][j];
     // store in left and right triangular matrices
     for (i = 0; i < size; i++)
     {
          for (j = 0; j < size; j++)
          {
               Matrix3[i][j] = 0.0;
               Matrix4[i][j] = 0.0;
          }
     }
     for (i = 0; i < size; i++)  // row
     {
          for (j = 0; j <= i; j++)
              Matrix3[i][j] = Matrix2[i][j]; // lower matrix
          Matrix3[i][i] = 1.0;
     }
     for (i = 0; i < size; i++)
         for (j = i; j < size; j++)
             Matrix4[i][j] = Matrix2[i][j]; // upper matrix

     // Place lower in grid1
     Grid1->RowCount = size + 1;
     Grid1->ColCount = size + 1;
     Rows1 = size;
     Cols1 = size;
     for (i = 0; i < size; i++)
         for (j = 0; j < size; j++)
             Grid1->Cells[j+1][i+1] = FloatToStr(Matrix3[i][j]);
     Obj1NameEdit->Text = "LowerDecomp";
     // place upper in grid2
     Grid2->RowCount = size + 1;
     Grid2->ColCount = size + 1;
     Rows2 = size;
     Cols2 = size;
     for (i = 0; i < size; i++)
         for (j = 0; j < size; j++)
             Grid2->Cells[j+1][i+1] = FloatToStr(Matrix4[i][j]);
     Obj2NameEdit->Text = "UpperDecomp";
     //save combined upper and lower in grid3
     Grid3->RowCount = size + 1;
     Grid3->ColCount = size + 1;
     Rows3 = size;
     Cols3 = size;
     for (i = 0; i < size; i++)
         for (j = 0; j < size; j++)
             Grid3->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
     Obj3NameEdit->Text = "LUMatrix";
     // save permutations in grid4
     Grid4->RowCount = size + 1;
     Grid4->ColCount = 2;
     Rows4 = size;
     Cols4 = 1;
     for (i = 0; i < size; i++)  Grid4->Cells[1][i+1] = IntToStr(intvector[i] + 1);
     Obj4NameEdit->Text = "RowPermutations";

     OperationEdit->Text = "UpLowDecomp";
     opstr = IntToStr(CurrentGrid) + "-";
     Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
     opstr = opstr + "UpLowDecomp:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save lower matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"lowermat");
          if (info.Length() > 0) lowername = info;
          else lowername = "lowermat";
          prmptstr = "Save upper matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"uppermat");
          if (info.Length() > 0) uppername = info;
          else uppername = "uppermat";
          opstr = opstr + ":" + IntToStr(1) + "-" + lowername;
          opstr = opstr + ":" + IntToStr(2) + "-" + uppername;
         ScriptList->Items->Add(opstr);
         CurrentObjName = lowername;
         CurrentObjType = 1;
         CurrentGrid = 1;
         Obj1NameEdit->Text = lowername;
         ComboAdd(CurrentObjName);
         mnuSaveClick(this);
         CurrentObjName = uppername;
         CurrentObjType = 1;
         CurrentGrid = 2;
         Obj2NameEdit->Text = uppername;
         ComboAdd(CurrentObjName);
         mnuSaveClick(this);
     }
     // deallocate memory
     delete[] intvector;
     ClearDblMatMem(Matrix4,size);
     ClearDblMatMem(Matrix3,size);
     ClearDblMatMem(Matrix2,size);
     ClearDblMatMem(Matrix1,size);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Print1Click(TObject *Sender)
{
     double **Matrix;
     AnsiString *ColHeadings;
     int i, j;
     int nrows, ncols;
     AnsiString title;

     switch (CurrentGrid)
     {
        case 1 :
              GetDblMatMem(Matrix,Rows1,Cols1);
              ColHeadings = new AnsiString[Cols1];
              nrows = Rows1;
              ncols = Cols1;
              for (i = 0; i < Rows1; i++)
                  for (j = 0; j < Cols1; j++)
                      Matrix[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              for (i = 1; i <= Cols1; i++)  ColHeadings[i-1] = Grid1->Cells[i][0];
              title = Obj1NameEdit->Text;
              break;
         case 2 :
              GetDblMatMem(Matrix,Rows2,Cols2);
              ColHeadings = new AnsiString[Cols2];
              nrows = Rows2;
              ncols = Cols2;
              for (i = 0; Rows2; i++)
                  for (j = 0; j < Cols2; j++)
                      Matrix[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              for (i = 1; i <= Cols2; i++)  ColHeadings[i-1] = Grid2->Cells[i][0];
              title = Obj2NameEdit->Text;
              break;
         case 3 :
              GetDblMatMem(Matrix,Rows3,Cols3);
              ColHeadings = new AnsiString[Cols3];
              nrows = Rows3;
              ncols = Cols3;
              for (i = 0; i < Rows3; i++)
                  for (j = 0; j < Cols3; j++)
                      Matrix[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              for (i = 1; i <= Cols3; i++) ColHeadings[i-1] = Grid3->Cells[i][0];
              title = Obj3NameEdit->Text;
              break;
         case 4 :
              GetDblMatMem(Matrix,Rows4,Cols4);
              ColHeadings = new AnsiString[Cols4];
              nrows = Rows4;
              ncols = Cols4;
              for (i = 0; i < Rows4; i++)
                  for (j = 0; j < Cols4; j++)
                      Matrix[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              for (i = 1;i <= Cols4; i++)  ColHeadings[i-1] = Grid4->Cells[i][0];
              title = Obj4NameEdit->Text;
              break;
     }
     title = title + " From Grid Number " + IntToStr(CurrentGrid);
     ArrayPrint(Matrix, nrows, ncols, "Grid Values",ColHeadings, ColHeadings,title.c_str());
     FrmOutPut->ShowModal();
     delete[] ColHeadings;
     switch (CurrentGrid)
     {
        case 1 : ClearDblMatMem(Matrix,Rows1); break;
        case 2 : ClearDblMatMem(Matrix,Rows2); break;
        case 3 : ClearDblMatMem(Matrix,Rows3); break;
        case 4 : ClearDblMatMem(Matrix,Rows4); break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::DiagonaltoVector1Click(TObject *Sender)
{
     int i, j, size, matgrid, nextgrid;
     double *diag;
     AnsiString opstr,prmptstr, info;

     if (CurrentGrid == 0) return;
     prmptstr = "The matrix is in grid: ";
     info = InputBox("MATRIX GRID",prmptstr,IntToStr(CurrentGrid));
     if (info == "") return;
     matgrid = StrToInt(info);
     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }
     switch (matgrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              diag = new double[size];
              for (i = 0; i < size; i++)  diag[i] = StrToFloat(Grid1->Cells[i+1][i+1]);
              nextgrid = 2;
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              diag = new double[size];
              for (i = 0; i < size; i++)  diag[i] = StrToFloat(Grid2->Cells[i+1][i+1]);
              nextgrid = 3;
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              if (Rows3 != Cols3) goto emsg;
              size = Rows3;
              diag = new double[size];
              for (i = 0; i < size; i++)  diag[i] = StrToFloat(Grid3->Cells[i+1][i+1]);
              nextgrid = 4;
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              diag = new double[size];
              for (i = 0; i < size; i++)  diag[i] = StrToFloat(Grid4->Cells[i+1][i+1]);
              nextgrid = 1;
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     // place diagonal elements in next available grid
     switch (nextgrid)
     {
        case 1:
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Grid1->Cells[j+1][i+1] = "";
              for (i = 0; i < size; i++)  Grid1->Cells[1][i+1] = FloatToStr(diag[i]);
              Cols1 = 1;
              Rows1 = size;
              Grid1->ColCount = 2;
              Grid1->RowCount = size + 1;
              Obj1NameEdit->Text = "DiagVec";
              break;
        case 2:
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Grid2->Cells[j+1][i+1] = "";
              for (i = 0; i < size; i++)  Grid2->Cells[1][i+1] = FloatToStr(diag[i]);
              Cols2 = 1;
              Rows2 = size;
              Grid2->ColCount = 2;
              Grid2->RowCount = size + 1;
              Obj2NameEdit->Text = "DiagVec";
              break;
        case 3:
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Grid3->Cells[j+1][i+1] = "";
              for (i = 0; i < size; i++)  Grid3->Cells[1][i+1] = FloatToStr(diag[i]);
              Cols3 = 1;
              Rows3 = size;
              Grid3->ColCount = 2;
              Grid3->RowCount = size + 1;
              Obj3NameEdit->Text = "DiagVec";
              break;
        case 4:
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Grid4->Cells[j+1][i+1] = "";
              for (i = 0; i < size; i++)  Grid4->Cells[1][i+1] = FloatToStr(diag[i]);
              Cols4 = 1;
              Rows4 = size;
              Grid4->ColCount = 2;
              Grid4->RowCount = size + 1;
              Obj4NameEdit->Text = "DiagVec";
              break;
     }

     OperationEdit->Text = "DiagToVec:";
     opstr = IntToStr(matgrid) + "-" + "DiagToVec:";
     opstr = opstr + IntToStr(matgrid) + "-" + Operand1Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save diagonal vector as: ";
          info = InputBox("SAVE AS",prmptstr,"diagvec");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "diagvec";
               info = "diagvec";
          }
          opstr = opstr + ":" + IntToStr(nextgrid) + "-" + info;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 2;
          CurrentGrid = nextgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (nextgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     delete[] diag;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Determinant1Click(TObject *Sender)
{
     int i, j, size, nextgrid;
     AnsiString opstr, prmptstr, info;
     int *intvector;
     double determ;

     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }

     switch (CurrentGrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              if (Rows3 != Cols3) goto emsg;
              size = Rows3;
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     // allocate memory
     GetDblMatMem(Matrix1,size,size);
     intvector = new int[size];

     // store data to be decomposed in Matrix1
     switch (CurrentGrid)
     {
        case 1 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
         nextgrid = 2;
         break;
        case 2 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
         nextgrid = 3;
         break;
        case 3 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
         nextgrid = 4;
         break;
        case 4 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
         nextgrid = 1;
         break;
     }

     // decompose
     ludcmp(Matrix1,size,intvector,determ);
     for (i = 0; i < size; i++)  determ = determ * Matrix1[i][i];

     // place results in next grid
     switch (nextgrid)
     {
        case 1 :
              Grid1->RowCount = 2;
              Grid1->ColCount = 2;
              Rows1 = 1;
              Cols1 = 1;
              Obj1NameEdit->Text = "Determinant";
              Grid1->Cells[1][1] = FloatToStr(determ);
              CurrentObjName = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = 2;
              Grid2->ColCount = 2;
              Rows2 = 1;
              Cols2 = 1;
              Obj2NameEdit->Text = "Determinant";
              Grid2->Cells[1][1] = FloatToStr(determ);
              CurrentObjName = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = 2;
              Grid3->ColCount = 2;
              Rows3 = 1;
              Cols3 = 1;
              Obj3NameEdit->Text = "Determinant";
              Grid3->Cells[1][1] = FloatToStr(determ);
              CurrentObjName = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = 2;
              Grid4->ColCount = 2;
              Rows4 = 1;
              Cols4 = 1;
              Obj4NameEdit->Text = "Determinant";
              Grid4->Cells[1][1] = FloatToStr(determ);
              CurrentObjName = Obj4NameEdit->Text;
              break;
     }
     if (ScriptOp == false)
     {
          prmptstr = "Save determinant as: ";
          info = InputBox("SAVE AS",prmptstr,"determinant");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "determinant";
               info = "determinant";
          }
          OperationEdit->Text = "Determinant";
          opstr = IntToStr(CurrentGrid) + "-" + "Determinant:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(nextgrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 4;
          CurrentGrid = nextgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (nextgrid)
          {
              case 1 : Obj1NameEdit->Text = info; break;
              case 2 : Obj2NameEdit->Text = info; break;
              case 3 : Obj3NameEdit->Text = info; break;
              case 4 : Obj4NameEdit->Text = info; break;
          }
     }

     // deallocate memory
     delete[] intvector;
     ClearDblMatMem(Matrix1,size);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ComboAdd(AnsiString FileName)
{
     bool rslt;

     if (CurrentObjType == 1) // matrix
     {
          rslt = DuplicateMat(FileName);
          if (rslt == false)
          {
               MatrixCombo->Items->Add(FileName);
               MatCount = MatCount + 1;
          }
     }

     if (CurrentObjType == 2) // column vector
     {
          rslt = DuplicateColVec(FileName);
          if (rslt == false)
          {
               ColCombo->Items->Add(FileName);
               ColVecCount = ColVecCount + 1;
          }
     }

     if (CurrentObjType == 3) // row vector
     {
          rslt = DuplicateRowVec(FileName);
          if (rslt == false)
          {
               RowCombo->Items->Add(FileName);
               RowVecCount = RowVecCount + 1;
          }
     }

     if (CurrentObjType == 4) // scaler
     {
          rslt = DuplicateScaler(FileName);
          if (rslt == false)
          {
               ScalerCombo->Items->Add(FileName);
               ScaCount = ScaCount + 1;
          }
     }
}
//-------------------------------------------------------------------

void __fastcall TMatManForm::EigensClick(TObject *Sender)
{
     int i, j, nfactors, size, choice;
     double *rootsvec, *avector, *bvector;
     double c, trace, pcnttrace, sum;
     AnsiString opstr, prmptstr, info;
     AnsiString rootname, vectname;

     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a symetric matrix.");
          return;
     }
     switch (CurrentGrid)
     {
        case 1 :
              if (Rows1 != Cols1) goto emsg;
              size = Rows1;
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              if (Rows2 != Cols2) goto emsg;
              size = Rows2;
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              if (Rows3 != Cols3) goto emsg;
              size = Rows3;
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              if (Rows4 != Cols4) goto emsg;
              size = Rows4;
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     // allocate memory
     GetDblMatMem(Matrix1,size,size);
     GetDblMatMem(Matrix2,size,size);
     rootsvec = new double[size];
     bvector = new double[size];
     avector = new double[size];

     // store data in Matrix1 to be analyzed
     switch (CurrentGrid)
     {
        case 1 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
         break;
        case 2 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
         break;
        case 3 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
         break;
        case 4 :
         for (i = 0; i < size; i++)
             for (j = 0; j < size; j++)
                 Matrix1[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
         break;
     }

     c = 0.0;
     nfactors = size;
     trace = 0.0;
     sum = 0.0;
     for (i = 0; i < size; i++)  trace = trace + Matrix1[i][i];

     // select the desired method
     if (FrmRootMethod->ShowModal() != mrCancel)
          choice = FrmRootMethod->Choice;
     else goto finish;
     switch (choice)
     {
        case 1 :
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Matrix2[i][j] = Matrix1[i][j];
              SEVS(size,size,c,Matrix1,Matrix2,rootsvec,bvector,size); // works! (vectors not normalized)
              break;
        case 2 : nonsymroots(Matrix1,size,nfactors,c,Matrix2,
                 rootsvec,bvector,trace,pcnttrace); // works (vectors not normalized)
              break;
        case 3 :
              SymMatRoots(Matrix1,size,rootsvec,Matrix2); // works! (vectors normalized)
              for (i = 0; i < size; i++)  bvector[i] = rootsvec[i] / trace * 100.0;
              break;
        case 4 :
              xtqli(Matrix1, size, rootsvec, bvector, avector); // works! (vectors normalized)
              for (i = 0; i < size; i++)
                  for (j = 0; j < size; j++)
                      Matrix2[i][j] = Matrix1[i][j];
              break;
        case 5 :
             Roots(Matrix1,size,rootsvec,Matrix2); // works! (vectors normalized)
             for (i = 0; i < size; i++)  bvector[i] = rootsvec[i] / trace * 100.0;
             break;
     }

     for (i = 0; i < size; i++)  sum = sum + rootsvec[i];
     pcnttrace = (trace / sum) * 100.0;

     // Place results in the four grids
     Grid1->RowCount = size + 1; // diagonal roots matrix in first grid
     Grid1->ColCount = size + 1;
     Grid2->RowCount = size + 1; // column vectors matrix in second
     Grid2->ColCount = size + 1;
     Grid3->RowCount = size + 1; // percentage vector in each root in 3
     Grid3->ColCount = 2;
     Grid4->RowCount = 3; // trace and %trace in 4
     Grid4->ColCount = 2;
     Rows1 = size;
     Cols1 = size;
     Rows2 = size;
     Cols2 = size;
     Rows3 = size;
     Cols3 = 1;
     Rows4 = 2;
     Cols4 = 1;
     for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
     for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col " + IntToStr(i);
     for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
     for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col " + IntToStr(i);
     for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
     for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col " + IntToStr(i);
     for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
     for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col " + IntToStr(i);
     Grid4->Cells[0][1] = "Trace";
     Grid4->Cells[0][2] = "%Extract";
     Obj1NameEdit->Text = "Roots";
     Obj2NameEdit->Text = "vectors";
     Obj3NameEdit->Text = "RootPcnts";
     Obj4NameEdit->Text = "Trace&Pcnt";
     for (i = 0; i < size; i++)
     {
          for (j = 0; j < size; j++)
          {
               if (i == j) Grid1->Cells[i+1][i+1] = FloatToStr(rootsvec[i]);
               else Grid1->Cells[j+1][i+1] = FloatToStr(0.0);
          }
     }
     for (i = 0; i < size; i++)
          for (j = 0; j < size; j++)
               Grid2->Cells[j+1][i+1] = FloatToStr(Matrix2[i][j]);
     for (i = 0; i < size; i++)  Grid3->Cells[1][i+1] = FloatToStr(bvector[i]);
     Grid4->Cells[1][1] = FloatToStr(trace);
     Grid4->Cells[1][2] = FloatToStr(pcnttrace);
     OperationEdit->Text = "MatrixRoots";
     opstr = IntToStr(CurrentGrid) + "-";
     opstr = opstr + "MatrixRoots:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;

     if (ScriptOp == false)
     {
          prmptstr = "Save roots diagonal matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"roots");
          if (info.Length() > 0) rootname = info;
          else rootname = "roots";
          prmptstr = "Save eigenvectors as: ";
          info = InputBox("SAVE AS",prmptstr,"eigenvectors");
          if (info.Length() > 0) vectname = info;
          else vectname = "eigenvectors";
          Obj1NameEdit->Text = rootname;
          Obj2NameEdit->Text = vectname;
          opstr = opstr + ":" + IntToStr(1) + "-" + rootname;
          opstr = opstr + ":" + IntToStr(2) + "-" + vectname;
          ScriptList->Items->Add(opstr);
          // save roots
          CurrentObjName = rootname;
          CurrentObjType = 1;
          CurrentGrid = 1;
          Obj1NameEdit->Text = rootname;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          // save vectors
          CurrentObjName = vectname;
          CurrentObjType = 1;
          CurrentGrid = 2;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          Obj2NameEdit->Text = vectname;
     }
finish:
     // deallocate memory
     delete[] avector;
     delete[] bvector;
     delete[] rootsvec;
     ClearDblMatMem(Matrix2, size);
     ClearDblMatMem(Matrix1, size);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Transpose1Click(TObject *Sender)
{
     int i, j, gridno, nextgrid;
     AnsiString opstr, prmptstr, info;


     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a matrix.");
          return;
     }
/*
     prmptstr = "Transpose the data in which grid?";
     info = InputBox("MATRIX NO.",prmptstr,IntToStr(CurrentGrid));
     gridno = StrToInt(info);
     prmptstr = "Place the transpose in which grid?";
     info = InputBox("MATRIX NO.",prmptstr,IntToStr(CurrentGrid));
     nextgrid = StrToInt(info);
     CurrentGrid = gridno;
*/
     switch (CurrentGrid)
     {
        case 1 :
              Operand1Edit->Text = Obj1NameEdit->Text;
              nextgrid = 2;
              for (i = 1; i <= Rows1; i++)
                  for (j = 1; j <= Cols1; j++)
                      Grid2->Cells[i][j] = Grid1->Cells[j][i];
              for (i = 1; i <= Rows1; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              for (i = 1; i <= Cols1; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              Grid2->RowCount = Cols1 + 1;
              Grid2->ColCount = Rows1 + 1;
              Rows2 = Cols1;
              Cols2 = Rows1;
              break;
        case 2 :
              Operand1Edit->Text = Obj2NameEdit->Text;
              nextgrid = 3;
              for (i = 1; i <= Rows2; i++)
                  for (j = 1; j <= Cols2; j++)
                      Grid3->Cells[i][j] = Grid2->Cells[j][i];
              for (i = 1; i <= Rows2; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              for (i = 1; i <= Cols2; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              Grid3->RowCount = Cols2 + 1;
              Grid3->ColCount = Rows2 + 1;
              Rows3 = Cols2;
              Cols3 = Rows2;
              break;
        case 3 :
              Operand1Edit->Text = Obj3NameEdit->Text;
              nextgrid = 4;
              for (i = 1; i <= Rows3; i++)
                  for (j = 1; j <= Cols3; j++)
                      Grid4->Cells[i][j] = Grid3->Cells[j][i];
              for (i = 1; i <= Rows3; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              for (i = 1; i <= Cols3; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              Grid4->RowCount = Cols3 + 1;
              Grid4->ColCount = Rows3 + 1;
              Rows4 = Cols3;
              Cols4 = Rows3;
              break;
        case 4 :
              Operand1Edit->Text = Obj4NameEdit->Text;
              nextgrid = 1;
              for (i = 1; i <= Rows4; i++)
                  for (j = 1; j <= Cols4; j++)
                      Grid1->Cells[i][j] = Grid4->Cells[j][i];
              for (i = 1; i <= Rows4; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              for (i = 1; i <= Cols4; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              Grid1->RowCount = Cols4 + 1;
              Grid1->ColCount = Rows4 + 1;
              Rows1 = Cols4;
              Cols1 = Rows4;
              break;
     }
     OperationEdit->Text = "MatTranspose";
     Operand3Edit->Text = "";
     if (ScriptOp == false)
     {
          prmptstr = "Save transpose matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"transpose");
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          Operand1Edit->Text = IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + "MatTranspose:" + Operand1Edit->Text;
          if (info.Length() > 0)
               Operand2Edit->Text = ":" + IntToStr(nextgrid) + "-" + info;
          else {
               Operand2Edit->Text = ":" + IntToStr(nextgrid) + "-" + "transpose";
               info = "transpose";
          }
          opstr = opstr + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 1;
          CurrentGrid = nextgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (nextgrid)
          {
              case 1 : Obj1NameEdit->Text = info; break;
              case 2 : Obj2NameEdit->Text = info; break;
              case 3 : Obj3NameEdit->Text = info; break;
              case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScriptListClick(TObject *Sender)
{
   int i, Count;
   int parseresult;
//   AnsiString OpStr;

   Count = ScriptList->Items->Count;
   if (Count < 1)
   {
        ShowMessage("No script loaded to execute!");
        return;
   }
   ScriptOp = true;
   i = ScriptList->ItemIndex;
   OpStr = ScriptList->Items->Strings[i];
   parseresult = OpParse( Opergrid, Op1grid, Op2grid, Op3grid);
   if (parseresult == 0)
   {
        ShowMessage("Operation code not found in a script entry.");
        ScriptOp = false;
        return;
   }

   // Now, execute the operation
   OperExec(); //(Operation, Op1, Op2, Op3, Opergrid, Op1grid, Op2grid, Op3grid);
   ScriptOp = false;
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::NormalizeColumns1Click(TObject *Sender)
{
     int i, j;
     double sum;
     AnsiString opstr, prmptstr, info;

     switch (CurrentGrid)
     {
        case 1 :
              for (j = 1; j < Grid1->ColCount; j++)
              {
                  sum = 0.0;
                  for (i = 1; i < Grid1->RowCount; i++)
                      sum = sum + sqr(StrToFloat(Grid1->Cells[j][i]));
                  sum = sqrt(sum);
                  for (i = 1; i < Grid1->RowCount; i++)
                       Grid1->Cells[j][i] = FloatToStr(StrToFloat(Grid1->Cells[j][i]) / sum);
              }
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              for (j = 1; j < Grid2->ColCount; j++)
              {
                  sum = 0.0;
                  for (i = 1; i < Grid2->RowCount; i++)
                      sum = sum + sqr(StrToFloat(Grid2->Cells[j][i]));
                  sum = sqrt(sum);
                  for (i = 1; i < Grid2->RowCount; i++)
                       Grid2->Cells[j][i] = FloatToStr(StrToFloat(Grid2->Cells[j][i]) / sum);
              }
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              for (j = 1; j < Grid3->ColCount; j++)
              {
                  sum = 0.0;
                  for (i = 1; i < Grid3->RowCount; i++)
                      sum = sum + sqr(StrToFloat(Grid3->Cells[j][i]));
                  sum = sqrt(sum);
                  for (i = 1; i < Grid3->RowCount; i++)
                       Grid3->Cells[j][i] = FloatToStr(StrToFloat(Grid3->Cells[j][i]) / sum);
              }
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              for (j = 1; j < Grid4->ColCount; j++)
              {
                  sum = 0.0;
                  for (i = 1; i < Grid4->RowCount; i++)
                      sum = sum + sqr(StrToFloat(Grid4->Cells[j][i]));
                  sum = sqrt(sum);
                  for (i = 1; i < Grid4->RowCount; i++)
                       Grid4->Cells[j][i] = FloatToStr(StrToFloat(Grid4->Cells[j][i]) / sum);
              }
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }

     if (ScriptOp == false)
     {
          prmptstr = "Save normalized vectors matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"normalvectors");
          if (info.Length() > 0)
          {
               Operand2Edit->Text = ":" + IntToStr(CurrentGrid) + "-" + info;
          }
          else  {
               Operand2Edit->Text = "normalvectors";
               info = "normalvecs";
          }
          switch (CurrentGrid)
          {
              case 1 : Obj1NameEdit->Text = info; break;
              case 2 : Obj2NameEdit->Text = info; break;
              case 3 : Obj3NameEdit->Text = info; break;
              case 4 : Obj4NameEdit->Text = info; break;
          }
         opstr = IntToStr(CurrentGrid) + "-";
         Operand1Edit->Text =  ExtractFileName(Operand1Edit->Text);
         opstr = opstr + "NormalizeCols:" + Operand1Edit->Text;
         opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
         ScriptList->Items->Add(opstr);
         CurrentObjName = info;
         CurrentObjType = 1;
         ComboAdd(CurrentObjName);
         mnuSaveClick(this);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::mnuTraceClick(TObject *Sender)
{
     int i, nextgrid;
     double sum;
     AnsiString opstr, prmptstr, info;

     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a matrix.");
          return;
     }
     sum = 0.0;

     switch (CurrentGrid)
     {
        case 1 :
              for (i = 1; i < Grid1->ColCount; i++)
                  sum = sum + StrToFloat(Grid1->Cells[i][i]);
              Operand1Edit->Text = Obj1NameEdit->Text;
              nextgrid = 2;
              break;
        case 2 :
              for (i = 1; i < Grid2->ColCount; i++)
                  sum = sum + StrToFloat(Grid2->Cells[i][i]);
              Operand1Edit->Text = Obj2NameEdit->Text;
              nextgrid = 3;
              break;
        case 3 :
              for (i = 1; i < Grid3->ColCount; i++)
                  sum = sum + StrToFloat(Grid3->Cells[i][i]);
              Operand1Edit->Text = Obj3NameEdit->Text;
              nextgrid = 4;
              break;
        case 4 :
              for (i = 1; i < Grid4->ColCount; i++)
                  sum = sum + StrToFloat(Grid4->Cells[i][i]);
              Operand1Edit->Text = Obj4NameEdit->Text;
              nextgrid = 1;
              break;
     }

     // place results in next grid
     switch (nextgrid)
     {
        case 1 :
              Grid1->RowCount = 2;
              Grid1->ColCount = 2;
              Obj1NameEdit->Text = "Trace";
              Grid1->Cells[1][1] = FloatToStr(sum);
              CurrentObjName = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = 2;
              Grid2->ColCount = 2;
              Obj2NameEdit->Text = "Trace";
              Grid2->Cells[1][1] = FloatToStr(sum);
              CurrentObjName = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = 2;
              Grid3->ColCount = 2;
              Obj3NameEdit->Text = "Trace";
              Grid3->Cells[1][1] = FloatToStr(sum);
              CurrentObjName = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = 2;
              Grid4->ColCount = 2;
              Obj4NameEdit->Text = "Trace";
              Grid4->Cells[1][1] = FloatToStr(sum);
              CurrentObjName = Obj4NameEdit->Text;
              break;
     }

     OperationEdit->Text = "MatTrace";
     if (ScriptOp == false)
     {
          prmptstr = "Save trace as: ";
          info = InputBox("SAVE AS",prmptstr,"trace");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "trace";
               info = "trace";
          }
          switch (nextgrid)
          {
              case 1 : Obj1NameEdit->Text = info; break;
              case 2 : Obj2NameEdit->Text = info; break;
              case 3 : Obj3NameEdit->Text = info; break;
              case 4 : Obj4NameEdit->Text = info; break;
          }
          Operand1Edit->Text = IntToStr(CurrentGrid) + "-" + ExtractFileName(Operand1Edit->Text);
          opstr = IntToStr(CurrentGrid) + "-" + "MatTrace:" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(nextgrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 4;
          CurrentGrid = nextgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::RowVectorxMatrix1Click(TObject *Sender)
{
// premultiplication of a matrix by a row vector

     int i, j, k;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The row vector is in grid: ";
          info = InputBox("VECTOR GRID",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The post-matrix is in grid:";
          info = InputBox("POST MATRIX",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else
     { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }
     switch (pregrid)
     {  // row vector
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }
     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj4NameEdit->Text;
              break;
     }
     GetDblMatMem(prodmat,prerows,postcols);
     for (i = 0; i < prerows; i++)
     {
         for (j = 0; j < postcols; j++)
         {
             prodmat[i][j] = 0.0;
             for (k = 0; k < precols; k++)
                 prodmat[i][j] = prodmat[i][j] + (premat[i][k]*postmat[k][j]);
         }
     }
     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++)  Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++)  Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "Product";
              Operand3Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++)  Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++)  Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "Product";
              Operand3Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = postrows;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++)  Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++)  Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "Product";
              Operand3Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = postrows;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++)  Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++)  Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj4NameEdit->Text = "Product";
              Operand3Edit->Text = Obj4NameEdit->Text;
              break;
     }
     OperationEdit->Text = "PreVecxPostMat";
     if (ScriptOp == false)
     {
          prmptstr = "Save product as: ";
          info = InputBox("SAVE AS",prmptstr,"RowxMat");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "RowxMat";
               info = "RowxMat";
          }
          opstr = IntToStr(CurrentGrid) + "-";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          opstr = opstr + "PreVecxPostMat:" + IntToStr(pregrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(postgrid) + "-" + ExtractFileName(Operand2Edit->Text);
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + ExtractFileName(Operand3Edit->Text);
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 3;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch(resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalarxMatrix1Click(TObject *Sender)
{
// premultiplication of a matrix by a scaler
     int i, j;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The scalar is in grid: ";
          info = InputBox("SCALAR GRID",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The matrix is in grid: ";
          info = InputBox("MATRIX GRID",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }
     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }
     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }
     GetDblMatMem(prodmat,postrows,postcols);
     for (i = 0; i < postrows; i++)
         for (j = 0; j < postcols; j++)
                 prodmat[i][j] = premat[0][0]*postmat[i][j];
     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = postrows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = postrows;
              Cols1 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++)  Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "Product";
              break;
        case 2 :
              Grid2->RowCount = postrows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = postrows;
              Cols2 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++)  Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "Product";
              break;
        case 3 :
              Grid3->RowCount = postrows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = postrows;
              Cols3 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++)  Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "Product";
              break;
        case 4 :
              Grid4->RowCount = postrows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = postrows;
              Cols4 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++)  Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "Product";
              break;
     }
     OperationEdit->Text = "ScalerxPostMat";
     opstr = IntToStr(CurrentGrid) + "-";
     opstr = opstr + "ScalerxPostMat:" + IntToStr(pregrid) + "-" + Operand1Edit->Text;
     opstr = opstr + ":" + IntToStr(postgrid) + "-" + Operand2Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save product as: ";
          info = InputBox("SAVE AS",prmptstr,"ScalarxMat");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "ScalerxMat";
               info = "ScalarxMat";
          }
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 1;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,postrows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::mnuMatxColClick(TObject *Sender)
{
// postmultiplication of a matrix by a column vector
     int i, j, k;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "Multiply the pre-matrix in grid ";
          info = InputBox("PRE MATRIX",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "By the post-vector in grid ";
          info = InputBox("POST VECTOR",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }

     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }
     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }
     GetDblMatMem(prodmat,prerows,postcols);
     for (i = 0; i < prerows; i++)
     {
         for (j = 0; j < postcols; j++)
         {
             prodmat[i][j] = 0.0;
             for (k = 0; k < precols; k++)
                 prodmat[i][j] = prodmat[i][j] + (premat[i][k]*postmat[k][j]);
         }
     }
     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              break;
     }
     OperationEdit->Text = "PreMatxPostVec";
     if (ScriptOp == false)
     {
          prmptstr = "Save product vector as: ";
          info = InputBox("SAVE AS",prmptstr,"MatxVec");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else Operand3Edit->Text = "MatxVec";
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          Operand2Edit->Text = ExtractFileName(Operand2Edit->Text);
          opstr = IntToStr(CurrentGrid) + "-";
          opstr = opstr + "PreMatxPostVec:" + IntToStr(pregrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(postgrid) + "-" + Operand2Edit->Text;
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 2;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Add1Click(TObject *Sender)
{
// Addition of two matrices

     int i, j, k;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The First Matrix in grid: ";
          info = InputBox("MATRIX A",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The second Matrix is in grid: ";
          info = InputBox("MATRIX B",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }

     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     GetDblMatMem(prodmat,prerows,precols);
     for (i = 0; i < prerows; i++)
         for (j = 0; j < precols; j++)
                 prodmat[i][j] = premat[i][j] + postmat[i][j];

     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj4NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj4NameEdit->Text;
              break;
     }
     OperationEdit->Text = "MatPlusMat";
     opstr = IntToStr(CurrentGrid) + "-";
     opstr = opstr + "MatPlusMat:"+ IntToStr(pregrid) + "-" + Operand1Edit->Text;
     opstr = opstr + ":" + IntToStr(postgrid) + "-" + Operand2Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save sum as: ";
          info = InputBox("SAVE AS",prmptstr,"MatPlusMat");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "MatPlusMat";
               info = "MatPlusMat";
          }
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 1;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);

          switch (resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Subtract1Click(TObject *Sender)
{
// Subtraction of two matrices
     int i, j, k;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The First Matrix in grid: ";
          info = InputBox("MATRIX A",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The second Matrix is in grid: ";
          info = InputBox("MATRIX B",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }

     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj1NameEdit->Text);
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj2NameEdit->Text);
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj3NameEdit->Text);
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = ExtractFileName(Obj4NameEdit->Text);
              break;
     }

     GetDblMatMem(prodmat,prerows,precols);
     for (i = 0; i < prerows; i++)
         for (j = 0; j < precols; j++)
                 prodmat[i][j] = premat[i][j] - postmat[i][j];
     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = precols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj4NameEdit->Text = "MatrixSum";
              Operand3Edit->Text = Obj4NameEdit->Text;
              break;
     }
     OperationEdit->Text = "MatMinusMat";
     opstr = IntToStr(CurrentGrid) + "-" + "MatMinusMat:"+ IntToStr(pregrid) + "-" + Operand1Edit->Text;
     opstr = opstr + ":" + IntToStr(postgrid) + "-" + Operand2Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save difference as: ";
          info = InputBox("SAVE AS",prmptstr,"MatMinusMat");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "MatMinusMat";
               info = "MatMinusMat";
          }
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 1;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);

          switch (resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::GetGridData(int gridno)
{
     FILE *SaveFile;
     int i, j, Rows, Cols;
     AnsiString cellstring;
     AnsiString OpStr;
     AnsiString FName;
     char filename[121];

     if (OpenDialog1->Execute())
     {
          strcpy(filename,OpenDialog1->FileName.c_str());
          SaveFile = fopen(filename,"rt");
          fscanf(SaveFile,"%d",&CurrentObjType);
          fscanf(SaveFile,"%s",&filename);
          CurrentObjName = filename;
          CurrentObjName = ExtractFileName(CurrentObjName);
          fscanf(SaveFile,"%d",&Rows);
          fscanf(SaveFile,"%d",&Cols);
          GetDblMatMem(Matrix1,Rows,Cols);
          for (i = 1; i <= Rows; i++)
          {
               for (j = 1; j <= Cols; j++)
               {
                    fscanf(SaveFile,"%s",&filename);
                    cellstring = filename;
                    Matrix1[i-1][j-1] = StrToFloat(cellstring);
               }
          }
          fclose(SaveFile);
     }
     else return;

     switch (gridno)
     {
        case 1 :
              Obj1NameEdit->Text = CurrentObjName;
              Rows1 = Rows;
              Cols1 = Cols;
              Grid1->RowCount = Rows + 1;
              Grid1->ColCount = Cols + 1;
              for (i = 1; i <= Cols; i++)  Grid1->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows; i++)  Grid1->Cells[0][i] = "Row" + IntToStr(i);
              for (i = 1; i <= Rows; i++)
                  for (j = 1; j <= Cols; j++)
                      Grid1->Cells[j][i] = FloatToStr(Matrix1[i-1][j-1]);
              break;
        case 2 :
              Obj2NameEdit->Text = CurrentObjName;
              Rows2 = Rows;
              Cols2 = Cols;
              Grid2->RowCount = Rows + 1;
              Grid2->ColCount = Cols + 1;
              for (i = 1; i <= Cols; i++)  Grid2->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows; i++)  Grid2->Cells[0][i] = "Row" + IntToStr(i);
              for (i = 1; i <= Rows; i++)
                  for (j = 1; j <= Cols; j++)
                      Grid2->Cells[j][i] = FloatToStr(Matrix1[i-1][j-1]);
              break;
        case 3 :
              Obj3NameEdit->Text = CurrentObjName;
              Rows3 = Rows;
              Cols3 = Cols;
              Grid3->RowCount = Rows + 1;
              Grid3->ColCount = Cols + 1;
              for (i = 1; i <= Cols; i++)  Grid3->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows; i++)  Grid3->Cells[0][i] = "Row" + IntToStr(i);
              for (i = 1; i <= Rows; i++)
                  for (j = 1; j <= Cols; j++)
                      Grid3->Cells[j][i] = FloatToStr(Matrix1[i-1][j-1]);
              break;
        case 4 :
              Obj4NameEdit->Text = CurrentObjName;
              Rows4 = Rows;
              Cols4 = Cols;
              Grid4->RowCount = Rows + 1;
              Grid4->ColCount = Cols + 1;
              for (i = 1; i <= Cols; i++)  Grid4->Cells[i][0] = "Col."+ IntToStr(i);
              for (i = 1; i <= Rows; i++)  Grid4->Cells[0][i] = "Row" + IntToStr(i);
              for (i = 1; i <= Rows; i++)
                  for (j = 1; j <= Cols; j++)
                      Grid4->Cells[j][i] = FloatToStr(Matrix1[i-1][j-1]);
              break;
     }
     FName = ExtractFileName(CurrentObjName);
     ComboAdd(FName);

     if (ScriptOp == false)
     {
          FName = IntToStr(CurrentGrid) + "-" + FName;
          OpStr = IntToStr(CurrentGrid) + "-" + "FileOpen:" + FName;
          if (NoOpenChk->Checked == false) ScriptList->Items->Add(OpStr);
          OperationEdit->Text = "FileOpen";
          Operand1Edit->Text = CurrentObjName;
          Operand2Edit->Text = "";
          Operand3Edit->Text = "";
     }
     ClearDblMatMem(Matrix1,Rows);
     FmtCells(this);
}
//-------------------------------------------------------------------

int TMatManForm::OpParse(int &Opergrid, int &Op1grid, int &Op2grid,
                         int &Op3grid)
{
     int colonpos, dashpos;

     Operation = "";
     Op1 = "";
     Op2 = "";
     Op3 = "";
     colonpos = OpStr.AnsiPos(":");
     if (colonpos == 0)
     {
          ShowMessage("Operation code not found in a script entry.");
          return (0);
     }
     Operation = copy(OpStr,1,colonpos-1);
     OpStr = copy(OpStr,colonpos+1,OpStr.Length());
     colonpos = OpStr.AnsiPos(":");

     if (colonpos > 0) // more than one operand
     {
          Op1 = copy(OpStr,1,colonpos-1);
          OpStr = copy(OpStr,colonpos+1,OpStr.Length());
          colonpos = OpStr.AnsiPos(":");
          if (colonpos > 0) // more than two operands
          {
               Op2 = copy(OpStr,1,colonpos-1);
               Op3 = copy(OpStr,colonpos+1,OpStr.Length());
          }
          else Op2 = copy(OpStr,1,OpStr.Length());
     }
     else if (OpStr.Length() > 0) Op1 = OpStr;

     // Now, strip the grid number for each part (n-)
     // first, set defaults
     Opergrid = 0;
     Op1grid = 0;
     Op2grid = 0;
     Op3grid = 0;
     dashpos = Operation.AnsiPos("-");
     if (dashpos > 0)
     {
          Opergrid = StrToInt(copy(Operation,dashpos-1,1));
          Operation = copy(Operation,dashpos+1,Operation.Length());
     }
     dashpos = Op1.AnsiPos("-");
     if (dashpos > 0)
     {
          Op1grid = StrToInt(copy(Op1,dashpos-1,1));
          Op1 = copy(Op1,dashpos+1,Op1.Length());
     }

     dashpos = Op2.AnsiPos("-");
     if (dashpos > 0)
     {
          Op2grid = StrToInt(copy(Op2,dashpos-1,1));
          Op2 = copy(Op2,dashpos+1,Op2.Length());
     }

     dashpos = Op3.AnsiPos("-");
     if (dashpos > 0)
     {
          Op3grid = StrToInt(copy(Op3,dashpos-1,1));
          Op3 = copy(Op3,dashpos+3,Op3.Length());
     }

     OperationEdit->Text = Operation;
     Operand1Edit->Text = Op1;
     Operand2Edit->Text = Op2;
     Operand3Edit->Text = Op3;
     return(1);
}
//-------------------------------------------------------------------

void TMatManForm::OperExec(void)
{
     AnsiString prompt, response;
     FILE *SaveFile;

     if (Opergrid > 0) CurrentGrid = Opergrid;
     Operand1Edit->Text = "";
     Operand2Edit->Text = "";
     Operand3Edit->Text = "";

     if (Operation == "FileOpen")
     {
          if (Opergrid > 0) CurrentGrid = Opergrid;
          OpenDialog1->FileName = Op1;
          GetFile(this);
     }

     if (Operation == "FileSave")
     {
          if (Opergrid > 0) CurrentGrid = Opergrid;
          SaveDialog1->FileName = Op1;
          CurrentObjName = Op1;
          mnuSaveClick(this);
     }

     if (Operation == "KeyMatInput")
     {
          prompt = "Input data matrix for " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y") KeyMatClick(this);
     }

     if (Operation == "KeyVecInput")
     {
          prompt = "Input vector for " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y") KeyVectClick(this);
     }

     if (Operation == "KeyScalerInput")
     {
          prompt = "Input the scaler " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y") KeyScalarClick(this);
     }

     if (Operation == "RowAugment")
     {
          prompt = "Row augment the matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               RowAugment1Click(this);
          }
     }

     if (Operation == "ColAugment")
     {
          prompt = "Column augment the matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               ColumnAugment1Click(this);
          }
     }

     if (Operation == "DeleteRow")
     {
          prompt = "Delete matrix row in " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               mnuDelRowClick(this);
          }
     }

     if (Operation == "DeleteCol")
     {
          prompt = "Delete matrix column in " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               mnuDelColumnClick(this);
          }
     }

     if (Operation == "SVDInverse")
     {
          prompt = "Invert the matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               SVDInverse1Click(this);
          }
     }

     if (Operation == "PreMatxPostMat")
     {
          prompt = "Premultiply " + Op1 + " by " + Op2 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               CurrentObjType = 1;
               OpenDialog1->FileName = Op1;
               GetFile(this);
               CurrentGrid = 2;
               Operand2Edit->Text = Op2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               Operand3Edit->Text = Op3;
               MATxMATClick(this);
          }
     }

     if (Operation == "Tridiagonalize")
     {
          prompt = "Tridiagonalize the matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               Tridiagonalize1Click(this);
          }
     }

     if (Operation == "UpLowDecomp")
     {
          prompt = "Obtain upper and lower decompositon of " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               UpLowDecompClick(this);
          }
     }

     if (Operation == "DiagToVec")
     {
          prompt = "Copy diagonal of " + Op1 + " to vector " + Op2 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               DiagonaltoVector1Click(this);
          }
     }

     if (Operation == "Determinant")
     {
          prompt = "Obtain determinant of matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               Determinant1Click(this);
          }
     }

     if (Operation == "MatTranspose")
     {
          prompt = "Obtain transpose of matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               Transpose1Click(this);
          }
     }

     if (Operation == "MatrixRoots")
     {
          prompt = "Obtain eigenvalues and vectors of matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               EigensClick(this);
          }
     }

     if (Operation == "MatTrace")
     {
          prompt = "Obtain trace of matrix " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               mnuTraceClick(this);
          }
     }

     if (Operation == "NormalizeRows")
     {
          prompt = "Normalize rows of matrix " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               NormalizeRows1Click(this);
          }
     }

     if (Operation == "NormalizeCols")
     {
          prompt = "Normalize columns of matrix " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               NormalizeColumns1Click(this);
          }
     }

     if (Operation == "MatMinusMat")
     {
          prompt = "Subtract matrix " + Op2 + " from " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               CurrentGrid = 2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               Subtract1Click(this);
          }
     }

     if (Operation == "MatPlusMat")
     {
          prompt = "Add matrix " + Op1 + " to " + Op2 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               CurrentGrid = 2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               Add1Click(this);
          }
     }

     if (Operation == "PreVecxPostMat")
     {
          prompt = "Multiply matrix " + Op1 + " by row vector " + Op2 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op2;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 3;
               GetFile(this);
               CurrentGrid = 2;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               RowVectorxMatrix1Click(this);
          }
     }

     if (Operation == "ScalerxPostMat")
     {
          prompt = "Multiply scaler " + Op1 + " times matrix " + Op2 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 4;
               GetFile(this);
               CurrentGrid = 2;
               Operand2Edit->Text = Op2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               ScalarxMatrix1Click(this);
          }
     }

     if (Operation == "PreMatxPostVec")
     {
          prompt = "Multiply matrix " + Op1 + " by col.Vector " + Op2 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               CurrentObjType = 1;
               OpenDialog1->FileName = Op1;
               GetFile(this);
               CurrentGrid = 2;
               Operand2Edit->Text = Op2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 2;
               GetFile(this);
               mnuMatxColClick(this);
          }
     }

     if (Operation == "MatxPostMat")
     {
          prompt = "Multiply matrix " + Op1 + " by matrix " + Op2 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               CurrentGrid = 2;
               Operand2Edit->Text = Op2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               MATxMATClick(this);
          }
     }

     if (Operation == "VectorTranspose")
     {
          prompt = "Transpose vector " + Op1  + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               if (FileExists(Op1))
               {
                    SaveFile = fopen(Op1.c_str(),"r");
                    fread(&CurrentObjType,sizeof(CurrentObjType),1,SaveFile);
                    fclose(SaveFile);
               }
               GetFile(this);
               Transpose2Click(this);
          }
     }

     if (Operation == "ScalerxVector")
     {
          prompt = "Multiply vector " + Op2  + " by scaler " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op2;
               if (FileExists(Op2))
               {
                    SaveFile = fopen(Op2.c_str(),"r");
                    fread(&CurrentObjType,sizeof(CurrentObjType),1,SaveFile);
                    fclose(SaveFile);
               }
               CurrentGrid = 1;
               OpenDialog1->FileName = Op2;
               GetFile(this);
               Operand2Edit->Text = Op1;
               CurrentGrid = 2;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 4;
               GetFile(this);
               ScalarxVector1Click(this);
          }
     }

     if (Operation == "sqrtvector")
     {
          prompt = "Square root of elements in vector " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (FileExists(Op1))
               {
                    SaveFile = fopen(Op1.c_str(),"r");
                    fread(&CurrentObjType,sizeof(CurrentObjType),1,SaveFile);
                    fclose(SaveFile);
               }
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               GetFile(this);
               SquareRootofVector1Click(this);
          }
     }

     if (Operation == "VectorRecip")
     {
          prompt = "Recipricol of elements in vector " + Op1 + "?";
          response = InputBox("EXECUTE",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (FileExists(Op1))
               {
                    SaveFile = fopen(Op1.c_str(),"r");
                    fread(&CurrentObjType,sizeof(CurrentObjType),1,SaveFile);
                    fclose(SaveFile);
               }
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               GetFile(this);
               VectRecipsClick(this);
          }
     }

     if (Operation == "VecxVec")
     {
          prompt = "Multiply " + Op1 + " times " + Op2 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               if (ExtractFileExt(Op1) == ".CVE")
                  CurrentObjType = 2;
               else CurrentObjType = 3;
               GetFile(this);
               CurrentGrid = 2;
               Operand2Edit->Text = Op2;
               OpenDialog1->FileName = Op2;
               if (ExtractFileExt(Op2) == ".CVE")
                  CurrentObjType = 2;
               else CurrentObjType = 3;
               GetFile(this);
               Operand3Edit->Text = Op3;
               RvecxCvecClick(this);
          }
     }

     if (Operation == "SqrtScaler")
     {
          prompt = "Square root of scaler " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 4;
               GetFile(this);
               ScalerSqRtClick(this);
          }
     }

     if (Operation == "ScalerRecip")
     {
          prompt = "Recipricol of scaler " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 4;
               GetFile(this);
               ScalerRecipClick(this);
          }
     }

     if (Operation == "ScalerProd")
     {
          prompt = "Multiply " + Op1 + " by a value?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 4;
               GetFile(this);
               ScalerProdClick(this);
          }
     }

     if (Operation == "ExtractVector")
     {
          prompt = "Extract " + Op2 + " from " + Op1 + "?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               ExtractVectorClick(this);
          }
     }

     if (Operation == "VecToDiag")
     {
          prompt = "Place " + Op1 + " into diagonal of matrix" + Op2 +"?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               CurrentGrid = 1;
               OpenDialog1->FileName = Op1;
               if (ExtractFileExt(Op1) == ".CVE")
                  CurrentObjType = 2;
               else if (ExtractFileExt(Op1) == ".RVE")
                  CurrentObjType = 3;
               else return;
               GetFile(this);
               Operand2Edit->Text = Op2;
               CurrentGrid = 2;
               OpenDialog1->FileName = Op2;
               CurrentObjType = 1;
               GetFile(this);
               VectortoDiagonal1Click(this);
          }
     }

     if (Operation == "IDMAT")
     {
          prompt = "Create an Identity Matrix?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y") IDMatrixClick(this);
     }

     if (Operation == "SVDAnalysis")
     {
          prompt = "Decompose" + Op1 + "matrix into U, S and V ?";
          response = InputBox("EXECUTE?",prompt,"Y");
          if (response == "Y")
          {
               OperationEdit->Text = Operation;
               Operand1Edit->Text = Op1;
               if (Op1grid > 0) CurrentGrid = Op1grid;
               OpenDialog1->FileName = Op1;
               CurrentObjType = 1;
               GetFile(this);
               SVDUWVanalysis1Click(this);
          }
     }

     Operation = "";
}
//-------------------------------------------------------------------

void __fastcall TMatManForm::NormalizeRows1Click(TObject *Sender)
{
     int i, j;
     double sum;
     AnsiString opstr, prmptstr, info;

     switch (CurrentGrid)
     {
        case 1 :
           for (i = 1; i < Grid1->RowCount; i++)
           {
              sum = 0.0;
              for (j = 1; j < Grid1->ColCount; j++)
                   sum = sum + sqr(StrToFloat(Grid1->Cells[j][i]));
              sum = sqrt(sum);
              for (j = 1; j < Grid1->ColCount; j++)
                   Grid1->Cells[j][i] = FloatToStr(StrToFloat(Grid1->Cells[j][i]) / sum);
              Operand1Edit->Text = Obj1NameEdit->Text;
           }
           break;
        case 2 :
           for (i = 1; i < Grid2->RowCount; i++)
           {
              sum = 0.0;
              for (j = 1; j < Grid2->ColCount; j++)
                   sum = sum + sqr(StrToFloat(Grid2->Cells[j][i]));
              sum = sqrt(sum);
              for (j = 1; j < Grid2->ColCount; j++)
                   Grid2->Cells[j][i] = FloatToStr(StrToFloat(Grid2->Cells[j][i]) / sum);
              Operand1Edit->Text = Obj2NameEdit->Text;
           }
           break;
        case 3 :
           for (i = 1; i < Grid3->RowCount; i++)
           {
              sum = 0.0;
              for (j = 1; j < Grid3->ColCount; j++)
                   sum = sum + sqr(StrToFloat(Grid3->Cells[j][i]));
              sum = sqrt(sum);
              for (j = 1; j < Grid3->ColCount; j++)
                   Grid3->Cells[j][i] = FloatToStr(StrToFloat(Grid3->Cells[j][i]) / sum);
              Operand1Edit->Text = Obj3NameEdit->Text;
           }
           break;
        case 4 :
           for (i = 1; i < Grid4->RowCount; i++)
           {
              sum = 0.0;
              for (j = 1; j < Grid4->ColCount; j++)
                   sum = sum + sqr(StrToFloat(Grid4->Cells[j][i]));
              sum = sqrt(sum);
              for (j = 1; j < Grid4->ColCount; j++)
                   Grid4->Cells[j][i] = FloatToStr(StrToFloat(Grid4->Cells[j][i]) / sum);
              Operand1Edit->Text = Obj4NameEdit->Text;
           }
           break;
     }
     if (ScriptOp == false)
     {
          prmptstr = "Save normalized rows matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"RowNormMat");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "RowNormMat";
               info = "RowNormMat";
          }
         opstr = IntToStr(CurrentGrid) + "-";
         opstr = opstr + "NormalizeRows:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
         opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
         ScriptList->Items->Add(opstr);
         CurrentObjName = info;
         CurrentObjType = 1;
         ComboAdd(CurrentObjName);
         mnuSaveClick(this);

         switch (CurrentGrid)
         {
            case 1 : Obj1NameEdit->Text = info; break;
            case 2 : Obj2NameEdit->Text = info; break;
            case 3 : Obj3NameEdit->Text = info; break;
            case 4 : Obj4NameEdit->Text = info; break;
         }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Transpose2Click(TObject *Sender)
{
     int i, j, transgrid, vectype;
     AnsiString opstr, prmptstr, info;

     if (CurrentGrid == 0) return;
     if ((CurrentObjType == 1) || (CurrentObjType == 4))
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a vector.");
          return;
     }
     if (ScriptOp == true) CurrentGrid = 1;
     transgrid = CurrentGrid + 1;
     if (transgrid > 4) transgrid = 1;
     switch (CurrentGrid)
     {
        case 1 :
              Operand1Edit->Text = Obj1NameEdit->Text;
              // get type of resulting vector
              if (Rows1 == 1) vectype = 2;
              else vectype = 3;
              Grid2->RowCount = Grid1->ColCount;
              Grid2->ColCount = Grid1->RowCount;
              Rows2 = Grid2->RowCount-1;
              Cols2 = Grid2->ColCount-1;
              Obj2NameEdit->Text = "VectorTrans";
              for (i = 1; i <= Rows1; i++)
                  for (j = 1; j <= Cols1; j++)
                      Grid2->Cells[i][j] = Grid1->Cells[j][i];
              break;
        case 2 :
              Operand1Edit->Text = Obj2NameEdit->Text;
              if (Rows2 == 1) vectype = 2;
              else vectype = 3;
              Grid3->RowCount = Grid2->ColCount;
              Grid3->ColCount = Grid2->RowCount;
              Rows3 = Grid3->RowCount-1;
              Cols3 = Grid3->ColCount-1;
              Obj3NameEdit->Text = "VectorTrans";
              for (i = 1; i <= Rows2; i++)
                  for (j = 1; j <= Cols2; j++)
                      Grid3->Cells[i][j] = Grid2->Cells[j][i];
              break;
        case 3 :
              Operand1Edit->Text = Obj3NameEdit->Text;
              if (Rows3 == 1) vectype = 2;
              else vectype = 3;
              Grid4->RowCount = Grid3->ColCount;
              Grid4->ColCount = Grid3->RowCount;
              Rows4 = Grid4->RowCount-1;
              Cols4 = Grid4->ColCount-1;
              Obj4NameEdit->Text = "VectorTrans";
              for (i = 1; i <= Rows3; i++)
                  for (j = 1; j <= Cols3; j++)
                      Grid4->Cells[i][j] = Grid3->Cells[j][i];
              break;
        case 4 :
              Operand1Edit->Text = Obj4NameEdit->Text;
              if (Rows4 == 1) vectype = 2;
              else vectype = 3;
              Grid1->RowCount = Grid4->ColCount;
              Grid1->ColCount = Grid4->RowCount;
              Rows1 = Grid4->RowCount-1;
              Cols1 = Grid4->ColCount-1;
              Obj1NameEdit->Text = "VectorTrans";
              for (i = 1; i <= Rows4; i++)
                  for (j = 1; j <= Cols4; j++)
                      Grid1->Cells[i][j] = Grid4->Cells[j][i];
              break;
     }
     OperationEdit->Text = "Vec.Transpose";
     opstr = IntToStr(CurrentGrid) + "-" + "VectorTranspose:";
     opstr = opstr +  IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save vector transpose as: ";
          info = InputBox("SAVE AS",prmptstr,"VecTrans");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "VecTrans";
               info = "VecTrans";
          }
          opstr = opstr + ":" + IntToStr(transgrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = vectype;
          CurrentGrid = transgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (transgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalarxVector1Click(TObject *Sender)
{
     int i, j, vectype;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The scaler is in grid " + IntToStr(CurrentGrid);
          info = InputBox("SCALER",prmptstr,"2");
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The vector is in grid " + IntToStr(CurrentGrid);
          info = InputBox("VECTOR",prmptstr,"2");
          if (info == "") return;
          postgrid = StrToInt(info);
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }

     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }

     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              if (Cols1 > Rows1) vectype = 3;
              else vectype = 2;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              if (Cols2 > Rows2) vectype = 3;
              else vectype = 2;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              if (Cols3 > Rows3) vectype = 3;
              else vectype = 2;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              if (Cols4 > Rows4) vectype = 3;
              else vectype = 2;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj4NameEdit->Text;
              break;
     }
     GetDblMatMem(prodmat,postrows,postcols);
     for (i = 0; i < postrows; i++)
         for (j = 0; j < postcols; j++)
                 prodmat[i][j] = premat[0][0] * postmat[i][j];

     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = postrows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = postrows;
              Cols1 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "Product";
              Operand3Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              Grid2->RowCount = postrows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = postrows;
              Cols2 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "Product";
              Operand3Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              Grid3->RowCount = postrows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = postrows;
              Cols3 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "Product";
              Operand3Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              Grid4->RowCount = postrows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = postrows;
              Cols4 = postcols;
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj4NameEdit->Text = "Product";
              Operand3Edit->Text = Obj4NameEdit->Text;
              break;
     }
     OperationEdit->Text = "ScalerxVector";
     if (ScriptOp == false)
     {
          Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
          Operand2Edit->Text = ExtractFileName(Operand2Edit->Text);
          Operand3Edit->Text = ExtractFileName(Operand3Edit->Text);
          opstr = IntToStr(CurrentGrid) + "-";
          opstr = opstr + "ScalerxVector:" + IntToStr(pregrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(postgrid) + "-" + Operand2Edit->Text;
          prmptstr = "Save product as: ";
          info = InputBox("SAVE AS",prmptstr,"ScalerxVec");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "ScalerxVec";
               info = "ScalerxVec";
          }
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = vectype;
          CurrentGrid = resultgrid;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);

          switch (resultgrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
     // deallocate memory
     ClearDblMatMem(prodmat,postrows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::SquareRootofVector1Click(TObject *Sender)
{
     int vectype, i, j;
     AnsiString opstr, prmptstr, info, priorobjname;

     CurrentObjName = "sqrtvector";
     switch (CurrentGrid)
     {
        case 1 :
              priorobjname = Obj1NameEdit->Text;
              if (ExtractFileExt(priorobjname) == ".RVE") vectype = 3;
              else vectype = 2;
              for (i = 1; i <= Rows1; i++)
              {
                   for (j = 1; j <= Cols1; j++)
                   {
                        if (StrToFloat(Grid1->Cells[j][i]) < 0.0)
                           ShowMessage("ERROR - attempt to take root of a negative value!");
                        else
                            Grid1->Cells[j][i] = FloatToStr(sqrt(fabs(StrToFloat(Grid1->Cells[j][i]))));
                   }
              }
              Obj1NameEdit->Text = CurrentObjName;
              break;
        case 2 :
              priorobjname = Obj2NameEdit->Text;
              if (ExtractFileExt(priorobjname) == ".RVE") vectype = 3;
              else vectype = 2;
              for (i = 1; i <= Rows2; i++)
              {
                   for (j = 1; j <= Cols2; j++)
                   {
                        if (StrToFloat(Grid2->Cells[j][i]) < 0.0)
                           ShowMessage("ERROR - attempt to take root of a negative value!");
                        else
                            Grid2->Cells[j][i] = FloatToStr(sqrt(fabs(StrToFloat(Grid2->Cells[j][i]))));
                   }
              }
              Obj2NameEdit->Text = CurrentObjName;
              break;
        case 3 :
              priorobjname = Obj3NameEdit->Text;
              if (ExtractFileExt(priorobjname) == ".RVE") vectype = 3;
              else vectype = 2;
              for (i = 1; i <= Rows3; i++)
              {
                   for (j = 1; j <= Cols3; j++)
                   {
                        if (StrToFloat(Grid3->Cells[j][i]) < 0.0)
                           ShowMessage("ERROR - attempt to take root of a negative value!");
                        else
                            Grid3->Cells[j][i] = FloatToStr(sqrt(fabs(StrToFloat(Grid3->Cells[j][i]))));
                   }
              }
              Obj3NameEdit->Text = CurrentObjName;
              break;
        case 4 :
              priorobjname = Obj4NameEdit->Text;
              if (ExtractFileExt(priorobjname) == ".RVE") vectype = 3;
              else vectype = 2;
              for (i = 1; i <= Rows4; i++)
              {
                   for (j = 1; j <= Cols4; j++)
                   {
                        if (StrToFloat(Grid4->Cells[j][i]) < 0.0)
                           ShowMessage("ERROR - attempt to take root of a negative value!");
                        else
                            Grid4->Cells[j][i] = FloatToStr(sqrt(fabs(StrToFloat(Grid4->Cells[j][i]))));
                   }
              }
              Obj4NameEdit->Text = CurrentObjName;
              break;
     } // end switch

     if (ScriptOp == false)
     {
          prmptstr = "Save square root of vector as: ";
          info = InputBox("SAVE AS",prmptstr,"SqrtVec");
          if (info.Length() > 0) Operand2Edit->Text = ":" + IntToStr(CurrentGrid) + "-" + info;
          else  {
               Operand2Edit->Text = "SqrtVec";
               info = "SqrtVec";
          }
          opstr = IntToStr(CurrentGrid) + "-" + "sqrtvector:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + priorobjname;
          opstr = opstr + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = vectype;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);

          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::VectRecipsClick(TObject *Sender)
{
     int vectype, i, j;
     AnsiString opstr, prmptstr, info, priorobjname;

     CurrentObjName = "VectorRecips";
     switch (CurrentGrid)
     {
        case 1 :
              priorobjname = Obj1NameEdit->Text;
              if (Rows1 > Cols1) vectype = 2;
              else vectype = 3;
              for (i = 1; i <= Rows1; i++)
              {
                   for (j = 1; j <= Cols1; j++)
                   {
                        if (StrToFloat(Grid1->Cells[j][i]) == 0.0)
                           ShowMessage("ERROR - attempt to divide by zero!");
                        else
                            Grid1->Cells[j][i] = FloatToStr(1.0 /StrToFloat(Grid1->Cells[j][i]));
                   }
              }
              Obj1NameEdit->Text = CurrentObjName;
              break;
        case 2 :
              priorobjname = Obj2NameEdit->Text;
              if (Rows2 > Cols2) vectype = 2;
              else vectype = 3;
              for (i = 1; i <= Rows2; i++)
              {
                   for (j = 1; j <= Cols2; j++)
                   {
                        if (StrToFloat(Grid2->Cells[j][i]) == 0.0)
                           ShowMessage("ERROR - attempt to divide by zero!");
                        else
                            Grid2->Cells[j][i] = FloatToStr(1.0 /StrToFloat(Grid2->Cells[j][i]));
                   }
              }
              Obj2NameEdit->Text = CurrentObjName;
              break;
        case 3 :
              priorobjname = Obj3NameEdit->Text;
              if (Rows3 > Cols3) vectype = 2;
              else vectype = 3;
              for (i = 1; i <= Rows3; i++)
              {
                   for (j = 1; j <= Cols3; j++)
                   {
                        if (StrToFloat(Grid3->Cells[j][i]) == 0.0)
                           ShowMessage("ERROR - attempt to divide by zero!");
                        else
                            Grid3->Cells[j][i] = FloatToStr(1.0 /StrToFloat(Grid3->Cells[j][i]));
                   }
              }
              Obj3NameEdit->Text = CurrentObjName;
              break;
        case 4 :
              priorobjname = Obj4NameEdit->Text;
              if (Rows2 > Cols2) vectype = 2;
              else vectype = 3;
              for (i = 1; i <= Rows4; i++)
              {
                   for (j = 1; j <= Cols4; j++)
                   {
                        if (StrToFloat(Grid4->Cells[j][i]) == 0.0)
                           ShowMessage("ERROR - attempt to divide by zero!");
                        else
                            Grid4->Cells[j][i] = FloatToStr(1.0 /StrToFloat(Grid4->Cells[j][i]));
                   }
              }
              Obj4NameEdit->Text = CurrentObjName;
              break;
     } // end of switch

     if (ScriptOp == false)
     {
          opstr = IntToStr(CurrentGrid) + "-" + "VectorRecip:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + priorobjname;
          prmptstr = "Save recipricol of vector as: ";
          info = InputBox("SAVE AS",prmptstr,"VectorRecip");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "VectorRecip";
               info = "VectorRecip";
          }
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = vectype;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::RvecxCvecClick(TObject *Sender)
{
// premultiplication of a vector by another vector

     int i, j, k, resulttype;
     int precols, postcols, prerows, postrows;
     AnsiString info;
     int pregrid, postgrid, resultgrid;
     AnsiString prmptstr;
     double **premat, **postmat, **prodmat;
     AnsiString opstr;

     if (ScriptOp == false)
     {
          prmptstr = "The pre-vector is in grid: ";
          info = InputBox("PRE-VECTOR",prmptstr,IntToStr(CurrentGrid));
          if (info == "") return;
          pregrid = StrToInt(info);
          prmptstr = "The post-vector is in grid: ";
          info = InputBox("POST-VECTOR",prmptstr,IntToStr(CurrentGrid));
          postgrid = StrToInt(info);
          if (info == "") return;
          info = InputBox("RESULTS INTO","Place results in grid :","3");
          if (info == "") return;
          resultgrid = StrToInt(info);
     }
     else { // executing the script
          pregrid = 1;
          postgrid = 2;
          resultgrid = 3;
     }

     switch (pregrid)
     {
        case 1 :
              precols = Cols1;
              prerows = Rows1;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              precols = Cols2;
              prerows = Rows2;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              precols = Cols3;
              prerows = Rows3;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              precols = Cols4;
              prerows = Rows4;
              GetDblMatMem(premat,prerows,precols);
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < precols; j++)
                      premat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand1Edit->Text = Obj4NameEdit->Text;
              break;
     }

     switch (postgrid)
     {
        case 1 :
              postcols = Cols1;
              postrows = Rows1;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj1NameEdit->Text;
              break;
        case 2 :
              postcols = Cols2;
              postrows = Rows2;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj2NameEdit->Text;
              break;
        case 3 :
              postcols = Cols3;
              postrows = Rows3;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj3NameEdit->Text;
              break;
        case 4 :
              postcols = Cols4;
              postrows = Rows4;
              GetDblMatMem(postmat,postrows,postcols);
              for (i = 0; i < postrows; i++)
                  for (j = 0; j < postcols; j++)
                      postmat[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
              Operand2Edit->Text = Obj4NameEdit->Text;
              break;
     }
     GetDblMatMem(prodmat,prerows,postcols);
     if (prerows > 1) resulttype = 1;
     else resulttype = 4;
     for (i = 0; i < prerows; i++)
     {
         for (j = 0; j < postcols; j++)
         {
             prodmat[i][j] = 0.0;
             for (k = 0; k < precols; k++)
                 prodmat[i][j] = prodmat[i][j] + (premat[i][k] * postmat[k][j]);
         }
     }

     switch (resultgrid)
     {
        case 1 :
              Grid1->RowCount = prerows+1;
              Grid1->ColCount = postcols+1;
              Rows1 = prerows;
              Cols1 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid1->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
              Obj1NameEdit->Text = "Product";
              Operand3Edit->Text = Obj1NameEdit->Text;
              if (Rows1 == Cols1) CurrentObjType = 1;
              if (Rows1 > Cols1) CurrentObjType = 2;
              if (Cols1 > Rows1) CurrentObjType = 3;
              break;
        case 2 :
              Grid2->RowCount = prerows+1;
              Grid2->ColCount = postcols+1;
              Rows2 = prerows;
              Cols2 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid2->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
              Obj2NameEdit->Text = "Product";
              Operand3Edit->Text = Obj2NameEdit->Text;
              if (Rows2 == Cols2) CurrentObjType = 1;
              if (Rows2 > Cols2) CurrentObjType = 2;
              if (Cols2 > Rows2) CurrentObjType = 3;
              break;
        case 3 :
              Grid3->RowCount = prerows+1;
              Grid3->ColCount = postcols+1;
              Rows3 = prerows;
              Cols3 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid3->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
              Obj3NameEdit->Text = "Product";
              Operand3Edit->Text = Obj3NameEdit->Text;
              if (Rows3 == Cols3) CurrentObjType = 1;
              if (Rows3 > Cols3) CurrentObjType = 2;
              if (Cols3 > Rows3) CurrentObjType = 3;
              break;
        case 4 :
              Grid4->RowCount = prerows+1;
              Grid4->ColCount = postcols+1;
              Rows4 = prerows;
              Cols4 = postcols;
              for (i = 0; i < prerows; i++)
                  for (j = 0; j < postcols; j++)
                      Grid4->Cells[j+1][i+1] = prodmat[i][j];
              for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
              for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
              Obj4NameEdit->Text = "Product";
              Operand3Edit->Text = Obj4NameEdit->Text;
              if (Rows4 == Cols4) CurrentObjType = 1;
              if (Rows4 > Cols4) CurrentObjType = 2;
              if (Cols4 > Rows4) CurrentObjType = 3;
              break;
     }
     OperationEdit->Text = "VecxVec";
     opstr = IntToStr(CurrentGrid) + "-";
     Operand1Edit->Text = ExtractFileName(Operand1Edit->Text);
     Operand1Edit->Text = IntToStr(postgrid) + "-" + Operand1Edit->Text;
     opstr = opstr + "VecxVec:"+ Operand1Edit->Text;
     Operand2Edit->Text = ExtractFileName(Operand2Edit->Text);
     Operand2Edit->Text = IntToStr(pregrid) + "-" + Operand2Edit->Text;
     opstr = opstr + ":" + Operand2Edit->Text;
     if (ScriptOp == false)
     {
          prmptstr = "Save product as: ";
          info = InputBox("SAVE AS",prmptstr,"VectorProd");
          if (info.Length() > 0) Operand3Edit->Text = info;
          else  {
               Operand3Edit->Text = "VectorProd";
               info = "VectorProd";
          }
          opstr = opstr + ":" + IntToStr(resultgrid) + "-" + Operand3Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = resulttype;
          ComboAdd(CurrentObjName);
          CurrentGrid = resultgrid;
          mnuSaveClick(this);
     }
     // deallocate memory
     ClearDblMatMem(prodmat,prerows);
     ClearDblMatMem(postmat,postrows);
     ClearDblMatMem(premat,prerows);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ColumnVectorxRowVector1Click(TObject *Sender)
{
     RvecxCvecClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalerSqRtClick(TObject *Sender)
{
     AnsiString opstr, prmptstr, info;

     OperationEdit->Text = "SqrtScalar";
     switch (CurrentGrid)
     {
        case 1 :
               if (StrToFloat(Grid1->Cells[1][1]) < 0.0)
               {
                  ShowMessage("Attempt to take square root of a negative value.");
                  return;
               }
               else Grid1->Cells[1][1] = FloatToStr(sqrt(StrToFloat(Grid1->Cells[1][1])));
               Operand1Edit->Text = Obj1NameEdit->Text;
               Obj1NameEdit->Text = "SqrtScaler";
               break;
        case 2 :
               if (StrToFloat(Grid2->Cells[1][1]) < 0.0)
               {
                  ShowMessage("Attempt to take square root of a negative value.");
                  return;
               }
               else Grid2->Cells[1][1] = FloatToStr(sqrt(StrToFloat(Grid2->Cells[1][1])));
               Operand1Edit->Text = Obj2NameEdit->Text;
               Obj2NameEdit->Text = "SqrtScaler";
               break;
        case 3 :
               if (StrToFloat(Grid3->Cells[1][1]) < 0.0)
               {
                  ShowMessage("Attempt to take square root of a negative value.");
                  return;
               }
               else Grid3->Cells[1][1] = FloatToStr(sqrt(StrToFloat(Grid3->Cells[1][1])));
               Operand1Edit->Text = Obj3NameEdit->Text;
               Obj3NameEdit->Text = "SqrtScaler";
               break;
        case 4 :
               if (StrToFloat(Grid4->Cells[1][1]) < 0.0)
               {
                  ShowMessage("Attempt to take square root of a negative value.");
                  return;
               }
               else Grid4->Cells[1][1] = FloatToStr(sqrt(StrToFloat(Grid4->Cells[1][1])));
               Operand1Edit->Text = Obj4NameEdit->Text;
               Obj4NameEdit->Text = "SqrtScaler";
               break;
     }
     if (ScriptOp == false)
     {
          prmptstr = "Save scalar square root as: ";
          info = InputBox("SAVE AS",prmptstr,"SqrtScalar");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "SqrtScalar";
               info = "SqrtScaler";
          }
          opstr = IntToStr(CurrentGrid) + "-" + "SqrtScaler:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 4;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);

          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalerRecipClick(TObject *Sender)
{
     AnsiString opstr, prmptstr, info;

     OperationEdit->Text = "ScalerRecip";
     switch (CurrentGrid)
     {
        case 1 :
               if (StrToFloat(Grid1->Cells[1][1]) == 0.0)
               {
                  ShowMessage("Attempt to divide by zero.");
                  return;
               }
               Grid1->Cells[1][1] = FloatToStr(1.0 / StrToFloat(Grid1->Cells[1][1]));
               Operand1Edit->Text = Obj1NameEdit->Text;
               Obj1NameEdit->Text = "ScalerRecip";
               Operand2Edit->Text = Obj1NameEdit->Text;
               CurrentObjName = Obj1NameEdit->Text;
               break;
        case 2 :
               if (StrToFloat(Grid2->Cells[1][1]) == 0.0)
               {
                  ShowMessage("Attempt to divide by zero.");
                  return;
               }
               Grid2->Cells[1][1] = FloatToStr(1.0 / StrToFloat(Grid2->Cells[1][1]));
               Operand1Edit->Text = Obj2NameEdit->Text;
               Obj2NameEdit->Text = "ScalerRecip";
               Operand2Edit->Text = Obj2NameEdit->Text;
               CurrentObjName = Obj2NameEdit->Text;
               break;
        case 3 :
               if (StrToFloat(Grid3->Cells[1][1]) == 0.0)
               {
                  ShowMessage("Attempt to divide by zero.");
                  return;
               }
               Grid3->Cells[1][1] = FloatToStr(1.0 / StrToFloat(Grid3->Cells[1][1]));
               Operand1Edit->Text = Obj3NameEdit->Text;
               Obj3NameEdit->Text = "ScalerRecip";
               Operand2Edit->Text = Obj3NameEdit->Text;
               CurrentObjName = Obj3NameEdit->Text;
               break;
        case 4 :
               if (StrToFloat(Grid4->Cells[1][1]) == 0.0)
               {
                  ShowMessage("Attempt to divide by zero.");
                  return;
               }
               Grid4->Cells[1][1] = FloatToStr(1.0 / StrToFloat(Grid4->Cells[1][1]));
               Operand1Edit->Text = Obj4NameEdit->Text;
               Obj4NameEdit->Text = "ScalerRecip";
               Operand2Edit->Text = Obj4NameEdit->Text;
               CurrentObjName = Obj4NameEdit->Text;
               break;
     }
     if (ScriptOp == false)
     {
          opstr = IntToStr(CurrentGrid) + "-" + "ScalerRecip:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          prmptstr = "Save reciprocal of scaler as: ";
          info = InputBox("SAVE AS",prmptstr,"ScalarRecip");
          if (info.Length() > 0) Operand2Edit->Text = info;
          else  {
               Operand2Edit->Text = "ScalarRecip";
               info = "ScalarRecip";
          }
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 4;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalerProdClick(TObject *Sender)
{
     double multiplier;
     AnsiString prmptstr, info, opstr;

     prmptstr = "Multiply the scalar by " ;
     info = InputBox("MULTIPLY BY ",prmptstr,"");
     if (info == "") return;
     multiplier = StrToFloat(info);
     OperationEdit->Text = "ScalarxScalar";
     switch (CurrentGrid)
     {
        case 1 :
              Operand1Edit->Text = Obj1NameEdit->Text;
              Grid1->Cells[1][1] = FloatToStr(StrToFloat(Grid1->Cells[1][1]) * multiplier);
              Obj1NameEdit->Text = "ScalarProd";
              break;
        case 2 :
              Operand1Edit->Text = Obj2NameEdit->Text;
              Grid2->Cells[1][1] = FloatToStr(StrToFloat(Grid2->Cells[1][1]) * multiplier);
              Obj2NameEdit->Text = "ScalarProd";
              break;
        case 3 :
              Operand1Edit->Text = Obj3NameEdit->Text;
              Grid3->Cells[1][1] = FloatToStr(StrToFloat(Grid3->Cells[1][1]) * multiplier);
              Obj3NameEdit->Text = "ScalarProd";
              break;
        case 4 :
              Operand1Edit->Text = Obj4NameEdit->Text;
              Grid4->Cells[1][1] = FloatToStr(StrToFloat(Grid4->Cells[1][1]) * multiplier);
              Obj4NameEdit->Text = "ScalarProd";
              break;
     }

     if (ScriptOp == false)
     {
          prmptstr = "Save product of scalars as: ";
          info = InputBox("SAVE AS",prmptstr,"ScalarProd");
          if (info.Length() > 0) Operand2Edit->Text = ":" + IntToStr(CurrentGrid) + "-" + info;
          else  {
               Operand2Edit->Text = "ScalarProd";
               info = "ScalarProd";
          }
          opstr = IntToStr(CurrentGrid) + "-" + "ScalerProd:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(CurrentGrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentObjName = info;
          CurrentObjType = 4;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          switch (CurrentGrid)
          {
             case 1 : Obj1NameEdit->Text = info; break;
             case 2 : Obj2NameEdit->Text = info; break;
             case 3 : Obj3NameEdit->Text = info; break;
             case 4 : Obj4NameEdit->Text = info; break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Print3Click(TObject *Sender)
{
     int i;

     if (ScriptList->Items->Count == 0) return;
     FrmOutPut->RichOutPut->Lines->Add("CURRENT LISTING FOR SCRIPT " + ScriptName);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 0; i < ScriptList->Items->Count; i++)
          FrmOutPut->RichOutPut->Lines->Add(ScriptList->Items->Strings[i]);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Edit1Click(TObject *Sender)
{
     int count, i;

     count = ScriptList->Items->Count;
     FrmScriptEditor->ScriptList->Clear();
     for (i = 0; i < count; i++) FrmScriptEditor->ScriptList->Items->Add(ScriptList->Items->Strings[i]);
     FrmScriptEditor->ShowModal();

}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ExtractVectorClick(TObject *Sender)
{
     int i, excol, togrid;
     AnsiString prmptstr, info, opstr, collabel;

     switch (CurrentGrid)
     {
        case 1 :
              Operand1Edit->Text = Obj1NameEdit->Text;
              excol = Grid1->Col;
              prmptstr = "Extract which column (1 - " + IntToStr(excol) + ")?";
              info = InputBox("EXTRACT",prmptstr,IntToStr(excol));
              excol = StrToInt(info);
              collabel = Grid1->Cells[excol][0];
              prmptstr = "Place vector into grid ";
              info = InputBox("GRID?",prmptstr,"2");
              togrid = StrToInt(info);
              for (i = 1; i <= Rows1; i++)
              {
                   switch (togrid)
                   {
                      case 2 : Grid2->Cells[1][i] = Grid1->Cells[excol][i]; break;
                      case 3 : Grid3->Cells[1][i] = Grid1->Cells[excol][i]; break;
                      case 4 : Grid4->Cells[1][i] = Grid1->Cells[excol][i]; break;
                   }
              }
              switch (togrid)
              {
                 case 2 :
                       Grid2->Cells[1][0] = collabel;
                       Grid2->RowCount = Grid1->RowCount;
                       Rows2 = Grid2->RowCount - 1;
                       Grid2->ColCount = 2;
                       Cols2 = 1;
                       Obj2NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 3 :
                       Grid3->Cells[1][0] = collabel;
                       Grid3->RowCount = Grid1->RowCount;
                       Rows3 = Grid3->RowCount - 1;
                       Grid3->ColCount = 2;
                       Cols3 = 1;
                       Obj3NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 4 :
                       Grid4->Cells[1][0] = collabel;
                       Grid4->RowCount = Grid1->RowCount;
                       Rows4 = Grid4->RowCount - 1;
                       Grid4->ColCount = 2;
                       Cols4 = 1;
                       Obj4NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Case" + IntToStr(i);
                       break;
              } // end switch togrid
              break; // end case currentgrid = 1
        case 2 :
              Operand1Edit->Text = Obj2NameEdit->Text;
              excol = Grid2->Col;
              prmptstr = "Extract which column (1 - " + IntToStr(excol) + ")?";
              info = InputBox("EXTRACT",prmptstr,IntToStr(excol));
              excol = StrToInt(info);
              collabel = Grid2->Cells[excol][0];
              prmptstr = "Place vector into grid ";
              info = InputBox("GRID?",prmptstr,"3");
              togrid = StrToInt(info);
              for (i = 1; i <= Rows2; i++)
              {
                   switch (togrid)
                   {
                      case 3 : Grid3->Cells[1][i] = Grid2->Cells[excol][i]; break;
                      case 4 : Grid4->Cells[1][i] = Grid2->Cells[excol][i]; break;
                      case 1 : Grid1->Cells[1][i] = Grid2->Cells[excol][i]; break;
                   }
              }
              switch (togrid)
              {
                 case 3 :
                       Grid3->Cells[1][0] = collabel;
                       Grid3->RowCount = Grid2->RowCount;
                       Rows3 = Grid3->RowCount - 1;
                       Grid3->ColCount = 2;
                       Cols3 = 1;
                       Obj3NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 4 :
                       Grid4->Cells[1][0] = collabel;
                       Grid4->RowCount = Grid2->RowCount;
                       Rows4 = Grid4->RowCount - 1;
                       Grid4->ColCount = 2;
                       Cols4 = 1;
                       Obj4NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 1 :
                       Grid1->Cells[1][0] = collabel;
                       Grid1->RowCount = Grid2->RowCount;
                       Rows1 = Grid1->RowCount - 1;
                       Grid1->ColCount = 2;
                       Cols1 = 1;
                       Obj1NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Case" + IntToStr(i);
                       break;
              } // end togrid
              break;
        case 3 :
              Operand1Edit->Text = Obj3NameEdit->Text;
              excol = Grid3->Col;
              prmptstr = "Extract which column (1 - " + IntToStr(excol) + ")?";
              info = InputBox("EXTRACT",prmptstr,IntToStr(excol));
              excol = StrToInt(info);
              collabel = Grid3->Cells[excol][0];
              prmptstr = "Place vector into grid ";
              info = InputBox("GRID?",prmptstr,"4");
              togrid = StrToInt(info);
              for (i = 1; i <= Rows3; i++)
              {
                   switch (togrid)
                   {
                      case 4 : Grid4->Cells[1][i] = Grid3->Cells[excol][i]; break;
                      case 1 : Grid1->Cells[1][i] = Grid3->Cells[excol][i]; break;
                      case 2 : Grid2->Cells[1][i] = Grid3->Cells[excol][i]; break;
                   }
              }
              switch (togrid)
              {
                 case 4 :
                       Grid4->Cells[1][0] = collabel;
                       Grid4->RowCount = Grid3->RowCount;
                       Rows4 = Grid4->RowCount - 1;
                       Grid4->ColCount = 2;
                       Cols4 = 1;
                       Obj4NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 1 :
                       Grid1->Cells[1][0] = collabel;
                       Grid1->RowCount = Grid3->RowCount;
                       Rows1 = Grid1->RowCount - 1;
                       Grid1->ColCount = 2;
                       Cols1 = 1;
                       Obj1NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 2 :
                       Grid2->Cells[1][0] = collabel;
                       Grid2->RowCount = Grid3->RowCount;
                       Rows2 = Grid2->RowCount - 1;
                       Grid2->ColCount = 2;
                       Cols2 = 1;
                       Obj2NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Case" + IntToStr(i);
                       break;
              }
              break;
        case 4 :
              Operand1Edit->Text = Obj4NameEdit->Text;
              excol = Grid4->Col;
              prmptstr = "Extract which column (1 - " + IntToStr(excol) + ")?";
              info = InputBox("EXTRACT",prmptstr,IntToStr(excol));
              excol = StrToInt(info);
              collabel = Grid4->Cells[excol][0];
              prmptstr = "Place vector into grid ";
              info = InputBox("GRID?",prmptstr,"1");
              togrid = StrToInt(info);
              for (i = 1; i <= Rows4; i++)
              {
                   switch (togrid)
                   {
                      case 1 : Grid1->Cells[1][i] = Grid4->Cells[excol][i]; break;
                      case 2 : Grid2->Cells[1][i] = Grid4->Cells[excol][i]; break;
                      case 3 : Grid3->Cells[1][i] = Grid4->Cells[excol][i]; break;
                   }
              }
              switch (togrid)
              {
                 case 1 :
                       Grid1->Cells[1][0] = collabel;
                       Grid1->RowCount = Grid4->RowCount;
                       Rows1 = Grid1->RowCount - 1;
                       Grid1->ColCount = 2;
                       Cols1 = 1;
                       Obj1NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 2 :
                       Grid2->Cells[1][0] = collabel;
                       Grid2->RowCount = Grid4->RowCount;
                       Rows2 = Grid2->RowCount - 1;
                       Grid2->ColCount = 2;
                       Cols2 = 1;
                       Obj2NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Case" + IntToStr(i);
                       break;
                 case 3 :
                       Grid3->Cells[1][0] = collabel;
                       Grid3->RowCount = Grid4->RowCount;
                       Rows3 = Grid3->RowCount - 1;
                       Grid3->ColCount = 2;
                       Cols3 = 1;
                       Obj3NameEdit->Text = "ExtractVec";
                       Operand2Edit->Text = "ExtractVec";
                       for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Case" + IntToStr(i);
                       break;
              } // end switch togrid = 3
              break;
     } // end switch currentgrid
     mnuDelColumnClick(this);

     if (ScriptOp == false)
     {
          prmptstr = "Save Extracted vector as ";
          info = InputBox("VECTOR NAME",prmptstr,"ExtractVector");
          if (info.Length() > 0) Operand2Edit->Text = info;
          opstr = IntToStr(CurrentGrid) + "-" + "ExtractVector:";
          opstr = opstr + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(togrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentGrid = togrid;
          CurrentObjName = Operand2Edit->Text;
          CurrentObjType = 2; // column vector
          mnuSaveClick(this);
          ComboAdd(CurrentObjName);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     int i, j;

     if (Button == mbRight) // reset the grid
     {
          for (i = 1; i <= Rows1; i++)
              for (j = 1; j <= Cols1; j++)
                  Grid1->Cells[j][i] = "";
          for (i = 1; i <= 4; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
          for (i = 1; i <= 4; i++) Grid1->Cells[0][i] = "Row" + IntToStr(i);
          Rows1 = 4;
          Cols1 = 4;
          Grid1->RowCount = 5;
          Grid1->ColCount = 5;
          Obj1NameEdit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid2MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     int i, j;

     if (Button == mbRight) // reset the grid
     {
          for (i = 1; i <= Rows2; i++)
              for (j = 1; j <= Cols2; j++)
                  Grid2->Cells[j][i] = "";
          for (i = 1; i <= 4; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
          for (i = 1; i <= 4; i++) Grid2->Cells[0][i] = "Row" + IntToStr(i);
          Rows2 = 4;
          Cols2 = 4;
          Grid2->RowCount = 5;
          Grid2->ColCount = 5;
          Obj2NameEdit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid3MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     int i, j;

     if (Button == mbRight) // reset the grid
     {
          for (i = 1; i <= Rows3; i++)
              for (j = 1; j <= Cols3; j++)
                  Grid3->Cells[j][i] = "";
          for (i = 1; i <= 4; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
          for (i = 1; i <= 4; i++) Grid3->Cells[0][i] = "Row" + IntToStr(i);
          Rows3 = 4;
          Cols3 = 4;
          Grid3->RowCount = 5;
          Grid3->ColCount = 5;
          Obj3NameEdit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid4MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     int i, j;

     if (Button == mbRight) // reset the grid
     {
          for (i = 1; i <= Rows4; i++)
              for (j = 1; j <= Cols4; j++)
                  Grid4->Cells[j][i] = "";
          for (i = 1; i <= 4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
          for (i = 1; i <= 4; i++) Grid4->Cells[0][i] = "Row" + IntToStr(i);
          Rows4 = 4;
          Cols4 = 4;
          Grid4->RowCount = 5;
          Grid4->ColCount = 5;
          Obj4NameEdit->Text = "";
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::About1Click(TObject *Sender)
{
     ShowMessage("Copyright 2002 by Bill Miller");
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Contents1Click(TObject *Sender)
{
       Application->MessageBox("See the OpenStat Reference Manual","Manual",MB_OKCANCEL);
//     Application->HelpFile = "MATMAN.HLP";
//     Application->HelpJump("IDH_001");
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::InsertaRow1Click(TObject *Sender)
{
   int insrow, insgrid, i, j, showresult;
   bool before;
   AnsiString response;

   insgrid = CurrentGrid;
   switch (CurrentGrid)
   {
      case 1: insrow = Grid1->Row; break;
      case 2: insrow = Grid2->Row; break;
      case 3: insrow = Grid3->Row; break;
      case 4: insrow = Grid4->Row; break;
   }
   response = InputBox("WHERE","Before(B) or after(A) the currently selected row?","B");
   if (response == "B") before = true;
   else before = false;
   switch (insgrid)
   {
        case 1 :
                 Grid1->RowCount = Grid1->RowCount + 1;
                 if (before)
                 { // insert a row before insrow
                       for (i = Rows1; i >= insrow-1; i--)
                           for (j = 1; j <= Cols1; j++)
                               Grid1->Cells[j][i+1] = Grid1->Cells[j][i];
                       if (insrow > 1)
                          for (j = 1; j <= Cols1; j++) Grid1->Cells[j][insrow-1] = "";
                       else for (j = 1; j <= Cols1; j++) Grid1->Cells[j][1] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Rows1; i >= insrow+1; i--)
                           for (j = 1; j <= Cols1; j++)
                               Grid1->Cells[j][i+1] = Grid1->Cells[j][i];
                       for (j = 1; j <= Cols1; j++) Grid1->Cells[j][insrow+1] = "";
                 }
                 Rows1 = Rows1 + 1;
                 for (i = 1; i <= Rows1; i++) Grid1->Cells[0][i] = "Row " + IntToStr(i);
                 break; // end case grid 1
        case 2 :
                 Grid2->RowCount = Grid2->RowCount + 1;
                 if (before)
                 { // insert a row before insrow
                       for (i = Rows2; i >= insrow-1; i--)
                           for (j = 1; j <= Cols2; j++)
                               Grid2->Cells[j][i+1] = Grid2->Cells[j][i];
                       if (insrow > 1)
                          for (j = 1; j <= Cols2; j++) Grid2->Cells[j][insrow-1] = "";
                       else for (j = 1; j <= Cols2; j++) Grid2->Cells[j][1] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Rows2; i >= insrow+1; i--)
                           for (j = 1; j <= Cols2; j++)
                               Grid2->Cells[j][i+1] = Grid2->Cells[j][i];
                       for (j = 1; j <= Cols2; j++) Grid2->Cells[j][insrow+1] = "";
                 }
                 Rows2 = Rows2 + 1;
                 for (i = 1; i <= Rows2; i++) Grid2->Cells[0][i] = "Row " + IntToStr(i);
                 break; // end case grid 2
        case 3 :
                 Grid3->RowCount = Grid3->RowCount + 1;
                 if (before)
                 { // insert a row before insrow
                       for (i = Rows3; i >= insrow-1; i--)
                           for (j = 1; j <= Cols3; j++)
                               Grid3->Cells[j][i+1] = Grid3->Cells[j][i];
                       if (insrow > 1)
                          for (j = 1; j <= Cols3; j++) Grid3->Cells[j][insrow-1] = "";
                       else for (j = 1; j <= Cols3; j++) Grid3->Cells[j][1] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Rows3; i >= insrow+1; i--)
                           for (j = 1; j <= Cols3; j++)
                               Grid3->Cells[j][i+1] = Grid3->Cells[j][i];
                       for (j = 1; j <= Cols3; j++) Grid3->Cells[j][insrow+1] = "";
                 }
                 Rows3 = Rows3 + 1;
                 for (i = 1; i <= Rows3; i++) Grid3->Cells[0][i] = "Row " + IntToStr(i);
                 break; // end case grid 1
        case 4 :
                 Grid4->RowCount = Grid4->RowCount + 1;
                 if (before)
                 { // insert a row before insrow
                       for (i = Rows4; i >= insrow-1; i--)
                           for (j = 1; j <= Cols4; j++)
                               Grid4->Cells[j][i+1] = Grid4->Cells[j][i];
                       if (insrow > 1)
                          for (j = 1; j <= Cols4; j++) Grid4->Cells[j][insrow-1] = "";
                       else for (j = 1; j <= Cols4; j++) Grid4->Cells[j][1] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Rows4; i >= insrow+1; i--)
                           for (j = 1; j <= Cols4; j++)
                               Grid4->Cells[j][i+1] = Grid4->Cells[j][i];
                       for (j = 1; j <= Cols4; j++) Grid4->Cells[j][insrow+1] = "";
                 }
                 Rows4 = Rows4 + 1;
                 for (i = 1; i <= Rows4; i++) Grid4->Cells[0][i] = "Row " + IntToStr(i);
                 break; // end case grid 1
   } // end switch insgrid
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::InsertaColumn1Click(TObject *Sender)
{
   int inscol, insgrid, i, j, showresult;
   bool before;
   AnsiString response;

   insgrid = CurrentGrid;
   switch (CurrentGrid)
   {
      case 1: inscol = Grid1->Col; break;
      case 2: inscol = Grid2->Col; break;
      case 3: inscol = Grid3->Col; break;
      case 4: inscol = Grid4->Col; break;
   }
   response = InputBox("WHERE","Before(B) or after(A) the currently selected column?","B");
   if (response == "B") before = true;
   else before = false;

   switch (insgrid)
   {
        case 1 :
                 Grid1->ColCount = Grid1->ColCount + 1;
                 if (before)
                 { // insert a column before inscol
                       for (i = Cols1; i >= inscol-1; i--)
                           for (j = 1; j <= Rows1; j++)
                               Grid1->Cells[i+1][j] = Grid1->Cells[i][j];
                       if (inscol > 1)
                          for (j = 1; j <= Rows1; j++) Grid1->Cells[inscol-1][j] = "";
                       else for (j = 1; j <= Rows1; j++) Grid1->Cells[1][j] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Cols1; i >= inscol+1; i--)
                           for (j = 1; j <= Rows1; j++)
                               Grid1->Cells[i+1][j] = Grid1->Cells[i][j];
                       for (j = 1; j <= Rows1; j++) Grid1->Cells[inscol+1][j] = "";
                 }
                 Cols1 = Cols1 + 1;
                 for (i = 1; i <= Cols1; i++) Grid1->Cells[i][0] = "Col." + IntToStr(i);
                 break; // end case grid 1
        case 2 :
                 Grid2->ColCount = Grid2->ColCount + 1;
                 if (before)
                 { // insert a column before inscol
                       for (i = Cols2; i >= inscol-1; i--)
                           for (j = 1; j <= Rows2; j++)
                               Grid2->Cells[i+1][j] = Grid2->Cells[i][j];
                       if (inscol > 1)
                          for (j = 1; j <= Rows2; j++) Grid2->Cells[inscol-1][j] = "";
                       else for (j = 1; j <= Rows2; j++) Grid2->Cells[1][j] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Cols2; i >= inscol+1; i--)
                           for (j = 1; j <= Rows2; j++)
                               Grid2->Cells[i+1][j] = Grid2->Cells[i][j];
                       for (j = 1; j <= Rows2; j++) Grid2->Cells[inscol+1][j] = "";
                 }
                 Cols2 = Cols2 + 1;
                 for (i = 1; i <= Cols2; i++) Grid2->Cells[i][0] = "Col." + IntToStr(i);
                 break; // end case grid 2
        case 3 :
                 Grid3->ColCount = Grid3->ColCount + 1;
                 if (before)
                 { // insert a column before inscol
                       for (i = Cols3; i >= inscol-1; i--)
                           for (j = 1; j <= Rows3; j++)
                               Grid3->Cells[i+1][j] = Grid3->Cells[i][j];
                       if (inscol > 1)
                          for (j = 1; j <= Rows3; j++) Grid3->Cells[inscol-1][j] = "";
                       else for (j = 1; j <= Rows3; j++) Grid3->Cells[1][j] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Cols3; i >= inscol+1; i--)
                           for (j = 1; j <= Rows3; j++)
                               Grid3->Cells[i+1][j] = Grid3->Cells[i][j];
                       for (j = 1; j <= Rows3; j++) Grid3->Cells[inscol+1][j] = "";
                 }
                 Cols3 = Cols3 + 1;
                 for (i = 1; i <= Cols3; i++) Grid3->Cells[i][0] = "Col." + IntToStr(i);
                 break; // end case grid 33
        case 4 :
                 Grid4->ColCount = Grid4->ColCount + 1;
                 if (before)
                 { // insert a column before inscol
                       for (i = Cols4; i >= inscol-1; i--)
                           for (j = 1; j <= Rows4; j++)
                               Grid4->Cells[i+1][j] = Grid4->Cells[i][j];
                       if (inscol > 1)
                          for (j = 1; j <= Rows4; j++) Grid4->Cells[inscol-1][j] = "";
                       else for (j = 1; j <= Rows4; j++) Grid4->Cells[1][j] = "";
                 }
                 else { // insert a row after insrow
                       for (i = Cols4; i >= inscol+1; i--)
                           for (j = 1; j <= Rows4; j++)
                               Grid4->Cells[i+1][j] = Grid4->Cells[i][j];
                       for (j = 1; j <= Rows4; j++) Grid4->Cells[inscol+1][j] = "";
                 }
                 Cols4 = Cols4 + 1;
                 for (i = 1; i <= Cols4; i++) Grid4->Cells[i][0] = "Col." + IntToStr(i);
                 break; // end case grid 4
   } // end switch  insgrid
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::VectortoDiagonal1Click(TObject *Sender)
{
     int i, vecgrid, matgrid;
     AnsiString info, prmptstr, opstr;

     if (ScriptOp == true)
     {
          vecgrid = 1;
          matgrid = 2;
     }
     else {
          prmptstr = "Insert the vector from grid ";
          info = InputBox("VECTOR GRID",prmptstr,IntToStr(CurrentGrid));
          vecgrid = StrToInt(info);
          prmptstr = "into the matrix diagonal in grid ";
          info = InputBox("MATRIX GRID",prmptstr,IntToStr(CurrentGrid));
          matgrid = StrToInt(info);
     }
     switch (vecgrid)
     {
        case 1 : Operand1Edit->Text = Obj1NameEdit->Text; break;
        case 2 : Operand1Edit->Text = Obj2NameEdit->Text; break;
        case 3 : Operand1Edit->Text = Obj3NameEdit->Text; break;
        case 4 : Operand1Edit->Text = Obj4NameEdit->Text; break;
     }

     switch (matgrid)
     {
        case 1 :
              Operand2Edit->Text = Obj1NameEdit->Text;
              switch (vecgrid)
              {
                 case 2 :
                       if (Rows2 > Cols2)
                          for (i = 1; i <= Rows2; i++) Grid1->Cells[i][i] = Grid2->Cells[1][i];
                       else for (i = 1; i <= Cols2; i++) Grid1->Cells[i][i] = Grid2->Cells[i][1];
                       break;
                 case 3 :
                       if (Rows3 > Cols3)
                          for (i = 1; i <= Rows3; i++) Grid1->Cells[i][i] = Grid3->Cells[1][i];
                       else for (i = 1; i <= Cols3; i++) Grid1->Cells[i][i] = Grid3->Cells[i][1];
                       break;
                 case 4 :
                       if (Rows4 > Cols4)
                          for (i = 1; i <= Rows4; i++) Grid1->Cells[i][i] = Grid4->Cells[1][i];
                       else for (i = 1; i <= Cols4; i++) Grid1->Cells[i][i] = Grid4->Cells[i][1];
                       break;
              }
              break;
         case 2 :
              Operand2Edit->Text = Obj2NameEdit->Text;
              switch (vecgrid)
              {
                 case 1 :
                       if (Rows1 > Cols1)
                          for (i = 1; i <= Rows1; i++) Grid2->Cells[i][i] = Grid1->Cells[1][i];
                       else for (i = 1; i <= Cols1; i++) Grid2->Cells[i][i] = Grid1->Cells[i][1];
                       break;
                 case 3 :
                       if (Rows3 > Cols3)
                          for (i = 1; i <= Rows3; i++) Grid2->Cells[i][i] = Grid3->Cells[1][i];
                       else for (i = 1; i <= Cols3; i++) Grid2->Cells[i][i] = Grid3->Cells[i][1];
                       break;
                 case 4 :
                       if (Rows4 > Cols4)
                          for (i = 1; i <= Rows4; i++) Grid2->Cells[i][i] = Grid4->Cells[1][i];
                       else for (i = 1; i <= Cols4; i++)  Grid2->Cells[i][i] = Grid4->Cells[i][1];
                       break;
              }
              break;
         case 3 :
              Operand2Edit->Text = Obj3NameEdit->Text;
              switch (vecgrid)
              {
                 case 1 :
                       if (Rows1 > Cols1)
                          for (i = 1; i <= Rows1; i++) Grid3->Cells[i][i] = Grid1->Cells[1][i];
                       else for (i = 1; i <= Cols1; i++) Grid3->Cells[i][i] = Grid1->Cells[i][1];
                       break;
                 case 2 :
                       if (Rows2 > Cols2)
                          for (i = 1; i <= Rows2; i++) Grid3->Cells[i][i] = Grid2->Cells[1][i];
                       else for (i = 1; i <= Cols2; i++) Grid3->Cells[i][i] = Grid2->Cells[i][1];
                       break;
                 case 4 :
                       if (Rows4 > Cols4)
                          for (i = 1; i <= Rows4; i++) Grid3->Cells[i][i] = Grid4->Cells[1][i];
                       else for (i = 1; i <= Cols4; i++) Grid3->Cells[i][i] = Grid4->Cells[i][1];
                       break;
              }
              break;
         case 4 :
              Operand2Edit->Text = Obj4NameEdit->Text;
              switch (vecgrid)
              {
                 case 1 :
                       if (Rows1 > Cols1)
                          for (i = 1; i <= Rows1; i++) Grid4->Cells[i][i] = Grid1->Cells[1][i];
                       else for (i = 1; i <= Cols1; i++) Grid4->Cells[i][i] = Grid1->Cells[i][1];
                       break;
                 case 2 :
                       if (Rows2 > Cols2)
                          for (i = 1; i <= Rows2; i++) Grid4->Cells[i][i] = Grid2->Cells[1][i];
                       else for (i = 1; i <= Cols2; i++) Grid4->Cells[i][i] = Grid2->Cells[i][1];
                       break;
                 case 3 :
                       if (Rows3 > Cols3)
                          for (i = 1; i <= Rows3; i++) Grid4->Cells[i][i] = Grid3->Cells[1][i];
                       else for (i = 1; i <= Cols3; i++) Grid4->Cells[i][i] = Grid3->Cells[i][1];
                       break;
              }
              break;
     } // end switch  matgrid
     OperationEdit->Text = "VecToDiag";

     if (ScriptOp == false)
     {
          opstr = IntToStr(CurrentGrid) + "-" + "VecToDiag:";
          Operand1Edit->Text = IntToStr(vecgrid) + "-" + Operand1Edit->Text;
          opstr = opstr + Operand1Edit->Text;
          opstr = opstr + ":" + IntToStr(matgrid) + "-" + Operand2Edit->Text;
          ScriptList->Items->Add(opstr);
          CurrentGrid = matgrid;
          CurrentObjName = Operand2Edit->Text;
          CurrentObjType = 1; // column vector
          mnuSaveClick(this);
          ComboAdd(CurrentObjName);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::IDMatrixClick(TObject *Sender)
{
     AnsiString info, prmptstr, opstr;
     int i, j, nsize, gridno;

     prmptstr = "Enter the number of rows and columns:";
     info = InputBox("MATRIX SIZE",prmptstr,"4");
     nsize = StrToInt(info);
     if (nsize <= 0) return;
     prmptstr = "Place the matrix in grid:";
     info = InputBox("GRID NO.",prmptstr,IntToStr(CurrentGrid));
     gridno = StrToInt(info);

     switch (gridno)
     {
        case 1 :
              for (i = 1; i <= nsize; i++)
              {
                   for (j = 1; j <= nsize; j++)
                   {
                        if (i != j) Grid1->Cells[i][j] = FloatToStr(0.0);
                        else Grid1->Cells[i][j] = FloatToStr(1.0);
                        Grid1->Cells[j][0] = "Col." + IntToStr(j);
                   }
                   Grid1->Cells[0][i] = "Row " + IntToStr(i);
              }
              Grid1->RowCount = nsize + 1;
              Grid1->ColCount = nsize + 1;
              Rows1 = nsize;
              Cols1 = nsize;
              break;
        case 2 :
              for (i = 1; i <= nsize; i++)
              {
                   for (j = 1; j <= nsize; j++)
                   {
                        if (i != j) Grid2->Cells[i][j] = FloatToStr(0.0);
                        else Grid2->Cells[i][j] = FloatToStr(1.0);
                        Grid2->Cells[j][0] = "Col." + IntToStr(j);
                   }
                   Grid2->Cells[0][i] = "Row " + IntToStr(i);
              }
              Grid2->RowCount = nsize + 1;
              Grid2->ColCount = nsize + 1;
              Rows2 = nsize;
              Cols2 = nsize;
              break;
        case 3 :
              for (i = 1; i <= nsize; i++)
              {
                   for (j = 1; j <= nsize; j++)
                   {
                        if (i != j) Grid3->Cells[i][j] = FloatToStr(0.0);
                        else Grid3->Cells[i][j] = FloatToStr(1.0);
                        Grid3->Cells[j][0] = "Col." + IntToStr(j);
                   }
                   Grid3->Cells[0][i] = "Row " + IntToStr(i);
              }
              Grid3->RowCount = nsize + 1;
              Grid3->ColCount = nsize + 1;
              Rows3 = nsize;
              Cols3 = nsize;
              break;
        case 4 :
              for (i = 1; i <= nsize; i++)
              {
                   for (j = 1; j <= nsize; j++)
                   {
                        if (i != j) Grid4->Cells[i][j] = FloatToStr(0.0);
                        else Grid4->Cells[i][j] = FloatToStr(1.0);
                        Grid4->Cells[j][0] = "Col." + IntToStr(j);
                   }
                   Grid4->Cells[0][i] = "Row " + IntToStr(i);
              }
              Grid4->RowCount = nsize + 1;
              Grid4->ColCount = nsize + 1;
              Rows4 = nsize;
              Cols4 = nsize;
              break;
     }
     CurrentGrid = gridno;
     CurrentObjType = 1;
     CurrentObjName = "IDMAT";
     OperationEdit->Text = Operation;
     Operand1Edit->Text = "IDMAT";
     if (ScriptOp == false)
     {
          prmptstr = "Save identity matrix as ";
          info = InputBox("MATRIX NAME",prmptstr,"IDMAT");
          CurrentObjName = info;
          Operand1Edit->Text = info;
          opstr = IntToStr(gridno) + "-IDMAT:";
          opstr = opstr + IntToStr(gridno) + "-" + Operand1Edit->Text;
          ScriptList->Items->Add(opstr);
          mnuSaveClick(this);
          ComboAdd(CurrentObjName);
     }

     switch (gridno)
     {
        case 1 : Obj1NameEdit->Text = Operand1Edit->Text; break;
        case 2 : Obj2NameEdit->Text = Operand1Edit->Text; break;
        case 3 : Obj3NameEdit->Text = Operand1Edit->Text; break;
        case 4 : Obj4NameEdit->Text = Operand1Edit->Text; break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Clear1Click(TObject *Sender)
{
     ScriptList->Clear();
}
//---------------------------------------------------------------------------


void __fastcall TMatManForm::MatPostMatClick(TObject *Sender)
{
    MATxMATClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::FmtCells(TObject *Sender)
{
     AnsiString cellstr;
     int i, j, valtype, align, cellwide, decplaces, fldwide, gridno;
     char fmt[41];
     char astring[41];
     double X;

     gridno = CurrentGrid;
     decplaces = ops.gridnodecimals;
     fldwide = ops.gridfldwidth;

     strcpy(fmt,"%");
     sprintf(astring,"%d",fldwide);
     strcat(fmt,astring);
     strcat(fmt,".");
     sprintf(astring,"%d",decplaces);
     strcat(fmt,astring);
     strcat(fmt,"f");
//     sprintf(astring,fmt,X);
     // replace . with , if european style
     if (ops.format == 1)
     {
        unsigned int i;
        for (i = 0; i < strlen(astring); i++) if (astring[i] == '.')
           astring[i] = ',';  // European decimal point
     }

     switch (gridno)
     {
         case 1: for (i=1; i <= Rows1;i++)
                 {
                     for (j = 1; j <= Cols1; j++)
                     {
                         X = StrToFloat(Grid1->Cells[j][i]);
                         sprintf(astring,fmt,X);
                         Grid1->Cells[j][i] = astring;
                         Grid1->Cells[j][i] = Trim(Grid1->Cells[j][i]);
                     }
                 }
                 break;
         case 2: for (i=1; i <= Rows2;i++)
                 {
                     for (j = 1; j <= Cols2; j++)
                     {
                         X = StrToFloat(Grid2->Cells[j][i]);
                         sprintf(astring,fmt,X);
                         Grid2->Cells[j][i] = astring;
                         Grid2->Cells[j][i] = Trim(Grid2->Cells[j][i]);
                     }
                 }
                 break;
         case 3: for (i=1; i <= Rows3;i++)
                 {
                     for (j = 1; j <= Cols3; j++)
                     {
                         X = StrToFloat(Grid3->Cells[j][i]);
                         sprintf(astring,fmt,X);
                         Grid3->Cells[j][i] = astring;
                         Grid3->Cells[j][i] = Trim(Grid3->Cells[j][i]);
                     }
                 }
                 break;
         case 4: for (i=1; i <= Rows4;i++)
                 {
                     for (j = 1; j <= Cols4; j++)
                     {
                         X = StrToFloat(Grid4->Cells[j][i]);
                         sprintf(astring,fmt,X);
                         Grid4->Cells[j][i] = astring;
                         Grid4->Cells[j][i] = Trim(Grid4->Cells[j][i]);
                     }
                 }
                 break;
     }
}
//------------------------------------------------------------------------

void __fastcall TMatManForm::FormatBtnClick(TObject *Sender)
{
     FmtCells(this);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::PrintVector1Click(TObject *Sender)
{
     int gridno, ncols, nrows, nelements;
     double *vector;
     AnsiString *Labels;
     char Title[51];

     switch (CurrentGrid)
     {
        case 1 :
              nrows = Rows1;
              ncols = Cols1;
              if (nrows > ncols) // column vector
              {
                 vector = new double[nrows];
                 Labels = new AnsiString[nrows];
                 strcpy(Title,Obj1NameEdit->Text.c_str());
                 for (int i = 1; i <= nrows; i++)
                 {
                     vector[i-1] = StrToFloat(Grid1->Cells[1][i]);
                     Labels[i-1] = Grid1->Cells[0][i];
                 }
                 VPrint(vector, nrows, Labels, Title);
              }
              else // row vector
              {
                  vector = new double[ncols];
                  Labels = new AnsiString[ncols];
                  strcpy(Title,Obj1NameEdit->Text.c_str());
                  for (int i = 1; i <= ncols; i++)
                  {
                     vector[i-1] = StrToFloat(Grid1->Cells[i][1]);
                     Labels[i-1] = Grid1->Cells[i][0];
                  }
                  VPrint(vector, ncols, Labels, Title);
              }
              delete[] Labels;
              delete[] vector;
              break;
         case 2 :
              nrows = Rows2;
              ncols = Cols2;
              if (nrows > ncols) // column vector
              {
                 vector = new double[nrows];
                 Labels = new AnsiString[nrows];
                 strcpy(Title,Obj2NameEdit->Text.c_str());
                 for (int i = 1; i <= nrows; i++)
                 {
                     vector[i-1] = StrToFloat(Grid2->Cells[1][i]);
                     Labels[i-1] = Grid2->Cells[0][i];
                 }
                 VPrint(vector, nrows, Labels, Title);
              }
              else // row vector
              {
                  vector = new double[ncols];
                  Labels = new AnsiString[ncols];
                  strcpy(Title,Obj2NameEdit->Text.c_str());
                  for (int i = 1; i <= ncols; i++)
                  {
                     vector[i-1] = StrToFloat(Grid2->Cells[i][1]);
                     Labels[i-1] = Grid2->Cells[i][0];
                  }
                  VPrint(vector, ncols, Labels, Title);
              }
              delete[] Labels;
              delete[] vector;
              break;
         case 3 :
              nrows = Rows3;
              ncols = Cols3;
              if (nrows > ncols) // column vector
              {
                 vector = new double[nrows];
                 Labels = new AnsiString[nrows];
                 strcpy(Title,Obj3NameEdit->Text.c_str());
                 for (int i = 1; i <= nrows; i++)
                 {
                     vector[i-1] = StrToFloat(Grid3->Cells[1][i]);
                     Labels[i-1] = Grid3->Cells[0][i];
                 }
                 VPrint(vector, nrows, Labels, Title);
              }
              else // row vector
              {
                  vector = new double[ncols];
                  Labels = new AnsiString[ncols];
                  strcpy(Title,Obj3NameEdit->Text.c_str());
                  for (int i = 1; i <= ncols; i++)
                  {
                     vector[i-1] = StrToFloat(Grid3->Cells[i][1]);
                     Labels[i-1] = Grid3->Cells[i][0];
                  }
                  VPrint(vector, ncols, Labels, Title);
              }
              delete[] Labels;
              delete[] vector;
              break;
         case 4 :
              nrows = Rows4;
              ncols = Cols4;
              if (nrows > ncols) // column vector
              {
                 vector = new double[nrows];
                 Labels = new AnsiString[nrows];
                 strcpy(Title,Obj4NameEdit->Text.c_str());
                 for (int i = 1; i <= nrows; i++)
                 {
                     vector[i-1] = StrToFloat(Grid4->Cells[1][i]);
                     Labels[i-1] = Grid4->Cells[0][i];
                 }
                 VPrint(vector, nrows, Labels, Title);
              }
              else // row vector
              {
                  vector = new double[ncols];
                  Labels = new AnsiString[ncols];
                  strcpy(Title,Obj4NameEdit->Text.c_str());
                  for (int i = 1; i <= ncols; i++)
                  {
                     vector[i-1] = StrToFloat(Grid4->Cells[i][1]);
                     Labels[i-1] = Grid4->Cells[i][0];
                  }
                  VPrint(vector, ncols, Labels, Title);
              }
              delete[] Labels;
              delete[] vector;
              break;
     }
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::ScalarPrintClick(TObject *Sender)
{
     AnsiString outline;

     switch (CurrentGrid)
     {
        case 1:
            outline = "Grid 1 Scalar Value = " + Grid1->Cells[1][1];
            break;
        case 2:
            outline = "Grid 2 Scalar Value = " + Grid2->Cells[1][1];
            break;
        case 3:
            outline = "Grid 3 Scalar Value = " + Grid3->Cells[1][1];
            break;
        case 4:
            outline = "Grid 4 Scalar Value = " + Grid4->Cells[1][1];
            break;
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid4DblClick(TObject *Sender)
{
     CurrentGrid = 4;
     CurrentObjName = Obj4NameEdit->Text;
     GridNoEdit->Text = IntToStr(4);

}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid3DblClick(TObject *Sender)
{
     CurrentGrid = 3;
     CurrentObjName = Obj3NameEdit->Text;
     GridNoEdit->Text = IntToStr(3);

}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid2DblClick(TObject *Sender)
{
     CurrentGrid = 2;
     CurrentObjName = Obj2NameEdit->Text;
     GridNoEdit->Text = IntToStr(2);

}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::Grid1DblClick(TObject *Sender)
{
     CurrentGrid = 1;
     CurrentObjName = Obj1NameEdit->Text;
     GridNoEdit->Text = IntToStr(1);

}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::SVDUWVanalysis1Click(TObject *Sender)
{
     int size, gridchoice;
     int i, j, M, N;
     AnsiString opstr, prmptstr, info;
     double **U, *W, **V, **S, **A;
     AnsiString InverseName, Wname, Uname, Vname;
     if (CurrentObjType != 1)
emsg:
     {
          ShowMessage("Error - Selected grid does not contain a matrix.");
          return;
     }
     switch (CurrentGrid)
     {
        case 1 :
              Operand1Edit->Text = Obj1NameEdit->Text;
              M = Rows1;
              N = Cols1;
              break;
        case 2 :
              Operand1Edit->Text = Obj2NameEdit->Text;
              M = Rows2;
              N = Cols2;
              break;
        case 3 :
              Operand1Edit->Text = Obj3NameEdit->Text;
              M = Rows3;
              N = Cols3;
              break;
        case 4 :
              Operand1Edit->Text = Obj4NameEdit->Text;
              M = Rows4;
              N = Cols4;
              break;
     }

     OperationEdit->Text = "SVDAnalysis";
     opstr = IntToStr(CurrentGrid) + "-";
     opstr = opstr + "SVDAnalysis:" + IntToStr(CurrentGrid) + "-" + Operand1Edit->Text;

     // allocate memory
     GetDblMatMem(A,M,N);
     GetDblMatMem(U,M,N);
     GetDblMatMem(S,N,N);
     GetDblMatMem(V,N,N);
     switch (CurrentGrid)
     {
        case 1 :
             for (i = 0; i < M; i++)
                 for (j = 0; j < N; j++)
                     A[i][j] = StrToFloat(Grid1->Cells[j+1][i+1]);
             break;
        case 2 :
             for (i = 0; i < M; i++)
                 for (j = 0; j < N; j++)
                     A[i][j] = StrToFloat(Grid2->Cells[j+1][i+1]);
             break;
        case 3 :
             for (i = 0; i < M; i++)
                 for (j = 0; j < N; j++)
                     A[i][j] = StrToFloat(Grid3->Cells[j+1][i+1]);
             break;
        case 4 :
             for (i = 0; i < M; i++)
                 for (j = 0; j < N; j++)
                     A[i][j] = StrToFloat(Grid4->Cells[j+1][i+1]);
             break;
     }
     svd(A, M, N, U, S, V);

     // Place results in the grids
     Grid2->RowCount = M + 1;
     Grid2->ColCount = N + 1;
     Rows2 = M;
     Cols2 = N;
     Obj2NameEdit->Text = "U_Matrix";
     for (i = 0; i < M; i++)
        for (j = 0; j <  N; j++)
                Grid2->Cells[j+1][i+1] = FloatToStr(U[i][j]);
     CurrentGrid = 2;
     FmtCells(this);

     Grid3->RowCount = N + 1;
     Grid3->ColCount = N + 1;
     Rows3 = N;
     Cols3 = N;
     Obj3NameEdit->Text = "S_Matrix";
     for (i = 0; i < N; i++)
        for (j = 0; j <  N; j++)
                Grid3->Cells[j+1][i+1] = FloatToStr(S[i][j]);
     CurrentGrid = 3;
     FmtCells(this);

     Grid4->RowCount = N + 1;
     Grid4->ColCount = N + 1;
     Rows4 = N;
     Cols4 = N;
     Obj4NameEdit->Text = "V_Matrix";
     for (i = 0; i < N; i++)
          for (j = 0; j < N; j++)
               Grid4->Cells[j+1][i+1] = FloatToStr(V[i][j]);
     CurrentGrid = 4;
     FmtCells(this);

     if (ScriptOp == false)
     {
          prmptstr = "Save U matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"U");
          if (info.Length() > 0) Uname = info;
          else Uname = "U";
          prmptstr = "SAVE S matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"S");
          if (info.Length() > 0) Wname = info;
          else Wname = "S";
          prmptstr = "SAVE V matrix as: ";
          info = InputBox("SAVE AS",prmptstr,"V");
          if (info.Length() > 0 ) Vname = info;
          else Vname = "V";
          Obj2NameEdit->Text = Uname;
          Obj3NameEdit->Text = Wname;
          Obj4NameEdit->Text = Vname;
          ScriptList->Items->Add(opstr);
          // save U
          CurrentObjName = Uname;
          CurrentObjType = 1;
          CurrentGrid = 2;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          Obj2NameEdit->Text = Uname;
          // save W
          CurrentObjName = Wname;
          CurrentObjType = 1;
          CurrentGrid = 3;
          ComboAdd(CurrentObjName);
          mnuSaveClick(this);
          Obj3NameEdit->Text = Wname;
          // save V
          CurrentObjName = Vname;
          CurrentObjType = 1;
          CurrentGrid = 4;
          mnuSaveClick(this);
          Obj4NameEdit->Text = Vname;
     }

     // deallocate memory
     ClearDblMatMem(V,N);
     ClearDblMatMem(S,N);
     ClearDblMatMem(U,M);
     ClearDblMatMem(A,M);
}
//---------------------------------------------------------------------------

void __fastcall TMatManForm::GetMainDataClick(TObject *Sender)
{
        int nrows, ncols, ngrid;
        AnsiString Instr;

        Instr = InputBox("Input to Which Grid?","1","1");
        ngrid = StrToInt(Instr);
        switch (ngrid)
        {
           case 1:
                Grid1->RowCount = MainForm->Grid->RowCount;
                Grid1->ColCount = MainForm->Grid->ColCount;
                Rows1 = MainForm->Grid->RowCount-1;
                Cols1 = MainForm->Grid->ColCount-1;
                for (int i = 0; i <= MainForm->Grid->RowCount; i++)
                   for (int j = 0; j <= MainForm->Grid->ColCount; j++)
                        Grid1->Cells[j][i] = MainForm->Grid->Cells[j][i];
                Obj1NameEdit->Text = MainForm->FileNameEdit->Text;
                break;
           case 2:
                Grid2->RowCount = MainForm->Grid->RowCount;
                Grid2->ColCount = MainForm->Grid->ColCount;
                Rows2 = MainForm->Grid->RowCount-1;
                Cols2 = MainForm->Grid->ColCount-1;
                for (int i = 0; i <= MainForm->Grid->RowCount; i++)
                   for (int j = 0; j <= MainForm->Grid->ColCount; j++)
                        Grid2->Cells[j][i] = MainForm->Grid->Cells[j][i];
                Obj2NameEdit->Text = MainForm->FileNameEdit->Text;
                break;
           case 3:
                Grid3->RowCount = MainForm->Grid->RowCount;
                Grid3->ColCount = MainForm->Grid->ColCount;
                Rows3 = MainForm->Grid->RowCount-1;
                Cols3 = MainForm->Grid->ColCount-1;
                for (int i = 0; i <= MainForm->Grid->RowCount; i++)
                   for (int j = 0; j <= MainForm->Grid->ColCount; j++)
                        Grid3->Cells[j][i] = MainForm->Grid->Cells[j][i];
                Obj3NameEdit->Text = MainForm->FileNameEdit->Text;
                break;
           case 4:
                Grid4->RowCount = MainForm->Grid->RowCount;
                Grid4->ColCount = MainForm->Grid->ColCount;
                Rows4 = MainForm->Grid->RowCount-1;
                Cols4 = MainForm->Grid->ColCount-1;
                for (int i = 0; i <= MainForm->Grid->RowCount; i++)
                   for (int j = 0; j <= MainForm->Grid->ColCount; j++)
                        Grid4->Cells[j][i] = MainForm->Grid->Cells[j][i];
                Obj4NameEdit->Text = MainForm->FileNameEdit->Text;
                break;
        }
        CurrentObjName = MainForm->FileNameEdit->Text;
        nrows = MainForm->Grid->RowCount;
        ncols = MainForm->Grid->ColCount;
        if ((nrows >= 2) && (ncols >= 2)) CurrentObjType = 1;
        if ((nrows >= 2) && (ncols == 1)) CurrentObjType = 2;
        if ((nrows == 1) && (ncols >= 2)) CurrentObjType = 3;
        if ((nrows == 1) && (ncols == 1)) CurrentObjType = 4;
        CurrentGrid = ngrid;

}
//---------------------------------------------------------------------------

