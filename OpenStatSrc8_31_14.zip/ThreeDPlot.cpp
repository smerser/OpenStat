//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include <stdlib.h>
#include "ThreeDPlot.h"
#include "MainUnit.h"
#include <printers.hpp>
#include "DataFuncs.h"
#define TOL 0.0005
#define PI 3.14159265358979323846
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrm3DPlot *Frm3DPlot;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TFrm3DPlot::TFrm3DPlot(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::OkBtnClick(TObject *Sender)
{
    delete[] ZScaled;
    delete[] YScaled;
    delete[] XScaled;
    Frm3DPlot->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::PrintBtnClick(TObject *Sender)
{
    String Label("3D PLOT");
    POINT3D p1,p2,p, pa, pb;
    POINTint p11,p22;
    TPrinter *pPrinter = Printer(); // obtain a pointer to the Printer object
    int Clwidth =  pPrinter->PageWidth;
//    int Clheight = pPrinter->PageHeight;
    int Clheight = Clwidth;
    int offset = Clwidth / 20;
    long int t, X;

    Clwidth = Clwidth - Clwidth / 20;
    pPrinter->BeginDoc();
    // First, draw axis
    p1.x = -1; p1.y = p1.z = 0;
    p2.x = 1; p2.y = 0; p2.z = 0;
    pPrinter->Canvas->Pen->Color = clRed;
    //draw a 3d line
    p1.z = -p1.z;
    p2.z = -p2.z;
    pa = World3DToWorld2D(p1,this);
    pb = World3DToWorld2D(p2,this);
    // scale it up
    p11.x = (WXleft-pa.x)*(Clwidth-offset) / (WXleft - WXright)+ offset + 0.5;
    p11.y = (WYtop-pa.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    p22.x = (WXleft-pb.x)*(Clwidth-offset) / (WXleft - WXright) + offset + 0.5;
    p22.y = (WYtop-pb.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    pPrinter->Canvas->MoveTo(p11.x,p11.y);
    pPrinter->Canvas->LineTo(p22.x,p22.y);
    p1.x = 0; p1.y = -1; p2.x = 0; p2.y = 1; p2.z = 0;
    pPrinter->Canvas->Pen->Color = clBlue;
    //draw a 3d line
    p1.z = -p1.z;
    p2.z = -p2.z;
    pa = World3DToWorld2D(p1,this);
    pb = World3DToWorld2D(p2,this);
    // scale it up
    p11.x = (WXleft-pa.x)*(Clwidth-offset) / (WXleft - WXright)+ offset + 0.5;
    p11.y = (WYtop-pa.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    p22.x = (WXleft-pb.x)*(Clwidth-offset) / (WXleft - WXright) + offset + 0.5;
    p22.y = (WYtop-pb.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    pPrinter->Canvas->MoveTo(p11.x,p11.y);
    pPrinter->Canvas->LineTo(p22.x,p22.y);
    p1.y = 0; p1.z = -1; p2.x = 0; p2.y = 0; p2.z = 1;
    pPrinter->Canvas->Pen->Color = clGreen;
    //draw a 3d line
    p1.z = -p1.z;
    p2.z = -p2.z;
    pa = World3DToWorld2D(p1,this);
    pb = World3DToWorld2D(p2,this);
    // scale it up
    p11.x = (WXleft-pa.x)*(Clwidth-offset) / (WXleft - WXright)+ offset + 0.5;
    p11.y = (WYtop-pa.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    p22.x = (WXleft-pb.x)*(Clwidth-offset) / (WXleft - WXright) + offset + 0.5;
    p22.y = (WYtop-pb.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
    pPrinter->Canvas->MoveTo(p11.x,p11.y);
    pPrinter->Canvas->LineTo(p22.x,p22.y);
    pPrinter->Canvas->Pen->Color = clBlack;

    //Now, plot points
    for (int i = 0; i < NoCases; i++)
    {
        p.x = XScaled[i];
        p.y = YScaled[i];
        p.z = ZScaled[i];
        // draws a 3d point
        p1.z = -p1.z;
        pa = World3DToWorld2D(p,this);
        // scale it up
        p11.x = (WXleft-pa.x)*(Clwidth-offset) / (WXleft - WXright) + offset + 0.5;
        p11.y = (WYtop-pa.y)*(Clheight-offset) / (WYtop-WYbottom) + offset + 0.5;
        pPrinter->Canvas->Rectangle(p11.x - 4,p11.y - 4,p11.x + 4, p11.y + 4);
    }

    // Print Heading
    t = pPrinter->Canvas->TextWidth(Label);
    X = (Clwidth / 2) - (t / 2);
    pPrinter->Canvas->TextOut(X,0,Label);
    Label = "RED = X, BLUE = Y, GREEN = Z";
    t = pPrinter->Canvas->TextWidth(Label);
    X = (Clwidth / 2) - (t / 2);
    pPrinter->Canvas->TextOut(X,Clheight,Label);
    Label = XVarEdit->Text;
    Label = Label + "  ";
    Label = Label + YVarEdit->Text;
    Label = Label + "  ";
    Label = Label + ZVarEdit->Text;
    t = pPrinter->Canvas->TextWidth(Label);
    X = (Clwidth / 2) - (t / 2);
    pPrinter->Canvas->TextOut(X,Clheight+40,Label);
    Label = "ROTATION: X deg. = ";
    Label = Label + XEdit->Text;
    Label = Label + "  Y deg. = ";
    Label = Label + YEdit->Text;
    Label = Label + "  Z deg. = ";
    Label = Label + ZEdit->Text;
    t = pPrinter->Canvas->TextWidth(Label);
    X = (Clwidth / 2) - (t / 2);
    pPrinter->Canvas->TextOut(X,Clheight+80,Label);

    pPrinter->EndDoc();    // finish printing

}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::XScrollScroll(TObject *Sender,
      TScrollCode ScrollCode, int &ScrollPos)
{
    Rotate(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::YScrollScroll(TObject *Sender,
      TScrollCode ScrollCode, int &ScrollPos)
{
    Rotate(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::ZScrollScroll(TObject *Sender,
      TScrollCode ScrollCode, int &ScrollPos)
{
    Rotate(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrm3DPlot::FormShow(TObject *Sender)
{
    ListBox1->Items->Clear();
    for (int i = 0; i < NoVariables; i++)
        ListBox1->Items->Add(MainForm->Grid->Cells[i+1][0]);
    XScroll->Position = 0;
    YScroll->Position = 0;
    ZScroll->Position = 0;
    // set device limits
    DXmin = 36;
    DXmax = 436;
    DYmin = 36;
    DYmax = 436;
    // set world limits
    WXleft = WYbottom = -1.0;
    WXright = WYtop = 1.0;
    XEdit->Text = 0;
    YEdit->Text = 0;
    ZEdit->Text = 0;
    XVarEdit->Text = "";
    YVarEdit->Text = "";
    ZVarEdit->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::Rotate(TObject* Sender)
{
   POINT3D p;

    Canvas->Brush->Style = bsSolid;
    Canvas->Brush->Color = clWhite;
    Canvas->Pen->Color = clBlack;
    Canvas->Rectangle(20,20,460,460);

   //First, erase current points
   Canvas->Pen->Color = clWhite;
   Canvas->Brush->Color = clWhite;
   for (int i = 0; i < NoCases; i++)
   {
        p.x = XScaled[i];
        p.y = YScaled[i];
        p.z = ZScaled[i];
        drawpoint(p,this);
   }
   eraseaxis(this);
   Canvas->Brush->Color = clBlack;
   Canvas->Pen->Color = clBlack;
   degX = float(XScroll->Position);
   degY = float(YScroll->Position);
   degZ = float(ZScroll->Position);
   XEdit->Text = XScroll->Position;
   YEdit->Text = YScroll->Position;
   ZEdit->Text = ZScroll->Position;
   SetAxesAngles(degX, degY, degZ,this);
   drawaxis(this);
   for (int i = 0; i < NoCases; i++)
   {
        p.x = XScaled[i];
        p.y = YScaled[i];
        p.z = ZScaled[i];
        drawpoint(p,this);
   }
}
//---------------------------------------------------------------------------
float __fastcall TFrm3DPlot::DegToRad(float deg,TObject *Sender)
{
    return (deg*PI/180.0);
}
//---------------------------------------------------------------------------

float __fastcall TFrm3DPlot::RadToDeg(float rad,TObject *Sender)
{
    return (rad*180.0 / PI);
}
//---------------------------------------------------------------------------
TFrm3DPlot::POINT3D __fastcall TFrm3DPlot::World3DToWorld2D(POINT3D p, TObject *Sender)
{
    POINT3D ptemp;
    ptemp = p;
    if (RX)  {
        ptemp.x = p.x;
        ptemp.y = COSRX * p.y - SINRX * p.z;
        ptemp.z = SINRX * p.y + COSRX * p.z;
        p = ptemp;
    }
    if (RY)  {
        ptemp.x = COSRY * p.x + SINRY * p.z;
        ptemp.y = p.y;
        ptemp.z = SINRY * p.x + COSRY * p.z;
        p = ptemp;
    }
    if (RZ)  {
        ptemp.x = COSRZ * p.x - SINRZ * p.y;
        ptemp.y = SINRZ * p.x + COSRZ * p.y;
        ptemp.z = p.z;
    }
    if (fabs(ptemp.x) < TOL) ptemp.x = 0.0;
    if (fabs(ptemp.y) < TOL) ptemp.y = 0.0;
    if (fabs(ptemp.z) < TOL) ptemp.z = 0.0;
    return(ptemp);
}
//---------------------------------------------------------------------------

TFrm3DPlot::POINTint __fastcall TFrm3DPlot::World2DToDevice(POINT3D p, TObject *Sender)
{
    POINTint ptemp;
    ptemp.x = (WXleft - p.x) * (DXmax - DXmin) / (WXleft - WXright) + DXmin + 0.5;
    ptemp.y = (WYtop -  p.y) * (DYmax - DYmin) / (WYtop - WYbottom) + DYmin + 0.5;
    return(ptemp);
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::drawpoint(POINT3D p1, TObject *Sender)
{
    // draws a 3d point
    POINTint p2;
    p1.z = -p1.z;
    p2 = World2DToDevice(World3DToWorld2D(p1,this),this);
    Canvas->Rectangle(p2.x - 2,p2.y - 2,p2.x + 2, p2.y + 2);
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::drawline(POINT3D p1, POINT3D p2, TObject *Sender)
{
    //draws a 3d line
    POINTint p11,p22;
    p1.z = -p1.z;
    p2.z = -p2.z;
    p11 = World2DToDevice(World3DToWorld2D(p1,this),this);
    p22 = World2DToDevice(World3DToWorld2D(p2,this),this);
    Canvas->MoveTo(p11.x,p11.y);
    Canvas->LineTo(p22.x,p22.y);
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::drawaxis(TObject *Sender)
{
    POINT3D p1,p2;

    p1.x = -1; p1.y = p1.z = 0;
    p2.x = 1; p2.y = 0; p2.z = 0;
    Canvas->Pen->Color = clRed;
    drawline(p1,p2,this);
    p1.x = 0; p1.y = -1; p2.x = 0; p2.y = 1; p2.z = 0;
    Canvas->Pen->Color = clBlue;
    drawline(p1,p2,this);
    p1.y = 0; p1.z = -1; p2.x = 0; p2.y = 0; p2.z = 1;
    Canvas->Pen->Color = clGreen;
    drawline(p1,p2,this);
    Canvas->Pen->Color = clWhite;
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::SetAxesAngles(float rx, float ry, float rz, TObject *Sender)
{
    RX = DegToRad(rx,this);
    RY = DegToRad(ry,this);
    RZ = DegToRad(rz,this);
    COSRX = cos(RX);
    SINRX = sin(RX);
    COSRY = cos(RY);
    SINRY = sin(RY);
    COSRZ = cos(RZ);
    SINRZ = sin(RZ);
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::ScaleValues(TObject *Sender)
{
    // This routine scales the X, Y and Z values in the grid to new
    // values ranging from -1 to 1 for each.  The arrays of scaled
    // values are pointed to by the private float pointers XScaled,
    // YScaled and ZScaled;

    float Xmax, Ymax, Zmax, Xmin, Ymin, Zmin, value, prop;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;
    
    try  {
       XScaled = new float[NoCases];
       YScaled = new float[NoCases];
       ZScaled = new float[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory.","ERROR",MB_OK);
        return;
    }

//    Xmax = atof(MainForm->Grid->Cells[GridColX][1].c_str());
    result = GetValue(1, GridColX,intvalue, dblvalue, strvalue);
    if (result != 0) Xmax = 0.0;
    Xmax = dblvalue;
    Xmin = Xmax;
//    Ymin = atof(MainForm->Grid->Cells[GridColY][1].c_str());
    result = GetValue(1, GridColY,intvalue, dblvalue, strvalue);
    if (result != 0) Ymin = 0.0;
    Ymin = dblvalue;
    Ymax = Ymin;
//    Zmax = atof(MainForm->Grid->Cells[GridColZ][1].c_str());
    result = GetValue(1, GridColZ,intvalue, dblvalue, strvalue);
    if (result != 0) Zmax = 0.0;
    Zmax = dblvalue;
    Zmin = Zmax;
    for (int i = 0; i < NoCases; i++)
    {
//        value = atof(MainForm->Grid->Cells[GridColX][i+1].c_str());
        result = GetValue(i+1, GridColX,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        if (value > Xmax) Xmax = value;
        if (value < Xmin) Xmin = value;
//        value = atof(MainForm->Grid->Cells[GridColY][i+1].c_str());
        result = GetValue(i+1, GridColY,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        if (value > Ymax) Ymax = value;
        if (value < Ymin) Ymin = value;
//        value = atof(MainForm->Grid->Cells[GridColZ][i+1].c_str());
        result = GetValue(i+1, GridColZ,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        if (value > Zmax) Zmax = value;
        if (value < Zmin) Zmin = value;
    }
    // now scale values
    for (int i = 0; i < NoCases; i++)
    {
//        value = atof(MainForm->Grid->Cells[GridColX][i+1].c_str());
        result = GetValue(i+1, GridColX,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        prop = (Xmax - value) / (Xmax - Xmin);
        XScaled[i] = prop - 0.5;  //scale between -1 and +1
//        value = atof(MainForm->Grid->Cells[GridColY][i+1].c_str());
        result = GetValue(i+1, GridColY,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        prop = (Ymax - value) / (Ymax - Ymin);
        YScaled[i] = prop - 0.5;
//        value = atof(MainForm->Grid->Cells[GridColZ][i+1].c_str());
        result = GetValue(i+1, GridColZ,intvalue, dblvalue, strvalue);
        if (result != 0) value = 0.0;
        value = dblvalue;
        prop = (Zmax - value) / (Zmax - Zmin);
        ZScaled[i] = prop - 0.5;
    }
}
void __fastcall TFrm3DPlot::CancelBtnClick(TObject *Sender)
{
    Frm3DPlot->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::ListBox1Click(TObject *Sender)
{
    int index, result;
    AnsiString Xvar, Yvar, Zvar;

    index = ListBox1->ItemIndex;
    if (XVarEdit->Text == "")
    {
        XVarEdit->Text = ListBox1->Items->Strings[index];
        return;
    }
    if (YVarEdit->Text == "")
    {
        YVarEdit->Text = ListBox1->Items->Strings[index];
        return;
    }
    ZVarEdit->Text = ListBox1->Items->Strings[index];
    // Get column no.s of selected variables
    Xvar = XVarEdit->Text;
    Yvar = YVarEdit->Text;
    Zvar = ZVarEdit->Text;
    for (int i = 0; i < NoVariables; i++)
    {
        if (Xvar == MainForm->Grid->Cells[i+1][0]) GridColX = i+1;
        if (Yvar == MainForm->Grid->Cells[i+1][0]) GridColY = i+1;
        if (Zvar == MainForm->Grid->Cells[i+1][0]) GridColZ = i+1;
    }
    result = VarTypeChk(GridColX,0);
    if (result == 1) return;
    result = VarTypeChk(GridColY,0);
    if (result == 1) return;
    result = VarTypeChk(GridColZ,0);
    if (result == 1) return;
    ScaleValues(this); // get scaled X, y and Z values (-1.0 to 1.0)
    XScroll->Position = 20;
    YScroll->Position = -15;
    ZScroll->Position = -5;
    Canvas->Pen->Color = clBlack;
    Rotate(this);
}
//---------------------------------------------------------------------------

void __fastcall TFrm3DPlot::eraseaxis(TObject *Sender)
{
    POINT3D p1,p2;

    p1.x = -1; p1.y = p1.z = 0;
    p2.x = 1; p2.y = 0; p2.z = 0;
    Canvas->Pen->Color = clWhite;
    drawline(p1,p2,this);
    p1.x = 0; p1.y = -1; p2.x = 0; p2.y = 1; p2.z = 0;
    drawline(p1,p2,this);
    p1.y = 0; p1.z = -1; p2.x = 0; p2.y = 0; p2.z = 1;
    drawline(p1,p2,this);
}
//---------------------------------------------------------------


