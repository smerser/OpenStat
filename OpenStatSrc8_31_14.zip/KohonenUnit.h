//---------------------------------------------------------------------------

#ifndef KohonenUnitH
#define KohonenUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TKohononForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TRadioGroup *NormMethod;
   TEdit *NVarsEdit;
   TButton *CancelBtn;
   TButton *OKBtn;
   TLabel *Label2;
   TEdit *NOutEdit;
   TLabel *Label3;
   TEdit *WeightsEdit;
   TLabel *Label4;
   TEdit *ConfuseEdit;
   TLabel *Label5;
   TEdit *ClassifyEdit;
   TLabel *Label6;
   TEdit *TrainEdit;
   TRadioGroup *LearnGrp;
   TLabel *Label7;
   TLabel *Label8;
   TEdit *RateEdit;
   TEdit *ReduceEdit;
private:	// User declarations
public:		// User declarations
   __fastcall TKohononForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKohononForm *KohononForm;
//---------------------------------------------------------------------------
#endif
