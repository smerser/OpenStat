//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "SensUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSensForm *SensForm;
//---------------------------------------------------------------------------
__fastcall TSensForm::TSensForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::ResetBtnClick(TObject *Sender)
{
     if (ops.format == 0) AlphaEdit->Text = "0.05";
     else AlphaEdit->Text = "0,05";
     StandardizeChk->Checked = false;
     PlotChk->Checked = false;
     SlopesChk->Checked = false;
     InBtn->Enabled = true;
     OutBtn->Enabled = false;
     AvgSlopeChk->Checked = false;
     Varlist->Clear();
     SelectedList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::InBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              SelectedList->Items->Add(Varlist->Items->Strings[i]);
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::OutBtnClick(TObject *Sender)
{
     int index;

     index = SelectedList->ItemIndex;
     Varlist->Items->Add(SelectedList->Items->Strings[index]);
     SelectedList->Items->Delete(index);
     InBtn->Enabled = true;
     if (SelectedList->Items->Count == 0) OutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::AllBtnClick(TObject *Sender)
{
     int count, index;

     count = Varlist->Items->Count;
     for (index = 0; index < count; index++)
         SelectedList->Items->Add(Varlist->Items->Strings[index]);
     Varlist->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TSensForm::OKBtnClick(TObject *Sender)
{
     int NoVars, noselected, count, half, q, tp, low, hi, col;
     int *selected;
     double **Values;
     double **Slopes;
     double **AvgSlopes;
     double *RankedQ;
     double *Sorted;
     double temp, MedianSlope, MannKendall, Z, C, M1, M2, Alpha, mean, stddev;
     AnsiString cellstring;
     AnsiString *RowLabels, *ColLabels;
     char outline[121];
     bool Standardize = false;
     bool Plot = false;
     bool SlopePlot = false;
     bool AvgSlope = false;

     if (StandardizeChk->Checked) Standardize = true;
     if (PlotChk->Checked) Plot = true;
     if (SlopesChk->Checked) SlopePlot = true;
     if (AvgSlopeChk->Checked) AvgSlope = true;
     Alpha = 1.0 - StrToFloat(AlphaEdit->Text) / 2.0;
     noselected = SelectedList->Items->Count;
     if (noselected == 0)
     {
        ShowMessage("ERROR!  First, select variables to analyze.");
        return;
     }
     RowLabels = new AnsiString[NoCases];
     ColLabels = new AnsiString[NoCases];
     selected = new int[noselected];
     GetDblMatMem(Values,NoCases,noselected+1);
     GetDblMatMem(Slopes,NoCases,NoCases);
     NoVars = (NoCases * (NoCases - 1)) / 2;
     RankedQ = new double[NoVars];
     Sorted = new double[NoCases];
     if (AvgSlope) GetDblMatMem(AvgSlopes,NoCases,NoCases);

     for (int i = 0; i < NoCases; i++)
     {
         RowLabels[i] = MainForm->Grid->Cells[0][i+1];
         ColLabels[i] = RowLabels[i];
         for (int j = 0; j < NoCases; j++) Slopes[i][j] = 0.0;
     }

     // Get selected variables
     for (int i = 1; i <= noselected; i++)
     {
        cellstring = SelectedList->Items->Strings[i-1];
        for (int j = 1; j <= NoVariables; j++)
            if (cellstring == MainForm->Grid->Cells[j][0]) selected[i-1] = j;
     }

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("SEN'S DETECTION AND ESTIMATION OF TRENDS");
     sprintf(outline,"Number of data points = %d, Confidence Interval = %4.2f",
         NoCases,Alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");

     // Get the data
     if (AvgSlope) // clear area for averaged data
        for (int i = 0; i < NoCases; i++) Values[i][noselected] = 0.0;
     for (int j = 0; j < noselected; j++)
     {
         col = selected[j];
         for (int i = 1; i <= NoCases; i++)
         {
             Values[i-1][j] = floor(StrToFloat(MainForm->Grid->Cells[col][i]));
             if (AvgSlope) Values[i-1][noselected] = Values[i-1][noselected] +
                 Values[i-1][j];
         }
     }
     if (PrtDataChk->Checked)
     {
        ArrayPrint(Values, NoCases, noselected, "CASE", RowLabels, ColLabels, "Values");
        FrmOutPut->ShowModal();
     }

     // standardize if more than one variable and standardization elected
     if ((noselected > 1) && (Standardize == true))
     {
        for (int j = 0; j < noselected; j++)
        {
            mean = 0.0;
            stddev = 0.0;
            for (int i = 0; i < NoCases; i++)
            {
                mean += Values[i][j];
                stddev += (Values[i][j] * Values[i][j]);
            }
            stddev = stddev - (mean * mean) / NoCases;
            stddev = stddev / (NoCases - 1);
            stddev = sqrt(stddev);
            mean /= NoCases;
            for (int i = 0; i < NoCases; i++)
                Values[i][j] = (Values[i][j] - mean) / stddev;
            sprintf(outline,"Variable = %s, mean = %8.3f, standard deviation = %8.3f",
                MainForm->Grid->Cells[selected[j]][0].c_str(),mean,stddev);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
     }

     // average values if elected
     if (AvgSlope)
     {
        for (int i = 0; i < NoCases; i++) Values[i][noselected] /= (double)noselected;
     }

     // Get interval slopes
     int no2do = noselected;
     if (AvgSlope) no2do++;
     for (int j = 0; j < no2do; j++) // variable
     {
         if (j < noselected)
         {
            col = selected[j];
            cellstring = MainForm->Grid->Cells[col][0];
         }
         else
         {
             col = 0;
             cellstring = "Combined Scores";
         }
         for (int i = 0; i < NoCases-1; i++)
         {
             for (int k = i+1; k < NoCases; k++)
                 Slopes[i][k] = (Values[k][j] - Values[i][j]) / (double)(k-i);
         }
         if (PrtSlopesChk->Checked)
         {
//            FrmOutPut->RichOutPut->Clear();
            ArrayPrint(Slopes, NoCases, NoCases, "CASE", RowLabels, ColLabels, "Slopes");
            FrmOutPut->ShowModal();
         }

         // get ranked slopes and median estimator
         count = 0;
         for (int i = 0; i < NoCases-1; i++)
         {
             for (int k = i+1; k < NoCases; k++)
             {
                 RankedQ[count] = Slopes[i][k];
                 count++;
             }
         }
         // sort into ascending order
         for (int i = 0; i < count-1; i++)
         {
             for (int k = i+1; k < count; k++)
             {
                 if (RankedQ[i] > RankedQ[k])
                 {
                    temp = RankedQ[i];
                    RankedQ[i] = RankedQ[k];
                    RankedQ[k] = temp;
                 }
             }
         }
         if (PrtRanksChk->Checked)
         {
            AnsiString *RankLabels;
            RankLabels = new AnsiString[count];
            for (int k = 0; k < count; k++) RankLabels[k] = k+1;
//            FrmOutPut->RichOutPut->Clear();
            VPrint(RankedQ, count, RankLabels, "Ranked Slopes");
            FrmOutPut->ShowModal();
            delete[] RankLabels;
         }

         // Get median slope
         half = count / 2;
         if ((2 * half) < count) MedianSlope = RankedQ[half]; // odd number
         else MedianSlope = (RankedQ[half-1] + RankedQ[half])/ 2.0; // even no.

         // Get Mann-Kendall statistic based on tied values
         for (int i = 0; i < NoCases; i++) Sorted[i] = Values[i][j];
         // sort values
         for (int i = 0; i < NoCases-1; i++)
         {
             for (int k = i+1; k < NoCases; k++)
             {
                 if (Sorted[i] > Sorted[k]) // swap
                 {
                    temp = Sorted[i];
                    Sorted[i] = Sorted[k];
                    Sorted[k] = temp;
                 }
             }
         }
         MannKendall = 0.0;
         q = 0;
         for (int i = 0; i < NoCases-1; i++)
         {
             tp = 1; // no. of ties for pth (i) value
             for (int k = i + 1; k < NoCases; k++)
             {
                 if (Sorted[k] != Sorted[i])
                 {
                    i = k-1; // set i to next value beyond tied values
                    break;
                 }
                 else tp++;
             }
             if (tp > 1)
             {
                q++;
                MannKendall += (tp * (tp-1) * (2 * tp + 5));
             }
         }
         MannKendall = (NoCases * (NoCases-1) * (2 * NoCases + 5) - MannKendall) / 18.0;
         Z = inversez(Alpha);
         if (MannKendall > 0)
         {
            C = Z * sqrt(MannKendall);
            M1 = ((double) count - C) / 2.0;
            M2 = ((double) count + C) / 2.0;
         }
         else
         {
             sprintf(outline,"Error: z = %8.3f, MannKendall = %8.3f",Z,MannKendall);
             ShowMessage(outline);
         }

         // show results
         if (j < noselected)
            sprintf(outline,"Results for %s",cellstring.c_str());
         else sprintf(outline,"Results for averaged values");
         FrmOutPut->RichOutPut->Lines->Add(outline);
         if ((noselected > 1) && (Standardize == true))
         {
            mean = 0.0;
            stddev = 0.0;
            for (int i = 0; i < NoCases; i++)
            {
                mean += Values[i][j];
                stddev += (Values[i][j] * Values[i][j]);
            }
            stddev = stddev - (mean * mean) / NoCases;
            stddev = stddev / (NoCases - 1);
            stddev = sqrt(stddev);
            mean /= NoCases;
            sprintf(outline,"Mean = %8.3f, Standard Deviation = %8.3f",mean,stddev);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         sprintf(outline,"Median Slope for %d values = %8.3f",count,MedianSlope);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"Mann-Kendall Variance statistic = %8.3f (%d ties observed)",
             MannKendall,q);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"Ranks of the lower and upper confidence = (%8.3f,%8.3f)",
             M1,M2+1);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         low = M1-1;
         if ( ((M1-1) - (double) low) > 0.5) low = ceil(M1-1);
         hi = M2;
         if ( (M2 - (double) hi) > 0.5) hi = ceil(M2);
         if ((low > 0) || (hi <= count))
         {
             sprintf(outline,"Corresponding lower and upper slopes = (%8.3f,%8.3f)",
             RankedQ[low],RankedQ[hi]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         else
         {
             sprintf(outline,"ERROR! low rank = %d, hi rank = %d",low,hi);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("");

         // plot slopes if elected
         if (Plot)
         {
            GetDblMatMem(GraphForm->Xpoints,1,NoCases+1);
            GetDblMatMem(GraphForm->Ypoints,1,NoCases+1);
            GraphForm->GraphType = 7;
            GraphForm->nosets = 1;
            GraphForm->nbars = NoCases;
            GraphForm->BackColor = clYellow;
            GraphForm->WallColor = clBlue;
            GraphForm->FloorColor = clGray;
            if (j < noselected)
               GraphForm->Heading = MainForm->Grid->Cells[col][0];
            else GraphForm->Heading = "Average Values";
            GraphForm->barwideprop = 1.0;
            GraphForm->AutoScale = true;
            GraphForm->ShowLeftWall = true;
            GraphForm->ShowRightWall = true;
            GraphForm->ShowBottomWall = true;
            GraphForm->YTitle = "Measure";
            GraphForm->XTitle = "Time";
            for (int k = 0; k < NoCases; k++)
            {
                GraphForm->Ypoints[0][k] = Values[k][j];
                GraphForm->Xpoints[0][k] = k+1;
            }
            GraphForm->ShowModal();
            ClearDblMatMem(GraphForm->Ypoints,1);
            ClearDblMatMem(GraphForm->Xpoints,1);
         }

         // plot ranked slopes if elected
         if (SlopePlot)
         {
            GetDblMatMem(GraphForm->Xpoints,1,count+1);
            GetDblMatMem(GraphForm->Ypoints,1,count+1);
            GraphForm->GraphType = 7;
            GraphForm->nosets = 1;
            GraphForm->nbars = count;
            GraphForm->BackColor = clYellow;
            GraphForm->WallColor = clBlue;
            GraphForm->FloorColor = clGray;
            GraphForm->Heading = "Ranked Slopes";
            GraphForm->barwideprop = 1.0;
            GraphForm->AutoScale = true;
            GraphForm->ShowLeftWall = true;
            GraphForm->ShowRightWall = true;
            GraphForm->ShowBottomWall = true;
            GraphForm->YTitle = "Slope";
            GraphForm->XTitle = "Rank";
            for (int k = 0; k < count; k++)
            {
                GraphForm->Ypoints[0][k] = RankedQ[k];
                GraphForm->Xpoints[0][k] = k+1;
            }
            GraphForm->ShowModal();
            ClearDblMatMem(GraphForm->Ypoints,1);
            ClearDblMatMem(GraphForm->Xpoints,1);
         }

         if (AvgSlope) // add to average
         {
            for (int i = 0; i < NoCases-1; i++)
            {
                for (int k = i+1; k < NoCases; k++)
                    AvgSlopes[i][k] = AvgSlopes[i][k] + Slopes[i][k];
            }
         }
     } // next variable j
//     FrmOutPut->ShowModal();

     // Average multiple measures
     if (AvgSlope) // get averages
     {
//         FrmOutPut->RichOutPut->Clear();
         FrmOutPut->RichOutPut->Lines->Add("Results for averaged slopes");
         for (int i = 0; i < NoCases-1; i++)
         {
             for (int k = i+1; k < NoCases; k++)
                 AvgSlopes[i][k] = AvgSlopes[i][k] / noselected;
         }

         // get ranked slopes and median estimator
         count = 0;
         for (int i = 0; i < NoCases-1; i++)
         {
             for (int j = i+1; j < NoCases; j++)
             {
                 RankedQ[count] = AvgSlopes[i][j];
                 count++;
             }
         }
         for (int i = 0; i < count-1; i++) // sort ranked slopes
         {
             for (int j = i+1; j < count; j++)
             {
                 if (RankedQ[i] > RankedQ[j])
                 {
                    temp = RankedQ[i];
                    RankedQ[i] = RankedQ[j];
                    RankedQ[j] = temp;
                 }
             }
         }
         // Get median slope
         half = count / 2;
         if ((2 * half) < count) MedianSlope = RankedQ[half + 1]; // odd no.
         else MedianSlope = (RankedQ[half] + RankedQ[half+1])/ 2.0; // even no.

         // Get Mann-Kendall statistic based on tied values
         MannKendall = 0.0;
         q = 0;
         for (int i = 0; i < count-1; i++)
         {
             tp = 1; // no. of ties for pth (i) value
             for (int j = i + 1; j < count; j++)
             {
                 if (RankedQ[j] != RankedQ[i])
                 {
                    i = j-1;
                    break;
                 }
                 else tp++;
             }
             if (tp > 1)
             {
                q++;
                MannKendall += (tp * (tp-1) * (2 * tp + 5));
             }
         }
         MannKendall = (NoCases * (NoCases-1) * (2 * NoCases + 5) - MannKendall) / 18.0;
         Z = inversez(Alpha);
         C = Z * sqrt(MannKendall);
         M1 = ((double) count - C) / 2.0;
         M2 = ((double) count + C) / 2.0;

         // show results
         sprintf(outline,"Median Slope for %d values = %8.3f for averaged measures",
             count,MedianSlope);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"Mann-Kendall Variance statistic = %8.3f (%d ties observed)",
             MannKendall,q);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"Ranks of the lower and upper confidence = (%8.3f,%8.3f)",
             M1,M2);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         low = M1-1;
         if ( ((M1-1) - (double) low) > 0.5) low = ceil(M1-1);
         hi = M2;
         if ( (M2 - (double) hi) > 0.5) hi = ceil(M2);
         sprintf(outline,"Corresponding lower and upper slopes = (%8.3f,%8.3f)",
             RankedQ[low],RankedQ[hi]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
/*
     // plot ranked slopes if elected
     if (SlopePlot)
     {
            GetDblMatMem(GraphForm->Xpoints,1,count+1);
            GetDblMatMem(GraphForm->Ypoints,1,count+1);
            GraphForm->GraphType = 7;
            GraphForm->nosets = 1;
            GraphForm->nbars = count;
            GraphForm->BackColor = clYellow;
            GraphForm->WallColor = clBlue;
            GraphForm->FloorColor = clGray;
            GraphForm->Heading = "Ranked Slopes";
            GraphForm->barwideprop = 1.0;
            GraphForm->AutoScale = true;
            GraphForm->ShowLeftWall = true;
            GraphForm->ShowRightWall = true;
            GraphForm->ShowBottomWall = true;
            GraphForm->YTitle = "Slope";
            GraphForm->XTitle = "Rank";
            for (int k = 0; k < count; k++)
            {
                GraphForm->Ypoints[0][k] = RankedQ[k];
                GraphForm->Xpoints[0][k] = k+1;
            }
            GraphForm->ShowModal();
            ClearDblMatMem(GraphForm->Ypoints,1);
            ClearDblMatMem(GraphForm->Xpoints,1);
     }
*/
     FrmOutPut->ShowModal();

     if (AvgSlope) ClearDblMatMem(AvgSlopes,NoCases);
     delete[] Sorted;
     delete[] RankedQ;
     ClearDblMatMem(Slopes,NoCases);
     ClearDblMatMem(Values,NoCases);
     delete[] selected;
     delete[] ColLabels;
     delete[] RowLabels;
}
//---------------------------------------------------------------------------
