//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "stdlib.h"
#include "stdio.h"
#include "math.h"
#include "functions.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "MatrixUnit.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "RegSelUnit.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TRegSelForm *RegSelForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TRegSelForm::TRegSelForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRegSelForm::DepInBtnClick(TObject *Sender)
{
	int index;

    index = LstVariables->ItemIndex;
    DepVarEdit->Text = LstVariables->Items->Strings[index];
    LstVariables->Items->Delete(index);
    DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRegSelForm::IndInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstVariables->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstVariables->Selected[i])
         {
            cellstring = LstVariables->Items->Strings[i];
            IndepList->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstVariables->Items->Count; i++)
           {
               if (LstVariables->Selected[i])
               {
                  LstVariables->Items->Delete(i);
                  count--;
               }
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TRegSelForm::BtnResetClick(TObject *Sender)
{
    AnsiString cellstring;
    if (NoInBlock != NULL)
    {
       delete[] NoInBlock;
       NoInBlock = NULL;
    }
    NoInBlock = new int[NoVariables];
    if (BlkVars != NULL)
    {
       delete[] BlkVars;
       BlkVars = NULL;
    }
    BlkVars = new AnsiString[NoVariables];
    if (ops.format == 0)
    {
       SigInEdit->Text = "0.05";
       SigOutEdit->Text = "0.10";
    }
    else
    {
       SigInEdit->Text = "0,05";
       SigOutEdit->Text = "0,10";
    }
 	 IndepList->Clear();
    BlkNoEdit->Text = "1";
    DepVarEdit->Text = "";
    DepInBtn->Visible = true;
    ChkDesc->Checked = false;
    ChkCorrMat->Checked = false;
    ChkInverse->Checked = false;
    ChkCoefMat->Checked = true;
    SaveRChkBox->Checked = false;
    PredictChk->Checked = false;
    BPGChk->Checked = false;
    BlkCnt = 0;
    VarCnt = 0;
    Panel1->Visible = false;
    LstVariables->Clear();
    for (int i = 0; i < NoVariables; i++)
        LstVariables->Items->Add(MainForm->Grid->Cells[i+1][0]);
}

//---------------------------------------------------------------------------
void __fastcall TRegSelForm::BtnNextClick(TObject *Sender)
{
    char astring[11];

    //First, save current block list and clear the list space
    if (IndepList->Items->Count > 0)
    {
       for (int i = 0; i < IndepList->Items->Count;i++)
       {
    	     BlkVars[VarCnt] = IndepList->Items->Strings[i];
           VarCnt++;
       }
       NoInBlock[BlkCnt] = IndepList->Items->Count;
       BlkCnt++;
       IndepList->Clear();
       sprintf(astring,"%d",BlkCnt+1);
       BlkNoEdit->Text = astring;
    }
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::ComputeBtnClick(TObject *Sender)
{
    if (IndepList->Items->Count > 0) BtnNextClick(this);
    blkentryreg();
    if (NoInBlock != NULL)
    {
       delete[] NoInBlock;
       NoInBlock = NULL;
    }
    if (BlkVars != NULL)
    {
       delete[] BlkVars;
       BlkVars = NULL;
    }
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::FormShow(TObject *Sender)
{
     BtnResetClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::IndOutBtnClick(TObject *Sender)
{
     int index = IndepList->ItemIndex;
     if (index >= 0)
     {
        LstVariables->Items->Add(IndepList->Items->Strings[index]);
        IndepList->Items->Delete(index);
     }
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::blkentryreg(void)
{
     // procedure for entry of one or more blocks of variables
     AnsiString cellstring;
     int *VarsIn, index = 0, depcol = 0, StepNo = 0;
     double sigin, sigout, fvalue, probability, df1, df2, pdf1, OldR2, F, FProbF;
     AnsiString *VarLabels;
     bool PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs, PredResid;
     char outline[121];
     double *Means, *Variances, *StdDevs, *BWeights, *BetaWeights;
     double *Bttests, *tProbs, *BStdErrs;
     double R2, stderrest;
     bool errorcode;
     int *ColNoSelected;
     int result;
     double sumx2 = 0.0;

     VarsIn = new int[NoVariables];
     VarLabels = new AnsiString[NoVariables];
     PrintDesc = false;
     PrintCorrs = false;
     PrintInverse = false;
     PrintCoefs = false;
     SaveCorrs = false;
     PredResid = false;
     ShowAll = false;
     SaveXTX = false;
     SaveXTY = false;
     if (ChkDesc->Checked) PrintDesc = true;
     if (ChkCorrMat->Checked) PrintCorrs = true;
     if (ChkInverse->Checked) PrintInverse = true;
     if (ChkCoefMat->Checked) PrintCoefs = true;
     if (SaveRChkBox->Checked) SaveCorrs = true;
     if (PredictChk->Checked) PredResid = true;
     if (ShowAllChk->Checked) ShowAll = true;
     if (SaveXTXChk->Checked) SaveXTX = true;
     if (SaveXTYChk->Checked) SaveXTY = true;
     
     // get column number of the dependent variable
     cellstring = DepVarEdit->Text;
     for (int i = 0; i < NoVariables; i++)
         if (cellstring == MainForm->Grid->Cells[i+1][0]) depcol = i+1;
     if (depcol == 0)
     {
        ShowMessage("No dependent variable found.  Try again.");
        delete[] VarLabels;
        delete[] VarsIn;
        return;
     }
      // do the analysis entering variables for each block in sequence
     sigin = StrToFloat(SigInEdit->Text);
     for (int i = 0; i < BlkCnt; i++)
     {
         StepNo++;
         // do the analysis for variables in this block and previous blocks
         // first, get the variables to enter for this block
         for (int j = 0; j < NoInBlock[i]; j++)
         {
              cellstring = BlkVars[index];
              for (int k = 0; k < NoVariables; k++)
              {
                  if (cellstring == MainForm->Grid->Cells[k+1][0])
                  {
                      VarsIn[index] = k+1; // capture grid column number of variable
                      VarLabels[index] = cellstring;
                  }
              }
              index++;
         }
         if (index == 0)
         {
            ShowMessage("Problem encountered: no independent variables to analyze.");
            delete[] VarLabels;
            delete[] VarsIn;
            return;
         }

         Means = new double[index + 1];
         Variances = new double[index + 1];
         StdDevs = new double[index + 1];
         BWeights = new double[index + 1];
         BetaWeights = new double[index + 1];
         Bttests = new double[index + 1];
         tProbs = new double[index + 1];
         BStdErrs = new double[index + 1];

         // Now, pass the parameters to the regression procedure in the Matrix Unit
         int NCases = NoCases;
         pdf1 = 0.0;
//         df1 = 0.0;
//         df2 = 0.0;
         OldR2 = 0.0;

         mreg(index,VarsIn,depcol,VarLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tProbs,R2,fvalue,stderrest,NCases,errorcode,
             PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);

         // check significance of block entered
         df1 = index - pdf1;
         df2 = NCases - index - 1;
         F = ((R2 - OldR2) / (1.0 - R2)) * df2 / df1;
         FProbF = ftest(df1,df2,F);
         sprintf(outline,"F = %6.3f with probability = %6.3f",F,FProbF);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         if (FProbF < sigin)
         {
               sprintf(outline,"Block %d met entry requirements",StepNo);
               FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         else
         {
               sprintf(outline,"Block %d did not meet entry requirements",StepNo);
               FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         OldR2 = R2;
         pdf1 = index;

         if (PredResid)
         {
            int NoVars = index + 1;
            ColNoSelected = new int[NoVars];
            for (int i = 0; i < index; i++) ColNoSelected[i] = VarsIn[i];
            ColNoSelected[NoVars-1] = depcol;
            PredictIt(ColNoSelected, NoVars, Means, StdDevs,
                      BetaWeights, stderrest, index);
            delete[] ColNoSelected;
         }
         if (BPGChk->Checked)
         {
            double BPG;
            ComputeBPG(this, Means, Variances, StdDevs, BetaWeights, BWeights, BStdErrs,
            Bttests, tProbs, BPG, NCases, depcol, index, VarsIn,VarLabels,
            PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
         } // END IF BPG REQUESTED
         delete[] BStdErrs;
         delete[] tProbs;
         delete[] Bttests;
         delete[] BetaWeights;
         delete[] BWeights;
         delete[] StdDevs;
         delete[] Variances;
         delete[] Means;
         FrmOutPut->ShowModal();
     } // next block
     delete[] VarLabels;
     delete[] VarsIn;
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::ComputeBPG(TObject *Sender, double *Means, double *Variances,
      double *StdDevs, double *BetaWeights, double *BWeights, double *BStdErrs,
      double *Bttests, double *tProbs, double &BPG, int NCases, int depcol, int index, int *VarsIn,
      AnsiString *VarLabels, bool PrintDesc, bool PrintCorrs, bool PrintInverse,
      bool PrintCoefs, bool SaveCorrs)
{
      double R2, fvalue, stderrest;
      bool errorcode;
      char outline[121];

            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("=====================================================");
            FrmOutPut->RichOutPut->Lines->Add("Breusch-Pagan-Godfrey Test of Heteroscedasticity");
            FrmOutPut->RichOutPut->Lines->Add("=====================================================");
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("Auxiliary Regression");
            FrmOutPut->RichOutPut->Lines->Add("");
            BPG = 0.0;
            int col = NoVariables + 1;
            NewVar(col,false);
            DictionaryForm->DGrid->Cells[1][col] = "BPGResid";
            MainForm->Grid->Cells[col][0] = "BPGResid.";
            NoVariables = NoVariables + 1;
            // get predicted raw score
            for (int i = 1; i <= NoCases; i++)
            {
              double Y = 0.0;
              for (int j = 1; j <= index; j++)
              {
                  int col = VarsIn[j-1];
                  double z = (StrToFloat(Trim(MainForm->Grid->Cells[col][i])) -
                               Means[j-1]) / StdDevs[j-1];
                  Y = Y + (z * BetaWeights[j-1]); // predicted z score
              }
              Y = Y * StdDevs[index] + Means[index]; // predicte raw
              int k = depcol;
              Y = StrToFloat(Trim(MainForm->Grid->Cells[k][i])) - Y; // residual
              BPG = BPG + (Y * Y); // sum of squared residuals
              // save squared value for each case
              MainForm->Grid->Cells[NoVariables-1][i] = FloatToStr(Y * Y);
            }
            BPG = BPG / NCases;
            for (int i = 1; i <= NoCases; i++)
            {
                double Y = StrToFloat(Trim(MainForm->Grid->Cells[NoVariables-1][i])) / BPG;
                MainForm->Grid->Cells[NoVariables-1][i] = Y;
            }
            // Now, regress Hetero values on the independent variables
            depcol = NoVariables-1;
            VarsIn[index] = depcol;
            VarLabels[index] = MainForm->Grid->Cells[depcol][0];
            mreg(index,VarsIn,depcol,VarLabels,Means,Variances,StdDevs,BWeights,
              BetaWeights,BStdErrs,Bttests,tProbs,R2,fvalue,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
            BPG = ( R2 * Variances[index] * double((NoCases-1))) / 2.0;
            double chiprob = 1.0 - chisquaredprob(BPG,index);
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("Breusch-Pagan-Godfrey Test of Heteroscedasticity");
            sprintf(outline,"Chi-Square = %8.3f with probability greater value = %8.3f",BPG,chiprob);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
}
//---------------------------------------------------------------------------

void __fastcall TRegSelForm::PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars)
{
   // routine obtains predicted raw and standardized scores and their
   // residuals.  It is assumed that the dependent variable is last in the
   // list of variable column pointers stored in the ColNoSelected vector.

   int col, i, j, k, Index, IndexX, IndexY;
   double predicted, zpredicted, z1, z2, resid, Term1, Term2;
   double StdErrPredict, t95, Hi95, Low95;
   char astring[121];

   // Get the z predicted score and its residual
   col = NoVariables + 1;
   NewVar(col,false);
   MainForm->Grid->Cells[col][0] = "Pred.z";
   DictionaryForm->DGrid->Cells[1][col] = "Pred.z";
   col = NoVariables + 1;
   NewVar(col,false);
   MainForm->Grid->Cells[col][0] = "zResid.";
   DictionaryForm->DGrid->Cells[1][col] = "zResid.";
   MainForm->Grid->ColCount += 2;
   for (i = 1; i <= NoCases; i++)
   {
       zpredicted = 0.0;
       for (j = 0; j < NoIndepVars; j++)
       {
           k = ColNoSelected[j];
           z1 = (StrToFloat(Trim(MainForm->Grid->Cells[k][i])) -
                               Means[j]) / StdDevs[j];
           zpredicted = zpredicted + (z1 * BetaWeights[j]);
       }
       sprintf(astring,"%8.4f",zpredicted);
       MainForm->Grid->Cells[col-1][i] = astring;
       Index = ColNoSelected[NoVars-1];
       z2 = StrToFloat(Trim(MainForm->Grid->Cells[Index][i]));
       z2 = (z2 - Means[NoVars-1]) / StdDevs[NoVars-1]; // z score
       sprintf(astring,"%8.4f",z2 - zpredicted);  // z residual
       MainForm->Grid->Cells[col][i] = astring;
   }

   // Get raw predicted and residuals
   col = NoVariables + 1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "Pred.Raw";
   MainForm->Grid->Cells[col][0] = "Pred.Raw";
   // calculate raw predicted scores and store in grid at col
   for (i = 1; i <= NoCases; i++)
   {   // predicted raw obtained from previously predicted z score
       predicted = StrToFloat(Trim(MainForm->Grid->Cells[col-2][i])) *
                            StdDevs[NoVars-1] + Means[NoVars-1];
       sprintf(astring,"%8.3f",predicted);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // Calculate residuals of predicted raw scores }
   col = NoVariables +1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "RawResid.";
   MainForm->Grid->Cells[col][0] = "RawResid.";
//   NoVariables = NoVariables + 1;
   for (i = 1; i <= NoCases; i++)
   {
       Index = ColNoSelected[NoVars-1];
       resid = StrToFloat(Trim(MainForm->Grid->Cells[Index][i])) -
               StrToFloat(Trim(MainForm->Grid->Cells[col-1][i]));
       sprintf(astring,"%8.3f",resid);
       MainForm->Grid->Cells[col][i] = astring;
   }
/*
   // Calculate Confidence Interval for raw predicted score
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "StdErrPred";
   NewVar(col,true);
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Low 95%";
   NewVar(col,true);
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Top 95%";
   NewVar(col,true);
   for (i = 1; i <= NoCases; i++)
   {
       // get term1 of the std. err. prediction
       Term1 = 0.0;
       for (j = 1; j <= NoIndepVars; j++)
       {
           col = ColNoSelected[j-1];
           z1 = StrToFloat(Trim(MainForm->Grid->Cells[col][i]));
           z1 = (z1 - Means[j-1]) / StdDevs[j-1];
           z1 = (z1 * z1) * IndepInverse[j-1][j-1];
           Term1 = Term1 + z1;
       }
       // get term2 of the std err. of prediction
       Term2 = 0.0;
       for (j = 1; j <= NoIndepVars - 1; j++)
       {
           for (k = j + 1; j <= NoIndepVars; j++)
           {
               col = ColNoSelected[j-1];
               z1 = StrToFloat(Trim(MainForm->Grid->Cells[col][i]));
               col = ColNoSelected[k-1];
               z2 = StrToFloat(Trim(MainForm->Grid->Cells[col][i]));
               z1 = (z1 - Means[j-1]) / StdDevs[j-1];
               z2 = (z2 - Means[k-1]) / StdDevs[k-1];
               Term2 = Term2 + IndepInverse[j-1][k-1] * z1 * z2;
           }
       }
       Term2 = 2.0 * Term2;
       StdErrPredict = sqrt(NoCases + 1 + Term1 + Term2);
       StdErrPredict = (StdErrEst / sqrt(NoCases)) * StdErrPredict;
       t95 = inverset(0.975,NoCases-NoIndepVars-1);
       Low95 = StrToFloat(Trim(MainForm->Grid->Cells[NoVars+4][i]));
       Hi95 = Low95;
       Low95 = Low95 - (t95 * StdErrPredict);
       Hi95 = Hi95 + (t95 * StdErrPredict);
       sprintf(astring,"%8.3f",Hi95);
       MainForm->Grid->Cells[NoVariables][i] = astring;
       sprintf(astring,"%8.3f",Low95);
       MainForm->Grid->Cells[NoVariables-1][i] = astring;
       sprintf(astring,"%8.3f",StdErrPredict);
       MainForm->Grid->Cells[NoVariables-2][i] = astring;
   } // next case
*/
}
//--------------------------------------------------------------------------

