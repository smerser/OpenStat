//---------------------------------------------------------------------------

#ifndef EscapeUnitH
#define EscapeUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TEscForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TEdit *ProcEdit;
   TLabel *Label2;
   TButton *Button1;
   void __fastcall Button1Click(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
   bool eschit;
   __fastcall TEscForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEscForm *EscForm;
//---------------------------------------------------------------------------
#endif
