//---------------------------------------------------------------------------

#ifndef GenNewFileUnitH
#define GenNewFileUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TGenNewFileForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TEdit *FreqVarEdit;
    TLabel *Label3;
    TEdit *ValVarEdit;
    TLabel *Label4;
    TListBox *OtherVarList;
    TBitBtn *FreqInBtn;
    TBitBtn *FreqOutBtn;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ReturnBtn;
    TBitBtn *ValInBtn;
    TBitBtn *OtherInBtn;
    TBitBtn *ValOutBtn;
    TBitBtn *OtherOutBtn;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FreqInBtnClick(TObject *Sender);
    void __fastcall FreqOutBtnClick(TObject *Sender);
    void __fastcall ValInBtnClick(TObject *Sender);
    void __fastcall ValOutBtnClick(TObject *Sender);
    void __fastcall OtherInBtnClick(TObject *Sender);
    void __fastcall OtherOutBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TGenNewFileForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGenNewFileForm *GenNewFileForm;
//---------------------------------------------------------------------------
#endif
