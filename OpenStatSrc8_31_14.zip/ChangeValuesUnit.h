//---------------------------------------------------------------------------

#ifndef ChangeValuesUnitH
#define ChangeValuesUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TChangeValuesForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *ListBox1;
        TLabel *Label2;
        TListBox *OpList;
        TEdit *Value1Edit;
        TLabel *Label3;
        TListBox *ListBox2;
        TLabel *Label4;
        TEdit *Value2Edit;
        TButton *Button1CancelBtn;
        TButton *ChangeBtn;
        TButton *ReturnBtn;
        TCheckBox *DefaultChk;
        TCheckBox *NewVarChk;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ChangeBtnClick(TObject *Sender);
        void __fastcall ListBox1Click(TObject *Sender);
        void __fastcall ListBox2Click(TObject *Sender);
        void __fastcall OpListClick(TObject *Sender);
        void __fastcall DefaultChkClick(TObject *Sender);
        void __fastcall NewVarChkClick(TObject *Sender);
private:	// User declarations
        int Var1Index, Var2Index, OpIndex;
        bool newvariable;
public:		// User declarations
        __fastcall TChangeValuesForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TChangeValuesForm *ChangeValuesForm;
//---------------------------------------------------------------------------
#endif
