//---------------------------------------------------------------------------

#ifndef StudentizedH
#define StudentizedH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TStudentizedq : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TEdit *DF1Edit;
        TEdit *DF2Edit;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *CumEdit;
        TEdit *PropGreater;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TLabel *Label5;
        TEdit *QEdit;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TStudentizedq(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStudentizedq *Studentizedq;
//---------------------------------------------------------------------------
#endif
