//---------------------------------------------------------------------------
#ifndef GradeSysUnitH
#define GradeSysUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TGradeSysFrm : public TForm
{
__published:	// IDE-managed Components
    TStringGrid *Grid;
    TLabel *Label1;
    TEdit *TestNoEdit;
    TGroupBox *GroupBox1;
    TCheckBox *zChkBox;
    TCheckBox *RankChkBox;
    TCheckBox *LtrGrdChkBox;
    TCheckBox *RawDistChkBox;
    TCheckBox *zDistChkBox;
    TCheckBox *GradeDistChkBox;
    TCheckBox *RelChkBox;
    TCheckBox *ClsSumryChkBox;
    TCheckBox *StdRepChkBox;
    TGroupBox *GroupBox2;
    TCheckBox *TotRawChkBox;
    TCheckBox *TotZChkBox;
    TCheckBox *TotRankChkBox;
    TCheckBox *TotWRawChkBox;
    TCheckBox *TotWzChkBox;
    TCheckBox *TotWRankChkBox;
    TCheckBox *CompRelChkBox;
    TGroupBox *GroupBox3;
    TCheckBox *GrdMethChkBox;
    TCheckBox *TestDescChkBox;
    TCheckBox *PrntGridChkBox;
    TCheckBox *TestSumChkBox;
    TCheckBox *GrdBkSumChkBox;
    TCheckBox *BookTitleChkBox;
    TButton *DoTestBtn;
    TButton *DoClassBtn;
    TButton *DoBookBtn;
    TButton *SaveFileBtn;
    TButton *CancelBtn;
    TButton *ExitBtn;
    TLabel *Label2;
    TEdit *TestNameEdit;
    TLabel *Label3;
    TEdit *BookNameEdit;
    TButton *AddStudBtn;
    TButton *AddTestBtn;
    TButton *DelStudBtn;
    TButton *DelTestBtn;
    TButton *OpenFileBtn;
    TOpenDialog *OpenDialog1;
    TButton *SortBtn;
    TSaveDialog *SaveDialog1;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall AddStudBtnClick(TObject *Sender);
    void __fastcall GridKeyPress(TObject *Sender, char &Key);
    void __fastcall AddTestBtnClick(TObject *Sender);
    void __fastcall GridClick(TObject *Sender);
    void __fastcall DelStudBtnClick(TObject *Sender);
    void __fastcall DelTestBtnClick(TObject *Sender);
    void __fastcall SortBtnClick(TObject *Sender);
    void __fastcall OpenFileBtnClick(TObject *Sender);
    void __fastcall SaveFileBtnClick(TObject *Sender);
    void __fastcall DoBookBtnClick(TObject *Sender);
    void __fastcall DoTestBtnClick(TObject *Sender);
    void __fastcall DoClassBtnClick(TObject *Sender);
 private:	// User declarations
    bool FileOpened;
    int TestNo;
    int AbsenceMethod;
    int GradeScheme;
    char FileName[81];
    FILE * fileptr;
    struct GradeBook
    {
        int NoStudents;
        int NoTests;
        int AbsenceMethod;
        int GradeScheme;
        double Dist[12][2];
        char Name[41];
    };
    GradeBook gbook;

    struct Test
    {
        int TestNo;
        int NoItems;
        double Weight;
        double Reliability;
        double Mean;
        double StdDev;
        char Description[41];
    };
    Test *tests[20];
    
    void __fastcall InitTest(int TestN);
    void __fastcall PrintCases(void);
    void __fastcall BarPlot(int col, int type);
    void __fastcall CompRel(void);

public:		// User declarations
    __fastcall TGradeSysFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGradeSysFrm *GradeSysFrm;
//---------------------------------------------------------------------------
#endif
