//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MemMgrUnit.h"
#include "Printers.hpp"
#include "MainUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "functions.h"
#include "FrmFDSpecs.h"
#include "GraphUnit.h"

#include "SmoothData.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
TSmoothForm *SmoothForm;
//---------------------------------------------------------------------------
__fastcall TSmoothForm::TSmoothForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSmoothForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     RepeatEdit->Text = "1";
     VariableEdit->Text = "";
     InBtn->Visible = true;
     OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSmoothForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);        
}
//---------------------------------------------------------------------------
void __fastcall TSmoothForm::InBtnClick(TObject *Sender)
{
     int index;
     index = VarList->ItemIndex;
     VariableEdit->Text = VarList->Items->Strings[index];
     InBtn->Visible = false;
     OutBtn->Visible = true;
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TSmoothForm::OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(VariableEdit->Text);
     VariableEdit->Text = "";
     OutBtn->Visible = false;
     InBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TSmoothForm::ComputeBtnClick(TObject *Sender)
{
     double *DataPts;
     double *OutPts;
//     double *Smoothed;
     double value;
     double dblvalue;
     double avg;
     int result;
     int N;
     int Reps;
     int intvalue;
     AnsiString VarLabel;
     AnsiString strvalue;

     N = NoCases;
     GetDblVecMem(DataPts,N);
     GetDblVecMem(OutPts,N);
//     GetDblVecMem(Smoothed,N);

     Reps = StrToInt(RepeatEdit->Text);
     VarLabel = VariableEdit->Text;
     for (int i = 0; i < NoVariables; i++)
         if (VarLabel == MainForm->Grid->Cells[i+1][0]) VarCol = i+1;

     for (int i = 0; i < N; i++)
     {
        value = StrToFloat(MainForm->Grid->Cells[VarCol][i+1]);
        //result = GetValue(i+1,VarCol,intvalue,dblvalue,strvalue);
        //if (result == 1) value = 0.0;
        //else value = dblvalue;
        DataPts[i] = value;
     }

     // repeat smoothing for number of times eleted
     OutPts[0] = DataPts[0];
     OutPts[N-1] = DataPts[N-1];
     for (int j = 1; j <= Reps; j++)
     {
         for (int i = 1; i < N-1; i++)
         {
             avg = (DataPts[i-1] + DataPts[i] + DataPts[i+1]) / 3.0;
             OutPts[i] = avg;
         }
         if (j < Reps) for (int i = 0; i < N; i++) DataPts[i] = OutPts[i];
     }

     // create new variable and copy smoothed data into it.
     int col = NoVariables+1;
     MainForm->Grid->Cells[col][0] = "Smoothed"; 
     NewVar(col,true);
     for (int i = 0;i < N; i++) MainForm->Grid->Cells[col][i+1] = OutPts[i];
}
//---------------------------------------------------------------------------
