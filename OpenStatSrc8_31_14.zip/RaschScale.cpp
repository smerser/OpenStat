//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "except.h"
#include "functions.h"
#include "RaschScale.h"
#include "DataFuncs.h"
//#include "TGraphUnit.h"
#include "stdio.h"
#include "MainUnit.h"
#include "GraphUnit.h"
#include "MemMgrUnit.h"
#include "RaschUnit.h"

extern bool FilterOn;
extern int FilterCol;
extern int NoVariables;
extern int NoCases;
//---------------------------------------------------------------------------

void ANALYZE(int *itemfail, int *grpfail, int **f, int &T, int *grppass,\
             int *itempass, int r, int C1, double &min, double &max,\
             double *p2)
{
	int i, j;

     for (i = 0; i < r; i++) itemfail[i] = 0;
     for (j = 0; j < C1; j++) grpfail[j] = 0;
     for (i = 0; i < r; i++)
     {
          for (j = 0; j < C1; j++)
          {
               grpfail[j] += f[i][j];
               itemfail[i] += f[i][j];
          }
     }
     T = 0;
     for (j = 0; j < C1; j++) T += grpfail[j];
     for (j = 0; j < C1; j++) grppass[j] = T - grpfail[j];
     for (i = 0; i < r; i++)  itempass[i] = T - itemfail[i];
     min = p2[0];
     max = p2[0];
     for (i = 0; i < C1; i++)
     {
          if (p2[i] < min) min = p2[i];
          if (p2[i] > max) max = p2[i];
     }
}  // End Sub 'end analyze procedure

//---------------------------------------------------------------

void EXPAND(double v1, double v2, double &xexpand, double &yexpand)
{
     yexpand = sqrt( (1.0 + (v2 / 2.89)) / (1.0 - (v1 * v2 / 8.35)) );
     xexpand = sqrt( (1.0 + (v1 / 2.89)) / (1.0 - (v1 * v2 / 8.35)) );
} //End Sub 'end of expand

//----------------------------------------------------------------

void FinishIt(int r, int *i5, double *rptbis, double *rbis, double *slope, \
			  double *mean, int *itemfail, double *P )
{
	int i;
	char outline[100];

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Item Data Summary");
     FrmOutPut->RichOutPut->Lines->Add( "ITEM  PT.BIS.R.  BIS.R.  SLOPE   PASSED  FAILED  RASCH DIFF");
     for (i = 0; i < r; i++)
     {
        sprintf(outline,"%3d   %6.3f  %6.3f    %5.2f  %6.2f  %4d      %6.3f",\
        		i5[i],rptbis[i],rbis[i],slope[i],mean[i],itemfail[i],P[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
} // end FinishIt procedure

//---------------------------------------------------------------------

void FREQUENCIES(int C1, int r, int **f, int *rowtot, int *i5, int *s5,\
                 int T, int *S )
{
	bool Done = false;
    int i, j, c2, c3;
    char outline[100];
    char strvalue[21];

     c3 = C1;
     c2 = 0;
     if (c3 > 16) c3 = 16;
     while (!Done)
     {
      FrmOutPut->RichOutPut->Lines->Add("Matrix of Item Failures in Score Groups");
      strcpy(outline,"   Score Group");
      for (j = c2; j < c3; j++)
      {
        sprintf(strvalue,"%4d",s5[j]);
		strcat(outline,strvalue);
      }
      strcat(outline,"     Total");
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("ITEM" );
      FrmOutPut->RichOutPut->Lines->Add(" ");
      for (i = 0; i < r; i++)
      {
      	sprintf(outline,"%4d          ",i5[i]);
        for (j = c2; j < c3; j++)
        {
           sprintf(strvalue,"%4d",f[i][j]);
           strcat(outline,strvalue);
        }
        sprintf(strvalue,"%7d",rowtot[i]);
		strcat(outline,strvalue);
        FrmOutPut->RichOutPut->Lines->Add(outline);
      }
      strcpy(outline,"Total         ");
      for (j = c2; j < c3; j++)
      {
       	  sprintf(strvalue,"%4d",S[j]);
          strcat(outline,strvalue);
      }
      sprintf(strvalue,"%7d",T);
      strcat(outline,strvalue);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add( "");
      if (c3 == C1) Done = true;
      else
      {
         c2 = c3 + 1;
         c3 = c2 + 15;
         if (c3 > C1) c3 = C1;
      }
     } // end while not done
} // end sub frequencies

//------------------------------------------------------------------

void GETLOGS(double *L, double *L1, double *L2, double *g, double *g2,\
             double *f2, int *rowtot, int k, int *s5, int *S, int T, int r,\
             int C1, double &v1, double &v2 )
{
	double tx, rowtx, rx, t2, t3, e;
	int i, j;
	char outline[100];

     //write('Do you want to print log computations (y or n) : ')
     //readln(response)
     t2 = 0.0;
     tx = T;
     rx = r;
     for (i = 0; i < r; i++)
     {
          rowtx = rowtot[i];
          L[i] = log(rowtx / (tx - rowtx));
          t2 = t2 + L[i];
     }
     t2 = t2 / rx;
     for (i = 0; i < r; i++)
     {
          L1[i] = L[i] - t2;
          L2[i] = L1[i] * L1[i];
          v1 += L2[i];
     }
     v1 /= rx;
     FrmOutPut->RichOutPut->Lines->Add( "Item Log Odds Deviation Squared Deviation");
     for (i = 0; i < r; i++)
     {
         sprintf(outline,"%3d  %6.2f   %6.2f     %6.2f",i+1,L[i],L1[i],L2[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     t3 = 0.0;
     v2 = 0.0;
     for (j = 0; j < C1; j++)
     {
          e = s5[j];
          g[j] = log(e / (k - e));
          g2[j] = S[j] * g[j];
          t3 += g2[j];
          f2[j] = S[j] * (g[j] * g[j]);
          v2 = v2 + f2[j];
     }
     t3 /= tx;
     v2 /= tx - (t3 * t3);
     FrmOutPut->RichOutPut->Lines->Add("Score Frequency Log Odds Freq.x Log  Freq.x Log Odds Squared");
     for (j = 0; j < C1; j++)
     {
        sprintf(outline,"%3d   %3d      %6.2f      %6.2f     %6.2f",\
                s5[j],S[j],g[j],g2[j],f2[j]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }
} //end of  getlogs

//-----------------------------------------------------------------------

void GETSCORES(int noselected, int *selected, int NoCases, int **f,\
               double *mean, double *xsqr, double *sumxy, int *S, int *X,\
               double &sumx, double &sumx2, int &N)
{
    int i, j, k1, T;
    char outline[100];
    char strvalue[21];

     FrmOutPut->Show();
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Rasch One-Parameter Logistic Test Scaling (Item Response Theory)");
     FrmOutPut->RichOutPut->Lines->Add("Written by William G. Miller");
     FrmOutPut->RichOutPut->Lines->Add("");
     k1 = noselected;
     for (i = 0; i < k1; i++)
     {
          for (j = 0; j < k1+2; j++)
          {
             f[i][j] = 0;
          }
          mean[i] = 0.0;
          xsqr[i] = 0.0;
          sumxy[i] = 0,0;
     }
     for (j = 0; j < k1+2; j++) S[j] = 0;
     N = 0;
     sumx = 0.0;
     sumx2 = 0.0;

     //Read each case and scores for each item.  Eliminate rows (subjects)
     //that have a total score of zero or all items correct
     for (i = 0; i < NoCases; i++)
     {
          if (!ValidRecord(i+1,selected,noselected)) continue;
          T = 0;
          for (j = 0; j < k1; j++)
          {
              int item = selected[j];
              X[j] = floor(StrToFloat(MainForm->Grid->Cells[item][i+1]));
              T = T + X[j];
          }
          if ((T < k1) && (T > 0))
          {
             sprintf(outline,"Case %3d Total Score = %3d Item scores",i+1,T);
             sumx += T;
             sumx2 += (T * T);
             for (j = 0; j < k1; j++)
             {
                mean[j] += X[j];
                xsqr[j] += X[j] * X[j];
                sumxy[j] += X[j] * T;
    			sprintf(strvalue,"%2d",X[j]);
                strcat(outline,strvalue);
                if (X[j] == 0) f[j][T-1]++;
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            S[T-1]++;
            N++;
          }
          else
          {
               sprintf(outline,"case %3d eliminated.  Total score was %3d",\
                       i+1, T);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
} //end sub getscores

//--------------------------------------------------------------------------

void MAXABILITY(double *expdcnt, double *d2, double *e2, double **p1,\
                double *p2, double *P, int C1, int r, double **D, \
                int *s5, int noloops)
{
	int i, j;
    double d9=0.0;
    char outline[100];

	sprintf(outline,"Maximum Likelihood Iteration Number %2d",noloops);
	FrmOutPut->RichOutPut->Lines->Add(outline);
     for (j = 0; j < C1; j++)
     {
          expdcnt[j] = 0.0;
          d2[j] = 0.0;
     }
     for (i = 0; i < r; i++)
     {
         for (j = 0; j < C1; j++)
             p1[i][j] = exp(p2[j] - P[i]) / (1.0 + exp(p2[j] - P[i]));
     }
     for (j = 0; j < C1; j++)
     {
          for (i = 0; i < r; i++)
          {
               expdcnt[j] += p1[i][j];
               // expected number in score group
               D[i][j] = exp(p2[j] - P[i]) / (sqrt(1.0 + exp(p2[j] - P[i])));
               d2[j] += D[i][j]; // rate of change value
          }
     }
     for (j = 0; j < C1; j++)
     {
          e2[j] = expdcnt[j] - s5[j];  // discrepency
          e2[j] /= d2[j];
          if (fabs(e2[j]) > d9) d9 = fabs(e2[j]);
          p2[j] -= e2[j];
     }
     /*
	'     writeln
	'     writeln('Actual and Estimated Scores')
	'     writeln
	'     writeln('Score  Estimated  Adjustment')
	'     for j = 1 to c1 do
	'         writeln(s5(j):3,'   ',expdcnt(j):6:2,'       ',e2(j):6:2)
	'     writeln
    */
} // end of maxability

//--------------------------------------------------------------------------

double MAXITEM(double *R1, double *d1, double **p1, double **D, double *e1,\
             double *p2, double *P, int *S, int *rowtot, int T, int r, int C1)
{
	int i, j;
    double d9 = 0.0;

     for (i = 0; i < r; i++)
     {
          R1[i] = 0.0;
          d1[i] = 0.0;
     }
     for (i = 0; i < r; i++)
         for (j = 0; j < C1; j++)
             p1[i][j] = exp(p2[j] - P[i]) / (1.0 + exp(p2[j] - P[i]));
     for (i = 0; i < r; i++)
     {
          for (j = 0; j < C1; j++) R1[i] = R1[i] + S[j] * p1[i][j];
          e1[i] = R1[i] - (T - rowtot[i]);
     }
     // e1(i) contains the difference between actual and expected passes
     // now calculate derivatives and adjustments
     for (i = 0; i < r; i++)
     {
          for (j = 0; j < C1; j++)
          {
               D[i][j] = exp(p2[j] - P[i]) / (sqrt(1.0 + exp(p2[j] - P[i])));
               d1[i] += S[j] * D[i][j];
          }
          e1[i] /= d1[i];
          // adjustment for item difficulty estimates
          if (fabs(e1[i]) > d9) d9 = fabs(e1[i]);
          P[i] += e1[i];
     }
     /*
	'     writeln
	'     writeln('actual and estimated items right')
	'     writeln
	'     writeln('item  actual  estimated  adjustment')
	'     for i = 1 to r do
	'     begin
	'          writeln(i:3,'  ',(t-rowtot(i)):3,'           ',e1(i):6:2)
	'     end
	'     writeln
    */
    return d9;
} // end of maxitem subroutine

//--------------------------------------------------------------------------

void MAXOUT(int r, int C1, int *i5, int *s5, double *P, double *p2)
{
	int i, j;
    char outline[100];

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Maximum Likelihood Estimates");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Item  Log Difficulty");
     for (i = 0; i < r; i++)
     {
         sprintf(outline,"%3d     %6.2f",i5[i],P[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Score   Log Ability");
     for (j = 0; j < C1; j++)
     {
         sprintf(outline,"%3d    %6.2f",s5[j],p2[j]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
} // end  of maxout

//--------------------------------------------------------------------------

void PROX(double *P, double *p2, int k, int r, int C1, double *L1, \
          double yexpand, double xexpand, double *g, int T, int *rowtot, \
          int *i5, int *s5)
{
	double tx, rowtx, errorterm, stderror;
	int i, j;
	char outline[100];

    FrmOutPut->RichOutPut->Lines->Add(" ");
     for (i = 0; i < r; i++) P[i] = L1[i] * yexpand;
     for (j = 0; j < C1; j++) p2[j] = g[j] * xexpand;
     if (RaschForm->ProxChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add( "Prox values and Standard Errors" );
        FrmOutPut->RichOutPut->Lines->Add(" ");
        FrmOutPut->RichOutPut->Lines->Add("Item     Scale Value     Standard Error");
     }
     tx = T;
     for (i = 0; i < r; i++)
     {
         rowtx = rowtot[i];
         errorterm = tx / ((tx - rowtx) * rowtx);
         //writeln(lst,'row = ',i:2,' yexpand = ',yexpand:8:2,
         //      total = ',t:8,' row total = ',rowtot(i):8,
         //      error term = ',errorterm:8:2)  }
         stderror = yexpand * sqrt(errorterm);
         if (RaschForm->ProxChk->Checked)
         {
            sprintf(outline,"%3d    %7.3f          %7.3f",i5[i],P[i],stderror);
            FrmOutPut->RichOutPut->Lines->Add(outline);
         }
     }
     if (RaschForm->ProxChk->Checked)
     {
        sprintf(outline,"Y expansion factor = %8.4f",yexpand);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Score    Scale Value     Standard Error");
     }
     for (j = 0; j < C1; j++)
     {
          stderror = xexpand * sqrt(double(k) / (double(s5[j]) * double(k - s5[j])));
          if (RaschForm->ProxChk->Checked)
          {
             sprintf(outline,"%3d    %7.3f         %7.3f",s5[j],p2[j],stderror);
             FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     if (RaschForm->ProxChk->Checked)
     {
        sprintf(outline,"X expansion factor = %8.4f",xexpand);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }
} //end of prox


//---------------------------------------------------------------------------

void REDUCE(int k, int &r, int &T, int &C1, int *i5, int *rowtot, int *s5,\
            int **f, int *S)
{ // NOW REDUCE THE MATRIX BY ELIMINATING 0 OR 1 ROWS AND COLUMNS

	bool Done;
	int check, i, j, column, row;
	char outline[100];

    FrmOutPut->RichOutPut->Lines->Add("");

    //Store item numbers in i5 array and initialize row totals
     for (i = 0; i < k; i++)
     {
          i5[i] = i+1;
          rowtot[i] = 0;
     }

     //Store group numbers in s5 array
     r = k;
     T = 0;
     C1 = k - 1; // No. of score groups (all correct group eliminated)
     for (j = 0; j < C1; j++)
     {
          s5[j] = j+1;
          T = T + S[j];
     }

     //Get row totals of the failures matrix (item totals)
     for (i = 0; i < r; i++)
         for (j = 0; j < C1; j++) rowtot[i] = rowtot[i] + f[i][j];

     // now check for item elimination
     Done = false;
     while (!Done)
     {
       for (i = 0; i < r; i++)
       {
          if ((rowtot[i] == 0) || (rowtot[i] == T))
          {
               sprintf(outline,"Row %3d for item %3d eliminated.",i+1,i5[i]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               if (i < r-1)
               {
                    for (j = i; j < (r - 1); j++) //move rows up to replace row i
                    {
                        for (column = 0; column < C1; column++)
                            f[j][column] = f[j + 1][column];
                        rowtot[j] = rowtot[j + 1];
                        i5[j] = i5[j + 1];
                    }
               }
               r = r - 1;
          } // end if
       } // end for i
       check = 1;
       for (i = 0; i < r; i++)
          if ((rowtot[i] == 0) || (rowtot[i] == T)) check = 0;
       if (check == 1) Done = true;
     }

     // check for group elimination
     Done = false;
     j = 0;
     while (!Done)
     {
          if (S[j] == 0)
          {
               sprintf(outline,"Column %3d score group %3d eliminated - total group count = %3d",\
                       j+1, s5[j], S[j]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               if (j < C1-1)
               {
                     for (i = j; i < (C1 - 1); i++)
                     {
                          for (row = 0; row < r; row++)
                              f[row][i] = f[row][i + 1];
                          S[i] = S[i + 1];
                          s5[i] = s5[i + 1];
                     }
                     C1 = C1 - 1;
               }
               else  C1 = C1 - 1;
          }
          if (S[j] > 0) j = j + 1;
          if (j >= C1-1)
          {
               while (S[C1-1] <= 0) C1 = C1 - 1;
               Done = true;
          }
     }
     sprintf(outline,"Total number of score groups = %4d",C1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
	 FrmOutPut->RichOutPut->Lines->Add("");
} // end of reduce

//-------------------------------------------------------------------------

void  SLOPES(double *rptbis, double *rbis, double *slope, int N, double sumx,\
             double sumx2, double *sumxy, int r, double *xsqr, double *mean)
{
	double propi, term1, term2, z, Y;
    int j;

     term1 = N * sumx2 - sumx * sumx;
     for (j = 0; j < r; j++)
     {
          rptbis[j] = N * sumxy[j] - mean[j] * sumx;
          term2 = N * xsqr[j] - (mean[j] * mean[j]);
          if ((term1 > 0) && (term2 > 0))
            rptbis[j] = rptbis[j] / sqrt(term1 * term2);
          else rptbis[j] = 1.0;
          propi = mean[j] / N;
          if ((propi > 0.0) && (propi < 1.0)) z = inversez(propi);
          if (propi <= 0.0) z = -3.0;
          if (propi >= 1.0) z = 3.0;

          Y = ord(z);
          if (Y > 0) rbis[j] = rptbis[j] * (sqrt(propi * (1.0 - propi)) / Y);
          else rbis[j] = 1.0;
          if (rbis[j] <= -1.0) rbis[j] = -0.99999;
          if (rbis[j] >= 1.0) rbis[j] = 0.99999;
          slope[j] = rbis[j] / sqrt(1.0 - (rbis[j] * rbis[j]));
     }
} // end of slopes procedure

//---------------------------------------------------------------------------

void TESTFIT(int r, int C1, int **f, int *S, double *P, double *p2, int T )
{

	double ct, ch, prob;
    int i, j;
    char outline[100];

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add( "Goodness of Fit Test for Each Item");
     FrmOutPut->RichOutPut->Lines->Add("Item  Chi-Squared  Degrees of  Probability");
     FrmOutPut->RichOutPut->Lines->Add("No.   Value        Freedom     of Larger Value");
     ct = 0.0;
     for (i = 0; i < r; i++)
     {
          ch = 0.0;
          for (j = 0; j < C1; j++)
               ch = ch + (exp(p2[j] - P[i]) * f[i][j]) + (exp(P[i] - \
                    p2[j]) * (S[j] - f[i][j]));
          prob = 1.0 - chisquaredprob(ch, T - C1);
          sprintf(outline,"%3d   %8.2f     %3d          %6.4f",i+1,ch,(T-C1),prob);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          ct = ct + ch;
     }
     FrmOutPut->RichOutPut->Lines->Add("");
  	 //   prob = 1.0 - chisquaredprob(ct,(t*r-r-c1))
     //   writeln(lst,'Total ',ct:8:2,'        ',(t*r-r-c1):4,'        ',
     //                prob:6:4)  }
     //   writeln(lst)
     //   writeln(lst,'End of Analysis')
} // end of testfit

//---------------------------------------------------------------------------

void plot(double **xyarray, int arraysize, char *Title, int Vdivisions,\
          int Hdivisions)
{

    int i;
    float xvalue, yvalue;

    // Allocate space for point sets of means
    GetDblMatMem(GraphForm->Xpoints,1,arraysize);
    GetDblMatMem(GraphForm->Ypoints,1,arraysize);
    GraphForm->Heading = Title;
    GraphForm->XTitle = "log ability";
    GraphForm->YTitle = "Information";
    GraphForm->nosets = 1;
    GraphForm->nbars = arraysize;
    GraphForm->barwideprop = 1.0;
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clLtGray;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowLeftWall = true;
    GraphForm->ShowRightWall = true;
    GraphForm->ShowBottomWall = true;
    GraphForm->ShowBackWall = true;
    GraphForm->AutoScale = true;
    GraphForm->miny = 0.0;
    GraphForm->maxy = 0.0;
    GraphForm->GraphType = 6;  // 2D Line graph
    GraphForm->PtLabels = false;
    for (i=0; i < arraysize; i++)
    {
        xvalue = xyarray[i][0];
        GraphForm->Xpoints[0][i] = xvalue;
        yvalue = xyarray[i][1];
        GraphForm->Ypoints[0][i] = yvalue;
    }
    GraphForm->ShowModal();
    // clean up the heap
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
/*
    AnsiString ValTitle;
    FrmTChart->Series1->Active = false;
    FrmTChart->Series3->Active = false;
    FrmTChart->Series2->Active = false;
    FrmTChart->Series4->Active = true;
    FrmTChart->Series5->Active = false;
    FrmTChart->Series4->Clear();
    for (int i = 0; i < arraysize; i++)
        FrmTChart->Series4->AddXY( xyarray[i][0],xyarray[i][1],"", clTeeColor);
    FrmTChart->Chart1->Title->Text->Clear();
    ValTitle = Title;
    FrmTChart->Chart1->Title->Text->Add(ValTitle);
    FrmTChart->Chart1->LeftAxis->Title->Caption = "INFORMATION";
    FrmTChart->Chart1->BottomAxis->Title->Caption = "LOG ABILITY";
    FrmTChart->ShowModal();
*/
}  //end plot subroutine

//--------------------------------------------------------------------------

void PLOTINFO(int k, int r, double **info, double **A, double *slope, \
              double *P)
{
	double min, max, cg, hincrement, Ymax, elg, term1, term2, jx;
	char headstring[256], valstring[256];
    int i, j, jj, size;

     min = -3.5;
     max = 3.5;
     hincrement = (max - min) / 50;
     cg = 0.2;
     Ymax = 0;
     for (i = 0; i < r; i++) // item loop
     {
          jj = 0;
          jx = min;
          while (jx <= (max + hincrement))
          {
               if (slope[i] > 30) slope[i] = 30;
               elg = 1.7 * slope[i] * (P[i] - jx);
               elg = exp(elg);
               term1 = 2.89 * (slope[i]) * (1.0 - cg) * (slope[i]) * (1.0 - cg);
               term2 = (cg + elg) * (1.0 + 1.0 / elg) * (1.0 + 1.0 / elg);
               info[i][jj] = term1 / term2;
               if (info[i][jj] > Ymax) Ymax = info[i][jj];
               jj = jj + 1;
               jx = jx + hincrement;
          }
          size = jj-1;
     }
     for (i = 0; i < r; i++) //item loop
     {
          strcpy(headstring,"Item Information Function for Item ");
          sprintf(valstring,"%3d",i+1);
          strcat(headstring,valstring);
          for (j = 0; j < size; j++)
          {
                A[j][0] = min + (hincrement * j );
                A[j][1] = info[i][j];
          }
          plot(A, size, headstring, 50, 50);
          //response = MsgBox("Print item?", 36, "PRINT?")
          //If response = IDYES Then GraphOut.PrintForm
     }
} //end of PlotInfo


//-----------------------------------------------------------------------------

void rasch(int NoVariables, int NoCases, int noselected, int *selected)
{
     int noloops;
     int k1, N, C1, r,  T;
     double sumx, sumx2;
     double v1, v2, xexpand, yexpand, d9;
     double min, max;
     int *X, *rowtot;
     int *itemfail, *itempass, *grpfail, *grppass, *S, *s5, *i5;
     int **f; // frequency matrix of no of cases each item correct in each group
     double *mean, *xsqr, *sumxy, *L, *L1, *L2, *g, *g2, *f2, *P, *p2, *R1, *d1;
     double **p1, **D, *e1, *expdcnt, *d2, *e2, *rptbis, *rbis, *slope, **info;
     double **A;
     try
     {
        rptbis = new double[noselected];
        rbis = new double[noselected];
        slope = new double[noselected];
        e2 = new double[noselected];
        d2 = new double[noselected];
        expdcnt = new double[noselected];
        e1 = new double[noselected];
        L = new double[noselected];
        L1 = new double[noselected];
        L2 = new double[noselected];
        g = new double[noselected];
        g2 = new double[noselected];
        f2 = new double[noselected];
        P = new double[noselected];
        p2 = new double[noselected];
        R1 = new double[noselected];
        d1 = new double[noselected];
    	   X = new int[NoCases];
        rowtot = new int[noselected];
        mean = new double[noselected];
        xsqr = new double[noselected];
        sumxy = new double[noselected];
        S = new int[noselected+2];
        s5 = new int[noselected];
        i5 = new int[noselected];
    	   itemfail = new int[noselected];
        itempass = new int[noselected];
        grpfail = new int[noselected];
        grppass = new int[noselected];
        f = new int *[noselected];
        for (int i = 0; i < noselected; i++) f[i] = new int[noselected+2];
    	   p1 = new double *[noselected];
        for (int i = 0; i < noselected; i++) p1[i] = new double[noselected];
        D = new double *[noselected];
        for (int i = 0; i < noselected; i++) D[i] = new double[noselected];
        info = new double *[noselected];
        for (int i = 0; i < noselected; i++) info[i] = new double[60];
        A = new double*[60];
        for (int i = 0; i < 60; i++) A[i] = new double[2];
	}
     catch (...) // This block entered only if xalloc is thrown.
     {
    	   ShowMessage("Could not allocate memory.");
        return;
	}

	if (NoVariables < 1)
     {
    	   ShowMessage("You must have data in your data grid!");
        return;
     }

     bool finished;

	//begin { main program }
     finished = false;
     N = NoCases;
     k1 = noselected;

     GETSCORES(noselected, selected, NoCases, f, mean, xsqr, sumxy, S, X,
                sumx, sumx2, N);
     REDUCE(k1, r, T, C1, i5, rowtot, s5, f, S);
     FREQUENCIES(C1, r, f, rowtot, i5, s5, T, S );
     v1 = v2 = 0.0;
     GETLOGS(L, L1, L2, g, g2, f2, rowtot, k1, s5, S, T, r, C1, v1, v2);
     EXPAND(v1, v2, xexpand, yexpand);
     PROX(P, p2, k1, r, C1, L1, yexpand, xexpand, g, T, rowtot, i5, s5);
     // start iterations for the maximum-liklihood (Newton-Rhapson procedure)
     // estimates
     noloops = 0;

     while (!finished)
     {
           d9 = MAXITEM(R1, d1, p1, D, e1, p2, P, S, rowtot, T, r, C1);
           if (d9 < 0.01) finished = true;
           else MAXABILITY(expdcnt, d2, e2, p1, p2, P, C1, r, D, s5, noloops);
           noloops = noloops + 1;
           if (noloops > 25)
           {
           	 ShowMessage("Maximum Liklihood failed to converge after 25 iterations");
            	 finished = true;
           }
      }
      MAXOUT(r, C1, i5, s5, P, p2);
      TESTFIT(r, C1, f, S, P, p2, T);
      SLOPES(rptbis, rbis, slope, N, sumx, sumx2, sumxy, r, xsqr, mean);
      ANALYZE(itemfail, grpfail, f, T, grppass, itempass, r, C1, min, max, p2);
      if (RaschForm->PlotItemDifChk->Checked) PlotItems(r, i5, P);
      if (RaschForm->PlotLogAbilityChk->Checked) PlotScrs(C1, s5, p2);
      if (RaschForm->PlotItemInfoChk->Checked) PLOTINFO(k1, r, info, A, slope, P);
      FinishIt(r, i5, rptbis, rbis, slope, mean, itemfail, P);
      //response = MsgBox("Save Rasch item and ability estimates (y or n) ? ", 36, "SAVE ESTIMATES")
      //If response = IDYES Then
      //     SAVEESTIMATES();

	for (int i = 0; i < 60; i++) delete[] A[i];
     delete[] A;
	for (int i = 0; i < noselected; i++) delete[] info[i];
     delete[] info;
	for (int i = 0; i < noselected; i++) delete[] D[i];
     delete[] D;
     for (int i = 0; i < noselected; i++) delete[] p1[i];
     delete[] p1;
     for (int i = 0; i < noselected; i++) delete[] f[i];
     delete[] f;
     delete[] grppass;
     delete[] grpfail;
     delete[] itempass;
     delete[] itemfail;
     delete[] i5;
     delete[] s5;
     delete[] S;
     delete[] sumxy;
     delete[] xsqr;
     delete[] mean;
     delete[] rowtot;
     delete[] X;
     delete[] d1;
     delete[] R1;
     delete[] p2;
     delete[] P;
	delete[] f2;
     delete[] g2;
     delete[] g;
	delete[] L2;
     delete[] L1;
     delete[] L;
     delete[] e1;
     delete[] expdcnt;
     delete[] d2;
     delete[] e2;
     delete[] slope;
     delete[] rbis;
     delete[] rptbis;
} // end of RASCH analysis PROGRAM

//-----------------------------------------------------------------------

void PlotItems(int r, int *i5, double *P)
{
    int i;
    double *xvalues;

    xvalues = new double[r];
    GetDblMatMem(GraphForm->Ypoints,1,r);
    GetDblMatMem(GraphForm->Xpoints,1,r);
    for (i = 1; i <= r; i++)
    {
        xvalues[i-1] = i5[i-1];
        GraphForm->Xpoints[0][i-1] = xvalues[i-1];
        GraphForm->Ypoints[0][i-1] = P[i-1];
    }
    GraphForm->nosets = 1;
    GraphForm->nbars = r;
    GraphForm->Heading = "LOG DIFFICULTIES FOR ITEMS";
    GraphForm->XTitle = "ITEM";
    GraphForm->YTitle = "LOG DIFFICULTY";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = true;
    GraphForm->GraphType = 2; // bar chart
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    delete[] xvalues;
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
}
//-------------------------------------------------------------------

void PlotScrs(int C1, int *s5, double *p2)
{
    int i;
    double *xvalues;

    xvalues = new double[C1];
    GetDblMatMem(GraphForm->Ypoints,1,C1);
    GetDblMatMem(GraphForm->Xpoints,1,C1);
    for (i = 1; i <= C1; i++)
    {
        xvalues[i-1] = s5[i-1];
        GraphForm->Xpoints[0][i-1] = xvalues[i-1];
        GraphForm->Ypoints[0][i-1] = p2[i-1];
    }
    GraphForm->nosets = 1;
    GraphForm->nbars = C1;
    GraphForm->Heading = "LOG ABILITIES FOR SCORE GROUPS";
    GraphForm->XTitle = "SCORE";
    GraphForm->YTitle = "LOG ABILITY";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = true;
    GraphForm->GraphType = 2; // bar chart
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    delete[] xvalues;
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
}
//-------------------------------------------------------------------
void PlotTest(double **TestInfo, int arraysize, AnsiString Title,
              int Vdivisions, int Hdivisions)
{
    int i;
    double *xvalue, *yvalue;

    // Allocate space for point sets of means
    xvalue = new double[arraysize];
    yvalue = new double[arraysize];
    GetDblMatMem(GraphForm->Ypoints,1,arraysize);
    GetDblMatMem(GraphForm->Xpoints,1,arraysize);

    // store points for means
    for (i = 1; i <= arraysize; i++)
    {
         yvalue[i-1] = TestInfo[i-1][1];
         xvalue[i-1] = TestInfo[i-1][0];
         GraphForm->Ypoints[0][i-1] = yvalue[i-1];
         GraphForm->Xpoints[0][i-1] = xvalue[i-1];
    }
    GraphForm->nosets = 1;
    GraphForm->nbars = arraysize;
    GraphForm->Heading = Title;
    GraphForm->XTitle = "log ability";
    GraphForm->YTitle = "Info";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = true;
    GraphForm->GraphType = 5; // 2d line chart
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();

    delete[] xvalue;
    delete[] yvalue;
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
}  //end plot subroutine

