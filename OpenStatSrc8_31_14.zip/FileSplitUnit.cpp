//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "FileSplitUnit.h"
#include "stdio.h"
#include "DictionaryUnit.h"

extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSplitFileForm *SplitFileForm;
//---------------------------------------------------------------------------
__fastcall TSplitFileForm::TSplitFileForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSplitFileForm::FormShow(TObject *Sender)
{
        VarList->Clear();
        VarList2->Clear();
        FileOneList->Clear();
        FileTwoList->Clear();
        FirstFileEdit->Text = "FirstFile.TEX";
        SecondFileEdit->Text = "SecondFile.TEX";
        SeqNoEdit->Text = "";
        SelVarEdit->Text = "";
        SelValueEdit->Text = "";
        VertSelGrp->ItemIndex = 0;
        SplitTypeGrp->ItemIndex = 0;
        Label4->Visible = false;
        Panel2->Visible = false;
        for (int i = 1; i <= NoVariables; i++)
        {
                VarList->Items->Add(MainForm->Grid->Cells[i][0]);
                VarList2->Items->Add(MainForm->Grid->Cells[i][0]);
        }
        VarList->Visible = false;
        VarLabel->Visible = false;
        SelVarEdit->Visible = false;
        SelValueEdit->Visible = false;
        VertSelGrp->Visible = true;
        SeqNoEdit->Visible = true;
        Label6->Visible = false;
        Label7->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSplitFileForm::ResetBtnClick(TObject *Sender)
{
        FormShow(this);        
}
//---------------------------------------------------------------------------
void __fastcall TSplitFileForm::SplitTypeGrpClick(TObject *Sender)
{
        if (SplitTypeGrp->ItemIndex == 0)
        {
                Label3->Visible = true;
                Panel1->Visible = true;
                Label4->Visible = false;
                Panel2->Visible = false;
        }
        else
        {
                Label3->Visible = false;
                Panel1->Visible = false;
                Label4->Visible = true;
                Panel2->Visible = true;
        }

}
//---------------------------------------------------------------------------
void __fastcall TSplitFileForm::ComputeBtnClick(TObject *Sender)
{
        int nrows1, nrows2, ncols1, ncols2;
        int type = SplitTypeGrp->ItemIndex;
        int VertSelType, pos, SelVarPos;
        int *dicpos;
        AnsiString FileOneName = FirstFileEdit->Text;
        AnsiString FileTwoName = SecondFileEdit->Text;
        AnsiString astring;
        AnsiString VarName;
        AnsiString SelVarValue;
        FILE *OutFile1;
        FILE *OutFile2;
        char tabchar = '\t';
        char newline = '\n';

        dicpos = new int[NoVariables];
        
        // Open both output files for writing .TEX files
        OutFile1 = fopen(FileOneName.c_str(),"wt");
        OutFile2 = fopen(FileTwoName.c_str(),"wt");

        if (type == 0) // vertical split
        {
                ncols1 = NoVariables;
                ncols2 = NoVariables;
                VertSelType = VertSelGrp->ItemIndex;
                if (VertSelType == 0) // select 1 to N cases
                {
                        nrows1 = StrToInt(SeqNoEdit->Text);
                        nrows2 = NoCases - nrows1;
                        fprintf(OutFile1,"%d%c",nrows1,tabchar);
                        fprintf(OutFile1,"%d%c",ncols1,newline);
                        fprintf(OutFile2,"%d%c",nrows2,tabchar);
                        fprintf(OutFile2,"%d%c",ncols2,newline);

                        // print dictionary
                        for (int i = 1; i <= ncols1; i++) // dictionary rows
                        {
      	                        for (int j = 0; j < 7; j++) // dictionary columns
                                {
         	                        astring = Trim(DictionaryForm->DGrid->Cells[j][i]);
                                        fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                                        fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                                }
                                fprintf(OutFile1,"%c",newline);
                                fprintf(OutFile2,"%c",newline);
                        }

                        // print data to first file
                        for (int i = 0; i <= nrows1; i++)
                        {
                                for (int j = 0; j <= ncols1; j++)
                                {
                                        astring = Trim(MainForm->Grid->Cells[j][i]);
                                        fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                                }
                                fprintf(OutFile1,"%c",newline);
                        }
                        // print data to second file
                        // print grid row 0 first
                        for (int j = 0; j <= ncols2; j++)
                        {
                                astring = Trim(MainForm->Grid->Cells[j][0]);
                                fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                        }
                        fprintf(OutFile2,"%c",newline);
                        for (int i = nrows1+1; i <= nrows1 + nrows2; i++)
                        {
                                for (int j = 0; j <= ncols2; j++)
                                {
                                        astring = Trim(MainForm->Grid->Cells[j][i]);
                                        fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                                }
                                fprintf(OutFile2,"%c",newline);
                        }

                } // end if vert select type = 0;
                else // vertical selection type = 1;
                {
                        VarName = SelVarEdit->Text;
                        // get position of variable in the main grid
                        for (int i = 1; i <= NoVariables; i++)
                                if (VarName == MainForm->Grid->Cells[i][0]) SelVarPos = i;
                        // get value of the variable for selection
                        SelVarValue = SelValueEdit->Text;
                        // get number of cases with the selection value
                        nrows1 = 0;
                        for (int i = 1; i <= NoCases; i++)
                                if (SelVarValue == Trim(MainForm->Grid->Cells[SelVarPos][i])) nrows1++;
                        nrows2 = NoCases - nrows1;
                        fprintf(OutFile1,"%d%c",nrows1,tabchar);
                        fprintf(OutFile1,"%d%c",ncols1,newline);
                        fprintf(OutFile2,"%d%c",nrows2,tabchar);
                        fprintf(OutFile2,"%d%c",ncols2,newline);
                        // print dictionary
                        for (int i = 1; i <= ncols1; i++) // dictionary rows
                        {
      	                        for (int j = 0; j < 7; j++) // dictionary columns
                                {
         	                        astring = Trim(DictionaryForm->DGrid->Cells[j][i]);
                                        fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                                        fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                                }
                                fprintf(OutFile1,"%c",newline);
                                fprintf(OutFile2,"%c",newline);
                        }
                        // copy row 0 to data files
                        for (int j = 0; j <= NoVariables; j++)
                        {
                                astring = Trim(MainForm->Grid->Cells[j][0]);
                                fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                                fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                                fprintf(OutFile1,"%c",newline);
                                fprintf(OutFile2,"%c",newline);
                        }
                        // select cases that have the selection value
                        for (int i = 1; i <= NoCases; i++)
                        {
                                if (SelVarValue == Trim(MainForm->Grid->Cells[SelVarPos][i]))
                                {  // file 1
                                        for (int j = 0; j <= ncols1; j++)
                                        {
                                                astring = Trim(MainForm->Grid->Cells[j][i]);
                                                fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                                        }
                                        fprintf(OutFile1,"%c",newline);
                                }
                                else // file 2
                                {
                                        for (int j = 0; j <= ncols2; j++)
                                        {
                                                astring = Trim(MainForm->Grid->Cells[j][i]);
                                                fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                                        }
                                        fprintf(OutFile2,"%c",newline);
                                }
                        }
                }
        } // end if type = 0
        else // horizontal split
        {
                nrows1 = NoCases;
                nrows2 = NoCases;
//                FileOneList->Items->Add(VarName);
//                FileTwoList->Items->Add(VarName);
                ncols1 = FileOneList->Items->Count;
                ncols2 = FileTwoList->Items->Count;
                fprintf(OutFile1,"%d%c",nrows1,tabchar);
                fprintf(OutFile1,"%d%c",ncols1,newline);
                fprintf(OutFile2,"%d%c",nrows2,tabchar);
                fprintf(OutFile2,"%d%c",ncols2,newline);
                // print dictionary for file 1
                // find dictionary entries for variables in first file
                for (int j = 1; j <= NoVariables; j++)
                {
                        for (int k = 0; k < ncols1; k++)
                        {
                                if (MainForm->Grid->Cells[j][0] == FileOneList->Items->Strings[k])
                                        dicpos[k] = j;
                        }
                }

                for (int i = 1; i <= ncols1; i++) // dictionary rows
                {
                        pos = dicpos[i-1];
                        for (int j = 0; j < 7; j++) // dictionary columns
                        {
                                astring = Trim(DictionaryForm->DGrid->Cells[j][pos]);
                                fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                        }
                        fprintf(OutFile1,"%c",newline);
                }
                // write data for file 1
                for (int i = 0; i <= nrows1; i++)
                {
                        astring = Trim(MainForm->Grid->Cells[0][i]);
                        fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                        for (int j = 1; j <= ncols1; j++)
                        {
                                pos = dicpos[j-1];
                                astring = Trim(MainForm->Grid->Cells[pos][i]);
                                fprintf(OutFile1,"%s%c",astring.c_str(),tabchar);
                        }
                        fprintf(OutFile1,"%c",newline);
                }
                // do same as above for second file
                // find dictionary entries for variables in second file
                for (int j = 1; j <= NoVariables; j++)
                {
                        for (int k = 0; k < ncols2; k++)
                        {
                                if (MainForm->Grid->Cells[j][0] == FileTwoList->Items->Strings[k])
                                        dicpos[k] = j;
                        }
                }

                for (int i = 1; i <= ncols2; i++) // dictionary rows
                {
                        pos = dicpos[i-1];
                        for (int j = 0; j < 7; j++) // dictionary columns
                        {
                                astring = Trim(DictionaryForm->DGrid->Cells[j][pos]);
                                fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                        }
                        fprintf(OutFile2,"%c",newline);
                }
                // write data for file 2
                for (int i = 0; i <= nrows2; i++)
                {
                        astring = Trim(MainForm->Grid->Cells[0][i]);
                        fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                        for (int j = 1; j <= ncols2; j++)
                        {
                                pos = dicpos[j-1];
                                astring = Trim(MainForm->Grid->Cells[pos][i]);
                                fprintf(OutFile2,"%s%c",astring.c_str(),tabchar);
                        }
                        fprintf(OutFile2,"%c",newline);                }
        }
        fclose(OutFile1);
        fclose(OutFile2);
        delete[] dicpos;
}
//---------------------------------------------------------------------------
void __fastcall TSplitFileForm::VarListClick(TObject *Sender)
{
        int isel = VarList->ItemIndex;
        SelVarEdit->Text = VarList->Items->Strings[isel];
}
//---------------------------------------------------------------------------

void __fastcall TSplitFileForm::VertSelGrpClick(TObject *Sender)
{
        if (VertSelGrp->ItemIndex == 0)
        {
                VarList->Visible = false;
                VarLabel->Visible = false;
                SelVarEdit->Visible = false;
                SelValueEdit->Visible = false;
                SeqNoEdit->Visible = true;
                Label6->Visible = false;
                Label7->Visible = false;
        }
        else
        {
                VarList->Visible = true;
                VarLabel->Visible = true;
                SelVarEdit->Visible = true;
                SelValueEdit->Visible = true;
                SeqNoEdit->Visible = false;
                Label6->Visible = true;
                Label7->Visible = true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TSplitFileForm::File1InBtnClick(TObject *Sender)
{
        int isel = VarList2->ItemIndex;
        FileOneList->Items->Add(VarList2->Items->Strings[isel]);
}
//---------------------------------------------------------------------------

void __fastcall TSplitFileForm::File1OutBtnClick(TObject *Sender)
{
        int isel = FileOneList->ItemIndex;
        if (isel >= 0)
                VarList2->Items->Add(FileOneList->Items->Strings[isel]);
}
//---------------------------------------------------------------------------

void __fastcall TSplitFileForm::File2InBtnClick(TObject *Sender)
{
        int isel = VarList2->ItemIndex;
        FileTwoList->Items->Add(VarList2->Items->Strings[isel]);
}
//---------------------------------------------------------------------------

void __fastcall TSplitFileForm::File2OutBtnClick(TObject *Sender)
{
        int isel = FileTwoList->ItemIndex;
        if (isel >= 0)
                VarList2->Items->Add(FileTwoList->Items->Strings[isel]);
}
//---------------------------------------------------------------------------

