//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DateFunc.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
// #include "local.h"

/****************************************************************************
 * The following macro returns 1 if the year given (with century) is a leap
 * year, else 0.
 ****************************************************************************/

#define leap_year(y) ((y)%4 == 0 && ((y)%100 != 0 || (y)%400 == 0))

/****************************************************************************
 * itlib/date3.c	ymd_to_date() function.
 ****************************************************************************/

static	const unsigned char month_tab[2][13] ={
	{0, 31,	28, 31,	30, 31,	30, 31,	31, 30,	31, 30,	31},
	{0, 31,	29, 31,	30, 31,	30, 31,	31, 30,	31, 30,	31}
};

static const short it_cum_day_tab[2][13] = {
	{0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365},
	{0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366},
};

/****************************************************************************
 * ymd_to_date()
 ****************************************************************************/


//IT_DATE STDCALL CONSTRTN
long ymd_to_date(int year, int month, int day)
{
	int		tot;
	int		leap;

	/*************************************************************************
	 * If it's an invalid date, return a missing/NULL date.
	 *************************************************************************/

	if( !valid_ymd(year, month,day) ) return(0);

	/*************************************************************************
	 * It's cool.  Let's convert it to the number of days since Jan 1, 1970.
	 *************************************************************************/

	/* Set up correct century if not already in ccyy format */
	if( year >= 70 && year <= 99 ) {
		year += 1900;
	}

	if( year >= 0 && year <= 59) {
		year += 2000;
	}

	/* Do the calculation */
	leap = 0;
	if( leap_year(year) ) leap = 1;

	tot = day + it_cum_day_tab[leap][month-1] - 1; /* We want offset of zero */
	year--;
	leap = ((year) / 4) - (year / 100) + (year / 400) - 477;
	tot += leap * 366 + (year - 1969 - leap) * 365;

	return (tot);
}

/****************************************************************************
 * valid_ymd()	Return true if year, month, day is a valid date combination
 * 				and can be represented in an IT_DATE variable.
 ****************************************************************************/

#ifdef OS4680
pragma On(Use_reg_vars);
#endif

//IT_BOOLEAN STDCALL CONSTRTN

//-------------------------------------------------------------------

valid_ymd(int year, int month, int day)
{
	int leap;

	/************************************************************************
	 * If year is yy format in 1900s or 2000s, add century.
	 *
	 * (Note: If it's a yy format after 59 but before 70, it will not get
	 * converted to century and will (correctly) get thown out in the
	 * subsequent check for < 1970.)
	 ************************************************************************/

	if( year >= 70 && year <= 99 ) year += 1900;
	if( year >= 0 && year <= 59 ) year += 2000;

	/************************************************************************
	 * If it's less than Jan 2nd, 1970, it's less than we can represent.
	 ************************************************************************/

	if( year < 1970 ) return(0);
	if( year == 1970 && month == 1 && day == 1 ) return(0);

	/************************************************************************
	 * If it's greater than Spetember 18, 2059, it's more than we can
	 * (portably) represent.
	 ************************************************************************/

	if( year > 2059 ) return(0);
	if( year == 2059 ) {
		if( month > 9 ) return(0);
		if( month == 9 && day > 18 ) return(0);
	}

	/************************************************************************
	 * OK. We've proved that the date is within our range of representation.
	 * Now, we need to make sure it's a real date.  (eg: Not Feb 30.)
	 *
	 * First, ensure that it's a valid month.
	 ************************************************************************/

	if( month < 1 || month > 12 ) return(0);

	/************************************************************************
	 * Make sure that day is valid for this month & type of year.
	 ************************************************************************/

	leap = 0;
	if( leap_year(year) ) leap = 1;

	if( day < 1 || day > (int) month_tab[leap][month] ) return(0);

	/************************************************************************
	 * It's a groovy date.  Return true.
	 ************************************************************************/

	return(1);
}
//-------------------------------------------------------------------



