//---------------------------------------------------------------------------

#ifndef SLNDepreciationUnitH
#define SLNDepreciationUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TSLNDepreciationFrm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TEdit *CostEdit;
     TEdit *SalvageEdit;
     TEdit *LifeEdit;
     TEdit *DepreciationEdit;
     TButton *ComputeBtn;
     TButton *ResetBtn;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TSLNDepreciationFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSLNDepreciationFrm *SLNDepreciationFrm;
//---------------------------------------------------------------------------
#endif
