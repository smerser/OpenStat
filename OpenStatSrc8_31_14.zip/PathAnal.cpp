//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>

#include "PathAnal.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmPath *FrmPath;
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TFrmPath::TFrmPath(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::CausingInBtnClick(TObject *Sender)
{
     int index, count;
     AnsiString cellstring;
     int nocausing = ListBox2->Items->Count;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
//            count++;
            // find col. no. in grid and store in model causing sequence vector
            for (int j = 0; j < NoVariables; j++)
            {
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                {
                   causingseq[ModelNo-1][nocausing] = j+1;
                   nocausing++;
                }
            }
         }
     }

     CausingOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::CausedInBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox1->ItemIndex;
     cellstring = ListBox1->Items->Strings[index];
     CausedEdit->Text = cellstring;
     CausedOutBtn->Enabled = true;
     ModelDefined[ModelNo-1] = true;
     // find col no in grid of caused variable and store in caused vector
     for (int i = 0; i < NoVariables; i++)
     {
         if (cellstring == MainForm->Grid->Cells[i+1][0])
         {
            causedseq[ModelNo-1] = i+1;
         }
     }
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::CausedOutBtnClick(TObject *Sender)
{
     CausedEdit->Text = "";
     ModelDefined[ModelNo-1] = false;
     causedseq[ModelNo-1] = 0;
     if (ModelNo > 1) ModelNo--;
     ScrollBar1->Position = ModelNo;
     ModelNoEdit->Text = ModelNo;
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::CausingOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox2->Items->Delete(index);
     // find col. no. in grid matched deleted item and remove from causing
     // sequence in the model
     for (int i = 0; i < NoVariables; i++)
     {
         if (cellstring == MainForm->Grid->Cells[i+1][0])
         {
            // find matching col.no. and reset to zero
            for (j = 0; j < NoVariables; j++)
            {
                if (causingseq[ModelNo-1][j] == i+1) causingseq[ModelNo-1][j] = 0;
            }
         }
     }
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::ScrollBar1Change(TObject *Sender)
{
     int col;
     AnsiString cellstring;

     if (ScrollBar1->Position > NoVariables) return;
     if (ScrollBar1->Position < ModelNo) // user wants back
     {
        ListBox2->Clear();
        CausedEdit->Text = "";
        ModelNo = ScrollBar1->Position;
        ModelNoEdit->Text = ModelNo;
        if (ModelDefined[ModelNo-1]) // model exists - reload data
        {
            col = causedseq[ModelNo-1];
            if (col != 0) // no caused variable if = 0
               CausedEdit->Text = MainForm->Grid->Cells[col][0];
            else CausedEdit->Text = "";
            for (int i = 0; i < NoVariables; i++)
            {
                col = causingseq[ModelNo-1][i];
                if (col != 0)
                {
                    cellstring = MainForm->Grid->Cells[col][0];
                    ListBox2->Items->Add(cellstring);
                }
            }
        }
     }
     if (ScrollBar1->Position > ModelNo)
     {
         ModelNo = ScrollBar1->Position;
         ModelNoEdit->Text = ModelNo;
         ListBox2->Clear();
         CausedEdit->Text = "";
         if (!ModelDefined[ModelNo-1])
         {
            CausedOutBtn->Enabled = false;
            CausingOutBtn->Enabled = false;
         }
         else // reset the existing model parameters
         {
              col = causedseq[ModelNo-1];
              if (col != 0) // no caused variable if = 0
                  CausedEdit->Text = MainForm->Grid->Cells[col][0];
              for (int i = 0; i < NoVariables; i++)
              {
                  col = causingseq[ModelNo-1][i];
                  if (col != 0)
                  {
                     cellstring = MainForm->Grid->Cells[col][0];
                     ListBox2->Items->Add(cellstring);
                  }
              }
         }
     }
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::OKBtnClick(TObject *Sender)
{
    int prtopts, size, count, IER;
    int NoIndep, dep, indep;
    double constant, df1, df2, SSt, SSres, MSres, VarEst, StdErrEst;
    double SSModel, F, ProbF, SSx, StdErrB;
    double *B;
    AnsiString cellstring;
    AnsiString *ColLabels;
    int result;

    ColLabels = new AnsiString[NoVariables];

    NoModels = 0;
    for (i = 0; i < NoVariables; i++) if (ModelDefined[i])NoModels++;
    nocaused = NoModels;

    // determine no. of variables causing each caused variable
    for (i = 0; i < NoModels; i++)
    {
        nocausing[i] = 0;
        for (j = 0; j < NoVariables; j++)
            if (causingseq[i][j] != 0) nocausing[i]++;
    }
    size = 0;
    for (i = 0; i < nocaused; i++) size += nocausing[i];

    try  {
        ColNoSelected = new int[NoVariables];
        WorkMat = new double *[NoVariables+1];
        for (i = 0; i < NoVariables+1; i++) WorkMat[i] = new double[NoVariables+1];
        WorkVector = new double[NoVariables+1];
        TempMat = new double *[NoVariables+1];
        for (i = 0; i < NoVariables+1; i++) TempMat[i] = new double[NoVariables+1];
	    PathCoef = new double *[NoVariables];
        for (i = 0; i < NoVariables; i++) PathCoef[i] = new double[NoVariables];
        IndMatrix = new double *[NoVariables];
        for (i = 0; i < NoVariables; i++) IndMatrix[i] = new double[NoVariables];
        InvMatrix = new double *[NoVariables+1];
        for (i = 0; i < NoVariables+1; i++) InvMatrix[i] = new double[NoVariables+1];
        e = new double *[NoVariables];
        for (i = 0; i < NoVariables; i++) e[i] = new double[NoVariables];
        W = new double *[NoVariables];
        for (i = 0; i < NoVariables; i++) W[i] = new double[NoVariables];
        causal = new int *[size];
        for (i = 0; i < size; i++) causal[i] = new int[2];
        beta = new double[NoVariables];
        v = new double[NoVariables];
        p = new double[size];
        exogenous = new int[NoVariables];
        causing = new int[NoVariables];
        B = new double[NoVariables];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Path Analysis","MEMORY!",MB_OK);
        exit (-1);
    }

    // get and show model parameters
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("PATH ANALYSIS RESULTS");
    FrmOutPut->RichOutPut->Lines->Add("");

    for (i = 0; i < nocaused; i++)
    {
        col = causedseq[i];
        strcpy(outline,"RESULTING VARIABLE: ");
        strcat(outline,MainForm->Grid->Cells[col][0].c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("     Due To Variables:");
        for (j = 0; j < nocausing[i]; j++)
        {
            col = causingseq[i][j];
            strcpy(outline,"    ");
            strcat(outline,MainForm->Grid->Cells[col][0].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }
    FrmOutPut->ShowModal();

    // get correlations among all variables selected for the analysis
    NoSelected = ListBox1->Items->Count;
    for (i = 0; i < NoSelected; i++)
    {
        cellstring = ListBox1->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0]) ColNoSelected[i] = j+1;
            //result = VarTypeChk(j+1,0);
            //if (result == 1) goto cleanup;
        }
    }
    for (i = 0; i < NoSelected; i++) ColLabels[i] = MainForm->Grid->Cells[ColNoSelected[i]][0];
    count = NoCases;
    prtopts = 2;  // matrix only printed
    if (ShowDescChk->Checked) prtopts = 1; // descriptives and matrix
    if (FileType != 3) // if not a matrix in the grid
    {
        IER = Correlations(means,stddevs,rmat,NoSelected,ColNoSelected,count,3,false,prtopts);
        if (IER == 1)
            Application->MessageBox("A variance of zero found for a variable.","ERROR",MB_OK);

        if (SaveRChkBox->Checked)
            SaveSqrMat(rmat, NoSelected, count, ColLabels, means, stddevs);
    }
    else // read the R matrix from the grid
    {
        for (i = 0; i < NoSelected; i++)
        {
            int rowno = ColNoSelected[i];
            for (j = 0; j < NoSelected; j++)
            {
                int colno = ColNoSelected[j];
                rmat[i][j] = atof(MainForm->Grid->Cells[rowno][colno].c_str());
                rmat[j][i] = rmat[i][j];
            }
        }
        for (i = 0; i < NoSelected; i++)
        {
            means[i] = 0.0;
            stddevs[i] = 1.0;
            rmat[i][i] = 1.0;
        }
        strcpy(outline,"Correlation Matrix");
        MatPrint(rmat, NoSelected, NoSelected, ColNoSelected, outline);
        FrmOutPut->ShowModal();
    }

    // initialize reconstruction matrix, weights matrix and path coefficients
    for (i = 0; i < NoVariables; i++)
    {
        for (j = 0; j < NoVariables; j++)
        {
            e[i][j] = 0.0;
            W[i][j] = 0.0;
            PathCoef[i][j] = 0.0;
        }
    }

    //Now, do the regression analysis for each model
    for(i = 0; i < nocaused; i++) // No. of models to calculate
    {
        row = causedseq[i]; //sequence no. of caused variable
        if (ShowModRChk->Checked)
        {
           sprintf(outline,"Regression results for variable %s",
                MainForm->Grid->Cells[row][0].c_str());
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }

        //Get vector of independent with dependent correlations
        for (j = 0; j < nocausing[i]; j++) //No. of predictors of variable i
        {
            col = causingseq[i][j]; //Sequence no. of predictor
              v[j] = rmat[row-1][col-1];
        }
        if (ShowModRChk->Checked)
        {
           strcpy(outline,"Correlations of dependent and independent variables");
           vectorprint(v, causingseq[i], nocausing[i], outline);
        }

        //Get matrix among predictor variables (independent variables matrix)
        for (j = 0; j < nocausing[i]; j++)
        {
            causing[j] = causingseq[i][j];
            for (k = 0; k < nocausing[i]; k++)
            {
                row = causingseq[i][j];
                col = causingseq[i][k];
                IndMatrix[j][k] = rmat[row-1][col-1];
                TempMat[j+1][k+1] = rmat[row-1][col-1];
            }
        }
        if (ShowModRChk->Checked)
        {
           strcpy(outline,"Matrix of Correlations Among Independent Variables");
           MatPrint(IndMatrix, nocausing[i], nocausing[i], causing, outline);
        }

        // get inverse
        matinv(TempMat,nocausing[i],InvMatrix,WorkMat,WorkVector);
        NoIndep = nocausing[i];
        dep = causedseq[i]-1;
        constant = 0.0;
        df2 = count - NoIndep - 1;
        //Now get beta and B coefficients
        for (j = 0; j < nocausing[i]; j++)
        {
            beta[j] = 0.0;
            for (k = 0; k < nocausing[i]; k++)
            {
                beta[j] += InvMatrix[j+1][k+1] * v[k];
            }
            indep = causingseq[i][j];
            B[j] = beta[j] * stddevs[dep] / stddevs[indep-1];
            constant += B[j] * means[indep-1];
        }
        constant = means[dep] - constant;
        s2 = 0.0; //Get squared multiple correlation
        for (j = 0; j < nocausing[i]; j++)
        {
            s2 += beta[j] * v[j];
            row = causedseq[i];
            col = causingseq[i][j];
            PathCoef[row-1][col-1] = beta[j];
        }
        // get std errors , F tests, etc.
        SSt = double(count-1) * stddevs[dep]*stddevs[dep];
        SSres = SSt * (1.0 - s2);
        MSres = SSres / df2;
        VarEst = SSres / df2;
        StdErrEst = sqrt(VarEst);
        SSModel = SSt - SSres;
        df1 = 1.0;
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add\
            ("Variable       Beta      B         Std.Error t         Prob.>t");
        for (j = 0; j < nocausing[i]; j++)
        {
            F = 1000.0;
            col = causingseq[i][j];
            indep = causing[j]-1;
            SSx = double(count-1) * (stddevs[indep]*stddevs[indep]);
            StdErrB = sqrt(VarEst / (SSx * (1.0 / InvMatrix[j+1][j+1])));
            if (StdErrB > 0) F = B[j] / StdErrB;
            ProbF = ftest(df1,df2,F*F);
            if (ShowModRChk->Checked)
            {
               sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%10.3f",\
                       MainForm->Grid->Cells[col][0].c_str(),
                       beta[j] ,B[j], StdErrB, F, ProbF);
               FrmOutPut->RichOutPut->Lines->Add(outline);
            }
        }
        if (ShowModRChk->Checked)
        {
           sprintf(outline,"Constant  %20.3f",constant);
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }

        if (ShowModRChk->Checked)
        {
           df1 = NoIndep;
           df2 = count - NoIndep - 1;
           if (s2 >= 1.0) F = 1000;
           else F = (s2 / df1) / ((1.0-s2)/ df2);
           ProbF = ftest(df1,df2,F);
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"Source     DF        SS        MS        F         Prob>F");
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Model     %3d       %9.3f %9.3f %9.4f %9.4f",
                   NoIndep, SSModel, SSModel / df1, F, ProbF);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Error     %3.0f       %9.3f %9.3f",
                   df2,SSres,MSres);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Total     %3d       %9.3f",count-1,SSt);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"\n%10s%8s%10s%10s%12s%5s%5s","Variable","R","R2",
        		 "F","Prob.>F","DF1","DF2");
           FrmOutPut->RichOutPut->Lines->Add(outline);
           row = causedseq[i];
           sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%5.0f%5.0f\n",
                       		MainForm->Grid->Cells[row][0].c_str(),
                            sqrt(s2),s2,F,ProbF,df1,df2);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Std. Error of Estimate = %10.3f\n",StdErrEst);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           FrmOutPut->RichOutPut->Lines->Add("");
        }
        if (ShowModRChk->Checked) FrmOutPut->ShowModal();
    } // next i (caused regressions)

    //Now, reconstruct the correlation matrix from path coefficients
    //First, obtain list of exogenous variables
    noexogenous = 0;
    for (i = 0; i < NoSelected; i++)
    {
        matched = false;
        col = ColNoSelected[i];
        for (j = 0; j < nocaused; j++)
            if (causedseq[j] == col) matched = true;
        if (!matched)
        {
            exogenous[noexogenous] = col;
            noexogenous++;
        }
    }

    //Now fill in the reconstructed matrix with correlations among exogenous variables
    for (i = 0; i < noexogenous-1; i++)
    {
        for (j = i+1; j < noexogenous; j++)
        {
            e[i][j] = 0.0;
            e[j][i] = 0.0;
            row = exogenous[i];
            col = exogenous[j];
            e[i][j] = rmat[row-1][col-1];
            e[j][i] = rmat[col-1][row-1];
            e[j][j] = 1.0;
        }
    }
    for (i = 0; i < NoSelected; i++) e[i][i] = 1.0;

    //Build matrix of path coefficients
    for (i = 0; i < nocaused; i++)
    {
        row = causedseq[i];
        for (j = 0; j < nocausing[i]; j++)
        {
            col = causingseq[i][j];
            W[row-1][col-1] = PathCoef[row-1][col-1];
            W[col-1][row-1] = W[row-1][col-1];
        }
    }

    //Print results
    strcpy(outline,"Matrix of Path Coefficients");
    MatPrint(W, NoSelected, NoSelected, ColNoSelected, outline);
    FrmOutPut->ShowModal();

    //Build models vectors
    NoModels = 0;
    for (int i = 0; i < nocaused; i++) NoModels += nocausing[i];
    k = 0;
    for (i = 0; i < nocaused; i++)
    {
        for (j = 0; j < nocausing[i]; j++)
        {
            causal[k][0] = causedseq[i];
            causal[k][1] = causingseq[i][j];
            row = causedseq[i];
            col = causingseq[i][j];
            p[k] = PathCoef[row-1][col-1];
            k++;
        }
    }

    //Sort on resultant then causing variables
    for (i = 0; i < NoModels-1; i++)
    {
        for (j = i+1; j < NoModels; j++)
        {
            if (causal[i][0] > causal[j][0]) // swap
            {
                t = causal[i][1];
                causal[i][1] = causal[j][1];
                causal[j][1] = t;
                t = causal[i][0];
                causal[i][0] = causal[j][0];
                causal[j][0] = t;
                Temp = p[i];
                p[i] = p[j];
                p[j] = Temp;
            }
        }
    }
    for (i = 0; i < NoModels-1; i++)
    {
        for (j = i+1; j < NoModels; j++)
        {
            if ((causal[i][0] == causal[j][0]) && (causal[i][1] > causal[j][1]))
            {
                t = causal[i][0];
                causal[i][0] = causal[j][0];
                causal[j][0] = t;
                t = causal[i][1];
                causal[i][1] = causal[j][1];
                causal[j][1] = t;
                Temp = p[i];
                p[i] = p[j];
                p[j] = Temp;
            }
        }
    }

    FrmOutPut->RichOutPut->Lines->Add("SUMMARY OF CAUSAL MODELS");
    FrmOutPut->RichOutPut->Lines->Add("Result Var.     Due to Var.   Path Coefficient");

    for (i = 0; i < NoModels; i++)
    {

        sprintf(outline,"%12s   %12s  %6.3f",
                MainForm->Grid->Cells[causal[i][0]][0].c_str(),
                MainForm->Grid->Cells[causal[i][1]][0].c_str(),
                p[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();

    //Get reproduced correlation matrix in e
    for (i = 0; i < NoSelected; i++)
    {
        for (j = i; j < NoSelected; j++)
        {
            if (i != j)
            {
               for (L = 0; L < j; L++)
               {
                   for (L2 = 0; L2 < NoModels; L2++)
                   {
                       if ((causal[L2][0]-1 == j) && (causal[L2][1]-1 == L))
                          e[i][j] += (W[j][L] * e[i][L]);
                   }
               }// next L
               e[j][i] = e[i][j];
            } // end if
        } // next j
    } // next i

    if (ShowRepdChk->Checked)
    {
       strcpy(outline,"Reproduced Correlation Matrix");
       MatPrint(e, NoSelected, NoSelected, ColNoSelected, outline);
       FrmOutPut->ShowModal();
    }

    //Examine discrepencies
    d2 = 0.0;
    sum = 0.0;
    for (i = 0; i < NoSelected; i++)
    {
        for (j = 0; j < NoSelected; j++)
        {
            absdiff = fabs(rmat[i][j] - e[i][j]);
            sum += absdiff;
            if (absdiff > d2) d2 = absdiff;
        }
    }

    FrmOutPut->RichOutPut->Lines->Add("Average absolute difference between observed and reproduced");
    sprintf(outline,"coefficients = %5.3f",sum / double(NoSelected * NoSelected));
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Maximum difference found = %5.3f",d2);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // clean up heap (delete last allocated first)
cleanup:
    delete[] B;
    delete[] causing;
    delete[] exogenous;
    delete[] p;
    delete[] v;
    delete[] beta;
    for (i = 0; i < size; i++) delete[] causal[i];
    delete[] causal;
    for (i = 0; i < NoVariables; i++) delete[] W[i];
    delete[] W;
    for (i = 0; i < NoVariables; i++) delete[] e[i];
    delete[] e;
    for (i = 0; i < NoVariables+1; i++) delete[] InvMatrix[i];
    delete[] InvMatrix;
    for (i = 0; i < NoVariables; i++) delete[] IndMatrix[i];
    delete[] IndMatrix;
    for (i = 0; i < NoVariables; i++) delete[] PathCoef[i];
    delete[] PathCoef;
    for (i = 0; i < NoVariables+1; i++) delete[] TempMat[i];
    delete[] TempMat;
    delete[] WorkVector;
    for (i = 0; i < NoVariables+1; i++) delete[] WorkMat[i];
    delete[] WorkMat;
    delete[] ColNoSelected;
    delete[] ColLabels;

    if (allocated)
    {
        delete[] nocausing;
        delete[] stddevs;
        delete[] means;
        for (int i = 0; i < NoVariables; i++) delete[] rmat[i];
        delete[] rmat;
        delete[] ModelDefined;
        delete[] causedseq;
        for (int i = 0; i < NoVariables; i++) delete[] causingseq[i];
        delete[] causingseq;
        allocated = false;
    }
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::FormShow(TObject *Sender)
{
     AnsiString cellstring;

     ListBox1->Clear();
     ListBox2->Clear();
     ListBox3->Clear();
     CausedEdit->Text = "";
     ShowModRChk->Checked = false;
     ShowDescChk->Checked = false;
     ShowRepdChk->Checked = false;
     ModelNo = 1;
     ModelNoEdit->Text = ModelNo;
     ScrollBar1->Position = 1;
     CausedOutBtn->Enabled = false;
     CausingOutBtn->Enabled = false;
     SelOutBtn->Enabled = false;
     NoModels = 1;
     try  {
        causingseq = new int *[NoVariables];
        for (int i = 0; i < NoVariables; i++) causingseq[i] = new int[NoVariables];
        causedseq = new int[NoVariables];
        ModelDefined = new bool[NoVariables];
        rmat = new double *[NoVariables];
        for (int i = 0; i < NoVariables; i++) rmat[i] = new double[NoVariables];
        means = new double[NoVariables];
        stddevs = new double[NoVariables];
        nocausing = new int[NoVariables];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Path Analysis","MEMORY!",MB_OK);
        exit (-1);
    }
    allocated = true;
    for (int i = 0; i < NoVariables; i++)
    {
        ModelDefined[i] = false;
        causedseq[i] = 0;
        for (int j = 0; j < NoVariables; j++) causingseq[i][j] = 0;
    }
    for (int i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        ListBox3->Items->Add(cellstring);
    }
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::CancelBtnClick(TObject *Sender)
{
     if (allocated)
     {
        delete[] nocausing;
        delete[] stddevs;
        delete[] means;
        for (int i = 0; i < NoVariables; i++) delete[] rmat[i];
        delete[] rmat;
        delete[] ModelDefined;
        delete[] causedseq;
        for (int i = 0; i < NoVariables; i++) delete[] causingseq[i];
        delete[] causingseq;
        allocated = false;
     }
     FrmPath->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::ResetBtnClick(TObject *Sender)
{
     if (allocated)
     {
        delete[] nocausing;
        delete[] stddevs;
        delete[] means;
        for (int i = 0; i < NoVariables; i++) delete[] rmat[i];
        delete[] rmat;
        delete[] ModelDefined;
        delete[] causedseq;
        for (int i = 0; i < NoVariables; i++) delete[] causingseq[i];
        delete[] causingseq;
        allocated = false;
     }
     FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::ResetModBtnClick(TObject *Sender)
{
     if (CausedEdit->Text != "") CausedEdit->Text = "";
     int count = ListBox2->Items->Count;
     for (int i = 0; i < count; i++) ListBox2->Items->Delete(0);
     causedseq[ModelNo-1] = 0;
     for (int i = 0; i < NoVariables; i++) causingseq[ModelNo-1][i] = 0;
     ModelDefined[ModelNo-1] = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmPath::SelInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox3->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox3->Selected[i])
         {
            cellstring = ListBox3->Items->Strings[i];
            ListBox1->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox3->Items->Count; i++)
           {
               if (ListBox3->Selected[i])
               {
                  ListBox3->Items->Delete(i);
                  count--;
               }
           }
     }
     SelOutBtn->Enabled = true;

}
//---------------------------------------------------------------------------

void __fastcall TFrmPath::SelOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox1->ItemIndex;
     cellstring = ListBox1->Items->Strings[index];
     ListBox3->Items->Add(cellstring);
     ListBox1->Items->Delete(index);

}
//---------------------------------------------------------------------------

void __fastcall TFrmPath::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox3->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox3->Items->Strings[index];
          ListBox1->Items->Add(cellstring);
     }
     ListBox3->Clear();
     SelOutBtn->Enabled = true;

}
//---------------------------------------------------------------------------


