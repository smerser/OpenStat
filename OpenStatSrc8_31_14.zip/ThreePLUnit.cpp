//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
#include "stdio.h"
#include "ThreePLUnit.h"
#include "ThreePFuncs.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TThreePLForm *ThreePLForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoVariables;
extern int NoCases;

//---------------------------------------------------------------------------
__fastcall TThreePLForm::TThreePLForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TThreePLForm::ResetBtnClick(TObject *Sender)
{
     CalibrateOps->ItemIndex = 1;
     ParamFileEdit->Text = "";
     ResponseFileEdit->Text = "";
     ExamineeIDEdit->Text = "";
     ThetaEdit->Text = "";
     ItersEdit->Text = "";
     PlotAbilityChk->Checked = false;
     PlotaChk->Checked = false;
     PlotbChk->Checked = false;
     PlotcChk->Checked = false;
     CurvesChk->Checked = false;
     VarList->Clear();
     ItemList->Clear();
     IDInBtn->Visible = true;
     IDOutBtn->Visible = false;
     ThetaInBtn->Visible = true;
     ThetaOutBtn->Visible = false;
     ItemInBtn->Visible = true;
     ItemOutBtn->Visible = false;
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     ParamGrid->ColCount = 5;
     ParamGrid->Cells[0][0] = "ITEM";
     ParamGrid->Cells[1][0] = "ID";
     ParamGrid->Cells[2][0] = "SLOPE(a)";
     ParamGrid->Cells[3][0] = "DIFF.(b)";
     ParamGrid->Cells[4][0] = "CHANCE(c)";
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::IDInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     ExamineeIDEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     IDInBtn->Visible = false;
     IDOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::IDOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ExamineeIDEdit->Text);
     ExamineeIDEdit->Text = "";
     IDInBtn->Visible = true;
     IDOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ThetaInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     ThetaEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ThetaInBtn->Visible = false;
     ThetaOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ThetaOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ThetaEdit->Text);
     ThetaEdit->Text = "";
     ThetaInBtn->Visible = true;
     ThetaOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ItemInBtnClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            ItemList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     ItemOutBtn->Visible = true;
     if (VarList->Items->Count < 1) ItemInBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ItemOutBtnClick(TObject *Sender)
{
     int index;

     index = ItemList->ItemIndex;
     VarList->Items->Add(ItemList->Items->Strings[index]);
     ItemList->Items->Delete(index);
     ItemInBtn->Visible = true;
     if (ItemList->Items->Count < 1) ItemOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ComputeBtnClick(TObject *Sender)
{
     FILE * parms;
     int i, j, k, option, ThetaCol, IDCol, N, nobs, ni, iold, NoItems;
     int ItemCol, nl, nvalid = 0;
     int *ItemCols;
     int *ItemIDs;
     int *SubjectID;
//     double **Scores;
     double *ItemTots;
     double *Theta, *ThetaError;
     double *Parma, *ParmaError;
     double *Parmb, *ParmbError;
     double *Parmc, *ParmcError;
     double *TotScrs;
     double seeth;
     int *nobs2, *nobs3;
     double a, b, c, theta, mserr = 0.0, mserrold;
     char outstr[101];

     GetIntVecMem(ItemCols,NoVariables);
     GetIntVecMem(ItemIDs,NoVariables);
     GetIntVecMem(SubjectID,NoCases);
     GetIntVecMem(nobs2,NoVariables);
     GetIntVecMem(nobs3,NoCases);
     GetDblVecMem(Theta,NoCases);
     GetDblVecMem(ThetaError,NoCases);
     GetDblVecMem(Parma,NoVariables);
     GetDblVecMem(ParmaError,NoVariables);
     GetDblVecMem(Parmb,NoVariables);
     GetDblVecMem(ParmbError,NoVariables);
     GetDblVecMem(Parmc,NoVariables);
     GetDblVecMem(ParmcError,NoVariables);
     GetDblVecMem(ItemTots,NoVariables);
     TotScrs = new double[NoCases];

     // Get the calibration option elected
     iopt =  CalibrateOps->ItemIndex + 1;

     // Get columns of the response file in the main form grid
     for (int i = 1; i <= NoVariables; i++)
     {
         if (MainForm->Grid->Cells[i][0] == ExamineeIDEdit->Text) IDCol = i;
         if (MainForm->Grid->Cells[i][0] == ThetaEdit->Text) ThetaCol = i;
     }
     NoItems = ItemList->Items->Count;
     for (int i = 1; i <= NoVariables; i++)
     {
         for (int j = 0; j < NoItems; j++)
         {
             if (MainForm->Grid->Cells[i][0] == ItemList->Items->Strings[j])
                ItemCols[j] = i;
         }
     }
     ParamGrid->RowCount = NoItems+1;
     ParamGrid->ColCount = 5;

     // Get the total scores
     GetTotalScores(NoItems, ItemCols, TotScrs, this);
     if (InitialzChk->Checked == true) SetThetaz(ThetaCol, TotScrs, this);

     // Get the item parameters from the parameter grid
     for (int i = 0; i < NoItems; i++)
     {
          Parma[i] = StrToFloat(ParamGrid->Cells[2][i+1]);
          Parmb[i] = StrToFloat(ParamGrid->Cells[3][i+1]);
          Parmc[i] = StrToFloat(ParamGrid->Cells[4][i+1]);
          ItemIDs[i] = StrToInt(ParamGrid->Cells[1][i+1]);
          ItemTots[i] = 0.0;
     }

     // Get the input file data from the grid
     for (int i = 1; i <= NoCases; i++)
     {
         SubjectID[i-1] = floor(StrToFloat(MainForm->Grid->Cells[IDCol][i]));
         Theta[i-1] = StrToFloat(MainForm->Grid->Cells[ThetaCol][i]);
//         TotScrs[i-1] = 0.0;
         double X;
         for (int j = 0; j < NoItems; j++)
         {
             int k = ItemCols[j];
             if (ValidValue(i,k)) X = StrToFloat(MainForm->Grid->Cells[k][i]);
             else X = 0.0;
//             if (X == 1.0) TotScrs[i-1] += X;
             ItemTots[j] += X;
         }
     }

     // Eliminate unestimable cases and items if elected
     if (FilterChk->Checked)
     {
        bool done = false;
        int oldnoitems = NoItems;
        int oldnocases = NoCases;
        while (!done)
        {
           for (int i = 0; i < NoItems; i++)
           {
              if ((ItemTots[i] == 0.0) || (ItemTots[i] == NoCases)) // eliminate item
              {
                 k = ItemCols[i];
                 AnsiString astring = "Item " + IntToStr(ItemIDs[i]) + " Eliminated";
                 FrmOutPut->RichOutPut->Lines->Add(astring);
                 AnsiString ItemLabel = MainForm->Grid->Cells[k][0];
                 // eliminate label from user's list and ParamGrid
                 int index;
                 for (int m = 0; m < ItemList->Items->Count; m++)
                    if (ItemList->Items->Strings[m] == ItemLabel) index = m;
                 ItemList->Items->Delete(index);
                 // move Item Totals, IDs, Parameters up 1
                 for (int m = i; m < NoItems-1; m++)
                 {
                     ItemTots[m] = ItemTots[m+1];
                     Parma[m] = Parma[m+1];
                     Parmb[m] = Parmb[m+1];
                     Parmc[m] = Parmc[m+1];
                     ItemIDs[m] = ItemIDs[m+1];
                 }
                 DeleteaCol(k);
                 DefaultsBtnClick(this);
                 NoItems--;
              }
           }
           ParamGrid->RowCount = NoItems+1;
           NoVariables = MainForm->Grid->ColCount - 1;

           for (int i = 1; i <= NoCases; i++)
           {
              if ((TotScrs[i-1] == 0) || (TotScrs[i-1] >= NoItems)) // eliminate case
              {
                 AnsiString astring = "Subject " + IntToStr(SubjectID[i-1]) + " Eliminated.";
                 FrmOutPut->RichOutPut->Lines->Add(astring);
                 // move delete scores, subject ID and Theta up 1
                 for (int m = i-1; m < NoCases; m++)
                 {
                     TotScrs[m] = TotScrs[m+1];
                     SubjectID[m] = SubjectID[m+1];
                     Theta[m] = Theta[m+1];
                 }
                 CutaRow(i);
                 NoCases--;
              }
           }
           NoCases = MainForm->Grid->RowCount - 1;

           // Again get columns of the response file in the main form grid
           for (int i = 1; i <= NoVariables; i++)
           {
              if (MainForm->Grid->Cells[i][0] == ExamineeIDEdit->Text) IDCol = i;
              if (MainForm->Grid->Cells[i][0] == ThetaEdit->Text) ThetaCol = i;
           }
           for (int i = 1; i <= NoVariables; i++)
           {
              for (int j = 0; j < NoItems; j++)
              {
                 if (MainForm->Grid->Cells[i][0] == ItemList->Items->Strings[j])
                   ItemCols[j] = i;
              }
           }

           // recalculate item and subject totals
           for (int i = 1; i <= NoCases; i++)
           {
              SubjectID[i-1] = floor(StrToFloat(MainForm->Grid->Cells[IDCol][i]));
              Theta[i-1] = StrToFloat(MainForm->Grid->Cells[ThetaCol][i]);
              TotScrs[i-1] = 0.0;
              double X;
              for (int j = 1; j <= NoItems; j++)
              {
                 int k = ItemCols[j-1];
                 if (ValidValue(i,k)) X = StrToFloat(MainForm->Grid->Cells[k][i]);
                 else X = 0.0;
                 if (X == 1.0) TotScrs[i-1] += X;
                 ItemTots[j-1] += X;
              }
           }
           if (oldnoitems == NoItems) done = true;
           else
           {
               done = false;
               oldnoitems = NoItems;
           }
           if (oldnocases == NoCases) done = true;
           else
           {
               done = false;
               oldnocases = NoCases;
           }
        } // end while not done
        FrmOutPut->RichOutPut->Lines->Add("");
     } // end if reduction elected

     // Calibrate
     if (iopt == 2) // calibrate a,b,c and theta given responses
     {
          bool test = true;
          int iterations = 0;
          int oldits = 0;
          nl = 0;
/*
          for (i = 0; i < NoItems; i++) // FOR i = 1 TO ni
          {
               Parma[i] = 0.75; // aa( i ) = .75
               Parmb[i] = 0.0; // bb( i ) = 0.0
               Parmc[i] = 0.20; // cc( i ) = .20
          } //  NEXT
*/
          do //DO
          {
               iterations++;
               if (iterations != oldits)
               {
                  ItersEdit->Text = IntToStr(iterations);
                  Pbar->StepIt();
                  oldits = iterations;
               }
               mserrold = mserr;
               mserr = 0.0;
               // ' estimate items
               for (i = 1; i <= NoItems; i++) // items
               {
                    ItemCol = ItemCols[i-1];
                    a = Parma[i-1]; // aa( i )
                    b = Parmb[i-1]; // bb( i )
                    c = Parmc[i-1]; // cc( i )
                    calib_abc(ParmaError[i-1],ParmbError[i-1],ParmcError[i-1],ItemCol,Theta,a,b,c,NoCases);
                    mserr = mserr + mse(ItemCol, Theta, Parma[i-1],Parmb[i-1],Parmc[i-1], NoCases, nobs ) / NoItems;
                    Parma[i-1] = a; // aa( i ) = a
                    Parmb[i-1] = b; // bb( i ) = b
                    Parmc[i-1] = c; // cc( i ) = c
                    nobs2[i-1] = nobs;
               } //  NEXT i

               // ' estimate examinees
               for (j = 1; j <= NoCases; j++) //FOR j = 1 TO n
               {
                    theta = Theta[j-1]; // th( j )
                    nvalid = NoCases;
                    calib_theta(ThetaError[j-1],theta,NoItems,Parma,Parmb,Parmc,j,nvalid,ItemCols);
                    Theta[j-1] = theta;
                    nobs3[j-1] = nvalid;
               } //  NEXT j
               nl++;
               if (nl > 100) test = false;
               if ((nl > 4) && (fabs(mserr - mserrold) < 0.0000000001)) test = false;
          } while (test);
          Pbar->Position = Pbar->Max;
          sprintf(outstr,"Seq ItemID  Nobs   a_calib   b_calib   c_calib   seea    seeb    seec");
          FrmOutPut->RichOutPut->Lines->Add(outstr);
          for (i = 1; i <= NoItems; i++) // FOR i = 1 TO ni
          {
               a = Parma[i-1];
               b = Parmb[i-1];
               c = Parmc[i-1];
               nobs = nobs2[i-1];
               sprintf(outstr,"  %3d  %4d %4d %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f",
                 i,ItemIDs[i-1],nobs,a,b,c,ParmaError[i-1],ParmbError[i-1],ParmcError[i-1]);
               FrmOutPut->RichOutPut->Lines->Add(outstr);
          } //    NEXT
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outstr,"SeqID  ExaminID  Nvalid  Theta  Std.Err.Theta");
          FrmOutPut->RichOutPut->Lines->Add(outstr);

          // Save theta values and print results
          for (i = 1; i <= NoCases; i++) //FOR i = 1 TO n
          {
               MainForm->Grid->Cells[ThetaCol][i] = Theta[i-1];
               sprintf(outstr," %3d   %8d   %3d   %8.3f   %8.3f",
                 i,SubjectID[i-1],nobs3[i-1],Theta[i-1],ThetaError[i-1]);
               FrmOutPut->RichOutPut->Lines->Add(outstr);
          } //  NEXT i
          ItersEdit->Text = IntToStr(iterations);
     } //  END IF

     if ((iopt == 3) || (iopt == 4))
     {
          FrmOutPut->RichOutPut->Lines->Add("Item Parameter Calibrations");
          if (iopt == 3) // calibrate a, b, c given theta and responses
          {
               sprintf(outstr,"Seq ItemID  Nobs  a_calib  b_calib  c_calib  seea    seeb    seec");
               FrmOutPut->RichOutPut->Lines->Add(outstr);
          }
          else // calibrate a and b given c and theta
          {
               sprintf(outstr,"SeqItem AccNo  Nobs  a_calib  b_calib  c_given  seea      seeb      seec");
               FrmOutPut->RichOutPut->Lines->Add(outstr);
          } // END IF
          for (i = 1; i <= NoItems; i++) // FOR i = 1 TO ni
          {
               a = Parma[i-1]; // aa( i )
               b = Parmb[i-1]; // bb( i )
               c = Parmc[i-1]; // cc( i )

               //  count nobs
               ItemCol = ItemCols[i-1];
               mserr = mse( ItemCol, Theta, a, b, c, NoCases, nobs );
               if (nobs > 5)
               {
                    ParmaError[i-1] = -1.0; //seea( i ) = - 1.0:
                    ParmbError[i-1] = -1.0; //seeb( i ) = - 1.0:
                    ParmcError[i-1] = -1.0; //seec( i ) = - 1.0
                    a = 1.0;
                    b = 0.0;
                    if (iopt == 4) c = 0.0;
                    if (nobs > 9)
                         calib_abc(ParmaError[i-1],ParmbError[i-1],ParmcError[i-1],ItemCol,Theta,a,b,c,NoCases);
                    if (ParmaError[i-1] == -1.0) a = 0.0;
                    if (ParmbError[i-1] == -1.0) b = 0.0;
                    if ((ParmcError[i-1] == -1.0) && (iopt != 4)) c = 0.0;
                    Parma[i-1] = a;
                    Parmb[i-1] = b;
                    Parmc[i-1] = c;
                    sprintf(outstr,"%3d  %4d  %3d %8.3f %8.3f %8.3f %8.3f %8.3f %8.3f",
                        i,ItemIDs[i-1],NoCases, Parma[i-1],Parmb[i-1],Parmc[i-1],
                        ParmaError[i-1],ParmbError[i-1],ParmcError[i-1]);
                    FrmOutPut->RichOutPut->Lines->Add(outstr);
               } // END IF
          } // NEXT i
     } // END IF


     //  just theta
     if (iopt == 1) // calibrate theta given a,b,c and responses
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("Subject Theta (ability) Estimates");
          sprintf(outstr," Seq    ID  Nvalid   Theta  Std.Err.Theta");
          FrmOutPut->RichOutPut->Lines->Add(outstr);

          for (j = 1; j <= NoCases; j++)
          {
               theta = 0.0;
               seeth = - 1.0;
               calib_theta(seeth,theta,NoItems,Parma,Parmb,Parmc,j,nobs,ItemCols);
               sprintf(outstr,"%4d  %4d    %4d %8.3f   %8.3f",j,SubjectID[j-1],nobs,theta,seeth);
               FrmOutPut->RichOutPut->Lines->Add(outstr);
               MainForm->Grid->Cells[ThetaCol][j] = theta;
          } // NEXT j
     } //  END IF

     // save parameters
     parms = fopen(ParmFileName.c_str(),"wt");
     for (int i = 0; i < NoItems; i++)
     {
          fprintf(parms,"%5d,%8.3f,%8.3f,%8.3f\n",ItemIDs[i],Parma[i],Parmb[i],Parmc[i]);
          ParamGrid->Cells[1][i+1] = ItemIDs[i];
          ParamGrid->Cells[2][i+1] = Parma[i];
          ParamGrid->Cells[3][i+1] = Parmb[i];
          ParamGrid->Cells[4][i+1] = Parmc[i];
          ParamGrid->Cells[0][i+1] = i+1;
     }
     fclose(parms);

     // report means and standard deviations of parameter estimates
     FrmOutPut->RichOutPut->Lines->Add("");
     double Meana = 0.0;
     double Meanb = 0.0;
     double Meanc = 0.0;
     double Variancea = 0.0;
     double Varianceb = 0.0;
     double Variancec = 0.0;
     double StdDeva;
     double StdDevb;
     double StdDevc;
     for (int i = 0; i < NoItems; i++)
     {
         Meana += Parma[i];
         Meanb += Parmb[i];
         Meanc += Parmc[i];
         Variancea += (Parma[i] * Parma[i]);
         Varianceb += (Parmb[i] * Parmb[i]);
         Variancec += (Parmc[i] * Parmc[i]);
     }
     Variancea = Variancea - (Meana * Meana / NoItems);
     Varianceb = Varianceb - (Meanb * Meanb / NoItems);
     Variancec = Variancec - (Meanc * Meanc / NoItems);
     Variancea /= (NoItems-1);
     Varianceb /= (NoItems-1);
     Variancec /= (NoItems-1);
     StdDeva = sqrt(Variancea);
     StdDevb = sqrt(Varianceb);
     StdDevc = sqrt(Variancec);
     Meana /= NoItems;
     Meanb /= NoItems;
     Meanc /= NoItems;
     sprintf(outstr,"Mean a = %8.3f, Variance a = %8.3f, StdDev. a = %8.3f",
             Meana, Variancea, StdDeva);
     FrmOutPut->RichOutPut->Lines->Add(outstr);
     sprintf(outstr,"Mean b = %8.3f, Variance b = %8.3f, StdDev. b = %8.3f",
             Meanb, Varianceb, StdDevb);
     FrmOutPut->RichOutPut->Lines->Add(outstr);
     sprintf(outstr,"Mean c = %8.3f, Variance c = %8.3f, StdDev. c = %8.3f",
             Meanc, Variancec, StdDevc);
     FrmOutPut->RichOutPut->Lines->Add(outstr);

     FrmOutPut->ShowModal();

     // now do graphs as requested
     if (PlotAbilityChk->Checked)
     {
        double Xmax = 0.0;
        double Xmin = double(NoItems);
        double X;
        for (int i = 0; i < NoCases; i++)
        {
            TotScrs[i] = 0.0;
            for (int j = 0; j < NoItems; j++)
            {
                int k = ItemCols[j];
                if (ValidValue(i+1,k)) X = StrToFloat(MainForm->Grid->Cells[k][i+1]);
                else X = 0.0;
                if (X == 1.0) TotScrs[i] += X;
            }
            if (TotScrs[i] > Xmax) Xmax = TotScrs[i];
            if (TotScrs[i] < Xmin) Xmin = TotScrs[i];
        }
        char *title = "PLOT OF TOTAL SCORE VS LOG ABILITY";
        plotxy(Theta,TotScrs,Xmax,Xmin,3.0,-3.0,NoCases,title);
     }
     if (PlotbChk->Checked)
     {
        char *title = "Distribution of Item Difficulty";
        double *ItmNo;
        double *ItmDif;
        ItmNo = new double[NoItems];
        ItmDif = new double[NoItems];
        double Xmax = NoItems;
        double Xmin = 1;
        double Ymax = -6.0;
        double Ymin = 6.0;
        for (int i = 0; i < NoItems; i++)
        {
            ItmNo[i] = double(i+1);
            ItmDif[i] = Parmb[i];
            if (Parmb[i] > Ymax) Ymax = Parmb[i];
            if (Parmb[i] < Ymin) Ymin = Parmb[i];
        }
        // sort in ascending order
        for (int i = 0; i < NoItems-1; i++)
        {
            for (int j = i+1; j < NoItems; j++)
            {
                if (ItmDif[i] > ItmDif[j])
                {
                   double temp = ItmDif[i];
                   ItmDif[i] = ItmDif[j];
                   ItmDif[j] = temp;
                }
            }
        }
        plotxy(ItmDif,ItmNo,Xmax,Xmin,Ymax,Ymin,NoItems,title);
        delete[] ItmDif;
        delete[] ItmNo;
     }
     if (PlotaChk->Checked)
     {
        char *title = "Distribution of Item Slopes";
        double *ItmNo;
        double *ItmDif;
        ItmNo = new double[NoItems];
        ItmDif = new double[NoItems];
        double Xmax = NoItems;
        double Xmin = 1;
        double Ymax = -6.0;
        double Ymin = 6.0;
        for (int i = 0; i < NoItems; i++)
        {
            ItmNo[i] = double(i+1);
            ItmDif[i] = Parma[i];
            if (Parma[i] > Ymax) Ymax = Parma[i];
            if (Parma[i] < Ymin) Ymin = Parma[i];
        }
        // sort in ascending order
        for (int i = 0; i < NoItems-1; i++)
        {
            for (int j = i+1; j < NoItems; j++)
            {
                if (ItmDif[i] <= ItmDif[j]) continue;
                double temp = ItmDif[i];
                ItmDif[i] = ItmDif[j];
                ItmDif[j] = temp;
            }
        }
        plotxy(ItmDif,ItmNo,Xmax,Xmin,Ymax,Ymin,NoItems,title);
        delete[] ItmDif;
        delete[] ItmNo;
     }
     if (PlotcChk->Checked)
     {
        char *title = "Distribution of Item Parameter c";
        double *ItmNo;
        double *ItmDif;
        ItmNo = new double[NoItems];
        ItmDif = new double[NoItems];
        double Xmax = NoItems;
        double Xmin = 1;
        double Ymax = -5.0;
        double Ymin = 5.0;
        for (int i = 0; i < NoItems; i++)
        {
            ItmNo[i] = double(i+1);
            ItmDif[i] = Parmc[i];
            if (Parmc[i] > Ymax) Ymax = Parmc[i];
            if (Parmc[i] < Ymin) Ymin = Parmc[i];
        }
        // sort in ascending order
        for (int i = 0; i < NoItems-1; i++)
        {
            for (int j = i+1; j < NoItems; j++)
            {
                if (ItmDif[i] <= ItmDif[j]) continue;
                double temp = ItmDif[i];
                ItmDif[i] = ItmDif[j];
                ItmDif[j] = temp;
            }
        }
        plotxy(ItmDif,ItmNo,Xmax,Xmin,Ymax,Ymin,NoItems,title);
        delete[] ItmDif;
        delete[] ItmNo;
     }
     if (CurvesChk->Checked)
     {
        double *Prob;
        double *Scale;
        double *TestInfo;
        double exponent;
        double th;
        double P,Q;
        double thincr = 0.06;
        double Maxt = -1000.0;
        double Mint = 1000.0;
        char title[101];
        Prob = new double[101];
        Scale = new double[101];
        TestInfo = new double[101];

        for (int i = 0; i < NoItems; i++) // characteristic curves first
        {
            th = -3.0;
            for (int j = 0; j < 100; j++)
            {
                sprintf(title,"Characteristic Curve for %d",i+1);
                exponent = exp(-Parma[i]*(th - Parmb[i]));
                Prob[j] = Parmc[i] + (1.0 - Parmc[i]) * (1.0 / (1.0 + exponent));
                if (Prob[j] < Mint) Mint = Prob[j];
                if (Prob[j] > Maxt) Maxt = Prob[j];
                Scale[j] = th;
                th += thincr;
            }
            plotxy(Prob,Scale,3.0,-3.0,Maxt,Mint,100,title);
        }
        Maxt = -1000.0;
        Mint = 1000.0;
        for (int i = 0; i < NoItems; i++) // item information curves next
        {
            th = -3.0;
            for (int j = 0; j < 100; j++)
            {
                sprintf(title,"Information Curve for %d",i+1);
                double L = Parma[i] * (th - Parmb[i]);
                P = Parmc[i] + (1.0 - Parmc[i]) * (1.0 / (1.0 + exp(-L)));
                Q = 1.0 - P;
                Prob[j] = (Parma[i] * Parma[i]) * (Q / P) *
                  (((P - Parmc[i]) * (P - Parmc[i])) / (1.0 - (Parmc[i] * Parmc[i])));
                if (Prob[j] < Mint) Mint = Prob[j];
                if (Prob[j] > Maxt) Maxt = Prob[j];
                Scale[j] = th;
                th += thincr;
            }
            plotxy(Prob,Scale,3.0,-3.0,Maxt,Mint,100,title);
        }
        Maxt = -1000.0;
        Mint = 1000.0;
        for (int j = 0; j < 100; j++) TestInfo[j] = 0.0;
        for (int j = 0; j < 100; j++)
        {
            TestInfo[j] += Prob[j];
            if (TestInfo[j] < Mint) Mint = TestInfo[j];
            if (TestInfo[j] > Maxt) Maxt = TestInfo[j];
        }
        sprintf(title,"Test Information Curve");
        plotxy(TestInfo,Scale,3.0,-3.0,Maxt,Mint,100,title);

        delete[] TestInfo;
        delete[] Scale;
        delete[] Prob;
     }

     // Do item fit chi-squares
     ItemFit(Parma,Parmb,Parmc,TotScrs,Theta,NoItems,NoCases);

     // clean up the heap
cleanup:
     delete[] TotScrs;
     delete[] ItemTots;
     delete[] ParmcError;
     delete[] Parmc;
     delete[] ParmbError;
     delete[] Parmb;
     delete[] ParmaError;
     delete[] Parma;
     delete[] ThetaError;
     delete[] Theta;
     delete[] nobs3;
     delete[] nobs2;
     delete[] SubjectID;
     delete[] ItemIDs;
     delete[] ItemCols;
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::ParmBtnClick(TObject *Sender)
{
     FILE * parms;
     int NoItems = ItemList->Items->Count;

     ParamGrid->RowCount = NoItems+1;
     ResponseFileName = MainForm->FileNameEdit->Text;
     ResponseFileEdit->Text = ExtractFileName(ResponseFileName);
     ParmFileName = ExtractFileName(ResponseFileName);
     ParmFileName = ChangeFileExt(ParmFileName,".PRM");
     if (FileExists(ParmFileName)) // open and read the existing parm file
     {
        ParamFileEdit->Text = ParmFileName;
        parms = fopen(ParmFileName.c_str(),"rt");
        int ID;
        char value[51];
        double value1, value2, value3;
        char *p;
        for (int i = 0; i < NoItems; i++)
        {
             fgets(value,49,parms);
             // now, decode the four values
             p = strtok(value,",");
             if (p) ID = atoi(p);
             p = strtok(NULL,",");
             if (p) value1 = atof(p);
             p = strtok(NULL,",");
             if (p) value2 = atof(p);
             p = strtok(NULL,",");
             if (p) value3 = atof(p);
             ParamGrid->Cells[1][i+1] = IntToStr(ID);
             ParamGrid->Cells[2][i+1] = FloatToStr(value1);
             ParamGrid->Cells[3][i+1] = FloatToStr(value2);
             ParamGrid->Cells[4][i+1] = FloatToStr(value3);
             ParamGrid->Cells[0][i+1] = IntToStr(i+1);
             if ((feof(parms)) && (i < NoItems-1))
             {
                ShowMessage("Parm file does not match item list - seting default.");
                DefaultsBtnClick(this);
             }
        }
        fclose(parms);
     }
     else // create a file and data with estimates
     {
          int counter = 0;
          parms = fopen(ParmFileName.c_str(),"wt");
          for (int i = 0; i < NoItems; i++)
          {
              counter++;
              fprintf(parms,"%5d,%8.3f,%8.3f,%8.3f\n",counter,0.0,1.0,0.2);
              ParamGrid->Cells[1][i+1] = IntToStr(counter);
              ParamGrid->Cells[2][i+1] = FloatToStr(0.75);
              ParamGrid->Cells[3][i+1] = FloatToStr(0.0);
              ParamGrid->Cells[4][i+1] = FloatToStr(0.2);
              ParamGrid->Cells[0][i+1] = IntToStr(i+1);
          }
          fclose(parms);
     }
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::DefaultsBtnClick(TObject *Sender)
{
     FILE * parms;
     int NoItems = ItemList->Items->Count;
     int counter = 0;
     parms = fopen(ParmFileName.c_str(),"wt");
     for (int i = 0; i < NoItems; i++)
     {
              counter++;
              fprintf(parms,"%5d,%8.3f,%8.3f,%8.3f\n",counter,0.0,1.0,0.2);
              ParamGrid->Cells[1][i+1] = IntToStr(counter);
              ParamGrid->Cells[2][i+1] = FloatToStr(0.75);
              ParamGrid->Cells[3][i+1] = FloatToStr(0.0);
              ParamGrid->Cells[4][i+1] = FloatToStr(0.2);
              ParamGrid->Cells[0][i+1] = IntToStr(i+1);
     }
     fclose(parms);
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::GetTotalScores(int NoItems, int *ItemCols, double *TotScrs, TObject *Sender)
{
     for (int i = 1; i <= NoCases; i++)
     {
         double X;
         TotScrs[i-1] = 0.0;
         for (int j = 0; j < NoItems; j++)
         {
             int k = ItemCols[j];
             if (ValidValue(i,k)) X = StrToFloat(MainForm->Grid->Cells[k][i]);
             else X = 0.0;
             if (X == 1.0) TotScrs[i-1] += X;
         }
     }
}
//---------------------------------------------------------------------------

void __fastcall TThreePLForm::SetThetaz(int ThetaCol, double *TotScrs, TObject *Sender)
{
     double Mean, Variance, StdDev, Z, X;
     char outline[81];

     Mean = 0.0;
     Variance = 0.0;
     for (int i = 0; i < NoCases; i++)
     {
         Mean += TotScrs[i];
         Variance += (TotScrs[i] * TotScrs[i]);
     }
     Variance = Variance  - ((Mean * Mean) / NoCases);
     Variance = Variance / (NoCases - 1);
     StdDev = sqrt(Variance);
     Mean /= (double)NoCases;
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"TOTAL SCORES: Mean = %8.3f, Variance = %8.3f, Standard Deviation = %8.3f",
             Mean, Variance, StdDev);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");

     // convert total scores to z scores and store in Grid at theta variable
     for (int i = 0; i < NoCases; i++)
     {
         Z  = (Mean - TotScrs[i]) / StdDev;
         MainForm->Grid->Cells[ThetaCol][i+1] = FloatToStr(Z);
     }
}
//---------------------------------------------------------------------------




