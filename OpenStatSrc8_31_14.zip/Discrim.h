//---------------------------------------------------------------------------
#ifndef DiscrimH
#define DiscrimH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TDiscrimForm : public TForm
{
__published:	// IDE-managed Components
    TListBox *ListBox1;
    TLabel *Label1;
    TListBox *ListBox2;
    TLabel *Label2;
    TGroupBox *OutOptions;
    TLabel *Label3;
    TEdit *GroupVar;
    TCheckBox *CheckBox1;
    TCheckBox *CheckBox2;
    TCheckBox *CheckBox3;
    TCheckBox *CheckBox4;
    TCheckBox *CheckBox5;
    TCheckBox *CheckBox6;
    TCheckBox *CheckBox7;
    TCheckBox *CheckBox8;
    TCheckBox *CheckBox9;
    TCheckBox *CheckBox10;
    TCheckBox *CheckBox11;
    TCheckBox *CheckBox12;
    TCheckBox *CheckBox13;
    TGroupBox *SaveOptions;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ResetBtn;
    TBitBtn *VarInBtn;
    TBitBtn *VarOutBtn;
    TButton *BtnAll;
    TCheckBox *CheckBox20;
    TCheckBox *CheckBox21;
    TCheckBox *CheckBox22;
    TCheckBox *CheckBox23;
    TRadioGroup *RadioGroup1;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TRadioButton *RadioButton3;
    TCheckBox *SaveRMatChkBox;
        TLabel *Label4;
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    
    void __fastcall FormShow(TObject *Sender);
    void __fastcall VarInBtnClick(TObject *Sender);
    void __fastcall VarOutBtnClick(TObject *Sender);
    void __fastcall ListBox2Click(TObject *Sender);
    void __fastcall BtnAllClick(TObject *Sender);
        void __fastcall CheckBox21Click(TObject *Sender);
        void __fastcall CheckBox22Click(TObject *Sender);
        void __fastcall CheckBox23Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TDiscrimForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDiscrimForm *DiscrimForm;
//---------------------------------------------------------------------------
#endif
