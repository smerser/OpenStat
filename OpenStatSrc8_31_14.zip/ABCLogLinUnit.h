//---------------------------------------------------------------------------

#ifndef ABCLogLinUnitH
#define ABCLogLinUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TABCLogLinForm : public TForm
{
__published:	// IDE-managed Components
     TRadioGroup *InputGrp;
     TPanel *Panel2;
     TLabel *Label3;
     TLabel *Label4;
     TLabel *Label5;
     TLabel *Label6;
     TListBox *VarList;
     TBitBtn *RowInBtn;
     TBitBtn *RowOutBtn;
     TBitBtn *ColInBtn;
     TBitBtn *ColOutBtn;
     TBitBtn *FreqInBtn;
     TBitBtn *FreqOutBtn;
     TEdit *RowEdit;
     TEdit *ColEdit;
     TEdit *FreqEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TPanel *Panel1;
     TLabel *Label1;
     TLabel *Label2;
     TEdit *NoRowsEdit;
     TEdit *NoColsEdit;
     TStringGrid *Grid;
     TMemo *Memo1;
     TBitBtn *SliceInBtn;
     TBitBtn *SliceOutBtn;
     TLabel *Label7;
     TEdit *SliceEdit;
     TLabel *Label8;
     TEdit *NoSlicesEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall InputGrpClick(TObject *Sender);
     void __fastcall RowInBtnClick(TObject *Sender);
     void __fastcall RowOutBtnClick(TObject *Sender);
     void __fastcall ColInBtnClick(TObject *Sender);
     void __fastcall ColOutBtnClick(TObject *Sender);
     void __fastcall SliceInBtnClick(TObject *Sender);
     void __fastcall SliceOutBtnClick(TObject *Sender);
     void __fastcall NoRowsEditKeyPress(TObject *Sender, char &Key);
     void __fastcall NoColsEditKeyPress(TObject *Sender, char &Key);
     void __fastcall NoSlicesEditKeyPress(TObject *Sender, char &Key);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall FreqInBtnClick(TObject *Sender);
     void __fastcall FreqOutBtnClick(TObject *Sender);
private:	// User declarations
     void __fastcall ModelEffect(int Nrows, int Ncols, int Nslices,
                        double ***Data,
                        double *RowMarg,
                        double *ColMarg,
                        double *SliceMarg,
                        double **AB,
                        double **AC,
                        double **BC,
                        double &Total,
                        int Model);
     void __fastcall Iterate(int Nrows, int Ncols, int Nslices,
                                 double ***Data,
                                 double *RowMarg,
                                 double *ColMarg,
                                 double *SliceMarg,
                                 double &Total,
                                 double ***Expected,
                                 double *NewRowMarg,
                                 double *NewColMarg,
                                 double *NewSliceMarg,
                                 double &NewTotal);
     void __fastcall PrintTable(int Nrows, int Ncols, int Nslices,
                                    double ***Data,
                                    double *RowMarg,
                                    double *ColMarg,
                                    double *SliceMarg,
                                    double Total);
     void __fastcall PrintLamdas(int Nrows, int Ncols, int Nslices,
                                     double ****CellLambdas,
                                     double mu);
     void __fastcall PrintMatrix(double **matrix,
                                       int Nrows, int Ncols,
                                       AnsiString Title);
public:		// User declarations
     __fastcall TABCLogLinForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TABCLogLinForm *ABCLogLinForm;
//---------------------------------------------------------------------------
#endif
