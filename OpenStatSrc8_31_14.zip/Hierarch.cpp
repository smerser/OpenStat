//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "Hierarch.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmHier *FrmHier;
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];

//---------------------------------------------------------------------------
__fastcall TFrmHier::TFrmHier(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmHier::BtnCancelClick(TObject *Sender)
{
     FrmHier->Hide();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::BtnOkClick(TObject *Sender)
{
    AnsiString *varlabels, *rowlabels;
    AnsiString cellstring;
    int i, j, k, k1, k3 = 0, L, w3, n3, n4, n5, M, ingrp, col;
    int GrpCnt = 0, Nrows, Ncols, NoSelected, linecount;
    int *w2, *k4, *k5, *L1, *ColSelected;
    double Y, d1, x1, MaxError = 0.0;
    double *W, **Distance, *XAxis, *YAxis, *mean, *Var, *SD;
    char outline[81];

    NoSelected = ListBox2->Items->Count;
    if (NoSelected < 2)
    {
        ShowMessage("ERROR! Select two or more variables to analyze.");
        return;
    }
    
    Ncols = NoSelected;
    Nrows = NoCases;

    // Get stack space
    try  {
        varlabels = new AnsiString[Ncols];
        rowlabels = new AnsiString[Nrows];
        mean = new double[Ncols];
        Var = new double[Ncols];
        SD = new double[Ncols];
        W = new double[Nrows];
        XAxis = new double[Nrows];
        YAxis = new double[Nrows];
        k4 = new int[Nrows];
        k5 = new int[Nrows];
        w2 = new int[Nrows];
        L1 = new int[Nrows];
        ColSelected = new int[Ncols];
        Distance = new double*[Nrows];
        for (i = 0; i < Nrows; i++) Distance[i] = new double[Nrows];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Hierarchical Clustering.","MEMORY ERROR",MB_OK);
        exit (-1);
    }

    //Get labels and columns of selected variables
    for (i = 0; i < Ncols; i++)
    {
        cellstring = ListBox2->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
            {
                varlabels[i] = cellstring;
                ColSelected[i] = j+1;
            }
        }
    }

    // Get labels of rows
    for (i = 0; i < Nrows; i++) rowlabels[i] = MainForm->Grid->Cells[0][i+1];

    // Get data into the distance matrix
    for (i = 0; i < Nrows; i++)
    {
        if (!ValidRecord(i+1,ColSelected,NoSelected)) continue;
        for (j = 0; j < Ncols; j++)
        {
            int col = ColSelected[j];
            Distance[i][j] = atof(MainForm->Grid->Cells[col][i+1].c_str());
        }
    }

    // Calculate means and standard deviations of variables
    for (j = 0; j < Ncols; j++)
    {
        mean[j] = 0.0;
        Var[j] = 0.0;
        SD[j] = 0.0;
        for (i = 0; i < Nrows; i++)
        {
            if (!ValidRecord(i+1,ColSelected,NoSelected)) continue;
            mean[j] += Distance[i][j];
            Var[j] += (Distance[i][j] * Distance[i][j]);
        }
    }
    for (j = 0; j < Ncols; j++)
    {
        Var[j] -= (mean[j] * mean[j] / double(Nrows));
        Var[j] /= double(Nrows - 1);
        SD[j] = sqrt(Var[j]);
        mean[j] /= double(Nrows);
    }

    // Ready the output form
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Hierarchical Cluster Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Number of object to cluster = %d on %d variables.",Nrows, Ncols);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    linecount = 3;
    if (DescChkBox->Checked)
    {
       vectorprint(mean,ColSelected,Ncols,"Variable Means");
       vectorprint(Var,ColSelected,Ncols,"Variable Variances");
       vectorprint(SD,ColSelected,Ncols,"Variable Standard Deviations");
       FrmOutPut->ShowModal();
       linecount = 0;
    }
    // Standardize the distance scores if elected
    if (StdChkBox->Checked)
    {
        for (j = 0; j < Ncols; j++)
            for (i = 0; i < Nrows; i++)
                Distance[i][j] = (Distance[i][j] - mean[j]) / SD[j];
        if (RepChkBox->Checked) // replace original values in grid with z scores if elected
        {
            for (i = 0; i < Nrows; i++)
            {
                if (!ValidRecord(i+1,ColSelected,NoSelected)) continue;
                for (j = 0; j < Ncols; j++)
                {
                    int col = ColSelected[j];
                    sprintf(outline,"%6.4f",Distance[i][j]);
                    MainForm->Grid->Cells[col][i+1] = outline;
                }
            }
        }
    }

    // Convert data matrix to initial matrix of error potentials
    for (i = 0; i < Nrows; i++)
    {
        if (!ValidRecord(i+1,ColSelected,NoSelected)) continue;
        for (j = 0; j < Ncols; j++) W[j] = Distance[i][j];
        for (j = i; j < Nrows; j++)
        {
            if (!ValidRecord(j+1,ColSelected,NoSelected)) continue;
            Distance[i][j] = 0.0;
            for (k = 0; k < Ncols; k++) Distance[i][j] +=
               (Distance[j][k] - W[k]) * (Distance[j][k] - W[k]);
            Distance[i][j] /= 2.0;
        }
    }
    for (i = 0; i < Nrows; i++)
        for (j = i; j < Nrows; j++) Distance[j][i] = 0.0;

    // strcpy(outline, "Matrix of Error potentials");
    // MatPrint(Distance, Nrows, Nrows, varlabels, outline, 5, 2);

    // Now, group the cases for maximum groups down
    k1 = atoi(MaxGrpsEdit->Text.c_str());
    n3 = Nrows;

    // Initialize group membership and group-n vectors
    for (i = 0; i < Nrows; i++)
    {
        k4[i] = i;
        k5[i] = i;
        w2[i] = 1;
    }

    // create a new column for group codes if elected
    if (GridGroupsChk->Checked)
    {
       ingrp = StrToInt(GrpNoEdit->Text);
       col = NoVariables + 1;
       MainForm->Grid->Cells[col][0] = "Group";
       NewVar(col,true);
    }

    // Locate optimal combination, if more than 2 groups remain
label1:
    n3 = n3 - 1;
    if (n3 > 1)
    {
        x1 = 100000000000.0;
        for (i = 0; i < Nrows; i++)
        {
            if (k5[i] == i)
            {
                for (j = i; j < Nrows; j++)
                {
                    if ((i != j) && (k5[j] == j))
                    {
                        d1 = Distance[i][j] - Distance[i][i] - Distance[j][j];
                        if (d1 < x1)
                        {
                            x1 = d1;
                            L = i;
                            M = j;
                        } // end if
                    } // end if
                } // next j
            } // end if
        } // next i
        n4 = w2[L];
        n5 = w2[M];

        FrmOutPut->RichOutPut->Lines->Add("");
        linecount++;
        GrpCnt++;
        XAxis[GrpCnt] = n3;
        YAxis[GrpCnt] = x1;
        if (x1 > MaxError) MaxError = x1;
        sprintf(outline,"%d groups after combining group %d (n = %d ) and group %d (n = %d) error = %7.3f",
                n3, L, n4, M, n5, x1);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        linecount++;
        if (linecount >= 60)
        {
           FrmOutPut->ShowModal();
           linecount = 0;
        }
        w3 = w2[L] + w2[M];
        x1 = Distance[L][M] * w3;
        Y = Distance[L][L] * w2[L] + Distance[M][M] * w2[M];
        Distance[L][L] = Distance[L][M];
        for (i = 0; i < Nrows; i++)
            if (k5[i] == M) k5[i] = L;
        for (i = 0; i < Nrows; i++)
        {
            if ((i != L) && (k5[i] == i))
            {
                if (i <= L)
                {
                    Distance[i][L] = Distance[i][L] * (w2[i] + w2[L])
                        + Distance[i][M] * (w2[i] + w2[M])
                        + x1 - Y - Distance[i][i] * w2[i];
                    Distance[i][L] = Distance[i][L] / (w2[i] + w3);
                }
                else
                {
                    Distance[L][i] = Distance[L][i] * (w2[L] + w2[i])
                        + (Distance[M][i] + Distance[i][M]) * (w2[M] + w2[i]);
                    Distance[L][i] = (Distance[L][i]+ x1 - Y
                        - Distance[i][i] * w2[i]) / (w2[i] + w3);
                }
            }
        }
        w2[L] = w3;
        if (n3 > k1) goto label1;

        // print group memberships of all objects, if optioned
        for (i = 0; i < Nrows; i++)
        {
            if (k5[i] == i)
            {
               L = 0;
               for (j = 0; j < Nrows; j++)
               {
                   if (k5[j] == i)
                   {
                      L1[L] = k4[j];
                      if (k3 == 1) L1[L] = j;
                      L++;
                    }
                }
                if ((k3 == 1) || (k3 == 0))
                {
                    sprintf(outline,"Group %d (n= %d)",i+1,L);
                    FrmOutPut->RichOutPut->Lines->Add(outline);
                    strcpy(outline,"");
                    for (j = 0; j < L; j++)
                    {
                          sprintf(outline,"   Object = %s",rowlabels[L1[j]].c_str());
                          FrmOutPut->RichOutPut->Lines->Add(outline);
                          linecount++;
                          if ((GridGroupsChk->Checked) && (ingrp == n3))
                          {
                             MainForm->Grid->Cells[col][L1[j]+1] = IntToStr(i+1);
                          }
                    }
                    if (linecount >= 60)
                    {
                       FrmOutPut->ShowModal();
                       linecount = 0;
                    }
                } // end if
            } // end if
        } // next i
        goto label1;
    } // end if
    if (linecount > 0) FrmOutPut->ShowModal();

    if (PlotChkBox->Checked)
    {
       scatplot(XAxis, YAxis, GrpCnt, "Plot of Error vs No. of Groups",
             "No. of Groups", "Size of Error", 2.0, double(Nrows), 0.0, MaxError);
    }
    // clean up
    for (i = 0; i < Nrows; i++) delete[] Distance[i];
    delete[] Distance;
    delete[] ColSelected;
    delete[] L1;
    delete[] w2;
    delete[] k5;
    delete[] k4;
    delete[] YAxis;
    delete[] XAxis;
    delete[] W;
    delete[] SD;
    delete[] Var;
    delete[] mean;
    delete[] rowlabels;
    delete[] varlabels;

    FrmHier->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::VarInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     VarOutBtn->Enabled = true;

}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::VarOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);    
    
}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox1->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox1->Items->Strings[index];
          ListBox2->Items->Add(cellstring);
     }
     ListBox1->Clear();
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::FormShow(TObject *Sender)
{
     AnsiString cellstring;
     
     ListBox1->Clear();
     ListBox2->Clear();
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
     MaxGrpsEdit->Text = 10;
     RepChkBox->Checked = false;
     StdChkBox->Checked = true;
     VarOutBtn->Enabled = false;
     DescChkBox->Checked = false;
     PlotChkBox->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmHier::BtnResetClick(TObject *Sender)
{
     FormShow(this);
}
//---------------------------------------------------------------------------

