//---------------------------------------------------------------------------

#ifndef BayesianUnitH
#define BayesianUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TBayesianFrm : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Components1;
        TMenuItem *Help1;
        TMenuItem *Reset1;
        TMenuItem *Exit1;
        TMenuItem *DataManagement1;
        TMenuItem *Catelogue;
        TMenuItem *ProbDists;
        TMenuItem *BijnaryModels1;
        TMenuItem *UniNormalMods;
        TMenuItem *MultCatMods;
        TMenuItem *SimpRegCorr;
        TMenuItem *Utilities;
        TMenuItem *Proportions;
        TMenuItem *Means;
        TMenuItem *MultRegCorrs;
        TMenuItem *SimultGrpPredict;
        TMenuItem *OneWayAnova;
        TMenuItem *MultFactorAnova;
        TMenuItem *About1;
        TMenuItem *OverVw;
        TMenuItem *DataReduce;
        TMenuItem *DataGraphics1;
        TMenuItem *DataTransform;
        TMenuItem *DataGrouping1;
        TMenuItem *DataFiling1;
        TMenuItem *DataFileCatelogue1;
        TMenuItem *ITBSScoresSchool11;
        TMenuItem *ITBSScoresSchool21;
        TMenuItem *ESSAA;
        TMenuItem *ACT;
        TMenuItem *Normal1;
        TMenuItem *StudentsT1;
        TMenuItem *InverseChi1;
        TMenuItem *ChiSquare1;
        TMenuItem *Beta1;
        TMenuItem *BehrensFisher1;
        TMenuItem *Pareto1;
        TMenuItem *SnedecorsF1;
        TMenuItem *Binomial1;
        TMenuItem *Pascal1;
        TMenuItem *BetaBinomial1;
        TMenuItem *Poisson1;
        TMenuItem *Gamma1;
        TMenuItem *MultivariateNormal1;
        TMenuItem *MultivariateT1;
        TMenuItem *Dirichlet1;
        TMenuItem *RobustNormal1;
        TMenuItem *ExponentialPower1;
        TMenuItem *DoubleExponential1;
        TMenuItem *DoubleF1;
        TMenuItem *Wishart1;
        TMenuItem *BetaBinomialModel1;
        TMenuItem *MixedBetaBinomialModel1;
        TMenuItem *BetaPascalModel1;
        TMenuItem *MixedPascalModel1;
        TMenuItem *ComparisonoftwoProportions1;
        TMenuItem *TwoParameterNormalNaturalConjugatePriors1;
        TMenuItem *TwoParameterNormalMixedPriors1;
        TMenuItem *ComparisonofTwoMeans1;
        TMenuItem *ComparisonofTwoStandardDeviations1;
        TMenuItem *NinePointUnivariateUtility1;
        TMenuItem *NormalOgiveUtility1;
        TMenuItem *PiecewiseExpectedUtility1;
        TMenuItem *TwobyTwo1;
        TMenuItem *ThreebyThree1;
        TMenuItem *Contents1;
        void __fastcall Exit1Click(TObject *Sender);

private:	// User declarations
        int CompSelected;
        
public:		// User declarations
        __fastcall TBayesianFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBayesianFrm *BayesianFrm;
//---------------------------------------------------------------------------
#endif
