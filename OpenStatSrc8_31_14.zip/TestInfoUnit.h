//---------------------------------------------------------------------------
#ifndef TestInfoUnitH
#define TestInfoUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TTestInfoFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *NoEdit;
    TLabel *Label2;
    TEdit *TitleEdit;
    TLabel *Label3;
    TEdit *WeightEdit;
    TLabel *Label4;
    TEdit *NoItemsEdit;
    TLabel *Label5;
    TEdit *DateEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
    TLabel *Label6;
    TEdit *TestRelEdit;
private:	// User declarations
public:		// User declarations
    __fastcall TTestInfoFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestInfoFrm *TestInfoFrm;
//---------------------------------------------------------------------------
#endif
