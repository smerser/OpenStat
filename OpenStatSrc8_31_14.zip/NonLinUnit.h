//---------------------------------------------------------------------------

#ifndef NonLinUnitH
#define NonLinUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>


//---------------------------------------------------------------------------
class TEquatParseForm : public TForm
{
__published:	// IDE-managed Components
        TOpenDialog *OpenDialog1;
        TStringGrid *Grid;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ExitBtn;
        TEdit *EquationEdit;
        TLabel *Label2;
        TEdit *FileNameEdit;
        TListBox *VarList;
        TLabel *Label3;
        TBitBtn *InBtn;
        TBitBtn *OutBtn;
        TLabel *Label4;
        TLabel *Label5;
        TEdit *ResultEdit;
	TComboBox *FuncBox;
	TComboBox *OpsBox;
	TLabel *Label10;
	TLabel *Label11;
	TLabel *Label12;
	TLabel *Label13;
	TLabel *Label14;
	TLabel *Label15;
	TLabel *Label16;
	TLabel *Label17;
	TEdit *DepEdit;
	TLabel *Label18;
	TBitBtn *DepInBtn;
	TBitBtn *DepOutBtn;
	TComboBox *ComboBox1;
	TLabel *Label19;
	TEdit *StdErrYEdit;
	TGroupBox *OptBox;
	TCheckBox *ShowItsChk;
	TCheckBox *IterResultsChk;
	TLabel *Label20;
	TEdit *NoItsEdit;
	TLabel *Label21;
	TLabel *Label6;
	TEdit *AnalyzedEdit;
	TComboBox *ParmBox;
	TComboBox *VarsBox;
	TCheckBox *PlotXYBox;
	TCheckBox *PlotYYBox;
	TCheckBox *SaveBox;
	TButton *CancelBtn;
	TCheckBox *SaveResidBox;
	TCheckBox *AbsDevBox;
	TLabel *Label1;
	TEdit *ConfIntEdit;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
	void __fastcall ComputeBtnClick(TObject *Sender);
	void __fastcall FuncBoxClick(TObject *Sender);
	void __fastcall OpsBoxClick(TObject *Sender);
	void __fastcall InBtnClick(TObject *Sender);
	void __fastcall OutBtnClick(TObject *Sender);
	void __fastcall DepInBtnClick(TObject *Sender);
	void __fastcall DepOutBtnClick(TObject *Sender);
	void __fastcall ComboBox1Click(TObject *Sender);
	void __fastcall EquationEditExit(TObject *Sender);
	void __fastcall ParmBoxClick(TObject *Sender);
	void __fastcall VarsBoxClick(TObject *Sender);
private:	// User declarations
	int NVars, NParms, ycol, funcno, nrows, ncols;
   int xcols[8];
   double a, b, c, d, e, f, g, h;
   double x1, x2, x3, x4, x5, x6, x7, x8;
   double ParmValues[8];
   double Xvalues[8];
//   double UpperLimit[8];
//   double LowerLimit[8];
	char parsestr[101];
   double value;
   double **Data;
//   char op;
   double Par[8];
   double SEP[8];
   double Der[9];
   double Arr[8][9];
   double Cov[8][8];
   double xArr[8];
   double RMS;
   double oldrms;
   bool done;
	double ccSW;
	double ccAv;
	double ccSD;

//   void __fastcall TestFit(TObject *Sender);
//   double __fastcall CalcSS(double tempparms[],TObject *Sender);
   void __fastcall ReadCases(TObject *Sender);
   void __fastcall Iterate(TObject *Sender);
   double __fastcall AStudT(double p, int n);
   double __fastcall StudT(double t, int n);
   double __fastcall StatCom(double q, int i, int j, int b);
   void __fastcall Plotit(void);
   void __fastcall SavePred(void);
   void __fastcall SaveResid(void);
   void __fastcall plotxy(TObject *Sender);
   void __fastcall ReadParms(void);
   void __fastcall ReadXs(int i);

public:		// User declarations
        __fastcall TEquatParseForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEquatParseForm *EquatParseForm;
//---------------------------------------------------------------------------
#endif
