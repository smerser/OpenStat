//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "DataFuncs.h"
#include "ToleranceInterval.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TToleranceIntervalForm *ToleranceIntervalForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TToleranceIntervalForm::TToleranceIntervalForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TToleranceIntervalForm::ResetBtnClick(TObject *Sender)
{
        MeanEdit->Text = "";
        SDEdit->Text = "";
        NSizeEdit->Text = "";
        CIEdit->Text = "0.95";
        TolCIEdit->Text = "0.99";
        LowMeanCIEdit->Text = "";
        HiMeanCIEdit->Text = "";
        Left1TailEdit->Text = "";
        Right1TailEdit->Text = "";
        TwoTailTolLowEdit->Text = "";
        TwoTailTolHiEdit->Text = "";
        LowTolEdit->Text = "";
        HiTolEdit->Text = "";
        DesiredPropEdit->Text = "0.90";
        VarList->Clear();
        DepEdit->Text = "";
        Label15->Visible = false;
        VarList->Visible = false;
        Label16->Visible = false;
        DepEdit->Visible = false;
        DepIn->Visible = false;
        DepOut->Visible = false;
//        for (int i = 1; i <= NoVariables; i++)
//         VarList->Items->Add(MainForm->Grid->Cells[i][0]);

}
//---------------------------------------------------------------------------
void __fastcall TToleranceIntervalForm::RadioGroup1Click(TObject *Sender)
{
        int index, i;
        index = RadioGroup1->ItemIndex;
        if (index != 1)
        {
                VarList->Clear();
                Label15->Visible = true;
                VarList->Visible = true;
                Label16->Visible = true;
                DepEdit->Visible = true;
                DepIn->Visible = true;
                DepOut->Visible = true;
                for (i = 1; i <= NoVariables; i++)
                        VarList->Items->Add(MainForm->Grid->Cells[i][0]);
        }
}
//---------------------------------------------------------------------------
void __fastcall TToleranceIntervalForm::DepInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepIn->Visible = false;
     DepOut->Visible = true;           
}
//---------------------------------------------------------------------------
void __fastcall TToleranceIntervalForm::DepOutClick(TObject *Sender)
{
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TToleranceIntervalForm::ComputeBtnClick(TObject *Sender)
{
        int N, i, index, col;
        double mean, stddev, PcntConf, lowtol, hitol, tollow, tolhi, X;
        double variance, sum, semean, ConfInt, CI, onetail, lowonetail;
        double YL, YU, k1, k2, vdf, chisqr, a, b, z, z2, zp, zgamma, p;
        AnsiString cellstring;
        char outline[121];
        sum = 0.0;
        mean = 0.0;
        variance = 0.0;
        stddev = 0.0;
        PcntConf = 0.0;
        lowtol = 0.0;
        hitol = 0.0;
        tollow = 0.0;
        tolhi = 0.0;
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("DISTRIBUTION PARAMETER ESTIMATES");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("========================================================");
        index = RadioGroup1->ItemIndex;
        if (index != 1)  // data entered from grid
        {
                N = StrToInt(MainForm->NoCasesEdit->Text);
                col = StrToInt(MainForm->ColEdit->Text);
                cellstring = MainForm->FileNameEdit->Text;
                sprintf(outline,"%s (N = %d)  Column = %d",cellstring,N,col);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                for (i = 1; i <= N; i++)
                {
                        X = StrToFloat(MainForm->Grid->Cells[col][i]);
                        sum = sum + X;
                        mean = mean + X;
                        variance = variance + (X * X);
                }
                variance = variance - (sum * sum) / float(N);
                variance = variance / float(N - 1);
                stddev = sqrt(variance);
                semean = sqrt(variance / float(N));
                ConfInt = StrToFloat(CIEdit->Text);
                CI = ConfInt;
                mean = mean / float(N);
                MeanEdit->Text = FloatToStr(mean);
                sprintf(outline,"Mean = %8.3f",mean);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                SDEdit->Text = FloatToStr(stddev);
                sprintf(outline,"Standard Deviation = %8.3f",stddev);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"Standard Error of the Mean = %8.3f",semean);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                NSizeEdit->Text = IntToStr(N);
                onetail = ConfInt;
                lowonetail = 1.0 - onetail;
                ConfInt = (1.0 - ConfInt) / 2.0;
                ConfInt = 1.0 - ConfInt;
                if (N >120) ConfInt = semean * inversez(ConfInt);
                else ConfInt = semean * inverset(ConfInt,float(N-1));
                sprintf(outline," %5.3f Confidence Interval for mean : %10.3f to %10.3f",
                CI, mean - ConfInt, mean + ConfInt);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                LowMeanCIEdit->Text = FloatToStr(mean - ConfInt);
                HiMeanCIEdit->Text = FloatToStr(mean + ConfInt);
                onetail = semean * inverset(onetail,float(N-1));
                lowonetail = semean * inverset(lowonetail,float(N-1));
                sprintf(outline," One-tailed %5.3f Confidence for the Left of the mean = %10.3f",CI,mean + lowonetail);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                Left1TailEdit->Text = FloatToStr(mean + lowonetail);
                sprintf(outline," One-tailed %5.3f Confidence for the Right of the mean = %10.3f",CI,mean + onetail);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                Right1TailEdit->Text = FloatToStr(mean + onetail);

                CI = StrToFloat(TolCIEdit->Text);
                p = StrToFloat(DesiredPropEdit->Text);
                vdf = StrToFloat(MainForm->NoCasesEdit->Text) - 1.0;
                chisqr = inversechi(1.0 - CI, vdf);
                z = inversez((1.0 -p) / 2.0);
                z2 = z * z;
                k2 = sqrt((vdf * (1.0 + 1.0 / float(N)) * z2) / chisqr);
                YL = mean - (k2 * stddev);
                YU = mean + (k2 * stddev);
                TwoTailTolLowEdit->Text = FloatToStr(YL);
                TwoTailTolHiEdit->Text = FloatToStr(YU);
                sprintf(outline,"Low Tolerance = %10.4f and High Tolerance = %10.4f for proportion %5.3f",
                    YL, YU, p);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                zgamma = sqr(inversez(vdf));
                a = 1.0 - (zgamma / (2.0 * (N - 1.0)));
                zp = inversez(p);
                b = sqr(zp) - (zgamma / N);
                k1 = (zp + sqrt(sqr(zp) - (a * b))) / a;
                YL = mean - (k1 * stddev);
                YU = mean + (k1 * stddev);
                sprintf(outline,"Lower one-sided tolerance for proportion %5.3f = %10.4f",
                     p, YL);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"Upper one-sided tolerance for proportion %5.3f = %10.4f",
                     p, YU);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                LowTolEdit->Text = FloatToStr(YL);
                HiTolEdit->Text = FloatToStr(YU);
        }
        else
        {
                mean = StrToFloat(MeanEdit->Text);
                stddev = StrToFloat(SDEdit->Text);
                N = StrToFloat(NSizeEdit->Text);
                ConfInt = StrToFloat(CIEdit->Text);
                CI = ConfInt;
                CI = StrToFloat(TolCIEdit->Text);
                p = StrToFloat(DesiredPropEdit->Text);
                vdf = StrToFloat(MainForm->NoCasesEdit->Text) - 1.0;
                sprintf(outline,"Mean = %8.3f",mean);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"Standard Deviation = %8.3f",stddev);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                semean = stddev / sqrt(float(N));
                sprintf(outline,"Standard Error of the Mean = %8.3f",semean);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                onetail = ConfInt;
                lowonetail = 1.0 - onetail;
                ConfInt = (1.0 - ConfInt) / 2.0;
                ConfInt = 1.0 - ConfInt;
                if (N >120) ConfInt = semean * inversez(ConfInt);
                else ConfInt = semean * inverset(ConfInt,float(N-1));
                sprintf(outline," %5.3f Confidence Interval for mean : %10.3f to %10.3f",
                CI, mean - ConfInt, mean + ConfInt);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                LowMeanCIEdit->Text = FloatToStr(mean - ConfInt);
                HiMeanCIEdit->Text = FloatToStr(mean + ConfInt);
                onetail = semean * inverset(onetail,float(N-1));
                lowonetail = semean * inverset(lowonetail,float(N-1));
                sprintf(outline," One-tailed %5.3f Confidence for the Left of the mean = %10.3f",CI,mean + lowonetail);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                Left1TailEdit->Text = FloatToStr(mean + lowonetail);
                sprintf(outline," One-tailed %5.3f Confidence for the Right of the mean = %10.3f",CI,mean + onetail);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                Right1TailEdit->Text = FloatToStr(mean + onetail);

                CI = StrToFloat(TolCIEdit->Text);
                p = StrToFloat(DesiredPropEdit->Text);
                vdf = N - 1.0;
                chisqr = inversechi(1.0 - CI, N-1);
                z = inversez((1.0 - p) / 2.0);
                z2 = z * z;
//                sprintf(outline,"paramaters: chisqr = %14.5f, z = %14.5f, z2 = %14.5f",chisqr,z,z2);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
//                sprintf(outline,"parameters: p = %8.3f, vdf = %8.3f",p,vdf);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
                k2 = vdf * (1.0 + (1.0 / N));
//                sprintf(outline,"parameters: k2 = %10.3f",k2);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
                k2 = k2 * z2;
//                sprintf(outline,"parameters: k2 = %10.3f",k2);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
                k2 = k2 / chisqr;
//                sprintf(outline,"parameters: k2 = %10.3f",k2);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
                k2 = sqrt(k2);

//                sprintf(outline,"parameters: k2 = %10.3f",k2);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
//                k2 = sqrt((vdf * (1.0 + (1.0 / float(N))) * z2) / chisqr);
                YL = mean - (k2 * stddev);
                YU = mean + (k2 * stddev);
                TwoTailTolLowEdit->Text = FloatToStr(YL);
                TwoTailTolHiEdit->Text = FloatToStr(YU);
                sprintf(outline,"Low Tolerance = %10.4f and High Tolerance = %10.4f for proportion %5.3f",
                    YL, YU, p);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                zgamma = inversez(CI);
                zgamma *= zgamma;
                a = 1.0 - (zgamma / (2.0 * (N - 1.0)));
                zp = inversez(1.0 - p);
                b = (zp * zp) - (zgamma / N);
//                k1 = zp * zp;
                k1 = inverset(p,N-1.0);
//                sprintf(outline,"parameters: a = %8.3f, b = %8.3f, zgamma = %8.3f, zp = %8.3f, k1 = %8.3f",
//                   a, b, zgamma, zp, k1);
//               FrmOutPut->RichOutPut->Lines->Add(outline);

                k1 = k1 * sqrt(1.0 + 1.0 / N);
//                sprintf(outline,"parameters: a = %8.3f, b = %8.3f, zgamma = %8.3f, zp = %8.3f, k1 = %8.3f",
//                   a, b, zgamma, zp, k1);
//               FrmOutPut->RichOutPut->Lines->Add(outline);
//                k1 = k1 - (a * b);
//                sprintf(outline,"parameters: a = %8.3f, b = %8.3f, zgamma = %8.3f, zp = %8.3f, k1 = %8.3f",
//                   a, b, zgamma, zp, k1);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
//                k1 = sqrt(k1);
//                sprintf(outline,"parameters: a = %8.3f, b = %8.3f, zgamma = %8.3f, zp = %8.3f, k1 = %8.3f",
//                   a, b, zgamma, zp, k1);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
//                k1 = k1 / a;
//                sprintf(outline,"parameters: a = %8.3f, b = %8.3f, zgamma = %8.3f, zp = %8.3f, k1 = %8.3f",
//                   a, b, zgamma, zp, k1);
//                FrmOutPut->RichOutPut->Lines->Add(outline);
//                k1 = (zp + sqrt((zp * zp) - (a * b))) / a;
                YL = mean - (k1 * stddev);
                YU = mean + (k1 * stddev);
                sprintf(outline,"Lower one-sided tolerance for proportion %5.3f = %10.4f",
                     p, YL);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"Upper one-sided tolerance for proportion %5.3f = %10.4f",
                     p, YU);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                LowTolEdit->Text = FloatToStr(YL);
                HiTolEdit->Text = FloatToStr(YU);
        }
        
        FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

