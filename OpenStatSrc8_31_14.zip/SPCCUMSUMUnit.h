//---------------------------------------------------------------------------

#ifndef SPCCUMSUMUnitH
#define SPCCUMSUMUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TSPCCUMSUMForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label2;
     TEdit *GroupEdit;
     TLabel *Label3;
     TEdit *MeasEdit;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TGroupBox *GroupBox1;
     TLabel *Label4;
     TLabel *Label5;
     TLabel *Label6;
     TEdit *DeltaEdit;
     TEdit *AlphaEdit;
     TEdit *BetaEdit;
     TGroupBox *GroupBox2;
     TEdit *TargetEdit;
     TCheckBox *TargetChk;
     TCheckBox *ShowUpperChk;
     TCheckBox *ShowLowerChk;
     TCheckBox *VMaskChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PlotMeans(double * means,
                             int NoGrps,
                             double GrandMean,
                             double UCL, double LCL,
                             TObject *Sender);
private:	// User declarations
     double semean;
public:		// User declarations
     __fastcall TSPCCUMSUMForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSPCCUMSUMForm *SPCCUMSUMForm;
//---------------------------------------------------------------------------
#endif
