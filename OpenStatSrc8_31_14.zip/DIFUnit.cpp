//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "output.h"
#include "GraphUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "DIFUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDIFForm *DIFForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TDIFForm::TDIFForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Clear();
     ItemsList->Clear();
     GroupVarEdit->Text = "";
     LevelsEdit->Text = "";
     InBtn->Visible = true;
     OutBtn->Visible = false;
     AllBtn->Visible = true;
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
     ItemStatsChk->Checked = true;
     TestStatsChk->Checked = false;
     ItemTestChk->Checked = false;
     MHChk->Checked = true;
     RefGrpEdit->Text = "";
     TrgtGrpEdit->Text = "";
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     if (NoVariables > 0) LevelScroll->Max = NoVariables;
     LevelNoEdit->Text = "1";
     LowBoundEdit->Text = "0";
     UpBoundEdit->Text = "2";
     LevelScroll->Position = 1;
     //allocate space on heap
     Lbounds = new int[NoVariables];
     Ubounds = new int[NoVariables];

}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::ReturnBtnClick(TObject *Sender)
{
     delete[] Ubounds;
     Ubounds = NULL;
     delete[] Lbounds;
     Lbounds = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::InBtnClick(TObject *Sender)
{
     int index, i;

     if (VarList->ItemIndex < 0)
     {
          InBtn->Visible = false;
          return;
     }
     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            ItemsList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     OutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::OutBtnClick(TObject *Sender)
{
   int index;

   index = ItemsList->ItemIndex;
   if (index < 0)
   {
        OutBtn->Visible = false;
        return;
   }
   VarList->Items->Add(ItemsList->Items->Strings[index]);
   ItemsList->Items->Delete(index);
   InBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::AllBtnClick(TObject *Sender)
{
     int i;

     if (VarList->Items->Count < 1) return;
     for (i = 0; i <  VarList->Items->Count; i++)
          ItemsList->Items->Add(VarList->Items->Strings[i]);
     VarList->Clear();
     InBtn->Visible = false;
     OutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::GrpInBtnClick(TObject *Sender)
{
     int index;

     if (VarList->ItemIndex < 0)
     {
          GrpInBtn->Visible = false;
          return;
     }
     index = VarList->ItemIndex;
     GroupVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     GrpInBtn->Visible = false;
     GrpOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::LowBoundEditExit(TObject *Sender)
{
     int i;

     i = StrToInt(LevelNoEdit->Text);
     Lbounds[i-1] = StrToInt(LowBoundEdit->Text);
     UpBoundEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::UpBoundEditExit(TObject *Sender)
{
     int i;

     i = StrToInt(LevelNoEdit->Text);
     Ubounds[i-1] = StrToInt(UpBoundEdit->Text);
     if (i == StrToInt(LevelsEdit->Text))
     {
          ComputeBtn->SetFocus();
          return;
     }
     LowBoundEdit->Text = IntToStr(Ubounds[i-1] + 1);
     LevelScroll->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::LevelsEditExit(TObject *Sender)
{
     LevelScroll->Max = StrToInt(LevelsEdit->Text);
     LowBoundEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::LevelScrollScroll(TObject *Sender,
      TScrollCode ScrollCode, int &ScrollPos)
{
     int scrlpos, level;

     level = StrToInt(LevelNoEdit->Text);
     scrlpos = LevelScroll->Position;
     if ((scrlpos > level) && (level <= StrToInt(LevelsEdit->Text)))
     {
          LevelNoEdit->Text = IntToStr(scrlpos);
          LowBoundEdit->SetFocus();
          return;
     }
     if (scrlpos < level)
     {
          level = scrlpos;
          if (level > 0)
          {
               LevelNoEdit->Text = IntToStr(level);
               LowBoundEdit->Text = IntToStr(Lbounds[level-1]);
               UpBoundEdit->Text = IntToStr(Ubounds[level-1]);
          }
          LowBoundEdit->SetFocus();
     }
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::GrpOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(GroupVarEdit->Text);
     GroupVarEdit->Text = "";
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TDIFForm::ComputeBtnClick(TObject *Sender)
{
     int i, j, k, itm, grpvar, subjgrp, value, subjscore, scrgrpsize;
     int lower, upper, sum, TotPurge, LoopIt, RItem, FItem;
     AnsiString cellstring, title;
     int nsize[3];
     double Rtm, Wtm;
     char outline[121];
     double *Means, *Variances, *StdDevs;
     double **CorMat;  // correlations among items and total score
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     ColLabels = new AnsiString[NoVariables+1];
     RowLabels = new AnsiString[NoVariables+1];
     GetIntMatMem(Data,NoCases,NoVariables+3); //group, items, total, flag
     Tot = new int[NoCases];
     ColNoSelected = new int[NoVariables];

     LoopIt = 0;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Mantel-Haenszel DIF Analysis adapted by Bill Miller from");
     FrmOutPut->RichOutPut->Lines->Add("EZDIF written by Niels G. Waller");
     FrmOutPut->RichOutPut->Lines->Add("");

     NoItems = ItemsList->Items->Count;
     for (k = 1; k <= 2; k++) nsize[k] = 0;

     // get items to analyze and their labels
     for (i = 1; i <= NoItems; i++) // items to analyze
     {
          for (j = 1; j <= NoVariables; j++) // variables in grid
          {
               cellstring = MainForm->Grid->Cells[j][0];
               if (cellstring == ItemsList->Items->Strings[i-1])
               { // matched - save info
                     ColNoSelected[i-1] = j;
                     ColLabels[i-1] = cellstring;
                     RowLabels[i-1] = cellstring;
               } // end match
          } // next j
     } // next i
     ColLabels[NoItems] = "TOTAL";
     RowLabels[NoItems] = "TOTAL";

     // get the variable number of the grouping code
     grpvar = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GroupVarEdit->Text)  grpvar = i;
     }
     if (grpvar == 0)
     {
          delete[] ColNoSelected;
          delete[] Tot;
          ClearIntMatMem(Data,NoCases);
          delete[] RowLabels;
          delete[] ColLabels;
          ShowMessage("Error - No group variable found.");
          return;
     }
/*
     result = VarTypeChk(grpvar,1);
     if (result == 1)
     {
          delete[] ColNoSelected;
          delete[] Tot;
          ClearIntMatMem(Data,NoCases);
          delete[] RowLabels;
          delete[] ColLabels;
     }
*/
     // get number of test score levels
     nolevels = StrToInt(LevelsEdit->Text);

     // read data (score group and items)
     for (i = 1; i <= NoCases; i++)
     {
          subjscore = 0;
          value = floor(StrToFloat(Trim(MainForm->Grid->Cells[grpvar][i])));
          //result = GetValue(i,grpvar,intvalue,dblvalue,strvalue);
          //if (result == 1) value = 0;
          //else value = intvalue;
          subjgrp = 0;
          if (value == StrToInt(RefGrpEdit->Text))  subjgrp = 1; // reference grp
          if (value == StrToInt(TrgtGrpEdit->Text))  subjgrp = 2; // target group
          if (subjgrp == 0)
          {
               ShowMessage("Error - Bad group code for a subject.");
                delete[] ColNoSelected;
                delete[] Tot;
                ClearIntMatMem(Data,NoCases);
                delete[] RowLabels;
                delete[] ColLabels;
                return;
          }
          Data[i-1][0] = subjgrp;
          nsize[subjgrp] = nsize[subjgrp] + 1;
          for (j = 1; j <= NoItems; j++)
          {
               itm = ColNoSelected[j-1];
               value = floor(StrToFloat(Trim(MainForm->Grid->Cells[itm][i])));
               //result = GetValue(i,itm,intvalue,dblvalue,strvalue);
               //if (result == 1) value = 0;
               //else value = intvalue;
               if (value == 1)  subjscore = subjscore + 1;
               Data[i-1][j] = value;
          }
          Tot[i-1] = subjscore;
     }

     // obtain item means, variances, standard deviations for total subjects
     Means = new double[NoVariables];
     Variances = new double[NoVariables];
     StdDevs = new double[NoVariables];
     GetDblMatMem(CorMat,NoVariables,NoVariables);

     int prtopts = 0;
     int IER = 0;
     if (ItemStatsChk->Checked) prtopts = 1;
     IER = Correlations(Means,StdDevs,CorMat,NoItems,ColNoSelected,NoCases,3,false,prtopts);
     if (IER > 0)
     {
        ShowMessage("An item included has zero variance.  Remove from analysis.");
        goto CleanUp;
     }
     for (i = 0; i < NoItems; i++) Variances[i] = sqr(StdDevs[i]);
     // obtain total score mean, variance and stddev
     tmean = 0.0;
     tvar = 0.0;
     tsd = 0.0;
     for (i = 0; i < NoCases; i++)
     {
          tmean = tmean + Tot[i];
          tvar = tvar + (Tot[i] * Tot[i]);
     }
     tvar = (tvar - (tmean * tmean / (double)NoCases)) / (double)(NoCases - 1);
     tsd = sqrt(tvar);
     tmean = tmean / (double)NoCases;

     // Show total test score statistics if checked
     if (TestStatsChk->Checked)
     {
          sprintf(outline,"Total Score: Mean = %10.3f, Variance = %10.3f, Std.Dev. = %10.3f",
               tmean, tvar, tsd);
          cellstring = outline;
          FrmOutPut->RichOutPut->Lines->Add(cellstring);
          FrmOutPut->RichOutPut->Lines->Add("");
     }
     sprintf(outline,"Reference group size = %d, Focus group size = %d",
          nsize[1],nsize[2]);
     cellstring = outline;
     FrmOutPut->RichOutPut->Lines->Add(cellstring);
     FrmOutPut->RichOutPut->Lines->Add("");

     // get Cronbach alpha for total group if checked
     if (AlphaChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        double AlphaRel = 0.0;
        double SEMeas = 0.0;
        // get sum of item variances
        for (i = 0; i < NoItems; i++) AlphaRel = AlphaRel + Variances[i];
        AlphaRel  = AlphaRel / tvar;
        AlphaRel = 1.0 - AlphaRel;
        AlphaRel = ((double)NoItems / ((double)NoItems - 1.0)) * AlphaRel;
        SEMeas = tsd * sqrt(1.0 - AlphaRel);
        sprintf(outline,"Alpha Reliability Estimate for Test = %6.4f  S.E. of Measurement = %8.3f",
                AlphaRel,SEMeas);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     // Get item-total score correlations for total group if checked
     if (ItemTestChk->Checked)
     {
        double *Cors;
        Cors = new double[NoItems];
        // cross-products
        for (i = 0; i < NoItems; i++)
        {
           Cors[i] = 0.0;
           for (j = 0; j < NoCases; j++) Cors[i] = Cors[i] + (Data[j][i+1] * Tot[j]);
        }
        // covariances
        for (i = 0; i < NoItems; i++)
          Cors[i] = (Cors[i] - ((double)NoCases * Means[i] * tmean)) / (double)(NoCases-1);
        // correlations
        for (i = 0; i < NoItems; i++)
         Cors[i] = Cors[i] / (StdDevs[i] * tsd);
        // show results
        VPrint(Cors,NoItems,ColLabels,"Item-Total Correlations");
        // release memory
        delete[] Cors;
     }
CleanUp:     //clean up the heap for test statistics
     ClearDblMatMem(CorMat,NoVariables);
     CorMat = NULL;
     delete[] StdDevs;
     StdDevs = NULL;
     delete[] Variances;
     Variances = NULL;
     delete[] Means;
     Means = NULL;

     // Show upper and lower bounds for score group bins
     FrmOutPut->RichOutPut->Lines->Add("Conditioning Levels");
     FrmOutPut->RichOutPut->Lines->Add("Lower        Upper");
     for (i = 0; i < nolevels; i++)
     {
          sprintf(outline,"%5d        %5d",Lbounds[i],Ubounds[i]);
          cellstring = outline;
          FrmOutPut->RichOutPut->Lines->Add(cellstring);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->ShowModal();

     // check for zero variance in each group
     for (k = 1; k <= 2; k++) // group
     {
          for (i = 0; i < NoItems; i++) // item
          {
               sum = 0;
               for (j = 0; j < NoCases; j++) // subject
               {
                    if (Data[j][0] == k)   // group match ?
                    {
                         sum = sum + Data[j][i+1];
                    }
               }
          }
          if ((sum == 0) || (sum == NoVariables))
          {
               sprintf(outline,"Item %d in group %d has zero variance.",
                   i+1,k);
               cellstring = outline;
               ShowMessage(cellstring);
               return;
          }
     }

     // Get count of no. right and wrong for each item in each group
     GetIntMatMem(RMHRight,nolevels,NoItems);
     GetIntMatMem(RMHWrong,nolevels,NoItems);
     GetIntMatMem(FMHRight,nolevels,NoItems);
     GetIntMatMem(FMHWrong,nolevels,NoItems);
     GetIntMatMem(RScrGrpCnt,nolevels,NoItems);
     GetIntMatMem(FScrGrpCnt,nolevels,NoItems);
     Code = new char[NoItems];
     GetIntMatMem(Level10OK,nolevels,NoItems);
     GetIntMatMem(NT,nolevels,NoItems);
     Alpha = new double[NoItems];
     AlphaNum = new double[NoItems];
     AlphaDen = new double[NoItems];
     MHDiff = new double [NoItems];
     CodeRF = new char[NoItems];
     GetDblMatMem(ExpA,nolevels,NoItems);
     GetDblMatMem(VarA,nolevels,NoItems);
     SumA = new double[NoItems];
     SumExpA = new double[NoItems];
     SumVarA = new double[NoItems];
     ChiSqr = new double[NoItems];
     Prob = new double[NoItems];
     Aster = new AnsiString[NoItems];
     SEMHDDif = new double[NoItems];
     C = new double[NoItems];

LoopStart:
     // clear arrays
     for (j = 0; j < NoItems; j++)
     {
          for (k = 0; k < nolevels; k++)
          {
               RMHRight[k][j] = 0;
               RMHWrong[k][j] = 0;
               RScrGrpCnt[k][j] = 0;
               FMHRight[k][j] = 0;
               FMHWrong[k][j] = 0;
               FScrGrpCnt[k][j] = 0;
               Level10OK[k][j] = 1;
               NT[k][j] = 0;
               ExpA[k][j] = 0.0;
               VarA[k][j] = 0.0;
          }
          Alpha[j] = 0.0;
          AlphaNum[j] = 0.0;
          AlphaDen[j] = 0.0;
          MHDiff[j] = 0.0;
          CodeRF[j] = ' ';
          Prob[j] = 0.0;
     }

     LoopIt = LoopIt + 1;
     FrmOutPut->RichOutPut->Clear();
     sprintf(outline,"COMPUTING M-H CHI-SQUARE, PASS # %d",LoopIt);
     cellstring = outline;
     FrmOutPut->RichOutPut->Lines->Add(cellstring);
     for (k = 0; k < nolevels; k++)
     {
          for (i = 0; i < NoCases; i++)
          {
               subjgrp = Data[i][0];
               for (j = 0; j < NoItems; j++)
               {
                    RItem = 0;
                    value = Data[i][j+1];
                    if ((LoopIt == 2) && (Code[j] == 'C'))  RItem = value;
                    if (value == 1)
                    {
                         if ((Tot[i]+RItem >= Lbounds[k]) &&
                             (Tot[i]+RItem <= Ubounds[k]))
                         {
                              if (subjgrp == 1)
                              {
                                   RMHRight[k][j] = RMHRight[k][j] + 1;
                                   RScrGrpCnt[k][j] = RScrGrpCnt[k][j] + 1;
                              } // if reference group
                              if (subjgrp == 2)
                              {
                                   FMHRight[k][j] = FMHRight[k][j] + 1;
                                   FScrGrpCnt[k][j] = FScrGrpCnt[k][j] + 1;
                              } // if focus group
                         } // end if () and ()
                    } // value = 1
                    if (value == 0)
                    {
                         if ((Tot[i]+RItem >= Lbounds[k]) &&
                             (Tot[i]+RItem <= Ubounds[k]))
                         {
                              if (subjgrp == 1)
                              {
                                   RMHWrong[k][j] = RMHWrong[k][j] + 1;
                                   RScrGrpCnt[k][j] = RScrGrpCnt[k][j] + 1;
                              }
                              if (subjgrp == 2)
                              {
                                   FMHWrong[k][j] = FMHWrong[k][j] + 1;
                                   FScrGrpCnt[k][j] = FScrGrpCnt[k][j] + 1;
                              }
                         }
                    } // if value = 0
               } // next j
          } // next i
     } // next k
     for (j = 0; j < NoItems; j++) Code[j] = 'Z'; // clean out ETS code

     // print score group counts for Reference and focus subjects
     if (CountsChk->Checked)
     {
          for (i = 0; i < nolevels; i++)
          {
              sprintf(outline,"%3d-%3d",Lbounds[i],Ubounds[i]);
              RowLabels[i] = outline;
          }
          IntArrayPrint(RScrGrpCnt,nolevels,NoItems,"Score Level Counts by Item",RowLabels,ColLabels,
               "Cases in Reference Group");
          IntArrayPrint(FScrGrpCnt,nolevels,NoItems,"Score Level Counts by Item",RowLabels,ColLabels,
               "Cases in Focus Group");
     }

     // Plot Item curves if checked
     if ((CurvesChk->Checked) && (LoopIt == 1))  ItemCurves(this);

     // check for minimum of 10 per category in each item
     // compute NT
     for (j = 0; j < NoItems; j++)
     {
          for (k = 0; k < nolevels; k++)
          {
               if ((RScrGrpCnt[k][j] < 10) || (FScrGrpCnt[k][j] < 10))
                  Level10OK[k][j] = 0; // insufficient n
               else Level10OK[k][j] = 1;  // 10 or more - OK
               NT[k][j] = RScrGrpCnt[k][j] + FScrGrpCnt[k][j];
          }
     }

     for (k = 0; k < nolevels; k++)
     {
          if (Level10OK[k][0] == 0)
          {
               sprintf(outline,"Insufficient data found in level: %d - %d",
                   Lbounds[k],Ubounds[k]);
               cellstring = outline;
               FrmOutPut->RichOutPut->Lines->Add(cellstring);
          }
     }

     // compute alpha
     for (j = 0; j < NoItems; j++)
     {
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
               {
                    AlphaNum[j] = AlphaNum[j] + (double)(RMHRight[k][j] * FMHWrong[k][j]) / (double)NT[k][j];
                    AlphaDen[j] = AlphaDen[j] + (double)(RMHWrong[k][j] * FMHRight[k][j]) / (double)NT[k][j];
               }
          }
     }

     for (j = 0; j < NoItems; j++)
     {
          if (AlphaDen[j] == 0.0)
          {
               sprintf(outline,"Window too small at item %d level %d",
                   j+1,k+1);
               cellstring = outline;
               ShowMessage(cellstring);
               continue;
          }
          else
          {
               Alpha[j] = AlphaNum[j] / AlphaDen[j];
               if (Alpha[j] < 0.001) Alpha[j] = 0.001;
               MHDiff[j] = -2.35 * log(Alpha[j]);
          }
     }

     // compute expected values
     for (j = 0; j < NoItems; j++)
     {
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
               {
                    ExpA[k][j] = (double)(RScrGrpCnt[k][j] * (RMHRight[k][j] + FMHRight[k][j] )) /
                        (double)NT[k][j];
               }
          }
     }

     // compute variances
     for (j = 0; j < NoItems; j++)
     {
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
               {
                    Rtm = RMHRight[k][j] + FMHRight[k][j];
                    Wtm = RMHWrong[k][j] + FMHWrong[k][j];
                    VarA[k][j] = (double)(RScrGrpCnt[k][j] * FScrGrpCnt[k][j] * Rtm * Wtm) /
                        (double)( NT[k][j] * NT[k][j] * (NT[k][j]-1) );
               }
          }
     }

     // compute chi-squares
      for (j = 0; j < NoItems; j++)
     {
          SumA[j] = 0.0;
          SumExpA[j] = 0.0;
          SumVarA[j] = 0.0;
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
               {
                    SumA[j] = SumA[j] + RMHRight[k][j];
                    SumExpA[j] = SumExpA[j] + ExpA[k][j];
                    SumVarA[j] = SumVarA[j] + VarA[k][j];
               }
          }
     }

     for (j = 0; j < NoItems; j++)
     {
         if (SumVarA[j] == 0.0) ChiSqr[j] = 1000.0;
         else ChiSqr[j] = (sqr((fabs(SumA[j] - SumExpA[j]) - 0.5))) / SumVarA[j];
         Prob[j] = 1.0 - chisquaredprob(ChiSqr[j],1);
         if (Prob[j] > 0.05)  Aster[j] = "";
         if (Prob[j] <= 0.05)  Aster[j] = "*";
         if (Prob[j] <= 0.01)  Aster[j] = "**";
         if (Prob[j] <= 0.005)  Aster[j] = "***";
     }

     // compute std. errors
     for (j = 0; j < NoItems; j++)
     {
          C[j] = 0.0;
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
                  C[j] = C[j] + ((double)(RMHRight[k][j] * FMHWrong[k][j]) / (double)NT[k][j]);
          }
     }

     for (j = 0; j < NoItems; j++)
     {
          SEMHDDif[j] = 0.0;
          for (k = 0; k < nolevels; k++)
          {
               if (Level10OK[k][j] == 1)
               {
                    SEMHDDif[j] = SEMHDDif[j] + (double)( (RMHRight[k][j] * FMHWrong[k][j] )
                        + ( Alpha[j] * RMHWrong[k][j] * FMHRight[k][j])) *
                        ( RMHRight[k][j] + FMHWrong[k][j] + Alpha[j] *
                        ( RMHWrong[k][j]  + FMHRight[k][j] )) / (double)( 2 * NT[k][j] * NT[k][j]);
               }
          }
     }

     for (j = 0; j < NoItems; j++)
     {
         if (SEMHDDif[j] <= 0.0) SEMHDDif[j] = 0;
         if (C[j] == 0) SEMHDDif[j] = 0.0;
         else SEMHDDif[j] = (2.35 / C[j]) * sqrt(SEMHDDif[j]);
     }

     // code results with ETS codes
     for (j = 0; j < NoItems; j++)
     {
          if ( (fabs(MHDiff[j]) > 1.5) && ((fabs(MHDiff[j]) - (1.96 * SEMHDDif[j])
            > 1.0)))  Code[j] = 'C';
          if ((fabs(MHDiff[j]) - (1.96 * SEMHDDif[j]) <= 0.0) ||
              (fabs(MHDiff[j]) <= 1.0))   Code[j] = 'A';
          if ((Code[j] != 'A') && (Code[j] != 'C'))  Code[j] = 'B';
     }

     // purge
     TotPurge = 0;
     for (j = 0; j < NoItems; j++)
     {
          if (Code[j] == 'C')
          {
               TotPurge = TotPurge + 1;
               for (i = 0; i < NoCases; i++) Tot[i] = Tot[i] - Data[i][j+1];
               if (Alpha[j] > 1.0)  CodeRF[j] = 'R';
               if (Alpha[j] < 1.0)  CodeRF[j] = 'F';
          }
     }

     // show results
     FrmOutPut->RichOutPut->Lines->Add(
          "CODES ITEM     SIG.  ALPHA   CHI2    P-VALUE    MH D-DIF   S.E. MH D-DIF");
     for (j = 0; j < NoItems; j++)
     {
          sprintf(outline,"%1c %1c %4d      %3s %6.3f   %7.3f  %6.3f     %6.3f       %6.3f",
              Code[j],CodeRF[j], j+1, Aster[j].c_str(),Alpha[j],ChiSqr[j],Prob[j],MHDiff[j],
              SEMHDDif[j]);
          cellstring = outline;
          FrmOutPut->RichOutPut->Lines->Add(cellstring);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     if (LoopIt == 1)
     {
          sprintf(outline,"No. of items purged in pass 1 = %d",TotPurge);
          cellstring = outline;
          FrmOutPut->RichOutPut->Lines->Add(cellstring);
          FrmOutPut->RichOutPut->Lines->Add("Item Numbers:");
          for (j = 0; j < NoItems; j++)
          {
               if (Code[j] == 'C')
               {
                    sprintf(outline,"%d",j+1);
                    cellstring = outline;
                    FrmOutPut->RichOutPut->Lines->Add(cellstring);
               }
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->ShowModal();
     if (LoopIt < 2)  goto LoopStart;

     // clean up the heap
     delete[] C;
     C = NULL;
     delete[] SEMHDDif;
     SEMHDDif = NULL;
     delete[] Aster;
     Aster = NULL;
     delete[] Prob;
     Prob = NULL;
     delete[] ChiSqr;
     ChiSqr = NULL;
     delete[] SumVarA;
     SumVarA = NULL;
     delete[] SumExpA;
     SumExpA = NULL;
     delete[] SumA;
     SumA = NULL;
     ClearDblMatMem(VarA,nolevels);
     VarA = NULL;
     ClearDblMatMem(ExpA,nolevels);
     ExpA = NULL;
     delete[] CodeRF;
     CodeRF = NULL;
     delete[] MHDiff;
     MHDiff = NULL;
     delete[] AlphaDen;
     AlphaDen = NULL;
     delete[] AlphaNum;
     AlphaNum = NULL;
     delete[] Alpha;
     Alpha = NULL;
     ClearIntMatMem(NT,nolevels);
     NT = NULL;
     ClearIntMatMem(Level10OK,nolevels);
     Level10OK = NULL;
     delete[] Code;
     Code = NULL;
     ClearIntMatMem(FScrGrpCnt,nolevels);
     FScrGrpCnt = NULL;
     ClearIntMatMem(RScrGrpCnt,nolevels);
     RScrGrpCnt = NULL;
     ClearIntMatMem(FMHWrong,nolevels);
     FMHWrong = NULL;
     ClearIntMatMem(FMHRight,nolevels);
     FMHRight = NULL;
     ClearIntMatMem(RMHWrong,nolevels);
     RMHWrong = NULL;
     ClearIntMatMem(RMHRight,nolevels);
     RMHRight = NULL;
     delete[] ColNoSelected;
     ColNoSelected = NULL;
     delete[] Tot;
     Tot = NULL;
     ClearIntMatMem(Data,NoCases);
     Data = NULL;
     delete[] RowLabels;
     RowLabels = NULL;
     delete[] ColLabels;
     ColLabels = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TDIFForm::ItemCurves(TObject *Sender)
{
     int i, ii, j;
     double **XPlotPts;
     double **YPlotPts;
     AnsiString LabelStr, xTitle, yTitle;
     char outline[121];
     int max;

     GetDblMatMem(YPlotPts,2,nolevels);
     GetDblMatMem(XPlotPts,1,nolevels);

     // get maximum no. of scores in either groups bins
     for (i = 0; i < NoItems; i++)
     {
          max = 0;
          for (j = 0; j < nolevels; j++)
          {
               if (RMHRight[j][i] > max)  max = RMHRight[j][i];
               if (FMHRight[j][i] > max)  max = FMHRight[j][i];
          }

          // Plot reference group in blue, focus group in red
          for (ii = 1; ii <= 2; ii++) // possible group curves
          {
               for  (j = 0; j < nolevels; j++)  //get points to plot
               {
                    XPlotPts[0][j] = Lbounds[j];
                    if (ii == 1)  YPlotPts[ii-1][j] = RMHRight[j][i];
                    if (ii == 2)  YPlotPts[ii-1][j] = FMHRight[j][i];
               }
          } // next group

          // Plot the points
          GraphForm->BackColor = clWhite;
          GraphForm->ShowLeftWall = true;
          GraphForm->ShowRightWall = true;
          GraphForm->ShowBottomWall = true;
          GraphForm->ShowBackWall = true;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlue;
          GraphForm->FloorColor = clBlue;
          sprintf(outline,"Blue = Reference, Red = Focus for item %d",i+1);
          GraphForm->Heading = outline;
          xTitle = "Lower bounds of levels";
          GraphForm->XTitle = xTitle;
          yTitle = "Frequencies";
          GraphForm->YTitle = yTitle;
          GraphForm->nosets = 2;
          GraphForm->nbars = nolevels;
          GraphForm->barwideprop = 0.5;
          GraphForm->miny = 0.0;
          GraphForm->maxy = max;
          GraphForm->AutoScale = false;
          GraphForm->GraphType = 6; // 2d line charts
          GraphForm->PtLabels = false;
          for (ii = 1; ii <= 2; ii++)
          {
               if (ii == 1)  LabelStr = "Reference";
               if (ii == 2)  LabelStr = "Focus";
               GraphForm->SetLabels[ii] = LabelStr;
          }
          GraphForm->Ypoints = YPlotPts;
          GraphForm->Xpoints = XPlotPts;
          GraphForm->ShowModal();
     } // next item

     ClearDblMatMem(XPlotPts,1);
     ClearDblMatMem(YPlotPts,2);
}
//-------------------------------------------------------------------

void __fastcall TDIFForm::LowBoundEditKeyPress(TObject *Sender, char &Key)
{
     if (Key == 13) UpBoundEdit->SetFocus(); // return key
}
//---------------------------------------------------------------------------

void __fastcall TDIFForm::CancelBtnClick(TObject *Sender)
{
     delete[] Ubounds;
     Ubounds = NULL;
     delete[] Lbounds;
     Lbounds = NULL;
}
//---------------------------------------------------------------------------

