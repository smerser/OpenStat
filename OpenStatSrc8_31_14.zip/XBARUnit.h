//---------------------------------------------------------------------------

#ifndef XBARUnitH
#define XBARUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TXBARForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label2;
     TEdit *GroupEdit;
     TLabel *Label3;
     TEdit *MeasEdit;
     TRadioGroup *SigmaGroup;
     TEdit *SigmaEdit;
     TGroupBox *OptionsGroup;
     TCheckBox *ShowUpperChk;
     TCheckBox *ShowLowerChk;
     TCheckBox *UseTargetChk;
     TEdit *UpperSpecEdit;
     TEdit *LowerSpecEdit;
     TEdit *TargetSpecEdit;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall PlotMeans(double *means,
                     int NoGrps,
                     double UCL, double LCL, double GrandMean,
                     double TargetSpec, double LowerSpec, double UpperSpec,
                     TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TXBARForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TXBARForm *XBARForm;
//---------------------------------------------------------------------------
#endif
