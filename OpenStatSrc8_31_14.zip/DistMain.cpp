//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DistMain.h"
#include "dcdflib.h"
#include "stdio.h"
#include <math.h>
#include "Printers.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDistMainForm *DistMainForm;
//---------------------------------------------------------------------------
__fastcall TDistMainForm::TDistMainForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDistMainForm::FormShow(TObject *Sender)
{
     int Yincr, Xincr;
     AnsiString astring;
     char valstr[5];

     //ParmBox->Visible = false;
     //ParmBox2->Visible = false;
     PlotLabel->Visible = false;
     ImageHi = Image1->Height;
     ImageWide = Image1->Width;
     Xstart = ImageWide / 10;
     Xend = (ImageWide * 9) / 10;
     Ystart = ImageHi / 10;
     Yend = (ImageHi * 9) / 10;
     Image1->Canvas->Pen->Color = clBlack;
     Image1->Canvas->Brush->Color = clWhite;
     Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);

}
//---------------------------------------------------------------------------
void __fastcall TDistMainForm::ExitBtnClick(TObject *Sender)
{
     return;
}
//---------------------------------------------------------------------------
void __fastcall TDistMainForm::CumCompBtnClick(TObject *Sender)
{
     AnsiString Caption, Xlabel, Ylabel;
     char title[100];
     double s, xn, pr, ompr, X, Y;

     selected = CumGroup->ItemIndex + 1;
     switch (selected)
     {  // cumulative distribution frequencies
           case 1 : // binomial cdf
           {
                Which = 1;
                s = StrToFloat(ParmEdit1->Text);
                xn = StrToFloat(ParmEdit2->Text);
                pr = StrToFloat(ParmEdit3->Text);
                if (ceil(s) != s ||s < 0)
                {
                Application->MessageBox("Input a nonnegative integer for N Observed","Information",MB_OK);
                return;
                }
                if (ceil(xn)!=xn||xn<=0)
                {
                Application->MessageBox("N Trials must be a positive integer","ERROR!",MB_OK);
                return;
                }
                if (pr <= 0 ||pr >= 1)
                {
                Application->MessageBox("Input a value between 0 and 1 for the probability","ERROR!",MB_OK);
                return;
                }
                ompr = 1.0 - pr;
                cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
   //            ParmEdit4->Text = FloatToStr(P);
  //             ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);
                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Binomial CDF (%5.0f,%5.0f,  %5.3f )",s,xn,pr);
                Caption = title;
                Xlabel = "Events Observed";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double xincr = xn / 100.0;
                for (int i = 0; i <= 100; i++) // plot upper part and lower part
                {
                    s = i * xincr;
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    Xplot[i] = s;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 2 : // normal cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                double Mean = StrToFloat(ParmEdit2->Text);
                double StdDev = StrToFloat(ParmEdit3->Text);
                if (StdDev <= 0 )
                {
                Application->MessageBox("Standard deviation must be positive","ERROR!",MB_OK);
                return;
                }
                cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
     //           ParmEdit4->Text = FloatToStr(P);
    //            ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                Mean = StrToFloat(ParmEdit2->Text);
                StdDev = StrToFloat(ParmEdit3->Text);
                sprintf(title,"Normal CDF ( %5.3f, %5.3f, %5.3f )",X,Mean,StdDev);
                Caption = title;
                Xlabel = "X";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double xincr = (6.0 * StdDev) / 100.0;
                X = Mean -3.0 * StdDev;
                for (int i = 0; i <= 100; i++) // plot from 0 to 100
                {
                    cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 3 : // chi-square cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample chi-square
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                if (X < 0)
                {
                Application->MessageBox("Chi-square observed must be nonnegative","ERROR!",MB_OK);
                return;
                }
                if (Y<=0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
      //          ParmEdit3->Text = FloatToStr(P);
      //          ParmEdit4->Text = FloatToStr(Q);
                ParmEdit3->Text = FormatFloat("0.000000",P);
                ParmEdit4->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Chi-square CDF ( %5.3f, d.f. =%5.1f )",X,Y);
                Caption = title;
                Xlabel = "Chi-square Observed";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                X = 0.0;
                double tecto;
                if (Y >= 60 || Y < 20 ) {tecto = 2.5*Y;} else {tecto = 100;}
                double xincr = tecto / 100.0;
                for (int i = 0; i <= 100; i++) // plot chi-square from 0 to 100
                {
                    X = xincr * i;
                    cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 1.0;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 4 : // student t cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample t
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                if (Y<=0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                cdft(&Which,&P,&Q,&X,&Y,&Status,&Bound);
    //            ParmEdit3->Text = FloatToStr(P);
     //           ParmEdit4->Text = FloatToStr(Q);
                ParmEdit3->Text = FormatFloat("0.000000",P);
                ParmEdit4->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = -4 to 4
                sprintf(title,"t CDF ( t = %5.3f, d.f. =%5.1f )",X,Y);
                PlotLabel->Caption = title;
                Caption = title;
                Xlabel = "t Observed";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double xincr = 8.0 / 100.0;
                X = -4.0;
                for (int i = 0; i <= 100; i++) // plot chi-square from 0 to 100
                {
                    cdft(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 5 : // F cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample F value
                double df1 = StrToFloat(ParmEdit2->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit3->Text); // deg. freedom denominator
                if (X <= 0)
                {
                Application->MessageBox("F value must be positive","ERROR!",MB_OK);
                return;
                }
                if (df1 <= 0 || df2 <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
      //          ParmEdit4->Text = FloatToStr(P);
      //          ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 100 in steps of 1
                sprintf(title,"F CDF ( %5.3f,%5.1f, %5.1f )",X,df1,df2);
                Caption = title;
                Xlabel = "Observed F";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot F from 0 to 10
                {
                    cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 0.1;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 6 : // Poisson cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                double Mean = StrToFloat(ParmEdit2->Text);
                if (ceil(X)!= X || X < 0)
                {
                Application->MessageBox("Input a nonnegative integer for N Observed","Information",MB_OK);
                return;
                }
                if (Mean <= 0)
                {
                Application->MessageBox("Mean must be positive","ERROR!",MB_OK);
                return;
                }
                cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
       //         ParmEdit4->Text = FloatToStr(P);
       //         ParmEdit5->Text = FloatToStr(Q);
                ParmEdit3->Text = FormatFloat("0.000000",P);
                ParmEdit4->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Poisson CDF (%5.0f, %5.3f )",X,Mean);
                Caption = title;
                Xlabel = "X";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double tecto;
                if (2*Mean > 20) {tecto = 2*Mean;} else {tecto = 20;}
                double xincr = tecto / 100.0;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot from 0 to 100
                {
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 7 : // beta cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                A = StrToFloat(ParmEdit2->Text);
                B = StrToFloat(ParmEdit3->Text);
                Y = 1.0 - X;
                cdfbet(&Which,&P,&Q,&X,&Y,&A,&B,&Status,&Bound);
                if (X < 0 || X > 1)
                {
                Application->MessageBox("X value must between 0 and 1","ERROR!",MB_OK);
                return;
                }
                if (A <= 0)
                {
                Application->MessageBox("Parameter A must be positive","ERROR!",MB_OK);
                return;
                }
                if (B <= 0)
                {
                Application->MessageBox("Parameter B must be positive","ERROR!",MB_OK);
                return;
                }
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Beta CDF ( %5.3f, %5.3f, %5.3f )",X,A,B);
                Caption = title;
                Xlabel = "X value";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double xincr = 0.01;
                for (int i = 0; i <= 100; i++) // plot upper part and lower part
                {
                    X = i * xincr;
                    Y = 1.0 - X;
                    cdfbet(&Which,&P,&Q,&X,&Y,&A,&B,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 8 : // Gamma cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                double shape = StrToFloat(ParmEdit2->Text);
                double scale = StrToFloat(ParmEdit3->Text);
                if (X < 0)
                {
                Application->MessageBox("Gamma value must be nonegative","ERROR!",MB_OK);
                return;
                }
                if (shape <= 0)
                {
                Application->MessageBox("Shape parameter must be positive","ERROR!",MB_OK);
                return;
                }
                if (scale <= 0)
                {
                Application->MessageBox("Scale parameter must be positive","ERROR!",MB_OK);
                return;
                }
                cdfgam(&Which,&P,&Q,&X,&shape,&scale,&Status,&Bound);
        //        ParmEdit4->Text = FloatToStr(P);
         //       ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Gamma CDF ( %5.3f, %5.3f, %5.3f )",X,shape,scale);
                Caption = title;
                Xlabel = "X value";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot from 0 to 100
                {
                    cdfgam(&Which,&P,&Q,&X,&shape,&scale,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 1.0;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 9 : // negative binomial cdf
           {
                // clean graphic
                for (int i = 0; i <= 100; i++)
                {Yplot[i]= 0.0; Xplot[i]= 0.0;}
                
                Which = 1;
                s = StrToFloat(ParmEdit1->Text);
                xn = StrToFloat(ParmEdit2->Text);
                pr = StrToFloat(ParmEdit3->Text);
                ompr = 1.0 - pr;
                if (ceil(s) != s ||s < 0)
                {
                Application->MessageBox("Input a nonnegative integer for N Failures","Information",MB_OK);
                return;
                }
                if (ceil(xn)!=xn||xn<=0)
                {
                Application->MessageBox("N Successes must be a positive integer","ERROR!",MB_OK);
                return;
                }
                if (pr <= 0 ||pr >= 1)
                {
                Application->MessageBox("Input a value between 0 and 1 for the probability","ERROR!",MB_OK);
                return;
                }
                cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
    //            ParmEdit4->Text = FloatToStr(P);
    //            ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"Negative Binomial CDF (%5.0f,%5.0f, %5.3f )",s,xn,pr);
                Caption = title;
                Xlabel = "Failures Observed";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                double tecto;
                tecto = 4*(xn * ompr)/pr;
                double xincr;
                xincr = tecto / 100.0;
                for (int i = 0; i <= 100; i++) // plot upper part and lower part
                {
                    s = i * xincr;
                    cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    Xplot[i] = s;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 10 : // non-central chi-square cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample chi-square
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                double pnonc = StrToFloat(ParmEdit3->Text);
                if (X < 0)
                {
                Application->MessageBox("Non-Central Chi-square observed must be nonnegative","ERROR!",MB_OK);
                return;
                }
                if (Y <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                if (pnonc < 0)
                {
                Application->MessageBox("The noncentrality parameter must be nonnegative","ERROR!",MB_OK);
                return;
                }
                cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
     //           ParmEdit4->Text = FloatToStr(P);
     //           ParmEdit5->Text = FloatToStr(Q);
                ParmEdit4->Text = FormatFloat("0.000000",P);
                ParmEdit5->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 100 in steps of 1
                sprintf(title,"Non-Central Chi-square CDF ( %5.3f,%5.0f, %5.3f )",X,Y,pnonc);
                Caption = title;
                Xlabel = "Noncentral Chi-square Observed";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot chi-square from 0 to 100
                {
                    cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 1.0;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 11 : // non-central F cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample F value
                double df1 = StrToFloat(ParmEdit2->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit3->Text); // deg. freedom denominator
                double phonc = StrToFloat(ParmEdit4->Text); // non-centrality parameter
                cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
       //         ParmEdit4->Text = FloatToStr(P);
        //        ParmEdit5->Text = FloatToStr(Q);
                if (X <= 0)
                {
                Application->MessageBox("F value must be positive","ERROR!",MB_OK);
                return;
                }
                if (df1 <= 0 || df2 <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                Q = 1 - P;
                ParmEdit5->Text = FormatFloat("0.000000",P);
                ParmEdit6->Text = FormatFloat("0.000000",Q);
                ParmEdit7->Text = IntToStr(Status);
                sprintf(title,"Noncentral F CDF ( %5.3f,%5.0f, %5.0f, %5.3f )",X,df1,df2,phonc);
                Caption = title;
                Xlabel = "Observed F";
                Ylabel = "Prob.";
                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot F from 0 to 10
                {
                    cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 0.1;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TDistMainForm::ProbCompBtnClick(TObject *Sender)
{
     AnsiString Xlabel, Ylabel, Caption;
     char title[101];

     selected = ProbGroup->ItemIndex + 1;
     switch (selected)
     {    // probability distribution frequencies
           case 1 : // binomial probability
           {
               //                        N   (X)     (N-X)
               // binary probability = (   )P   (1-P)
               //

               // clean graphic
                for (int i = 0; i <= 100; i++)
                {Yplot[i]= 0.0; Xplot[i]= 0.0;}
                
                Which = 1;
                PlotLabel->Visible = true;
                double s = StrToFloat(ParmEdit11->Text);  // observed
                double xn = StrToFloat(ParmEdit12->Text); // trials
                double pr = StrToFloat(ParmEdit13->Text); // probability
                if (ceil(s)!=s||s<0)
                {
                Application->MessageBox("N Observed must be a nonnegative integer","ERROR!",MB_OK);
                return;
                }
                if (ceil(xn)!=xn||xn<=0)
                {
                Application->MessageBox("N Trials must be a positive integer","ERROR!",MB_OK);
                return;
                }
                if (pr <= 0 ||pr >= 1)
                {
                Application->MessageBox("Input a value between 0 and 1 for the probability","ERROR!",MB_OK);
                return;
                }
                double ompr;
             //   double combins;
            //    combins = combinations(ceil(s),ceil(xn));
            //    P = combins * pow(pr,s) * pow(1.0-pr,xn-s);
                ompr = 1.0 - pr;
                cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                double p2 = P;
                double s2 = s;
                if (s >= 1)
                {
                s = s - 1;
                cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                P = p2 - P;
                }
                else {P = p2;}
                Q = 1.0 - P;
    //            ParmEdit14->Text = FloatToStr(P);
     //           ParmEdit15->Text = FloatToStr(Q);
                ParmEdit14->Text = FormatFloat("0.000000",P);
                ParmEdit15->Text = FormatFloat("0.000000",Q);
                double start = 0.0;
                double tecto;
                s = 0.0;
                if (xn <= 100) {tecto = xn;}
                else if (xn > 100 && floor(xn * pr + 50) <= xn) {start = max(0.0,floor(xn * pr - 50)); tecto = 100;}
                else {tecto = 100;}
                for (int i = 0; i <= tecto; i++)
                {
                    s = i + start;
                    s = ceil(s);
                    Xplot[i] = s;
                    ompr = 1.0 - pr;
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    double p2 = P;
                    if (s >= 1)
                    {
                    s = s - 1;
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    P = p2 - P;
                    }
                    else {P = p2;}

           //         combins = combinations(ceil(s),ceil(xn));
            //        P = combins * pow(pr,s) * pow(1.0-pr,xn-s);
                    Yplot[i] = P;
                }
                sprintf(title,"Binomial PF (%5.0f,%5.0f,  %5.3f )",s2,xn,pr);
                Caption = title;
                Xlabel = "Events Observed";
                Ylabel = "Prob.";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
                      /* Application->MessageBox("No plot is made for N > 100","Information",MB_OK);
                       for (int i = 1; i <= 100; i++) {Yplot[i] = 0; Xplot[i]=i;}
                       Xplot[0]=0; Yplot[0]=1;
                       PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
                       break;
                       */
                break;
           }
           case 2 : // normal probability
           {
                // h = (1 / ((2 * PI)^.5*StdDev) ) e^(-((x-Mean)/StdDev)^2 / 2)
                X = StrToFloat(ParmEdit11->Text);
                double Mean = StrToFloat(ParmEdit12->Text);
                double StdDev = StrToFloat(ParmEdit13->Text);
                double x = X;
                if (StdDev <= 0 )
                {
                        Application->MessageBox("Standard deviation must be positive","ERROR!",MB_OK);
                        return;
                }
                Y = (1.0 / (StdDev * sqrt(2.0 * M_PI)))* exp(-((x-Mean)/StdDev)*((x-Mean)/StdDev)/ 2.0);
     //           ParmEdit14->Text = FloatToStr(Y);
                ParmEdit14->Text = FormatFloat("0.000000",Y);
                x = Mean -3.0 * StdDev;
                double xincr = (6.0 * StdDev)/ 100;
                for (int i = 0; i <= 100; i++)
                {
                    x += xincr;
                    Y = (1.0 / (StdDev * sqrt(2.0 * M_PI)))* exp(-((x-Mean)/StdDev)*((x-Mean)/StdDev)/ 2.0);
                    Xplot[i] = x;
                    Yplot[i] = Y;
                }
                sprintf(title,"Normal PDF ( %5.3f, %5.3f, %5.3f )",X,Mean,StdDev);
                Caption = title;
                //Caption = "Normal PDF";
                Xlabel = "X value";
                Ylabel = "Density f";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 3 : // chi-square probability
           {
                //           n-2    -X
                //           ---    --
                //            2      2
                //       X         e
                //  h = -------------------
                //           n    ___
                //           --   |  |   n
                //           2    |    ( - )
                //        2       |      2
                //
                PlotLabel->Visible = true;
                double num;
                double den;
                double LnGamma;
                double Gamma;
                double fraction;
                X = StrToFloat(ParmEdit11->Text);
                Y = StrToFloat(ParmEdit12->Text);
                if (Y <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                if (X <= 0)
                {
                Application->MessageBox("Chi-square observed must be positive","ERROR!",MB_OK);
                return;
                }
                num = pow(X,(Y-2.0)/2.0) * exp(-X / 2.0);
                fraction = Y / 2.0;
                LnGamma = alngam(&fraction);
                Gamma = exp(LnGamma);
                den = pow(2.0,fraction) * Gamma;
                P = num / den;
             //   ParmEdit13->Text = FloatToStr(P);
                ParmEdit13->Text = FormatFloat("0.000000",P);
                sprintf(title,"Chi-square PDF ( %5.3f, d.f. =%5.1f )",X,Y);
                X = 0.0;
                Caption = title;
                Xlabel = "Chi-square value";
                Ylabel = "Density f";
                double tecto;
                if (Y >= 60 || Y < 20) {tecto = 2.6*Y;} else {tecto = 100;}
                double xincr = tecto / 100;
                X = 0.0;
                for (int i = 0; i <= 100; i++)
                {
                    //X += 1.0;
                    X += xincr;
                    num = pow(X,(Y-2.0)/2.0) * exp(-X / 2.0);
                    fraction = Y / 2.0;
                    LnGamma = alngam(&fraction);
                    Gamma = exp(LnGamma);
                    den = pow(2.0,fraction) * Gamma;
                    P = num / den;
                    Xplot[i] = X;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 4 : // student t probability
           {
                PlotLabel->Visible = true;
                double fraction1;
                double fraction2;
                double term1;
                double term2;
                double term3;
                X = StrToFloat(ParmEdit11->Text); // t value
                Y = StrToFloat(ParmEdit12->Text); // deg. freedom
                if (Y<=0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                fraction1 = (Y+1.0) / 2.0;
                fraction2 = Y / 2.0;
                term1 = exp(alngam(&fraction1) - alngam(&fraction2));
                term2 = 1.0 / sqrt(Y * M_PI);
                term3 = 1.0 / pow((1.0 + (X * X / Y)),(Y+1.0)/2.0);
                P = term1 * term2 * term3;
     //           ParmEdit13->Text = FloatToStr(P);
                ParmEdit13->Text = FormatFloat("0.000000",P);
                sprintf(title,"t PDF ( t = %5.3f, d.f. =%5.1f )",X,Y);
                Caption = title;
                //PlotLabel->Caption = title;
                Xlabel = "t value";
                Ylabel = "Density f";
                X = -5.0;
                double xincr = 10.0 / 100.0;
                for (int i = 0; i <= 100; i++)
                {
                    term3 = 1.0 / pow((1.0 + (X * X / Y)),(Y+1.0)/2.0);
                    P = term1 * term2 * term3;
                    Q = 1.0 - P;
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 5 : // F probability
           {
                //
                double LnGamma1;
                double LnGamma2;
                double LnGamma3;
                double num1;
                double num2;
                double den2;
                double df1;
                double df2;
                double term1;
                double fraction;
                X = StrToFloat(ParmEdit11->Text);
                df1 = StrToFloat(ParmEdit12->Text);
                df2 = StrToFloat(ParmEdit13->Text);
                if (X <= 0)
                {
                Application->MessageBox("F Value must be positive","ERROR!",MB_OK);
                return;
                }
                if (df1 <= 0 || df2 <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                num1 = (df1 + df2) / 2.0;
                LnGamma1 = alngam(&num1);
                fraction = df1 / 2.0;
                LnGamma2 = alngam(&fraction);
                fraction = df2 / 2.0;
                LnGamma3 = alngam(&fraction);
                term1 = exp(LnGamma1 - LnGamma2 - LnGamma3);
                fraction = pow( (df1/df2),(df1/2.0));
                num2 = pow(X,(df1-2.0)/2.0);
                den2 = pow( (1.0+(df1/df2)*X),(df1+df2)/2.0);
                P = term1 * fraction * (num2 / den2);
     //           ParmEdit4->Text = FloatToStr(P);
                ParmEdit14->Text = FormatFloat("0.000000",P);
                sprintf(title,"F PDF ( %5.3f,%5.1f, %5.1f )",X,df1,df2);
                Caption = title;
                X = 0.0;
                for (int i = 0; i <= 100; i++)
                {
                    num1 = (df1 + df2) / 2.0;
                    LnGamma1 = alngam(&num1);
                    fraction = df1 / 2.0;
                    LnGamma2 = alngam(&fraction);
                    fraction = df2 / 2.0;
                    LnGamma3 = alngam(&fraction);
                    term1 = exp(LnGamma1 - LnGamma2 - LnGamma3);
                    fraction = pow( (df1/df2),(df1/2.0));
                    num2 = pow(X,(df1-2.0)/2.0);
                    den2 = pow( (1.0+(df1/df2)*X),(df1+df2)/2.0);
                    P = term1 * fraction * (num2 / den2);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 0.1;
                }
               // Caption = "F PDF";
                Ylabel = "Density f";
                Xlabel = "F value";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 6 : // Poisson probability
           {
                // clean graphic
                for (int i = 0; i <= 100; i++)
                {Yplot[i]= 0.0; Xplot[i]= 0.0;}
                Which = 1;
                X = StrToFloat(ParmEdit11->Text);
                double Mean = StrToFloat(ParmEdit12->Text);
                if (ceil(X)!= X || X < 0)
                {
                Application->MessageBox("N Observed must be a nonnegative integer","ERROR!",MB_OK);
                return;
                }
                if (Mean <= 0)
                {
                Application->MessageBox("Mean must be positive","ERROR!",MB_OK);
                return;
                }
                cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                double p2 = P;
                double X2 = X;
                if (X >= 1)
                {
                X = X - 1;
                cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                P = p2 - P;
                }
                else {P = p2;}
                Q = 1.0 - P;
                ParmEdit13->Text = FormatFloat("0.000000",P);
                ParmEdit14->Text = FormatFloat("0.000000",Q);
                double start = 0.0;
                double tecto;
                if (ceil(Mean) > 10 && ceil(Mean) < 51) {tecto = 2*ceil(Mean);}
                else if (ceil(Mean) <= 10) {tecto = 20;}
                else {tecto = 100; start = ceil(Mean)-50;}
                X = 0.0;
                //for (int i = 0; i <= 100; i++) Yplot[i] = 0.0;
                for (int i = 0; i <= tecto; i++)
                {
                    X = i + start;
                    Xplot[i] = X;
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    double p2 = P;
                    if (X >= 1)
                    {
                    X = X - 1;
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    P = p2 - P;
                    }
                    else {P = p2;}
                    Yplot[i] = P;
                }
                sprintf(title,"Poisson PF (%5.0f, %5.3f )",X2,Mean);
                Caption = title;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
                Xlabel = "X value";
                Ylabel = "Prob.";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
                break;
           }
           case 7 : // beta probability
           {
                X = StrToFloat(ParmEdit11->Text);
                A = StrToFloat(ParmEdit12->Text);
                B = StrToFloat(ParmEdit13->Text);
                if (X < 0 || X > 1)
                {
                Application->MessageBox("X value must between 0 and 1","ERROR!",MB_OK);
                return;
                }
                if (A <= 0)
                {
                Application->MessageBox("Parameter A must be positive","ERROR!",MB_OK);
                return;
                }
                if (B <= 0)
                {
                Application->MessageBox("Parameter B must be positive","ERROR!",MB_OK);
                return;
                }
                Y = 1.0 - X;
 //               double result;
//                result = brcmp1(&mu,&A,&B,&X,&Y);
  //              ParmEdit5->Text = FloatToStr(result);
 //               double xmax = 0.0;
                double LnGammaA;
                double GammaA;
                double LnGammaB;
                double GammaB;
                double LnGammaAB;
                double GammaAB;
                double AplusB = A + B;
                double Beta;
                double result;
                LnGammaA = alngam(&A);
                GammaA = exp(LnGammaA);
                LnGammaB = alngam(&B);
                GammaB = exp(LnGammaB);
                LnGammaAB = alngam(&AplusB);
                GammaAB = exp(LnGammaAB);
                Beta = GammaAB / (GammaA * GammaB);
                result = Beta * pow(Y,(B-1.0)) * pow(X,(A-1.0));
                ParmEdit14->Text = FormatFloat("0.000000",result);
                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Beta PDF ( %5.3f, %5.3f, %5.3f )",X,A,B);
                Caption = title;
                Xlabel = "X value";
                Ylabel = "Density f";
                PlotLabel->Visible = true;
//                Image1->Canvas->MoveTo(Xstart,Yend);
                X = 0.0;
                double xincr = 0.01;
                for (int i = 1; i <= 100; i++) // plot pdf
                {
                    X += xincr;
                    Y = 1.0 - X;
                    LnGammaA = alngam(&A);
                    GammaA = exp(LnGammaA);
                    LnGammaB = alngam(&B);
                    GammaB = exp(LnGammaB);
                    LnGammaAB = alngam(&AplusB);
                    GammaAB = exp(LnGammaAB);
                    Beta = GammaAB / (GammaA * GammaB);
                    result = Beta * pow(Y,(B-1.0)) * pow(X,(A-1.0));
                    Xplot[i-1] = X;
                    Yplot[i-1] = result;
//                    bratio(&A,&B,&X,&Y,&W,&W1,&ierr);  // incomplete beta ratio (Density function)
 //                   if (result > xmax) xmax = result;
//                    cdfbet(&Which,&P,&Q,&X,&Y,&A,&B,&Status,&Bound);
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
//                FrmOutPut->ShowModal();
 //               ParmLabel7->Caption = "Dx Y";
  //              ParmEdit17->Text = FloatToStr(xmax);
                break;
           }
           case 8 : // Gamma probability
           {
                //        b^a        a-1 -X.b
                //  y = ----------- X   e
                //      Gamma(a)
                //
                PlotLabel->Visible = true;
                X = StrToFloat(ParmEdit11->Text);
                double shape = StrToFloat(ParmEdit12->Text);
                double scale = StrToFloat(ParmEdit13->Text);
                if (X <= 0)
                {
                Application->MessageBox("Gamma value must be positive","ERROR!",MB_OK);
                return;
                }
                if (shape <= 0)
                {
                Application->MessageBox("Shape parameter must be positive","ERROR!",MB_OK);
                return;
                }
                if (scale <= 0)
                {
                Application->MessageBox("Scale parameter must be positive","ERROR!",MB_OK);
                return;
                }
                double LnGamma;
                double Gamma;
                LnGamma = alngam(&shape);
                Gamma = exp(LnGamma);
                Y = (pow(scale,shape)/Gamma) * pow(X,shape-1.0) * exp(-X * scale);
                ParmEdit14->Text = FormatFloat("0.000000",Y);
                sprintf(title,"Gamma PDF ( %5.3f, %5.3f, %5.3f )",X,shape,scale);
                Caption = title;
                X = 0.01;
                P =  (pow(scale,shape)/Gamma) * pow(X,shape-1) * exp(-X * scale);
                Yplot[0] = P;
                X = 1.0;
                for (int i = 1; i <= 100; i++) // plot from 0 to 100
                {
                    Xplot[i] = X;
                    P =  (pow(scale,shape)/Gamma) * pow(X,shape-1) * exp(-X * scale);
                    Yplot[i] = P;
                    X += 1.0;
                }
                Xlabel = "X value";
                Ylabel = "Density f";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 9 : // negative binomial probability
           {
                // clean graphic
                for (int i = 0; i <= 100; i++)
                {Yplot[i]= 0.0; Xplot[i]= 0.0;}

                Which = 1;
                double s = StrToFloat(ParmEdit11->Text);
                double xn = StrToFloat(ParmEdit12->Text);
                double pr = StrToFloat(ParmEdit13->Text);
                double ompr = 1.0 - pr;
                if (ceil(s) != s ||s < 0)
                {
                Application->MessageBox("Number of Failures must be a nonnegative integer","ERROR!",MB_OK);
                return;
                }
                if (ceil(xn)!=xn||xn<=0)
                {
                Application->MessageBox("Number of Successes must be a positive integer","ERROR!",MB_OK);
                return;
                }
                if (pr <= 0 ||pr >= 1)
                {
                Application->MessageBox("Input a value between 0 and 1 for the probability","ERROR!",MB_OK);
                return;
                }
                cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                double p2 = P;
                double s2 = s;
                if (s >= 1)
                {
                s = s - 1;
                cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                P = p2 - P;
                }
                else {P = p2;}
                Q = 1.0 - P;
    //            ParmEdit14->Text = FloatToStr(P);
     //           ParmEdit15->Text = FloatToStr(Q);
                ParmEdit14->Text = FormatFloat("0.000000",P);
                ParmEdit15->Text = FormatFloat("0.000000",Q);
                // plot distribution
                double tecto;
                double start = 0.0;
                s = 0.0;
                if (floor(xn * ompr /pr - 50) >= 0) {start = floor(xn * ompr /pr - 50); tecto = 100;}
                else {tecto = 100;}
                for (int i = 0; i <= tecto; i++)
                {
                    s = i + start;
                    s = ceil(s);
                    cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    p2 = P;
                    if (s >= 1)
                    {
                    s = s - 1;
                    cdfnbn(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    P = p2 - P;
                    }
                    else {P = p2;}
                    Xplot[i] = s;
                    Yplot[i] = P;
                }
                sprintf(title,"Negative Binomial PF (%5.0f,%5.0f, %5.3f )",s2,xn,pr);
                Caption = title;
                Xlabel = "Failures Observed";
                Ylabel = "Prob.";
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
                break;
           }
           case 10 : // non-central chi-square probability
           {
                Which = 1;
                X = StrToFloat(ParmEdit11->Text); // sample chi-square
                Y = StrToFloat(ParmEdit12->Text); // deg. freedom
                double pnonc = StrToFloat(ParmEdit13->Text);
                if (X < 0)
                {
                Application->MessageBox("Non-Central Chi-square observed must be nonnegative","ERROR!",MB_OK);
                return;
                }
                if (Y <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                if (pnonc < 0)
                {
                Application->MessageBox("The noncentrality parameter must be nonnegative","ERROR!",MB_OK);
                return;
                }
                cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                X = (X - 0.00001);
                double p2 = P;
                cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                P = (p2 - P)/0.00001;
                ParmEdit14->Text = FormatFloat("0.000000",P);
               // ParmEdit17->Text = IntToStr(Status);
                // plot distribution for P = 0 to 100 in steps of 1
                sprintf(title,"Noncentral Chi-square PDF ( %5.3f,%5.0f, %5.3f )",X,Y,pnonc);
                Caption = title;
                Xlabel = "Noncentral Chi-square value";
                Ylabel = "Density f";
                PlotLabel->Visible = true;
                X = 0.00001;
                cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                p2 = P;
                X = X - 0.000001;
                cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                P = (p2 - P)/0.000001;
                Xplot[0] = 0.0;
                Yplot[0] = P;
                X = 0.0;
                for (int i = 1; i <= 100; i++) // plot non-central prob. chi-square from 0 to 100
                {
                    X = i;
                    cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                    p2 = P;
                    X = X - 0.00001;
                    cdfchn(&Which,&P,&Q,&X,&Y,&pnonc,&Status,&Bound);
                    P = (p2 - P)/0.00001;
                    Xplot[i] = i;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 11 : // non-central F probability
           {
                Which = 1;
                X = StrToFloat(ParmEdit11->Text); // sample F value
                double df1 = StrToFloat(ParmEdit12->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit13->Text); // deg. freedom denominator
                double phonc = StrToFloat(ParmEdit14->Text); // non-centrality parameter
       //         ParmEdit4->Text = FloatToStr(P);
        //        ParmEdit5->Text = FloatToStr(Q);
                if (X <= 0)
                {
                Application->MessageBox("F value must be positive","ERROR!",MB_OK);
                return;
                }
                if (df1 <= 0 || df2 <= 0)
                {
                Application->MessageBox("The number of degrees of freedom must be positive","ERROR!",MB_OK);
                return;
                }
                if (phonc < 0)
                {
                Application->MessageBox("The noncentrality parameter must be nonnegative","ERROR!",MB_OK);
                return;
                }
                cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                X = (X - 0.00001);
                double p2 = P;
                cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                P = (p2 - P)/0.00001;
                ParmEdit15->Text = FormatFloat("0.000000",P);
               // ParmEdit17->Text = IntToStr(Status);
                // plot distribution for P = 0 to 100 in steps of 1
                sprintf(title,"Noncentral F PDF ( %5.3f,%5.0f, %5.0f, %5.3f )",X,df1,df2,phonc);
                Caption = title;
                Xlabel = "Noncentral F value";
                Ylabel = "Density f";
                PlotLabel->Visible = true;
                X = 0.00001;
                cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                p2 = P;
                X = X - 0.000001;
                cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                P = (p2 - P)/0.000001;
                Xplot[0] = 0.0;
                Yplot[0] = P;
                X = 0.0;
                for (int i = 1; i <= 100; i++) // plot non-central prob. chi-square from 0 to 10
                {
                    X = 0.1 * i;
                    cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                    p2 = P;
                    X = X - 0.000001;
                    cdffnc(&Which,&P,&Q,&X,&df1,&df2,&phonc,&Status,&Bound);
                    P = (p2 - P)/0.000001;
                    Xplot[i] = i;
                    Yplot[i] = P;
                }
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                break;
           }
     }
}
//---------------------------------------------------------------------------

void __fastcall TDistMainForm::CumGroupClick(TObject *Sender)
{
     selected = CumGroup->ItemIndex + 1;
     switch (selected)
     {
           case 1 : // binomial cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "2";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "N Trials";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Even Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "P";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Q";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 2 : // normal cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "x value";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "0.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "0.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Std. Dev.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "1.0";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 3 : // chi-square cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Chi-square";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "5.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "3";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "";
                ParmLabel5->Visible = false;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = false;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 4 : // student t cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "t value";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "";
                ParmLabel5->Visible = false;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = false;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 5 : // F cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "F value";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Num.Deg.F.";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "5";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Den.Deg.F.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "10";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 6 : // Poisson cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "2";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "";
                ParmLabel5->Visible = false;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = false;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 7 : // beta cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "X value";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "0.3";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "A";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "2.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "B";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "2.0";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 8 : // Gamma cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Gamma value";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Shape Param.";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "2.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Scale Param.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.1";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 9 : // negative binomial cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Failures";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "3";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "N Successes";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "5";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Even Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.3";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "P";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Q";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 10 : // non-central chi-square cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Noncentral X2";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "5.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "3";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Noncentrality";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "1.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 11 : // non-central F cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Noncentral F";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Num.Deg.F.";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "5";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Den.Deg.F.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "10";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Centrality";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "1-Prob.";
                ParmLabel6->Visible = true;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = true;
                ParmLabel7->Caption = "Status";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TDistMainForm::ProbGroupClick(TObject *Sender)
{
      selected = ProbGroup->ItemIndex + 1;
     switch (selected)
     {
           case 1 : // binomial pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "N Observed";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "2";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "N Trials";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "10";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Even Prob.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "0.5";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "P";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "Q";
                ParmLabel15->Visible = true;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = true;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 2 : // normal pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "x value";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "0.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Mean";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "0.0";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Std. Dev.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "1.0";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Density f";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 3 : // chi-square pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "Chi-square";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "5.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Deg.Freedom";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "3";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Density f";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "";
                ParmLabel14->Visible = false;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = false;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 4 : // student t pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "t value";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "1.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Deg.Freedom";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "10";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Density f";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "";
                ParmLabel14->Visible = false;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = false;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 5 : // F pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "F value";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "1.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Num.Deg.F.";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "5";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Den.Deg.F.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "10";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Density f";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 6 : // Poisson pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "N Observed";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "2";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Mean";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "10.0";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Prob.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "1-Prob.";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 7 : // beta pdf
           {
                ParmBox->Visible = true;
                ParmLabel11->Caption = "X value";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "0.3";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "A";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "2.0";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "B";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "2.0";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Density f";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 8 : // Gamma pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "Gamma value";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "1.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Shape Param.";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "2.0";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Scale Param.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "0.1";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Density f";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 9 : // negative binomial pdf
           {
                ParmBox->Visible = true;
                ParmLabel11->Caption = "N Failures";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "3";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "N Successes";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "5";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Even Prob.";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "0.3";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "P";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "Q";
                ParmLabel15->Visible = true;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = true;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 10 : // non-central chi-square pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "Noncentral X2";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "5.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Deg.Freedom";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "3";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Noncentrality";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "1.5";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Density f";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "";
                ParmLabel15->Visible = false;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = false;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
           case 11 : // non-central F pdf
           {
                ParmBox2->Visible = true;
                ParmLabel11->Caption = "Noncentral F";
                ParmLabel11->Visible = true;
                ParmEdit11->Text = "1.0";
                ParmEdit11->Visible = true;
                ParmLabel12->Caption = "Num.Deg.F";
                ParmLabel12->Visible = true;
                ParmEdit12->Text = "5";
                ParmEdit12->Visible = true;
                ParmLabel13->Caption = "Den.Deg.F";
                ParmLabel13->Visible = true;
                ParmEdit13->Text = "10";
                ParmEdit13->Visible = true;
                ParmLabel14->Caption = "Noncentrality";
                ParmLabel14->Visible = true;
                ParmEdit14->Text = "0.5";
                ParmEdit14->Visible = true;
                ParmLabel15->Caption = "Density f";
                ParmLabel15->Visible = true;
                ParmEdit15->Text = "";
                ParmEdit15->Visible = true;
                ParmLabel16->Caption = "";
                ParmLabel16->Visible = false;
                ParmEdit16->Text = "";
                ParmEdit16->Visible = false;
                ParmLabel17->Caption = "Status";
                ParmLabel17->Visible = false;
                ParmEdit17->Text = "";
                ParmEdit17->Visible = false;
                break;
           }
     }

}
//---------------------------------------------------------------------------

void TDistMainForm::PlotXY(double *Xplot, double *Yplot, AnsiString Xlabel,
                           AnsiString Ylabel, AnsiString Caption, bool continuous)
{
     int Yincr, Xincr, xprop, yprop, TextHi;
     int LabelWide = Image1->Canvas->TextWidth(Xlabel);
     double Yrange, Ymin, Ymax, Xrange, Xmin, Xmax, Xstep, Ystep;
     char valstr[95];
     AnsiString astring;

     Image1->Canvas->Pen->Color = clRed;
     Image1->Canvas->Brush->Color = clWhite;
     Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);

     Image1->Canvas->TextOutA(Xstart-5,Ystart-15,Ylabel);
     PlotLabel->Caption = Caption;
     Image1->Canvas->TextOutA((Xend-Xstart)/2- LabelWide / 2,Yend+ 20,Xlabel);

     // draw axis lines
     Image1->Canvas->MoveTo(Xstart,Yend);
     Image1->Canvas->LineTo(Xend,Yend);
     Image1->Canvas->MoveTo(Xstart,Yend);
     Image1->Canvas->LineTo(Xstart,Ystart);

     // get min, max and range of Y
     Ymin = 1.0e300;
     Ymax = -1.0e300;
     for (int i = 0; i < 100; i++)
     {
         if (Yplot[i] > Ymax) Ymax = Yplot[i];
         if (Yplot[i] < Ymin) Ymin = Yplot[i];
     }
     Yrange = Ymax - Ymin;
     Ystep = Yrange / 10;
     // get min, max and range of X
     Xmin = 1.0e300;
     Xmax = -1.0e300;
     for (int i = 0; i < 100; i++)
     {
         if (Xplot[i] > Xmax) Xmax = Xplot[i];
         if (Xplot[i] < Xmin) Xmin = Xplot[i];
     }
     Xrange = Xmax - Xmin;
     Xstep = Xrange / 10;

     // create y axis values
     Yincr = (Yend - Ystart) / 10;
     for (int i = 0; i < 11; i++) // print Y axis values
     {
         int place = Yend - (i * Yincr);
         float value = Ymin + (Ystep * i);
         sprintf(valstr,"%4.2f",value);
         astring = valstr;
         TextHi = Image1->Canvas->TextHeight(astring);
         Image1->Canvas->TextOutA(Xstart-25,place-TextHi,astring);
     }

     // create x axis values
     Xincr = (Xend - Xstart) / 10;
     for (int i = 0; i < 11; i++) // print x axis
     {
         int place = Xstart + (i * Xincr);
         float value = Xmin + (i * Xstep);
         sprintf(valstr,"%4.2f",value);
         astring = valstr;
         Image1->Canvas->TextOutA(place,Yend + 10,astring);
     }

     // plot the x, y values
     xprop = Xstart + ceil(((Xplot[0]-Xmin) / Xrange) * (Xend - Xstart));
     yprop = Yend - ceil(((Yplot[0]-Ymin) / Yrange) * (Yend - Ystart));
     if (continuous) Image1->Canvas->MoveTo(xprop,yprop);
     else Image1->Canvas->MoveTo(xprop,Yend);
     for (int i = 0; i < 99; i++)
     {
         xprop = Xstart + ceil(((Xplot[i]-Xmin) / Xrange) * (Xend - Xstart));
         yprop = Yend - ceil(((Yplot[i]-Ymin) / Yrange) * (Yend - Ystart));
//         sprintf(valstr,"%5.3f %5.3f %5d %5d",Xplot[i],Yplot[i],xprop,yprop);
         if (continuous) Image1->Canvas->LineTo(xprop,yprop);
         else
         {
             Image1->Canvas->MoveTo(xprop,Yend);
             Image1->Canvas->LineTo(xprop,yprop);
         }
     }

}
//---------------------------------------------------------------------------

double MyProdSums(double N, double A)
{
    double Total = 1.0;
    double i;

    for (i = A; i <= N; i++) Total *= i;
    return (Total);
}
//---------------------------------------------------------------------------

int TDistMainForm::combinations(int X, int N)
{
/*
    int combos;
    double logfact1, logfact2, logfact3;

    logfact1 = 0.0;
    logfact2 = 0.0;
    logfact3 = 0.0;
    if (N > 0)
    {
       for (int i = 1; i <= N; i++) logfact1 += log(i);
    }
    else logfact1 = log(1);

    if (X > 0)
    {
       for (int i = 1; i <= X; i++) logfact2 += log(i);
    }
    else logfact2 = log(1);

    if (N-X > 0)
    {
       for (int i = 1; i <= (N-X); i++) logfact3 += log(i);
    }
    else logfact3 = log(1);

    combos = exp(logfact1 - logfact2 - logfact3);
    return (combos);
*/

/*   double Y, numerator, denominator;
    double Total = 1.0;
    double i;

    Y = N - X;
    if (Y > X)
    {
        for (i = Y+1; i <= N; i++) Total *= i;
        numerator = Total;
        Total = 1.0;
        for (i = 1; i <= X; i++) Total *= i;
        denominator = Total;
    }
    else
    {
        for (i = X+1; i <= N; i++) Total *= i;
        numerator = Total;
        Total = 1.0;
        for (i = 1; i <= Y; i++) Total *= i;
        denominator = Total;
    }
    return ((int) (numerator / denominator));
*/
    double Y, numerator, denominator;
    double Total = 1.0;
    double i;
    Y = N - X;
        if (X <= N/2)
    {
        for (i = 2; i <= X; i++) Total *= (i+Y)/i;
        Total *= (Y+1);
    }
        else
    {
        for (i = 2; i <= Y; i++) Total *= (i+X)/i;
        Total *= (X+1);
    }
    if (X==1||Y==1)
    {Total=N;}
    if (X==0||Y==0)
    {Total=1;}
    return ((int) (Total));
}
//---------------------------------------------------------------------------


void __fastcall TDistMainForm::PrintBtnClick(TObject *Sender)
{
       TPrinter *Prntr = Printer();
       Prntr->Orientation = poPortrait;

       TRect r = Rect(20,20,Prntr->PageWidth-20,Prntr->PageHeight / 2 + 20);
       Prntr->BeginDoc();
       Prntr->Canvas->StretchDraw(r, Image1->Picture->Bitmap);
       Prntr->EndDoc();
}
//---------------------------------------------------------------------------

void __fastcall TDistMainForm::SaveImgBtnClick(TObject *Sender)
{
        AnsiString as;

        as = InputBox("Image File","NAME:","Distribution.bmp");
        Image1->Picture->SaveToFile(as);
}
//---------------------------------------------------------------------------

