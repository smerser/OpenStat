//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MemMgrUnit.h"
#include "math.h"
#include "DataFuncs.h"
#include "MainUnit.h"
#include "GraphUnit.h"
#include "DictionaryUnit.h"
#include "GroupFreqUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGroupFreqForm *GroupFreqForm;
extern int NoCases;
extern int NoVariables;
//---------------------------------------------------------------------------
__fastcall TGroupFreqForm::TGroupFreqForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGroupFreqForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 0; i < NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i+1][0]);
     GrpVarEdit->Text = "";
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TGroupFreqForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TGroupFreqForm::GrpInBtnClick(TObject *Sender)
{
     int index;

     index = Varlist->ItemIndex;
     if (index < 0) return;
     GrpVarEdit->Text = Varlist->Items->Strings[index];
     Varlist->Items->Delete(index);
     GrpInBtn->Visible = false;
     GrpOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TGroupFreqForm::GrpOutBtnClick(TObject *Sender)
{
     if (GrpVarEdit->Text == "") return;
     Varlist->Items->Add(GrpVarEdit->Text);
     GrpVarEdit->Text = "";
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TGroupFreqForm::OKBtnClick(TObject *Sender)
{
     int nogroups, mingrp, maxgrp, grpcol, tempcol, value, minfreq, maxfreq;
     int *freq; // frequency of scores within each group
     AnsiString Label;
     bool results, prompt;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;
     
     // First, get the variables of the analysis
     grpcol = 0;
     for (int i = 1; i <= NoVariables; i++)
     {
         if (MainForm->Grid->Cells[i][0] == GrpVarEdit->Text) grpcol = i;
     }

     if (grpcol == 0)
     {
        ShowMessage("ERROR!  First select a group variable.");
        return;
     }

     // check to see if strcol is a string variable
     Label = DictionaryForm->DGrid->Cells[3][grpcol];
     if (Label == "2") // recode into an integer code
     {
        results = StringsToInt(grpcol, tempcol, false);
        grpcol = NoVariables;
     }

     //result = VarTypeChk(grpcol,1);
     //if (result == 1) return;

     Label = MainForm->Grid->Cells[grpcol][0];

     // get min and max of group variable
     mingrp = 1000;
     maxgrp = -1000;
     for (int i = 1; i <= NoCases; i++)
     {
         if (! ValidValue(i,grpcol)) continue;
         value = floor(StrToFloat(Trim(MainForm->Grid->Cells[grpcol][i])));
         //result = GetValue(i, grpcol, intvalue, dblvalue, strvalue);
         //if (result != 0) value = 0;
         //else value = intvalue;
         if (value < mingrp) mingrp = value;
         if (value > maxgrp) maxgrp = value;
     }
     nogroups = maxgrp - mingrp + 1;
     if (nogroups <= 1)
     {
        ShowMessage("ERROR! One or fewer groups found.  Is variable defined as integer?");
        return;
     }

     // setup frequency array and count cases in each group
     freq = new int[nogroups+1];
     for (int i = 0; i < nogroups+1; i++) freq[i] = 0;
     for (int i = 1; i <= NoCases; i++)
     {
         if (! ValidValue(i,grpcol)) continue;
         value = floor(StrToFloat(Trim(MainForm->Grid->Cells[grpcol][i])));
         //result = GetValue(i, grpcol, intvalue, dblvalue, strvalue);
         //if (result != 0) value = 0;
         //else value = intvalue;
         value = value - mingrp; // adjust to zero for lowest group
         freq[value]++;
     }

     // get min and max frequencies and check for existence of a range
     minfreq = 10000;
     maxfreq = -10000;
     for (int i = 0; i < nogroups; i++)
     {
         if (freq[i] < minfreq) minfreq = freq[i];
         if (freq[i] > maxfreq) maxfreq = freq[i];
     }
     if (minfreq == maxfreq)
     {
         ShowMessage("ERROR!  All groups have equal frequency.  Cannot plot.");
         delete[] freq;
         return;
     }

     // now graph the frequencies
     GetDblMatMem(GraphForm->Xpoints,1,nogroups+1);
     GetDblMatMem(GraphForm->Ypoints,1,nogroups+1);

     GraphForm->GraphType = PlotGrp->ItemIndex;
     GraphForm->nosets = 1;
     GraphForm->nbars = nogroups;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlue;
     GraphForm->FloorColor = clGray;
     GraphForm->Heading = "Frequency Distribution";
     GraphForm->XTitle = "Values of " + Label;
     GraphForm->YTitle = "Frequency";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxfreq;
     GraphForm->ShowLeftWall = true;
     GraphForm->ShowRightWall = true;
     GraphForm->ShowBottomWall = true;
     for (int k = 0; k <= nogroups; k++)
     {
            GraphForm->Ypoints[0][k] = (double)freq[k];
            GraphForm->Xpoints[0][k] = (double) (mingrp + k);
     }
     GraphForm->ShowModal();
//     if (results == false) DeleteaCol(grpcol);

     // cleanup
     ClearDblMatMem(GraphForm->Ypoints,1);
     ClearDblMatMem(GraphForm->Xpoints,1);
     delete[] freq;
}
//---------------------------------------------------------------------------
