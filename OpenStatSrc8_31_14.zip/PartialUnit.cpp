//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <math.h>
#include <stdio.h>
#include "output.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include "PartialUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;

TFrmPartial *FrmPartial;
//---------------------------------------------------------------------------
__fastcall TFrmPartial::TFrmPartial(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmPartial::FormShow(TObject *Sender)
{
    DepEdit->Text = "";
    VarList->Clear();
    Predictors->Clear();
    Partialled->Clear();
    PredOutBtn->Enabled = false;
    PredInBtn->Enabled = true;
    DepInBtn->Enabled = true;
    CntrlInBtn->Enabled = true;
    CntrlOutBtn->Enabled = false;
    for (int i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);    
}
//---------------------------------------------------------------------------
void __fastcall TFrmPartial::ResetBtnClick(TObject *Sender)
{
    FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmPartial::DepInBtnClick(TObject *Sender)
{
    int index, count;

    index = VarList->ItemIndex;
    DepEdit->Text = VarList->Items->Strings[index];
    DepInBtn->Enabled = false;
    count = 1;
    while (count > 0)
    {
        for (int i = 0; i < VarList->Items->Count; i++)
        {
            if (VarList->Selected[i])
            {
                VarList->Items->Delete(i);
                count--;
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::PredInBtnClick(TObject *Sender)
{
    int index, count = 0;
    AnsiString cellstring;

    index = VarList->Items->Count;
    for (int i = 0; i < index; i++)
    {
         if (VarList->Selected[i])
         {
            cellstring = VarList->Items->Strings[i];
            Predictors->Items->Add(cellstring);
            count++;
         }
    }
    PredOutBtn->Enabled = true;
    while (count > 0)
    {
        for (int i = 0; i < VarList->Items->Count; i++)
        {
            if (VarList->Selected[i])
            {
                VarList->Items->Delete(i);
                count--;
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::CntrlInBtnClick(TObject *Sender)
{
    int index, count = 0;
    AnsiString cellstring;

    index = VarList->Items->Count;
    for (int i = 0; i < index; i++)
    {
         if (VarList->Selected[i])
         {
            cellstring = VarList->Items->Strings[i];
            Partialled->Items->Add(cellstring);
            count++;
         }
    }
    CntrlOutBtn->Enabled = true;
    while (count > 0)
    {
        for (int i = 0; i < VarList->Items->Count; i++)
        {
            if (VarList->Selected[i])
            {
                VarList->Items->Delete(i);
                count--;
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::PredOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = Predictors->ItemIndex;
     cellstring = Predictors->Items->Strings[index];
     VarList->Items->Add(cellstring);
     Predictors->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::CntrlOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = Partialled->ItemIndex;
     cellstring = Partialled->Items->Strings[index];
     VarList->Items->Add(cellstring);
     Partialled->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::CancelBtnClick(TObject *Sender)
{
    FrmPartial->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::ReturnClick(TObject *Sender)
{
    FrmPartial->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmPartial::ComputeBtnClick(TObject *Sender)
{
    double **rmatrix, **inverse, **workmat, *Means, *StdDevs;
    double **V, *W, *Betas, R2Full, R2Cntrl, SemiPart, Partial;
    double df1, df2, F, Prob;
    int NoPredVars=0, NoCntrlVars=0, DepVarNo, *PredVars, *CntrlVars;
    int *MatVars, TotNoVars = 0, pcnt, ccnt, IER = 0, count;
    AnsiString varstring;
    char outline[81];
    int result;

    // Get no. of predictor and control VarList
    NoPredVars = Predictors->Items->Count;
    NoCntrlVars = Partialled->Items->Count;
    if ((NoPredVars == 0) || (NoCntrlVars == 0))
    {
        Application->MessageBox("You must select at least one predictor and one control variable!","ERROR!",MB_OK);
        return;
    }
    TotNoVars = NoPredVars + NoCntrlVars + 1;
    count = NoCases;
    // Allocate space required
    try
    {
        rmatrix = new double *[TotNoVars];
        for (int i = 0; i < TotNoVars; i++) rmatrix[i] = new double[TotNoVars];
        inverse = new double *[TotNoVars+1];
        for (int i = 0; i < TotNoVars+1; i++) inverse[i] = new double[TotNoVars+1];
        workmat = new double *[TotNoVars+1];
        for (int i = 0; i < TotNoVars+1; i++) workmat[i] = new double[TotNoVars+1];
        PredVars = new int[NoPredVars];
        CntrlVars = new int[NoCntrlVars];
        MatVars = new int[TotNoVars];
        Means = new double[TotNoVars];
        StdDevs = new double[TotNoVars];
        V = new double *[TotNoVars+1];
        for (int i = 0; i < TotNoVars+1; i++) V[i] = new double[TotNoVars+1];
        W = new double[TotNoVars+1];
        Betas = new double[TotNoVars];
    }
    catch (...)
    {
        Application->MessageBox("Error in allocating memory.","MEM. ERROR",MB_OK);
        exit (1);
    }

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Partial and Semi-Partial Correlation Analysis");

    // Get column numbers of dependent, predictor and control VarList
    pcnt = 0;
    for (int i = 0; i < NoPredVars; i++)
    {
        varstring = Predictors->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
        {
            if (varstring == MainForm->Grid->Cells[j+1][0])
            {
                PredVars[pcnt] = j + 1;
                pcnt++;
            }
        }
    }
    ccnt = 0;
    for (int i = 0; i < NoCntrlVars; i++)
    {
        varstring = Partialled->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
        {
            if (varstring == MainForm->Grid->Cells[j+1][0])
            {
                CntrlVars[ccnt] = j + 1;
                ccnt++;
            }
        }
    }
    varstring = DepEdit->Text;
    for (int i = 0; i < NoVariables; i++)
        if (varstring == MainForm->Grid->Cells[i+1][0]) DepVarNo = i+1;
/*
    // check for valid variable types
    result = VarTypeChk(DepVarNo,0);
    if (result == 1) goto cleanup;
    for (int i = 0; i < NoPredVars; i++)
    {
        result = VarTypeChk(PredVars[i],0);
        if (result == 1) goto cleanup;
    }
    if (NoCntrlVars > 0)
    {
        for (int i = 0; i < NoCntrlVars; i++)
        {
                result = VarTypeChk(CntrlVars[i],0);
                if (result == 1) goto cleanup;
        }
    }
*/
    sprintf(outline,"Dependent variable = %s",MainForm->Grid->Cells[DepVarNo][0].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Predictor VarList:");
    for (int i = 0; i < NoPredVars; i++)
    {
        sprintf(outline,"Variable %d = %s",i+1,MainForm->Grid->Cells[PredVars[i]][0].c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Control Variables:");
    for (int i = 0; i < NoCntrlVars; i++)
    {
        sprintf(outline,"Variable %d = %s",i+1,MainForm->Grid->Cells[CntrlVars[i]][0].c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    if (NoPredVars > 1)
    {
        sprintf(outline,"Higher order partialling at level = %d",NoPredVars);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (NoCntrlVars > 1)
    {
        sprintf(outline,"Multiple partialling with %d Variables.",NoCntrlVars);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
    }

    // Now, build the correlation matrix
    MatVars[0] = DepVarNo;
    for (int i = 0; i < NoPredVars; i++) MatVars[i+1] = PredVars[i];
    for (int i = 0; i < NoCntrlVars; i++) MatVars[i+1+NoPredVars] = CntrlVars[i];

//    if (FileType != 3) // don't do this if a matrix was read
//    {
        IER = Correlations(Means, StdDevs, rmatrix, TotNoVars, MatVars,
                count, 3, false, 1);
        if (IER == 1)
        {
            Application->MessageBox("Zero variance found.","ERROR!",MB_OK);
            return;
        }
//    }
/*
    else // matrix input
    {
        for (int i = 0; i < TotNoVars; i++)
        {
            Means[i] = 0.0;
            StdDevs[i] = 1.0;
            int k = MatVars[i];
            for (int j = 0; j < TotNoVars; j++)
            {
                int l = MatVars[j];
                rmatrix[i][j] = atof(MainForm->Grid->Cells[k][l].c_str());
            }
        }
    }
*/
    // Now do Multiple regression models required
    // Full model first
    for (int i = 1; i < TotNoVars; i++)
        for (int j = 1; j < TotNoVars; j++)
            workmat[i][j] = rmatrix[i][j];
    matinv(workmat, TotNoVars-1, inverse, V, W);
    R2Full = 0.0;
    for (int i = 0; i < TotNoVars-1; i++) // rows
    {
        W[i] = 0.0;
        for (int j = 0; j < TotNoVars-1; j++) // columns
        {
                W[i] += (inverse[i+1][j+1] * rmatrix[0][j+1]);
        }
        R2Full = R2Full + W[i] * rmatrix[0][i+1];
    }
    sprintf(outline,"Squared Multiple Correlation with all Variables = %6.3f",R2Full);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Standardized Regression Coefficients:");
    for (int i = 0; i < TotNoVars-1; i++)
    {
        sprintf(outline,"%10s = %6.3f",MainForm->Grid->Cells[MatVars[i+1]][0].c_str(),W[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");

    // Now do model for Partial and Semi-partial
    for (int i = 0; i < NoCntrlVars; i++)
    {
        int K = i + 1 + NoPredVars;
        for (int j = 0; j < NoCntrlVars; j++)
        {
            int L = j + 1 + NoPredVars;
            workmat[i+1][j+1] = rmatrix[K][L];
        }
    }
    matinv(workmat, NoCntrlVars, inverse, V, W);
    R2Cntrl = 0.0;
    for (int i = 0; i < NoCntrlVars; i++) // rows
    {
        int L = i + 1 + NoPredVars;
        W[i] = 0.0;
        for (int j = 0; j < NoCntrlVars; j++) // columns
        {
                int K = j + 1 + NoPredVars;
                W[i] += (inverse[i+1][j+1] * rmatrix[0][K]);
        }
        R2Cntrl = R2Cntrl + W[i] * rmatrix[0][L];
    }
    sprintf(outline,"Squared Multiple Correlation with control Variables = %6.3f",R2Cntrl);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Standardized Regression Coefficients:");
    for (int i = 0; i < NoCntrlVars; i++)
    {
        sprintf(outline,"%10s = %6.3f",MainForm->Grid->Cells[MatVars[i+1+NoPredVars]][0].c_str(),W[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");

    SemiPart = R2Full - R2Cntrl;
    Partial = SemiPart / (1.0 - R2Cntrl);
    df1 = TotNoVars - 1 - NoCntrlVars;
    df2 = count - TotNoVars;
    F = (SemiPart / (1.0 - R2Full)) * (df2 / df1);
    Prob = ftest(df1,df2,F);

    // Report results
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Partial Correlation = %6.3f",sqrt(Partial));
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Semi-Partial Correlation = %6.3f",sqrt(SemiPart));
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"F = %8.3f with probability = %6.4f, D.F.1 = %3.0f and D.F.2 = %3.0f",F,Prob,df1,df2);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // clean up the heap
cleanup:
    delete[] Betas;
    delete[] W;
    for (int i = 0; i < TotNoVars; i++) delete[] V[i];
    delete[] V;
    delete[] StdDevs;
    delete[] Means;
    delete[] MatVars;
    delete[] CntrlVars;
    delete[] PredVars;
    for (int i = 0; i < TotNoVars+1; i++) delete[] workmat[i];
    delete[] workmat;
    for (int i = 0; i < TotNoVars+1; i++) delete[] inverse[i];
    delete[] inverse;
    for (int i = 0; i < TotNoVars; i++) delete[] rmatrix[i];
    delete[] rmatrix;
}
//---------------------------------------------------------------------------

