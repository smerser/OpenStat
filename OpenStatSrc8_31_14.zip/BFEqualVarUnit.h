//---------------------------------------------------------------------------

#ifndef BFEqualVarUnitH
#define BFEqualVarUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBFEqualVarTestForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *Varlist;
        TLabel *Label2;
        TBitBtn *GrpInBtn;
        TBitBtn *GrpOutBtn;
        TMemo *Memo1;
        TBitBtn *DepInBtn;
        TBitBtn *DepOutBtn;
        TEdit *GroupVarEdit;
        TEdit *DepVarEdit;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *CIEdit;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall GrpInBtnClick(TObject *Sender);
        void __fastcall GrpOutBtnClick(TObject *Sender);
        void __fastcall DepInBtnClick(TObject *Sender);
        void __fastcall DepOutBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TBFEqualVarTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBFEqualVarTestForm *BFEqualVarTestForm;
//---------------------------------------------------------------------------
#endif
