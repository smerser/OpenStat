//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "MemMgrUnit.h"
#include "SingleLinkUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSingleLinkForm *SingleLinkForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TSingleLinkForm::TSingleLinkForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSingleLinkForm::FormShow(TObject *Sender)
{
     AnsiString cellstring;
     
     ListBox1->Clear();
     VarSelEdit->Text = "";
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
     RepChkBox->Checked = false;
     StdChkBox->Checked = false;
     VarOutBtn->Enabled = false;
     DescChkBox->Checked = false;
     PlotChkBox->Checked = false;    
}
//---------------------------------------------------------------------------

void __fastcall TSingleLinkForm::BtnResetClick(TObject *Sender)
{
     FormShow(this);
}
//---------------------------------------------------------------------------

void __fastcall TSingleLinkForm::VarOutBtnClick(TObject *Sender)
{
     ListBox1->Items->Add(VarSelEdit->Text);
     VarSelEdit->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall TSingleLinkForm::VarInBtnClick(TObject *Sender)
{
     int index;

     index = ListBox1->ItemIndex;
     VarSelEdit->Text = ListBox1->Items->Strings[index];
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TSingleLinkForm::BtnOkClick(TObject *Sender)
{
     int *NoInGrp;       // no. of subjects in a grouping
     int NoGroups, ID, ID1, ID2;
     int ColSelected;
     int NoScores = NoCases;
     AnsiString varlabel;
     char outline[501];
     char astring[5];
     double *Scores;      // subject scores
     double **Distance;  // distance between objects
     int *SubjectIDs;    // subject ids - sorted with Distance
     double X1, X2;      // grid values of two subjects
     int **Groups;       // subjects in each group
     double *GrpErrors;
     double Smallest, Mean = 0.0, Variance = 0.0, StdDev;
     int **clusters;
     varlabel = VarSelEdit->Text;
     int *Lst;
     int result;

     //Get selected variable
     ColSelected = 0;
     for (int j = 0; j < NoVariables; j++)
         if (VarSelEdit->Text == MainForm->Grid->Cells[j+1][0]) ColSelected = j+1;
     if (ColSelected == 0)
     {
        ShowMessage("ERROR!  No variable selected to analyze.");
        return;
     }
     //result = VarTypeChk(ColSelected,0);
     //if (result == 1) return;

     // Allocate memory
     Distance = new double*[NoCases];
     for (int i = 0; i < NoCases; i++) Distance[i] = new double[NoCases];
     SubjectIDs = new int[NoCases];
     NoInGrp = new int[NoCases];
     Groups = new int *[NoCases];
     for (int i = 0; i < NoCases; i++) Groups[i] = new int[NoCases];
     Scores = new double[NoCases];
     GrpErrors = new double[NoCases];
     GetIntMatMem(clusters,NoCases+1,3);
     Lst = new int[NoCases+1];

     // initialize arrays
     for (int i = 0; i < NoCases; i++)
     {
         NoInGrp[i] = 1;
         SubjectIDs[i] = i+1;
         for (int j = 0; j < NoCases; j++)
         {
             Groups[i][j] = 0;
             Distance[i][j] = 0.0;
         }
         for (int j = 0; j < 3; j++) clusters[i][j] = 0;
     }
     NoGroups = 0;

     // Get data into the distance matrix
     for (int i = 0; i < NoCases; i++)
     {
         int col = ColSelected;
         Scores[i] = StrToFloat(MainForm->Grid->Cells[col][i+1]);
         Mean += Scores[i];
         Variance += (Scores[i] * Scores[i]);
     }
     Variance = Variance - ((Mean * Mean) / NoCases);
     Variance /= (NoCases - 1);
     StdDev = sqrt(Variance);
     Mean /= NoCases;

     // sort the scores and ids in distance and subjed ids
     for (int i = 0; i < NoCases-1; i++)
     {
         for (int j = i+1; j < NoCases; j++)
         {
             if (Scores[i] > Scores[j]) // swap
             {
                X1 = Scores[i];
                Scores[i] = Scores[j];
                Scores[j] = X1;
                ID = SubjectIDs[i];
                SubjectIDs[i] = SubjectIDs[j];
                SubjectIDs[j] = ID;
             }
         }
     }
     for (int i = 0; i < NoCases; i++) Lst[i+1] = SubjectIDs[i];

     // Show results
     FrmOutPut->RichOutPut->Lines->Add("Single Linkage Clustering by Bill Miller");
     sprintf(outline,"FILE: %s",MainForm->FileNameEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Variable = %s",varlabel.c_str());
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Number of cases = %d",NoCases);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Mean = %8.3f, Variance = %8.3f, Std.Dev. = %8.3f",Mean, Variance, StdDev);
     FrmOutPut->RichOutPut->Lines->Add(outline);

    // Standardize the distance scores if elected
    if (StdChkBox->Checked)
    {
        for (int i = 0; i < NoCases; i++) Scores[i] = (Scores[i] - Mean) / StdDev;
        if (RepChkBox->Checked) // replace original values in grid with z scores if elected
        {
            for (int i = 0; i < NoCases; i++)
            {
                int col = ColSelected;
                sprintf(outline,"%6.4f",Scores[i]);
                MainForm->Grid->Cells[col][i+1] = outline;
            }
        }
    }

     FrmOutPut->RichOutPut->Lines->Add("");
     if (DescChkBox->Checked)
     {
           bool done = false;
           int startat = 0;
           int endat = NoScores;
           if (endat > 20) endat = 20;
           do
           {
              strcpy(outline,"GROUP ID");
              for (int i = startat; i < endat; i++)
              {
                  sprintf(astring,"%4d",SubjectIDs[i]);
                  strcat(outline,astring);
              }
              FrmOutPut->RichOutPut->Lines->Add(outline);
              startat = endat;
              if (startat >= NoScores) done = true;
              endat = startat + 20;
              if (endat > NoScores) endat = NoScores;
           } while (!done);
     }

     // calculate Distances and smallest Distance
label1:
     Smallest = fabs(Scores[0] - Scores[1]); // initial values
     for (int i = 0; i < NoScores-1; i++)
     {
         for (int j = i+1; j < NoScores; j++)
         {
             Distance[i][j] = fabs(Scores[i] - Scores[j]);
             Distance[j][i] = Distance[i][j];
             if (Distance[i][j] <= Smallest)
             {
                Smallest = Distance[i][j];
                ID1 = i;
                ID2 = j;
             }
         }
     }
     if (NoGroups < NoCases-1)
     {
         if (DescChkBox->Checked)
         {
            sprintf(outline,"        (Group %d is combined with Group %d)",SubjectIDs[ID1],SubjectIDs[ID2]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
         }
     }

     // eliminate second score and replace first with average
     NoInGrp[ID1]++;
     NoInGrp[ID2]--;
     clusters[NoGroups+1][1] = SubjectIDs[ID1];
     clusters[NoGroups+1][2] = SubjectIDs[ID2];

     // record results for this grouping
label2:
     Groups[NoGroups][ID1] = 1;  // set flags for those objects grouped
     Groups[NoGroups][ID2] = 1;
     if (NoGroups < NoCases-1) // eliminate second score and replace first with average
     {
        double average = fabs(Scores[ID1] + Scores[ID2]) / 2.0;
        Scores[ID1] = average;
        for (int i = ID2; i < NoScores-1; i++)
        {
            Scores[i] = Scores[i+1];
            SubjectIDs[i] = SubjectIDs[i+1];
        }
        NoScores--;
        for (int i = 0; i < NoScores; i++) Groups[NoGroups][SubjectIDs[i]] = 1;
        if (DescChkBox->Checked)
        {
           bool done = false;
           int startat = 0;
           int endat = NoScores;
           if (endat > 20) endat = 20;
           do
           {
              strcpy(outline,"GROUP ID");
              for (int i = startat; i < endat; i++)
              {
                  sprintf(astring,"%4d",SubjectIDs[i]);
                  strcat(outline,astring);
              }
              FrmOutPut->RichOutPut->Lines->Add(outline);
              startat = endat;
              if (startat >= NoScores) done = true;
              endat = startat + 20;
              if (endat > NoScores) endat = NoScores;
           } while (!done);
        }

        // get errors
        GrpErrors[NoGroups] += Distance[ID1][ID2];
        NoGroups++;
        goto label1;
     }

     // show errors
     if (DescChkBox->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("GROUPING STEP    ERROR");
        for (int i = 0; i < NoGroups; i++)
        {
            sprintf(outline,"     %3d          %10.3f",i+1,GrpErrors[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
     }

     FrmOutPut->ShowModal();
    if (PlotChkBox->Checked)
    {
       double *XAxis, *YAxis;
       double MaxError = GrpErrors[NoGroups-1];
       XAxis = new double[NoCases];
       YAxis = new double[NoCases];
       for (int i = 0; i < NoGroups; i++)
       {
           XAxis[i] = NoGroups - i;
           YAxis[i] = GrpErrors[i];
       }
       scatplot(XAxis, YAxis, NoGroups, "Plot of Error vs No. of Groups",
             "No. of Groups", "Size of Error", 2.0, double(NoCases), 0.0, MaxError);
       delete[] YAxis;
       delete[] XAxis;
    }

    if (DendoChk->Checked)
    {
       FrmOutPut->RichOutPut->Clear();
       TreePlot(clusters,Lst,NoGroups+1);
       FrmOutPut->ShowModal();
    }

     //clean up the memory
    delete[] Lst;
    ClearIntMatMem(clusters,NoCases+1);
    delete[] GrpErrors;
    delete[] Scores;
    for (int i = 0; i < NoCases; i++) delete[] Groups[i];
    delete[] Groups;
    delete[] NoInGrp;
    delete[] SubjectIDs;
    for (int i = 0; i < NoCases; i++) delete[] Distance[i];
    delete[] Distance;
}
//---------------------------------------------------------------------------

void TSingleLinkForm::TreePlot(int **Clusters, int *Lst, int NoPoints)
{
     char outline[501];
     char valstr[21];
     AnsiString plotline;
     char star = '*';
     char blank = ' ';
     int *ColPos;
     int col1, col2, colpos1, colpos2;
     int noparts, startcol, endcol;
     AnsiString *Results;
     int linecount = 0;
     ColPos = new int[NoPoints+1];
     Results = new AnsiString[NoPoints*2+3];

     FrmOutPut->RichOutPut->Lines->Add("");

     // store initial column positions of vertical linkages
     for (int i = 1; i <= NoPoints; i++) ColPos[Lst[i]] = 4 + (i * 5);

     // create column heading indented 10 spaces
     strcpy(outline,"UNIT ");
     for (int i = 1; i <= NoPoints; i++)
     {
         sprintf(valstr,"%5d",Lst[i]);
         strcat(outline,valstr);
     }
     Results[linecount] = outline;
     linecount++;

     // create beginning of vertical linkages
     plotline = "STEP ";
     for (int i = 1; i <= NoPoints; i++) plotline += "    *";
     Results[linecount] = plotline;
     linecount++;

     // start dendoplot
     for (int i = 1; i <= NoPoints; i++)
     {
         strcpy(outline,"");
         sprintf(valstr,"%3d  ",i); // put node no. first
         strcat(outline,valstr);
         // clear remainder of outline
         for (int j = 5; j <= (5 + NoPoints * 5); j++) outline[j] = blank;
         outline[6 + NoPoints * 5] = '\0';
         col1 = Clusters[i][1];
         col2 = Clusters[i][2];
         // find column positions for each variable
         colpos1 = ColPos[col1];
         colpos2 = ColPos[col2];
         for (int k = colpos1; k <= colpos2; k++) outline[k] = star;
         // change column positions 1/2 way between the matched ones
         int newcol = colpos1 + ((colpos2 - colpos1) / 2);
         for (int k = 1; k <= NoPoints; k++)
         if ((ColPos[k] == colpos1) || (ColPos[k] == colpos2))ColPos[k] = newcol;
         for (int k = 1; k <= NoPoints; k++)
         {
             int L = ColPos[k];
             if ((L != colpos1) && (L != colpos2)) outline[L] = star;
         }
         Results[linecount] = outline;
         linecount++;

         // add a line of connectors to next grouping
         strcpy(outline,"     ");
         for (int j = 5; j <= (5 + NoPoints * 5); j++) outline[j] = blank;
         for (int j = 1; j <= NoPoints; j++)
         {
             colpos1 = ColPos[j];
             outline[colpos1] = star;
         }
         Results[linecount] = outline;
         linecount++;
     } // next node

     // output the Results in parts
     // determine number of pages needed for whole plot
     noparts = 0;
     int howlong = strlen(Results[1].c_str());
     noparts = ceil((float)howlong / 80.0);
     if (noparts <= 0) noparts = 1;

     if (noparts == 1) // simply print the list
     {
         for (int i = 0; i < linecount; i++)
         {
             FrmOutPut->RichOutPut->Lines->Add(Results[i]);
         }
     }
     else // break lines into strings of 15 units
     {
         startcol = 0;
         endcol = 80;
         for (int i = 1; i <= noparts; i++)
         {
             sprintf(outline,"PART %d OUTPUT",i);
             FrmOutPut->RichOutPut->Lines->Add(outline);
             char aline[82];
             for (int j = 0; j <= 80; j++) aline[j] = ' ';

             for (int j = 0; j < linecount; j++)
             {
                 int count = 0;
                 strcpy(outline,Results[j].c_str());
                 for (int k = startcol; k <= endcol; k++)
                 {
                     aline[count] = outline[k];
                     count++;
                 }
                 aline[count+1] = '\0';
                 FrmOutPut->RichOutPut->Lines->Add(aline);
             }
             FrmOutPut->RichOutPut->Lines->Add("");
             startcol = endcol + 1;
             endcol = endcol + 80;
             if (endcol > howlong) endcol = howlong;
         }
     }
     delete[] Results;
     delete[] ColPos;
}
//---------------------------------------------------------------------------

