//---------------------------------------------------------------------------

#ifndef PaymentUnitH
#define PaymentUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TPaymentFrm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TEdit *PresentEdit;
     TLabel *Label2;
     TEdit *PaymentEdit;
     TLabel *Label5;
     TEdit *FutureEdit;
     TLabel *Label4;
     TEdit *RateEdit;
     TRadioGroup *WhenGroup;
     TButton *ComputeBtn;
     TButton *ResetBtn;
     TLabel *Label3;
     TEdit *NPeriodsEdit;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TPaymentFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPaymentFrm *PaymentFrm;
//---------------------------------------------------------------------------
#endif
