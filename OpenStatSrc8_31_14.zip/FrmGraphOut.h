//---------------------------------------------------------------------------
#ifndef FrmGraphOutH
#define FrmGraphOutH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TGraphOut : public TForm
{
__published:	// IDE-managed Components
	TButton *BtnClose;
	TButton *BtnPrint;
    TScrollBar *XScBar;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label5;
    TLabel *Label8;
    TButton *NextBtn;
    TRichEdit *Redit;
    TEdit *XDegEdit;
    TLabel *Label11;
	void __fastcall BtnCloseClick(TObject *Sender);
	void __fastcall BtnPrintClick(TObject *Sender);
    void __fastcall XScBarChange(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    
    void __fastcall NextBtnClick(TObject *Sender);
private:	// User declarations

public:		// User declarations
	__fastcall TGraphOut(TComponent* Owner);
    bool factend;
    int oldx;
    int col1;
    int col2;
};
//---------------------------------------------------------------------------
extern TGraphOut *GraphOut;
//---------------------------------------------------------------------------
#endif
void factplot(double *X, double *Y, int NoCases, char *titlestr,
     char *x_axis, char *y_axis, double x_min, double x_max, double y_min,
     double y_max);
void rotate(void);     
