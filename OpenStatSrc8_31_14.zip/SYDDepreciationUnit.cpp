//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SYDDepreciationUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSYDDepreciationFrm *SYDDepreciationFrm;
//---------------------------------------------------------------------------
__fastcall TSYDDepreciationFrm::TSYDDepreciationFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TSYDDepreciationFrm::ResetBtnClick(TObject *Sender)
{
     CostEdit->Text = "";
     SalvageEdit->Text = "";
     LifeEdit->Text = "";
     DepreciationEdit->Text = "";
     PeriodEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSYDDepreciationFrm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TSYDDepreciationFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Cost, Depreciation, Salvage;
     int Life, Period;

     Cost = StrToFloat(CostEdit->Text);
     Salvage = StrToFloat(SalvageEdit->Text);
     Life = StrToInt(LifeEdit->Text);
     Period = StrToInt(PeriodEdit->Text);
     Depreciation = SYDDepreciation(Cost, Salvage, Life, Period);
     DepreciationEdit->Text = FloatToStr(Depreciation);
}
//---------------------------------------------------------------------------
