//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h";
#include "functions.h"
#include "MatrixUnit.h"
#include "OutPut.h";
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "MemMgrUnit.h"
#include "stdio.h"
#include "SSRegUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSSbyRegForm *SSbyRegForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;

//---------------------------------------------------------------------------
__fastcall TSSbyRegForm::TSSbyRegForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSSbyRegForm::ResetBtnClick(TObject *Sender)
{
     DepVarEdit->Text = "";
     VarList->Clear();
     TreatmentList->Clear();
     RepeatList->Clear();
     CovariateList->Clear();
     InteractList->Clear();
     AllInteractList->Clear();
     WithinList->Clear();
     DescriptChk->Checked = false;
     MRegChk->Checked = false;
     CodeTypeGrp->ItemIndex = 2;
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
     intdef = false;
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(Trim(MainForm->Grid->Cells[i][0]));
}
//---------------------------------------------------------------------------
void __fastcall TSSbyRegForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::DepInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     DepVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepInBtn->Visible = false;
     DepOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::TrtInBtnClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            TreatmentList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = VarList->ItemIndex;

     if (index < 0) return;
     TreatmentList->Items->Add(VarList->Items->Strings[index]);
     VarList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::TrtOutBtnClick(TObject *Sender)
{
     int index, i;

     index = TreatmentList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (TreatmentList->Selected[i])
         {
            VarList->Items->Add(TreatmentList->Items->Strings[i]);
            TreatmentList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = TreatmentList->ItemIndex;

     if (index < 0) return;
     VarList->Items->Add(TreatmentList->Items->Strings[index]);
     TreatmentList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::RepInBtnClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            RepeatList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = VarList->ItemIndex;

     if (index < 0) return;
     RepeatList->Items->Add(VarList->Items->Strings[index]);
     VarList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::RepOutBtnClick(TObject *Sender)
{
     int index, i;

     index = RepeatList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (RepeatList->Selected[i])
         {
            VarList->Items->Add(RepeatList->Items->Strings[i]);
            RepeatList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = RepeatList->ItemIndex;

     if (index < 0) return;
     VarList->Items->Add(RepeatList->Items->Strings[index]);
     RepeatList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::CovInBtnClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            CovariateList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = VarList->ItemIndex;

     if (index < 0) return;
     CovariateList->Items->Add(VarList->Items->Strings[index]);
     VarList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::CovOutBtnClick(TObject *Sender)
{
     int index, i;

     index = CovariateList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (CovariateList->Selected[i])
         {
            VarList->Items->Add(CovariateList->Items->Strings[i]);
            CovariateList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
/*
     int index = CovariateList->ItemIndex;

     if (index < 0) return;
     VarList->Items->Add(CovariateList->Items->Strings[index]);
     CovariateList->Items->Delete(index);
*/
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::ComputeBtnClick(TObject *Sender)
{
     int min, max, col, newcol;

     // get labels and column numbers of entered variables
     DepVar = DepVarEdit->Text;
     DepCol = 0;
     for (int i = 1; i <= NoVariables; i++)
         if (DepVar == Trim(MainForm->Grid->Cells[i][0])) DepCol = i;
     if (DepCol == 0)
     {
        ShowMessage("ERROR!  No dependent variable selected.");
        return;
     }
     NoTrtVars = 0;
     for (int i = 0; i < TreatmentList->Items->Count; i++)
     {
         for (int j = 1; j <= NoVariables; j++)
         {
             if (TreatmentList->Items->Strings[i] == Trim(MainForm->Grid->Cells[j][0]))
             {
                Treatments[NoTrtVars] = Trim(MainForm->Grid->Cells[j][0]);
                TrtVarCols[NoTrtVars] = j;
                NoTrtVars++;
             }
         }
     }

     NoRepVars = 0;
     for (int i = 0; i < RepeatList->Items->Count; i++)
     {
         for (int j = 1; j <= NoVariables; j++)
         {
             if (RepeatList->Items->Strings[i] == Trim(MainForm->Grid->Cells[j][0]))
             {
                RepeatedMeas[NoRepVars] = Trim(MainForm->Grid->Cells[j][0]);
                RepVarCols[NoRepVars] = j;
                NoRepVars++;
             }
         }
     }
     NoCovVars = 0;
     for (int i = 0; i < CovariateList->Items->Count; i++)
     {
         for (int j = 1; j <= NoVariables; j++)
         {
             if (CovariateList->Items->Strings[i] == Trim(MainForm->Grid->Cells[j][0]))
             {
                Covariates[NoCovVars] = Trim(MainForm->Grid->Cells[j][0]);
                CovVarCols[NoCovVars] = j;
                NoCovVars++;
             }
         }
     }

     NoWithVars = 0;
     for (int i = 0; i < WithinList->Items->Count; i++)
     {
         for (int j = 1; j <= NoVariables; j++)
         {
             if (WithinList->Items->Strings[i] == Trim(MainForm->Grid->Cells[j][0]))
             {
                Withins[NoWithVars] = Trim(MainForm->Grid->Cells[j][0]);
                WithinCols[NoWithVars] = j;
                NoWithVars++;
             }
         }
     }

     // get number of vectors required for each treatment
     for (int i = 0; i < NoTrtVars; i++)
     {
         min = 1000;
         max = -1000;
         col = TrtVarCols[i];
         for (int j = 1; j <= NoCases; j++)
         {
             int value = floor(StrToFloat(MainForm->Grid->Cells[col][j]));
             if (value < min) min = value;
             if (value > max) max = value;
         }
         NoTrtVectors[i] = max - min;
         MinTrtValue[i] = min;
         MaxTrtValue[i] = max;
     }

     // create new variables for the treatments
     for (int i = 0; i < NoTrtVars; i++)
     {
         int k = TrtVarCols[i];
         TrtVecColStart[i] = NoVariables + 1;
         for (int j = 0; j < NoTrtVectors[i]; j++)
         {
             newcol = NoVariables + 1;
             NewVar(newcol,false);
             AnsiString astring = Trim(MainForm->Grid->Cells[k][0]) + IntToStr(j+1);
             DictionaryForm->DGrid->Cells[1][newcol] = astring;
             MainForm->Grid->Cells[newcol][0] = astring;
         }
     }

     // Indicate the treatment variables that are between subject sources
     ncnt = 0;  // vector counter
     for (int i = 0; i < NoTrtVars; i++)
     {
         for (int j = 0; j < NoTrtVectors[i]; j++)
         {
             IsWithin[ncnt] = false;
             ncnt++;
         }
     }

     // get number of vectors required for each within variable
     for (int i = 0; i < NoWithVars; i++)
     {
         col = WithinCols[i];
         min = 1000;
         max = -1000;
         for (int j = 1; j <= NoCases; j++)
         {
             int value = floor(StrToFloat(MainForm->Grid->Cells[col][j]));
             if (value < min) min = value;
             if (value > max) max = value;
         }
         NoWithVectors[i] = max - min;
         MinWithValue[i] = min;
         MaxWithValue[i] = max;
     }

     //  create new variables for the within measures
     for (int i = 0; i < NoWithVars; i++)
     {
         int k = WithinCols[i];
         WithVecColStart[i] = NoVariables + 1;
         for (int j = 0; j < NoWithVectors[i]; j++)
         {
             newcol = NoVariables + 1;
             NewVar(newcol,false);
             AnsiString astring = Trim(MainForm->Grid->Cells[k][0]) + IntToStr(j+1);
             DictionaryForm->DGrid->Cells[1][newcol] = astring;
             MainForm->Grid->Cells[newcol][0] = astring;
         }
     }

     // Indicate the within subject vectors
     for (int i = 0; i < NoWithVars; i++)
     {
         for (int j = 0; j < NoWithVectors[i]; j++)
         {
             IsWithin[ncnt] = true;
             ncnt++;
         }
     }

     // get number of vectors required for each repeated measure variable
     for (int i = 0; i < NoRepVars; i++)
     {
         col = RepVarCols[i];
         min = 1000;
         max = -1000;
         for (int j = 1; j <= NoCases; j++)
         {
             int value = floor(StrToFloat(MainForm->Grid->Cells[col][j]));
             if (value < min) min = value;
             if (value > max) max = value;
         }
         NoRepVectors[i] = max - min;
         MinRepValue[i] = min;
         MaxRepValue[i] = max;
     }

     //  create new variables for the repeated measures
     for (int i = 0; i < NoRepVars; i++)
     {
         int k = RepVarCols[i];
         RepVecColStart[i] = NoVariables + 1;
         for (int j = 0; j < NoRepVectors[i]; j++)
         {
             newcol = NoVariables + 1;
             NewVar(newcol,false);
             AnsiString astring = Trim(MainForm->Grid->Cells[k][0]) + IntToStr(j+1);
             DictionaryForm->DGrid->Cells[1][newcol] = astring;
             MainForm->Grid->Cells[newcol][0] = astring;
         }
     }

     // generate treatment vectors
     GenTrtVectors(this);

     // generate within subject treatment variable vectors
     GenWithinVectors(this);

     // generate repeated measures vectors
     GenRepVectors(this);

     // generate interaction vectors
     GenInteractVectors(this);

     MainForm->NoVarsEdit->Text = MainForm->Grid->ColCount - 1;
     if (GenVecsChk->Checked) return;

     // Do regressions for each effect
     DoRegressions(this);
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::GenTrtVectors(TObject *Sender)
{
     int col, min, start, type, grpval;

     if (NoTrtVars < 1) return;
     type = CodeTypeGrp->ItemIndex;

     for (int i = 0; i < NoTrtVars; i++)
     {
         min = MinTrtValue[i];
         col = TrtVarCols[i];
         start = TrtVecColStart[i];
         for (int j = 0; j < NoTrtVectors[i]; j++)
         {
             for (int k = 1; k <= NoCases; k++)
             {
                 grpval = floor(StrToFloat(MainForm->Grid->Cells[col][k]));
                 switch (type)
                 {
                     case 0: // dummy coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         else MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 1: // effect coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval == NoTrtVectors[i]) MainForm->Grid->Cells[start+j][k] = -1;
                         if (grpval != j+min) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 2: // orthogonal coding
                     {
                         if (grpval <= j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval-1 == j+min) MainForm->Grid->Cells[start+j][k] = -(j+1);
                         if (grpval > j+min+1) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                 }  // end of type switch
             } // next case
         } // next treatment vector
     }  // next treatment variable
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::GenWithinVectors(TObject *Sender)
{
     int col, min, start, type, grpval;

     if (NoWithVars < 1) return;
     type = CodeTypeGrp->ItemIndex;

     for (int i = 0; i < NoWithVars; i++)
     {
         min = MinWithValue[i];
         col = WithinCols[i];
         start = WithVecColStart[i];
         for (int j = 0; j < NoWithVectors[i]; j++)
         {
             for (int k = 1; k <= NoCases; k++)
             {
                 grpval = floor(StrToFloat(MainForm->Grid->Cells[col][k]));
                 switch (type)
                 {
                     case 0: // dummy coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         else MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 1: // effect coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval == NoTrtVectors[i]) MainForm->Grid->Cells[start+j][k] = -1;
                         if (grpval != j+min) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 2: // orthogonal coding
                     {
                         if (grpval <= j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval-1 == j+min) MainForm->Grid->Cells[start+j][k] = -(j+1);
                         if (grpval > j+min+1) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                 }  // end of type switch
             } // next case
         } // next within vector
     }  // next within variable
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::GenRepVectors(TObject *Sender)
{
     int col, min, start, type, grpval;

     if (NoRepVars < 1) return;
     type = CodeTypeGrp->ItemIndex;

     for (int i = 0; i < NoRepVars; i++)
     {
         min = MinRepValue[i];
         col = RepVarCols[i];
         start = RepVecColStart[i];
         for (int j = 0; j < NoRepVectors[i]; j++)
         {
             for (int k = 1; k <= NoCases; k++)
             {
                 grpval = floor(StrToFloat(MainForm->Grid->Cells[col][k]));
                 switch (type)
                 {
                     case 0: // dummy coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         else MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 1: // effect coding
                     {
                         if (grpval == j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval == NoTrtVectors[i]) MainForm->Grid->Cells[start+j][k] = -1;
                         if (grpval != j+min) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                     case 2: // orthogonal coding
                     {
                         if (grpval <= j+min) MainForm->Grid->Cells[start+j][k] = 1;
                         if (grpval-1 == j+min) MainForm->Grid->Cells[start+j][k] = -(j+1);
                         if (grpval > j+min+1) MainForm->Grid->Cells[start+j][k] = 0;
                     }
                     break;
                 }  // end of type switch
             } // next case
         } // next treatment vector
     }  // next treatment variable
}
//---------------------------------------------------------------------------


void __fastcall TSSbyRegForm::StartInterBtnClick(TObject *Sender)
{
     intdef = true;
     InteractList->Clear();
}
//---------------------------------------------------------------------------


void __fastcall TSSbyRegForm::DepVarEditDblClick(TObject *Sender)
{
     if (! intdef) return;
     InteractList->Items->Add(Trim(DepVarEdit->Text));
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::TreatmentListDblClick(TObject *Sender)
{
     int index = TreatmentList->ItemIndex;

     if (! intdef) return;
     if (index < 0) return;
     InteractList->Items->Add(Trim(TreatmentList->Items->Strings[index]));
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::RepeatListDblClick(TObject *Sender)
{
     int index = RepeatList->ItemIndex;

     if (! intdef) return;
     if (index < 0) return;
     InteractList->Items->Add(Trim(RepeatList->Items->Strings[index]));
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::CovariateListDblClick(TObject *Sender)
{
     int index = CovariateList->ItemIndex;

     if (! intdef) return;
     if (index < 0) return;
     InteractList->Items->Add(Trim(CovariateList->Items->Strings[index]));
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::EndItnterActBtnClick(TObject *Sender)
{
     int index;
     int nolines;
     AnsiString linestr;

     if (! intdef) return;
     linestr = "";
     nolines = InteractList->Items->Count;
     if (nolines > 0)
     {
         for (int i = 0; i < nolines; i++)
         {
             linestr = linestr + InteractList->Items->Strings[i];
             if (i < nolines-1) linestr = linestr + "*";
         }
         AllInteractList->Items->Add(linestr);
     }
     intdef = false;
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::GenInteractVectors(TObject *Sender)
{
     int col, col1, col2, min, start, grpval, index;
     int newcol, subcnt, totalvecs, oldnovariables;
     AnsiString SubStr[20];
     int VecStartPos[20];
     int NoVecs[20];
     double value1, value2;
     AnsiString Label, cellstring;
     char achar;
     bool Repflag = false;
     bool withinflag;

     NoMainInts = 0;
     NoIntVars = AllInteractList->Items->Count;
     if (NoIntVars < 1) return;

     for (int i = 0; i < NoIntVars; i++)
     {
         withinflag = false;
         // parse each interaction string into variable substrings
         subcnt = 0;
         Interaction[i] = AllInteractList->Items->Strings[i];
         strparse(i,SubStr,subcnt,this);
         for (int j = 0; j < subcnt; j++)
         {
             // check for a treatment variable
             for (int k = 0; k < NoTrtVars; k++)
             {
                 if (Trim(Treatments[k]) == SubStr[j])
                 {
                    VecStartPos[j] = TrtVecColStart[k];
                    NoVecs[j] = NoTrtVectors[k];
                 }
             }
             // check for a within variable
             for (int k = 0; k < NoWithVars; k++)
             {
                 if (Trim(Withins[k]) == SubStr[j])
                 {
                    VecStartPos[j] = WithVecColStart[k];
                    NoVecs[j] = NoWithVectors[k];
                    withinflag = true;
                 }
             }

             // check for a covariate
             for (int k = 0; k < NoCovVars; k++)
             {
                 if (Trim(Covariates[k]) == SubStr[j])
                 {
                    VecStartPos[j] = CovVarCols[k];
                    NoVecs[j] = 1;
                 }
             }
             // check for a repeated measure
             for (int k = 0; k < NoRepVars; k++)
             {
                 if (Trim(RepeatedMeas[k]) == SubStr[j])
                 {
                    VecStartPos[j] = RepVecColStart[k];
                    NoVecs[j] = NoRepVectors[k];
                    Repflag = true;
                 }
             }
         } // next substring

         // get total no. of new variables to create
         totalvecs = 1;
         for (int j = 0; j < subcnt; j++) totalvecs = totalvecs * NoVecs[j];
         NoIntVectors[i] = totalvecs;
         IntVecColStart[i] = NoVariables + 1;

         // create new variables
         oldnovariables = NoVariables + 1; // save beginning position
         for (int j = 0; j < totalvecs; j++)
         {
             newcol = NoVariables + 1;
             NewVar(newcol,false);
         }

         // fill new vectors with 1.0's and clear variable labels
         for (int j = 0; j < totalvecs; j++)
         {
             MainForm->Grid->Cells[oldnovariables+j][0] = ""; // clear labels
             for (int k = 1; k <= NoCases; k++) // fill subject vectors with 1's
                 MainForm->Grid->Cells[oldnovariables+j][k] = FloatToStr(1.0);
         }

         // generate interaction vectors and labels for this interaction
         col = oldnovariables;
         int Start = col;
         int Last = subcnt-1;
         int replications = totalvecs;
         while (Last >= 0)
         {
             replications = replications / NoVecs[Last];
             col2 = VecStartPos[Last];
             int L = 1;
             while (col < Start + totalvecs)
             {
                 for (int j = 0; j < replications; j++)
                 {
                     Label = "";
                     cellstring = MainForm->Grid->Cells[col2][0];
                     achar = cellstring[1];
                     Label = Label + achar;
                     Label = Label + IntToStr(L);
                     MainForm->Grid->Cells[col][0] = MainForm->Grid->Cells[col][0] + Label;
                     for (int N = 1; N <= NoCases; N++)
                     {
                         value1 = StrToFloat(MainForm->Grid->Cells[col][N]);
                         value2 = StrToFloat(MainForm->Grid->Cells[col2][N]);
                         MainForm->Grid->Cells[col][N] = FloatToStr(value1 * value2);
                     }
                     col++;
                 }
                 col2++;
                 if (col2 >= VecStartPos[Last]+NoVecs[Last]) col2 = VecStartPos[Last];
                 L++;
                 if (L > NoVecs[Last]) L = 1;
             } // while col < totalvecs
             col = oldnovariables;
             Last--;
         } // end while last >= 0
         if (!Repflag) NoMainInts++;
         Repflag = false;
         if (withinflag) WithinInteract[i] = true;
         else WithinInteract[i] = false;
     } // next interaction
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::strparse(int i, AnsiString astring[], int &cnt, TObject *Sender)
{
     // procedure to break down a string of substrings separated by the character *
     // and return the substrings in astring and the no. of substrings in cnt.
     // the value i is the index for AllInteractList->Items->Strings[i]

     int position; // position of the separator character '*'
     AnsiString asterisk = "*";
     AnsiString cellstring;
     AnsiString parsestring = AllInteractList->Items->Strings[i];
     TReplaceFlags Flags;
     cnt = 0;
     while (StrLen(parsestring.c_str()) > 0)
     {
           int j = Sysutils::AnsiPos(asterisk,parsestring);
           if (j > 0)
           {
              cellstring = parsestring.SubString(1,j-1); // get substring
              astring[cnt] = Trim(cellstring);
              cnt++;
              parsestring = parsestring.SubString(j+1,StrLen(parsestring.c_str()));
           }
           else  // must be last substring
           {
              cellstring = parsestring;
              astring[cnt] = cellstring;
              cnt++;
              parsestring = "";
           }
     }
}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::DoRegressions(TObject *Sender)
{
     int NoIndep, col, novectors = 0, counter;
     int *IndepCols;
     AnsiString *RowLabels;
     double *Means;
     double *Variances;
     double *StdDevs;
     double *BWeights;
     double *BetaWeights;
     double *BStdErrs;
     double *Bttests;
     double *tProbs;
     double R2, F, probf, stderrest, FullR2;
     int NCases;
     bool errorcode = false;
     bool PrintDesc = false;
     bool PrintCorrs = false;
     bool PrintInverse = false;
     bool PrintCoefs = false;
     bool SaveCorrs = false;
     double R2Covs, R2Reps, R2Trts, R2Ints;
     char outline[101];
     AnsiString cellstring;
     AnsiString dashes = "-----------------------------------------------------------";

     NCases = NoCases;
     if (DescriptChk->Checked) PrintDesc = true;
     if (MRegChk->Checked)
     {
        PrintCorrs = true;
        PrintCoefs = true;
     }

     // Get the SS Total for the dependent variable
     SST = 0.0;
     double Sum = 0.0;
     double value;
     for (int i = 1; i <= NoCases; i++)
     {
         value = StrToFloat(MainForm->Grid->Cells[DepCol][i]);
         SST += (value * value);
         Sum += value;
     }
     SST = SST - ((Sum * Sum) / double(NoCases));
     sprintf(outline,"Sum of Squares Total = %10.4f",SST);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");

     // Do a full model (all included variables except replications)
     if (NoCovVars > 0) novectors += NoCovVars;
     if (NoTrtVars > 0)
     {
        for (int i = 0; i < NoTrtVars; i++) novectors += NoTrtVectors[i];
     }
     if (NoIntVars > 0)
     {
        for (int i = 0; i < NoIntVars; i++) novectors += NoIntVectors[i];
     }
     if (NoWithVars > 0)
     {
        for (int i = 0; i < NoWithVars; i++) novectors += NoWithVectors[i];
     }
     if (NoRepVars > 0)
     {
        for (int i = 0; i < NoRepVars; i++) novectors += NoRepVectors[i];
     }
     GetIntVecMem(IndepCols,novectors+1);
     GetDblVecMem(Means,novectors+1);
     GetDblVecMem(Variances,novectors+1);
     GetDblVecMem(StdDevs,novectors+1);
     GetDblVecMem(BWeights,novectors+1);
     GetDblVecMem(BetaWeights,novectors+1);
     GetDblVecMem(BStdErrs,novectors+1);
     GetDblVecMem(Bttests,novectors+1);
     GetDblVecMem(tProbs,novectors+1);
     RowLabels = new AnsiString[novectors+1];

     counter = 0;
     if (NoCovVars > 0)
     {
        for (int i = 0; i < NoCovVars; i++)
        {
            col = CovVarCols[i];
            RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
            IndepCols[counter] = col;
            counter++;
        }
     }

     if (NoTrtVars > 0)
     {
        for (int i = 0; i < NoTrtVars; i++)
        {
            int colstart = TrtVecColStart[i];
            for (int j = 0; j < NoTrtVectors[i]; j++)
            {
                col = colstart + j;
                RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
                IndepCols[counter] = col;
                counter++;
            }
        }
     }

     if (NoWithVars > 0)
     {
        for (int i = 0; i < NoWithVars; i++)
        {
            int colstart = WithVecColStart[i];
            for (int j = 0; j < NoWithVectors[i]; j++)
            {
                col = colstart + j;
                RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
                IndepCols[counter] = col;
                counter++;
            }
        }
     }

     if (NoIntVars > 0)
     {
        for (int i = 0; i < NoIntVars; i++)
        {
            int colstart = IntVecColStart[i];
            for (int j = 0; j < NoIntVectors[i]; j++)
            {
                col = colstart + j;
                RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
                IndepCols[counter] = col;
                counter++;
            }
        }
     }

     int repcount = 0;
     if (NoRepVars > 0)
     {
        for (int i = 0; i < NoRepVars; i++)
        {
            int colstart = RepVecColStart[i];
            for (int j = 0; j < NoRepVectors[i]; j++)
            {
                col = colstart + j;
                RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
                IndepCols[counter] = col;
                counter++;
                repcount++;
            }
        }
     }

     NoIndep = counter-repcount;
         mreg(NoIndep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
     FullR2 = R2;
     SSReg = R2 * SST;
     SSE = (1.0 - R2) * SST;
     DFE = NCases - NoIndep - 1;
     MSE = SSE / DFE;
     if (MRegChk->Checked)
     {
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // now eliminate each variable from full model to get SS for that variable
     for (int i = 0; i < NoIndep; i++) tempcols[i] = IndepCols[i];
     templabels = new AnsiString[novectors];
     for (int i = 0; i < NoIndep; i++) templabels[i] = RowLabels[i];
     int vecpos = 0;
     for (int i = 0; i < NoIndep; i++)
     {
         counter = 0;
         for (int j = 0; j < NoIndep; j++)
         {
             if (vecpos != j)
             {
                IndepCols[counter] = tempcols[j];
                RowLabels[counter] = templabels[j];
                counter++;
             }
         }

         if (counter > 0)
         {
         mreg(counter,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
            SS[i] = (FullR2 - R2) * SST;
            vecpos++;
            if (MRegChk->Checked)
            {
               FrmOutPut->ShowModal();
               FrmOutPut->RichOutPut->Clear();
            }
         }
         else SS[i] = FullR2 * SST;
     }

     // summarize the sums of squares
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("SUMS OF SQUARES AND MEAN SQUARES BY REGRESSION");
     FrmOutPut->RichOutPut->Lines->Add("TYPE III SS - R2 = Full Model - Restricted Model");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("VARIABLE       SUM OF SQUARES  D.F.");
     FrmOutPut->RichOutPut->Lines->Add("");
     for (int i = 0; i < NoIndep; i++)
     {
         cellstring = templabels[i];
//         F = SS[i] / MSE;
//         probf = ftest(1.0,DFE,F);
         sprintf(outline,"%15s %10.3f     %4d", cellstring.c_str(),SS[i], 1);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     cellstring = "ERROR          ";
     sprintf(outline,"%15s %10.3f     %4d",
                 cellstring.c_str(),SSE, DFE);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     cellstring = "TOTAL          ";
     sprintf(outline,"%15s %10.3f     %4d",
                 cellstring.c_str(),SST, NCases-1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();
//     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("");

     // summarize for original effects
     FrmOutPut->RichOutPut->Lines->Add("TOTAL EFFECTS SUMMARY");
     FrmOutPut->RichOutPut->Lines->Add(dashes);
     FrmOutPut->RichOutPut->Lines->Add("SOURCE                 SS  D.F.      MS");
     FrmOutPut->RichOutPut->Lines->Add(dashes);

     // covariates
     if (NoCovVars > 0)
     {
         for (int i = 0; i < NoCovVars; i++)
         {
             double CovSS = SS[i];
             SSCov[i] = CovSS;
             MSCov[i] = SSCov[i];
//             int CovDF = 1;
//             double CovMS = CovSS / CovDF;
//             F = CovMS / MSE;
//             probf = ftest(CovDF,DFE,F);
             cellstring = Covariates[i];
             sprintf(outline,"%15s%10.3f%4d%10.3f",
                      cellstring,SSCov[i],1,MSCov[i]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
     }

     // Do full model without each treatment variable
     double cumtrtss = 0.0;
     int cumtrtdf = 0;
     if (NoTrtVars > 0)
     {
         for (int i = 0; i < NoTrtVars; i++)
         {
             int startcol =  TrtVecColStart[i];
             int novecs = NoTrtVectors[i];
             int endcol = startcol + novecs-1;
             counter = 0;
             for (int k = 0; k < NoIndep; k++)
             {
                 if ((tempcols[k] < startcol) || (tempcols[k] > endcol))
                 {
                     RowLabels[counter] = templabels[k];
                     IndepCols[counter] = tempcols[k];
                     counter++;
                 }
             }

             if (counter > 0)
             {
                mreg(counter,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
                BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
                PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
             }
             else R2 = 0.0;
             double TrtSS = (FullR2 - R2) * SST;
             SSTrt[i] = TrtSS;
             cumtrtss += TrtSS;
             int TrtDF = novecs;
             DFTrt[i] = TrtDF;
             cumtrtdf += TrtDF;
             double TrtMS = TrtSS / TrtDF;
             MSTrt[i] = TrtMS;
//             F = TrtMS / MSE;
//             probf = ftest(TrtDF,DFE,F);
             cellstring = Treatments[i];
             sprintf(outline,"%15s%10.3f%4d%10.3f",
                      cellstring,TrtSS,TrtDF,TrtMS);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         } // next treatment
     }

     // Do full model without each within variable
     cumtrtss = 0.0;
     cumtrtdf = 0;

     if (NoWithVars > 0)
     {
         for (int i = 0; i < NoWithVars; i++)
         {
             int startcol =  WithVecColStart[i];
             int novecs = NoWithVectors[i];
             int endcol = startcol + novecs-1;
             counter = 0;
             for (int k = 0; k < NoIndep; k++)
             {
                 if ((tempcols[k] < startcol) || (tempcols[k] > endcol))
                 {
                     RowLabels[counter] = templabels[k];
                     IndepCols[counter] = tempcols[k];
                     counter++;
                 }
             }

             if (counter > 0)
             {
                mreg(counter,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
                BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
                PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
             }
             else R2 = 0.0;
             double TrtSS = (FullR2 - R2) * SST;
             SSWith[i] = TrtSS;
             int TrtDF = novecs;
             DFWith[i] = TrtDF;
             cumtrtss += TrtSS;
             cumtrtdf += TrtDF;
             double TrtMS = TrtSS / TrtDF;
             MSWith[i] = TrtMS;
//             F = TrtMS / MSE;
//             probf = ftest(TrtDF,DFE,F);
             cellstring = Withins[i];
             sprintf(outline,"%15s%10.3f%4d%10.3f",
                      cellstring,TrtSS,TrtDF,TrtMS);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         } // next treatment
     }

     // Do the same for interactions
     if (NoIntVars > 0)
     {
         for (int i = 0; i < NoIntVars; i++)
         {
             int startcol =  IntVecColStart[i];
             int novecs = NoIntVectors[i];
             int endcol = startcol + novecs-1;
             counter = 0;
             for (int k = 0; k < NoIndep; k++)
             {

                 if ((tempcols[k] < startcol) || (tempcols[k] > endcol))
                 {
                     RowLabels[counter] = templabels[k];
                     IndepCols[counter] = tempcols[k];
                     counter++;
                 }
             } // next novector

             mreg(counter,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
             double TrtSS = (FullR2 - R2) * SST;
             SSInt[i] = TrtSS;
             cumtrtss += TrtSS;
             int TrtDF = novecs;
             DFInt[i] = TrtDF;
             cumtrtdf += TrtDF;
             double TrtMS = TrtSS / TrtDF;
             MSInt[i] = TrtMS;
             cellstring = Interaction[i];
             sprintf(outline,"%15s%10.3f%4d%10.3f",
                      cellstring,TrtSS,TrtDF,TrtMS);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         } // next interaction
     }

     FrmOutPut->RichOutPut->Lines->Add(dashes);
     // Do the same for person vectors
     double TrtSS;
     int TrtDF;
     if (NoRepVars > 0)
     {
         for (int i = 0; i < NoRepVars; i++)
         {
             counter = 0;
             int colstart = RepVecColStart[i];
             for (int j = 0; j < NoRepVectors[i]; j++)
             {
                col = colstart + j;
                RowLabels[counter] = Trim(MainForm->Grid->Cells[col][0]);
                IndepCols[counter] = col;
                counter++;
             }
             NoIndep = counter;
             if (NoIndep > 0)
             {
                mreg(NoIndep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
                BetaWeights,BStdErrs,Bttests,tProbs,R2,F,stderrest,NCases,errorcode,
                PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
                TrtSS = R2 * SST;
             }
             else TrtSS = FullR2 * SST;
             SSReps = TrtSS;
             DFReps = counter;
             TrtDF = counter;
             double TrtMS = TrtSS / TrtDF;
             MSReps = TrtMS;
         }
     }

     // summarize between and within sources
     // add up the between subjects SS's (treatments, covariates, some interactions)
     double BetweenSS = 0.0;
     double ErrBetween = 0.0;
     int DFBetween = 0;
     for (int i = 0; i < NoTrtVars; i++)
     {
         BetweenSS += SSTrt[i];
         DFBetween += NoTrtVectors[i];
     }
     for (int i = 0; i < NoIntVars; i++)
     {
         if (!WithinInteract[i])
         {
            BetweenSS += SSInt[i];
            DFBetween += NoIntVectors[i];
         }
     }
     for (int i = 0; i < NoCovVars; i++)
     {
         BetweenSS += SSCov[i];
         DFBetween += 1;
     }
     if (NoRepVars > 0) ErrBetween = SSReps - BetweenSS;
     else ErrBetween = SSE;

     // add up the within subjects SS's (replications, some interactions)
     double WithinSS = 0.0;
     double ErrWithin;
     double CumWithin = 0;
     int CumDFWithin = 0;
     for (int i = 0; i < NoWithVars; i++) WithinSS += SSWith[i];
     for (int i = 0; i < NoIntVars; i++) if (WithinInteract[i]) WithinSS += SSInt[i];
     CumWithin =  WithinSS;

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add(dashes);
     sprintf(outline,"SOURCE                     SS  D.F.       MS");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add(dashes);
     if (NoTrtVars > 0)
     {
//         sprintf(outline,"BETWEEN SUBJECTS   %10.3f %4d",BetweenSS,NoIndep);
     if (NoRepVars > 0) sprintf(outline,"BETWEEN SUBJECTS   %10.3f %4d",SSReps,DFReps);
     else sprintf(outline,"BETWEEN SUBJECTS   %10.3f %4d",BetweenSS,novectors);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     if (NoCovVars > 0)
     {
        SSCovs = 0.0;
        for (int i = 0; i < NoCovVars; i++) SSCovs += SSCov[i];
//        ErrBetween -= SSCovs;
        DFCovs = NoCovVars;
        MSCovs = SSCovs / DFCovs;
        cellstring = "Covariates";
        sprintf(outline,"     %14s%10.3f %4d %10.3f",cellstring,SSCovs,NoCovVars,MSCovs);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     if (NoTrtVars > 0)
     {
        for (int i = 0; i < NoTrtVars; i++)
        {
            cellstring = Treatments[i];
            sprintf(outline,"     %14s%10.3f %4d %10.3f",cellstring,SSTrt[i],DFTrt[i],MSTrt[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        for (int i = 0; i < NoIntVars; i++)
        {
            if (! WithinInteract[i])
            {
               cellstring = Interaction[i];
               sprintf(outline,"     %14s%10.3f %4d %10.3f",cellstring,SSInt[i],DFInt[i],MSInt[i]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
            }
        }
        if (NoRepVars > 0) MSBetween = ErrBetween / (DFReps - DFBetween);
        else MSBetween = MSE;
        int dfbetween;
        if (NoRepVars > 0) dfbetween = DFReps-DFBetween;
        else dfbetween = NoCases - 1 - novectors;
        sprintf(outline,"ERROR BETWEEN      %10.3f %4d %10.3f",ErrBetween, dfbetween,MSBetween);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
     }
     FrmOutPut->RichOutPut->Lines->Add(dashes);

     if (NoWithVars > 0)
     {
        WithinSS = SST - SSReps;
        ErrWithin = WithinSS - CumWithin;
        DFWiths = NCases - 1 - DFReps;
        sprintf(outline,"WITHIN SUBJECTS    %10.3f %4d",WithinSS,DFWiths);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 0; i < NoWithVars; i++)
        {
            cellstring = Withins[i];
            sprintf(outline,"     %14s%10.3f %4d %10.3f",cellstring,SSWith[i],DFWith[i],MSWith[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            CumDFWithin += DFWith[i];
        }
        for (int i = 0; i < NoIntVars; i++)
        {
            if (WithinInteract[i])
            {
               cellstring = Interaction[i];
               sprintf(outline,"     %14s%10.3f %4d %10.3f",cellstring,SSInt[i],DFInt[i],MSInt[i]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               CumDFWithin += DFInt[i];
            }
        }
        MSWiths = ErrWithin / (DFWiths - CumDFWithin);
        sprintf(outline,"ERROR WITHIN       %10.3f %4d %10.3f",ErrWithin,DFWiths-CumDFWithin,MSWiths);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add(dashes);
     sprintf(outline,"TOTAL              %10.3f %4d",SST,NCases-1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add(dashes);
     FrmOutPut->ShowModal();

     delete[] templabels;
     delete[] RowLabels;
     delete[] tProbs;
     delete[] Bttests;
     delete[] BStdErrs;
     delete[] BetaWeights;
     delete[] BWeights;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
     delete[] IndepCols;
}
//---------------------------------------------------------------------------


void __fastcall TSSbyRegForm::WithInBtnClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            WithinList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }

}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::WithOutBtnClick(TObject *Sender)
{
     int index, i;

     index = WithinList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (WithinList->Selected[i])
         {
            VarList->Items->Add(WithinList->Items->Strings[i]);
            WithinList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }

}
//---------------------------------------------------------------------------

void __fastcall TSSbyRegForm::WithinListClick(TObject *Sender)
{
     int index = WithinList->ItemIndex;

     if (! intdef) return;
     if (index < 0) return;
     InteractList->Items->Add(Trim(WithinList->Items->Strings[index]));
}
//---------------------------------------------------------------------------

