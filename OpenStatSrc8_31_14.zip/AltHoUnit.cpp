//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "AltHoUnit.h"
#include "MainUnit.h"

extern struct Options ops;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAltHoFrm *AltHoFrm;
//---------------------------------------------------------------------------
__fastcall TAltHoFrm::TAltHoFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::NullMeanEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) AltMeanEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::AltMeanEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) StdDevEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::StdDevEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) TypeIEdit->SetFocus();    
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::TypeIEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) TypeIIEdit->SetFocus();    
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::TypeIIEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) ContBtn->SetFocus();    
}
//---------------------------------------------------------------------------


void __fastcall TAltHoFrm::ResetBtnClick(TObject *Sender)
{
     NullMeanEdit->Text = "";
     AltMeanEdit->Text = "";
     StdDevEdit->Text = "";
     if (ops.format == 0)
     {
        TypeIEdit->Text = "0.05";
        TypeIIEdit->Text = "0.20";
     }
     else
     {
        TypeIEdit->Text = "0,05";
        TypeIIEdit->Text = "0,20";
     }
}
//---------------------------------------------------------------------------

void __fastcall TAltHoFrm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

