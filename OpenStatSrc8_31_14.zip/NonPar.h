//---------------------------------------------------------------------------
#ifndef NonParH
#define NonParH
//---------------------------------------------------------------------------
#endif
void printtable(double **obs, double **theor, double *rowtot,
     double *coltot, double grandtot, int *levels, double *minvalue,
     double *maxvalue, int row, int col);
double ProdSums(double N, double A);
double combos(double X, double N);
void binomial(void);
void Concord(void);
void kwanova(void);
void MWUtest(void);
void qtest(void);
void signtest(void);
void Spearman(void);
void Wilcoxon(void);

