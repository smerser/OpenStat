//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "math.h"
#include "functions.h"
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "LogLinScreenUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLogLinScreenForm *LogLinScreenForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TLogLinScreenForm::TLogLinScreenForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
//     Panel1->Visible = false;
//     VarNoEdit->Text = "";
//     MaxEdit->Text = "";
//     MinEdit->Text = "";
//     NoDims = NoVariables;
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::InBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     SelList->Items->Add(VarList->Items->Strings[index]);
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::OutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     if (index >= 0)
     {
        VarList->Items->Add(SelList->Items->Strings[index]);
        SelList->Items->Delete(index);
     }
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::AllBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     if (index < 0) return;
     i = 0;
     while (i < index)
     {
           SelList->Items->Add(VarList->Items->Strings[i]);
           VarList->Items->Delete(i);
           index--;
     }
}
//---------------------------------------------------------------------------
void __fastcall TLogLinScreenForm::ComputeBtnClick(TObject *Sender)
{
   int ArraySize, N, index, index2, i, j, k, l, NoVars, count, value;
   double *Data;
   int *Subscripts;
   int *DimSize;
   int *GridPos;
   AnsiString *Labels;
   int **Margins;
   double *Expected;
   int *WorkVec;
   int **Indexes;
   double *LogM;
   int *NSize;
   double **M;
   AnsiString astr, HeadStr;
   int MaxDim, MP, MM;
   double U, Mu, Chi2, G2;
   int DF;
   double ProbChi2, ProbG2;
   double *GSQ;
   int *DGFR;
   double **PART;
   double **MARG;
   int **DFS;
   int **IP;
   int **IM;
   int *ISET;
   int *JSET;
   int **CONFIG;
   double *FIT;
   int *SIZE;
   int *COORD;
   double *X, *Y;
   int IFAULT;
   double *TABLE;
   int *DIM;
   int HiOrder;
   AnsiString response;
   char outline[81];
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;

     FrmOutPut->RichOutPut->Clear();

     // Allocate space for labels, DimSize and SubScripts
     NoVars = SelList->Items->Count;
     if (NoVars <= 0)
     {
        ShowMessage("ERROR!  No variables selected.");
        return;
     }
     NoDims = NoVars-1;
     Maximums = new int[NoDims];
     Minimums = new int[NoDims];
     Response = new bool[NoDims];
     Interact = new bool[NoDims];
     
     Labels = new AnsiString[NoVars];
     DimSize = new int[NoDims];
     Subscripts = new int[NoDims];
     GridPos = new int[NoVars];

     // get variable labels and column positions
     for (i = 1; i <= NoVars; i++)
     {
          astr = SelList->Items->Strings[i-1];
          for (j = 1; j <= NoVariables; j++)
          {
               if (MainForm->Grid->Cells[j][0] == astr)
               {
                    Labels[i-1] = astr;
                    GridPos[i-1] = j;
/*                    result = VarTypeChk(j,1);
                    if (result == 1)
                    {
                        delete[] GridPos;
                        delete[] Subscripts;
                        delete[] DimSize;
                        delete[] Labels;
                        delete[] Interact;
                        delete[] Response;
                        delete[] Minimums;
                        delete[] Maximums;
                        return;
                    }
                    break;
*/
               }
          }
     }

     // get minimum and maximums for each dimension
     for (i = 0; i < NoDims; i++)
     {
         k = GridPos[i];
         Minimums[i] = 1000;
         Maximums[i] = -1000;
         for (j = 1; j <= NoCases; j++)
         {
             if (!ValidRecord(j, GridPos, NoVars)) continue;
             value = floor(StrToFloat(Trim(MainForm->Grid->Cells[k][j])));
             //result = GetValue(j,k,intvalue,dblvalue,strvalue);
             //if (result == 1) value = 0;
             //else value = intvalue;
             if (value < Minimums[i]) Minimums[i] = value;
             if (value > Maximums[i]) Maximums[i] = value;
         }
     }
     
     // Get no. of categories for each dimension (DimSize)
     MaxDim = 0;
     ArraySize = 1;
     for (i = 0; i < NoDims; i++)
     {
          DimSize[i] = Maximums[i] - Minimums[i] + 1;
          if (DimSize[i] > MaxDim)  MaxDim = DimSize[i];
          ArraySize = ArraySize * DimSize[i];
     }

     // Allocate space for Data and marginals
     WorkVec = new int[MaxDim];
     Data = new double[ArraySize];
     GetIntMatMem(Margins,NoDims,MaxDim);
     Expected = new double[ArraySize];
     GetIntMatMem(Indexes,ArraySize+1,NoDims);
     LogM = new double[ArraySize];
     GetDblMatMem(M,ArraySize,NoDims);
     NSize = new int[NoDims];

     // Initialize data and margins arrays
     for (i = 1; i <= NoDims; i++)
         for (j = 1; j <= MaxDim; j++)
             Margins[i-1][j-1] = 0;
     for (i = 1; i <= ArraySize; i++) Data[i-1] = 0;
     N = 0;

     // Read and store frequencies in Data
     for (i = 1; i <= NoCases; i++)
     {
          if (ValidRecord(i,GridPos, NoVars))  // casewise check
          {
               for (j = 1; j <= NoDims; j++) // get cell subscripts
               {
                    index = floor(StrToFloat(Trim(MainForm->Grid->Cells[GridPos[j-1]][i])));
                    //result = GetValue(i,GridPos[j-1],intvalue,dblvalue,strvalue);
                    //if (result == 1) index = 0;
                    //else index = intvalue;
                    index = index - Minimums[j-1] + 1;
                    Subscripts[j-1] = index;
               }

               index = ArrayPosition(NoDims, Data, Subscripts, DimSize);

               for (j = 1; j <= NoDims; j++) // save subscripts for later use
                   Indexes[index][j-1] = Subscripts[j-1];

               k = GridPos[NoVars-1];
               Data[index] = Data[index] + floor(StrToFloat(Trim(MainForm->Grid->Cells[k][i])));
               //result = GetValue(i,k,intvalue,dblvalue,strvalue);
               //if (result == 1) Data[index] = Data[index] + 0;
               //else Data[index] = Data[index] + intvalue;
          }
     }

     // get total N
     for (i = 1; i <= ArraySize; i++) N = N + ceil(Data[i-1]);

     // Get marginal frequencies
      Marginals(NoDims,ArraySize,Indexes,Data,Margins);

     // Print Marginal totals if requested
     if (MargTotalsChk->Checked)
     {
          FrmOutPut->RichOutPut->Clear();
          FrmOutPut->RichOutPut->Lines->Add("FILE: " + MainForm->FileNameEdit->Text);
          FrmOutPut->RichOutPut->Lines->Add("");
          for (i = 1; i <= NoDims; i++)
          {
               HeadStr = "Marginal Totals for " + Labels[i-1];
               strcpy(outline,HeadStr.c_str());
               FrmOutPut->RichOutPut->Lines->Add(outline);
               k = DimSize[i-1];
               for (j = 0; j < k; j++) WorkVec[j] = Margins[i-1][j];
               FrmOutPut->RichOutPut->Lines->Add("Level Frequency");
               for (j = 0; j < k; j++)
               {
                   sprintf(outline,"%3d      %5d ",j + 1, WorkVec[j]);
                   FrmOutPut->RichOutPut->Lines->Add(outline);
               }
               FrmOutPut->RichOutPut->Lines->Add("");
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Total Frequencies = " + IntToStr(N);
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->ShowModal();

     // Get Expected cell values
     U = 0.0; // overall mean (mu) of log linear model
     for (i = 1; i <= ArraySize; i++) // indexes point to each cell
     {
          Expected[i-1] = 1.0;
          for (j = 1; j <= NoDims; j++)
          {
               k = Indexes[i-1][j-1];
               Expected[i-1] = Expected[i-1] * ((double)Margins[j-1][k-1] / (double)N);
          }
          Expected[i-1] = Expected[i-1] * (double)N;
          LogM[i-1] = log(Expected[i-1]);
     }
     for (i = 1; i <= ArraySize; i++) U = U + LogM[i-1];
     U = U / ArraySize;

     // print expected values
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("FILE: "+ MainForm->FileNameEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("EXPECTED CELL VALUES FOR MODEL OF COMPLETE INDEPENDENCE");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Cell          Observed  Expected  Log Expected");
     for (i = 1; i <= ArraySize; i++)
     {
          astr = "";
          for (j = 1; j <= NoDims; j++)
          {
              sprintf(outline,"%3d ",Indexes[i-1][j-1]);
              astr = astr + outline;
          }
          sprintf(outline,"%10.0f %10.2f %10.3f",Data[i-1],Expected[i-1],LogM[i-1]);
          astr = astr + outline;
          FrmOutPut->RichOutPut->Lines->Add(astr);
     }
     Chi2 = 0.0;
     G2 = 0.0;

     // Calculate chi-squared and G squared statistics
     for (i = 1; i <= ArraySize; i++)
     {
          Chi2 = Chi2 + sqr(Data[i-1] - Expected[i-1]) / Expected[i-1];
          G2 = G2 + Data[i-1] * log(Data[i-1] / Expected[i-1]);
     }
     G2 = 2.0 * G2;
     DF = 1;
     for (i = 1; i <= NoDims; i++) DF = DF * (DimSize[i-1]-1);
     ProbChi2 = 1.0 - chisquaredprob(Chi2,DF);
     ProbG2 = 1.0 - chisquaredprob(G2,DF);
     sprintf(outline,"Chisquare = %10.3f with probability = %10.3f (DF = %d)",Chi2,ProbChi2,DF);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"G squared = %10.3f with probability = %10.3f (DF = %d)",G2,ProbG2,DF);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"U (mu) for general loglinear model = %10.2f",U);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->ShowModal();

     // Get log linear model values for each cell
     // get M"s for each cell
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("First Order LogLinear Model Factors and N of Cells in Each");
     astr = "CELL              ";
     for (i = 1; i <= NoDims; i++)
     {
         sprintf(outline," U%d  N Cells   ",i);
         astr = astr + outline;
     }
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 1; i <= ArraySize; i++) // cell
     {
          astr = "";
          for (j = 1; j <= NoDims; j++)
          {
              sprintf(outline,"%3d ",Indexes[i-1][j-1]);
              astr = astr + outline;
          }
          for (j = 1; j <= NoDims; j++) // jth mu
          {
               index = Indexes[i-1][j-1]; // sum for this mu
               count = 0;
               Mu = 0.0;
               for (k = 1; k <= ArraySize; k++)
               {
                    if (index == Indexes[k-1][j-1])
                    {
                         count = count + 1;
                         Mu = Mu + LogM[k-1];
                    }
               }
               Mu = Mu / count - U;
               sprintf(outline,"%10.3f %3d ",Mu,count);
               astr = astr + outline;
          }
          FrmOutPut->RichOutPut->Lines->Add(astr);
     }
     FrmOutPut->ShowModal();

     // get second order interactions
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Second Order Loglinear Model Terms and N of Cells in Each");
     astr = "CELL              ";
     for (i = 1; i < NoDims; i++)
         for (j = i + 1; j <= NoDims; j++)
         {
             sprintf(outline,"U%d%d  N Cells  ",i,j);
             astr = astr + outline;
         }
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 1; i <= ArraySize; i++) // cell
     {
          astr = "";
          for (j = 1; j <= NoDims; j++)
          {
              sprintf(outline,"%3d ",Indexes[i-1][j-1]);
              astr = astr + outline;
          }
          for (j = 1; j < NoDims; j++) // jth
          {
               index = Indexes[i-1][j-1]; // sum for this mu using j and k
               for (k = j + 1; k <= NoDims; k++) // with kth
               {
                    index2 = Indexes[i-1][k-1];
                    Mu = 0.0;
                    count = 0;
                    for (l = 1; l <= ArraySize; l++)
                    {
                         if ((index == Indexes[l-1][j-1]) && (index2 == Indexes[l-1][k-1]))
                         {
                              Mu = Mu + LogM[l-1];
                              count = count + 1;
                         }
                    } // next l
                    Mu = Mu / (double)count - U;
                    sprintf(outline,"%10.3f %3d",Mu,count);
                    astr = astr + outline;
               } // next k (second term subscript)
          } // next j (first term subscript)
          FrmOutPut->RichOutPut->Lines->Add(astr);
     } // next i

     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     // get maximum no. of interactions in saturated model
     MaxCombos(NoDims, MM, MP);

     GSQ = new double[NoDims+1];
     DGFR = new int[NoDims+1];
     GetDblMatMem(PART,NoDims+1,MP+1);
     GetDblMatMem(MARG,NoDims+1,MP+1);
     GetIntMatMem(DFS,NoDims+1,MP+1);
     GetIntMatMem(IP,NoDims+1,MP+1);
     GetIntMatMem(IM,NoDims+1,MM+1);
     ISET = new int[NoDims+1];
     JSET = new int[NoDims+1];
     GetIntMatMem(CONFIG,NoDims+1,MP+1);
     FIT = new double[ArraySize+1];
     SIZE = new int[NoDims+1];
     COORD = new int[NoDims+1];
     X = new double[ArraySize+1];
     Y = new double[ArraySize+1];
     TABLE = new double[ArraySize+1];
     DIM = new int[NoDims+1];

     // Load TABLE and DIM one up from Data
     for (i = 1; i <= ArraySize; i++) TABLE[i] = Data[i-1];
     for (i = 1; i <= NoDims; i++)
     {
         DIM[i] = DimSize[i-1];
         COORD[i] = 0;
     }

     Screen(NoDims,MP,MM,ArraySize,TABLE,DIM,
          GSQ,DGFR,PART,MARG,DFS,IP,IM,ISET,JSET,CONFIG,FIT,SIZE,
          COORD,X,Y,IFAULT);

     // show results
     astr = "SCREEN FOR INTERACTIONS AMONG THE VARIABLES";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     astr = "Adapted from the Fortran program by Lustbader and Stodola printed in";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     astr = "Applied Statistics, Volume 30, Issue 1, 1981, pages 97-105 as Algorithm";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     astr = "AS 160 Partial and Marginal Association in Multidimensional Contingency Tables";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Statistics for tests that the interactions of a given order are zero";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     astr = "ORDER     STATISTIC    D.F.         PROB.";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     for (i = 1; i <= NoDims; i++)
     {
          ProbChi2 = 1.0 - chisquaredprob(GSQ[i],DGFR[i]);
          sprintf(outline,"%5d     %10.3f      %3d  %10.3f",i,GSQ[i],DGFR[i],ProbChi2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Statistics for Marginal Association Tests";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     astr = "VARIABLE  ASSOC.  PART ASSOC. MARGINAL ASSOC. D.F.    PROB";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     for (i = 1; i < NoDims; i++)
     {
          for (j = 1; j <= MP; j++)
          {
               ProbChi2 = 1.0 - chisquaredprob(MARG[i][j],DFS[i][j]);
               sprintf(outline,"%5d     %5d    %10.3f  %10.3f  %3d   %10.3f",
                       i,j,PART[i][j],MARG[i][j], DFS[i][j],ProbChi2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     delete[] DIM;
     delete[] TABLE;
     delete[] Y;
     delete[] X;
     delete[] COORD;
     delete[] SIZE;
     delete[] FIT;
     ClearIntMatMem(CONFIG,NoDims+1);
     delete[] JSET;
     delete[] ISET;
     ClearIntMatMem(IM,NoDims+1);
     ClearIntMatMem(IP,NoDims+1);
     ClearIntMatMem(DFS,NoDims+1);
     ClearDblMatMem(MARG,NoDims+1);
     ClearDblMatMem(PART,NoDims+1);
     delete[] DGFR;
     delete[] GSQ;
     delete[] NSize;
     ClearDblMatMem(M,ArraySize);
     delete[] LogM;
     ClearIntMatMem(Indexes,ArraySize+1);
     delete[] Expected;
     ClearIntMatMem(Margins,NoDims);
     delete[] Data;
     delete[] WorkVec;
     delete[] GridPos;
     delete[] Subscripts;
     delete[] DimSize;
     delete[] Labels;
     delete[] Interact;
     Interact = NULL;
     delete[] Response;
     Response = NULL;
     delete[] Minimums;
     Minimums = NULL;
     delete[] Maximums;
     Maximums = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::Marginals(int NoDims, int ArraySize, int **indexes,
                              double *Data, int **Margins)
{
     int i, j, category;

     for (i = 1; i <= ArraySize; i++)
     {
          for (j = 1; j <= NoDims; j++)
          {
               category = indexes[i-1][j-1];
               Margins[j-1][category-1] = Margins[j-1][category-1] + ceil(Data[i-1]);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::Screen(int &NVAR, int &MP, int &MM, int &NTAB,
                         double *TABLE, int *DIM, double *GSQ, int *DGFR,
                         double **PART, double **MARG, int **DFS,
                         int **IP, int **IM, int *ISET, int *JSET,
                         int **CONFIG, double *FIT, int *SIZE, int *COORD,
                         double *X, double *Y, int &IFAULT)
{
	 int ISZ, MAX, LIM, I, J, NV1, M, M1, ITP, NP, NP1, L3, DF;
      double ZERO, G21, G22, G23, AVG;

//      SUBROUTINE SCREEN(NVAR, MP, MM, NTAB, TABLE, DIM, GSQ, DGFR,
//     *   PART, MARG, DFS, IP, IM, ISET, JSET, CONFIG, FIT, SIZE,
//     *   COORD, X, Y, IFAULT)
//
//     ALGORITHM AS 160 APPL. STATIST. (1981) VOL.30, NO.1
//
//     Screen all efects for partial and marginal association.
//
      ZERO = 0.0;
      IFAULT = 1;
      if (NVAR <= 1) return;
      ISZ = 1;
      for (I = 1; I <= NVAR; I++)
      {
           if (DIM[I] <= 1) IFAULT = 2;
           ISZ = ISZ * DIM[I];
      }
      if (ISZ != NTAB) IFAULT = 2;
      MAX = 1;
      LIM = NVAR / 2;
      for (I = 1; I <= LIM; I++) MAX = MAX * (NVAR - I + 1) / I;
      if (MP < MAX)  IFAULT = 3;
      MAX = 1;
      LIM = (NVAR - 1) / 2;
      for (I = 1; I <= LIM; I++) MAX = MAX * (NVAR - I) / I;
      MAX = MAX * NVAR;
      if (MM < MAX)  IFAULT = 4;
      if (IFAULT > 1)  return;
//
//     Fit the no effect model
//
      DGFR[NVAR] = NTAB - 1;
      AVG = ZERO;
      IFAULT = 5;
      for (I = 1; I <= NTAB; I++)
      {
	       if (TABLE[I] < ZERO) return; //RETURN
	       AVG = AVG + TABLE[I];
      }
      IFAULT = 0;
      AVG = AVG / (double)NTAB;
      RESET(FIT, NTAB, AVG);
      LIKE(GSQ[1], FIT, TABLE, NTAB);
//
//    fitting effects
//
      NV1 = NVAR - 1;
      for (M = 1; M <= NV1; M++)
      {
          M1 = M;
          CONF(NVAR, M1, MP, MM, ISET, JSET, IP, IM, NP);
          //
          //    Fit the saturated model
          //
          RESET(FIT, NTAB, AVG);
          EVAL(IP, NP, M, 1, NVAR, MP, CONFIG, DIM, DGFR[M]);
          LOGFIT(NVAR, NTAB, NP, DIM, CONFIG, TABLE, FIT, SIZE, COORD, X, Y);
          LIKE(GSQ[M+1], FIT, TABLE, NTAB);
          //
          //     Move the first column of IP to the last
          //
          for (I = 1; I <= M; I++)
          {
	         ITP = IP[I][1];
	         NP1 = NP - 1;
              for (J = 1; J <= NP1; J++) IP[I][J] = IP[I][J+1];
	         IP[I][NP] = ITP;
          }
          L3 = -M + 1;
          for (J = 1; J <= NP; J++)
          {
              //  Fit the effects in IP ignoring the last column
	         RESET(FIT, NTAB, AVG);
	         EVAL(IP, NP-1, M, 1, NVAR, MP, CONFIG, DIM, DF);
	         LOGFIT(NVAR, NTAB, NP-1, DIM, CONFIG, TABLE, FIT, SIZE, COORD, X, Y);
	         LIKE(G21, FIT, TABLE, NTAB);
	         DFS[M][J] = DGFR[M] - DF;
	         PART[M][J] = G21 - GSQ[M+1];
              //     For M = 1, partials and marginals are equal
  	         if (M > 1)  goto label160;
	         MARG[1][J] = PART[1][J];
	         goto label170;
              //     Fit the last column alone
label160:     RESET(FIT, NTAB, AVG);
	         EVAL(IP, 1, M, NP, NVAR, MP, CONFIG, DIM, DF);
	         LOGFIT(NVAR, NTAB, 1, DIM, CONFIG, TABLE, FIT, SIZE, COORD, X, Y);
	         LIKE(G22, FIT, TABLE, NTAB);
              //     Locate the appropriate columns of IM and fit them
              L3 = L3 + M;
	         RESET(FIT, NTAB, AVG);
	         EVAL(IM, M, M-1, L3, NVAR, MM, CONFIG, DIM, DF);
	         LOGFIT(NVAR, NTAB, M, DIM, CONFIG, TABLE, FIT, SIZE, COORD, X, Y);
	         LIKE(G23, FIT, TABLE, NTAB);
	         MARG[M][J] = G23 - G22;
              //     Move the next effect to be ignored to the last in IP
label170:     for (I = 1; I <= M; I++)
              {
	           ITP = IP[I][NP];
	           IP[I][NP] = IP[I][J];
	           IP[I][J] = ITP;
              }
          }
          DGFR[NVAR] = DGFR[NVAR] - DGFR[M];
          GSQ[M] = GSQ[M] - GSQ[M+1];
      }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::CONF(int &N, int &M, int &MP, int &MM, int *ISET,
                       int *JSET, int **IP, int **IM, int &NP)
{
     bool ILAST, JLAST;
     int I, L, NM, JS;
//      SUBROUTINE CONF(N, M, MP, MM, ISET, JSET, IP, IM, NP)
//C
//C     ALGORITHM AS 160.1 APPL. STATIST. (1981) VOL.30, NO.1
//C
//C     Set up the arrays IP and IM for a given N and M.   Essentially
//C     IP contains all possible combinations of (N choose M).   For each
//C     combination found IM contains all combinations of degree M-1.
//C
      ILAST = true;
      NP = 0;
      NM = 0;
//    Get IP
L100:
      COMBO(ISET, N, M, ILAST);
      if (ILAST) return;
      NP = NP + 1;
      for (I = 1; I <= M; I++) IP[I][NP] = ISET[I];
      if (M == 1) goto L100;
//     Get IM
      JLAST = TRUE;
      L = M - 1;
L120:
      COMBO(JSET, M, L, JLAST);
      if (JLAST)  goto L100;
      NM = NM + 1;
      for (I = 1; I <= L; I++)
      {
	     JS = JSET[I];
	     IM[I][NM] = ISET[JS];
      }
      goto L120;
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::COMBO(int *ISET, int N, int M, bool &LAST)
{
	int I, K, L;
//      SUBROUTINE COMBO(ISET, N, M, LAST)
//
//     ALGORITHM AS 160.2  APPL. STATIST. (1981) VOL.30, NO.1
//
//     Subroutine to generate all possible combinations of M of the
//     integers from 1 to N in a stepwise fashion.   Prior to the first
//     call, LAST should be set to .FALSE.   Thereafter, as long as LAST
//     is returned .FALSE., a new valid combination has been generated.
//     When LAST goes .TRUE., there are no more combinations.
//
      if (LAST) goto L110;
//     Get next element to increment
      K = M;
L100: L = ISET[K] + 1;
      if (L + M - K <= N) goto L150;
      K = K - 1;
//     See if we are done
      if (K <= 0)  goto L130;
      goto L100;
//     Initialize first combination
L110: for (I = 1; I <= M; I++) ISET[I] = I;
L130: LAST = ! LAST;
      return;
//
//     Fill in remainder of combination.
//
L150: for (I = K; I <= M; I++)
      {
	     ISET[I] = L;
	     L = L + 1;
      }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::EVAL(int **IAR, int NC, int NV, int IBEG, int NVAR, int MAX,
                       int **CONFIG, int *DIM, int &DF)
{
       int I, J, K, KK, L;

//      SUBROUTINE EVAL(IAR, NC, NV, IBEG, NVAR, MAX, CONFIG, DIM, DF)
//
//     ALGORITHM AS 160.3 APPL. STATIST. (1981) VOL.30, NO.1
//
//     IAR  = array containing the effects to be fitted
//     NC   = number of columns of IAR to be used
//     NV   = number of variables in each effect
//     IBEG = gebinning column
//     DF   = degrees of freedom
//
//     CONFIG is in a format compatible with algorithm AS 51
//
      DF = 0;
      for (J = 1; J <= NC; J++)
      {
	     KK = 1;
	     for (I = 1; I <= NV; I++) //DO 100 I = 1, NV
          {
	          L = IBEG + J - 1;
	          K = IAR[I][L];
	          KK = KK * (DIM[K] - 1);
	          CONFIG[I][J] = K;
          }
	     CONFIG[NV+1][J] = 0;
	     DF = DF + KK;
      }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::RESET(double *FIT, int NTAB, double AVG)
{
     int I;

//
//      SUBROUTINE RESET(FIT, NTAB, AVG)
//
//     ALGORITHM AS 160.4 APPL. STATIST. (1981) VOL.30, NO.1
//
//     Initialize the fitted values to the average entry
//
      for (I = 1; I <= NTAB; I++)
      {
	     FIT[I] = AVG;
      }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::LIKE(double &GSQ,  double *FIT, double *TABLE, int NTAB)
{
     int I;
     double ZERO, TWO;

     ZERO = 0.0;
     TWO = 2.0;
//      SUBROUTINE LIKE(GSQ, FIT, TABLE, NTAB)
//
//     ALGORITHM AS 160.5 APPL. STATIST. (1981) VOL.30, NO.1
//
//     Compute the likelihood-ration chi-square
//
      GSQ = ZERO;
      for (I = 1; I <= NTAB; I++)
      {
	     if ((FIT[I] == ZERO) || (TABLE[I] == ZERO))  continue;
	     GSQ = GSQ + TABLE[I] * log(TABLE[I] / FIT[I]);
      }
      GSQ = TWO * GSQ;
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::LOGFIT(int NVAR, int NTAB, int NCON, int *DIM,
                         int **CONFIG, double *TABLE, double *FIT, int *SIZE,
                         int *COORD, double *X, double *Y)
{
     int II, K, KK, L, N, J, I;
     bool OPTION;
     double MAXDEV, ZERO, XMAX, E;
     int MAXIT, NV1, ISZ;

//      SUBROUTINE LOGFIT(NVAR, NTAB, NCON, DIM, CONFIG, TABLE, FIT, SIZE,
//     *     COORD, X, Y)
//
//     ALGORITHM AS 160.6 APPL. STATIST. (1981) VOL.30, NO.1
//
//     Iterative proportional fitting of the marginals of a contingency
//     table.   Relevant code from AS 51 is used.
//

      MAXDEV = 0.25;
      ZERO = 0.0;
      MAXIT = 25;
      for (KK = 1; KK <= MAXIT; KK++)
      {
          //     XMAX is the maximum deviation between fitted and true marginal
	     XMAX = ZERO;
	     for (II = 1; II <= NCON; II++)
          {
	          OPTION = TRUE;
               //     Initialize arrays
	          SIZE[1] = 1;
	          NV1 = NVAR - 1;
	          for (K = 1; K <= NV1; K++)
               {
	               L = CONFIG[K][II];
	               if (L == 0)  goto L110;
	               SIZE[K+1] = SIZE[K] * DIM[L];
               }
	          K = NVAR;
L110:          N = K - 1;
	          ISZ = SIZE[K];
	          for (J = 1; J <= ISZ; J++)
               {
	               X[J] = ZERO;
	               Y[J] = ZERO;
               }
               //     Initialize co-ordinates
L130:          for (K = 1; K <= N; K++) COORD[K] = 0;
               //     Find locations in tables
               I = 1;
L150:          J = 1;
               for (K = 1; K <= N; K++)
               {
	               L = CONFIG[K][II];
	               J = J + COORD[L] * SIZE[K];
               }
               if (! OPTION)  goto L170;
               //     Compute marginals
               X[J] = X[J] + TABLE[I];
	          Y[J] = Y[J] + FIT[I];
	          goto L180;
               //     Make adjustments
L170:          if (Y[J] <= ZERO)  FIT[I] = ZERO;
               if (Y[J] > ZERO)  FIT[I] = FIT[I] * X[J] / Y[J];
               //     Update co-ordinates
L180:          I = I + 1;
	          for (K = 1; K <= NVAR; K++)
               {
	               COORD[K] = COORD[K] + 1;
	               if (COORD[K] < DIM[K]) goto L150;
	               COORD[K] = 0;
               }
               if (!OPTION) goto L200;
	          OPTION = false;
	          goto L130;
               //     Find the largest deviation
L200:          for (I = 1; I <= ISZ; I++)
               {
	               E = fabs(X[I] - Y[I]);
	               if (E > XMAX)  XMAX = E;
               }
         }
         //     Test convergence
	    if (XMAX < MAXDEV) return;
      }
}
//---------------------------------------------------------------------------

void __fastcall TLogLinScreenForm::MaxCombos(int NoDims, int &MM, int &MP)
{
     int combos;
     int i,j;

     MM = 0;
     MP = 0;
     for (i = 1; i <= NoDims; i++)
     {
          combos = 1;
          // get numerator factorial products down to i
          for (j = NoDims; j >= i + 1; j--) combos = combos * j;
          // divide by factorial of NoDims - i;
          for (j = (NoDims - i); j >= 2; j--)
              combos = combos / j;
          if (combos > MP)  MP = combos;
          if (i * combos > MM)  MM = i * combos;
     }
}
//---------------------------------------------------------------------------


  int __fastcall TLogLinScreenForm::ArrayPosition(int NoDims, double *Data, int *Subscripts,
                               int *DimSize)
{
     int Position, i, j;
     int *PriorSizes;

     // allocate space for PriorSizes
     PriorSizes = new int [NoDims];

     // calculate PriorSizes values
     for (i = 0; i < NoDims - 1; i++) PriorSizes[i] = 1; // initialize
     for (i = NoDims - 2; i >=0; i--)
          for (j = 0; j <= i; j++) PriorSizes[i] = PriorSizes[i] * DimSize[j];
     Position = Subscripts[0] - 1;
     for (i = 0; i < NoDims - 1; i++)
         Position = Position + (PriorSizes[i] * (Subscripts[i+1]-1));
     delete[] PriorSizes;
//     PriorSizes = NULL;
     return (Position);
}
//---------------------------------------------------------------------------

