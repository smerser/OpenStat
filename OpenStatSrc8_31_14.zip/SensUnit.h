//---------------------------------------------------------------------------

#ifndef SensUnitH
#define SensUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSensForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *Varlist;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TBitBtn *AllBtn;
    TLabel *Label2;
    TListBox *SelectedList;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TMemo *Memo1;
    TGroupBox *GroupBox1;
    TCheckBox *StandardizeChk;
    TGroupBox *GroupBox2;
    TCheckBox *PlotChk;
    TCheckBox *SlopesChk;
    TLabel *Label3;
    TEdit *AlphaEdit;
    TGroupBox *GroupBox3;
    TCheckBox *PrtDataChk;
    TCheckBox *PrtSlopesChk;
    TCheckBox *PrtRanksChk;
    TCheckBox *AvgSlopeChk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TSensForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSensForm *SensForm;
//---------------------------------------------------------------------------
#endif
