//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "OneSampleUnit.h"
#include "Math.h"
#include "DataFuncs.h"
#include "OneSampOptUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOneSampOptForm *OneSampOptForm;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TOneSampOptForm::TOneSampOptForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::FormShow(TObject *Sender)
{
     XVarEdit->Text = "";
     YVarEdit->Text = "";
     TestForEdit->Text = "";
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     SelItem = OneSampleForm->RadioGroup1->ItemIndex;
     switch (SelItem)
     {
            case 0 : TestForEdit->Text = "One Sample Mean"; break;
            case 1 : TestForEdit->Text = "One Sample Proportion"; break;
            case 2 : TestForEdit->Text = "One Sample Correlation"; break;
            case 3 : TestForEdit->Text = "One Sample Variance"; break;
     }
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::OKBtnClick(TObject *Sender)
{
     int result,intvalue;
     double X, Y, dblvalue;
     AnsiString strvalue;

     // Now get sample statistic and place in the first form
     XCol = 0;
     YCol = 0;
     for (int i = 0; i < NoVariables; i++)
     {
         if (XVarEdit->Text == MainForm->Grid->Cells[i+1][0]) XCol = i+1;
         if (YVarEdit->Text == MainForm->Grid->Cells[i+1][0]) YCol = i+1;
     }
     if (XCol == 0)
     {
        ShowMessage("No variable found to analyze.  Returning.");
        return;
     }
     switch (SelItem)
     {
            case 0 : // Sample Mean or sample variance
            {
                 double Mean = 0.0;
                 double Variance = 0.0;
                 double StdDev;
                 int N = 0;
                 for (int i = 0; i < NoCases; i++)
                 {
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,XCol)) continue;
                       X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
                       Mean += X;
                       Variance += (X * X);
                       N++;
                 }
                 Variance = Variance - (Mean * Mean) / N;
                 Variance /= (N - 1);
                 StdDev = sqrt(Variance);
                 Mean /= N;
                 OneSampleForm->Statistic->Text = FloatToStr(Mean);
                 OneSampleForm->Size->Text = IntToStr(N);
                 OneSampleForm->StdDev->Text = FloatToStr(StdDev);
            }
            break;
            case 1 : // Sample Proportion
            {
                 double MinX = 1.0E1000;
                 double MaxX = -1.0E1000;
                 double PropLow = 0.0;
                 double PropHi = 0.0;
                 for (int i = 0; i < NoCases; i++)
                 {
//                      double X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
//                       result = GetValue(i+1,XCol,intvalue,dblvalue,strvalue);
//                       if (result == 1) X = 0.0;
//                       else X = dblvalue;
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,XCol)) continue;
                       X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
                      if (X < MinX) MinX = X;
                      if (X > MaxX) MaxX = X;
                 }
                 double Mean = 0.0;
                 double Variance = 0.0;
                 double StdDev;
                 int N = 0;
                 for (int i = 0; i < NoCases; i++)
                 {
//                       double X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
//                       result = GetValue(i+1,XCol,intvalue,dblvalue,strvalue);
//                       if (result == 1) X = 0.0;
//                       else X = dblvalue;
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,XCol)) continue;
                       X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
                       if (X == MinX) PropLow += 1.0;
                       if (X == MaxX) PropHi += 1.0;
                       N++;
                 }
                 Mean = PropHi / (PropLow + PropHi);
                 OneSampleForm->Statistic->Text = FloatToStr(Mean);
                 OneSampleForm->Size->Text = N;
                 Variance = (PropLow * PropHi) / (PropLow + PropHi);
                 StdDev = sqrt(Variance);
                 OneSampleForm->StdDev->Text = FloatToStr(StdDev);
            }
            break;
            case 2 : // Sample Correlation
            {
                 double MeanX = 0.0;
                 double MeanY = 0.0;
                 double CovXY = 0.0;
                 double VarX = 0.0;
                 double VarY = 0.0;
                 double CorrXY = 0.0;
                 int N = 0;
                 for (int i = 0; i < NoCases; i++)
                 {
//                       double X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
//                       result = GetValue(i+1,XCol,intvalue,dblvalue,strvalue);
//                       if (result == 1) X = 0.0;
//                       else X = dblvalue;
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,XCol)) continue;
                       X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);

//                       double Y = StrToFloat(MainForm->Grid->Cells[YCol][i+1]);
//                       result = GetValue(i+1,YCol,intvalue,dblvalue,strvalue);
//                       if (result == 1) Y = 0.0;
//                       else Y = dblvalue;
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,YCol)) continue;
                       Y = StrToFloat(MainForm->Grid->Cells[YCol][i+1]);

                       MeanX += X;
                       MeanY += Y;
                       CovXY += (X * Y);
                       VarX += (X * X);
                       VarY += (Y * Y);
                       N++;
                 }
                 CovXY = CovXY - (MeanX * MeanY) / N;
                 CovXY /= (N - 1);
                 VarX = VarX - (MeanX * MeanX) / N;
                 VarX /= (N - 1);
                 VarY = VarY - (MeanY * MeanY) / N;
                 VarY /= (N - 1);
                 CorrXY = CovXY / sqrt(VarX * VarY);
                 OneSampleForm->Statistic->Text = FloatToStr(CorrXY);
                 OneSampleForm->Size->Text = N;
            }
            break;
            case 3 : // variance
            {
                 double Mean = 0.0;
                 double Variance = 0.0;
                 double StdDev;
                 int N = 0;
                 for (int i = 0; i < NoCases; i++)
                 {
//                       double X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
//                       result = GetValue(i+1,XCol,intvalue,dblvalue,strvalue);
//                       if (result == 1) X = 0.0;
//                       else X = dblvalue;
                       if ((FilterOn) &&
                          (Trim(MainForm->Grid->Cells[FilterCol][i+1]) == "NO")) continue;
                       if (!ValidValue(i+1,XCol)) continue;
                       X = StrToFloat(MainForm->Grid->Cells[XCol][i+1]);
                       Mean += X;
                       Variance += (X * X);
                       N++;
                 }
                 Variance = Variance - (Mean * Mean) / N;
                 Variance /= (N - 1);
                 StdDev = sqrt(Variance);
//                 Mean /= N;
                 OneSampleForm->Statistic->Text = FloatToStr(Variance);
                 OneSampleForm->Size->Text = IntToStr(N);
                 OneSampleForm->StdDev->Text = FloatToStr(StdDev);
            }
            break;
     }
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::XVarInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     XVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::YVarInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     YVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::XVarOutBtnClick(TObject *Sender)
{
     if (XVarEdit->Text == "") return;
     VarList->Items->Add(XVarEdit->Text);
     XVarEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TOneSampOptForm::YVarOutBtnClick(TObject *Sender)
{
     if (YVarEdit->Text == "") return;
     VarList->Items->Add(YVarEdit->Text);
     YVarEdit->Text = "";
}
//---------------------------------------------------------------------------
