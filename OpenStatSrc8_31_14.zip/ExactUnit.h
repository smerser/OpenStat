//---------------------------------------------------------------------------

#ifndef ExactUnitH
#define ExactUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TExactForm : public TForm
{
__published:	// IDE-managed Components
     TRadioGroup *InputGroup;
     TPanel *Panel1;
     TLabel *Label1;
     TListBox *VarList;
     TBitBtn *RowIn;
     TBitBtn *RowOut;
     TBitBtn *ColIn;
     TBitBtn *ColOut;
     TBitBtn *DepIn;
     TBitBtn *DepOut;
     TLabel *Label2;
     TEdit *RowEdit;
     TLabel *Label3;
     TEdit *ColEdit;
     TLabel *Label4;
     TEdit *DepEdit;
     TLabel *Label5;
     TEdit *NCasesEdit;
     TPanel *Panel2;
     TEdit *RC11Edit;
     TEdit *RC12Edit;
     TEdit *RC21Edit;
     TEdit *RC22Edit;
     TLabel *Label6;
     TLabel *Label7;
     TLabel *Label8;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TLabel *Label9;
     TLabel *Label10;
     TLabel *Label11;
     TLabel *Label12;
     TLabel *Label13;
     TEdit *Row1Edit;
     TEdit *Col1Edit;
     TEdit *Row2Edit;
     TEdit *Col2Edit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall InputGroupClick(TObject *Sender);
     void __fastcall RowInClick(TObject *Sender);
     void __fastcall RowOutClick(TObject *Sender);
     void __fastcall ColInClick(TObject *Sender);
     void __fastcall ColOutClick(TObject *Sender);
     void __fastcall DepInClick(TObject *Sender);
     void __fastcall DepOutClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall FisherTable(int A, int b, int C, int d,
                                        double p, double SumP);

private:	// User declarations
public:		// User declarations
     __fastcall TExactForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TExactForm *ExactForm;
//---------------------------------------------------------------------------
#endif
