//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "functions.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "TwoCorrsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTwoCorrsForm *TwoCorrsForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TTwoCorrsForm::TTwoCorrsForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::ResetBtnClick(TObject *Sender)
{
     int i;

     RadioGroup1->ItemIndex = 0;
     RadioGroup2->ItemIndex = 0;
     Panel1->Visible = true;
     Panel2->Visible = false;
     VarList->Clear();
     rxy->Text = "";
     rxz->Text = "";
     ryz->Text = "";
     rxy1->Text = "";
     rxy2->Text = "";
     SampSize->Text = "";
     Size1->Text = "";
     Size2->Text = "";
     Xvar->Text = "";
     Yvar->Text = "";
     Zvar->Text = "";
     Grp->Text = "";
     CInterval->Text = "95";
     independent = true;
     griddata = false;
     for (i = 1; i <= NoVariables; i++)
     	VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::RadioGroup1Click(TObject *Sender)
{
     int index;

     index = RadioGroup1->ItemIndex;
     if (index == 0) // enter data on the form
     {
          Panel1->Visible = true;
          Panel2->Visible = false;
          griddata = false;
     }
     else // enter data from the grid
     {
          Panel1->Visible = false;
          Panel2->Visible = true;
          griddata = true;
          if (RadioGroup2->ItemIndex == 1)  // dependent proportions
          {
               Label14->Visible = true;
               Zvar->Visible = true;
               Grp->Visible = false;
               Label12->Visible = false;
          }
          else // independent proportions
          {
               Label14->Visible = false;
               Zvar->Visible = false;
               Grp->Visible = true;
               Label12->Visible = true;
          }
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::RadioGroup2Click(TObject *Sender)
{
     int index;

     index = RadioGroup2->ItemIndex;
     if (index == 0) // independent correlations
     {
          independent = true;
          Grp->Visible = true;
          Label12->Visible = true;
          Label14->Visible = false;
          Zvar->Visible = false;
          Label1->Visible = true;
          Label2->Visible = true;
          Label3->Visible = true;
          Label4->Visible = true;
          rxy1->Visible = true;
          rxy2->Visible = true;
          Size1->Visible = true;
          Size2->Visible = true;
          Label5->Visible = false;
          Label6->Visible = false;
          Label7->Visible = false;
          Label8->Visible = false;
          rxy->Visible = false;
          rxz->Visible = false;
          ryz->Visible = false;
          SampSize->Visible = false;
     }
     else // correlated correlations
     {
          independent = false;
          Label12->Visible = false;
          Grp->Visible = false;
          Label14->Visible = true;
          Zvar->Visible = true;
          Label1->Visible = false;
          Label2->Visible = false;
          Label3->Visible = false;
          Label4->Visible = false;
          rxy1->Visible = false;
          rxy2->Visible = false;
          Size1->Visible = false;
          Size2->Visible = false;
          Label5->Visible = true;
          Label6->Visible = true;
          Label7->Visible = true;
          Label8->Visible = true;
          rxy->Visible = true;
          rxz->Visible = true;
          ryz->Visible = true;
          SampSize->Visible = true;
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::ContinueBtnClick(TObject *Sender)
{
   double Corxy, Corxz, Coryz, Cor1, Cor2, alpha, tvalue, df1, df2;
   double CorDif, zOne, zTwo, zDif, StdError, zValue, zprobability;
   double UCL, LCL, ztest, ConfLevel, tprobability, ttest;
   double mean1, mean2, mean3, variance1, variance2, variance3;
   double stddev1, stddev2, stddev3, value1, value2, value3;
   double meanx1, meanx2, meany1, meany2, varx1, varx2, vary1, vary2;
   double sdx1, sdx2, sdy1, sdy2, value;
   int SSize1, SSize2, SSize, v1, v2, v3, grp, ncases, NoSelected;
   int min, max, grpval, ncases1, ncases2, tempcol;
   AnsiString cellstring;
   char outline[121];
   int *ColNoSelected;
   bool results;
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;

     ColNoSelected = new int [NoVariables];
     Corxy = 0.0;
     Corxz = 0.0;
     Coryz = 0.0;
     Cor1 = 0.0;
     Cor2 = 0.0;
     mean1 = 0.0;
     mean2 = 0.0;
     mean3 = 0.0;
     variance1 = 0.0;
     variance2 = 0.0;
     variance3 = 0.0;
     meanx1 = 0.0;
     meanx2 = 0.0;
     meany1 = 0.0;

     if (! griddata)  // use data on the form
     {
          if (independent)  // read data from form and obtain results
          {
               Cor1 = StrToFloat(rxy1->Text);
               Cor2 = StrToFloat(rxy2->Text);
               SSize1 = StrToInt(Size1->Text);
               SSize2 = StrToInt(Size2->Text);
               ConfLevel = StrToFloat(CInterval->Text) / 100.0;
               CorDif = Cor1 - Cor2;
               zOne = 0.5 * log((1.0 + Cor1) / (1.0 - Cor1));
               zTwo = 0.5 * log((1.0 + Cor2) / (1.0 - Cor2));
               zDif = zOne - zTwo;
               StdError = sqrt((1.0 / ((double) SSize1 - 3.0)) + (1.0 / ((double) SSize2 -3.0)));
               zValue = zDif / StdError;
               alpha = (1.0 - ConfLevel) / 2.0;
               ztest = inversez(1.0 - alpha);
               zprobability = 1.0 - probz(zValue);
               UCL = zDif + StdError * ztest;
               LCL = zDif - StdError * ztest;
               UCL = (exp(2.0 * UCL) - 1.0) / (exp(2.0 * UCL) + 1.0);
               LCL = (exp(2.0 * LCL) - 1.0) / (exp(2.0 * LCL) + 1.0);
          }
          if (! independent)  // obtain data from form and obtain results
          {
               Corxy = StrToFloat(rxy->Text);
               Corxz = StrToFloat(rxz->Text);
               Coryz = StrToFloat(ryz->Text);
               SSize = StrToInt(SampSize->Text);
               ConfLevel = StrToFloat(CInterval->Text) / 100.0;
               CorDif = Corxy - Corxz;
               alpha = (1.0 - ConfLevel) / 2.0;
               tvalue = (CorDif * sqrt(((double)SSize - 3.0) * (1.0 + Coryz))) /
                    sqrt(2.0 * (1.0 - (Corxy * Corxy) - (Corxz * Corxz) -
                    (Coryz * Coryz) + (2.0 * Corxy * Corxz * Coryz)));
//               df1 = 1.0;
               df2 = (double) SSize - 3.0;
               tprobability = tprob(tvalue,df2);
               ttest = inverset(1.0 - alpha, df2);
          }
     }

     if (griddata)
     {
          v1 = 0;
          v2 = 0;
          grp = 0;
          if (independent)  // read grid data for independent r"s
          {
               for (int i = 1; i <= NoVariables; i++)
               {
                    cellstring = MainForm->Grid->Cells[i][0];
                    if (cellstring == Xvar->Text)  v1 = i;
                    if (cellstring == Yvar->Text)  v2 = i;
                    if (cellstring == Grp->Text)  grp = i;
               }
               if ((v1 == 0) || (v2 == 0) || (grp == 0))
               {
                  ShowMessage("ERROR!  Select variables to analyze.");
                  delete[] ColNoSelected;
                  return;
               }

                // check to see if strcol is a string variable
                cellstring = DictionaryForm->DGrid->Cells[3][grp];
                if (cellstring == "2") // recode into an integer code
                {
                        results = StringsToInt(grp, tempcol, true);
                        grp = NoVariables;
                }
               //result = VarTypeChk(v1,0);
               //if (result == 1)
               //{
               //     delete[] ColNoSelected;
               //     return;
               //}
               //result = VarTypeChk(v2,0);
               //if (result == 1)
               //{
               //     delete[] ColNoSelected;
               //     return;
               //}
               //result = VarTypeChk(grp,1);
               //if (result == 1)
               //{
               //     delete[] ColNoSelected;
               //     return;
               //}

               ColNoSelected[0] = v1;
               ColNoSelected[1] = v2;
               ColNoSelected[2] = grp;
               NoSelected = 3;
               meanx1 = 0.0;
               meany1 = 0.0;
               varx1 = 0.0;
               vary1 = 0.0;
               meanx2 = 0.0;
               meany2 = 0.0;
               varx2 = 0.0;
               vary2 = 0.0;
               Cor1 = 0.0;
               Cor2 = 0.0;
               ncases1 = 0;
               ncases2 = 0;
               min = ceil(StrToFloat(Trim(MainForm->Grid->Cells[grp][1])));
               max = min;
               for (int i = 2; i <= NoCases;i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                    grpval = floor(StrToFloat(MainForm->Grid->Cells[grp][i]));
                    //result = GetValue(i,grp,intvalue,dblvalue,strvalue);
                    //if (result == 1) grpval = 0;
                    //else grpval = intvalue;
                    if (grpval > max)  max = grpval;
                    if (grpval < min)  min = grpval;
               }
               for (int i = 1; i <= NoCases;i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                    grpval = ceil(StrToFloat(Trim(MainForm->Grid->Cells[grp][i])));
                    if (grpval == min)
                    {
                         ncases1 = ncases1 + 1;
                         value1 =  StrToFloat(Trim(MainForm->Grid->Cells[v1][i]));
                         //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                         //if (result == 1) value1 = 0.0;
                         //else value1 = dblvalue;
                         meanx1 = meanx1 + value1;
                         varx1 = varx1 + (value1 * value1);
                         value2 = StrToFloat(Trim(MainForm->Grid->Cells[v2][i]));
                         //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                         //if (result == 1) value2 = 0.0;
                         //else value2 = dblvalue;
                         meany1 = meany1 + value2;
                         vary1 = vary1 + (value2 * value2);
                         Cor1 = Cor1 + (value1 * value2);
                    }
                    if (grpval == max)
                    {
                         ncases2 = ncases2 + 1;
                         value1 =  StrToFloat(Trim(MainForm->Grid->Cells[v1][i]));
                         meanx2 = meanx2 + value1;
                         varx2 = varx2 + (value1 * value1);
                         value2 = StrToFloat(Trim(MainForm->Grid->Cells[v2][i]));
                         meany2 = meany2 + value2;
                         vary2 = vary2 + (value2 * value2);
                         Cor2 = Cor2 + (value1 * value2);
                    }
               }  // next case
               varx1 = varx1 - (meanx1 * meanx1) / (double) ncases1;
               varx1 = varx1 / (ncases1 - 1.0);
               varx2 = varx2 - (meanx2 * meanx2) / (double) ncases2;
               varx2 = varx2 / (ncases2 - 1.0);
               vary1 = vary1 - (meany1 * meany1) / (double) ncases1;
               vary1 = vary1 / (ncases1 - 1.0);
               vary2 = vary2 - (meany2 * meany2) / (double) ncases2;
               vary2 = vary2 / (ncases2 - 1.0);
               Cor1 = Cor1 - (meanx1 * meany1) / (double) ncases1;
               Cor1 = Cor1 / ((double) ncases1 - 1.0);
               Cor2 = Cor2 - (meanx2 * meany2) / (double) ncases2;
               Cor2 = Cor2 / ((double) ncases2 - 1.0);
               sdx1 = sqrt(varx1);
               sdx2 = sqrt(varx2);
               sdy1 = sqrt(vary1);
               sdy2 = sqrt(vary2);
               Cor1 = Cor1 / (sdx1 * sdy1);
               Cor2 = Cor2 / (sdx2 * sdy2);
               meanx1 = meanx1 / (double) ncases1;
               meany1 = meany1 / (double) ncases1;
               meanx2 = meanx2 / (double) ncases2;
               meany2 = meany2 / (double) ncases2;
               SSize1 = ncases1;
               SSize2 = ncases2;
               ConfLevel = StrToFloat(CInterval->Text) / 100.0;
               CorDif = Cor1 - Cor2;
               zOne = 0.5 * log((1.0 + Cor1) / (1.0 - Cor1));
               zTwo = 0.5 * log((1.0 + Cor2) / (1.0 - Cor2));
               zDif = zOne - zTwo;
               StdError = sqrt((1.0 / ((double)SSize1 - 3.0)) + (1.0 / ((double)SSize2 -3.0)));
               zValue = zDif / StdError;
               alpha = (1.0 - ConfLevel) / 2.0;
               ztest = inversez(1.0 - alpha);
               zprobability = 1.0 - probz(zValue);
               UCL = zDif + StdError * ztest;
               LCL = zDif - StdError * ztest;
               UCL = (exp(2.0 * UCL) - 1.0) / (exp(2.0 * UCL) + 1.0);
               LCL = (exp(2.0 * LCL) - 1.0) / (exp(2.0 * LCL) + 1.0);
          }
          if (! independent)  // read grid data for dependent r"s
          {
               mean1 = 0.0;
               mean2 = 0.0;
               mean3 = 0.0;
               variance1 = 0.0;
               variance2 = 0.0;
               variance3 = 0.0;
               Corxy = 0.0;
               Corxz = 0.0;
               Coryz = 0.0;
               ncases = 0;
               for (int i = 1; i <= NoVariables;i++)
               {
                    cellstring = MainForm->Grid->Cells[i][0];
                    if (cellstring == Xvar->Text)  v1 = i;
                    if (cellstring == Yvar->Text)  v2 = i;
                    if (cellstring == Zvar->Text)  v3 = i;
               }
               ColNoSelected[0] = v1;
               ColNoSelected[1] = v2;
               ColNoSelected[2] = v3;
               NoSelected = 3;
               for (int i = 1; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                    ncases = ncases + 1;
                    value1 = StrToFloat(Trim(MainForm->Grid->Cells[v1][i]));
                    value2 = StrToFloat(Trim(MainForm->Grid->Cells[v2][i]));
                    value3 = StrToFloat(Trim(MainForm->Grid->Cells[v3][i]));
                    mean1 = mean1 + value1;
                    mean2 = mean2 + value2;
                    mean3 = mean3 + value3;
                    variance1 = variance1 + (value1 * value1);
                    variance2 = variance2 + (value2 * value2);
                    variance3 = variance3 + (value3 * value3);
                    Corxy = Corxy + (value1 * value2);
                    Corxz = Corxz + (value1 * value3);
                    Coryz = Coryz + (value2 * value3);
               }
               variance1 = variance1 - (mean1 * mean1) / (double) ncases;
               variance1 = variance1 / ((double) ncases - 1.0);
               stddev1 = sqrt(variance1);
               variance2 = variance2 - (mean2 * mean2) / (double) ncases;
               variance2 = variance2 / ((double)ncases - 1.0);
               stddev2 = sqrt(variance2);
               variance3 = variance3 - (mean3 * mean3) / (double) ncases;
               variance3 = variance3 / ((double) ncases - 1.0);
               stddev3 = sqrt(variance3);
               Corxy = Corxy - (mean1 * mean2) / (double) ncases;
               Corxy = Corxy / ((double)ncases - 1.0);
               Corxy = Corxy / (stddev1 * stddev2);
               Corxz = Corxz - (mean1 * mean3) / (double) ncases;
               Corxz = Corxz / ((double)ncases - 1.0);
               Corxz = Corxz / (stddev1 * stddev3);
               Coryz = Coryz - (mean2 * mean3) / (double) ncases;
               Coryz = Coryz / ((double) ncases - 1.0);
               Coryz = Coryz / (stddev2 * stddev3);
               mean1 = mean1 / (double)ncases;
               mean2 = mean2 / (double)ncases;
               mean3 = mean3 / (double)ncases;
               SSize = ncases;
               ConfLevel = StrToFloat(CInterval->Text) / 100.0;
               CorDif = Corxy - Corxz;
               alpha = (1.0 - ConfLevel) / 2.0;
               tvalue = (CorDif * sqrt(((double)SSize - 3.0) * (1.0 + Coryz))) /
                    sqrt(2.0 * (1.0 - (Corxy * Corxy) - (Corxz * Corxz) -
                    (Coryz * Coryz) + (2.0 * Corxy * Corxz * Coryz)));
//               df1 = 1.0;
               df2 = (double)SSize - 3.0;
               tprobability = tprob(tvalue,df2);
               ttest = inverset(1.0 - alpha, df2);
          }
     }

     // Initialize output form
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("COMPARISON OF TWO CORRELATIONS");
     FrmOutPut->RichOutPut->Lines->Add("");
     if (independent)
     {
          sprintf(outline,"Correlation one = %6.3f",Cor1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Sample size one = %d",SSize1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Correlation two = %6.3f",Cor2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Sample size two = %d",SSize2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference between correlations = %6.3f",CorDif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Confidence level selected = %s",CInterval->Text);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z for Correlation One = %6.3f",zOne);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z for Correlation Two = %6.3f",zTwo);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z difference = %6.3f",zDif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Standard error of difference = %6.3f",StdError);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z test statistic = %6.3f",zValue);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Probability > |z| = %6.3f",zprobability);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z Required for significance = %6.3f",ztest);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("Note: above is a two-tailed test.");
          sprintf(outline,"Confidence Limits = (%6.3f,%6.3f)",LCL,UCL);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          if (griddata) 
          {
               sprintf(outline,"Mean X for group 1 = %9.3f",meanx1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Mean X for group 2 = %9.3f",meanx2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Std.Dev. X for group 1 = %9.3f",sdx1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Std.Dev. X for group 2 = %9.3f",sdx2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Mean y for group 1 = %9.3f",meany1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Mean Y for group 2 = %9.3f",meany2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Std.Dev. Y for group 1 = %9.3f",sdy1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Std.Dev. Y for group 2 = %9.3f",sdy2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }

     if (! independent) 
     {
          sprintf(outline,"Correlation x with y = %6.3f",Corxy);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Correlation x with z = %6.3f",Corxz);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Correlation y with z = %6.3f",Coryz);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Sample size = %d",SSize);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Confidence Level Selected = %s",CInterval->Text);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference r(x,y) - r(x,z) = %6.3f",CorDif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"t test statistic = %6.3f",tvalue);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Probability > |t| = %6.3f",tprobability);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"t value for significance = %6.3f",ttest);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          if (griddata)
          {
               FrmOutPut->RichOutPut->Lines->Add("Variable      Mean  Variance  Std.Dev.");
               sprintf(outline,"   X     %9.3f %9.3f %9.3f",
                       mean1, variance1, stddev1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"   Y     %9.3f %9.3f %9.3f",
                       mean2, variance2, stddev2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"   Z     %9.3f %9.3f %9.3f",
                       mean3, variance3, stddev3);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->ShowModal();
     delete[] ColNoSelected;
     if (results == false) DeleteaCol(NoVariables);
}
//---------------------------------------------------------------------------
void __fastcall TTwoCorrsForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     if (! independent)
     {
          if (Xvar->Text == "")  Xvar->Text = VarList->Items->Strings[index];
          else if (Yvar->Text == "") Yvar->Text = VarList->Items->Strings[index];
          else Zvar->Text = VarList->Items->Strings[index];
     }
     if (independent)
     {
          if (Xvar->Text == "") Xvar->Text = VarList->Items->Strings[index];
          else if (Yvar->Text == "") Yvar->Text = VarList->Items->Strings[index];
          else Grp->Text = VarList->Items->Strings[index];
     }
}
//---------------------------------------------------------------------------
