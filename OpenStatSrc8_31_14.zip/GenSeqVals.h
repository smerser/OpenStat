//---------------------------------------------------------------------------

#ifndef GenSeqValsH
#define GenSeqValsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TGenSeqForm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *OptionGrp;
    TButton *GenBtn;
    TButton *ReturnBtn;
    TButton *CancelBtn;
    void __fastcall GenBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TGenSeqForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGenSeqForm *GenSeqForm;
//---------------------------------------------------------------------------
#endif
