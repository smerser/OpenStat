/******************************************************************************/
/*                                                                            */
/*  LAYERNET - All principal routines for LayerNet processing                 */
/*                                                                            */
/* Copyright (c) 1993 by Academic Press, Inc.                                 */
/*                                                                            */
/* All rights reserved.  Permission is hereby granted, until further notice,  */
/* to make copies of this diskette, which are not for resale, provided these  */
/* copies are made from this master diskette only, and provided that the      */
/* following copyright notice appears on the diskette label:                  */
/* (c) 1993 by Academic Press, Inc.                                           */
/*                                                                            */
/* Except as previously stated, no part of the computer program embodied in   */
/* this diskette may be reproduced or transmitted in any form or by any means,*/
/* electronic or mechanical, including input into storage in any information  */
/* system for resale, without permission in writing from the publisher.       */
/*                                                                            */
/* Produced in the United States of America.                                  */
/*                                                                            */
/* ISBN 0-12-479041-0                                                         */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include "funcdefs.h"    // Function prototypes
#include "NeuralMainUnit.h"
#include "OutPut.h"
extern unsigned int Character;

static void free_non_null ( void **p ) ;

/*
--------------------------------------------------------------------------------

   Constructor

   The parameter 'executable' determines whether work areas for hidden and
   output neuron activations are also allocated.  These are needed if we
   will ever apply inputs and want to compute outputs.

   In case of malloc failure, we set 'ok' to zero so the user knows about it.
   Also, we always leave unallocated weight pointers set to NULL.  There is no
   hard reason for doing this; calling programs should always know enough not
   to reference them.  However, it is simply good style.  Most compilers are
   much better at producing code that intercepts NULL pointer references than
   just wild pointers.  An ounce of prevention...

--------------------------------------------------------------------------------
*/

LayerNet::LayerNet (
   int out_model ,
   int n_inputs ,
   int n_hidden1 ,
   int n_hidden2 ,
   int n_outputs ,
   int executable ,  // Also allocate hidden and output neurons?
   int zero          // Zero all weights?
   )
{
   int n1, n2, n3 ;

   outmod = out_model ;
   nin = n_inputs ;
   nhid1 = n_hidden1 ;
   nhid2 = n_hidden2 ;
   nout = n_outputs ;
   exe = executable ;
   neterr = 1.0 ;

   confusion = NULL ;
   hid1_coefs = hid2_coefs = out_coefs = hid1 = hid2 = out = NULL ;

   ok = 0 ;   // Indicates failure of malloc (What a pessimist!)

   if (exe  &&  (confusion = (int *) MALLOC ( (nout+1) * sizeof(int))) == NULL)
      return ;

   if (nhid1 == 0) {                // No hidden layer
      n1 = nout * (nin+1) ;
      if (((out_coefs = (double *) MALLOC ( n1 * sizeof(double) )) == NULL)
       || (exe && (out = (double *) MALLOC ( nout * sizeof(double) )) == NULL)){
         free_non_null ( (void **) &out_coefs ) ;
         free_non_null ( (void **) &confusion ) ;
         return ;
         }
      if (zero) {
         while (n1--)
            out_coefs[n1] = 0.0 ;
         }
      }

   else if (nhid2 == 0) {           // One hidden layer
      n1 = nhid1 * (nin+1) ;
      n2 = nout * (nhid1+1) ;
      if (((hid1_coefs = (double *) MALLOC ( n1 * sizeof(double) )) == NULL)
       || ((out_coefs = (double *) MALLOC ( n2 * sizeof(double) ))==NULL)
       || (exe && (hid1 = (double *) MALLOC ( nhid1 * sizeof(double) ))==NULL)
       || (exe && (out = (double *) MALLOC ( nout * sizeof(double) )) == NULL)){
         free_non_null ( (void **) &hid1_coefs ) ;
         free_non_null ( (void **) &out_coefs ) ;
         free_non_null ( (void **) &hid1 ) ;
         free_non_null ( (void **) &confusion ) ;
         return ;
         }
      if (zero) {
         while (n1--)
            hid1_coefs[n1] = 0.0 ;
         while (n2--)
            out_coefs[n2] = 0.0 ;
         }
      }

   else {                           // Two hidden layers
      n1 = nhid1 * (nin+1) ;
      n2 = nhid2 * (nhid1+1) ;
      n3 = nout * (nhid2+1) ;
      if (((hid1_coefs = (double *) MALLOC ( n1 * sizeof(double) )) == NULL)
       || ((hid2_coefs = (double *) MALLOC ( n2 * sizeof(double) )) == NULL)
       || ((out_coefs = (double *) MALLOC ( n3 * sizeof(double) ))==NULL)
       || (exe && (hid1 = (double *) MALLOC ( nhid1 * sizeof(double) ))==NULL)
       || (exe && (hid2 = (double *) MALLOC ( nhid2 * sizeof(double) ))==NULL)
       || (exe && (out = (double *) MALLOC ( nout * sizeof(double) )) == NULL)){
         free_non_null ( (void **) &hid1_coefs ) ;
         free_non_null ( (void **) &hid2_coefs ) ;
         free_non_null ( (void **) &out_coefs ) ;
         free_non_null ( (void **) &hid1 ) ;
         free_non_null ( (void **) &hid2 ) ;
         free_non_null ( (void **) &confusion ) ;
         return ;
         }
      if (zero) {
         while (n1--)
            hid1_coefs[n1] = 0.0 ;
         while (n2--)
            hid2_coefs[n2] = 0.0 ;
         while (n3--)
            out_coefs[n3] = 0.0 ;
         }
      }

   if (exe)
      memset ( confusion , 0 , (nout+1) * sizeof(int) ) ;

   ok = 1 ;            // Indicate to caller that all mallocs succeeded
}

/*
   Local routine to free non-null pointers
*/

static void free_non_null ( void **p )
{
   if (*p != NULL) {
      FREE ( *p ) ;
      *p = NULL ;
      }
}


/*
--------------------------------------------------------------------------------

   Destructor

--------------------------------------------------------------------------------
*/

LayerNet::~LayerNet()
{
   if (! ok)    // If constructor's mallocs failed
      return ;  // there is nothing to free

   FREE ( out_coefs ) ;
   if (exe) {
      FREE ( out ) ;
      FREE ( confusion ) ;
      }

   if (nhid1) {
      FREE ( hid1_coefs ) ;
      if (exe)
         FREE ( hid1 ) ;
      if (nhid2) {
         FREE ( hid2_coefs ) ;
         if (exe)
            FREE ( hid2 ) ;
         }
      }
}

/*
--------------------------------------------------------------------------------

   copy_weights - Copy the weights from one network to another
                  Note that this is NOT like a copy or assignment,
                  as it does not copy other parameters.  In fact,
                  it gets sizes from the calling instance!

--------------------------------------------------------------------------------
*/

void LayerNet::copy_weights ( LayerNet *dest , LayerNet *source )
{
   int n ;

   dest->neterr = source->neterr ;
   if (source->exe  &&  dest->exe) // These may be important too!
      memcpy ( dest->confusion , source->confusion , (nout+1) * sizeof(int) ) ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      memcpy ( dest->out_coefs , source->out_coefs , n * sizeof(double) ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      memcpy ( dest->hid1_coefs , source->hid1_coefs , n * sizeof(double) ) ;
      n = nout * (nhid1+1) ;
      memcpy ( dest->out_coefs , source->out_coefs , n * sizeof(double) ) ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      memcpy ( dest->hid1_coefs , source->hid1_coefs , n * sizeof(double) ) ;
      n = nhid2 * (nhid1+1) ;
      memcpy ( dest->hid2_coefs , source->hid2_coefs , n * sizeof(double) ) ;
      n = nout * (nhid2+1) ;
      memcpy ( dest->out_coefs , source->out_coefs , n * sizeof(double) ) ;
      }
}


/*
--------------------------------------------------------------------------------

   zero_weights - Zero all weights in a network

--------------------------------------------------------------------------------
*/

void LayerNet::zero_weights ()
{
   int n ;

   neterr = 1.0 ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      while (n--)
         out_coefs[n] = 0.0 ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      while (n--)
         hid1_coefs[n] = 0.0 ;
      n = nout * (nhid1+1) ;
      while (n--)
         out_coefs[n] = 0.0 ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      while (n--)
         hid1_coefs[n] = 0.0 ;
      n = nhid2 * (nhid1+1) ;
      while (n--)
         hid2_coefs[n] = 0.0 ;
      n = nout * (nhid2+1) ;
      while (n--)
         out_coefs[n] = 0.0 ;
      }
}


/*
--------------------------------------------------------------------------------

   trial - Compute the output for a given input by evaluating network

--------------------------------------------------------------------------------
*/

void LayerNet::trial ( double *input )
{
   int i ;
   
   if (! exe) {   // Should NEVER happen, but good style to aid debugging
      ShowMessage( "Internal error in LayerNet::trial" ) ;
      return ;
      }

   if (nhid1 == 0) {                // No hidden layer
      for (i=0 ; i<nout ; i++)
         out[i] = activity ( input , out_coefs+i*(nin+1) , nin ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      for (i=0 ; i<nhid1 ; i++)
         hid1[i] = activity ( input , hid1_coefs+i*(nin+1) , nin ) ;
      for (i=0 ; i<nout ; i++)
         out[i] = activity ( hid1 , out_coefs+i*(nhid1+1) , nhid1 ) ;
      }

   else {                           // Two hidden layers
      for (i=0 ; i<nhid1 ; i++)
         hid1[i] = activity ( input , hid1_coefs+i*(nin+1) , nin ) ;
      for (i=0 ; i<nhid2 ; i++)
         hid2[i] = activity ( hid1 , hid2_coefs+i*(nhid1+1) , nhid1 ) ;
      for (i=0 ; i<nout ; i++)
         out[i] = activity ( hid2 , out_coefs+i*(nhid2+1) , nhid2 ) ;
      }
}


/*
--------------------------------------------------------------------------------

   learn

--------------------------------------------------------------------------------
*/

void LayerNet::learn ( TrainingSet *tptr , struct LearnParams *lptr )
{
   int i, itry, n_escape, n_retry, bad_count ;
   double err, prev_err, best_err, start_of_loop_error ;
   char msg[80] ;
   SingularValueDecomp *sptr ;
   LayerNet *worknet, *bestnet ;

   if (! exe) {   // Should NEVER happen, but good style to aid debugging
      ShowMessage( "Internal error in LayerNet::learn" ) ;
      return ;
      }

   n_escape = n_retry = 0 ;

/*
   Allocate scratch memory
*/

   MEMTEXT ( "LAYERNET::learn new worknet, bestnet" ) ;
   worknet = new LayerNet ( outmod , nin , nhid1 , nhid2 , nout , 0 , 0 ) ;
   bestnet = new LayerNet ( outmod , nin , nhid1 , nhid2 , nout , 0 , 1 ) ;

   if ((worknet == NULL)  ||  (! worknet->ok)
    || (bestnet == NULL)  ||  (! bestnet->ok)) {
      ShowMessage( "to learn" ) ;
      if (worknet != NULL)
         delete worknet ;
      if (bestnet != NULL)
         delete bestnet ;
      neterr = 1.0 ;
      return ;
      }

/*
   Find initial weight estimates via simulated annealing or genetics
   or simply regression if no hidden layers
*/

   if (lptr->init == 0)                             // NO INIT
      neterr = trial_error ( tptr ) ;

   if ((lptr->init == 1)  ||  (lptr->init == 2))    // ANNEAL
      anneal ( tptr , lptr , worknet , 1 ) ;

   else if (lptr->init == 3) {                      // GENETIC
      if (nhid1)
         gen_init ( tptr , lptr ) ;
      else {
         ShowMessage( "Genetic init pointless with no hidden layer" ) ;
         neterr = 1.0 ;
         goto FINISH ;
         }
      }

   else if (lptr->init == 4) {                      // REGRESSION
      if (nhid1) {
         ShowMessage( "REGRESS illegal if hidden layer.");
         neterr = 1.0 ;
         goto FINISH ;
         }

      MEMTEXT ( "LAYERNET: new SingularValueDecomp" ) ;
      sptr = new SingularValueDecomp ( tptr->ntrain , nin+1 , 1 ) ;
      if (! sptr->ok) {    // Indicates insufficient memory
         ShowMessage("for regression. Try ANNEAL NOREGRESS." ) ;
         neterr = 1.0 ;  // Flag failure to LayerNet::learn which called us
         delete sptr ;
         }
      neterr = regress ( tptr , sptr ) ;
      MEMTEXT ( "LAYERNET: delete SingularValueDecomp" ) ;
      delete sptr ;
      }

   if (lptr->init  &&  neterr > 0.999999) // Memory allocation failure
      goto FINISH ;

/*
   Initialization is done.  Learning loop is here.
   First, do conjugate gradient optimization, finding local minimum.
   Then anneal to break out of it.  If successful, loop back up to
   do conjugate gradient again.  Otherwise restart totally random.
*/

   copy_weights ( bestnet , this ) ;
   best_err = neterr ;
   bad_count = 0 ;           // Handles flat local mins

   for (itry=1 ; ; itry++) {

      sprintf ( msg , "Try %d  (best=%lf):", itry, 100.0 * best_err ) ;
//      ShowMessage( msg ) ;
      NeuralMainForm->MessageEdit->Text = msg;
      start_of_loop_error = neterr ;
      err = conjgrad ( tptr , 32767 , 1.e-8 , lptr->quit_err ) ;
      neterr = fabs ( err ) ; // err<0 if user pressed ESCape

      sprintf ( msg , "  Gradient err=%lf", 100.0 * neterr ) ;
//      ShowMessage( msg ) ;
      NeuralMainForm->MessageEdit->Text = msg;

      if (neterr < best_err) {   // Keep track of best
         copy_weights ( bestnet , this ) ;
         best_err = neterr ;
         }

      if (itry > 1000) break;

      if (err < lptr->quit_err) // err<0 if user pressed ESCape
         break ;

      i = itry * 97 + 101 ;   // Insure new seed for anneal
      if (i<0)
         i = -i ;
      slongrand ( (long) i ) ;

      prev_err = neterr ;  // So we can see if anneal helped
      anneal ( tptr , lptr , worknet , 0 ) ;

      sprintf ( msg , "  Anneal err=%lf", 100.0 * neterr ) ;
//      ShowMessage( msg ) ;

      if (neterr < best_err) {  // Keep track of best
         copy_weights ( bestnet , this ) ;
         best_err = neterr ;
         }

      if (best_err < lptr->quit_err)
         break ;

      if (neterr < prev_err) { // Did we break out of local min?
         if ((start_of_loop_error - neterr) < 1.e-3)
            ++bad_count ;  // Avoid many unprofitable iters
         else
            bad_count = 0 ;
         if (bad_count < 4) {
            ++n_escape ;          // For user interest only
            continue ;            // Escaped, so gradient learn again
            }
         }

      if (++n_retry > lptr->retries)
         break ;

//      ShowMessage( "  RESTART" ) ;
      zero_weights () ;  // Failed to break out, so retry random
      anneal ( tptr , lptr , worknet , 1 ) ;
      }

FINISH:
   copy_weights ( this , bestnet ) ;
   MEMTEXT ( "LAYERNET::learn delete worknet, bestnet" ) ;
   delete worknet ;
   delete bestnet ;
   sprintf ( msg , "%d successful escapes, %d retries", n_escape, n_retry ) ;
   ShowMessage( msg ) ;
   NeuralMainForm->MessageEdit->Text = msg;

   return ;
}


/*
--------------------------------------------------------------------------------

   wt_save - Save weights to disk (called from WT_SAVE.CPP)
   wt_restore - Restore weights from disk (called from WT_SAVE.CPP)

--------------------------------------------------------------------------------
*/

int LayerNet::wt_save ( FILE *fp )
{
   int n ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      fwrite ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      fwrite ( hid1_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nout * (nhid1+1) ;
      fwrite ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      fwrite ( hid1_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nhid2 * (nhid1+1) ;
      fwrite ( hid2_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nout * (nhid2+1) ;
      fwrite ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   if (ferror ( fp ))
      return 1 ;
   return 0 ;
}

void LayerNet::wt_restore ( FILE *fp )
{
   int n ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      fread ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      fread ( hid1_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nout * (nhid1+1) ;
      fread ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      fread ( hid1_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nhid2 * (nhid1+1) ;
      fread ( hid2_coefs , n * sizeof(double) , 1 , fp ) ;
      n = nout * (nhid2+1) ;
      fread ( out_coefs , n * sizeof(double) , 1 , fp ) ;
      }

   if (ferror ( fp ))
      ok = 0 ;
}

#include "OutPut.h"
extern unsigned int Character;

void LayerNet::anneal (
   TrainingSet *tptr ,        // Training set to use
   struct LearnParams *lptr , // User's general learning parameters
   LayerNet *bestnet ,        // Work area used to keep best network
   int init                   // Use zero suffix (initialization) anneal parms?
   )
{
   int ntemps, niters, setback, reg, nvars, key, user_quit ;
   int iter, improved, ever_improved, itemp ;
   long seed, bestseed ;
   char msg[80] ;
   double tempmult, temp, fval, bestfval, starttemp, stoptemp, fquit ;
   SingularValueDecomp *sptr ;
   struct AnnealParams *aptr ; // User's annealing parameters
                             
   aptr = lptr->ap ;

/*
   The parameter 'init' is nonzero if we are initializing
   weights for learning.  If zero we are attempting to break
   out of a local minimum.  The main effect  of this parameter
   is whether or not we use the zero suffix variables in the
   anneal parameters.
   A second effect is that regression is used only for
   initialization, not for escape.
*/

   if (init) {
      ntemps = aptr->temps0 ;
      niters = aptr->iters0 ;
      setback = aptr->setback0 ;
      starttemp = aptr->start0 ;
      stoptemp = aptr->stop0 ;
      }
   else {
      ntemps = aptr->temps ;
      niters = aptr->iters ;
      setback = aptr->setback ;
      starttemp = aptr->start ;
      stoptemp = aptr->stop ;
      }

/*
   Initialize other local parameters.  Note that there is no sense using
   regression if there are no hidden layers.  Also, regression is almost
   always counterproductive for local minimum escape.
*/

   fquit = lptr->quit_err ;
   reg = init  &&  nhid1  &&  (lptr->init != 1) ;

/*
   Allocate the singular value decomposition object for REGRESS.
   Also allocate a work area for REGRESS to preserve matrix.
*/

   if (reg) {
      if (nhid1 == 0)         // No hidden layer
         nvars = nin + 1 ;
      else if (nhid2 == 0)    // One hidden layer
         nvars = nhid1 + 1 ;
      else                    // Two hidden layers
         nvars = nhid2 + 1 ;

      MEMTEXT ( "ANNEAL: new SingularValueDecomp" ) ;
      sptr = new SingularValueDecomp ( tptr->ntrain , nvars , 1 ) ;

      if ((sptr == NULL)  || ! sptr->ok) {
         FrmOutPut->RichOutPut->Lines->Add(
            "for annealing with regression. Try ANNEAL NOREGRESS.");
         if (sptr != NULL)
            delete sptr ;
         neterr = 1.0 ; // Flag failure to LayerNet::learn which called us
         return ;
         }
      }

/*
   For every temperature, the center around which we will perturb is the
   best point so far.  This is kept in 'bestnet', so initialize it to the
   user's starting estimate.   Also, initialize 'bestfval', the best
   function value so far, to be the function value at that starting point.
*/

   copy_weights ( bestnet , this ) ; // Current weights are best so far
   if (init)
      bestfval = 1.e30 ;  // Force it to accept SOMETHING
   else 
      bestfval = trial_error ( tptr ) ;

/*
   This is the temperature reduction loop and the iteration within
   temperature loop.  We use a slick trick to keep track of the
   best point at a given temperature.  We certainly don't want to
   replace the best every time an improvement is had, as then we
   would be moving our center about, compromising the global nature
   of the algorithm.  We could, of course, have a second work area
   in which we save the 'best so far for this temperature' point.
   But if there are a lot of variables, the usual case, this wastes
   memory.  What we do is to save the seed of the random number
   generator which created the improvement.  Then later, when we
   need to retrieve the best, simply set the random seed and
   regenerate it.  This technique also saves a lot of copying time
   if many improvements are made for a single temperature.
*/

   temp = starttemp ;
   tempmult = exp( log( stoptemp / starttemp ) / (ntemps-1)) ;
   ever_improved = 0 ;                       // Flags if improved at all
   user_quit = 0 ;                           // Flags user pressed ESCape

   for (itemp=0 ; itemp<ntemps ; itemp++) {  // Temp reduction loop

      improved = 0 ;                         // Flags if this temp improved

      if (init) {
         sprintf ( msg , "\nANNEAL temp=%.2lf ", temp ) ;
//         ShowMessage( msg ) ;
         }

      for (iter=0 ; iter<niters ; iter++) {  // Iters per temp loop

         seed = longrand () ;                // Get a random seed
         slongrand ( seed ) ;                // Brute force set it
         perturb (bestnet, this, temp, reg) ;// Randomly perturb about best

         if (reg)                            // If using regression, estimate
            fval = regress ( tptr , sptr ) ; // out weights now
         else                                // Otherwise just evaluate
            fval = trial_error ( tptr ) ;

         if (fval < bestfval) {              // If this iteration improved
            bestfval = fval ;                // then update the best so far
            bestseed = seed ;                // and save seed to recreate it
            ever_improved = improved = 1 ;   // Flag that we improved

            if (bestfval <= fquit)           // If we reached the user's
               break ;                       // limit, we can quit

            iter -= setback ;                // It often pays to keep going
            if (iter < 0)                    // at this temperature if we
               iter = 0 ;                    // are still improving
            }
         }                                   // Loop: for all iters at a temp

      if (improved) {                        // If this temp saw improvement
         slongrand ( bestseed ) ;            // set seed to what caused it
         perturb (bestnet, this, temp, reg) ;// and recreate that point
         copy_weights ( bestnet , this ) ;   // which will become next center
         slongrand ( bestseed / 2 + 999 ) ;  // Jog seed away from best

         if (init) {
            sprintf ( msg , " ANNEAL: err=%.3lf%% ", 100.0 * bestfval ) ;
            NeuralMainForm->MessageEdit->Text = msg;
//            ShowMessage( msg ) ;
            }
         }

      if (bestfval <= fquit)  // If we reached the user's
         break ;              // limit, we can quit
//      ShowMessage("We are in the anneal.cpp procedure.");
//      Application->OnMessage = MainForm->AppMessage;

      if (Character == 27)  {
         user_quit = 1;
         ShowMessage("Escape Key Pressed in anneal.cpp");
         Character = 0;
         break;
      }
/*
      if (kbhit()) {          // Was a key pressed?
         key = getchar() ;     // Read it if so
         while (kbhit())      // Flush key buffer in case function key
            getchar () ;        // or key was held down
         if (key == 27) {     // ESCape
            user_quit = 1 ;   // Flags user that ESCape was pressed
            break ;
            }
         }
*/
      if (user_quit)
         break ;

      temp *= tempmult ;      // Reduce temp for next pass
      }                       // through this temperature loop


/*
   The trials left this weight set and neterr in random condition.
   Make them equal to the best, which will be the original
   if we never improved.

   Also, if we improved and are using regression, recall that bestnet
   only contains the best hidden weights, as we did not bother to run
   regress when we updated bestnet.  Do that now before returning.
*/

   copy_weights ( this , bestnet ) ; // Return best weights in this net
   neterr = bestfval ;               // Trials destroyed weights, err

   if (ever_improved  &&  reg)
      neterr = regress ( tptr , sptr ) ; // regressed output weights

   if (reg) {
      MEMTEXT ( "ANNEAL: delete SingularValueDecomp" ) ;
      delete sptr ;
      }
}


/*
--------------------------------------------------------------------------------

   Local routine to perturb coefficients

--------------------------------------------------------------------------------
*/

void LayerNet::perturb ( LayerNet *cent , LayerNet *perturbed , double temp ,
                         int reg )
{
   int n ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      shake ( n , cent->out_coefs , perturbed->out_coefs , temp ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      shake ( n , cent->hid1_coefs , perturbed->hid1_coefs , temp ) ;
      if (! reg) {
         n = nout * (nhid1+1) ;
         shake ( n , cent->out_coefs , perturbed->out_coefs , temp ) ;
         }
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      shake ( n , cent->hid1_coefs , perturbed->hid1_coefs , temp ) ;
      n = nhid2 * (nhid1+1) ;
      shake ( n , cent->hid2_coefs , perturbed->hid2_coefs , temp ) ;
      if (! reg) {
         n = nout * (nhid2+1) ;
         shake ( n , cent->out_coefs , perturbed->out_coefs , temp ) ;
         }
      }
}


double LayerNet::conjgrad (
   TrainingSet *tptr , // Training set to use
   int maxits ,        // Maximum iterations allowed
   double reltol ,     // Relative error change tolerance
   double errtol       // Quit if error drops this low
   )
{
   int i, n, iter, key, retry, max_retry ;
   double gam, *g, *h, *outdelta, *hid2delta, *grad, *base ;
   double error ;
   double prev_err ;
                     
   max_retry = 5 ;

/*
   Allocate work memory
*/

   MEMTEXT ( "CONJGRAD work" ) ;
   if (nhid2) {
      hid2delta = (double *) MALLOC ( nhid2 * sizeof(double) ) ;
      if (hid2delta == NULL)
         return -2.0 ;
      }
   else
      hid2delta = NULL ;

   outdelta = (double *) MALLOC ( nout * sizeof(double) ) ;

   if (nhid1 == 0)               // No hidden layer
      n = nout * (nin+1) ;
   else if (nhid2 == 0)          // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
   else                          // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;

   grad = (double *) MALLOC ( n * sizeof(double) ) ;
   base = (double *) MALLOC ( n * sizeof(double) ) ;
   g = (double *) MALLOC ( n * sizeof(double) ) ;
   h = (double *) MALLOC ( n * sizeof(double) ) ;

   if ((outdelta == NULL) || (grad == NULL) ||
       (base == NULL) || (g == NULL) || (h == NULL)) {
      if (hid2delta != NULL)
         FREE ( hid2delta ) ;
      if (outdelta != NULL)
         FREE ( outdelta ) ;
      if (grad != NULL)
         FREE ( grad ) ;
      if (base != NULL)
         FREE ( base ) ;
      if (g != NULL)
         FREE ( g ) ;
      if (h != NULL)
         FREE ( h ) ;
      return -2.0 ;   // Flags error
      }

   prev_err = 1.e30 ;
   error = find_grad ( tptr , hid2delta , outdelta , grad ) ;

   memcpy ( g , grad , n * sizeof(double) ) ;
   memcpy ( h , grad , n * sizeof(double) ) ;

/*
   Main iteration loop is here
*/
   for (iter=0 ; iter<maxits ; iter++) {  // Each iter is an epoch

/*
   Check current error against user's max.  Abort if user pressed ESCape
*/

      if (error <= errtol)   // If our error is within user's limit
         break ;             // then we are done!

      if (error <= reltol)   // Generally not necessary: reltol<errtol in
         break ;             // practice, but help silly users

//       Application->OnMessage = MainForm->AppMessage;

      if (Character == 27)  {
         error = -error;
         ShowMessage("Escape Key Pressed in conjgrad.cpp");
         Character = 0;
         break;
      }

/*
      if (kbhit()) {         // Was a key pressed?
         key = getch () ;    // Read it if so
         while (kbhit())     // Flush key buffer in case function key
            getch () ;       // or key was held down
         if (key == 27) {    // ESCape
            error = -error ; // Flags user that ESCape was pressed
            break ;
            }
         }
*/
      prev_err = error ;
      error = direcmin ( tptr , error , 10 , 1.e-10 ,
                         0.5 , base , grad ) ;
      if (error < 0.0)  // Indicates user pressed ESCape
         goto CGFINISH ;

      if ((2.0 * (prev_err - error)) <=       // If this direc gave poor result
          (reltol * (prev_err + error + 1.e-10))) { // will use random direc
         prev_err = error ;                   // But first exhaust grad
         error = find_grad ( tptr , hid2delta , outdelta , grad ) ;
         error = direcmin ( tptr , error , 15 , 1.e-10 ,
                            1.e-3 , base , grad ) ;
         for (retry=0 ; retry<max_retry ; retry++) {
            for (i=0 ; i<n ; i++)
               grad[i] = (double) (rand() - RANDMAX/2) / (RANDMAX * 10.0) ;
            error = direcmin ( tptr , error , 10 , 1.e-10 ,
                               1.e-2 , base , grad ) ;
            if (error < 0.0)  // Indicates user pressed ESCape
               goto CGFINISH ;
            if (retry < max_retry/2)
               continue ;
            if ((2.0 * (prev_err - error)) >
                (reltol * (prev_err + error + 1.e-10)))
               break ;   // Get out of retry loop if we improved enough
            } // For retry
         if (retry == max_retry)   // If we exhausted all tries
            break ;                // probably hopeless
         memcpy ( g , grad , n * sizeof(double) ) ;
         memcpy ( h , grad , n * sizeof(double) ) ;
         } // If this dir gave poor result

      prev_err = error ;

/*
   Setup for next iteration
*/

      error = find_grad ( tptr , hid2delta , outdelta , grad ) ;
      gam = gamma ( g , grad ) ;
      if (gam < 0.0)
         gam = 0.0 ;
      if (gam > 1.0)
         gam = 1.0 ;

      find_new_dir ( gam , g , h , grad ) ;
      }  // This is the end of the main iteration loop

/*
   Free work memory
*/

CGFINISH:
   MEMTEXT ( "CONJGRAD work" ) ;
   if (hid2delta != NULL)
      FREE ( hid2delta ) ;
   FREE ( outdelta ) ;
   FREE ( grad ) ;
   FREE ( base ) ;
   FREE ( g ) ;
   FREE ( h ) ;
   return error ;
}

/*
--------------------------------------------------------------------------------

   Local routine to compute gradient for a trial epoch

--------------------------------------------------------------------------------
*/

double LayerNet::find_grad (
   TrainingSet *tptr ,
   double *hid2delta ,
   double *outdelta ,
   double *grad
   )
{
   int i, j, size, tset, tclass, n, nprev, nnext ;
   double error, *dptr, diff, delta, *hid1grad, *hid2grad, *outgrad ;
   double *outprev, *prevact, *nextcoefs, *nextdelta, *gradptr ;

/*
   Compute size of each training sample
*/

   if (outmod == OUTMOD_CLASSIFY)
      size = nin + 1 ;
   else if (outmod == OUTMOD_AUTO)
      size = nin ;
   else if (outmod == OUTMOD_GENERAL)
      size = nin + nout ;

/*
   Compute length of grad vector and gradient positions in it.
   Also point to layer previous to output and its size.
   Ditto for layer after hid1.
*/

   if (nhid1 == 0) {      // No hidden layer
      n = nout * (nin+1) ;
      outgrad = grad ;
      nprev = nin ;
      }
   else if (nhid2 == 0) { // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
      hid1grad = grad ;
      outgrad = grad + nhid1 * (nin+1) ;
      outprev = hid1 ;
      nprev = nhid1 ;
      nnext = nout ;
      nextcoefs = out_coefs ;
      nextdelta = outdelta ;
      }
   else {                 // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;
      hid1grad = grad ;
      hid2grad = grad + nhid1 * (nin+1) ;
      outgrad = hid2grad + nhid2 * (nhid1+1) ;
      outprev = hid2 ;
      nprev = nhid2 ;
      nnext = nhid2 ;
      nextcoefs = hid2_coefs ;
      nextdelta = hid2delta ;
      }

   for (i=0 ; i<n ; i++)  // Zero gradient for summing
      grad[i] = 0.0 ;

   error = 0.0 ;  // Will cumulate total error here
   for (tset=0 ; tset<tptr->ntrain ; tset++) { // Do all samples

      dptr = tptr->data + size * tset ;     // Point to this sample
      trial ( dptr ) ;                      // Evaluate network for it

      if (outmod == OUTMOD_AUTO) {          // If this is AUTOASSOCIATIVE
         for (i=0 ; i<nout ; i++) {         // then the expected outputs
            diff = *dptr++ - out[i] ;       // are just the inputs
            error += diff * diff ;
            outdelta[i] = diff * actderiv ( out[i] ) ;
            }
         }

      else if (outmod == OUTMOD_CLASSIFY) {  // If this is Classification
         tclass = (int) dptr[nin] - 1 ;     // class is stored after inputs
         for (i=0 ; i<nout ; i++) {         // Recall that train added a
            if (tclass == i)                // fraction so that the above
               diff = NEURON_ON - out[i] ;  // truncation to get tclass is
            else                            // always safe in any radix
               diff = NEURON_OFF - out[i] ;
            error += diff * diff ;
            outdelta[i] = diff * actderiv ( out[i] ) ;
            }
         }

      else if (outmod == OUTMOD_GENERAL) {  // If this is GENERAL output
         dptr += nin ;                      // outputs stored after inputs
         for (i=0 ; i<nout ; i++) {
            diff = *dptr++ - out[i] ;
            error += diff * diff ;
            outdelta[i] = diff * actderiv ( out[i] ) ;
            }
         }

/*
   Cumulate output gradient
*/

      if (nhid1 == 0)         // No hidden layer
         prevact = tptr->data + size * tset ;
      else
         prevact = outprev ;  // Point to previous layer
      gradptr = outgrad ;
      for (i=0 ; i<nout ; i++) {
         delta = outdelta[i] ;
         for (j=0 ; j<nprev ; j++)
            *gradptr++ += delta * prevact[j] ;
         *gradptr++ += delta ;   // Bias activation is always 1
         }

/*
   Cumulate hid2 gradient (if it exists)
*/
   
      if (nhid2) {
         gradptr = hid2grad ;
         for (i=0 ; i<nhid2 ; i++) {
            delta = 0.0 ;
            for (j=0 ; j<nout ; j++)
               delta += outdelta[j] * out_coefs[j*(nhid2+1)+i] ;
            delta *= actderiv ( hid2[i] ) ;
            hid2delta[i] = delta ;
            for (j=0 ; j<nhid1 ; j++)
               *gradptr++ += delta * hid1[j] ;
            *gradptr++ += delta ;   // Bias activation is always 1
            }
         }

/*
   Cumulate hid1 gradient (if it exists)
*/
   
      if (nhid1) {
         prevact = tptr->data + size * tset ;
         gradptr = hid1grad ;
         for (i=0 ; i<nhid1 ; i++) {
            delta = 0.0 ;
            for (j=0 ; j<nnext ; j++)
               delta += nextdelta[j] * nextcoefs[j*(nhid1+1)+i] ;
            delta *= actderiv ( hid1[i] ) ;
            for (j=0 ; j<nin ; j++)
               *gradptr++ += delta * prevact[j] ;
            *gradptr++ += delta ;   // Bias activation is always 1
            }
         }

      } // for all tsets
   
   return error / ((double) tptr->ntrain * (double) nout) ;
}

/*
--------------------------------------------------------------------------------

   Local routine to find gamma

--------------------------------------------------------------------------------
*/

double LayerNet::gamma ( double *g , double *grad )
{
   int i, n ;
   double denom, numer ;

   if (nhid1 == 0)        // No hidden layer
      n = nout * (nin+1) ;
   else if (nhid2 == 0)   // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
   else                   // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;

   numer = denom = 0. ;

   for (i=0 ; i<n ; i++) {
      denom += g[i] * g[i] ;
      numer += (grad[i] - g[i]) * grad[i] ;  // Grad is neg gradient
      }

   if (denom == 0.)   // Should never happen (means gradient is zero!)
      return 0. ;
   else
      return numer / denom ;
}

/*
--------------------------------------------------------------------------------

   Local routine to find correction for next iteration

--------------------------------------------------------------------------------
*/

void LayerNet::find_new_dir ( double gam , double *g ,
                              double *h , double *grad )
{
   int i, n ;

   if (nhid1 == 0)        // No hidden layer
      n = nout * (nin+1) ;
   else if (nhid2 == 0)   // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
   else                   // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;

   for (i=0 ; i<n ; i++) {
      g[i] = grad[i] ;
      grad[i] = h[i] = g[i] + gam * h[i] ;
      }
}


/*
--------------------------------------------------------------------------------

   Local routine for debugging

--------------------------------------------------------------------------------
*/

void LayerNet::check_grad ( TrainingSet *tptr , double *grad )
{
   int i, j, n ;
   double f0, f1, deriv, dot, len1, len2 ;

   dot = len1 = len2 = 0.0 ;
   f0 = trial_error ( tptr ) ;

   for (i=0 ; i<nhid1 ; i++) {
      for (j=0 ; j<=nin ; j++) {
         hid1_coefs[i*(nin+1)+j] += .001 ;
         f1 = trial_error ( tptr ) ;
         hid1_coefs[i*(nin+1)+j] -= .001 ;
         deriv = 10000.0 * (f0 - f1) ;
         len1 += *grad * *grad ;
         len2 += deriv * deriv ;
         dot += *grad++ * deriv ;
         }
      }

   for (i=0 ; i<nhid2 ; i++) {
      for (j=0 ; j<=nhid1 ; j++) {
         hid2_coefs[i*(nhid1+1)+j] += .001 ;
         f1 = trial_error ( tptr ) ;
         hid2_coefs[i*(nhid1+1)+j] -= .001 ;
         deriv = 10000.0 * (f0 - f1) ;
         len1 += *grad * *grad ;
         len2 += deriv * deriv ;
         dot += *grad++ * deriv ;
         }
      }

   if (nhid1 == 0)        // No hidden layer
      n = nin ;
   else if (nhid2 == 0)   // One hidden layer
      n = nhid1 ;
   else                   // Two hidden layers
      n = nhid2 ;
   for (i=0 ; i<nout ; i++) {
      for (j=0 ; j<=n ; j++) {
         out_coefs[i*(n+1)+j] += .001 ;
         f1 = trial_error ( tptr ) ;
         out_coefs[i*(n+1)+j] -= .001 ;
         deriv = 10000.0 * (f0 - f1) ;
         len1 += *grad * *grad ;
         len2 += deriv * deriv ;
         dot += *grad++ * deriv ;
         }
      }
}


double LayerNet::direcmin (
   TrainingSet *tptr , // Training set to use
   double start_err ,  // Error (function value) at starting coefficients
   int itmax ,         // Upper limit on number of iterations allowed
   double eps ,        // Small, but greater than machine precision
   double tol ,        // Brent's tolerance (>= sqrt machine precision)
   double *base ,      // Work area (stepping out point)
   double *direc )     // Work area (stepping out direction)
{
   int key, user_quit, iter ;
   double step, x1, x2, x3, t1, t2, numer, denom, max_step ;
   double xlow, xhigh, xbest, testdist ;
   double current_err, err, previous_err, step_err ;
   double prevdist, frecent, fthirdbest, fsecbest, fbest ;
   double tol1, tol2, xrecent, xthirdbest, xsecbest, xmid;
   double  first_step = 2.5 ; // Heuristically found best

   user_quit = 0 ;
/*
   Take one step out in the gradient direction.  First preserve
   original weights for use as departure point parameterized by STEP.
*/

   preserve ( base ) ;   // Establishes a base for stepping out
   step_out ( first_step , direc , base ) ;
   err = trial_error ( tptr ) ;

/*
   If it increased, we had numerical problems computing the direction or
   the direction itself is too large a step.
   Negate the direction and use -1, 0 and 1.618 as first three steps.
   Otherwise use 0, 1 and 2.618 as first three steps.
*/

   if (err > start_err) {
      negate_dir ( direc ) ;
      x1 = -first_step ;
      x2 = 0. ;
      previous_err = err ;
      current_err = start_err ;
      }
   else {
      x1 = 0. ;
      x2 = first_step ;
      previous_err = start_err ;
      current_err = err ;
      }

/*
   At this point we have taken a single step and the function decreased.
   Take one more step in the golden ratio.
   Also keep errors lined up as 'previous_err', 'current_err' and 'err'.
   The corresponding abscissae will be x1, x2 and x3.
*/
//      Application->OnMessage = MainForm->AppMessage;
      if (Character == 27)  {
         ShowMessage("Escape Key Pressed in direcmin.cpp");
         Character = 0;
         return (-err);
      }

/*
   if (kbhit()) {          // Was a key pressed?
      key = getch () ;     // Read it if so
      while (kbhit())      // Flush key buffer in case function key
         getch () ;        // or key was held down
      if (key == 27)       // ESCape
         return (- err) ;
      }
*/
   x3 = x2 + 1.618034 * first_step ;
   step_out ( x3 , direc , base ) ;
   err = trial_error ( tptr ) ;

/*
   We now have three points x1, x2 and x3 with corresponding errors
   of 'previous_err', 'current_err' and 'err'.
   Endlessly loop until we bracket the minimum with the outer two.
*/
//      Application->OnMessage = MainForm->AppMessage;

   while (err < current_err) {   // As long as we are descending...
      if (Character == 27)  {
         ShowMessage("Escape Key Pressed in direcmin.cpp");
         user_quit = 1;
         Character = 0;
         break;
      }

/*
      if (kbhit()) {          // Was a key pressed?
         key = getch () ;     // Read it if so
         while (kbhit())      // Flush key buffer in case function key
            getch () ;        // or key was held down
         if (key == 27) {     // ESCape
            user_quit = 1 ;
            break ;
            }
         }
*/
/*
   Try a parabolic fit to estimate the location of the minimum.
*/

      t1 = (x2 - x1) * (current_err - err) ;
      t2 = (x2 - x3) * (current_err - previous_err) ;
      denom = 2. * ( t2 - t1 ) ;
      if (fabs ( denom ) < eps) {
         if (denom > 0.)
            denom = eps ;
         else
            denom = -eps ;
         }
      step = x2 + ((x2 - x1) * t1  -  (x2 - x3) * t2) / denom ;//Here if perfect
      max_step = x2 + 200. * (x3 - x2) ; // Don't jump too far

      if ((x2 - step) * (step - x3)  >  0.) {         // It's between x2 and x3
         step_out ( step , direc , base ) ;
         step_err = trial_error ( tptr ) ;

         if (step_err < err) {   // It worked!  We found min between b and c.

            x1 = x2 ;
            x2 = step ;
            previous_err = current_err ;
            current_err = step_err ;
            goto BOUNDED ;
            }
         else if (step_err > current_err) { // Slight miscalc.  Min at x2.
            x3 = step ;
            err = step_err ;
            goto BOUNDED ;
            }
         else {             // Parabolic fit was total waste.  Use default.
            step = x3 + 1.618034 * (x3 - x2) ;
            step_out ( step , direc , base ) ;
            step_err = trial_error ( tptr ) ;
            }
         }

      else if ((x3 - step) * (step - max_step) > 0.0) { // Between x3 and lim
         step_out ( step , direc , base ) ;
         step_err = trial_error ( tptr ) ;
         if (step_err < err) {  // Decreased, so advance by golden ratio
            x2 = x3 ;
            x3 = step ;
            step = x3 + 1.618034 * (x3 - x2) ;
            current_err = err ;
            err = step_err ;
            step_out ( step , direc , base ) ;
            step_err = trial_error ( tptr ) ;
            }
         }

      else if ((step - max_step) * (max_step - x3)  >= 0.) {  // Beyond limit
         step = max_step ;
         step_out ( step , direc , base ) ;
         step_err = trial_error ( tptr ) ;
         if (step_err < err) {  // Decreased, so advance by golden ratio
            x2 = x3 ;
            x3 = step ;
            step = x3 + 1.618034 * (x3 - x2) ;
            current_err = err ;
            err = step_err ;
            step_out ( step , direc , base ) ;
            step_err = trial_error ( tptr ) ;
            }
         }

      else {  // Wild!  Reject parabolic and use golden ratio.
         step = x3 + 1.618034 * (x3 - x2) ;
         step_out ( step , direc , base ) ;
         step_err = trial_error ( tptr ) ;
         }

/*
   Shift three points and continue endless loop
*/

      x1 = x2 ;
      x2 = x3 ;
      x3 = step ;
      previous_err = current_err ;
      current_err = err ;
      err = step_err ;
      } // Endless stepping out loop

BOUNDED:
   step_out ( x2 , direc , base);//Leave coefs at min

   if (x1 > x3) {  // We may have switched direction at start.
      t1 = x1 ;    // Brent's method which follows assumes ordered parameter.
      x1 = x3 ;
      x3 = t1 ;
      }

   if (user_quit) {
      update_dir ( x2 , direc ) ;// Make it be the actual dist moved
      return -current_err ;
      }

/*
--------------------------------------------------------------------------------

   At this point we have bounded the minimum between x1 and x3.

   Go to the refinement stage.  We use Brent's algorithm.

--------------------------------------------------------------------------------
*/

/*
  Initialize prevdist, the distance moved on the previous step, to 0 so that
  the 'if (fabs ( prevdist )  >  tol1)' encountered on the first iteration
  below will fail, forcing a golden section the first time.  Also initialize
  step to 0 to avoid a zealous compiler from pointing out that it was
  referenced before being set.
*/

   prevdist = step = 0.0 ;

/*
   We always keep the minimum bracketed between xlow and xhigh.
   xbest has the min function so far (or latest if tie).
   xsecbest and xthirdbest are the second and third best.
*/

   xbest = xsecbest = xthirdbest = x2 ;
   xlow = x1 ;
   xhigh = x3 ;

   fbest = fsecbest = fthirdbest = current_err ;


/*
   Main loop.  For safety we impose a limit on iterations.
*/

   for (iter=0 ; iter<itmax ; iter++) {

      xmid = 0.5 * (xlow + xhigh) ;
      tol1 = tol * (fabs ( xbest ) + eps) ;
      tol2 = 2. * tol1 ;
//      Application->OnMessage = MainForm->AppMessage;
      if (Character == 27)  {
         ShowMessage("Escape Key Pressed in direcmin.cpp");
         user_quit = 1;
         Character = 0;
         break;
      }

/*
      if (kbhit()) {          // Was a key pressed?
         key = getch () ;     // Read it if so
         while (kbhit())      // Flush key buffer in case function key
            getch () ;        // or key was held down
         if (key == 27) {     // ESCape
            user_quit = 1 ;
            break ;
            }
         }
*/
/*
   The following convergence test simultaneously makes sure xhigh and
   xlow are close relative to tol2, and that xbest is near the midpoint.
*/
      if (fabs ( xbest - xmid )  <=  (tol2 - 0.5 * (xhigh - xlow)))
         break ;

      if (fabs ( prevdist )  >  tol1) {  // If we moved far enough try parabolic fit
         t1 = (xbest - xsecbest) * (fbest - fthirdbest) ; // Temps for the
         t2 = (xbest - xthirdbest) * (fbest - fsecbest) ; // parabolic estimate
         numer = (xbest - xthirdbest) * t2  -  (xbest - xsecbest) * t1 ;
         denom = 2. * (t1 - t2) ;  // Estimate will be numer / denom
         testdist = prevdist ;     // Will soon verify interval is shrinking
         prevdist = step ;         // Save for next iteration
         if (denom != 0.0)         // Avoid dividing by zero
            step = numer / denom ; // This is the parabolic estimate to min
         else
            step = 1.e30 ;         // Assures failure of next test

         if ((fabs ( step ) < fabs ( 0.5 * testdist ))// If shrinking
          && (step + xbest > xlow)             // and within known bounds
          && (step + xbest < xhigh)) {         // then we can use the
            xrecent = xbest + step ;           // parabolic estimate
            if ((xrecent - xlow  <  tol2)  ||  // If we are very close
                (xhigh - xrecent <  tol2)) {   // to known bounds
               if (xbest < xmid)               // then stabilize
                  step = tol1 ;
               else
                  step = -tol1 ;
               }
            }
         else {  // Parabolic estimate poor, so use golden section
            prevdist = (xbest >= xmid)  ?  xlow - xbest  :  xhigh - xbest ;          // Poor so use
            step = .3819660 * prevdist ;
            }
         }
      else { // prevdist did not exceed tol1: we did not move far enough
             // to justify a parabolic fit.  Use golden section.
         prevdist = (xbest >= xmid)  ?  xlow - xbest  :  xhigh - xbest ;
         step = .3819660 * prevdist ;
         }

      if (fabs (step)  >=  tol1)     // In order to numerically justify
         xrecent = xbest + step ;    // another trial we must move a
      else {                         // decent distance.
         if (step > 0.)
            xrecent = xbest + tol1 ;
         else
            xrecent = xbest - tol1 ;
         }

/*
   At long last we have a trial point 'xrecent'.  Evaluate the function.
*/

      step_out ( xrecent , direc , base ) ;
      frecent = trial_error ( tptr ) ;

      if (frecent <= fbest) {    // If we improved...
         if (xrecent >= xbest)   // Shrink the (xlow,xhigh) interval by
            xlow = xbest ;       // replacing the appropriate endpoint
         else
            xhigh = xbest ;
         xthirdbest = xsecbest ; // Update x and f values for best,
         xsecbest = xbest ;      // second and third best
         xbest = xrecent ;
         fthirdbest = fsecbest ;
         fsecbest = fbest ;
         fbest = frecent ;
         }

      else {                  // We did not improve
         if (xrecent < xbest) // Shrink the (xlow,xhigh) interval by
            xlow = xrecent ;  // replacing the appropriate endpoint
         else
            xhigh = xrecent ;

         if ((frecent <= fsecbest)   // If we at least beat the second best
          || (xsecbest == xbest)) {  // or we had a duplication
            xthirdbest = xsecbest ;  // we can update the second and third
            xsecbest = xrecent ;     // best, though not the best.
            fthirdbest = fsecbest ;  // Recall that we started iters with
            fsecbest = frecent ;     // best, sec and third all equal.
            }
         else if ((frecent <= fthirdbest) // Oh well.  Maybe at least we can
           || (xthirdbest == xbest)       // beat the third best or rid
           || (xthirdbest == xsecbest)) { // ourselves of a duplication
            xthirdbest = xrecent ;        // (which is how we start the
            fthirdbest = frecent ;        // iterations)
            }
         }
      }

   step_out ( xbest , direc , base );//Leave coefs at min
   update_dir ( xbest , direc ) ;// Make it be the actual distance moved
   if (user_quit)
      return -fbest ;
   else
      return fbest ;
}


/*
--------------------------------------------------------------------------------

   Local routine to preserve coefs in 'base'

--------------------------------------------------------------------------------
*/

void LayerNet::preserve ( double *base )
{
   int n ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      memcpy ( base , out_coefs , n * sizeof(double) ) ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      memcpy ( base , hid1_coefs , n * sizeof(double) ) ;
      base += n ;
      n = nout * (nhid1+1) ;
      memcpy ( base , out_coefs , n * sizeof(double) ) ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      memcpy ( base , hid1_coefs , n * sizeof(double) ) ;
      base += n ;
      n = nhid2 * (nhid1+1) ;
      memcpy ( base , hid2_coefs , n * sizeof(double) ) ;
      base += n ;
      n = nout * (nhid2+1) ;
      memcpy ( base , out_coefs , n * sizeof(double) ) ;
      }
}


/*
--------------------------------------------------------------------------------

   Local routine to step out from base

--------------------------------------------------------------------------------
*/

void LayerNet::step_out ( double step , double *direc , double *base )
{
   int i, n ;

   if (nhid1 == 0) {                // No hidden layer
      n = nout * (nin+1) ;
      for (i=0 ; i<n ; i++)
         out_coefs[i] = *(base++) + *(direc++) * step ;
      }

   else if (nhid2 == 0) {           // One hidden layer
      n = nhid1 * (nin+1) ;
      for (i=0 ; i<n ; i++)
         hid1_coefs[i] = *(base++) + *(direc++) * step ;
      n = nout * (nhid1+1) ;
      for (i=0 ; i<n ; i++)
         out_coefs[i] = *(base++) + *(direc++) * step ;
      }

   else {                           // Two hidden layers
      n = nhid1 * (nin+1) ;
      for (i=0 ; i<n ; i++)
         hid1_coefs[i] = *(base++) + *(direc++) * step ;
      n = nhid2 * (nhid1+1) ;
      for (i=0 ; i<n ; i++)
         hid2_coefs[i] = *(base++) + *(direc++) * step ;
      n = nout * (nhid2+1) ;
      for (i=0 ; i<n ; i++)
         out_coefs[i] = *(base++) + *(direc++) * step ;
      }
}

/*
--------------------------------------------------------------------------------

   Local routine to make 'dir' be the actual distance moved

--------------------------------------------------------------------------------
*/

void LayerNet::update_dir ( double step , double *direc )
{
   int n ;

  if (nhid1 == 0)               // No hidden layer
      n = nout * (nin+1) ;
   else if (nhid2 == 0)          // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
   else                          // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;

   while (n--) {
      *direc *= step ;
      ++direc ;
      }
}

/*
--------------------------------------------------------------------------------

   Local routine to negate 'dir'

--------------------------------------------------------------------------------
*/

void LayerNet::negate_dir ( double *direc )
{
   int n ;

  if (nhid1 == 0)               // No hidden layer
      n = nout * (nin+1) ;
   else if (nhid2 == 0)          // One hidden layer
      n = nhid1 * (nin+1) + nout * (nhid1+1) ;
   else                          // Two hidden layers
      n = nhid1 * (nin+1) + nhid2 * (nhid1+1) + nout * (nhid2+1) ;

   while (n--) {
      *direc = -*direc ;
      ++direc ;
      }
}

double LayerNet::regress (
   TrainingSet *tptr ,       // Training set used for regression input
   SingularValueDecomp *sptr // Work areas and needed functions
   )

{
   int i, out, tset, size, nvars ;
   double *aptr, *bptr, *dptr, err, temp, diff ;


/*
   Compute the size of each training sample in tptr->data and the number
   of independent variables (columns of matrix)
*/

   if (outmod == OUTMOD_CLASSIFY)
      size = nin + 1 ;
   else if (outmod == OUTMOD_AUTO)
      size = nin ;
   else if (outmod == OUTMOD_GENERAL)
      size = nin + nout ;

   if (nhid1 == 0)         // No hidden layer
      nvars = nin + 1 ;
   else if (nhid2 == 0)    // One hidden layer
      nvars = nhid1 + 1 ;
   else                    // Two hidden layers
      nvars = nhid2 + 1 ;

/*
   Pass through training set, building matrix, then find its singular value
   decomposition.  We keep a copy of it so we can compute the error later.
*/

   aptr = sptr->a ;                     // Will build matrix here

   for (tset=0 ; tset<tptr->ntrain ; tset++) { // Do all training samples

      dptr = tptr->data + size * tset ; // Point to this sample

      if (nhid1 == 0) {                 // No hidden layer
         for (i=0 ; i<nin ; i++)        // so matrix is just inputs
            *aptr++ = *dptr++ ;
         }

      else if (nhid2 == 0) {            // One hidden layer
         for (i=0 ; i<nhid1 ; i++)      // so matrix is hidden1 activations
            *aptr++ = activity ( dptr , hid1_coefs+i*(nin+1) , nin ) ;
         }

      else {                            // Two hidden layers
         for (i=0 ; i<nhid1 ; i++)
            hid1[i] = activity ( dptr , hid1_coefs+i*(nin+1) , nin ) ;
         for (i=0 ; i<nhid2 ; i++)
            *aptr++ = activity ( hid1 , hid2_coefs+i*(nhid1+1) , nhid1 ) ;
         }
      *aptr++ = 1.0 ;  // Bias term is last column of matrix
      } // For each training sample


/*
   Do the singular value decomposition.
   Then solve for weights for each output neuron.
   After each output weight vector is computed (using backsub),
   compute the activation of that output neuron, compare it to
   its desired value in the training set, and cumulate the error.
*/

   sptr->svdcmp () ;

   err = 0.0 ;

   for (out=0 ; out<nout ; out++) {  // For each output neuron

      bptr = sptr->b ;               // Backsub routine wants RHS here

      for (tset=0 ; tset<tptr->ntrain ; tset++) {

         dptr = tptr->data + size * tset ;    // Training sample starts here

         if (outmod == OUTMOD_AUTO) {         // If this is AUTOASSOCIATIVE
            temp = dptr[out] ;                // output is just input
            if (temp > 0.999999)              // Avoid problems in
               temp = 0.999999 ;              // inverse_act function
            if (temp < 0.000001)
               temp = 0.000001 ;
            *bptr++ = inverse_act ( temp ) ;  // Inverse activation function
            }

         else if (outmod == OUTMOD_CLASSIFY) { // If this is Classification
            if ((int) dptr[nin] == out+1)     // class identifier past inputs
               *bptr++ = inverse_act ( NEURON_ON ) ; // Inverse of NEURON_ON
            else
               *bptr++ = inverse_act ( NEURON_OFF ) ;
            }

         else if (outmod == OUTMOD_GENERAL) { // If this is GENERAL output
            temp = dptr[nin+out] ;            // output is just past input
            if (temp > 0.999999)
               temp = 0.999999 ;
            if (temp < 0.000001)
               temp = 0.000001 ;
            *bptr++ = inverse_act ( temp ) ;    // Inverse activation function
            }
         } // For all training samples

      bptr = out_coefs + out * nvars ;    // Weight vector for this output will
      sptr->backsub ( 1.e-8 , bptr ) ;    // go here.  Find those weights.

      for (i=0 ; i<nvars ; i++) {   // Limit to reasonable values
         if (bptr[i] > 5.)
            bptr[i] = 5. ;
         if (bptr[i] < -5.)
            bptr[i] = -5. ;
         }

/*
   The weights for output neuron 'out' are now in place in out_coefs and are
   pointed to by bptr.  Pass through the training set, using the activations
   of the layer just before the output layer, still in sptr->a, to compute
   the activation of the output neuron.  Compare this attained activation to
   the desired in the training sample, and cumulate the mean square error.
   Note that we use nvars-1 in the call to 'activity' because the bias term
   is taken care of in that subroutine.
*/

      for (tset=0 ; tset<tptr->ntrain ; tset++) {// Cumulate err of this output

         dptr = tptr->data + size * tset ;       // Training sample starts here
         aptr = sptr->a + tset * nvars ;         // Inputs to output layer
         diff = activity ( aptr , bptr , nvars-1 ) ; // Find this output

         if (outmod == OUTMOD_AUTO)              // If this is AUTOASSOCIATIVE
            diff -= dptr[out] ;                  // the desired output is input

         else if (outmod == OUTMOD_CLASSIFY) {    // If this is Classification
            if ((int) dptr[nin] == out+1)        // class identifier past inputs
               diff -= NEURON_ON ;
            else
               diff -= NEURON_OFF ;
            }

         else if (outmod == OUTMOD_GENERAL)      // If this is GENERAL output
            diff -= dptr[nin+out] ;              // output is just past input

         err += diff * diff ;
         }
      } // For each output

   err /= (double) tptr->ntrain * (double) nout ;
   neterr = err ;
   return err ;
}

