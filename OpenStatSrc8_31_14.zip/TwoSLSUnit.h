//---------------------------------------------------------------------------

#ifndef TwoSLSUnitH
#define TwoSLSUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTwoSLSForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *DepVarEdit;
    TListBox *Explanatory;
    TListBox *Instrumental;
    TGroupBox *GroupBox1;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TBitBtn *DepIn;
    TBitBtn *DepOut;
    TBitBtn *ExpIn;
    TBitBtn *ExpOut;
    TBitBtn *InstIn;
    TBitBtn *InstOut;
    TCheckBox *ProxyRegShowChk;
    TMemo *Memo1;
    TCheckBox *SaveItChk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DepInClick(TObject *Sender);
    void __fastcall DepOutClick(TObject *Sender);
    void __fastcall ExpInClick(TObject *Sender);
    void __fastcall ExpOutClick(TObject *Sender);
    void __fastcall InstInClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
   void __fastcall PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars);

public:		// User declarations
    __fastcall TTwoSLSForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTwoSLSForm *TwoSLSForm;
//---------------------------------------------------------------------------
#endif
