//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FutureValueUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFutureValueForm *FutureValueForm;
//---------------------------------------------------------------------------
__fastcall TFutureValueForm::TFutureValueForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFutureValueForm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    PaymentEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0.0";
}
//---------------------------------------------------------------------------
void __fastcall TFutureValueForm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TFutureValueForm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Payment, PresentValue, FutureVal;
     int NPeriods, When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentEdit->Text);
     Payment = StrToFloat(PaymentEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     NPeriods = StrToInt(NPeriodsEdit->Text);
     FutureVal = FutureValue(Rate, NPeriods, Payment, PresentValue, Time);
     FutureEdit->Text = FloatToStr(FutureVal);
}
//---------------------------------------------------------------------------
