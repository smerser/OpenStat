//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "functions.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "GraphUnit.h"
#include "AnovaTestsUnit.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>

#include "OneCaseAnovaUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOneCaseAnovaForm *OneCaseAnovaForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;

//---------------------------------------------------------------------------
__fastcall TOneCaseAnovaForm::TOneCaseAnovaForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::FormShow(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     AEdit->Text = "";
     BEdit->Text = "";
     CEdit->Text = "";
     DependentEdit->Text = "";
     if (ops.format == 0)
     {
        OverAllEdit->Text = "0.05";
        PostHocEdit->Text = "0.05";
     }
     else
     {
        OverAllEdit->Text = "0,05";
        PostHocEdit->Text = "0,05";
     }
     OptionsBox->ItemIndex = 3;
     comparisons = false;
     DepOutBtn->Visible = false;
     AoutBtn->Visible = false;
     BoutBtn->Visible = false;
     CoutBtn->Visible = false;
     DepInBtn->Visible = true;
     AinBtn->Visible = true;
     BinBtn->Visible = true;
     CinBtn->Visible = true;
     InteractBtn->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::ResetBtnClick(TObject *Sender)
{
     FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::DepInBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              DependentEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DependentEdit->Text);
     DependentEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::AinBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              AEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     AoutBtn->Visible = true;
     AinBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::AoutBtnClick(TObject *Sender)
{
     VarList->Items->Add(AEdit->Text);
     AEdit->Text = "";
     AinBtn->Visible = true;
     AoutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::BinBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              BEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     BoutBtn->Visible = true;
     BinBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::BoutBtnClick(TObject *Sender)
{
     VarList->Items->Add(BEdit->Text);
     BEdit->Text = "";
     BinBtn->Visible = true;
     BoutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::CinBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              CEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     CoutBtn->Visible = true;
     CinBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::CoutBtnClick(TObject *Sender)
{
     VarList->Items->Add(CEdit->Text);
     CEdit->Text = "";
     CinBtn->Visible = true;
     CoutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOneCaseAnovaForm::ComputeBtnClick(TObject *Sender)
{
        int result;

        nofactors = 0;
        if ((AEdit->Text != "") && (BEdit->Text != "")) nofactors = 2;
        if ((AEdit->Text != "") && (BEdit->Text != "") && (CEdit->Text != "")) nofactors = 3;
        if (nofactors < 2)
        {
                ShowMessage("ERROR! Selection of 2 or 3 factors required!");
                return;
        }
        FrmOutPut->RichOutPut->Clear();
        // initialize values
        if (ScheffeChk->Checked) comparisons = true;
        if (TukeyHSDChk->Checked) comparisons = true;
        if (TukeyBChk->Checked) comparisons = true;
        if (TukeyKramerChk->Checked) comparisons = true;
        if (NewmanKeulsChk->Checked) comparisons = true;
        if (BonferroniChk->Checked) comparisons = true;
        if (OrthogonalChk->Checked) comparisons = true;
        ColNoSelected = new int[NoVariables];
        DepVarCol = 0;
        F1Col = 0;
        F2Col = 0;
        F3Col = 0;
        SSDep = 0.0;
        SSF1 = 0.0;
        SSF2 = 0.0;
        SSF3 = 0.0;
        SSF1F2 = 0.0;
        SSF1F3 = 0.0;
        SSF2F3 = 0.0;
        SSF1F2F3 = 0.0;
        MeanDep = 0.0;
        MeanF1 = 0.0;
        MeanF2 = 0.0;
        MeanF3 = 0.0;
        Nf1cells = 0;
        Nf2cells = 0;
        Nf3cells = 0;
        N = 0;
        NoSelected = 0;
        minf1 = 0;
        maxf1 = 0;
        minf2 = 0;
        maxf2 = 0;
        minf3 = 0;
        maxf3 = 0;

        //  Get column numbers of dependent variable and factors
        for (int i = 1; i <= NoVariables; i++)
        {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == DependentEdit->Text)
          {
               DepVarCol = i;
               //result = VarTypeChk(i,0);
               //if (result == 1)
               //{
               //   delete[] ColNoSelected;
               //   return;
               //}
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = DepVarCol;
          }
          if (cellstring == AEdit->Text)
          {
               F1Col = i;
               //result = VarTypeChk(i,1);
               //if (result == 1)
               //{
               //   delete[] ColNoSelected;
               //   return;
               //}
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F1Col;
          }
          if (cellstring == BEdit->Text)
          {
               F2Col = i;
               //result = VarTypeChk(i,1);
               //if (result == 1)
               //{
               //   delete[] ColNoSelected;
               //   return;
               //}
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F2Col;
          }
          if (cellstring == CEdit->Text)
          {
               F3Col = i;
               //result = VarTypeChk(i,1);
               //if (result == 1)
               //{
               //   delete[] ColNoSelected;
               //   return;
               //}
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F3Col;
          }
        }
        OverallAlpha = StrToFloat(OverAllEdit->Text);
        PostHocAlpha = StrToFloat(PostHocEdit->Text);
        // get min and max of each factor code
        getlevels(this);

        // allocate space
        cellcnts = new double[totcells];  // array of cell counts
        cellvars = new double[totcells];  // arrray of cell sums of squares  variances
        cellsums = new double[totcells];  // array of cell sums  means

        // initialize array values
        for (int i = 1; i <= totcells; i++)
        {
          cellsums[i-1] = 0.0;
          cellvars[i-1] = 0.0;
          cellcnts[i-1] = 0;
        }

        //  analysis
        switch (nofactors)
        {
           case 2 : // two-way anova
           {
             GetDblMatMem(counts,Nf1cells,Nf2cells); // matrix for 2-way containing cell sizes
             GetDblMatMem(sums,Nf1cells,Nf2cells);  // matrix for 2-way containing cell sums
             GetDblMatMem(vars,Nf1cells,Nf2cells);  // matrix for 2-way containing sums of squares
             RowSums = new double[Nf1cells];  // 2 way row sums
             ColSums = new double[Nf2cells];  // 2 way col sums
             RowCount = new double[Nf1cells]; // 2 way row count
             ColCount = new double[Nf2cells]; // 2 way col count
             OrdMeansA = new double[Nf1cells]; // ordered means for factor 1
             OrdMeansB = new double[Nf2cells]; // ordered means for factor 2

             Calc2Way(this);
             if (CompError)  goto nexttwo;
             TwoWayTable(this);
             TwoWayContrasts(this);
             FrmOutPut->ShowModal();
             if (OptionsBox->ItemIndex >= 0)  TwoWayPlot(this);
nexttwo:     delete[] OrdMeansB;
             delete[] OrdMeansA;
             delete[] ColCount;
             delete[] RowCount;
             delete[] ColSums;
             delete[] RowSums;
             ClearDblMatMem(vars,Nf1cells);
             ClearDblMatMem(sums,Nf1cells);
             ClearDblMatMem(counts,Nf1cells);
           }    break;
           case 3 : // three way anova
           {
             RowSums = new double[Nf1cells];  // 2 way row sums
             ColSums = new double[Nf2cells];  // 2 way col sums
             RowCount = new double[Nf1cells]; // 2 way row count
             ColCount = new double[Nf2cells]; // 2 way col count
             SlcSums = new double[Nf3cells];  // 3 way slice sums
             SlcCount = new double[Nf3cells]; // 3 way slice counts
             OrdMeansA = new double[Nf1cells]; // ordered means for factor 1
             OrdMeansB = new double[Nf2cells]; // ordered means for factor 2
             OrdMeansC = new double[Nf3cells]; // ordered means for factor 3
             GetDblCubeMem(wsum,Nf1cells,Nf2cells,Nf3cells);
             GetDblCubeMem(wx2,Nf1cells,Nf2cells,Nf3cells);
             GetIntCubeMem(ncnt,Nf1cells,Nf2cells,Nf3cells);
             Calc3Way(this);
             if (CompError)  goto nextthree;
             ThreeWayTable(this);
             ThreeWayContrasts(this);
             FrmOutPut->ShowModal();
             if (OptionsBox->ItemIndex >= 0)  ThreeWayPlot(this);
nextthree:
             ClearIntCubeMem(ncnt,Nf1cells,Nf2cells);
             ClearDblCubeMem(wx2,Nf1cells,Nf2cells);
             ClearDblCubeMem(wsum,Nf1cells,Nf2cells);
             delete[] OrdMeansC;
             delete[] OrdMeansB;
             delete[] OrdMeansA;
             delete[] SlcCount;
             delete[] SlcSums;
             delete[] ColCount;
             delete[] ColSums;
             delete[] RowCount;
             delete[] RowSums;
           }
        } // end switch
cleanit:
        delete[] cellcnts;
        delete[] cellvars;
        delete[] cellsums;
        delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::getlevels(TObject *Sender)
{
     int i;
     int result, avalue;
     double dblvalue;
     AnsiString strvalue;

     minf1 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][1])));
     maxf1 = minf1;
     for (i = 2; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i,F1Col,avalue,dblvalue,strvalue);
          //if (result == 1) intvalue = 0;
          //else intvalue = avalue;
          if (intvalue > maxf1)  maxf1 = intvalue;
          if (intvalue < minf1)  minf1 = intvalue;
     }
     Nf1cells = maxf1 - minf1 + 1;
     if (nofactors > 1)
     {
          minf2 = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][1])));
          maxf2 = minf2;
          for (i = 2; i <= NoCases; i++)
          {
               if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
               intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
               //result = GetValue(i,F2Col,avalue,dblvalue,strvalue);
               //if (result == 1) intvalue = 0;
               //else intvalue = avalue;
               if (intvalue > maxf2)  maxf2 = intvalue;
               if (intvalue < minf2)  minf2 = intvalue;
          }
          Nf2cells = maxf2 - minf2 + 1;
     }
     if (nofactors == 3)
     {
          minf3 = floor(StrToFloat(Trim(MainForm->Grid->Cells[F3Col][1])));
          maxf3 = minf3;
          for (i = 2; i <= NoCases; i++)
          {
               if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
               intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F3Col][i])));
               //result = GetValue(i,F3Col,avalue,dblvalue,strvalue);
               //if (result == 1) intvalue = 0;
               //else intvalue = avalue;
               if (intvalue > maxf3)  maxf3 = intvalue;
               if (intvalue < minf3)  minf3 = intvalue;
          }
          Nf3cells = maxf3 - minf3 + 1;
     }
     totcells = Nf1cells + Nf2cells + Nf3cells;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::Calc2Way(TObject *Sender)
{
     int i, j, grpA, grpB;
     double Constant, RowsTotCnt, ColsTotCnt, SSCells;

     CompError = false;
     // initialize matrix values
     NoGrpsA = maxf1 - minf1 + 1;
     NoGrpsB = maxf2 - minf2 + 1;
     for (i = 1; i <= NoGrpsA; i++)
     {
          RowSums[i-1] = 0.0;
          RowCount[i-1] = 0.0;
          for (j = 1; j <= NoGrpsB; j++)
          {
               counts[i-1][j-1] = 0.0;
               sums[i-1][j-1] = 0.0;
               vars[i-1][j-1] = 0.0;
          }
     }
     for (i = 1; i <= NoGrpsB; i++)
     {
          ColCount[i-1] = 0.0;
          ColSums[i-1] = 0.0;
     }
     N = 0;
     MeanDep = 0.0;
     SSDep = 0.0;
     SSCells = 0.0;
     RowsTotCnt = 0.0;
     ColsTotCnt = 0.0;
     SSNonAdd = 0.0;
     SSBalance = 0.0;
     MSNonAdd = 0.0;
     MSBalance = 0.0;
     // get working totals
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          grpA = floor(StrToFloat(MainForm->Grid->Cells[F1Col][i]));
          grpB = floor(StrToFloat(MainForm->Grid->Cells[F2Col][i]));
          X = StrToFloat(MainForm->Grid->Cells[DepVarCol][i]);
          grpA = grpA - minf1 + 1;
          grpB = grpB - minf2 + 1;
          counts[grpA-1][grpB-1] = counts[grpA-1][grpB-1] + 1;
          sums[grpA-1][grpB-1] = sums[grpA-1][grpB-1] + X;
          vars[grpA-1][grpB-1] = vars[grpA-1][grpB-1] + (X * X);
          RowSums[grpA-1] = RowSums[grpA-1] + X;
          ColSums[grpB-1] = ColSums[grpB-1] + X;
          RowCount[grpA-1] = RowCount[grpA-1] + 1.0;
          ColCount[grpB-1] = ColCount[grpB-1] + 1.0;
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }

     // Calculate results
     for (i = 0; i < NoGrpsA; i++)
     {
          SSF1 = SSF1 + ((RowSums[i] * RowSums[i]) / RowCount[i]);
          RowsTotCnt = RowsTotCnt + RowCount[i];
     }
     for (j = 0; j < NoGrpsB; j++)
     {
          SSF2 = SSF2 + ((ColSums[j] * ColSums[j]) / ColCount[j]);
          ColsTotCnt = ColsTotCnt + ColCount[j];
     }

     GrandMean = MeanDep / (double) N;

     for (i = 0; i < NoGrpsA; i++)
     {
          rowmean = RowSums[i] / RowCount[i];
          for (j = 0; j < NoGrpsB; j++)
          {
                 colmean = ColSums[j] / ColCount[j];
                 SSNonAdd = SSNonAdd +
                 ( (colmean - GrandMean) * (rowmean - GrandMean) * sums[i][j] );
          }
     }

     if (N > 0)  Constant = (MeanDep * MeanDep) / (double)N;
     else Constant = 0.0;
     SSF1 = SSF1 - Constant;
     SSF2 = SSF2 - Constant;
     SSDep = SSDep - Constant;
     SSErr = SSDep - (SSF1 + SSF2);
     SSNonAdd = (SSNonAdd * SSNonAdd) / ((SSF1 * SSF2) / (NoGrpsA * NoGrpsB)  );
     MSNonAdd = SSNonAdd;
     SSBalance = SSErr - SSNonAdd;
     if ((SSF1 < 0) || (SSF2 < 0))
     {
          ShowMessage("ERROR! A negative SS found. Unbalanced design? Ending analysis.");
          CompError = true;
          return;
     }
     DFTot = N - 1;
     DFF1 = NoGrpsA - 1;
     DFF2 = NoGrpsB - 1;
     DFErr = DFF1 * DFF2;
     DFBalance = DFErr - 1;
     MSF1 = SSF1 / DFF1;
     MSF2 = SSF2 / DFF2;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     MSBalance = SSBalance / DFBalance;
     OmegaF1 = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     OmegaF2 = (SSF2 - DFF2 * MSErr) / (SSDep + MSErr);
     Omega = OmegaF1 + OmegaF2;
     MeanDep = MeanDep / N;
     // f tests for fixed effects
     FF1 = fabs(MSF1 / MSErr);
     FF2 = fabs(MSF2 / MSErr);
     if (MSBalance > 0.0) FNonAdd = MSNonAdd / MSBalance;
     else FNonAdd = 0.0;
     ProbF1 = ftest(DFF1,DFErr,FF1);
     ProbF2 = ftest(DFF2,DFErr,FF2);
     ProbNonAdd = ftest(1.0,DFBalance,FNonAdd);
     if (ProbF1 > 1.0)  ProbF1 = 1.0;
     if (ProbF2 > 1.0)  ProbF2 = 1.0;

     // Obtain omega squared (proportion of dependent variable explained)
     if (OmegaF1 < 0.0)  OmegaF1 = 0.0;
     if (OmegaF2 < 0.0)  OmegaF2 = 0.0;
     if (Omega < 0.0)  Omega = 0.0;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::TwoWayTable(TObject *Sender)
{
     int i, j, groupsize;
     double MinVar, MaxVar, sumvars, sumDFrecip, XBar, V, S, RowSS, ColSS;
     double sumfreqlogvar, c, bartlett, cochran, hartley, chiprob;
     char astring[121];

     if (CompError) return;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Two Way Analysis of Variance");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Variable analyzed: %s",DependentEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Factor A (rows) variable: %s",AEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor B (columns) variable: %s",BEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE         D.F.    SS        MS         F      PROB.> F   Omega Squared");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Among Rows     %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f",
          DFF1,SSF1,MSF1,FF1,ProbF1,OmegaF1);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Among Columns  %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f",
          DFF2,SSF2,MSF2,FF2,ProbF2,OmegaF2);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Residual       %4.0f  %8.3f  %8.3f",
          DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring," NonAdditivity %4.0f  %8.3f  %8.3f  %8.3f  %6.3f",
        1.0,SSNonAdd,MSNonAdd,FNonAdd,ProbNonAdd);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring," Balance       %4.0f  %8.3f  %8.3f",DFBalance,SSBalance,MSBalance);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Total          %4.0f  %8.3f  %8.3f",
          DFTot,SSDep,MSDep);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Omega squared for combined effects = %8.3f",Omega);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("GROUP Row Col.  N     MEAN   VARIANCE  STD.DEV.");
     groupsize = ceil(counts[0][0]);
     equal_grp = true;
     MaxVar = 0.0;
     MinVar = 1e20;
     sumvars = 0.0;
     sumfreqlogvar = 0.0;
     sumDFrecip = 0.0;

     // Display cell means, variances, standard deviations
     V = 0.0;
     XBar = 0.0;
     S = 0.0;
     for (i = 0;i < NoGrpsA;i++)
     {
          for (j = 0;j < NoGrpsB;j++)
          {
               if (counts[i][j] > 1)
               {
                    XBar = sums[i][j] / counts[i][j];
                    V = vars[i][j] - ( (sums[i][j] * sums[i][j]) / counts[i][j]);
                    V = V / (counts[i][j] - 1.0);
                    S = sqrt(V);
                    sumvars  = sumvars + V;
                    if (V > MaxVar)  MaxVar = V;
                    if (V < MinVar)  MinVar = V;
                    sumDFrecip = sumDFrecip + (1.0 / (counts[i][j] - 1.0));
                    sumfreqlogvar = sumfreqlogvar + ((counts[i][j] - 1.0) * log(V));
                    if (counts[i][j] != groupsize) equal_grp = false;
               }
               else XBar = sums[i][j];
               sprintf(astring,"Cell %3d %3d  %3.0f  %8.3f  %8.3f  %8.3f",
                   minf1+i,minf2+j,counts[i][j],XBar,V,S);
               FrmOutPut->RichOutPut->Lines->Add(astring);
          }
     }

     //Display Row means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          XBar = RowSums[i] / RowCount[i];
          OrdMeansA[i] = XBar;
          RowSS = 0.0;
          for (j = 0; j < NoGrpsB; j++) RowSS = RowSS + vars[i][j];
          V = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
          V = V / (RowCount[i] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Row  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
               minf1+i,RowCount[i],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          XBar = ColSums[j] / ColCount[j];
          OrdMeansB[j] = XBar;
          ColSS = 0.0;
          for (i = 0; i < NoGrpsA; i++) ColSS = ColSS + vars[i][j];
          if (ColCount[j] > 0) V = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
          if (ColCount[j] > 1) V = V / (ColCount[j] - 1.0);
          if (V > 0.0) S = sqrt(V);
          sprintf(astring,"Col  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
             minf2+j,ColCount[j],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     sprintf(astring,"TOTAL         %3d  %8.3f  %8.3f  %8.3f",
          N,MeanDep,MSDep,sqrt(MSDep));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::TwoWayPlot(TObject *Sender)
{
     int i, j;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     if (CompError)  return;
     XValue = new double[Nf1cells+Nf2cells];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          RowSums[i-1] = RowSums[i-1] / RowCount[i-1];
          GraphForm->Ypoints[0][i-1] = RowSums[i-1];
          if (RowSums[i-1] > maxmean)  maxmean = RowSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = AEdit->Text;
     title =  AEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf2cells);
     for (i = 1; i <= Nf2cells; i++)
     {
          ColSums[i-1] = ColSums[i-1] / ColCount[i-1];
          GraphForm->Ypoints[0][i-1] = ColSums[i-1];
          if (ColSums[i-1] > maxmean)  maxmean = ColSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = BEdit->Text;
     title =  BEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor A x B Interaction next
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf2cells);
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          setstring = AEdit->Text + " " + IntToStr(i);
          GraphForm->SetLabels[i] = setstring;
          for (j = 1; j <= Nf2cells;j++)
          {
               XBar = sums[i-1][j-1] / counts[i-1][j-1];
               if (XBar > maxmean)  maxmean = XBar;
               GraphForm->Ypoints[i-1][j-1] = XBar;
          }
     }
     for (j = 1; j <= Nf2cells;j++)
     {
        XValue[j-1] = minf2 + j - 1;
        GraphForm->Xpoints[0][j-1] = XValue[j-1];
     }

     GraphForm->nosets = Nf1cells;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = "Factor A x Factor B";
     title =  BEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     delete[] XValue;
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::Calc3Way(TObject *Sender)
{
     int i, j, k, grpA, grpB, grpC;
     double Constant, RowsTotCnt, ColsTotCnt, SlcsTotCnt, SSCells, p, n2;

     if (InteractBtn->Checked) interacts = true;
     else interacts = false;

     CompError = false;
     // initialize matrix values
     NoGrpsA = maxf1 - minf1 + 1;
     NoGrpsB = maxf2 - minf2 + 1;
     NoGrpsC = maxf3 - minf3 + 1;
     for (i = 0; i < NoGrpsA; i++)
     {
          RowSums[i] = 0.0;
          RowCount[i] = 0.0;
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    wsum[i][j][k] = 0.0;
                    ncnt[i][j][k] = 0;
                    wx2[i][j][k] = 0.0;
               }
          }
     }
     for (i = 0; i < NoGrpsB; i++)
     {
          ColCount[i] = 0.0;
          ColSums[i] = 0.0;
     }
     for (i = 0; i < NoGrpsC; i++)
     {
          SlcCount[i] = 0.0;
          SlcSums[i] = 0.0;
     }
     N = 0;
     MeanDep = 0.0;
     SSDep = 0.0;
     RowsTotCnt = 0.0;
     ColsTotCnt = 0.0;
     SlcsTotCnt = 0.0;
     SSF1 = 0.0;
     SSF2 = 0.0;
     SSF3 = 0.0;
     SSF1F2 = 0.0;
     SSF1F3 = 0.0;
     SSF2F3 = 0.0;
     SSF1F2F3 = 0.0;
     SSCells = 0.0;
     SSNonAdd = 0.0;

     // get working totals
     for (i = 1; i <= NoCases;i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          grpA = floor(StrToFloat(MainForm->Grid->Cells[F1Col][i]));
          grpB = floor(StrToFloat(MainForm->Grid->Cells[F2Col][i]));
          grpC = floor(StrToFloat(MainForm->Grid->Cells[F3Col][i]));
          X = StrToFloat(MainForm->Grid->Cells[DepVarCol][i]);
          grpA = grpA - minf1 + 1;
          grpB = grpB - minf2 + 1;
          grpC = grpC - minf3 + 1;
          ncnt[grpA-1][grpB-1][grpC-1] = ncnt[grpA-1][grpB-1][grpC-1] + 1;
          wsum[grpA-1][grpB-1][grpC-1] = wsum[grpA-1][grpB-1][grpC-1] + X;
          wx2[grpA-1][grpB-1][grpC-1] = wx2[grpA-1][grpB-1][grpC-1] + (X * X);
          RowSums[grpA-1] = RowSums[grpA-1] + X;
          ColSums[grpB-1] = ColSums[grpB-1] + X;
          SlcSums[grpC-1] = SlcSums[grpC-1] + X;
          RowCount[grpA-1] = RowCount[grpA-1] + 1.0;
          ColCount[grpB-1] = ColCount[grpB-1] + 1.0;
          SlcCount[grpC-1] = SlcCount[grpC-1] + 1.0;
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }

     // Calculate results
     Constant = (MeanDep * MeanDep) / N;
     GrandMean = MeanDep / (double) N;

     // get ss for rows
     for (i = 0; i < NoGrpsA; i++)
     {
          SSF1 = SSF1 + ((RowSums[i] * RowSums[i]) / RowCount[i]);
          RowsTotCnt = RowsTotCnt + RowCount[i];
     }
     SSF1 = SSF1 - Constant;

     // get ss for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          SSF2 = SSF2 + ((ColSums[j] * ColSums[j]) / ColCount[j]);
          ColsTotCnt = ColsTotCnt + ColCount[j];
     }
     SSF2 = SSF2 - Constant;

     // get ss for slices
     for (k = 0; k < NoGrpsC; k++)
     {
          SSF3 = SSF3 + ((SlcSums[k] * SlcSums[k]) / SlcCount[k]);
          SlcsTotCnt = SlcsTotCnt + SlcCount[k];
     }
     SSF3 = SSF3 - Constant;

     // get ss for row x col interaction
     p = 0.0;
     n2 = 0.0;
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF1F2 = SSF1F2 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF1F2 = SSF1F2 - SSF1 - SSF2 - Constant;

     // get ss for row x slice interaction
     for (i = 0; i < NoGrpsA; i++)
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               for (j = 0; j < NoGrpsB; j++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF1F3 = SSF1F3 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF1F3 = SSF1F3 - SSF1 - SSF3 - Constant;

     // get ss for columns x slices interaction
     for (j = 0; j < NoGrpsB; j++)
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               for (i = 0; i < NoGrpsA; i++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF2F3 = SSF2F3 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF2F3 = SSF2F3 - SSF2 - SSF3 - Constant;

/*
     // get ss for cells
     for (i = 0; i < NoGrpsA; i++)
          for (j = 0; j < NoGrpsB; j++)
               for (k = 0; k < NoGrpsC; k++)
                    SSCells = SSCells + ((wsum[i][j][k] * wsum[i][j][k]) / ncnt[i][j][k]);

     SSF1F2F3 = SSCells - SSF1 - SSF2 - SSF3 - SSF1F2 - SSF1F3 - SSF2F3 - Constant;
*/
     for (i = 0; i < NoGrpsA; i++)
     {
          rowmean = RowSums[i] / RowCount[i];
          for (j = 0; j < NoGrpsB; j++)
          {
                 colmean = ColSums[j] / ColCount[j];
                 for (k = 0; k < NoGrpsC; k++)
                 {
                        slicemean = SlcSums[k] / SlcCount[k];
                        SSNonAdd = SSNonAdd +
                          ( (colmean - GrandMean) * (rowmean - GrandMean) *
                            (slicemean - GrandMean) * wsum[i][j][k] );
                 }
          }
     }
loop:
     SSDep = SSDep - Constant;
     if (interacts == false) SSErr = SSDep - (SSF1 + SSF2 + SSF3);
     else SSErr = SSDep - (SSF1 + SSF2 + SSF3 + SSF1F2 + SSF1F3 + SSF2F3);
     SSNonAdd = (SSNonAdd * SSNonAdd) / (SSF1 * SSF2 * SSF3);
     SSNonAdd = SSNonAdd * (NoGrpsA * NoGrpsB * NoGrpsC) *  (NoGrpsA * NoGrpsB * NoGrpsC );
     MSNonAdd = SSNonAdd;
     SSBalance = SSErr - SSNonAdd;

     if ((SSF1 < 0.0) || (SSF2 < 0.0) || (SSF3 < 0.0) || (SSF1F2 < 0.0) ||
        (SSF1F3 < 0.0) || (SSF2F3 < 0.0))
     {
          ShowMessage("ERROR! A negative SS found. Unbalanced Design? Ending analysis.");
          CompError = true;
          return;
     }
     DFTot = N - 1;
     DFF1 = NoGrpsA - 1;
     DFF2 = NoGrpsB - 1;
     DFF3 = NoGrpsC - 1;
     DFF1F2 = DFF1 * DFF2;
     DFF1F3 = DFF1 * DFF3;
     DFF2F3 = DFF2 * DFF3;
     if (interacts == false) DFErr = DFTot - DFF1 - DFF2 - DFF3;
     else DFErr = DFTot - DFF1 - DFF2 - DFF3 - DFF1F2 - DFF1F3 - DFF2F3;
     DFBalance = DFErr - 1;
     MSF1 = SSF1 / DFF1;
     MSF2 = SSF2 / DFF2;
     MSF3 = SSF3 / DFF3;
     MSF1F2 = SSF1F2 / DFF1F2;
     MSF1F3 = SSF1F3 / DFF1F3;
     MSF2F3 = SSF2F3 / DFF2F3;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     MSBalance = SSBalance / DFBalance;
     OmegaF1 = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     OmegaF2 = (SSF2 - DFF2 * MSErr) / (SSDep + MSErr);
     OmegaF3 = (SSF3 - DFF3 * MSErr) / (SSDep + MSErr);
     OmegaF1F2 = (SSF1F2 - DFF1F2 * MSErr) / (SSDep + MSErr);
     OmegaF1F3 = (SSF1F3 - DFF1F3 * MSErr) / (SSDep + MSErr);
     OmegaF2F3 = (SSF2F3 - DFF2F3 * MSErr) / (SSDep + MSErr);
     if (interacts == false) Omega = OmegaF1 + OmegaF2 + OmegaF3;
     else Omega = OmegaF1 + OmegaF2 + OmegaF3 + OmegaF1F2 + OmegaF1F3 +  OmegaF2F3;
     MeanDep = MeanDep / N;

     FF1 = fabs(MSF1 / MSErr);
     FF2 = fabs(MSF2 / MSErr);
     FF3 = fabs(MSF3 / MSErr);
     FF1F2 = fabs(MSF1F2 / MSErr);
     FF1F3 = fabs(MSF1F3 / MSErr);
     FF2F3 = fabs(MSF2F3 / MSErr);
     if (MSBalance > 0.0) FNonAdd = MSNonAdd / MSBalance;
     else FNonAdd = 0.0;

     ProbF1 = ftest(DFF1,DFErr,FF1);
     ProbF2 = ftest(DFF2,DFErr,FF2);
     ProbF3 = ftest(DFF3,DFErr,FF3);
     ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
     ProbF1F3 = ftest(DFF1F3,DFErr,FF1F3);
     ProbF2F3 = ftest(DFF2F3,DFErr,FF2F3);
     ProbNonAdd = ftest(1.0,DFBalance,FNonAdd);

     if (ProbF1 > 1.0)  ProbF1 = 1.0;
     if (ProbF2 > 1.0)  ProbF2 = 1.0;
     if (ProbF3 > 1.0)  ProbF3 = 1.0;
     if (ProbF1F2 > 1.0)  ProbF1F2 = 1.0;
     if (ProbF1F3 > 1.0)  ProbF1F3 = 1.0;
     if (ProbF2F3 > 1.0)  ProbF2F3 = 1.0;

     // Obtain omega squared (proportion of dependent variable explained)
     if (OmegaF1 < 0.0)  OmegaF1 = 0.0;
     if (OmegaF2 < 0.0)  OmegaF2 = 0.0;
     if (OmegaF3 < 0.0)  OmegaF3 = 0.0;
     if (OmegaF1F2 < 0.0)  OmegaF1F2 = 0.0;
     if (OmegaF1F3 < 0.0)  OmegaF1F3 = 0.0;
     if (OmegaF2F3 < 0.0)  OmegaF2F3 = 0.0;
     if (Omega < 0.0)  Omega = 0.0;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::ThreeWayTable(TObject *Sender)
{
     int groupsize;
     double MinVar, MaxVar, sumvars, sumDFrecip;
     int i, j, k;
     double XBar, V, S, RowSS, ColSS, SlcSS;
     double sumfreqlogvar, c, bartlett, cochran, hartley, chiprob;
     bool problem;
     char astring[121];

     if (CompError) return;
     FrmOutPut->RichOutPut->Clear();
     problem = false;
     FrmOutPut->RichOutPut->Lines->Add("Three Way Analysis of Variance");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Variable analyzed: %s",DependentEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Factor A (rows) variable: %s",AEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor B (columns) variable: %s",BEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor C (slices) variable: %s",CEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE         D.F.        SS            MS             F      PROB.> F   Omega Squared");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Among Rows     %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
             DFF1,SSF1,MSF1,FF1,ProbF1,OmegaF1);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Among Columns  %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
             DFF2,SSF2,MSF2,FF2,ProbF2,OmegaF2);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Among Slices   %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
             DFF3,SSF3,MSF3,FF3,ProbF3,OmegaF3);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     if (interacts)
     {
        sprintf(astring,"A x B Inter.   %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
             DFF1F2,SSF1F2,MSF1F2,FF1F2,ProbF1F2,OmegaF1F2);
        FrmOutPut->RichOutPut->Lines->Add(astring);
        sprintf(astring,"A x C Inter.   %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
             DFF1F3,SSF1F3,MSF1F3,FF1F3,ProbF1F3,OmegaF1F3);
        FrmOutPut->RichOutPut->Lines->Add(astring);
        sprintf(astring,"B x C Inter.   %4.0f  %12.4f  %12.4f  %12.4f  %6.3f     %6.3f",
          DFF2F3,SSF2F3,MSF2F3,FF2F3,ProbF2F3,OmegaF2F3);
        FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     sprintf(astring,"Residual       %4.0f  %12.4f  %12.4f", DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring," NonAdditivity %4.0f  %12.4f  %12.4f  %12.4f  %6.3f",
        1.0,SSNonAdd,MSNonAdd,FNonAdd,ProbNonAdd);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring," Balance       %4.0f  %12.4f  %12.4f",DFBalance,SSBalance,MSBalance);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Total          %4.0f  %12.4f  %12.4f",DFTot,SSDep,MSDep);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Omega squared for combined effects = %8.4f",Omega);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("GROUP              N     MEAN   VARIANCE  STD.DEV.");
     groupsize = ncnt[1][1][1];
     equal_grp = true;
     MaxVar = 0.0;
     MinVar = 1e20;
     sumvars = 0.0;
     sumfreqlogvar = 0.0;
     sumDFrecip = 0.0;

     // Display cell means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    V = 0.0;
                    S = 0.0;
               }
          }
     }

     //Display Row means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          XBar = RowSums[i] / RowCount[i];
          OrdMeansA[i] = XBar;
          RowSS = 0.0;
          for (j = 0; j < NoGrpsB; j++)
              for (k = 0; k < NoGrpsC; k++)  RowSS = RowSS + wx2[i][j][k];
          V = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
          V = V / (RowCount[i] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Row   %3d         %3.0f  %8.3f  %8.3f  %8.3f",
               minf1+i,RowCount[i],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          XBar = ColSums[j] / ColCount[j];
          OrdMeansB[j] = XBar;
          ColSS = 0.0;
          for (i = 0; i < NoGrpsA; i++)
              for (k = 0; k < NoGrpsC; k++)  ColSS = ColSS + wx2[i][j][k];
          V = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
          V = V / (ColCount[j] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Col   %3d         %3.0f  %8.3f  %8.3f  %8.3f",
             minf2+j,ColCount[j],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for slices
     for (k = 0; k < NoGrpsC; k++)
     {
          XBar = SlcSums[k] / SlcCount[k];
          OrdMeansC[k] = XBar;
          SlcSS = 0.0;
          for (i = 0; i < NoGrpsA; i++)
              for (j = 0; j < NoGrpsB; j++)  SlcSS = SlcSS + wx2[i][j][k];
          V = SlcSS - (SlcSums[k] * SlcSums[k] / SlcCount[k]);
          V = V / (SlcCount[k] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Slice %3d         %3.0f  %8.3f  %8.3f  %8.3f",
             minf3+k,SlcCount[k],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     sprintf(astring,"TOTAL             %3d  %8.3f  %8.3f  %8.3f",
          N,MeanDep,MSDep,sqrt(MSDep));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::ThreeWayPlot(TObject *Sender)
{
     int i, j, k;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     if (CompError) return;
     XValue = new double[totcells];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 0; i < Nf1cells; i++)
     {
          RowSums[i] = RowSums[i] / RowCount[i];
          GraphForm->Ypoints[0][i] = RowSums[i];
          if (RowSums[i] > maxmean) maxmean = RowSums[i];
          XValue[i] = minf1 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = AEdit->Text;
     title =  AEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf2cells);
     for (i = 0; i < Nf2cells; i++)
     {
          ColSums[i] = ColSums[i] / ColCount[i];
          GraphForm->Ypoints[0][i] = ColSums[i];
          if (ColSums[i] > maxmean)  maxmean = ColSums[i];
          XValue[i] = minf2 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = BEdit->Text;
     title =  BEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor C next
     setstring = "FACTOR C";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf3cells);
     for (i = 0; i < Nf3cells; i++)
     {
          SlcSums[i] = SlcSums[i] / SlcCount[i];
          GraphForm->Ypoints[0][i] = SlcSums[i];
          if (SlcSums[i] > maxmean)  maxmean = SlcSums[i];
          XValue[i] = minf3 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf3cells;
     GraphForm->Heading = CEdit->Text;
     title =  BEdit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor A x B Interaction within each slice next
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf2cells);
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     for (k = 0; k < Nf3cells; k++)
     {
          maxmean = 0.0;
          for (i = 0; i < Nf1cells; i++)
          {
               setstring = AEdit->Text + " " + IntToStr(i+1);
               GraphForm->SetLabels[i+1] = setstring;
               for (j = 0; j < Nf2cells; j++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[i][j] = XBar;
               }
          }
          for (j = 0; j < Nf2cells; j++)
          {
            XValue[j] = minf2 + j ;
            GraphForm->Xpoints[0][j] = XValue[j];
          }

          GraphForm->nosets = Nf1cells;
          GraphForm->nbars = Nf2cells;
          GraphForm->Heading = "Factor A x Factor B Within C " + IntToStr(k+1);
          title =  BEdit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.2;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     }
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf1cells);

     //  Factor A x C Interaction within each Column next
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf3cells);
     for (j = 0; j < Nf2cells; j++)
     {
          maxmean = 0.0;
          for (i = 0; i < Nf1cells; i++)
          {
               setstring = AEdit->Text + " " + IntToStr(i+1);
               GraphForm->SetLabels[i+1] = setstring;
               for (k = 0; k < Nf3cells; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[i][k] = XBar;
               }
          }
          for (k = 0; k < Nf3cells; k++)
          {
            XValue[k] = minf3 + k;
            GraphForm->Xpoints[0][k] = XValue[k];
          }

          GraphForm->nosets = Nf1cells;
          GraphForm->nbars = Nf3cells;
          GraphForm->Heading = "Factor A x Factor C Within B " + IntToStr(j+1);
          title =  CEdit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.2;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     }
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf1cells);

     //  Factor B x C Interaction within each row next
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,Nf2cells,Nf3cells);
     for (i = 0; i < Nf1cells; i++)
     {
          maxmean = 0.0;
          for (j = 0; j < Nf2cells; j++)
          {
               setstring = BEdit->Text + " " + IntToStr(j+1);
               GraphForm->SetLabels[j+1] = setstring;
               for (k = 0; k < Nf3cells; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[j][k] = XBar;
               }
          }
          for (j = 0; j < Nf3cells; j++)
          {
            XValue[j] = minf3 + j;
            GraphForm->Xpoints[0][j] = XValue[j];
          }

          GraphForm->nosets = Nf2cells;
          GraphForm->nbars = Nf3cells;
          GraphForm->Heading = "Factor B x Factor C Within A " + IntToStr(i+1);
          title =  CEdit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.2;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     } // next row
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf2cells);
     delete[] XValue;
}
//---------------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::TwoWayContrasts(TObject *Sender)
{
     int i, j;
     double value, alpha;
     char outline[121];
     double *variances;
     double RowSS, ColSS;

     if (comparisons == false) return;
     if (CompError) return;
     variances = new double[totcells];
     alpha = StrToFloat(PostHocEdit->Text);
     //  row comparisons
     if ((Nf1cells > 2) && (ProbF1 < OverallAlpha) )
     {
          for (i = 0; i < NoGrpsA; i++)
          {
               RowSS = 0.0;
               for (j = 0; j < NoGrpsB; j++) RowSS = RowSS + vars[i][j];
               variances[i] = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
               variances[i] = variances[i] / (RowCount[i] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS");
          // get smallest group size
          value = 1e20;
          for (i = 0; i < Nf1cells; i++)  if (RowCount[i] < value) value = RowCount[i];
          if (ScheffeChk->Checked)
              SCHEFFETEST(MSErr,RowSums,RowCount,minf1,maxf1,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(RowSums,RowCount,variances,minf1,maxf1,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
     }

     //  column comparisons
     if ((Nf2cells > 2) && (ProbF2 < OverallAlpha) )
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               ColSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)  ColSS = ColSS + vars[i][j];
               variances[j] = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
               variances[j] = variances[j] / (ColCount[j] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS");
          value = 1e20;
          for (i = 0; i < Nf2cells; i++)  if (ColCount[i] < value) value = ColCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,ColSums,ColCount,minf2,maxf2,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(ColSums,ColCount,variances,minf2,maxf2,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
     }

     //  simple effects for columns within each row
     if (ProbF3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH ROW");
          for (i = 0; i < Nf1cells; i++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"ROW %d COMPARISONS",i+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums and counts to cellsums and cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    cellsums[j] = sums[i][j];
                    cellcnts[j] = counts[i][j];
                    cellvars[j] = vars[i][j];
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each column
     if (ProbF3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH COLUMN");
          for (j = 0; j < Nf2cells; j++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"COLUMN %d COMPARISONS", j+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums and counts to cellsums and cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    cellsums[i] = sums[i][j];
                    cellcnts[i] = counts[i][j];
                    cellvars[i] = vars[i][j];
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }
     delete[] variances;
}
//-------------------------------------------------------------------

void __fastcall TOneCaseAnovaForm::ThreeWayContrasts(TObject *Sender)
{
     int i, j, k;
     double value, alpha;
     char outline[121];
     double *variances;
     double RowSS, ColSS, SlcSS;

     if (comparisons == false) return;
     if (CompError) return;
     alpha = StrToFloat(PostHocEdit->Text);
     if ((ScheffeChk->Checked == false) && (TukeyHSDChk->Checked == false) &&
        (TukeyBChk->Checked == false) && (TukeyKramerChk->Checked == false) &&
        (NewmanKeulsChk->Checked == false) && (BonferroniChk->Checked == false) &&
        (OrthogonalChk->Checked == false)) return;
     variances = new double[totcells];

     //  row comparisons
     if ((Nf1cells > 2) && (ProbF1 < OverallAlpha))
     {
          for (i = 0; i < NoGrpsA; i++)
          {
               RowSS = 0.0;
               for (j = 0; j < NoGrpsB; j++)
                   for (k = 0; k < NoGrpsC; k++) RowSS = RowSS + wx2[i][j][k];
               variances[i] = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
               variances[i] = variances[i] / (RowCount[i] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS");
          // get smallest group size
          value = 1e20;
          for (i = 0; i < Nf1cells; i++)  if (RowCount[i] < value) value = RowCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,RowSums,RowCount,minf1,maxf1,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(RowSums,RowCount,variances,minf1,maxf1,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
     }

     //  column comparisons
     if ((Nf2cells > 2) && (ProbF2 < OverallAlpha))
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               ColSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)
                   for (k = 0; k < NoGrpsC; k++) ColSS = ColSS + wx2[i][j][k];
               variances[j] = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
               variances[j] = variances[j] / (ColCount[j] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS");
          value = 1e20;
          for (i = 0; i < Nf2cells; i++)  if (ColCount[i] < value)  value = ColCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,ColSums,ColCount,minf2,maxf2,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(ColSums,ColCount,variances,minf2,maxf2,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
     }

     //  slice comparisons
     if ((Nf3cells > 2) && (ProbF3 < OverallAlpha))
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               SlcSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)
                   for (j = 0; j < NoGrpsB; j++) SlcSS = SlcSS + wx2[i][j][k];
               variances[k] = SlcSS - (SlcSums[k] * SlcSums[k] / SlcCount[k]);
               variances[k] = variances[k] / (SlcCount[k] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG SLICES");
          value = 1e20;
          for (i = 0; i < Nf3cells;i++)  if (SlcCount[i] < value)  value = SlcCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,SlcSums,SlcCount,minf3,maxf3,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,SlcSums,SlcCount,minf3,maxf3,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(SlcSums,SlcCount,variances,minf3,maxf3,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,SlcSums,SlcCount,minf3,maxf3,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
     }

     //  simple effects for columns within each row
     if (ProbF1F2 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH ROW");
          for (i = 0; i < Nf1cells; i++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"ROW %d COMPARISONS",i+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    for (k = 0; k < Nf3cells; k++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each column
     if (ProbF1F2 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH COLUMN");
          for (j = 0; j < Nf2cells; j++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"COLUMN %d COMPARISONS",j+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    for (k = 0; k < Nf3cells; k++)
                    {
                         cellsums[i] = wsum[i][j][k];
                         cellcnts[i] = ncnt[i][j][k];
                         cellvars[i] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }

     //  simple effects for columns within each slice
     if (ProbF2F3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH SLICE");
          for (k = 0; k < Nf3cells; k++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"SLICE %d COMPARISONS",k+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    for (i = 0; i < Nf1cells; i++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each slice
     if (ProbF1F3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH SLICE");
          for (k = 0; k < Nf3cells; k++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"SLICE %d COMPARISONS",k+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    for (j = 0; j < Nf2cells; j++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[i] < value)  value = cellcnts[i];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }

     delete[] variances;
}
