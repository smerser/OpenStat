//---------------------------------------------------------------------------

#ifndef ANCOVAUnitH
#define ANCOVAUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TANCOVAFORM : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TBitBtn *DepIn;
     TBitBtn *DepOut;
     TBitBtn *FixedIn;
     TBitBtn *CovIn;
     TBitBtn *FixedOut;
     TBitBtn *CovOut;
     TEdit *DepVar;
     TListBox *FixedList;
     TListBox *CovList;
     TMemo *Memo1;
     TGroupBox *GroupBox1;
     TCheckBox *Describe;
     TCheckBox *Rmats;
     TCheckBox *Inverses;
     TCheckBox *PlotMeans;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
    TCheckBox *RegsChk;
    TCheckBox *MeansChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall DepInClick(TObject *Sender);
     void __fastcall DepOutClick(TObject *Sender);
     void __fastcall FixedInClick(TObject *Sender);
     void __fastcall FixedOutClick(TObject *Sender);
     void __fastcall CovInClick(TObject *Sender);
     void __fastcall CovOutClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    int NCases, NoSelected, NoFixed, NoCovs, DepColNo, count;
    int *ColNoSelected; // Grid col. no's of predictors
    AnsiString *RowLabels, *ColLabels;
    double **CorMat; // correlation matrix
    double **IndMat; // correlation matrix among independent variables
    double *BetaWeights; // standardized regression weights
    double *Means, *Variances, *StdDevs;
    bool PrintIt; // true to print correlations in reg procedure
    double probout; // probability for removing a variable
    bool Testout; // true if testing for retention of variables
    bool plot; // if true, plot group means
    bool ShowRegs; // if true, show regression results
    double StdErrEst; // standard error of estimate
    double R2; // squared multiple correlation coefficient
    int *FixedCols; // grid columns of fixed variables
    int *CovCols; // grid columns of covariates
    int *mingrp, *maxgrp; // min and max group codes
    int **Block; // descriptors for group codings
    // values 1 to 5 contain group min, max, startcol, endcol and no. of vectors
    int NoBlocks; // number of vector blocks created for groups and inter.
    bool errorcode; // returned by routines that use an errorcode
    int *IndepIndex; // sequential number of predictors in corr. matrix
    AnsiString *BlockLabel;
    bool descript;
    bool printinv;
    int NoTestVecs; // no. of vectors for group interactions with covariates
    double constant; // regression constant
    int noind; // no. of independent variables in a regression analysis
    double *BWeights; // raw regression weights
    double *BStdErrs; // standard errors of regression weights
    double *BTtests;

    int __fastcall GetParms(TObject *Sender);
    void __fastcall CodeGroups(TObject *Sender);
    void __fastcall GenInteractions(TObject *Sender);
    void __fastcall DoRegs(TObject *Sender);
    void __fastcall CleanUp(TObject *Sender);
    void __fastcall EntryOpt1(TObject *Sender);
    void __fastcall GenCovInteracts(TObject *Sender);
    void __fastcall AdjustMeans(TObject *Sender);
    void __fastcall MultCompare(TObject *Sender);
    void __fastcall EffectCode(int GridCol, int min, int max,
                    AnsiString FactLetter,
                    int &startcol, int &endcol,int &novectors,TObject *Sender);
public:		// User declarations
     __fastcall TANCOVAFORM(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TANCOVAFORM *ANCOVAFORM;
//---------------------------------------------------------------------------
#endif
