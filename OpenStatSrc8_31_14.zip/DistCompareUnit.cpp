//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "dcdflib.h"
#include "cdflib.h"
#include "stdio.h"
#include <math.h>
#include "Printers.hpp"
#include "MainUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "functions.h"
#include "PlotUnit.h"
#include "NonPar.h"
#include "DistCompareUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

TDistCompareForm *DistCompareForm;
//---------------------------------------------------------------------------
__fastcall TDistCompareForm::TDistCompareForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::FormShow(TObject *Sender)
{
     int Yincr, Xincr;
     AnsiString astring;
     char valstr[5];
/*
     int ImageHi = PlotForm->Image1->Height;
     int ImageWide = PlotForm->Image1->Width;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,ImageWide,ImageHi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
*/     
     ParmBox->Visible = false;
     ImageHi = PlotForm->Image1->Height;
     ImageWide = PlotForm->Image1->Width;
     Xstart = ImageWide / 10;
     Xend = (ImageWide * 9) / 10;
     Ystart = ImageHi / 10;
     Yend = (ImageHi * 9) / 10;
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("FREQUENCY ANALYSIS BY BILL MILLER");
     FrmOutPut->RichOutPut->Lines->Add("");
     VarEdit->Text = "";
     CumGroup->ItemIndex = -1;
     TypeGroup->ItemIndex = -1;
     ProbGroup->ItemIndex = -1;
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::CumCompBtnClick(TObject *Sender)
{
     AnsiString Caption, Xlabel, Ylabel;
     char title[100];
     double s, xn, pr, ompr;

     selected = CumGroup->ItemIndex + 1;
     if (plottype == 3)
     {
         ProbCompBtnClick(this);
         return;
     }
     switch (selected)
     {
           case 1 : // binomial cdf
           {
                Which = 1;
                ParmEdit1->Text = "1";
                s = StrToFloat(ParmEdit1->Text);
                ParmEdit2->Text = IntToStr(NoCases);
                xn = StrToFloat(ParmEdit2->Text);
                xn = NoCases;
                pr = StrToFloat(ParmEdit3->Text);
                pr = 0.5;
                ompr = 1.0 - pr;
                cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Binary CDF (%5.2f,%5.2f)",s,xn);
                Caption = title;
                Xlabel = "Events Observed";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = xn / 100.0;
                for (int i = 0; i <= 100; i++) // plot upper part and lower part
                {
                    s = i * xincr;
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    Xplot[i] = s;
                    Yplot[i] = P;
                }
                if (plottype == 1)
                {
                    PlotForm->Image1->Canvas->Pen->Color = clRed;
                    PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                    PlotForm->Image1->Canvas->Pen->Color = clBlack;
                    PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 2 : // normal cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                double Mean = StrToFloat(ParmEdit2->Text);
                double StdDev = StrToFloat(ParmEdit3->Text);
                cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                Mean = StrToFloat(ParmEdit2->Text);
                StdDev = StrToFloat(ParmEdit3->Text);
                sprintf(title,"Normal CDF (%5.2f,%5.2f,%5.2f)",X,Mean,StdDev);
                Caption = title;
                Xlabel = "X";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = (6.0*StdDev) / 100.0;
                X = -3.0 * StdDev + Mean;
                for (int i = 0; i <= 100; i++) // plot from 0 to 100
                {
                    cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 3 : // chi-square cdf
           {
                Which = 1;
                ParmEdit1->Text = "1.0";
                if (ParmEdit2->Text == " ") ParmEdit2->Text = NoCases-1;
                X = StrToFloat(ParmEdit1->Text); // sample chi-square
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Chi-square CDF (%5.2f,%5.0f)",X,Y);
                Caption = title;
                Xlabel = "Chi-square Observed";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot chi-square from 0 to 100
                {
                    cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 1.0;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 4 : // student t cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample t
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                cdft(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = -4 to 4
                sprintf(title,"t CDF (t = %5.2f, d.f. = %5.0f)",X,Y);
//                PlotLabel->Caption = title;
                Caption = title;
                Xlabel = "t Observed";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = 8.0 / 100.0;
                X = -4.0;
                for (int i = 0; i <= 100; i++) // plot chi-square from 0 to 100
                {
                    cdft(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 5 : // F cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text); // sample F value
                double df1 = StrToFloat(ParmEdit2->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit3->Text); // deg. freedom denominator
                cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 100 in steps of 1
                sprintf(title,"F CDF (%5.2f,%5.0f,%5.0f)",X,df1,df2);
                Caption = title;
                Xlabel = "Observed F";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot F from 0 to 10
                {
                    cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 0.1;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 6 : // Poisson cdf
           {
                Which = 1;
                X = StrToFloat(ParmEdit1->Text);
                double Mean = StrToFloat(ParmEdit2->Text);
                cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Poisson CDF (%5.2f,%5.2f)",X,Mean);
                Caption = title;
                Xlabel = "X";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = (3 * Mean) / 100.0;
                X = 0.0;
                for (int i = 0; i <= 100; i++) // plot from 0 to 100
                {
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
           case 7 : // beta cdf
           {
                Which = 1;
                A = StrToFloat(ParmEdit1->Text);
                B = StrToFloat(ParmEdit2->Text);
                X = StrToFloat(ParmEdit3->Text);
                Y = 1.0 - X;
                cdfbet(&Which,&P,&Q,&X,&Y,&A,&B,&Status,&Bound);
                ParmEdit5->Text = FloatToStr(P);
                ParmEdit6->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Beta CDF (%5.2f,%5.2f)",A,B);
                Caption = title;
                Xlabel = "X";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = 0.01;
                for (int i = 0; i <= 100; i++) // plot upper part and lower part
                {
                    X = i * xincr;
                    Y = 1.0 - X;
                    cdfbet(&Which,&P,&Q,&X,&Y,&A,&B,&Status,&Bound);
                    Xplot[i] = X;
                    Yplot[i] = P;
                }
                if (plottype == 1)
                {
                   PlotForm->Image1->Canvas->Pen->Color = clRed;
                   PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                   PlotForm->Image1->Canvas->Pen->Color = clBlack;
                   PlotXY(Xplot, cumpcnt, Xlabel, Ylabel, Caption, true);
                }
                if (plottype == 2)
                   PlotXY(Yplot,cumpcnt,Xlabel,Ylabel,Caption,true);
                break;
           }
     }
     PlotForm->ShowModal();

     // clear the form
     PlotForm->Image1->Canvas->FillRect(Rect(0,0,ImageWide,ImageHi));
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::ProbCompBtnClick(TObject *Sender)
{
     AnsiString Xlabel, Ylabel, Caption;
     char title[101];

     selected = ProbGroup->ItemIndex + 1;
     switch (selected)
     {
           case 1 : // binomial probability
           {
               //                        N   (X)     (N-X)
               // binary probability = (   )P   (1-P)
               //                        X
                for (int i = 0; i < 100; i++)
                {
                        Xplot[i] = 0.0;
                        Yplot[i] = 0.0;
                }
                Caption = "Binary PDF";
                Xlabel = "Events Observed";
                Ylabel = "Prob.";
                Which = 4;
                ParmEdit4->Text = "";
                ParmEdit5->Text = "";
                double s = StrToFloat(ParmEdit1->Text);
                double xn = StrToFloat(ParmEdit2->Text);
                double pr = StrToFloat(ParmEdit3->Text);
                double ompr;
                double combins;
                combins = combos(ceil(s),ceil(xn));
                P = combins * pow(pr,s) * pow(1.0-pr,xn-s);
                Q = 1.0 - P;
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                double xincr = xn / 100.0;
                for (int i = 0; i < 100; i++)
                {
                    s = i * xincr;
                    Xplot[i] = s;
                    if (s > 0)
                    {
                        combins = combos(ceil(s),ceil(xn));
                        P = combins * pow(pr,ceil(s)) * pow(1.0-pr,ceil(xn)-ceil(s));
                    }
                    else P = 0;
                    Yplot[i] = P;
                }
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
//                PlotForm->ShowModal();
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, false);
                break;
           }
           case 2 : // normal probability
           {
                // h = (1 / (2 * PI)^.5 ) e^(-z^2 / 2)
                X = StrToFloat(ParmEdit1->Text);
                double Mean = StrToFloat(ParmEdit2->Text);
                double StdDev = StrToFloat(ParmEdit3->Text);
                double z = (X - Mean) / StdDev;
                Y = (1.0 / sqrt(2.0 * M_PI)) * exp(-(z*z)/2.0);
                ParmLabel4->Caption = "Height:";
                ParmEdit4->Text = FloatToStr(Y);
                ParmLabel5->Visible = false;
                ParmEdit5->Visible = false;
                z = -3.0;
                double xincr = 6.0 / 100;
                for (int i = 0; i <= 100; i++)
                {
                    z += xincr;
                    Y = (1.0 / sqrt(2.0 * M_PI)) * exp(-(z*z)/2.0);
                    Xplot[i] = z * StdDev + Mean;
                    Yplot[i] = Y;
                }
                Caption = "Normal PDF";
                Xlabel = "X value";
                Ylabel = "z Height";
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, true);
                for (int i = 0; i < 100; i++)
                {
                        Xplot[i] = 0.0;
                        Yplot[i] = 0.0;
                }
                
                break;
           }
           case 3 : // chi-square probability
           {
                //           n-2    -X
                //           ---    --
                //            2      2
                //       X         e
                //  h = -------------------
                //           n    ___
                //           --   |  |   n
                //           2    |    ( - )
                //        2       |      2
                //
//                PlotLabel->Visible = true;
                double num;
                double den;
                double LnGamma;
                double Gamma;
                double fraction;
                X = StrToFloat(ParmEdit1->Text);
                Y = StrToFloat(ParmEdit2->Text);
//                num = pow(X,(Y-2.0)/2.0) * exp(-X / 2.0);
//                fraction = Y / 2.0;
//                LnGamma = alngam(&fraction);
//                Gamma = exp(LnGamma);
//                den = pow(2.0,fraction) * Gamma;
//                P = num / den;
                cumchi(&X,&Y,&P,&Q);
//                Q = 1.0 - P;
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                X = 0.0;
                Caption = "Chi-square PDF";
                Xlabel = "Chi-square Observed";
                Ylabel = "Prob.";
                for (int i = 0; i < 100; i++)
                {
                    X += 1.0;
                    num = pow(X,(Y-2.0)/2.0) * exp(-X / 2.0);
                    fraction = Y / 2.0;
                    LnGamma = alngam(&fraction);
                    Gamma = exp(LnGamma);
                    den = pow(2.0,fraction) * Gamma;
                    P = num / den;
                    Xplot[i] = X;
                    Yplot[i] = P;
                }
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 4 : // student t probability
           {
//                PlotLabel->Visible = true;
                double fraction1;
                double fraction2;
                double term1;
                double term2;
                double term3;
                X = StrToFloat(ParmEdit1->Text); // t value
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                fraction1 = (Y+1.0) / 2.0;
                fraction2 = Y / 2.0;
                term1 = exp(alngam(&fraction1) - alngam(&fraction2));
                term2 = 1.0 / sqrt(Y * M_PI);
                term3 = 1.0 / pow((1.0 + (X * X / Y)),(Y+1.0)/2.0);
                P = term1 * term2 * term3;
                Q = 1.0 - P;
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                Caption = "t PDF";
                Xlabel = "t Observed";
                Ylabel = "Prob.";
                X = -5.0;
                double xincr = 10.0 / 100.0;
                for (int i = 0; i <= 100; i++)
                {
                    term3 = 1.0 / pow((1.0 + (X * X / Y)),(Y+1.0)/2.0);
                    P = term1 * term2 * term3;
                    Q = 1.0 - P;
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += xincr;
                }
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 5 : // F probability
           {
                //
                double LnGamma1;
                double LnGamma2;
                double LnGamma3;
                double num1;
                double num2;
                double den2;
                double df1;
                double df2;
                double term1;
                double fraction;
                X = StrToFloat(ParmEdit1->Text);
                df1 = StrToFloat(ParmEdit2->Text);
                df2 = StrToFloat(ParmEdit3->Text);
                num1 = (df1 + df2) / 2.0;
                LnGamma1 = alngam(&num1);
                fraction = df1 / 2.0;
                LnGamma2 = alngam(&fraction);
                fraction = df2 / 2.0;
                LnGamma3 = alngam(&fraction);
                term1 = exp(LnGamma1 - LnGamma2 - LnGamma3);
                fraction = pow( (df1/df2),(df1/2.0));
                num2 = pow(X,(df1-2.0)/2.0);
                den2 = pow( (1.0+(df1/df2)*X),(df1+df2)/2.0);
                P = term1 * fraction * (num2 / den2);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(1.0-P);
                X = 0.0;
                for (int i = 0; i < 100; i++)
                {
                    num1 = (df1 + df2) / 2.0;
                    LnGamma1 = alngam(&num1);
                    fraction = df1 / 2.0;
                    LnGamma2 = alngam(&fraction);
                    fraction = df2 / 2.0;
                    LnGamma3 = alngam(&fraction);
                    term1 = exp(LnGamma1 - LnGamma2 - LnGamma3);
                    fraction = pow( (df1/df2),(df1/2.0));
                    num2 = pow(X,(df1-2.0)/2.0);
                    den2 = pow( (1.0+(df1/df2)*X),(df1+df2)/2.0);
                    P = term1 * fraction * (num2 / den2);
                    Xplot[i] = X;
                    Yplot[i] = P;
                    X += 0.1;
                }
                Caption = "F PDF";
                Ylabel = "Prob.";
                Xlabel = "F Value";
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, true);
                break;
           }
           case 6 : // Poisson probability
           {
                // h = (Mean^X / /x!) e^-Mean I(x)
                double Mean = StrToFloat(ParmEdit2->Text);
                double Nobs = StrToFloat(ParmEdit1->Text);
                Which = 1;
                X = Nobs;
//                double FactX = 1;
//                for (int i = 1; i <= X; i++) FactX *= (double) i;
//                double h = exp(-Mean) * pow(Mean,X) / FactX;
                cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(1.0 - P);
                ParmLabel4->Caption = "Prob:";
                P = 0.0;
                X = 0;
                double xincr = range / 100.0;
                for (int i = 0; i <= 100; i++)
                {
                    X = ceil(min + (double) i * xincr);
                    double FactX = 1;
                    for (int i = 1; i <= X; i++) FactX *= (double) i;
                    double h = exp(-Mean) * pow(Mean,X) / FactX;
                    Yplot[i] = h;
                    Xplot[i] = X; // observed[i];
                }
                Caption = "POISSON PDF";
                Xlabel = "X value";
                Ylabel = "Prob.";
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, false);
//                PlotForm->ShowModal();
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, false);
                break;
           }
           case 7 : // beta probability
           {
                A = StrToFloat(ParmEdit1->Text);
                B = StrToFloat(ParmEdit2->Text);
                X = StrToFloat(ParmEdit3->Text);
                Y = 1.0 - X;
                double result;
                ParmEdit5->Text = FloatToStr(result);
                // plot distribution for X = 0 to 1 in steps of .01
                sprintf(title,"Beta PDF (%5.2f, %5.2f)",A,B);
                Caption = title;
                Xlabel = "X Values";
                Ylabel = "Prob.";
//                PlotLabel->Visible = true;
                double xincr = 0.01;
                double xmax = 0.0;
                double LnGammaA;
                double GammaA;
                double LnGammaB;
                double GammaB;
                double LnGammaAB;
                double GammaAB;
                double AplusB = A + B;
                double Beta;
                X = 0.0;
                for (int i = 1; i < 100; i++) // plot pdf
                {
                    X += xincr;
                    Y = 1.0 - X;
                    LnGammaA = alngam(&A);
                    GammaA = exp(LnGammaA);
                    LnGammaB = alngam(&B);
                    GammaB = exp(LnGammaB);
                    LnGammaAB = alngam(&AplusB);
                    GammaAB = exp(LnGammaAB);
                    Beta = GammaAB / (GammaA * GammaB);
                    result = Beta * pow(Y,(B-1.0)) * pow(X,(A-1.0));
                    Xplot[i-1] = X;
                    Yplot[i-1] = result;
                    if (result > xmax) xmax = result;
                }
                PlotForm->Image1->Canvas->Pen->Color = clRed;
                PlotXY(Xplot, Yplot, Xlabel, Ylabel, Caption, true);
                PlotForm->Image1->Canvas->Pen->Color = clBlack;
                PlotXY(Xplot, sampprob, Xlabel, Ylabel, Caption, true);
                ParmLabel7->Caption = "Dx Y";
                ParmEdit7->Text = FloatToStr(xmax);
                break;
           }
     }
     PlotForm->ShowModal();

     // clear the form
     PlotForm->Image1->Canvas->FillRect(Rect(0,0,ImageWide,ImageHi));
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::CumGroupClick(TObject *Sender)
{
     selected = CumGroup->ItemIndex + 1;
     switch (selected)
     {
           case 1 : // binomial cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "N Trials:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = NoCases;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Even Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "P";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Q";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "0.5";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 0;
                break;
           }
           case 2 : // normal cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "X value:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = mean;
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = mean;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Std. Dev.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = stddev;
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 1;
                break;
           }
           case 3 : // chi-square cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Chi-squared:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = NoCases / 2.0;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = false;
                ParmEdit5->Visible = false;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 2;
                break;
           }
           case 4 : // student t cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "t Value:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = false;
                ParmEdit5->Visible = false;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 3;
                break;
           }
           case 5 : // F cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "F Statistic";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Num.Deg.F.:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "5.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Den.Deg.F.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "10.0";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 4;
                break;
           }
           case 6 : // Poisson cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "";
                ParmLabel3->Visible = false;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = false;
                ParmLabel4->Caption = "Prob.:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 5;
                break;
           }
           case 7 : // beta cdf
           {
                Which = 1;
                ParmBox->Visible = true;
                ParmLabel1->Caption = "A = ";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "B = ";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "1.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "X = ";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Y = ";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "P = ";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "Q = ";
                ParmLabel6->Visible = true;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = true;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 6;
                break;
           }
           case 8 : // Gamma cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Gamma value:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Shape Parm.:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "2.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Scale Parm.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.1";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 7;
                break;
           }
           case 9 : // negative binomial cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "N Trials:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Even Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "P";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Q";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "0.5";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 8;
                break;
           }
           case 10 : // non-central chi-square cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Non-Central Chi-squared:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "1.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Centrality:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 9;
                break;
           }
           case 11 : // non-central F cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Non-Central F:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Num.Deg.F.:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "1.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Den.Deg.F.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "5.0";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Centrality:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "1-Prob.";
                ParmLabel6->Visible = true;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = true;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                ProbGroup->ItemIndex = 10;
                break;
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::ProbGroupClick(TObject *Sender)
{
     CumGroupClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TDistCompareForm::VarListClick(TObject *Sender)
{
     AnsiString CellVal, VarName, outline;
     char lineout[101];
     int j, k, Ncases, disttype;
     int index = VarList->ItemIndex;
     double theor;
     double zx;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     plottype = TypeGroup->ItemIndex + 1;
     disttype = CumGroup->ItemIndex + 1;
     VarEdit->Text = VarList->Items->Strings[index];
     CellVal = VarEdit->Text;
     VarName = CellVal;
     Ncases = 0;
     col = 0;
     for (j = 1; j <= NoVariables; j++)
     {
           if (MainForm->Grid->Cells[j][0] == CellVal)
           {
              col = j;
              outline = "Frequency Analysis for " + CellVal;
              FrmOutPut->RichOutPut->Lines->Add(outline);
              break;
           }
     }
     if (col == 0)
     {
        ShowMessage("ERROR! Select a variable to analyze.");
        return;
     }
     //result = VarTypeChk(col,0);
     //if (result == 1) return;

        // Get min, max, mean, stddev values for this variable
        min = 1.0e32;
        max = -1.0e32;
        mean = 0.0;
        stddev = 0.0;
        for (j = 1; j <= NoCases; j++)
        {
            if (! ValidValue) continue;
            value = StrToFloat(MainForm->Grid->Cells[col][j]);
            //result = GetValue(j, col,intvalue, dblvalue, strvalue);
            //if (result != 0) value = 0.0;
            //else value = dblvalue;
            mean += value;
            stddev += value * value;
            if (value > max) max = value;
            if (value < min) min = value;
            Ncases++;
        }
        stddev = stddev - ((mean * mean) / Ncases);
        stddev = sqrt(stddev / (Ncases-1));
        mean /= Ncases;
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(lineout,"MEAN = %8.3f, STANDARD DEVIATION = %8.3f",mean,stddev);
        FrmOutPut->RichOutPut->Lines->Add(lineout);
        FrmOutPut->RichOutPut->Lines->Add("");
        if (disttype == 1) // binomial
        {
           ParmEdit1->Text = "1";
           ParmEdit2->Text = Ncases;
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "0.5";
        }
        if (disttype == 2) // normal
        {
           ParmEdit2->Text = mean;
           ParmEdit3->Text = stddev;
        }
        if (disttype == 3) // chi-square
        {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = Ncases / 2.0;
           ParmEdit3->Text = "";
           ParmEdit4->Text = "";
        }
        if (disttype == 4) // t distribution
        {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = Ncases-1;
           ParmEdit3->Text = "";
           ParmEdit4->Text = "";
        }
        if (disttype == 5) // F distribution
        {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = Ncases / 2;
           ParmEdit3->Text = Ncases;
           ParmEdit4->Text = "";
           ParmEdit5->Text = "";
        }
        if (disttype == 6) //Poison distribution
        {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = mean;
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "";
        }
        if (disttype == 7) // beta distribution
        {
           ParmEdit1->Text = Ncases / 2;
           ParmEdit2->Text = Ncases;
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "";
        }

        range = 6 * stddev;
        min = mean - (3 * stddev);
        max = mean + (3 * stddev);
        incrsize = range / 100;
        nints = 100;
        GetDblVecMem(freq,nints + 2);
        GetDblVecMem(pcnt,nints+2);
        GetDblVecMem(cumpcnt,nints+2);
        GetDblVecMem(pcntrank,nints+2);
        GetDblVecMem(cumfreq,nints+2);
        GetDblVecMem(XValue,nints+2);
        GetDblVecMem(sampprob,nints+2);
        GetDblVecMem(theoretic,nints+2);
        GetDblVecMem(observed,nints+2);
        // Get frequency of cases in each interval
        for (j = 0; j < nints + 1; j++)
        {
            freq[j] = 0.0;
            pcnt[j] = 0.0;
            cumpcnt[j] = 0.0;
            pcntrank[j] = 0.0;
            cumfreq[j] = 0.0;
            XValue[j] = 0.0;
            theoretic[j] = 0.0;
        }
        for (j = 1; j <= NoCases; j++)
        {
           if (!ValidValue(j,col)) continue;
           value = StrToFloat(MainForm->Grid->Cells[col][j]);
           for (k = 1; k <= nints; k++)
           {
              if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
              {
                 freq[k-1]++;
                 observed[k-1] = value;
              }
           }
        }
        for (k = 0; k <= nints; k++) sampprob[k] = freq[k] / Ncases;
        for (j = 0; j < nints+1; j++) XValue[j] = min + (j * incrsize);

        // get cumulative frequencies and percents to midpoints
        cumfreq[0] = freq[0];
        pcnt[0] = freq[0] / Ncases;
        pcntrank[0] = (freq[0] / 2.0) / Ncases;
        for (k = 2; k <= nints; k++)
        {
           cumfreq[k-1] = cumfreq[k-2] + freq[k-1];
           pcnt[k-1] = freq[k-1] / Ncases;
           cumpcnt[k-1] = cumfreq[k-1] / Ncases;
           pcntrank[k-1] = (cumfreq[k-2] + freq[k-1] / 2.0) / Ncases;
        }
        for (k = 1; k <= nints; k++)
        {
           if (cumpcnt[k-1] > 0.0) zx = inversez(cumpcnt[k-1]);
           if (cumpcnt[k-1] == 0.0) zx = -3.0;
           if (cumpcnt[k-1] == 1.0) zx = 3.0;
           zx = zx * stddev + mean;
           theoretic[k] = zx;
        }

        // Print results if elected
        if (PrintChk->Checked)
        {
            FrmOutPut->RichOutPut->Lines->Add("    FROM  UP TO     FREQ.   PCNT    CUM.FREQ.  CUM.PCNT. %ILE RANK  NORM.X");
            FrmOutPut->RichOutPut->Lines->Add("");
            for (k = 1; k <= nints; k++)
            {
               sprintf(lineout,"%8.2f%8.2f%8.0f%8.2f  %8.2f  %8.2f  %8.2f  %8.2f",
               min+(k-1) * incrsize, // from
               min + k * incrsize,   // to
               freq[k-1],            // freq
               pcnt[k-1],            // percent
               cumfreq[k-1],         // cumulative freqency
               cumpcnt[k-1],         // cumulative percent to midpoint
               pcntrank[k-1],       // percentile rank
               theoretic[k-1]);       // theoretic normal X
               FrmOutPut->RichOutPut->Lines->Add(lineout);
            }
            FrmOutPut->ShowModal();
        }
}
//---------------------------------------------------------------------------
void __fastcall TDistCompareForm::ExitBtnClick(TObject *Sender)
{
     ClearDblVecMem(observed);
     ClearDblVecMem(theoretic);
     ClearDblVecMem(sampprob);
     ClearDblVecMem(XValue);
     ClearDblVecMem(cumfreq);
     ClearDblVecMem(pcntrank);
     ClearDblVecMem(cumpcnt);
     ClearDblVecMem(pcnt);
     ClearDblVecMem(freq);
}
//---------------------------------------------------------------------------

void __fastcall TDistCompareForm::ComputeBtnClick(TObject *Sender)
{
    CumCompBtnClick(this);
}
//---------------------------------------------------------------------------

void TDistCompareForm::PlotXY(double *Xplot, double *Yplot, AnsiString Xlabel,
                           AnsiString Ylabel, AnsiString Caption, bool continuous)
{
     int Yincr, Xincr, xprop, yprop, TextHi;
     int LabelWide = PlotForm->Image1->Canvas->TextWidth(Xlabel);
     double Yrange, Ymin, Ymax, Xrange, Xmin, Xmax, Xstep, Ystep;
     char valstr[95];
     AnsiString astring;

     PlotForm->Image1->Canvas->TextOutA(Xstart-5,Ystart-15,Ylabel);
     PlotForm->Image1->Canvas->TextOutA((Xend-Xstart)/2- LabelWide / 2,Yend+ 20,Xlabel);

     // draw axis lines
     PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
     PlotForm->Image1->Canvas->LineTo(Xend,Yend);
     PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
     PlotForm->Image1->Canvas->LineTo(Xstart,Ystart);

     // get min, max and range of Y
     Ymin = 1.0e300;
     Ymax = -1.0e300;
     for (int i = 0; i < 100; i++)
     {
         if (Yplot[i] > Ymax) Ymax = Yplot[i];
         if (Yplot[i] < Ymin) Ymin = Yplot[i];
     }
     Yrange = Ymax - Ymin;
     Ystep = Yrange / 10;
     // get min, max and range of X
     Xmin = 1.0e300;
     Xmax = -1.0e300;
     for (int i = 0; i < 100; i++)
     {
         if (Xplot[i] > Xmax) Xmax = Xplot[i];
         if (Xplot[i] < Xmin) Xmin = Xplot[i];
     }
     Xrange = Xmax - Xmin;
     Xstep = Xrange / 10;

     // create y axis values
     Yincr = (Yend - Ystart) / 10;
     for (int i = 0; i < 11; i++) // print Y axis values
     {
         int place = Yend - (i * Yincr);
         float value = Ymin + (Ystep * i);
         sprintf(valstr,"%4.3f",value);
         astring = valstr;
         TextHi = PlotForm->Image1->Canvas->TextHeight(astring);
         PlotForm->Image1->Canvas->TextOutA(Xstart-25,place-TextHi,astring);
     }

     // create x axis values
     Xincr = (Xend - Xstart) / 10;
     for (int i = 0; i < 11; i++) // print x axis
     {
         int place = Xstart + (i * Xincr);
         float value = Xmin + (i * Xstep);
         sprintf(valstr,"%4.2f",value);
         astring = valstr;
         PlotForm->Image1->Canvas->TextOutA(place,Yend + 10,astring);
     }

     // plot the x, y values
     xprop = Xstart + ceil(((Xplot[0]-Xmin) / Xrange) * (Xend - Xstart));
     yprop = Yend - ceil(((Yplot[0]-Ymin) / Yrange) * (Yend - Ystart));
     if (continuous) PlotForm->Image1->Canvas->MoveTo(xprop,yprop);
     else PlotForm->Image1->Canvas->MoveTo(xprop,Yend);
     for (int i = 0; i < 99; i++)
     {
         xprop = Xstart + ceil(((Xplot[i]-Xmin) / Xrange) * (Xend - Xstart));
         yprop = Yend - ceil(((Yplot[i]-Ymin) / Yrange) * (Yend - Ystart));
//         sprintf(valstr,"%5.3f %5.3f %5d %5d",Xplot[i],Yplot[i],xprop,yprop);
         if (continuous) PlotForm->Image1->Canvas->LineTo(xprop,yprop);
         else
         {
             PlotForm->Image1->Canvas->MoveTo(xprop,Yend);
             PlotForm->Image1->Canvas->LineTo(xprop,yprop);
         }
     }
}
//---------------------------------------------------------------------------

void __fastcall TDistCompareForm::TypeGroupClick(TObject *Sender)
{
        plottype = TypeGroup->ItemIndex + 1;
        if (plottype == 3) ProbGroup->Visible = true;
        else ProbGroup->Visible = false;
}
//---------------------------------------------------------------------------

