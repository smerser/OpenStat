//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "OutPut.h"
#include "EvalGenrUnit.h"
#include <stdio.h>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmEvalGen *FrmEvalGen;
//---------------------------------------------------------------------------
__fastcall TFrmEvalGen::TFrmEvalGen(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmEvalGen::FormShow(TObject *Sender)
{
    ProjNameEdit->Text = "";
    Author1Edit->Text = "";
    Author2Edit->Text = "";
    Author3Edit->Text = "";
    CompanyMemo->Clear();
    DateEdit->Text = "";
    DiagnosticBtn->Checked = false;
    FormativeBtn->Checked = false;
    SummativeBtn->Checked = false;
    CIPPBtn->Checked = false;
    ScrivenBtn->Checked = false;
    ExceptionBtn->Checked = false;
    CauseBtn->Checked = false;
    AnecdotalBtn->Checked = false;
    ChaosBtn->Checked = false;
    OtherBtn->Checked = false;
    PersonnelChk->Checked = false;
    MaterialsChk->Checked = false;
    ProcessChk->Checked = false;
    ProductsChk->Checked = false;
    FacilitiesChk->Checked = false;
    SafetyChk->Checked = false;
    EnvironmentChk->Checked = false;
    SystemsChk->Checked = false;
    OtherChk->Checked = false;
    PersonnelReqChk->Checked = false;
    FacilitiesReqChk->Checked = false;
    EquipReqChk->Checked = false;
    TimeReqChk->Checked = false;
    SoftwareReqChk->Checked = false;
    AccessReqChk->Checked = false;
    OtherReqChk->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmEvalGen::ResetBtnClick(TObject *Sender)
{
    FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmEvalGen::GenerateBtnClick(TObject *Sender)
{
    char outline[81];
    AnsiString text;

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Paragraph->LeftIndent = 20;
    FrmOutPut->RichOutPut->Paragraph->FirstIndent = 10;
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Paragraph->Alignment = taCenter;
    sprintf(outline,"%s",ProjNameEdit->Text.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%s",Author1Edit->Text.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (Author2Edit->Text != "")
    {
        sprintf(outline,"%s",Author2Edit->Text.c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    if (Author3Edit->Text != "")
    {
        sprintf(outline,"%s",Author3Edit->Text.c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    for (int i = 0; i < CompanyMemo->Lines->Count; i++)
    {
        sprintf(outline,"%s",CompanyMemo->Lines->Strings[i].c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"%s",DateEdit->Text.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    // Project Description
    FrmOutPut->RichOutPut->Paragraph->Alignment = taLeftJustify;
    text = "PROJECT DESCRIPTION";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Purpose:";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Goals:";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");

    // type of evaluation
    text = "General Type of Evaluation:";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    if (DiagnosticBtn->Checked)
    {
        text = "     This project may be considered a 'Diagnostic' type of evaluation.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "In this type, the evaluation attempts to identify problems within the targeted areas.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "It does NOT attempt to impliment corrections but will suggest possible solutions.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (FormativeBtn->Checked)
    {
        text = "     This project may be considered a 'Formative' type of evaluation.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "In this type, the evaluation is used to produce changes in the targeted area.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "As soon as the evaluation identifies a problem, solutions are proposed and are";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "implimented as soon as is practical.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (SummativeBtn->Checked)
    {
        text = "     This project may be considered a 'Summative' type of evaluation.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "In this type, the evaluation attempts to describe the level or degree";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "to which goals have been attained and identify areas where improvement";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        text = "is desirable.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }

    // Model of evaluation
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Evaluation Model Adopted for the Project";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    if (CIPPBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'CIPP' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (ScrivenBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Scriven' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (ExceptionBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Exeption' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (CauseBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Causal' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (AnecdotalBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Anecdotal' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (ChaosBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Chaos' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (OtherBtn->Checked)
    {
        text = "     The primary model employed in this evaluation is labeled the 'Eclectic' model.";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
        FrmOutPut->RichOutPut->Lines->Add("");
    }

    // targets
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Targets of the Evaluation";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "     The following have been targeted for specific evaluation in this project.";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "If it appears that other areas are potentially related to the target areas in a critical";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "manner, the evaluation targets may be re-negotiated to include those areas.";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());

    FrmOutPut->RichOutPut->Paragraph->Numbering = nsBullet;
    FrmOutPut->RichOutPut->Lines->Add("");
    if (PersonnelChk->Checked)
    {
        text = "     Personel";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (MaterialsChk->Checked)
    {
        text = "     Materials/Inputs";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (ProcessChk->Checked)
    {
        text = "     Processes";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (ProductsChk->Checked)
    {
        text = "     Products/Outcomes";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (FacilitiesChk->Checked)
    {
        text = "     Facilities";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (SafetyChk->Checked)
    {
        text = "     Safety";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (EnvironmentChk->Checked)
    {
        text = "     Environmental";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (SystemsChk->Checked)
    {
        text = "     Systems";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (OtherChk->Checked)
    {
        text = "     Other";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }

    // Resource Requirements
    FrmOutPut->RichOutPut->Paragraph->Numbering = nsNone;
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Resource Requirements of the Project";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "     To achieve the goals of this evaluation, one or more resources are required.";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "Specifically, the following resources and/or privelages will be required.  If the";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "contractor cannot provide them, the will be acquired by the project team and the costs";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "billed to the project.";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
//    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Paragraph->Numbering = nsBullet;
    FrmOutPut->RichOutPut->Lines->Add("");
    if (PersonnelReqChk->Checked)
    {
        text = "     Personnel:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (FacilitiesReqChk->Checked)
    {
        text = "     Space:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (EquipReqChk->Checked)
    {
        text = "     Equipment:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (TimeReqChk->Checked)
    {
        text = "     Time:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (SoftwareReqChk->Checked)
    {
        text = "     Software:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (AccessReqChk->Checked)
    {
        text = "     Access to:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }
    if (OtherReqChk->Checked)
    {
        text = "     Additional Items Required:";
        FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    }

    // Cost analysis
    FrmOutPut->RichOutPut->Paragraph->Numbering = nsNone;
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Project Cost Summary";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "ITEM OR SERVICE      UNITS IN     NO. UNITS     CHARGE";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    text = "-------------------  -----------  ------------  -------";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");

    // Results section
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Results of the Evaluation";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Personnel Contacts and Interactions:";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Data Collection and Analysis Results";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Summary of Qualitative Observations Recorded";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "General Findings of the Evaluation";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Implications for Action";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Limitations Which May Qualify Findings and Implications";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    text = "Other Outcomes Unanticipated in the Evaluation Plan";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    // summary
    text = "Project Summary";
    FrmOutPut->RichOutPut->Lines->Add(text.c_str());
    FrmOutPut->RichOutPut->Lines->Add("");

    FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------
