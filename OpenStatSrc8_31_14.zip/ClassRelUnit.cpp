//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h";
#include "functions.h"
#include "MatrixUnit.h"
#include "OutPut.h";
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "stdio.h"
#include "ClassRelUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TClassRelForm *ClassRelForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TClassRelForm::TClassRelForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TClassRelForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(Trim(MainForm->Grid->Cells[i][0]));
     ClassVarEdit->Text = "";
     NoItemsEdit->Text = "";
     NoCatsEdit->Text = "";
     for (int i = 0; i < ClassGrid->ColCount; i++)
         for (int j = 0; j < ClassGrid->RowCount; j++)
             ClassGrid->Cells[i][j] = "";
     ClassGrid->ColCount = 2;
     ClassGrid->RowCount = 2;
     ClassGrid->Cells[0][0] = "CLASS";
     ClassGrid->Cells[1][0] = "CUTOFF";
     InBtn->Visible = true;
     OutBtn->Visible = false;
     NoTestedEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TClassRelForm::ComputeBtnClick(TObject *Sender)
{
    double A, B, XP, SDP, XK, SDK;
    int KM1;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    N = StrToInt(NoItemsEdit->Text);
    M = NoCases;
    NoTestedEdit->Text = IntToStr(M);
    K = StrToInt(NoCatsEdit->Text);
    for (int i = 1; i <= K; i++) L[i] = StrToInt(ClassGrid->Cells[1][i]);

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("ESTIMATES OF DECISION RELIABILITY AND THEIR STANDARD ERRORS IN");
    FrmOutPut->RichOutPut->Lines->Add("MASTERY TESTING BASED ON THE BETA-BINOMIAL MODEL");
    sprintf(outline,"Test Score Analyzed = %s",ClassVarEdit->Text.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);

    XBAR = 0.0;
    SD = 0.0;
    for (int i = 1; i <= NoVariables; i++)
        if (MainForm->Grid->Cells[i][0] == ClassVarEdit->Text) col = i;
    //result = VarTypeChk(col,0);
    //if (result == 1) return;
    for (int i = 1; i <= NoCases; i++)
    {
        X = StrToFloat(MainForm->Grid->Cells[col][i]);
        //result = GetValue(i,col,intvalue,dblvalue,strvalue);
        //if (result == 1) X = 0.0;
        //else X = dblvalue;
        XBAR += X;
        SD += (X * X);
    }
    SD = SD - ((XBAR * XBAR) / NoCases);
    SD = SD / (NoCases - 1.0);
    SD = sqrt(SD);
    XBAR = XBAR / NoCases;
    KM1 = K - 1;
    sprintf(outline,"No. of Items = %d, No. of Categories = %d, No. of Cases = %d",
            N, K, M);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Test Mean = %8.3f, Standard Deviation = %8.3f",XBAR, SD);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    FrmOutPut->RichOutPut->Lines->Add("CUTOFF SCORES");
    for (int I = 1; I <= KM1; I++)
    {
        sprintf(outline,"%d = %5d",I,L[I]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    double KR21 = N / (N - 1.0) * (1.0 - XBAR * (N - XBAR) / (N * SD * SD));
    if (KR21 <= 0.0)  //IF(F.GT.0.) GOTO 5
    {
       FrmOutPut->RichOutPut->Lines->Add("NON-POSITIVE ESTIMATE KR21.");
       FrmOutPut->RichOutPut->Lines->Add("MOMENT ESTIMATES FOR ALPHA AND BETA DO NOT EXIST.");
       FrmOutPut->RichOutPut->Lines->Add("COMPUTATIONS DISCONTINUED FOR THIS CASE.");
       goto cleanup;
    }
    A = (-1.0 + 1.0 / KR21) * XBAR;
    B = -A + N / KR21 - N;
    KAPPA(N,A,B,K,L,M,XP,SDP,XK,SDK);
    FrmOutPut->RichOutPut->Lines->Add("Output Data Are:");
    sprintf(outline,"ALPHA = %10.5f, BETA = %10.5f, KR21 = %10.5f",A, B, KR21);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Cut Score = %9d, RAW AGREEMENT INDEX P = %8.5f",L[1],XP);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"STANDARD ERROR OF P = %8.5f",SDP);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"KAPPA INDEX = %8.4f, STANDARD ERROR OF KAPPA = %8.5f",XK,SDK);
    FrmOutPut->RichOutPut->Lines->Add(outline);

cleanup:
    FrmOutPut->ShowModal();
    delete[] L;
    delete[] F;
    delete[] CF;
    delete[] XA;
    delete[] XB;
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::KAPPA(int N, double &A, double &B, int K,
                int *L, int M, double &XP, double &SDP, double &XK,
                double &SDK)
{
      double P, PC, A1, A2, A3, VA, VB, VAB, TWO, VKP, VP, DPA, DPB, DPCA;
      double DPCB, BFZ, DBFA, DBFB, DSA, DSB, SUMBF, DKA, DKB;
      int IM1, ICUT, LL, LU;
      int ITEMP = 0;

      GetDblVecMem(F,N+2);
      GetDblVecMem(CF,N+2);
      GetDblVecMem(XA,N+2);
      GetDblVecMem(XB,N+2);

      TWO = 2.0;
      L[K] = N + 1;

      NEHY(N,A,B,F,CF);
      VARAB(N,A,B,VA,VB,VAB,M,F,XA,XB);
      ZERLAB(N,A,B,XA,XB,F);

      int index = L[1];
      PC = CF[index] * CF[index];
      DPCA = TWO * CF[index] * XA[index];
      DPCB = TWO * CF[index] * XB[index];

      for (int I = 2; I <= K; I++) //DO 5 I=2,K
      {
          IM1 = I - 1;
          A1 = CF[L[I]] - CF[L[IM1]];
          PC = PC + A1 * A1;
          DPCA = DPCA + TWO * A1 * (XA[L[I]] - XA[L[IM1]]);
          DPCB = DPCB + TWO * A1 * (XB[L[I]] - XB[L[IM1]]);
      } // 5
      if (K > 2) goto pos9; // IF(K.GT.2) GOTO 9

//     OTHERWISE THERE ARE TWO CATEGORIES.

      ICUT = L[1] - 1;
      if ((2 * L[1]) <= N) goto pos6; // IF(2*L(1).LE.N) GOTO 6
      ICUT = N - L[1];
      BF(N,ITEMP,ICUT,B,A,BFZ,DBFB,DBFA,DSB,DSA,SUMBF);
      A1 = CF[L[2]] - CF[L[1]];
      P = 1.0 - 2.0 * (A1 - SUMBF);
      DPA = -2.0 * (XA[L[2]] - XA[L[1]] - DSA);
      DPB = -2.0 * (XB[L[2]] - XB[L[1]] - DSB);
      goto pos15; // GOTO 15
pos6:
      BF(N,ITEMP,ICUT,A,B,BFZ,DBFA,DBFB,DSA,DSB,SUMBF);
      A1 = CF[L[1]];
      P = 1.0 - 2.0 * (A1 - SUMBF);
      DPA = -2.0 * (XA[L[1]] - DSA);
      DPB = -2.0 * (XB[L[1]] - DSB);
      goto pos15; // GOTO 15
pos9:
      DPA = 0.0;
      DPB = 0.0;
      P = 0.0;

      for (int I = 1; I <= K; I++) // DO 10 I=1,K
      {
          LL = 0;
          if (I > 1) LL = L[I-1]; // IF(I.GT.1) LL=L(I-1)
          LU = L[I] - 1;
          BF(N,LL,LU,A,B,BFZ,DBFA,DBFB,DSA,DSB,SUMBF);
          P = P + SUMBF;
          DPA = DPA + DSA;
          DPB = DPB + DSB;
      } // 10
pos15:
      A1 = 1.0 - PC;
      A2 = 1.0 - P;
      A3 = A1 * A1;
      DKA = (DPA * A1 - DPCA * A2) / A3;
      DKB = (DPB * A1 - DPCB * A2) / A3;

      VKP = VA * DKA * DKA + VB * DKB * DKB + 2 * VAB * DKA * DKB;
      VP = VA * DPA * DPA + VB * DPB * DPB + 2 * VAB * DPA * DPB;
      SDK = sqrt(VKP); // **.5
      XP = P;
      SDP = sqrt(VP); // **.5
      XK = (P - PC) / A1;
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::NEHY(int N, double &A, double &B, double *F,
            double *CF)
{
      double Z1, Z2;
      int K, KP1, KP2, IP1;

      Z1 = (double)N + B;
      Z2 = Z1 + A;
      K = 0;
      F[1] = 1.0;
      for (int I = 1; I <= N; I++) //DO 5 I=1,N
      {
          F[1] = F[1] * (Z1 - (double)I) / (Z2 - (double)I);
      } //5
pos10:
      KP1 = K + 1;
      KP2 = K + 2;
      F[KP2] = F[KP1] * (double)(N-K) * (A + (double)K) /
              ((double)KP1 * (Z1 - (double)KP1));
      K = K + 1;
      if ((K-N) < 0) goto pos10; // IF(K-N) 10,15,15
pos15:
      CF[1] = F[1];
      for (int I = 1; I <= N; I++) // DO 20 I=1,N
      {
          IP1 = I + 1;
          CF[IP1] = CF[I] + F[IP1];
      } // 20
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::BF(int N, int &LL, int &LU, double &A, double &B,
              double &BFZ, double &DBFA, double &DBFB, double &DSA,
              double &DSB, double &SUMBF)
{
      double Z1, Z2, Z1M1, XA, XB, DN, AAHOLD, XAHOLD, XBHOLD, DLL, AA, T, X, Y;
      int N2, IR;

      N2 = N + N;
      IR = LU - LL + 1;
      DN = (double)N;
      Z1 = (double)N2 + B;
      Z1M1 = Z1 - 1.0;
      Z2 = Z1 + A;
      DLL = (double)LL;

      if (LL != 0) goto pos10; //IF(LL.NE.0) GOTO 10

      AA = 1.0;
      XA = 0.0;
      XB = 0.0;

      for (int I = 1; I <= N2; I++) //DO 5 I=1,N2
      {
          T = (double) I;
          AA = AA * (Z1 - T) / (Z2 - T);
          XA = XA - 1.0 / (Z2 - T);
          XB = XB + 1.0 / (Z1 - T);
      } // 5

      XB = XB + XA;

      goto pos15; //GOTO 15
pos10:
      X = DLL - 1.0;
      Y = DLL - 1.0;
      AA = BFZ * (DN - X) * (A + X + Y) / ((X + 1.0) * (Z1M1 - X - Y));
      XA = DBFA + 1.0 / (A + X + Y);
      XB = DBFB - 1.0 / (Z1M1 - X - Y);

      X = LL;
      AA = AA * (DN - Y) * (A + X + Y) / ((Y + 1.0) * (Z1M1 - X - Y));
      XA = XA + 1.0 / (A + X + Y);
      XB = XB - 1.0 / (Z1M1 - X - Y);
pos15:
      SUMBF = AA;
      DSA = XA * AA;
      DSB = XB * AA;

      if (IR == 1) goto pos90; // IF(IR.EQ.1) GOTO 90

      AAHOLD = AA;
      XAHOLD = XA;
      XBHOLD = XB;

      for (int I = 2; I <= IR; I++) //DO 50 I=2,IR
      {
          X = DLL + (double)(I-2);
          Y = DLL;
          AA = AAHOLD * (DN - X) * (A + X + Y) / ((X + 1.0) * (Z1M1 - X - Y));
          XA = XAHOLD + 1.0 / (A + X + Y);
          XB = XBHOLD - 1.0 / (Z1M1 - X - Y);

          DSA = DSA + 2.0 * XA * AA;
          DSB = DSB + 2.0 * XB * AA;
          SUMBF = SUMBF + 2.0 * AA;

          AAHOLD = AA;
          XAHOLD = XA;
          XBHOLD = XB;

          X = X + 1.0;
          for (int J = 2; J <= I; J++) //DO 50 J=2,I
          {
              Y = DLL + (double)J - 2.0;

              AA = AA * (DN - Y) * (A + X + Y) / ((Y + 1.0) * (Z1M1 - X - Y));
              XA = XA + 1.0 / (A + X + Y);
              XB = XB - 1.0 / (Z1M1 - X - Y);

              if (I == J) goto pos40; // IF(I.EQ.J) GOTO 40
              SUMBF = SUMBF + 2.0 * AA;
              DSA = DSA + 2.0 * XA * AA;
              DSB = DSB + 2.0 * XB * AA;
              goto pos50; //GOTO 50

pos40:
              SUMBF = SUMBF + AA;
              DSA = DSA + XA * AA;
              DSB = DSB + XB * AA;
          }
pos50:
      } // 50

pos90:
      BFZ = AA;
      DBFA = XA;
      DBFB = XB;
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::ZERLAB(int N, double &A, double &B, double *XA,
                double *XB, double *F)
{
      double Z1, Z2, ONE;
      int NP1, IP1, IX, IM1;

      ONE = 1.0;
      XA[1] = 0.0;
      XB[1] = 0.0;
      Z1 = (double)N + B;
      Z2 = Z1 + A;
      NP1 = N + 1;
      for (int I = 1; I <= N; I++) //DO 5 I=1,N
      {
          XA[1] = XA[1] - ONE / (Z2 - (double)I);
          XB[1] = XB[1] + ONE / (Z1 - (double)I);
      } // 5
      XB[1] = XB[1] + XA[1];
      for (int I = 1; I <= N; I++) //DO 10 I=1,N
      {
          IP1 = I + 1;
          IX = I - 1;
          XA[IP1] = XA[I] + ONE / (A + (double)IX);
          XB[IP1] = XB[I] - ONE / (Z1 - (double)I);
      } // 10
      XA[1] = XA[1] * F[1];
      XB[1] = XB[1] * F[1];
      for (int I = 2; I <= NP1; I++) // DO 30 I=2,NP1
      {
          IM1 = I - 1;
          XA[I] = XA[IM1] + XA[I] * F[I];
          XB[I] = XB[IM1] + XB[I] * F[I];
      }
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::VARAB(int N, double &A, double &B, double &VA,
                double &VB, double &VAB, int M, double *F, double *DA,
                double *DB)
{
      double B11, B12, B22, D;
      int NP1;

      DERLAB(N,A,B,DA,DB);
      B11 = 0.0;
      B12 = 0.0;
      B22 = 0.0;
      NP1 = N + 1;
      for (int I = 1; I <= NP1; I++) // DO 15 I=1,NP1
      {
          B11 = B11 + DA[I] * DA[I] * F[I];
          B12 = B12 + DA[I] * DB[I] * F[I];
          B22 = B22 + DB[I] * DB[I] * F[I];
      } // 15
      B11 = B11 * M;
      B12 = B12 * M;
      B22 = B22 * M;
      D = B11 * B22 - B12 * B12;
      VA = B22 / D;
      VB = B11 / D;
      VAB = -B12 / D;
}
//---------------------------------------------------------------------

void __fastcall TClassRelForm::DERLAB(int N, double A, double B,
                 double *DA, double *DB)
{
      double Z1, Z2, ONE;
      int NP1, IX, IP1;

      ONE = 1.0;
      DA[1] = 0.0;
      DB[1] = 0.0;
      Z1 = (double)N + B;
      Z2 = Z1 + A;

      for (int I = 1; I <= N; I++) //DO 5 I=1,N
      {
          DA[1] = DA[1] - ONE / (Z2 - (double)I);
          DB[1] = DB[1] + ONE / (Z1 - (double)I);
      } // 5
      DB[1] = DB[1] + DA[1];
      for (int I = 1; I <= N; I++) //DO 10 I=1,N
      {
          IP1 = I + 1;
          IX = I - 1;
          DA[IP1] = DA[I] + ONE / (A + (double)IX);
          DB[IP1] = DB[I] - ONE / (Z1 - (double)I);
      } // 10
}
//---------------------------------------------------------------------------

void __fastcall TClassRelForm::NoCatsEditExit(TObject *Sender)
{
     if (NoCatsEdit->Text == "") return;
     int K = StrToInt(NoCatsEdit->Text);
     ClassGrid->RowCount = K + 1;
     GetIntVecMem(L,K+1);
     for (int i = 1; i <= K; i++) ClassGrid->Cells[0][i] = IntToStr(i);
     ClassGrid->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TClassRelForm::InBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     ClassVarEdit->Text = VarList->Items->Strings[index];
     OutBtn->Visible = true;
     InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TClassRelForm::OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ClassVarEdit->Text);
     ClassVarEdit->Text = "";
     InBtn->Visible = true;
     OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TClassRelForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TClassRelForm::NoCatsEditKeyPress(TObject *Sender,
      char &Key)
{
      if (Key == 13) NoCatsEditExit(this);
}
//---------------------------------------------------------------------------

void __fastcall TClassRelForm::NoItemsEditKeyPress(TObject *Sender,
      char &Key)
{
      if (Key == 13) NoCatsEdit->SetFocus();
}
//---------------------------------------------------------------------------

