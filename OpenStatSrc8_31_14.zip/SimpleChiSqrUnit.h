//---------------------------------------------------------------------------

#ifndef SimpleChiSqrUnitH
#define SimpleChiSqrUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TSimpleChiSqr : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TLabel *Label1;
        TEdit *NcatsEdit;
        TStringGrid *ObservedGrid;
        TStringGrid *ExpectedGrid;
        TLabel *Label2;
        TLabel *Label3;
        TButton *ComputeBtn;
        TButton *ResetBtn;
        TButton *ReturnBtn;
        TStringGrid *ChiSqrGrid;
        TLabel *Label4;
        TEdit *TotChiSqrEdit;
        TLabel *Label5;
        TEdit *ProbEdit;
        void __fastcall NcatsEditExit(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        int NoCats;

public:		// User declarations
        __fastcall TSimpleChiSqr(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSimpleChiSqr *SimpleChiSqr;
//---------------------------------------------------------------------------
#endif
