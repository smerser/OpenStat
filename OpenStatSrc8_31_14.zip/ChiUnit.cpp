//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "ChiUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TChiUnitForm *ChiUnitForm;
//---------------------------------------------------------------------------
__fastcall TChiUnitForm::TChiUnitForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TChiUnitForm::FormShow(TObject *Sender)
{
        DF1Edit->Text = "";
        CumEdit->Text = "";
        PropGreater->Text = "";
        QEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TChiUnitForm::ComputeBtnClick(TObject *Sender)
{
        double cumprob;
        double probgreater;
        double Q;
        int DF1;

        Q = StrToFloat(QEdit->Text);
        DF1 = StrToInt(DF1Edit->Text);
        cumprob = chisquaredprob(Q,DF1);
        probgreater = 1.0 - cumprob;
        CumEdit->Text = FloatToStr(cumprob);
        PropGreater->Text = FloatToStr(probgreater);
}
//---------------------------------------------------------------------------
