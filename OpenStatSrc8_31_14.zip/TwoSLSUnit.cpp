//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "TwoSLSUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTwoSLSForm *TwoSLSForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TTwoSLSForm::TTwoSLSForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     Explanatory->Clear();
     Instrumental->Clear();
     DepVarEdit->Text = "";
     ProxyRegShowChk->Checked = false;
     DepIn->Visible = true;
     DepOut->Visible = false;
     ExpIn->Visible = true;
     ExpOut->Visible = false;
     InstIn->Visible = true;
     InstOut->Visible = false;
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);    
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::DepInClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOut->Visible = true;
     DepIn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::DepOutClick(TObject *Sender)
{
     if (DepVarEdit->Text == "") return;
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::ExpInClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              Explanatory->Items->Add(VarList->Items->Strings[i]);
         }
         i++;
     }
     ExpOut->Visible = true;
     if (VarList->Items->Count < 1) ExpIn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::ExpOutClick(TObject *Sender)
{
     int index = Explanatory->ItemIndex;
     Explanatory->Items->Delete(index);
     ExpIn->Visible = true;
     if (Explanatory->Items->Count < 1) ExpOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::InstInClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              Instrumental->Items->Add(VarList->Items->Strings[i]);
         }
         i++;
     }
     InstOut->Visible = true;
     if (VarList->Items->Count < 1) InstIn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoSLSForm::ComputeBtnClick(TObject *Sender)
{
     int DepCol, *ExpCols, *InstCols, *ProxCols, NoInst, NoExp, NoProx, Noindep;
     int DepProx, *IndepCols, *ProxSrcCols, NCases, col, counter;
     AnsiString *ExpLabels, *InstLabels, *ProxLabels, *RowLabels, *ProxSrcLabels;
     char outstr[11];
     double R2, F, stderrest, X, Y, *Means, *Variances, *StdDevs, *BWeights;
     double *BetaWeights, *BStdErrs, *Bttests, *tprobs;
     double **ProxVals;
     bool errorcode, PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs;
     bool found;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     if (ProxyRegShowChk->Checked)
     {
        PrintDesc = true;
        PrintCorrs = true;
        PrintInverse = false;
        PrintCoefs = true;
        SaveCorrs = false;
     }
     else
     {
        PrintDesc = false;
        PrintCorrs = false;
        PrintInverse = false;
        PrintCoefs = false;
        SaveCorrs = false;
     }
     Means = new double[NoVariables+2];
     Variances = new double[NoVariables+2];
     StdDevs = new double[NoVariables+2];
     BWeights = new double[NoVariables+2];
     BetaWeights = new double[NoVariables+2];
     BStdErrs = new double[NoVariables+2];
     Bttests = new double[NoVariables+2];
     tprobs = new double[NoVariables+2];
     ExpLabels = new AnsiString[NoVariables+2];
     ExpCols = new int[NoVariables+2];
     InstLabels = new AnsiString[NoVariables+2];
     InstCols = new int[NoVariables+2];
     ProxCols = new int[NoVariables];
     ProxLabels = new AnsiString[NoVariables];
     IndepCols = new int[NoVariables];
     RowLabels = new AnsiString[NoVariables];
     ProxSrcCols = new int[NoVariables];
     ProxSrcLabels = new AnsiString[NoVariables];
     GetDblMatMem(ProxVals,NoCases,NoVariables);

     // Get variables to analyze
     NCases = NoCases;
     NoInst = Instrumental->Items->Count;
     NoExp = Explanatory->Items->Count;
     if (NoInst < NoExp)
     {
        ShowMessage("The no. of Instrumental must equal or exceed the Explanatory");
        goto cleanup;
     }
     for (int i = 0; i < NoVariables; i++)
     {
         if (MainForm->Grid->Cells[i+1][0] == DepVarEdit->Text)
         {
                DepCol = i+1;
                //result = VarTypeChk(DepCol,0);
                //if (result == 1) goto cleanup;
         }
         for (int j = 0; j < NoExp; j++)
         {
             if (MainForm->Grid->Cells[i+1][0] == Explanatory->Items->Strings[j])
             {
                ExpCols[j] = i+1;
                //result = VarTypeChk(i+1,0);
                //if (result == 1) goto cleanup;
                ExpLabels[j] = Explanatory->Items->Strings[j];
             }
         } // next j
         for (int j = 0; j < NoInst; j++)
         {
             if (MainForm->Grid->Cells[i+1][0] == Instrumental->Items->Strings[j])
             {
                InstCols[j] = i+1;
                //result = VarTypeChk(i+1,0);
                //if (result == 1) goto cleanup;
                InstLabels[j] = Instrumental->Items->Strings[j];
             }
         } // next j
     } // next i

     // Get prox variables which are the variables common to exp and inst lists
     NoProx = 0;
     for (int i = 0; i < NoInst; i++)
     {
         for (int j = 0; j < NoExp; j++)
         {
             if (ExpLabels[j] == InstLabels[i])
             {
                ProxLabels[NoProx] = "P_" + InstLabels[i];
                ProxSrcLabels[NoProx] = InstLabels[i];
                ProxCols[NoProx] = InstCols[i];
                NoProx++;
             }
         }
     }

     // Output Parameters of the Analysis
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("FILE: " + MainForm->FileNameEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Dependent = " + DepVarEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("Explanatory Variables:");
     for (int i = 0; i < NoExp; i++) FrmOutPut->RichOutPut->Lines->Add(ExpLabels[i]);
     FrmOutPut->RichOutPut->Lines->Add("Instrumental Variables:");
     for (int i = 0; i < NoInst; i++) FrmOutPut->RichOutPut->Lines->Add(InstLabels[i]);
     FrmOutPut->RichOutPut->Lines->Add("Proxy Variables:");
     for (int i = 0; i < NoProx; i++) FrmOutPut->RichOutPut->Lines->Add(ProxLabels[i]);
     FrmOutPut->RichOutPut->Lines->Add("");

     // Compute the prox regressions for the instrumental variables
     for (int i = 0; i < NoProx; i++)
     {
         col = NoVariables + 1;
         NewVar(col,false); // create column for proxy (predicted values)
         DictionaryForm->DGrid->Cells[1][col] = ProxLabels[i];
         MainForm->Grid->Cells[col][0] = ProxLabels[i];
         ProxSrcCols[i] = col;
         DepProx = ProxCols[i];
         Noindep = 0;
         for (int j = 0; j < NoInst; j++)
         {
             if (DepProx != InstCols[j]) // don't include the prox itself!
             {
                IndepCols[Noindep] = InstCols[j];
                RowLabels[Noindep] = InstLabels[j];
                Noindep++;
             }
         }
         for (int j = 0; j < NoExp; j++)
         {
             found = false;
             for (int k = 0; k < NoProx; k++)
                 if (ExpCols[j] == ProxCols[k]) found = true; // don't include the proxs themselves
             if (!found)
             {
                IndepCols[Noindep] = ExpCols[j];
                RowLabels[Noindep] = ExpLabels[j];
                Noindep++;
             }
         }
         IndepCols[Noindep] = DepProx;
         FrmOutPut->RichOutPut->Lines->Add("Analysis for " + ProxLabels[i]);
         FrmOutPut->RichOutPut->Lines->Add("Dependent: " + ProxSrcLabels[i]);
         FrmOutPut->RichOutPut->Lines->Add("Independent: ");
         for (int j = 0; j < Noindep; j++) FrmOutPut->RichOutPut->Lines->Add(RowLabels[j]);
         FrmOutPut->ShowModal();
         FrmOutPut->RichOutPut->Clear();
         PrintDesc = true;
         PrintCorrs = true;
         PrintInverse = false;
         PrintCoefs = true;
         SaveCorrs = false;

         mreg(Noindep,IndepCols,DepProx,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
         // save predicted scores at column = NoVariables and in ProxVals array
         for (int j = 1; j <= NoCases; j++)
         {
             Y = 0.0;
             for (int k = 0; k < Noindep; k++)
             {
                 col = IndepCols[k];
                 X = StrToFloat(MainForm->Grid->Cells[col][j]);
                 Y = Y + BWeights[k] * X;
             }
             Y = Y + BWeights[Noindep];  // intercept
             col = NoVariables;
             sprintf(outstr,"%12.5f",Y);
             MainForm->Grid->Cells[col][j] = outstr;
         } // next case
     } // next proxy
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     // Compute the OLS using the Prox values and explanatory
     Noindep = 0;
     counter = 0;
     for (int i = 0; i < NoExp; i++)
     {
         for (int j = 0; j < NoInst; j++)
         {
             if (ExpLabels[i] == InstLabels[j]) // use proxy
             {
                IndepCols[Noindep] = ProxSrcCols[counter];
                RowLabels[Noindep] = ProxLabels[counter];
                counter++;
                break;
             }
             else
             {
                 IndepCols[Noindep] = ExpCols[i];
                 RowLabels[Noindep] = ExpLabels[i];
             }
         }
         Noindep++;
     }
     PrintDesc = true;
     PrintCorrs = true;
     PrintInverse = false;
     PrintCoefs = true;
     SaveCorrs = false;
     IndepCols[Noindep] = DepCol;
     mreg(Noindep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     if (SaveItChk->Checked)
     {
        PredictIt(IndepCols, Noindep+1, Means, StdDevs, BetaWeights, stderrest, Noindep);
     }

     // cleanup
cleanup:
     ClearDblMatMem(ProxVals,NoCases);
     delete[] ProxSrcLabels;
     delete[] ProxSrcCols;
     delete[] RowLabels;
     delete[] IndepCols;
     delete[] ProxLabels;
     delete[] ProxCols;
     delete[] InstCols;
     delete[] InstLabels;
     delete[] ExpCols;
     delete[] ExpLabels;
     delete[] tprobs;
     delete[] Bttests;
     delete[] BStdErrs;
     delete[] BetaWeights;
     delete[] BWeights;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
}
//---------------------------------------------------------------------------

void __fastcall TTwoSLSForm::PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars)
{
   // routine obtains predicted raw and standardized scores and their
   // residuals.  It is assumed that the dependent variable is last in the
   // list of variable column pointers stored in the ColNoSelected vector.

   int col, i, j, k, Index, IndexX, IndexY;
   double predicted, zpredicted, z1, z2, resid, Term1, Term2, residsqr;
   double StdErrPredict, t95, Hi95, Low95;
   char astring[121];

   // Get the z predicted score and its residual
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "Pred.z";
   NewVar(col,true);
   DictionaryForm->DGrid->Cells[1][col] = "Pred.z";
   col = NoVariables + 1;
   MainForm->Grid->Cells[col][0] = "zResid.";
   NewVar(col,true);
   DictionaryForm->DGrid->Cells[1][col] = "zResid.";
   MainForm->Grid->ColCount += 2;
   for (i = 1; i <= NoCases; i++)
   {
       zpredicted = 0.0;
       for (j = 0; j < NoIndepVars; j++)
       {
           k = ColNoSelected[j];
           z1 = (atof(MainForm->Grid->Cells[k][i].c_str()) -
                               Means[j]) / StdDevs[j];
           zpredicted = zpredicted + (z1 * BetaWeights[j]);
       }
       sprintf(astring,"%8.4f",zpredicted);
       MainForm->Grid->Cells[col-1][i] = astring;
       Index = ColNoSelected[NoVars-1];
       z2 = atof(MainForm->Grid->Cells[Index][i].c_str());
       z2 = (z2 - Means[NoVars-1]) / StdDevs[NoVars-1]; // z score
       sprintf(astring,"%8.4f",z2 - zpredicted);  // z residual
       MainForm->Grid->Cells[col][i] = astring;
   }

   // Get raw predicted and residuals
   col = NoVariables + 1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "Pred.Raw";
   MainForm->Grid->Cells[col][0] = "Pred.Raw";
   // calculate raw predicted scores and store in grid at col
   for (i = 1; i <= NoCases; i++)
   {   // predicted raw obtained from previously predicted z score
       predicted = atof(MainForm->Grid->Cells[col-2][i].c_str()) *
                            StdDevs[NoVars-1] + Means[NoVars-1];
       sprintf(astring,"%8.3f",predicted);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // Calculate residuals of predicted raw scores }
   col = NoVariables +1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "RawResid.";
   MainForm->Grid->Cells[col][0] = "RawResid.";

   for (i = 1; i <= NoCases; i++)
   {
       Index = ColNoSelected[NoVars-1];
       resid = atof(MainForm->Grid->Cells[col-1][i].c_str()) -
                           atof(MainForm->Grid->Cells[Index][i].c_str());
       sprintf(astring,"%8.3f",resid);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // get square of raw residuals
   col = NoVariables + 1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "ResidSqr";
   MainForm->Grid->Cells[col][0] = "ResidSqr";
   for (i = 1; i <= NoCases; i++)
   {
       residsqr = atof(MainForm->Grid->Cells[col-1][i].c_str());
       residsqr = residsqr * residsqr;
       sprintf(astring,"%8.3f",residsqr);
       MainForm->Grid->Cells[col][i] = astring;
   }
}
//---------------------------------------------------------------------

