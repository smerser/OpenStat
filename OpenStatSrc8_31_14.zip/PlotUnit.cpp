//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Printers.hpp"
#include "PlotUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPlotForm *PlotForm;

//---------------------------------------------------------------------------
__fastcall TPlotForm::TPlotForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPlotForm::PrintBtnClick(TObject *Sender)
{
       TPrinter *Prntr = Printer();
       Prntr->Orientation = poPortrait;

       TRect r = Rect(20,20,Prntr->PageWidth-20,Prntr->PageHeight / 2 + 20);
       Prntr->BeginDoc();
       Prntr->Canvas->StretchDraw(r, Image1->Picture->Bitmap);
       Prntr->EndDoc();
}
//---------------------------------------------------------------------------
void __fastcall TPlotForm::SaveBtnClick(TObject *Sender)
{
     SaveDialog1->Filter = "BitMap File *.BMP|*.BMP";
     SaveDialog1->FilterIndex = 1;
     SaveDialog1->DefaultExt = "BMP";
     if (SaveDialog1->Execute())
     {
        Image1->Picture->SaveToFile(SaveDialog1->FileName);
     }
}
//---------------------------------------------------------------------------
void __fastcall TPlotForm::FormResize(TObject *Sender)
{
     Invalidate();   
}
//---------------------------------------------------------------------------

void __fastcall TPlotForm::ReturnBtnClick(TObject *Sender)
{
     // clear the form
     int ImageWide = Image1->Width;
     int ImageHi = Image1->Height;
     PlotForm->Image1->Canvas->FillRect(Rect(0,0,ImageWide,ImageHi));
        
}
//---------------------------------------------------------------------------

