//---------------------------------------------------------------------------
#ifndef DiscManoH
#define DiscManoH
//---------------------------------------------------------------------------
#endif
int oldcolcnt;
void Discriminant(void);
void PlotPts(double **RawCMat, double *Constants, int *ColNoSelected,
    int NoSelected, int noroots, int NoCases, int GroupVar,
    int NoGrps, int *NoInGrp);
void Classify(double **PooledW, double **GrpMeans, int *ColNoSelected,
             int NoSelected, int NoCases, int GroupVar, int NoGrps,
             int *NoInGrp, AnsiString *VarLabels);
void ClassIt(double **PooledW, int *ColNoSelected, double **GrpMeans,
             double *Roots,int noroots, int GroupVar, int NoGrps,
             int *NoInGrp, int NoSelected, int NoCases, double **RawCMat,
             double *Constants);
void plotxy(double *Xpoints, double *Ypoints, double Xmax, double Xmin,
            double Ymax, double Ymin, char *xTitle, char *yTitle,
            AnsiString *PtLabels, int N);



