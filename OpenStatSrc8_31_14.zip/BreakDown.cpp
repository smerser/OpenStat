//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "DataFuncs.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "BreakDown.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmBrkDwn *FrmBrkDwn;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TFrmBrkDwn::TFrmBrkDwn(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::VarInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::VarOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox1->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox1->Items->Strings[index];
          ListBox2->Items->Add(cellstring);
     }
     ListBox1->Clear();
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::FormShow(TObject *Sender)
{
     AnsiString cellstring;

     ListBox1->Clear();
     ListBox2->Clear();
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
     AnovaChkBox->Checked = false;
     DepVarEdit->Text = "";
     VarOutBtn->Enabled = false;
     ContInBtn->Enabled = true;
     ContOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::ResetBtnClick(TObject *Sender)
{
     FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::CancelBtnClick(TObject *Sender)
{
     FrmBrkDwn->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::OKBtnClick(TObject *Sender)
{
 // do the breakdown procedure here!
    int *Minimum, *Maximum, *levels, *displace, *subscript, *Selected, *Freq;
    double *mean, *variance, *Stddev, *SS;
    int i, j, index, NoSelected, ListSize, dependentvar, X, length_array;
    int ptr1, ptr2, sum, grandsum;
    double xsumtotal, xsqrtotal, grandsumx, grandsumx2, value, SD;
    double SST, SSW, SSB, MSW, MSB, F, ProbF, DF1, DF2;
    AnsiString cellstring;
    char outline[81];
    char valstr[81];
    bool dataread;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    // Use form to get variables
    NoSelected = FrmBrkDwn->ListBox2->Items->Count;

    // Get column no. of dependent variable
    dependentvar = 0;
    cellstring = FrmBrkDwn->DepVarEdit->Text;
    for (i = 0; i < NoVariables; i++)
        if (cellstring == MainForm->Grid->Cells[i+1][0])dependentvar = i+1;
    if ((NoSelected == 0) || (dependentvar == 0))
    {
        ShowMessage("ERROR!  Variables not correctly selected.");
        return;
    }
    //result = VarTypeChk(dependentvar,0);
    //if (result == 1) return;
    
    // Allocate heap
    try  {
        Minimum = new int[NoSelected];
        Maximum = new int[NoSelected];
        levels = new int[NoSelected+1];
        displace = new int[NoSelected+1];
        subscript = new int[NoSelected+1];
        Selected = new int[NoSelected+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Breakdown.","ERROR!",MB_OK);
        exit (-1);
    }

    // Get selected variables
    for (i = 0; i < NoSelected; i++)
    {
        cellstring = ListBox2->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0]) Selected[i] = j+1;
        }
/*        result = VarTypeChk(Selected[i],1);
        if (result == 1)
        {
                delete[] Selected;
                delete[] subscript;
                delete[] displace;
                delete[] levels;
                delete[] Maximum;
                delete[] Minimum;
                return;
        }
*/
    }
    Selected[NoSelected] = dependentvar;
    ListSize = NoSelected;

    // Get maximum and minimum levels in each variable
    for (i = 0; i < ListSize; i++)
    {
        index = Selected[i];
        Minimum[i] = floor(StrToFloat(MainForm->Grid->Cells[index][1]));
        //result = GetValue(1,index,intvalue,dblvalue,strvalue);
        //if (result == 1) Minimum[i] = 0;
        //else Minimum[i] = intvalue;
        Maximum[i] = Minimum[i];
        for (j = 0; j < NoCases; j++)
        {
            if (ValidRecord(j+1,Selected,NoSelected+1))
            {
                X = floor(StrToFloat(MainForm->Grid->Cells[index][j+1]));
                //result = GetValue(j+1, index, intvalue, dblvalue, strvalue);
                //if (result != 0) X = 0;
                //X = intvalue;
                if (X < Minimum[i]) Minimum[i] = X;
                if (X > Maximum[i]) Maximum[i] = X;
            }
        }
    }

    // Calculate number of levels for each variable
    for (i = 1; i <= ListSize; i++) levels[i-1] = Maximum[i-1] - Minimum[i-1] + 1;

    displace[ListSize-1] = 1;
    for (i = ListSize-1; i >= 1; i--)
    {
        displace[i-1] = levels[i] * displace[i];
    }

    // Now, tabulate
    length_array = 1;
    for (i = 1; i <= ListSize; i++) length_array *= levels[i-1];

    //Allocate space for Freq
    try  {
        Freq = new int[length_array+1];
        mean = new double[length_array+1];
        variance = new double[length_array+1];
        Stddev = new double[length_array+1];
        SS = new double[length_array+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Breakdown.","ERROR",MB_OK);
        exit (-1);
    }

    // initialize values
    for (i = 0; i <= length_array; i++)
    {
        mean[i] = 0.0;
        variance[i] = 0.0;
        SS[i] = 0.0;
    }

    // initialize frequency cells
    for (i = 0; i <= length_array; i++) Freq[i] = 0;

    for (i = 0; i < NoCases; i++)
    {
        dataread = false;
        if (ValidRecord(i+1,Selected,NoSelected+1))
        {
            for (j = 0; j < ListSize; j++)
            {
                index = Selected[j];
                X = floor(StrToFloat(MainForm->Grid->Cells[index][i+1]));
                //result = GetValue(i+1, index, intvalue, dblvalue, strvalue);
                //if (result != 0) X = 0;
                //else X = intvalue;
                X = X - Minimum[j] + 1;
                subscript[j] = X;
                dataread = true;
            }
        }
        if (dataread)
        {
           j = Index_Pos(subscript,displace,ListSize);
           Freq[j]++;
           index = dependentvar;
           value = StrToFloat(MainForm->Grid->Cells[index][i+1]);
           //result = GetValue(i+1, index, intvalue, dblvalue, strvalue);
           //if (result != 0) goto cleanup;
           //value = dblvalue;
           mean[j] += value;
           variance[j] += value * value;
        }
    }

    // setup the output
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("BREAKDOWN ANALYSIS PROGRAM");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("VARIABLE SEQUENCE FOR THE BREAKDOWN:");
    for (i = 0; i < ListSize; i++)
    {
        index = Selected[i];
        sprintf(outline,"%-10s (Variable %3d) Lowest level = %2d Highest level = %2d",
                MainForm->Grid->Cells[index][0].c_str(),i+1, Minimum[i], Maximum[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();

    // Breakdown the data
    ptr1 = ListSize - 1;
    ptr2 = ListSize;
    for (i = 0; i < ListSize; i++) subscript[i] = 1;
    sum = 0;
    xsumtotal = 0.0;
    xsqrtotal = 0.0;
    grandsum = 0;
    grandsumx = 0.0;
    grandsumx2 = 0.0;

Label1:
    index = Index_Pos(subscript,displace,ListSize);
    FrmOutPut->RichOutPut->Lines->Add("Variable levels: ");
    for (i = 0; i < ListSize; i++)
    {
        j = Selected[i];
        sprintf(outline,"%-10s level = %3d",MainForm->Grid->Cells[j][0].c_str(),
                Minimum[i] + subscript[i] - 1);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    sum = sum + Freq[index];
    xsumtotal += mean[index];
    xsqrtotal += variance[index];
    FrmOutPut->RichOutPut->Lines->Add("Freq.     Mean     Std. Dev.");
    sprintf(outline,"%3d",Freq[index]);
    if (Freq[index] > 0)
    {
        sprintf(valstr,"     %8.3f ",mean[index] / double(Freq[index]));
        strcat(outline,valstr);
    }
    else strcat(outline,"    ********  ");
    if (Freq[index] > 1)
    {
        SS[index] = variance[index];
        variance[index] = (variance[index] - (mean[index] * mean[index] /
           double(Freq[index]))) / double(Freq[index] - 1);
        Stddev[index] = sqrt(variance[index]);
        sprintf(valstr,"%8.3f ",Stddev[index]);
        strcat(outline,valstr);
    }
    else strcat(outline, "********");
    FrmOutPut->RichOutPut->Lines->Add(outline);

    subscript[ptr2-1]++;
    if (subscript[ptr2-1] <= levels[ptr2-1]) goto Label1;
    sprintf(outline,"Number of observations accross levels = %3d",sum);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (sum > 0)
    {
        sprintf(outline,"Mean accross levels = %8.3f", xsumtotal / double(sum));
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    else FrmOutPut->RichOutPut->Lines->Add("Mean accross levels = ********");
    if (sum > 1)
    {
        SD = xsqrtotal - (xsumtotal * xsumtotal / double(sum));
        SD = SD / double(sum - 1);
        SD = sqrt(SD);
        sprintf(outline,"Std. Dev. accross levels = %8.3f",SD);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    else FrmOutPut->RichOutPut->Lines->Add("Std. Dev. accross levels = *******");
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    grandsum += sum;
    grandsumx += xsumtotal;
    grandsumx2 += xsqrtotal;
    sum = 0;
    xsumtotal = 0.0;
    xsqrtotal = 0.0;
    if (ptr1 < 1) goto NextStep;
    subscript[ptr1-1]++;
    if (subscript[ptr1-1] <= levels[ptr1-1]) goto Label4;

Label3:
    ptr1--;
    if (ptr1 < 1) goto NextStep;
    if (subscript[ptr1-1] > levels[ptr1-1]) goto Label3;
    subscript[ptr1-1]++;
    if (subscript[ptr1-1] > levels[ptr1-1]) goto Label3;

Label4:
    for (i = ptr1+1; i <= ListSize; i++) subscript[i-1] = 1;
    ptr1 = ListSize - 1;
    if (ptr1 < 1) goto NextStep;
    goto Label1;

NextStep:
    sprintf(outline,"Grand number of observations accross all categories = %3d",grandsum);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (grandsum > 0)
    {
       sprintf(outline,"Overall Mean = %8.3f",grandsumx / double(grandsum));
       FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    if (grandsum > 1)
    {
       SD = sqrt((grandsumx2 - (grandsumx * grandsumx) / double(grandsum)) / double(grandsum - 1));
       sprintf(outline,"Overall standard deviation = %8.3f",SD);
       FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // Do ANOVA's if requested
    if (AnovaChkBox->Checked)
    {
        FrmOutPut->RichOutPut->Lines->Add("ANALYSES OF VARIANCE SUMMARY TABLES");
        FrmOutPut->RichOutPut->Lines->Add("");
        ptr1 = ListSize - 1;
        ptr2 = ListSize;
        for (i = 1; i <= ListSize; i++) subscript[i-1] = 1;
        SSB = 0.0;
        SSW = 0.0;
        MSB = 0.0;
        MSW = 0.0;
        grandsum = 0;
        grandsumx = 0.0;
        grandsumx2 = 0.0;
        DF1 = 0.0;
        DF2 = 0.0;
FirstOne:
        index = Index_Pos(subscript,displace,ListSize);
        if (Freq[index] > 0)
        {
           FrmOutPut->RichOutPut->Lines->Add("Variable levels: ");
           for (i = 0; i < ListSize; i++)
           {
              j = Selected[i];
              sprintf(outline,"%-10s level = %3d",MainForm->Grid->Cells[j][0].c_str(),
                Minimum[i] + subscript[i] - 1);
              FrmOutPut->RichOutPut->Lines->Add(outline);
           }
           FrmOutPut->RichOutPut->Lines->Add("");
           // build sumsof squares for this set
           DF1 += 1.0;
           DF2 += double(Freq[index] - 1);
           grandsum += Freq[index];
           grandsumx += mean[index];
           grandsumx2 += SS[index];
           SSW += SS[index] - (mean[index] * mean[index] / double(Freq[index]));
        }
        subscript[ptr2-1]++;
        if (subscript[ptr2-1] <= levels[ptr2-1]) goto FirstOne;
        if ((grandsum > 0.0) && (DF1 > 1) && (DF2 > 1) && (SSW > 0.0))
        {
           // build and show anova table
           SST = grandsumx2 - (grandsumx * grandsumx / double(grandsum));
           SSB = SST - SSW;
           DF1 -= 1.0; // no. of groups - 1
           MSB = SSB / DF1;
           MSW = SSW / DF2;
           F = MSB / MSW;
           ProbF = ftest(DF1,DF2,F);
           FrmOutPut->RichOutPut->Lines->Add("SOURCE    D.F.        SS        MS        F       Prob.>F");
           sprintf(outline,"GROUPS    %2d        %8.2f  %8.2f  %8.3f  %6.4f",
            int(DF1),SSB,MSB,F,ProbF);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"WITHIN    %2d        %8.2f  %8.2f", int(DF2),SSW,MSW);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"TOTAL     %2d        %8.2f",grandsum-1,SST);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           FrmOutPut->ShowModal();
           FrmOutPut->RichOutPut->Clear();
        }
        else
        {
            FrmOutPut->RichOutPut->Lines->Add("Insufficient data for ANOVA");
            FrmOutPut->ShowModal();
            FrmOutPut->RichOutPut->Clear();
        }

        SSB = 0.0;
        SSW = 0.0;
        MSB = 0.0;
        MSW = 0.0;
        grandsum = 0;
        grandsumx = 0.0;
        grandsumx2 = 0.0;
        DF1 = 0.0;
        DF2 = 0.0;
        if (ptr1 < 1) goto LastStep;
        subscript[ptr1-1]++;
        if (subscript[ptr1-1] <= levels[ptr1-1]) goto ThirdOne;
SecondOne:
        ptr1--;
        if (ptr1 < 1) goto LastStep;
        if (subscript[ptr1-1] > levels[ptr1-1]) goto SecondOne;
        subscript[ptr1-1]++;
        if (subscript[ptr1-1] > levels[ptr1-1]) goto SecondOne;
ThirdOne:
        for (i = ptr1+1; i <= ListSize; i++) subscript[i-1] = 1;
        ptr1 = ListSize - 1;
        if (ptr1 < 1) goto LastStep;
        goto FirstOne;
LastStep:
        // do anova for all cells
        FrmOutPut->RichOutPut->Lines->Add("ANOVA FOR ALL CELLS");
        FrmOutPut->RichOutPut->Lines->Add("");
        SST = 0.0;
        SSW = 0.0;
        DF2 = 0.0;
        grandsumx = 0.0;
        grandsum = 0;
        for (i = 1; i <= length_array; i++)
        {
            if (Freq[i] > 0)
            {
               SST += SS[i];
               grandsum += Freq[i];
               grandsumx += mean[i];
               SSW += SS[i] - (mean[i] * mean[i] / double(Freq[i]));
               DF1 = DF1 + 1.0;
               DF2 += double(Freq[i] - 1);
            }
        }
        if ( (DF1 > 1.0) && (DF2 > 1.0) && (SSW > 0.0))
        {
           SST = SST - (grandsumx * grandsumx / double(grandsum));
           SSB = SST - SSW;
           DF1 = double(length_array - 1);
           MSB = SSB / DF1;
           MSW = SSW / DF2;
           F = MSB / MSW;
           ProbF = ftest(DF1, DF2, F);
           FrmOutPut->RichOutPut->Lines->Add("SOURCE    D.F.        SS        MS        F       Prob.>F");
           sprintf(outline,"GROUPS    %2d        %8.2f  %8.2f  %8.3f  %6.4f",
            int(DF1),SSB,MSB,F,ProbF);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"WITHIN    %2d        %8.2f  %8.2f",
            int(DF2),SSW,MSW);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"TOTAL     %2d        %8.2f",grandsum-1,SST);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           FrmOutPut->RichOutPut->Lines->Add("FINISHED");
           FrmOutPut->ShowModal();
        }
        else
        {
            FrmOutPut->RichOutPut->Lines->Add("Only 1 group.  No ANOVA possible.");
            FrmOutPut->ShowModal();
        }
    }

cleanup:
    // clean up the heap
    delete[] SS;
    delete[] Stddev;
    delete[] variance;
    delete[] mean;
    delete[] Freq;
    delete[] Selected;
    delete[] subscript;
    delete[] displace;
    delete[] levels;
    delete[] Maximum;
    delete[] Minimum;

    FrmBrkDwn->Hide();
}
//---------------------------------------------------------------------------

int Index_Pos(int *X, int *displace, int ListSize)
{
    int index, i;

    index = X[ListSize-1];
    for (i = 1; i <= ListSize - 1; i++)
        index = index + ((X[i-1] - 1) * displace[i-1]);
    return (index);
}
//---------------------------------------------------------------------------
void __fastcall TFrmBrkDwn::ListBox2Click(TObject *Sender)
{
/*     AnsiString cellstring;
     int index;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     DepVarEdit->Text = cellstring;
     ListBox2->Items->Delete(index);
*/     
}
//---------------------------------------------------------------------------

void __fastcall TFrmBrkDwn::ContInBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     index = ListBox1->ItemIndex;
     cellstring = ListBox1->Items->Strings[index];
     DepVarEdit->Text = cellstring;
     ContOutBtn->Enabled = true;
     ContInBtn->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmBrkDwn::ContOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;

     cellstring = DepVarEdit->Text;
     ListBox1->Items->Add(cellstring);
     DepVarEdit->Text = "";
     ContOutBtn->Enabled = false;
     ContInBtn->Enabled = true;
}
//---------------------------------------------------------------------------

