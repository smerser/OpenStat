//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "canon.h"
#include "CanVars.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmCanonical *FrmCanonical;
//---------------------------------------------------------------------------
__fastcall TFrmCanonical::TFrmCanonical(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmCanonical::BtnOKClick(TObject *Sender)
{
    // FrmCanonical->Visible = false;    
}
//---------------------------------------------------------------------------

void __fastcall TFrmCanonical::BtnLeftInClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstVars->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstVars->Selected[i])
         {
            cellstring = LstVars->Items->Strings[i];
            LstLeftVars->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstVars->Items->Count; i++)
           {
               if (LstVars->Selected[i])
               {
                  LstVars->Items->Delete(i);
                  count--;
               }
           }
     }
     BtnLeftOut->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmCanonical::BtnRightInClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstVars->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstVars->Selected[i])
         {
            cellstring = LstVars->Items->Strings[i];
            LstRightVars->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstVars->Items->Count; i++)
           {
               if (LstVars->Selected[i])
               {
                  LstVars->Items->Delete(i);
                  count--;
               }
           }
     }
     BtnRightOut->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TFrmCanonical::BtnLeftOutClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    index = LstLeftVars->ItemIndex;
    if (index < 0) index = 0;
    cellstring = LstLeftVars->Items->Strings[index];
    LstVars->Items->Add(cellstring);
    LstLeftVars->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmCanonical::BtnRightOutClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    index = LstRightVars->ItemIndex;
    if (index < 0) index = 0;
    cellstring = LstRightVars->Items->Strings[index];
    LstVars->Items->Add(cellstring);
    LstRightVars->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TFrmCanonical::BtnCancelClick(TObject *Sender)
{
     FrmCanonical->Visible = false;

}
//---------------------------------------------------------------------------

