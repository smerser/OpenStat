#include "math.h"

double ftest(double DF1, double DF2, double f);
double betai(double A, double b, double X);
double betacf(double A, double b, double X);
double gammln(double xx);
double chisquaredprob(double X, int k);
double ord(double z);
double f(double z);
double simpsonintegral(double A, double b);
double normalprob(double z);
double zcumsimp(double z);
double zprob(double p, bool &errorstate);
double inversez(double prob);
double lngamma(double w);
double betaratio(double x, double a, double b, double lnbeta);
double inversebetaratio(double ratio, double a, double b, double lnbeta);
double fpercentpoint(double p, int k1, int k2);
double alnorm(double x, bool upper);
double prtrng(double q, double v, double r);
double STUDENT(double q, double v, double r);
double inversechi(double p, int k);
double chi2func(double chisqr, double df);
double Ffunc(double F, int df1, int df2);
void scatplot(double *X, double *Y, int NoCases, char *titlestr,
     char *x_axis, char *y_axis, double x_min, double x_max, double y_min,
     double y_max);
double tprob(double t, double df);
double inverset(double Probt, double DF);
double Percentile(int nscrgrps, double pcnt, double *freq,
                  double *cumfreq, double *Scores);
void swilk (bool &init, double *x, int n, int n1, int n2, double *a,
            double &w, double &pw, int &ifault);
void ppnd7 (double p, double &normal_dev, int &ifault);
double poly(double *c, int nord, double x);
double sign(double a, double b);
int isign(int a, int b);
double probz(double z);
double zdensity(double z);
double sqr(double value);
AnsiString copy(AnsiString source, int first, int last);
double WholeValue(double value);
double FractionValue(double value);
double Quartiles(int Type, double pcntile, int N, double *values);
