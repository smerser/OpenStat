//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
#include "DataFuncs.h"
#include <stdio.h>
#include "ABRAnova.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TABRForm *ABRForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoVariables;
extern int NoCases;

//---------------------------------------------------------------------------
__fastcall TABRForm::TABRForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::CancelBtnClick(TObject *Sender)
{
    ABRForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::OKBtnClick(TObject *Sender)
{
    GetData(this);
    Calculations(this);
    Summary(this);
    MeansReport(this);
    if (HomoCovarChkBox->Checked) BoxTests(this);
    if (MeansChkBox->Checked) GraphMeans(this);
    CleanUp(this);
    ABRForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::ResetBtnClick(TObject *Sender)
{
    VarList->Clear();
    AinBtn->Enabled = true;
    BinBtn->Enabled = true;
    CinBtn->Enabled = true;
    AoutBtn->Enabled = false;
    BoutBtn->Enabled = false;
    CoutBtn->Enabled = false;
    HomoCovarChkBox->Checked = false;
    AEdit->Text = "";
    BEdit->Text = "";
    NinGrpEdit->Text = "";
    RListBox->Clear();
    for (int i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::AinBtnClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    index = VarList->ItemIndex;
    if (index < 0) index = 0;
    cellstring = VarList->Items->Strings[index];
    AEdit->Text = cellstring;
    VarList->Items->Delete(index);
    AoutBtn->Enabled = true;
    AinBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::BinBtnClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    index = VarList->ItemIndex;
    if (index < 0) index = 0;
    cellstring = VarList->Items->Strings[index];
    BEdit->Text = cellstring;
    VarList->Items->Delete(index);
    BoutBtn->Enabled = true;
    BinBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::CinBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = VarList->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (VarList->Selected[i])
         {
            cellstring = VarList->Items->Strings[i];
            RListBox->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < VarList->Items->Count; i++)
           {
               if (VarList->Selected[i])
               {
                  VarList->Items->Delete(i);
                  count--;
               }
           }
     }
     CoutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::AoutBtnClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    cellstring = AEdit->Text;
    VarList->Items->Add(cellstring);
    AinBtn->Enabled = true;
    AoutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::BoutBtnClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    cellstring = BEdit->Text;
    VarList->Items->Add(cellstring);
    AinBtn->Enabled = true;
    BoutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TABRForm::CoutBtnClick(TObject *Sender)
{
	int index;
    int nodeps;
    AnsiString cellstring;

    nodeps = RListBox->Items->Count;
    if (nodeps == 0) return;
    index = RListBox->ItemIndex;
    if (index < 0) index = 0;
    cellstring = RListBox->Items->Strings[index];
    VarList->Items->Add(cellstring);
    RListBox->Items->Delete(index);
    nodeps = RListBox->Items->Count;
    if (nodeps == 0) CoutBtn->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::GetData(TObject *Sender)
{
    AnsiString cellstring;
    double SubjTot, X;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    NinGrp = floor(StrToFloat(NinGrpEdit->Text));
    if (NinGrp < 2)
    {
       Application->MessageBox("Each group must have two or more observations.","ERROR!",MB_OK);
       return;
    }
    ACol = 0;
    BCol = 0;
    for (int i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        if (cellstring == AEdit->Text) ACol = i+1;
        if (cellstring == BEdit->Text) BCol = i+1;
    }
    if ( (ACol == 0) || (BCol == 0))
    {
        Application->MessageBox("Select a variable for the A and B Variable Codes.","ERROR!",MB_OK);
        return;
    }
    // for strong type check for correct variable types uncomment the following:
    //result = VarTypeChk(ACol,1);
    //if (result == 1) CleanUp(this);
    //result = VarTypeChk(BCol,1);
    //if (result == 1) CleanUp(this);

    NoSelected = RListBox->Items->Count;
    MinA = floor(StrToFloat(MainForm->Grid->Cells[ACol][1]));
//    result = GetValue(1,ACol,intvalue,dblvalue,strvalue);
//    if (result == 1) MinA = 0;
//    else MinA = intvalue;
    MaxA = MinA;
//    MinB = atoi(MainForm->Grid->Cells[BCol][1].c_str());
    MinB = floor(StrToFloat(MainForm->Grid->Cells[BCol][1]));
    //result = GetValue(1,BCol,intvalue,dblvalue,strvalue);
    //if (result == 1) MinB = 0;
    //else MinB = intvalue;
    MaxB = MinB;
    for (int i = 1; i <= NoCases; i++)
    {
        group = floor(StrToFloat(MainForm->Grid->Cells[ACol][i]));
        //result = GetValue(i,ACol,intvalue,dblvalue,strvalue);
        //if (result == 1) group = 0;
        //else group = intvalue;
        if (group > MaxA) MaxA = group;
        if (group < MinA) MinA = group;
         group = floor(StrToFloat(MainForm->Grid->Cells[BCol][i]));
        //result = GetValue(i,BCol,intvalue,dblvalue,strvalue);
        //if (result == 1) group = 0;
        //else group = intvalue;
        if (group > MaxB) MaxB = group;
        if (group < MinB) MinB = group;
    }
    NoAGrps = MaxA - MinA + 1;
    NoBGrps = MaxB - MinB + 1;
    MaxRows = NoAGrps * NoBGrps;
    MaxCols = NoSelected;
    if (NoBGrps > NoSelected) MaxCols = NoBGrps;
    if (MaxCols > MaxRows) MaxRows = MaxCols;

    try
    {
        ColNoSelected = new int[NoSelected];
        ASums = new double[NoAGrps];
        BSums = new double[NoBGrps];
        CSums = new double[NoSelected];
        ABSums = new double*[NoAGrps];
        for (int i = 0; i < NoAGrps; i++) ABSums[i] = new double[NoBGrps];
        ACSums = new double*[NoAGrps];
        for (int i = 0; i < NoAGrps; i++) ACSums[i] = new double[NoSelected];
        BCSums = new double*[NoBGrps];
        for (int i = 0; i < NoBGrps; i++) BCSums[i] = new double[NoSelected];
        ABCSums = new double**[NoAGrps];
        for (int i = 0; i < NoAGrps; i++) ABCSums[i] = new double*[NoBGrps];
        for (int i = 0; i < NoAGrps; i++)
            for (int j = 0; j < NoBGrps; j++)
                ABCSums[i][j] = new double[NoSelected];
        SumPSqr = new double[NoCases];
        Matrix = new double*[MaxRows];
        for (int i = 0; i < MaxRows; i++) Matrix[i] = new double[MaxCols];
        RowLabels = new AnsiString[MaxRows];
        ColLabels = new AnsiString[MaxCols];
        PooledMat = new double*[MaxCols];
        for (int i = 0; i < MaxCols; i++) PooledMat[i] = new double[MaxCols];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in ABRAnova.","ERROR!",MB_OK);
        CleanUp(this);
        return;
    }
    // initialize arrays
    for (int i = 0; i < NoAGrps; i++)
    {
        ASums[i] = 0.0;
        for (int j = 0; j < NoBGrps; j++)
        {
            ABSums[i][j] = 0.0;
            for (int k = 0; k < NoSelected; k++) ABCSums[i][j][k] = 0.0;
        }
        for (int j = 0; j < NoSelected; j++) ACSums[i][j] = 0.0;
    }
    for (int i = 0; i < NoBGrps; i++)
    {
        BSums[i] = 0.0;
        for (int j = 0; j < NoSelected; j++) BCSums[i][j] = 0.0;
    }
    for (int i = 0; i < NoSelected; i++) CSums[i] = 0.0;
    for (int i = 0; i < NoCases; i++) SumPSqr[i] = 0.0;
    GrandTotal = 0.0;
    SumXSqr = 0.0;


    for (int i = 0; i < NoSelected; i++)
    {
        cellstring = RListBox->Items->Strings[i];
        for (int j = 1; j <= NoVariables; j++)
        {
            if (MainForm->Grid->Cells[j][0] == cellstring) ColNoSelected[i] = j;
        }
        //result = VarTypeChk(ColNoSelected[i],0);
        //if (result == 1) CleanUp(this);
    }
    // read data and store sums
    for (int i = 1; i <= NoCases; i++)
    {
        // First, check for valid case
        if (!ValidRecord(i,ColNoSelected,NoSelected)) continue;
        SubjA = floor(StrToFloat(MainForm->Grid->Cells[ACol][i]));
        //result = GetValue(i,ACol,intvalue,dblvalue,strvalue);
        //if (result == 1) SubjA = 0;
        //else SubjA = intvalue;
        SubjA -= MinA;
        SubjB = floor(StrToFloat(MainForm->Grid->Cells[BCol][i]));
        //result = GetValue(i,BCol,intvalue,dblvalue,strvalue);
        //if (result == 1) SubjB = 0;
        //else SubjB = intvalue;
        SubjB -= MinB;
        SubjTot = 0.0;
        for (int j = 0; j < NoSelected; j++)
        {
            X = StrToFloat(MainForm->Grid->Cells[ColNoSelected[j]][i]);
            //result = GetValue(i,ColNoSelected[j],intvalue,dblvalue,strvalue);
            //if (result == 1) X = 0.0;
            //else X = dblvalue;
            SubjTot += X;
            SumXSqr += (X * X);
            ABCSums[SubjA][SubjB][j] += X;
        }
        SumPSqr[i-1] += (SubjTot * SubjTot);
        GrandTotal += SubjTot;
    }
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::Calculations(TObject *Sender)
{
    double SumA, SumB, SumC, SumAB, SumAC, SumBC, SumABC;

    Term1 = (GrandTotal * GrandTotal) / (NinGrp * NoAGrps * NoBGrps * NoSelected);
    Term2 = SumXSqr;
    Term3 = 0.0;
    for (int i = 0; i < NoAGrps; i++)
    {
        SumA = 0.0;
        for (int j = 0; j < NoBGrps; j++)
            for (int k = 0; k < NoSelected; k++) SumA += ABCSums[i][j][k];
        ASums[i] += SumA;
        Term3 += (SumA * SumA);
    }
    Term3 /= (NinGrp * NoBGrps * NoSelected);

    Term4 = 0;
    for (int j = 0; j < NoBGrps; j++)
    {
        SumB = 0.0;
        for (int i = 0; i < NoAGrps; i++)
            for (int k = 0; k < NoSelected; k++) SumB += ABCSums[i][j][k];
        BSums[j] += SumB;
        Term4 += (SumB * SumB);
    }
    Term4 /= (NinGrp * NoAGrps * NoSelected);

    Term5 = 0.0;
    for (int k = 0; k < NoSelected; k++)
    {
        SumC = 0.0;
        for (int i = 0; i < NoAGrps; i++)
            for (int j = 0; j < NoBGrps; j++) SumC += ABCSums[i][j][k];
        CSums[k] += SumC;
        Term5 += (SumC * SumC);
    }
    Term5 /= (NinGrp * NoAGrps * NoBGrps);

    Term6 = 0.0;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoBGrps; j++)
        {
            SumAB = 0.0;
            for (int k = 0; k < NoSelected; k++) SumAB += ABCSums[i][j][k];
            ABSums[i][j] += SumAB;
            Term6 += (SumAB * SumAB);
        }
    }
    Term6 /= (NinGrp * NoSelected);

    Term7 = 0.0;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int k = 0; k < NoSelected; k++)
        {
            SumAC = 0.0;
            for (int j = 0; j < NoBGrps; j++) SumAC += ABCSums[i][j][k];
            ACSums[i][k] += SumAC;
            Term7 += (SumAC * SumAC);
        }
    }
    Term7 /= (NinGrp * NoBGrps);

    Term8 = 0.0;
    for (int j = 0; j < NoBGrps; j++)
    {
        for (int k = 0; k < NoSelected; k++)
        {
            SumBC = 0.0;
            for (int i = 0; i < NoAGrps; i++) SumBC += ABCSums[i][j][k];
            BCSums[j][k] += SumBC;
            Term8 += (SumBC * SumBC);
        }
    }
    Term8 /= (NinGrp * NoAGrps);

    Term9 = 0.0;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoBGrps; j++)
        {
            for (int k = 0; k < NoSelected; k++)
            {
                SumABC = ABCSums[i][j][k];
                Term9 += (SumABC * SumABC);
            }
        }
    }
    Term9 /= NinGrp;

    Term10 = 0.0;
    for (int i = 0; i < NoCases; i++) Term10 += SumPSqr[i];
    Term10 /= NoSelected;

    //Get DF, SS, MS, F and Probabilities
    DFBetween = (NinGrp * NoAGrps * NoBGrps) - 1.0;
    DFA = NoAGrps - 1.0;
    DFB = NoBGrps - 1.0;
    DFAB = (NoAGrps - 1.0) * (NoBGrps - 1.0);
    DFerrorBetween = (NoAGrps * NoBGrps) * (NinGrp - 1.0);
    DFWithin = (NinGrp * NoAGrps * NoBGrps) * (NoSelected - 1.0);
    DFC = NoSelected - 1.0;
    DFAC = (NoAGrps - 1.0) * (NoSelected - 1.0);
    DFBC = (NoBGrps - 1.0) * (NoSelected - 1.0);
    DFABC = (NoAGrps - 1.0) * (NoBGrps - 1.0) * (NoSelected - 1.0);
    DFerrorWithin = NoAGrps * NoBGrps * (NinGrp - 1.0) * (NoSelected - 1.0);
    SSBetweenSubjects = Term10 - Term1;
    SSA = Term3 - Term1;
    SSB = Term4 - Term1;
    SSAB = Term6 - Term3 - Term4 + Term1;
    SSerrorBetween = Term10 - Term6;
    SSWithinSubjects = Term2 - Term10;
    SSC = Term5 - Term1;
    SSAC = Term7 - Term3 - Term5 + Term1;
    SSBC = Term8 - Term4 - Term5 + Term1;
    SSABC = Term9 - Term6 - Term7 - Term8 + Term3 + Term4 + Term5 - Term1;
    SSerrorWithin = Term2 - Term9 - Term10 + Term6;
    MSA = SSA / DFA;
    MSB = SSB / DFB;
    MSAB = SSAB / DFAB;
    MSerrorBetween = SSerrorBetween / DFerrorBetween;
    MSC = SSC / DFC;
    MSAC = SSAC / DFAC;
    MSBC = SSBC / DFBC;
    MSABC = SSABC / DFABC;
    MSerrorWithin = SSerrorWithin / DFerrorWithin;
    FA = MSA / MSerrorBetween;
    FB = MSB / MSerrorBetween;
    FAB = MSAB / MSerrorBetween;
    FC = MSC / MSerrorWithin;
    FAC = MSAC / MSerrorWithin;
    FBC = MSBC / MSerrorWithin;
    FABC = MSABC / MSerrorWithin;
    ProbA = ftest(DFA,DFerrorBetween,FA);
    ProbB = ftest(DFB,DFerrorBetween,FB);
    ProbAB = ftest(DFAB,DFerrorBetween,FAB);
    ProbC = ftest(DFC,DFerrorWithin,FC);
    ProbAC = ftest(DFAC,DFerrorWithin,FAC);
    ProbBC = ftest(DFBC,DFerrorWithin,FBC);
    ProbABC = ftest(DFABC,DFerrorWithin,FABC);
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::Summary(TObject *Sender)
{
    char outline[81];

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("SOURCE              DF       SS        MS        F         PROB.");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Between Subjects  %5.0f%10.3f",DFBetween,SSBetweenSubjects);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   A Effects      %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFA, SSA, MSA, FA, ProbA);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   B Effects      %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFB, SSB, MSB, FB, ProbB);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   AB Effects     %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFAB, SSAB, MSAB, FAB, ProbAB);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   Error Between  %5.0f%10.3f%10.3f",
            DFerrorBetween,SSerrorBetween,MSerrorBetween);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Within Subjects   %5.0f%10.3f",DFWithin,SSWithinSubjects);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   C Replications %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFC, SSC, MSC, FC, ProbC);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   AC Effects     %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFAC, SSAC, MSAC, FAC, ProbAC);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   BC Effects     %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFBC, SSBC, MSBC, FBC, ProbBC);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   ABC Effects    %5.0f%10.3f%10.3f%10.3f%10.3f",
            DFABC, SSABC, MSABC, FABC, ProbABC);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   Error Within   %5.0f%10.3f%10.3f",
            DFerrorWithin, SSerrorWithin, MSerrorWithin);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Total             %5.0f%10.3f",
            DFBetween + DFWithin, SSBetweenSubjects + SSWithinSubjects);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::MeansReport(TObject *Sender)
{
    char Title[81];
    char ColHeader[81];
    char Label[21];
    int row = 0;

    FrmOutPut->RichOutPut->Clear();
    strcpy(Title,"ABR Means Table");
    strcpy(ColHeader,"Repeated Measures");
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoBGrps; j++)
        {
            sprintf(Label,"A%d B%d",i+1,j+1);
            RowLabels[row] = Label;
            for (int k = 0; k < NoSelected; k++)
            {
                Matrix[row][k] = ABCSums[i][j][k] / NinGrp;
                ColLabels[k] = MainForm->Grid->Cells[ColNoSelected[k]][0];
            }
            row++;
        }
    }
    ArrayPrint(Matrix,row,NoSelected,ColHeader,RowLabels,ColLabels,Title);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    strcpy(Title,"AB Means Table");
    strcpy(ColHeader,"B Levels");
    for (int i = 0; i < NoAGrps; i++)
    {
        sprintf(Label,"A%d",i+1);
        RowLabels[i] = Label;
        for (int j = 0; j < NoBGrps; j++)
        {
            Matrix[i][j] = ABSums[i][j] / (NinGrp * NoSelected);
        }
    }
    for (int j = 0; j < NoBGrps; j++)
    {
        sprintf(Label,"B %d",j+1);
        ColLabels[j] = Label;
    }
    ArrayPrint(Matrix,NoAGrps,NoBGrps,ColHeader,RowLabels,ColLabels,Title);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    strcpy(Title,"AC Means Table");
    strcpy(ColHeader,"C Levels");
    for (int i = 0; i < NoAGrps; i++)
    {
        sprintf(Label,"A%d",i+1);
        RowLabels[i] = Label;
        for (int j = 0; j < NoSelected; j++)
        {
            Matrix[i][j] = ACSums[i][j] / (NinGrp * NoBGrps);
        }
    }
    for (int j = 0; j < NoSelected; j++)
    {
        sprintf(Label,"C %d",j+1);
        ColLabels[j] = Label;
    }
    ArrayPrint(Matrix,NoAGrps,NoSelected,ColHeader,RowLabels,ColLabels,Title);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    strcpy(Title,"BC Means Table");
    strcpy(ColHeader,"C Levels");
    for (int i = 0; i < NoBGrps; i++)
    {
        sprintf(Label,"B%d",i+1);
        RowLabels[i] = Label;
        for (int j = 0; j < NoSelected; j++)
        {
            Matrix[i][j] = BCSums[i][j] / (NinGrp * NoAGrps);
        }
    }
    for (int j = 0; j < NoSelected; j++)
    {
        sprintf(Label,"C %d",j+1);
        ColLabels[j] = Label;
    }
    ArrayPrint(Matrix,NoBGrps,NoSelected,ColHeader,RowLabels,ColLabels,Title);
    FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::BoxTests(TObject *Sender)
{
    double *XVector, *XSums, *TotSums, X, **DetMat, **MeanCovMat;
    double Det, M1, M2, Sum1, C1, C2, f1, f2, chi, ProbChi;
    char Title[81];
    char ColHeader[81];
    char Label[81];

    try
    {
        XVector = new double[NoSelected];
        XSums = new double[NoSelected];
        DetMat = new double*[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++)
            DetMat[i] = new double[NoSelected+1];
        MeanCovMat = new double*[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++)
            MeanCovMat[i] = new double[NoSelected+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory in ABRAnova.","ERROR!",MB_OK);
        CleanUp(this);
        return;
    }

    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(Label,"C%d",i+1);
        RowLabels[i] = Label;
        ColLabels[i] = Label;
        for (int j = 0; j < NoSelected; j++) PooledMat[i][j] = 0.0;
    }

    // get variance-covariance matrix for the repeated measures within
    // each combination of A and B levels.  Pool them for the pooled
    // covariance matrix.  Get Determinants of each matrix.
    FrmOutPut->RichOutPut->Clear();
    Sum1 = 0.0;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoBGrps; j++)
        {
            sprintf(Label,"Variance-Covariance Matrix for A%d B%d",
                    i+1,j+1);
            strcpy(Title,Label);
            strcpy(ColHeader,"C Levels");
            // initialize Matrix for this combination
            for (int k = 0; k < NoSelected; k++)
            {
                for (int l = 0; l < NoSelected; l++) Matrix[k][l] = 0.0;
                XSums[k] = 0.0;
            }
            // read data and add to covariances
            for (int row = 1; row <= NoCases; row++)
            {
                SubjA = floor(StrToFloat(MainForm->Grid->Cells[ACol][row]));
                SubjA -= MinA;
                SubjB = floor(StrToFloat(MainForm->Grid->Cells[BCol][row]));
                SubjB -= MinB;
                if ((SubjA != i)||(SubjB != j)) continue;
                for (int k = 0; k < NoSelected; k++)
                {
                    X = StrToFloat(MainForm->Grid->Cells[ColNoSelected[k]][row]);
                    XVector[k] = X;
                    XSums[k] += X;
                }
                for (int k = 0; k < NoSelected; k++)
                {
                    for (int l = 0; l < NoSelected; l++)
                    {
                        Matrix[k][l] += (XVector[k] * XVector[l]);
                    }
                }
            } // next case
            // convert sums of cross-products to variance-covariance
            for (int k = 0; k < NoSelected; k++)
            {
                for (int l = 0; l < NoSelected; l++)
                {
                    Matrix[k][l] = Matrix[k][l] - (XSums[k]*XSums[l] /
                         double(NinGrp));
                    Matrix[k][l] /= double(NinGrp - 1);
                    PooledMat[k][l] += Matrix[k][l];
                }
            }
            ArrayPrint(Matrix,NoSelected,NoSelected,ColHeader,RowLabels,ColLabels,Title);
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("");
            for (int i = 0; i < NoSelected; i++)
                for (int j = 0; j < NoSelected; j++)
                    DetMat[i][j] = Matrix[i][j];
            Det = Determ(DetMat,NoSelected);
            if (Det > 0.0e35) Sum1 += (NinGrp * log(Det));
            else Application->MessageBox("Determinant of a covariance matrix near 0.","WARNING!",MB_OK);
        }// next B level
    } // next A level

    // get pooled variance-covariance
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            PooledMat[i][j] /= double(NoAGrps * NoBGrps);
    strcpy(Title,"Pooled Variance-Covariance Matrix");
    ArrayPrint(PooledMat,NoSelected,NoSelected,ColHeader,RowLabels,ColLabels,Title);

    // calculate F-Max for variance homogeneity

    // calculate Box test for covariance homogeneity
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            DetMat[i][j] = PooledMat[i][j];
    Det = Determ(DetMat,NoSelected);
    if (Det > 0.0e35)
    {
        M1 = (NinGrp*NoAGrps*NoBGrps * log(Det)) - Sum1;
        C1 = (2.0 * NoSelected * NoSelected + 3.0 * NoSelected - 1.0) /
         (6.0 * (NoSelected+1) * (NoAGrps * NoBGrps - 1.0));
        C1 = C1 * ( (NoAGrps * NoBGrps * (1.0 / NinGrp)) - (1.0 / (NinGrp * NoAGrps * NoBGrps)));
        f1 = (NoSelected * (NoSelected + 1.0) * (NoAGrps * NoBGrps - 1.0))/2.0;
        chi = (1.0 - C1) * M1;
        ProbChi = 1.0 - chisquaredprob(chi,int(f1));
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(Label,"Test that sample covariances are from same population:");
        FrmOutPut->RichOutPut->Lines->Add(Label);
        sprintf(Label,"Chi-Squared = %10.3f with %d degrees of freedom.",chi,int(f1));
        FrmOutPut->RichOutPut->Lines->Add(Label);
        sprintf(Label,"Probability of Chi-Squared = %10.3f",ProbChi);
        FrmOutPut->RichOutPut->Lines->Add(Label);
        FrmOutPut->RichOutPut->Lines->Add("");
    }
    else Application->MessageBox("Determinant of a pooled covariance matrix near 0.","WARNING!",MB_OK);
    // test that pooled covariance has form of equal variances and equal covariances
    if (Det > 0.0e35) // determinant of pooled covariance > 0
    {
        M2 = Det;
        double avgvar = 0.0;
        for (int i = 0; i < NoSelected; i++) avgvar += PooledMat[i][i];
        avgvar /= double(NoSelected);
        double avgcov = 0.0;
        for (int i = 0; i < NoSelected-1; i++)
            for (int j = i+1; j < NoSelected; j++)
                avgcov += PooledMat[i][j];
        avgcov /= double(NoSelected * (NoSelected - 1) / 2);
        for (int i = 0; i < NoSelected; i++) DetMat[i][i] = avgvar;
        for (int i = 0; i < NoSelected-1; i++)
        {
            for (int j = i+1; j < NoSelected; j++)
            {
                DetMat[i][j] = avgcov;
                DetMat[j][i] = avgcov;
            }
        }
        Det = Determ(DetMat,NoSelected);
        if (Det > 0.0e35)
        {
            int N = NoAGrps * NoBGrps * NinGrp;
            int p = NoAGrps * NoBGrps;
            int quad = NoSelected * NoSelected + NoSelected - 4;
            M2 = log(M2 / Det);
            M2 = -(N - p) * M2;
            C2 = NoSelected * (NoSelected + 1) * (NoSelected + 1) * (2 * NoSelected - 3);
            C2 = C2 / (6 * (N - p) * (NoSelected - 1) * quad);
            f2 = quad / 2;
            chi = (1.0 - C2) * M2;
            ProbChi = 1.0 - chisquaredprob(chi,int(f2));
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(Label,"Test that variance-covariances matrix has equal variances and equal covariances:");
            FrmOutPut->RichOutPut->Lines->Add(Label);
            sprintf(Label,"Chi-Squared = %10.3f with %d degrees of freedom.",chi,int(f2));
            FrmOutPut->RichOutPut->Lines->Add(Label);
            sprintf(Label,"Probability of Chi-Squared = %10.3f",ProbChi);
            FrmOutPut->RichOutPut->Lines->Add(Label);
            FrmOutPut->RichOutPut->Lines->Add("");
        }
        else Application->MessageBox("Determinant of theoretical covariance matrix near zero.","WARNING!",MB_OK);
    }
    FrmOutPut->ShowModal();

    // cleanup
    for (int i = 0; i < NoSelected+1; i++) delete[] MeanCovMat[i];
    delete[] MeanCovMat;
    for (int i = 0; i < NoSelected+1; i++) delete[] DetMat[i];
    delete[] DetMat;
    delete[] XSums;
    delete[] XVector;
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::GraphMeans(TObject *Sender)
{
    float MaxMean;

    // Plot Means if requested
    // Allocate space for point sets of means
    GetDblMatMem(GraphForm->Xpoints,1,NoAGrps);
    GetDblMatMem(GraphForm->Ypoints,NoBGrps,NoAGrps);
    for (int j = 0; j < NoAGrps; j++) GraphForm->Xpoints[0][j] = j + 1;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoBGrps; j++)
            GraphForm->Ypoints[j][i] = ABSums[i][j] / (NinGrp*NoSelected);
    }

    // Do AB interaction
    // Get maximum cell mean
    MaxMean = ABSums[0][0] / (NinGrp*NoSelected);
    for (int i = 0; i < NoAGrps; i++)
        for (int j = 0; j < NoBGrps; j++)
            if ((ABSums[i][j] / (NinGrp*NoSelected)) > MaxMean)
                MaxMean = ABSums[i][j] / (NinGrp*NoSelected);

    GraphForm->nosets = NoBGrps;
    GraphForm->nbars = NoAGrps;
    GraphForm->Heading = "AxB Interaction";
    GraphForm->XTitle = "B Levels";
    GraphForm->YTitle = "Means";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = false;
    GraphForm->miny = 0.0;
    GraphForm->maxy = MaxMean;
    GraphForm->GraphType = 3; // vertical 3d bars
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,NoBGrps);

    // Do AC interaction
    GetDblMatMem(GraphForm->Xpoints,1,NoSelected);
    GetDblMatMem(GraphForm->Ypoints,NoAGrps,NoSelected);
    MaxMean = ACSums[0][0] / (NinGrp*NoBGrps);
    for (int j = 0; j < NoSelected; j++) GraphForm->Xpoints[0][j] = j + 1;
    for (int i = 0; i < NoAGrps; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            if ((ACSums[i][j] / (NinGrp*NoBGrps)) > MaxMean)
                MaxMean = ACSums[i][j] / (NinGrp*NoBGrps);
            GraphForm->Ypoints[i][j] = ACSums[i][j] / (NinGrp*NoBGrps);
        }
    }
    GraphForm->nosets = NoAGrps;
    GraphForm->nbars = NoSelected;
    GraphForm->Heading = "AxC Interaction";
    GraphForm->XTitle = "C Levels";
    GraphForm->YTitle = "Means";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = false;
    GraphForm->miny = 0.0;
    GraphForm->maxy = MaxMean;
    GraphForm->GraphType = 3; // vertical 3d bars
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,NoAGrps);

    // Do BC interaction
    GetDblMatMem(GraphForm->Xpoints,1,NoSelected);
    GetDblMatMem(GraphForm->Ypoints,NoBGrps,NoSelected);
    MaxMean = BCSums[0][0] / (NinGrp*NoAGrps);
    for (int j = 0; j < NoSelected; j++) GraphForm->Xpoints[0][j] = j + 1;
    for (int i = 0; i < NoBGrps; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            if ((BCSums[i][j] / (NinGrp*NoAGrps)) > MaxMean)
                MaxMean = BCSums[i][j] / (NinGrp*NoAGrps);
            GraphForm->Ypoints[i][j] = BCSums[i][j] / (NinGrp*NoAGrps);
        }
    }

     GraphForm->nosets = NoBGrps;
    GraphForm->nbars = NoSelected;
    GraphForm->Heading = "BxC Interaction";
    GraphForm->XTitle = "C Levels";
    GraphForm->YTitle = "Means";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = false;
    GraphForm->miny = 0.0;
    GraphForm->maxy = MaxMean;
    GraphForm->GraphType = 3; // vertical 3d bars
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,NoAGrps);
}
//---------------------------------------------------------------------------

void __fastcall TABRForm::CleanUp(TObject *Sender)
{
    for (int i = 0; i < MaxCols; i++) delete[] PooledMat[i];
    delete[] PooledMat;
    delete[] ColLabels;
    delete[] RowLabels;
    for (int i = 0; i < MaxRows; i++) delete[] Matrix[i];
    delete[] Matrix;
    delete[] SumPSqr;
    for (int i = 0; i < NoAGrps; i++)
        for (int j = 0; j < NoBGrps; j++) delete[] ABCSums[i][j];
    for (int i = 0; i < NoAGrps; i++) delete[] ABCSums[i];
    delete[] ABCSums;
    for (int i = 0; i < NoBGrps; i++) delete[] BCSums[i];
    delete[] BCSums;
    for (int i = 0; i < NoAGrps; i++) delete[] ACSums[i];
    delete[] ACSums;
    for (int i = 0; i < NoAGrps; i++) delete[] ABSums[i];
    delete[] ABSums;
    delete[] CSums;
    delete[] BSums;
    delete[] ASums;
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------



