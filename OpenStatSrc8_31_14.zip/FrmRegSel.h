//---------------------------------------------------------------------------
#ifndef FrmRegSelH
#define FrmRegSelH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
//---------------------------------------------------------------------------
class TRegVarSel : public TForm
{
__published:	// IDE-managed Components
	TListBox *LstVariables;
	TLabel *Label1;
	TEdit *DepVar;
	TGroupBox *GroupBox1;
	TButton *BtnPrevious;
	TButton *BtnNext;
	TLabel *LblBlock;
	TBevel *Bevel1;
	TLabel *Label2;
	TListBox *LstIndependent;
	TLabel *Label3;
	TComboBox *CmbMethod;
	TBitBtn *BitBtn1;
	TBitBtn *BitBtn2;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnReset;
	TButton *BtnHelp;
	TGroupBox *GroupBox2;
	TCheckBox *ChkDesc;
	TCheckBox *ChkCorrMat;
	TCheckBox *ChkInverse;
	TCheckBox *ChkCoefMat;
	TGroupBox *GroupBox3;
	TCheckBox *ChkRawPredict;
	TCheckBox *ChkRawResid;
	TCheckBox *ChkzPredicted;
	TCheckBox *ChkzResid;
    TCheckBox *SaveRChkBox;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
	void __fastcall BitBtn1Click(TObject *Sender);
	void __fastcall BitBtn2Click(TObject *Sender);
	void __fastcall BtnResetClick(TObject *Sender);
	void __fastcall BtnNextClick(TObject *Sender);
	void __fastcall BtnPreviousClick(TObject *Sender);
	void __fastcall CmbMethodChange(TObject *Sender);
	
	void __fastcall FormCreate(TObject *Sender);
    void __fastcall BtnHelpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TRegVarSel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TRegVarSel *RegVarSel;
//---------------------------------------------------------------------------
#endif
