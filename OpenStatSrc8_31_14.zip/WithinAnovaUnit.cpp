//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include <stdio.h>
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "MainUnit.h"
#include "functions.h"
#include "GraphUnit.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include "AnovaTestsUnit.h"
#include "WithinAnovaUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmRepAnova *FrmRepAnova;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TFrmRepAnova::TFrmRepAnova(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::InBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     OutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::OutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox1->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox1->Items->Strings[index];
          ListBox2->Items->Add(cellstring);
     }
     ListBox1->Clear();
     OutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::ComputeBtnClick(TObject *Sender)
{
    AnsiString Label;
    int NoSelected, count, IER, row;
    int *Selected;
    AnsiString *ColLabels;
    double SSrows, SScols, SSwrows, SSerr, SStot;
    double MSrows, MScols, MSwrows, MSerr, MStot;
    double dfrows, dfcols, dfwrows, dferr, dftot;
    double f1, f2, probf1, probf2, GrandMean, Term1, Term2, Term3, Term4;
    double r1, r2, r3, r4, alpha;
    double *ColMeans, *ColVar, *RowMeans, *RowVar;
    char outline[121];
    AnsiString astr;
    bool errorfound = false;
    bool Posthoc = false;
    int result;

    NoSelected = ListBox2->Items->Count;
    if (NoSelected == 0)
    {
        ShowMessage("ERROR!  You must select 2 or more variables to analyze.");
        return;
    }

    try
    {
        Selected = new int[NoSelected];
        ColLabels = new AnsiString[NoSelected];
        ColMeans = new double[NoSelected];
        ColVar = new double[NoSelected];
        RowMeans = new double[NoCases];
        RowVar = new double[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Not enough memory-returning.","ERROR!",MB_OK);
        return;
    }
    for (int i = 0; i < NoSelected; i++)
    {
        Label = ListBox2->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
        {
            if (Label == MainForm->Grid->Cells[j+1][0])
            {
                Selected[i] = j+1;
/*
                result = VarTypeChk(j+1,0);
                if (result == 1)
                {
                        delete[] RowVar;
                        delete[] RowMeans;
                        delete[] ColVar;
                        delete[] ColMeans;
                        delete[] ColLabels;
                        delete[] Selected;
                        return;
                }
                break;
*/
            }
        }
    }
    for (int i = 0; i < NoSelected; i++)
    {
        int j = Selected[i];
        ColLabels[i] = MainForm->Grid->Cells[j][0];
    }

    // Initialize values
    SScols = 0.0;
    SSrows = 0.0;
    SSwrows = 0.0;
    SSerr = 0.0;
    SStot = 0.0;
    MScols = 0.0;
    MSrows = 0.0;
    MSwrows = 0.0;
    MSerr = 0.0;
    dfrows = 0.0;
    dfcols = 0.0;
    dfwrows = 0.0;
    dferr = 0.0;
    dftot = 0.0;
    GrandMean = 0.0;
    count = 0;
    if (PostHocChk->Checked) Posthoc = true;
    alpha = StrToFloat(AlphaEdit->Text);

    for (int i = 0; i < NoSelected; i++)
    {
        ColMeans[i] = 0.0;
        ColVar[i] = 0.0;
    }
    for (int j = 0; j < NoCases; j++)
    {
        RowMeans[j] = 0.0;
        RowVar[j] = 0.0;
    }

    // Read data and compute sums while reading
    row = 0;
    for (int i = 0; i < NoCases; i++) // row
    {
        if (ValidRecord(i+1,Selected,NoSelected)) count++;
        else continue;
        for (int j = 0; j < NoSelected; j++) // column
        {
            int k = Selected[j];
            double X = StrToFloat(MainForm->Grid->Cells[k][i+1]);
            RowMeans[row] += X;
            RowVar[row] += (X * X);
            ColMeans[j] += X;
            ColVar[j] += (X * X);
            GrandMean += X;
            SStot += (X * X);
        }
        row++;
    }

    // Calculate ANOVA results
    Term1 = (GrandMean * GrandMean) / double(count * NoSelected);
    Term2 = SStot;
    for (int i = 0; i < count; i++) SSrows += (RowMeans[i] * RowMeans[i]);
    Term4 = SSrows / double(NoSelected);
    for (int i = 0; i < NoSelected; i++) SScols += (ColMeans[i] * ColMeans[i]);
    Term3 = SScols / double(count);
    SSrows = Term4 - Term1;
    SScols = Term3 - Term1;
    SSwrows = Term2 - Term4;
    SSerr = Term2 - Term3 - Term4 + Term1;
    SStot = Term2 - Term1;
    dfrows = count - 1;
    dfcols = NoSelected - 1;
    dfwrows = count * (NoSelected - 1);
    dferr = (count - 1) * (NoSelected - 1);
    dftot = (count * NoSelected) - 1;
    MSrows = SSrows / dfrows;
    MScols = SScols / dfcols;
    MSwrows = SSwrows / dfwrows;
    MSerr = SSerr / dferr;
    MStot = SStot / dftot; // variance of all scores
//    GrandMean /= double(count * NoSelected);
    for (int i = 0; i < count; i++)
    {
        RowVar[i] = RowVar[i] - (RowMeans[i] * RowMeans[i] / double(NoSelected));
        RowVar[i] /= double(NoSelected - 1);
        RowMeans[i] /= double(NoSelected);
    }
    for (int i = 0; i < NoSelected; i++)
    {
        ColVar[i] = ColVar[i] - (ColMeans[i] * ColMeans[i] / double(count));
        ColVar[i] /= double(count - 1);
        ColMeans[i] /= double(count);
    }
    f1 = MScols / MSerr; // treatment F statistic
    probf1 = ftest(dfcols,dferr,f1);

    // Do reliability terms if requested
    if (RelEstChkBox->Checked)
    {
        r1 = 1.0 - (MSwrows / MSrows); // unadjusted reliability of test
        r2 = (MSrows - MSwrows) / (MSrows + double(NoSelected - 1) * MSwrows);
        // r2 is unadjusted reliability of a single item
        r3 = (MSrows - MSerr) / MSrows; // Cronbach alpha for test
        r4 = (MSrows - MSerr) / (MSrows + double(NoSelected - 1) * MSerr);
        // r4 is adjusted reliability of a single item
    }

    // do homogeneity of variance and covariance checks if requested

    // print results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Treatments by Subjects (AxS) ANOVA Results.");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("SOURCE           DF        SS        MS        F  Prob. > F");
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    sprintf(outline,"SUBJECTS       %4.0f%10.3f%10.3f",dfrows,SSrows,MSrows);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"WITHIN SUBJECTS%4.0f%10.3f%10.3f",dfwrows,SSwrows,MSwrows);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   TREATMENTS  %4.0f%10.3f%10.3f%10.3f%10.3f",dfcols,SScols,MScols,f1,probf1);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   RESIDUAL    %4.0f%10.3f%10.3f",dferr,SSerr,MSerr);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    sprintf(outline,"TOTAL          %4.0f%10.3f%10.3f",dftot,SStot,MStot);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("TREATMENT (COLUMN) MEANS AND STANDARD DEVIATIONS");
    FrmOutPut->RichOutPut->Lines->Add("VARIABLE  MEAN      STD.DEV.");
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(outline,"%-8s%10.3f%10.3f",ColLabels[i].c_str(),ColMeans[i],sqrt(ColVar[i]));
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");

    // Do post hoc analyses if requested
    if (Posthoc)
    {
       double *group_total, *group_count;
       group_total = new double[NoSelected];
       group_count = new double[NoSelected];
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEY(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEY_KRAMER(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEYBTEST(MSerr,dferr,group_total,group_count,1,NoSelected,count,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       SCHEFFETEST(MSerr,group_total,group_count,1,NoSelected,count*NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       Newman_Keuls(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       delete[] group_count;
       delete[] group_total;
    }

    // Do reliability estimates if requested
    if (RelEstChkBox->Checked)
    {
        FrmOutPut->RichOutPut->Lines->Add("RELIABILITY ESTIMATES");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("TYPE OF ESTIMATE              VALUE");
        sprintf(outline,"Unadjusted total reliability %7.3f",r1);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Unadjusted item reliabiity   %7.3f",r2);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Adjusted total (Cronbach)    %7.3f",r3);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Adjusted item reliability    %7.3f",r4);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();

    // Test assumptions of variance - covariance homogeneity if requested
    if (AssumpChkBox->Checked)
    {
        double **varcovmat, **vcmat, **workmat;
        errorfound = false;
        try // get space for variance/covariance matrix
        {
            varcovmat = new double *[NoSelected];
            for (int i = 0; i < NoSelected; i++) varcovmat[i] = new double[NoSelected];
            vcmat = new double *[NoSelected+1];
            for (int i = 0; i < NoSelected+1; i++) vcmat[i] = new double[NoSelected+1];
            workmat = new double *[NoSelected+1];
            for (int i = 0; i < NoSelected+1; i++) workmat[i] = new double[NoSelected+1];
        }
        catch (...)
        {
            Application->MessageBox("Out of memory.","ERROR!",MB_OK);
            return;
        }
        count = NoCases;
        FrmOutPut->RichOutPut->Lines->Add("BOX TEST FOR HOMOGENEITY OF VARIANCE-COVARIANCE MATRIX");
        FrmOutPut->RichOutPut->Lines->Add("");
        IER = Correlations(ColMeans, ColVar, varcovmat, NoSelected,Selected, count, 2,false, 2);
        if (IER == 1)
            Application->MessageBox("Zero variance found for a variable.","ERROR!",MB_OK);

        // get average of variances into workmat diagonal and average of
        // covariances into workmat off-diagonals (See Winer, pg 371)
        double avgvar = 0.0;
        double avgcov = 0.0;

        for (int i = 0; i < NoSelected; i++)
            for (int j = 0; j < NoSelected; j++)
                vcmat[i][j] = varcovmat[i][j];

        for (int i = 0; i < NoSelected; i++) avgvar += varcovmat[i][i];
        for (int i = 0; i < NoSelected-1; i++)
            for (int j = i+1; j < NoSelected; j++) avgcov += varcovmat[i][j];
        avgvar /= double(NoSelected);
        avgcov /= double(NoSelected * NoSelected - 1) / 2.0;

        for (int i = 0; i < NoSelected; i++) workmat[i][i] = avgvar;
        for (int i = 0; i < NoSelected-1; i++)
        {
            for (int j = i+1; j < NoSelected; j++)
            {
                workmat[i][j] = avgcov;
                workmat[j][i] = workmat[i][j];
            }
        }

        // get determinants of varcov and workmat (Note-destructive on inputs)
        double determ1 = 0.0;
        double determ2 = 0.0;
        double M2 = 0.0;
        double C2 = 0.0;
        double chi2 = 0.0;
        int f2 = 0;
        double prob = 0.0;
        determ1 = Determ(vcmat,NoSelected);
        if (determ1 < 0.0) determ1 = 0.0;
        determ2 = Determ(workmat,NoSelected);
        if (determ2 < 0.0) determ2 = 0.0;
        count = NoCases;
        if ((determ1 > 0.0) && (determ2 > 0.0))
            M2 = -double(NoCases*NoSelected - 1) * log(determ1 / determ2);
        else
        {
            M2 = 0.0;
            errorfound = true;
            Application->MessageBox("A determinant <= zero was found.","ERROR!",MB_OK);
        }
        if (errorfound == false)
        {
            C2 = (double)(NoSelected * (NoSelected+1) * (NoSelected + 1)) * double(2 * NoSelected - 3);
            C2 /= double(6 * (count - 1)*(NoSelected - 1) * (NoSelected * NoSelected + NoSelected - 4));
            chi2 = (1.0 - C2) * M2;
            f2 = (NoSelected * NoSelected + NoSelected - 4) / 2;
            if ((chi2 > 0.01) && (chi2 < 1000.0))
                prob = chisquaredprob(chi2,f2);
            else
            {
                if (chi2 <= 0.0) prob = 1.0;
                if (chi2 >= 1000.0) prob = 0.0;
            }
        }
        // rebuild the expected matrix to print out
        for (int i = 0; i < NoSelected; i++) varcovmat[i][i] = avgvar;
        for (int i = 0; i < NoSelected-1; i++)
        {
            for (int j = i+1; j < NoSelected; j++)
            {
                varcovmat[i][j] = avgcov;
                varcovmat[j][i] = avgcov;
            }
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        MatPrint(varcovmat,NoSelected,NoSelected,Selected,"ASSUMED POPULATION COVARIANCE MATRIX");
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Determinant of variance-covariance matrix = %10.3f",determ1);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Determinant of Population Covariance Matrix = %10.3f",determ2);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (errorfound == false)
        {
            sprintf(outline,"ChiSquare = %10.3f with %d degrees of freedom",chi2,f2);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"Probability of larger chisquare = %6.3f",1.0-prob);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        IER = Correlations(ColMeans, ColVar, varcovmat, NoSelected,Selected, count, 3,false, 2);
//        FrmOutPut->ShowModal();
        // deallocate heap
        for (int i = 0; i < NoSelected+1; i++) delete[] workmat[i];
        delete[] workmat;
        for (int i = 0; i < NoSelected+1; i++) delete[] vcmat[i];
        delete[] vcmat;
        for (int i = 0; i < NoSelected; i++) delete[] varcovmat[i];
        delete[] varcovmat;
   }

    // plot means of columns if requested
    if (PlotVarsChkBox->Checked) // Allocate space for point sets of means
    {
        GetDblMatMem(GraphForm->Xpoints,1,NoSelected);
        GetDblMatMem(GraphForm->Ypoints,1,NoSelected);
        // Get maximum mean
        float MaxMean = 0.0;
        for (int i = 0; i < NoSelected; i++)
            if (ColMeans[i] > MaxMean) MaxMean = ColMeans[i];
        {
            for (int j = 0; j < NoSelected; j++)
            {
                GraphForm->Ypoints[0][j] = ColMeans[j];
                GraphForm->Xpoints[0][j] = j+1;
            }
        }
        GraphForm->nosets = 1;
        GraphForm->nbars = NoSelected;
        GraphForm->Heading = "Treatment Means";
        GraphForm->XTitle = "COLUMN";
        GraphForm->YTitle = "VALUE";
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = false;
        GraphForm->miny = 0.0;
        GraphForm->maxy = MaxMean;
        GraphForm->GraphType = OptionsBox->ItemIndex;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clBlack;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowBackWall = true;
        GraphForm->ShowModal();
        ClearDblMatMem(GraphForm->Xpoints,1);
        ClearDblMatMem(GraphForm->Ypoints,1);
    }

    // deallocate space on the heap used for variables
    delete[] RowVar;
    delete[] RowMeans;
    delete[] ColVar;
    delete[] ColMeans;
    delete[] ColLabels;
    delete[] Selected;
}
//---------------------------------------------------------------------------
void __fastcall TFrmRepAnova::ResetBtnClick(TObject *Sender)
{
    AnsiString Label;
    ListBox1->Items->Clear();
    ListBox2->Items->Clear();
    for (int i = 0; i < NoVariables; i++)
    {
        Label = MainForm->Grid->Cells[i+1][0];
        ListBox1->Items->Add(Label);
    }
    AssumpChkBox->Checked = false;
    PlotVarsChkBox->Checked = false;
    RelEstChkBox->Checked = false;
    PostHocChk->Checked = false;
    OutBtn->Visible = false;
    if (ops.format == 0) AlphaEdit->Text = "0.05";
    else AlphaEdit->Text = "0,05";

}
//---------------------------------------------------------------------------

