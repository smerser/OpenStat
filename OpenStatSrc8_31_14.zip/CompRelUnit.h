//---------------------------------------------------------------------------

#ifndef CompRelUnitH
#define CompRelUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmCompRel : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarListBox;
    TLabel *Label2;
    TListBox *SelectedListBox;
    TSpeedButton *InBtn;
    TSpeedButton *OutBtn;
    TSpeedButton *AllBtn;
    TLabel *Label3;
    TListBox *RelListBox;
    TLabel *Label4;
    TListBox *WghtListBox;
    TMemo *Memo1;
    TButton *ComputeBtn;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ReturnBtn;
     TGroupBox *GroupBox1;
     TCheckBox *CorMatChk;
     TCheckBox *Comp2GridChk;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall RelListBoxClick(TObject *Sender);
    void __fastcall WghtListBoxClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmCompRel(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmCompRel *FrmCompRel;
//---------------------------------------------------------------------------
#endif
