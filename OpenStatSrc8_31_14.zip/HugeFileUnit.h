//---------------------------------------------------------------------------

#ifndef HugeFileUnitH
#define HugeFileUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include "stdio.h"
//---------------------------------------------------------------------------
class THugeFileForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TEdit *FileNameEdit;
   TLabel *Label2;
   TEdit *FormatFileEdit;
   TLabel *Label3;
   TEdit *NoVarsEdit;
   TStringGrid *SpecGrid;
   TComboBox *TypeBox;
   TButton *SaveFmtBtn;
   TButton *ReturnBtn;
   TButton *CancelBtn;
   TLabel *Label4;
   TEdit *NoLinesEdit;
   TLabel *Label5;
   TEdit *VarCntEdit;
        TOpenDialog *OpenDialog1;
        TMemo *Memo1;
        TButton *BtnDataOpen;
        TStringGrid *RecordGrid;
        TLabel *Label6;
        TRadioGroup *FileReadOps;
   void __fastcall FormShow(TObject *Sender);
   void __fastcall CancelBtnClick(TObject *Sender);
   void __fastcall ReturnBtnClick(TObject *Sender);
   void __fastcall SaveFmtBtnClick(TObject *Sender);
   void __fastcall SpecGridKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
   void __fastcall NoLinesEditKeyPress(TObject *Sender, char &Key);
   void __fastcall NoVarsEditKeyPress(TObject *Sender, char &Key);
   void __fastcall TypeBoxClick(TObject *Sender);
   void __fastcall OpenBtnClick(TObject *Sender);
   void __fastcall BtnDataOpenClick(TObject *Sender);
private:	// User declarations
   AnsiString FileName;
   AnsiString FmtFile;
   int NVars;
   void OpenFmtFile(TObject *Sender);
   void BuildDic(TObject *Sender);

public:		// User declarations
      void GetDiskValues(AnsiString *&DiskValues,int NoValues);
   __fastcall THugeFileForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE THugeFileForm *HugeFileForm;
//---------------------------------------------------------------------------
#endif
