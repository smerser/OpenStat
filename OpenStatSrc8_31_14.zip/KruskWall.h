//---------------------------------------------------------------------------
#ifndef KruskWallH
#define KruskWallH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TKWFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TEdit *GroupEdit;
    TLabel *Label3;
    TEdit *DependEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
        TLabel *Label4;
        TEdit *AlphaEdit;
        TCheckBox *MWUChk;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ListBox1Click(TObject *Sender);

private:	// User declarations
public:		// User declarations
    __fastcall TKWFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKWFrm *KWFrm;
//---------------------------------------------------------------------------
#endif
