//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "MainUnit.h"
#include "dstring.h"
#include "stdio.h"
#include "StemLeafUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStemLeafForm *StemLeafForm;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TStemLeafForm::TStemLeafForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     SelectList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::InBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              SelectList->Items->Add(Varlist->Items->Strings[i]);
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::OutBtnClick(TObject *Sender)
{
     int index;

     index = SelectList->ItemIndex;
     Varlist->Items->Add(SelectList->Items->Strings[index]);
     SelectList->Items->Delete(index);
     InBtn->Enabled = true;
     if (SelectList->Items->Count == 0) OutBtn->Enabled = false;

}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::AllBtnClick(TObject *Sender)
{
     int count, index;

     count = Varlist->Items->Count;
     for (index = 0; index < count; index++)
         SelectList->Items->Add(Varlist->Items->Strings[index]);
     Varlist->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TStemLeafForm::ComputeBtnClick(TObject *Sender)
{
    char outline[121];
    char astring[20];
    char truncstr[20];
    char *chr;
    AnsiString cellstring;
    double X;
    int stem, minstem, maxstem, bin;
    int nextleaf;
    int cntr;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;
    
    noselected = SelectList->Items->Count;
    if (noselected == 0)
    {
        ShowMessage("ERROR! No variables were selected.");
        return;
    }
    selected = new int[noselected];
    values = new double[NoCases];
    ValueString = new AnsiString[NoCases];
    bins = new int[20];
    frequency = new int[20];

    // Get selected variables
    for (int i = 1; i <= noselected; i++)
    {
        cellstring = SelectList->Items->Strings[i-1];
        for (int j = 1; j <= NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j][0])
            {
                selected[i-1] = j;
/*
                result = VarTypeChk(j,0);
                if (result == 1)
                {
                        delete[] frequency;
                        delete[] bins;
                        delete[] ValueString;
                        delete[] values;
                        delete[] selected;
                        return;
                }
*/
            }
        }
   }

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("STEM AND LEAF PLOTS");
    FrmOutPut->RichOutPut->Lines->Add("");

    // Analyze each variable selected
    for (int j = 0; j < noselected; j++)
    {
         int k = selected[j];
         sprintf(outline,"Stem and Leaf Plot for variable: %s",MainForm->Grid->Cells[k][0]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         ncases = 0;
         min = 1.0e20;
         max = -1.0e20;
         // Store values of the variable
         for (int i = 1; i <= NoCases; i++)
         {
             if (!ValidValue(i,k)) continue;
             values[ncases] = StrToFloat(MainForm->Grid->Cells[k][i]);
             //result = GetValue(i, k,intvalue, dblvalue, strvalue);
             //if (result != 0) values[ncases] = 0.0;
             //else values[ncases] = dblvalue;
             ValueString[ncases] = Trim(MainForm->Grid->Cells[k][i]);
             if (values[ncases] < min) min = values[ncases];
             if (values[ncases] > max) max = values[ncases];
             ncases = ncases + 1;
         }
         largest = ceil(max);
         smallest = ceil(min);
         stemsize = 1.0;
         if ((largest > 0) && (largest > 10))
         {
             do
             {
                 largest /= 10;
                 stemsize *= 10.0;
             } while (largest > 10);
         }
         else if ((largest < 0) && (smallest < -10))  // largest value is less than 0.0
         {
             do
             {
                 smallest *= 10;
                 stemsize /= 10.0;
             } while (smallest < -10);
         }

         // rescale values by stemsize
         for (int i = 0; i < ncases; i++) values[i] /= stemsize;

         // multiply values by 10, round and save value divided by 10
         double temp;
         for (int i = 0; i < ncases; i++)
         {
             temp = floor(values[i] * 10);
             temp /= 10.0;
             values[i] = temp;
             sprintf(astring,"%4.1f",values[i]);
             ValueString[i] = astring;
         }

         // get max and min stem values for creating bins for stem values
         minstem = 999;
         maxstem = -999;
         for (int i = 0; i < ncases; i++)
         {
             stem = values[i];
             if (stem < minstem) minstem = stem;
             if (stem > maxstem) maxstem = stem;
         }
//         stemrange = maxstem - minstem;

         // create arrays for stem and leaf plot
         for (int i = 0; i < 20; i++) frequency[i] = 0;

         // sort values into ascending order
         for (int i = 0; i < ncases-1; i++)
         {
             for (int k = i+1; k < ncases; k++)
             {
                 if (values[i] > values[k]) // swap values
                 {
                     X = values[i];
                     values[i] = values[k];
                     values[k] = X;
                     cellstring = ValueString[i];
                     ValueString[i] = ValueString[k];
                     ValueString[k] = cellstring;
                 }
             }
         }

         if (TestChk->Checked)
         {   // test output
             FrmOutPut->RichOutPut->Lines->Add("value     ValueString");
             for (int i = 0; i < ncases; i++)
             {
                 sprintf(outline,"%10.1f %s",values[i],ValueString[i].c_str());
                 FrmOutPut->RichOutPut->Lines->Add(outline);
             }
         }

         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("Frequency  Stem & Leaf");

         // place leafs in low and hi value bins (bins 0-4 and 5-9)
         for (int i = 0; i < 10; i++) // initialize counters
         {
             counterlow[i] = 0;
             counterhi[i] = 0;
         }
         for (int i = 0; i < ncases; i++)
         {
             bin = values[i]; // truncate to get stem value
             bin = bin - minstem;
             bins[bin] = values[i];
             // get leaf value
             strcpy(astring,ValueString[i].c_str());
             leafvalue = astring[3] - '0';
             if (leafvalue < 5)
             {
                leafslow[bin][counterlow[bin]] = astring[3];
                counterlow[bin]++;
                leafslow[bin][counterlow[bin]] = '\0';
             }
             else
             {
                 leafshi[bin][counterhi[bin]] = astring[3];
                 counterhi[bin]++;
                 leafshi[bin][counterhi[bin]] = '\0';
             }
         }

         // get max length of hi and low leaf counters
         counter = 0;
         for (int i = 0; i < 10; i++)
         {
             if (counterlow[i] > counter) counter = counterlow[i];
             if (counterhi[i] > counter) counter = counterhi[i];
         }

         // determine leaf depth needed to get counter <= 50
         if (counter > 50)
         {
            smallcount = 2;
            int testvalue;
            do
            {
                testvalue = counter / smallcount;
                smallcount++;
            } while (testvalue > 50);
            smallcount--; // leaf depth needed to reduce line lengths to 50 or less
         }
         else smallcount = 1;

         // sort leafs into ascending order
         for (int i = 0; i < 10; i++)
         {
             int M = strlen(leafslow[i]);
             if (M > 0)
             {
                for (int k = 0; k < M-1; k++)
                {
                    for (int L = k+1; L < M; L++)
                    {
                        if (leafslow[i][k] > leafslow[i][L]) // swap
                        {
                           int temp1 = leafslow[i][k];
                           leafslow[i][k] = leafslow[i][L];
                           leafslow[i][L] = temp1;
                        }
                    }
                }
             }
             M = strlen(leafshi[i]);
             if (M > 0)
             {
                for (int k = 0; k < M-1; k++)
                {
                    for (int L = k+1; L < M; L++)
                    {
                        if (leafshi[i][k] > leafshi[i][L]) // swap
                        {
                           int temp1 = leafshi[i][k];
                           leafshi[i][k] = leafshi[i][L];
                           leafshi[i][L] = temp1;
                        }
                    }
                }
             }
         }

         // rescale leafs
         for (int i = 0; i < 10; i++) // bin
         {
             // do lower leafs
             counter = 0;
             for (unsigned int k = 0; k < strlen(leafslow[i]); k++)
             {
                 leafvalue = leafslow[i][k] - '0';
                 templeafs[counter] = leafslow[i][k];
                 counter++;
                 templeafs[counter] = '\0';
                 cntr = 0;
                 for (unsigned int L = k+1; L < strlen(leafslow[i]); L++)
                 {
                     cntr++;
                     if (cntr >= smallcount) break;
                     nextleaf = leafslow[i][L] - '0';
                     if (nextleaf == leafvalue) k++;
                 }
             }
             // save templeaves in leafslow
             templeafs[counter] = '\0';
             strcpy(leafslow[i],templeafs);

             // do upper leafs
             counter = 0;
             for (unsigned int k = 0; k < strlen(leafshi[i]); k++)
             {
                 leafvalue = leafshi[i][k] - '0';
                 templeafs[counter] = leafshi[i][k];
                 counter++;
                 templeafs[counter] = '\0';
                 cntr = 0;
                 for (unsigned int L = k+1; L < strlen(leafshi[i]); L++)
                 {
                     cntr++;
                     if (cntr >= smallcount) break;
                     nextleaf = leafshi[i][L] - '0';
                     if (nextleaf == leafvalue) k++;
                 }
             }
             // save templeaves in leafshi
             templeafs[counter] = '\0';
             strcpy(leafshi[i],templeafs);
         } // next bin

         // plot results
         for (int i = 0; i < 10; i++)
         {
             if (counterlow[i] > 0)
             {
                 sprintf(outline,"%6d     %3d    %s",counterlow[i],bins[i],leafslow[i]);
                 FrmOutPut->RichOutPut->Lines->Add(outline);
             }
             if (counterhi[i] > 0)
             {
                 sprintf(outline,"%6d     %3d    %s",counterhi[i],bins[i],leafshi[i]);
                 FrmOutPut->RichOutPut->Lines->Add(outline);
             }
         }

         // summarize values
         k = selected[j];
         FrmOutPut->RichOutPut->Lines->Add("");
         sprintf(outline,"Stem width = %5.2f, max. leaf depth = %2d",stemsize,smallcount);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"Min. value = %8.3f, Max. value = %8.3f",min,max);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"No. of good cases = %d",ncases);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         FrmOutPut->RichOutPut->Lines->Add("");
         for (int i = 0; i < 10; i++)
         {
             strcpy(leafshi[i],"");
             strcpy(leafslow[i],"");
             counterlow[i] = 0;
             counterhi[i] = 0;
         }
         strcpy(templeafs,"");
    } // next jth variable
    FrmOutPut->ShowModal();
    
    // clean up
//    delete[] leafs;
    delete[] frequency;
    delete[] bins;
    delete[] ValueString;
    delete[] values;
    delete[] selected;
}
//---------------------------------------------------------------------------
