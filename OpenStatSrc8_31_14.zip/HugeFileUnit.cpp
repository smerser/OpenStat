//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DictionaryUnit.h"
#include "HugeFileUnit.h"
#include "stdio.h"
#include "DataFuncs.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool openfile;
//extern bool ReadDiskFile;
bool ReadDiskFile = false;
FILE * datafile;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THugeFileForm *HugeFileForm;
//---------------------------------------------------------------------------
__fastcall THugeFileForm::THugeFileForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::FormShow(TObject *Sender)
{
     AnsiString FmtFile;
     FILE *fmtf;
     int NoLines, MaxVars, FldNo, Start, End, Type, Line, k;
     char Label[41];
     char achar;

     SpecGrid->Cells[0][0] = "Line No.";
     SpecGrid->Cells[1][0] = "Field No.";
     SpecGrid->Cells[2][0] = "Start Pos.";
     SpecGrid->Cells[3][0] = "End Pos.";
     SpecGrid->Cells[4][0] = "Data Type";
     SpecGrid->Cells[5][0] = "Label";
     SpecGrid->RowCount = 2;
     for (int i = 0; i < 6; i++) SpecGrid->Cells[i][1] = "";
     FormatFileEdit->Text = "";
     VarCntEdit->Text = "";
     FileNameEdit->Text = "";
     NoVarsEdit->Text = "";
     NoLinesEdit->Text = "";
     RecordGrid->ColCount = 2;
     RecordGrid->Cells[0][0] = "UNITS";
     RecordGrid->Cells[0][1] = "CASE 1";
     ReadDiskFile = false;
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::CancelBtnClick(TObject *Sender)
{
     HugeFileForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::ReturnBtnClick(TObject *Sender)
{
     HugeFileForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::SaveFmtBtnClick(TObject *Sender)
{
     AnsiString FmtFile;
     FILE *fmtf;
     int NoLines, MaxVars, FldNo, Start, End, Type, Line, k, linecnt;
     char Label[41];

     NoLines = StrToInt(NoLinesEdit->Text);
     MaxVars = StrToInt(NoVarsEdit->Text);
     linecnt = SpecGrid->RowCount - 1;
     NVars = StrToInt(VarCntEdit->Text);

     if (FileExists(FileNameEdit->Text))  {
        FmtFile =  ChangeFileExt(FileNameEdit->Text,".FMT");
        FormatFileEdit->Text = FmtFile;
        fmtf = fopen(FmtFile.c_str(),"wt");
        fprintf(fmtf,"%d %d %d\n", NoLines, MaxVars, NVars);
        for (int i = 1; i <= linecnt; i++)  {
            Line = StrToInt(SpecGrid->Cells[0][i]);
            FldNo = StrToInt(SpecGrid->Cells[1][i]);
            Start = StrToInt(SpecGrid->Cells[2][i]);
            End = StrToInt(SpecGrid->Cells[3][i]);
            Type = StrToInt(SpecGrid->Cells[4][i]);
            strcpy(Label, SpecGrid->Cells[5][i].c_str());
            fprintf(fmtf,"%d %d %d %d %d %s\n",Line, FldNo, Start, End, Type, Label);
        }
        fclose(fmtf);
     }
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::SpecGridKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
      if (Key == VK_DOWN)  {
        if (SpecGrid->Row == SpecGrid->RowCount-1) SpecGrid->RowCount++;
      }
      if (Key == VK_HOME) SpecGrid->Col = 1;
      if (Key == VK_END) SpecGrid->Col = SpecGrid->ColCount-1;
      if ((Key == VK_UP) && (SpecGrid->Row > 1)) SpecGrid->Row--;

}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::NoLinesEditKeyPress(TObject *Sender,
      char &Key)
{
      if (Key == 13) NoVarsEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::NoVarsEditKeyPress(TObject *Sender,
      char &Key)
{
      int nrows, nlines, maxvars;

      if (Key == 13) {
         nlines = StrToInt(NoLinesEdit->Text);
         maxvars = StrToInt(NoVarsEdit->Text);
         nrows = nlines * maxvars;
         SpecGrid->RowCount = nrows + 1;
      }
}
//---------------------------------------------------------------------------
void __fastcall THugeFileForm::TypeBoxClick(TObject *Sender)
{
     AnsiString type;
     int row, index;

     row = SpecGrid->Row;
     index = TypeBox->ItemIndex;
     SpecGrid->Cells[4][row] = IntToStr(index);
}
//---------------------------------------------------------------------------

void __fastcall THugeFileForm::OpenBtnClick(TObject *Sender)
{
//     FILE *datafile;
     AnsiString cellvalue;
     AnsiString astring;
     char value[41];
     int valcnt, recdno, VarCnt, chrcount;
     int nolines, line, maxvars, start, end, howlong, varlong;
     char inputline[10002]; // big buffer for a file line
     AnsiString *DiskValues;

     VarCnt = StrToInt(VarCntEdit->Text);
     if (VarCnt > MainForm->Grid->ColCount-1)
     {
        MainForm->Grid->ColCount = VarCnt + 1;
        RecordGrid->ColCount = VarCnt + 1;
     }

     DiskValues = new AnsiString[VarCnt];
//     nolines = StrToInt(NoLinesEdit->Text); // no. of lines per record
//     maxvars = StrToInt(NoVarsEdit->Text);  // no. of variables per line max.
     if (FileReadOps->ItemIndex == 1) // read from the disk file?
     {
        ReadDiskFile = true;
        MainForm->StatusEdit->Text = "Reading from the Disk File, not Grid.";
     }
     if (FileExists(FileName))
     {
        datafile = fopen(FileName.c_str(),"rt");
        recdno = 1;

        while (! feof(datafile))
        {
           GetDiskValues(DiskValues,VarCnt);
           for (int i = 0; i < NVars; i++)
           {
                if (!ReadDiskFile)
                        MainForm->Grid->Cells[i+1][recdno] = DiskValues[i]; // store in grid
                if (recdno == 1) RecordGrid->Cells[i+1][recdno] = DiskValues[i];
                if (recdno == 1)
                {
                        astring = SpecGrid->Cells[5][i+1]; // variable label
                        MainForm->Grid->Cells[i+1][0] = astring;
                        RecordGrid->Cells[i+1][0] = astring;
                }
            }
           if (!feof(datafile)) recdno++;

           astring = "CASE " + IntToStr(recdno);
           if (!ReadDiskFile) MainForm->Grid->Cells[0][recdno] = astring;
           if (feof(datafile)) break;
           if ((recdno-1 > MainForm->Grid->RowCount - 1) & (!ReadDiskFile)) MainForm->Grid->RowCount++;
        } // while not end of the file loop end
        NoCases = recdno - 1;
        NoVariables = NVars;
     } // for existing file
     if (!ReadDiskFile) fclose(datafile);
     BuildDic(this);
     MainForm->NoCasesEdit->Text = IntToStr(recdno-1);
     MainForm->NoVarsEdit->Text = IntToStr(NVars);
     MainForm->FileNameEdit->Text = FileName;
     UpdateOps(MainForm->SaveDialog1->FileName.c_str());
     openfile = true;
     delete[] DiskValues;
     if (ReadDiskFile) fseek(datafile,0,0);
}
//---------------------------------------------------------------------------

void __fastcall THugeFileForm::BtnDataOpenClick(TObject *Sender)
{
        OpenDialog1->Filter = "All files (*.*)|*.*|Text file (*.txt)|*.TXT";
        OpenDialog1->FilterIndex = 1;
        OpenDialog1->DefaultExt = "txt";
        if (OpenDialog1->Execute())
        {
                FileName = OpenDialog1->FileName;
                FileNameEdit->Text = FileName;
                FmtFile =  ChangeFileExt(FileName,".FMT");
                if (FileExists(FmtFile)) OpenFmtFile(this);
                else
                {
                        ShowMessage("Enter the specifications for the format below, save it and re-open the file.");
                        return;
                }
                FormatFileEdit->Text = FmtFile;
                OpenBtnClick(this);
        }
}
//---------------------------------------------------------------------------

void THugeFileForm::OpenFmtFile(TObject *Sender)
{
     // open the format file for the FileName file
     FILE *fmtf;
     int NoLines, MaxVars, FldNo, Start, End, Type, Line, i, k, linecnt;
     char Label[41];

     fmtf = fopen(FmtFile.c_str(),"rt");
     fscanf(fmtf,"%d %d %d", &NoLines, &MaxVars, &NVars);
     NoLinesEdit->Text = IntToStr(NoLines);
     NoVarsEdit->Text = IntToStr(MaxVars);
     VarCntEdit->Text = IntToStr(NVars);
     i = 0;
     while (!feof(fmtf))
     {
            fscanf(fmtf,"%d %d %d %d %d %s",&Line, &FldNo, &Start, &End, &Type, &Label);
            if (!feof(fmtf))
            {
                i++;
                SpecGrid->Cells[0][i] = IntToStr(Line);
                SpecGrid->Cells[1][i] = IntToStr(FldNo);
                SpecGrid->Cells[2][i] = IntToStr(Start);
                SpecGrid->Cells[3][i] = IntToStr(End);
                SpecGrid->Cells[4][i] = IntToStr(Type);
                SpecGrid->Cells[5][i] = Label;
            }
     }
     linecnt = i;
     SpecGrid->RowCount = linecnt+1;
     VarCntEdit->Text = IntToStr(linecnt);
     fclose(fmtf);
}
//---------------------------------------------------------------------------

void THugeFileForm::BuildDic(TObject *Sender)
{
        // build dictionary file data
        int maxvars, type, howlong;
        AnsiString cellstring;

        maxvars = MainForm->Grid->ColCount-1;
        DictionaryForm->DGrid->RowCount = maxvars + 1;
        for (int i = 1; i <= NVars; i++)
        {
                DictionaryForm->DGrid->Cells[0][i] = IntToStr(i);
                DictionaryForm->DGrid->Cells[1][i] = MainForm->Grid->Cells[i][0];
                DictionaryForm->DGrid->Cells[2][i] = MainForm->Grid->Cells[i][0];
                cellstring = MainForm->Grid->Cells[i][1];
                howlong = StrLen(cellstring.c_str());
                for (int j = 1; j <= howlong; j++)
                {
                        char ach = cellstring[j];
                        if (isalpha(ach))
                        {
                                type = 2;
                                break;
                        }
                        if (isdigit(ach)) type = 1;
                        if (ach == '.')
                        {
                                type = 0;
                                break;
                        }
                }
                DictionaryForm->DGrid->Cells[3][i] = IntToStr(type);
                if (type == 0) // floating point
                {
                        int position = Sysutils::AnsiPos(".",cellstring);
                        if (position == 0)
                        {
                                DictionaryForm->DGrid->Cells[4][i] = IntToStr(howlong);
                                DictionaryForm->DGrid->Cells[5][i] = IntToStr(0);
                        }
                        else
                        {
                                DictionaryForm->DGrid->Cells[4][i] = IntToStr(position - 1);
                                DictionaryForm->DGrid->Cells[5][i] = IntToStr(howlong - position );
                        }
                }
                if (type > 0) // integer, string , etc.
                {
                        DictionaryForm->DGrid->Cells[4][i] = IntToStr(howlong);
                        DictionaryForm->DGrid->Cells[5][i] = IntToStr(0);
                }
                DictionaryForm->DGrid->Cells[6][i] = ops.missval;
        }
}
//---------------------------------------------------------------------------

void THugeFileForm::GetDiskValues(AnsiString *&DiskValues,int NoValues)
{
        // read the disk file to get values into strings
        char inputline[1002]; // big buffer for a file line
        int howlong, start, end, varlong, chrcount, maxvars, valcnt, nolines;
        char value[41];

        nolines = StrToInt(NoLinesEdit->Text); // no. of lines per record
        maxvars = StrToInt(NoVarsEdit->Text);  // no. of variables per line max.
        valcnt = 0; // count of variables in the record
        for (int i = 0; i < nolines; i++) // repeat for each record line
        {
                fgets(inputline,1000,datafile); // read a line
                if (feof(datafile)) return;
                howlong = strlen(inputline);  // how long is the line?
                chrcount = 0; // set count of characters read to 0
                inputline[howlong-1] = '\0'; // take return line off end
                for (int j = 0; j < maxvars; j++)
                {
                        if (valcnt >= NVars) break;
                        if (chrcount >= howlong) break;
                        // get values from this line according to the format grid
                        start = StrToInt(SpecGrid->Cells[2][(i*maxvars)+j+1]);
                        end = StrToInt(SpecGrid->Cells[3][(i*maxvars)+j+1]);
                        chrcount = chrcount + (end - start + 1);
                        if (end > 0)
                        { // is there a variable here?
                                varlong = end - start + 1; // how many characters in it?
                                for (int k = 0; k < varlong; k++)
                                {
                                        value[k] = inputline[start-1+k]; // parse out those characters
                                }
                                value[varlong] = '\0';  // and terminate string
                                DiskValues[valcnt] = value;
                        }
                        valcnt++;
                }  // end of this record lines variable j
        } // end of this record line
}
//---------------------------------------------------------------------------

