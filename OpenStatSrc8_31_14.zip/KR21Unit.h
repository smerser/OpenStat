//---------------------------------------------------------------------------

#ifndef KR21UnitH
#define KR21UnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TKR21Form : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TEdit *MaxScoreEdit;
     TEdit *MeanEdit;
     TEdit *StdDevEdit;
     TEdit *RelEdit;
     TButton *CancelBtn;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TKR21Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKR21Form *KR21Form;
//---------------------------------------------------------------------------
#endif
