//---------------------------------------------------------------------------

#ifndef SPCRangeUnitH
#define SPCRangeUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSPCRangeForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TRadioGroup *SigmaGroup;
     TGroupBox *OptionsGroup;
     TCheckBox *ShowUpperChk;
     TCheckBox *ShowLowerChk;
     TCheckBox *UseTargetChk;
     TEdit *UpperSpecEdit;
     TEdit *LowerSpecEdit;
     TEdit *TargetSpecEdit;
     TLabel *Label2;
     TEdit *GroupEdit;
     TLabel *Label3;
     TEdit *MeasEdit;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TEdit *SigmaEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PlotMeans(double *means,
                     int NoGrps,
                     double UCL, double LCL, double GrandMean,
                     double TargetSpec, double LowerSpec, double UpperSpec,
                     TObject *Sender);

private:	// User declarations
public:		// User declarations
     __fastcall TSPCRangeForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSPCRangeForm *SPCRangeForm;
//---------------------------------------------------------------------------
#endif
