//---------------------------------------------------------------------------
#ifndef FrmSelRndmH
#define FrmSelRndmH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
class TSelRndm : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GroupBox1;
	TRadioButton *BtnApprox;
	TEdit *TxtPcntCases;
	TLabel *Label1;
	TRadioButton *BtnExactly;
	TEdit *TxtCases;
	TLabel *Label2;
	TEdit *TxtFromFirst;
	TLabel *Label3;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnHelp;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
    void __fastcall BtnHelpClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TSelRndm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TSelRndm *SelRndm;
//---------------------------------------------------------------------------
#endif
