//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "stdio.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "StepBackUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStepBackForm *StepBackForm;
extern int NoCases;
extern int NoVariables;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TStepBackForm::TStepBackForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     MatInChk->Checked = false;
     SaveCorrsChk->Checked = false;
     PredictChk->Checked = false;
     CrossProdChk->Checked = false;
     CovarChk->Checked = false;
     CorrsChk->Checked = false;
     InverseChk->Checked = false;
     MeansChk->Checked = false;
     VariancesChk->Checked = false;
     StdDevsChk->Checked = false;
     BPGChk->Checked = false;
     DepEdit->Text = "";
/*
     if (ops.format == 0)
     {
        InProbEdit->Text = "0.05";
        OutProbEdit->Text = "0.10";
     }
     else
     {
        InProbEdit->Text = "0,05";
        OutProbEdit->Text = "0,10";
     }
*/
     DepOutBtn->Visible = false;
     DepInBtn->Visible = true;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::DepOutBtnClick(TObject *Sender)
{
     if (DepEdit->Text == "") return;
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::AllBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     for (int i = 0; i < VarList->Items->Count; i++)
         SelList->Items->Add(VarList->Items->Strings[i]);
     VarList->Clear();
     IndInBtn->Visible = false;
     IndOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TStepBackForm::OKBtnClick(TObject *Sender)
{
     int i, j, k, k1, col, NoVars, mattype, NCases,errcnt, Index, NoIndepVars;
     bool errorcode, showinverse;
     double largest, R2, Constant, Beta, df1, df2, SSt, SSres, VarEst, determinant;
     double StdErrEst, F, FProbF, sum, B, SSx, StdErrB, NewR2, LowestPartial;
     double pdf1, pdf2, PartF, PartProb, LargestProb, POut, SmallestProb;
     double *BetaWeights, *BWeights, *BStdErrs, *Bttests, *Bprobs;
     AnsiString cellstring, valstring, title;
     char outline[121];
     double **corrs, **ProdMat;
     double *Means;
     double *Variances;
     double *StdDevs;
     int *ColNoSelected;
     AnsiString *RowLabels;
     AnsiString *ColLabels;
     AnsiString *IndRowLabels;
     AnsiString *IndColLabels;
     double **CorrMat;
     double **InverseMat;
     int *IndepIndex;
     double *XYCorrs;
     bool matched;
     double *Partial;
     int *Candidate;
     int TempNoVars;
     int StepNo, OriginNoVars;
     AnsiString filename;
     bool doneonce = false;
     int result;

//     if (NoVariables < 2) NoVariables = 200;

     GetDblMatMem(corrs,NoVariables+1,NoVariables+1);
     GetDblMatMem(CorrMat,NoVariables+1,NoVariables+1);
     GetDblMatMem(InverseMat,NoVariables,NoVariables);
     GetDblMatMem(ProdMat,NoVariables,NoVariables);
     Means = new double[NoVariables];
     Variances = new double[NoVariables];
     StdDevs = new double[NoVariables];
     RowLabels = new AnsiString[NoVariables];
     ColLabels = new AnsiString[NoVariables];
     XYCorrs = new double[NoVariables];
     IndepIndex = new int[NoVariables];
     IndColLabels = new AnsiString[NoVariables];
     IndRowLabels = new AnsiString[NoVariables];
     BetaWeights = new double[NoVariables];
     BWeights = new double[NoVariables];
     BStdErrs = new double[NoVariables];
     Bttests = new double[NoVariables];
     Bprobs = new double[NoVariables];
     Partial = new double[NoVariables];
     Candidate = new int[NoVariables];
     ColNoSelected = new int[NoVariables];

     OriginNoVars = NoVariables; // note - additional variables might be created
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Stepwise Backward Multiple Regression by Bill Miller");
     errorcode = false;
     if (MatInChk->Checked)
     {
               LoadMatrix();
               NoVars = NoVariables;
               NCases = NoCases;
               for (i = 0; i < NoVars; i++)
               {
                    Means[i] = 0.0;
                    StdDevs[i] = 1.0;
                    Variances[i] = sqr(StdDevs[i]);
                    ColNoSelected[i] = i+1;
                    RowLabels[i] = MainForm->Grid->Cells[i+1][0];
                    ColLabels[i] = RowLabels[i];
               }
               for (i = 0; i < NoVars; i++)
               {
                   VarList->Items->Add(RowLabels[i]);
                   for (j = 0; j < NoVars; j++)
                       corrs[i][j] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][j+1]));
               }
//          }
     }
     else
     {
          // get independent item columns
          NoVars = SelList->Items->Count;
          if (NoVars < 1)
          {
               ShowMessage("ERROR! No independent variables selected.");
               goto CleanUp;
          }
          for (i = 0; i < NoVars; i++)
          {
               cellstring = SelList->Items->Strings[i];
               for (j = 1; j <= NoVariables; j++)
               {
                    if (cellstring == MainForm->Grid->Cells[j][0])
                    {
                         ColNoSelected[i] = j;
                         //result = VarTypeChk(j,0);
                         //if (result == 1) goto CleanUp;
                         RowLabels[i] = cellstring;
                         ColLabels[i] = cellstring;
                    }
               }
          }
          // get dependendent variable column
          if (DepEdit->Text == "")
          {
               ShowMessage("ERROR! No Dependent variable selected.");
               goto CleanUp;
          }
          NoVars = NoVars + 1;
          for (j = 1; j <= NoVariables; j++)
          {
               if (DepEdit->Text == MainForm->Grid->Cells[j][0])
               {
                    ColNoSelected[NoVars-1] = j;
                    //result = VarTypeChk(j,0);
                    //if (result == 1) goto CleanUp;
                    RowLabels[NoVars-1] = DepEdit->Text;
                    ColLabels[NoVars-1] = DepEdit->Text;
               }
          }
          NoCases = MainForm->Grid->RowCount - 1;
          NCases = NoCases;
     }

     if (InverseChk->Checked) showinverse = true;
     else showinverse = false;
     POut = 1.0;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Backward Stepwise Multiple Regression by Bill Miller");
     StepNo = 1;

     while (NoVars > 1)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"----------------- STEP %d ------------------",StepNo);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if ((CrossProdChk->Checked)&& (!MatInChk->Checked))
        {
           Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected, NCases, 1, false, 0);
           MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Cross-Products Matrix");
        }

        if ((CovarChk->Checked)&&(!MatInChk->Checked))
        {
               Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected,
                  NCases, 2, false, 0);
               MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Variance-Covariance Matrix");
          }
          if (!MatInChk->Checked)
             Correlations(Means, StdDevs, corrs, NoVars,ColNoSelected, NCases,
                       3, false, 0);

          if (CorrsChk->Checked)
             MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Product-Moment Correlations Matrix");

          if (SaveCorrsChk->Checked)
          {
             SaveDialog1->Filter = "OpenStat matrix files (*.MAT)|*.MAT|All files (*.*)|*.*";
             SaveDialog1->FilterIndex = 1;
             if (SaveDialog1->Execute())
             {
                filename = SaveDialog1->FileName;
                SaveSqrMat(corrs, NoVars, NCases, RowLabels, Means, StdDevs);
             }
             SaveCorrsChk->Checked = false;
          }
          for (int i = 0; i < NoVars; i++) Variances[i] = sqr(StdDevs[i]);
          if (MeansChk->Checked)
          {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(Means,NoVars,ColLabels,"Means");
          }
          if (VariancesChk->Checked)
          {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(Variances,NoVars,ColLabels,"Variances");
          }
          if (StdDevsChk->Checked)
          {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(StdDevs,NoVars,ColLabels,"Standard Deviations");
          }
          if (errorcode)
          {
             FrmOutPut->RichOutPut->Lines->Add("One or more correlations could not be computed due to zero variance of a variable.");
          }
//          FrmOutPut->ShowModal();

          if (errorcode)
          {
             ShowMessage("ERROR! A selected variable has no variability-run aborted.");
             goto CleanUp;
          }

          // get determinant of the correlation matrix
          determinant;
          for (i = 0; i < NoVars; i++)
              for (j = 0; j < NoVars; j++)
                  CorrMat[i][j] = corrs[i][j];
          determinant = Determ(CorrMat,NoVars);
          if (determinant < 0.000001)
          {
               ShowMessage("ERROR! Matrix is singular!");
//               goto CleanUp;
          }
          sprintf(outline,"Determinant of correlation matrix = %8.4f",determinant);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          NoIndepVars = NoVars-1;
          for (i = 1; i <= NoIndepVars; i++) IndepIndex[i-1] = i;
          MReg2(NCases,NoVars,NoIndepVars,IndepIndex,corrs,InverseMat,
               RowLabels,R2,BetaWeights,
               Means,Variances,errcnt,StdErrEst,Constant,POut,true, false,showinverse);

          if (PredictChk->Checked)
          {
             AnsiString astring;
             astring = InputBox("PREDICTION","Enter predicted values for "+IntToStr(StepNo),"Y");
             if (astring == "Y")
             {
                Predict(ColNoSelected, IndepIndex,NoVars, InverseMat, Means, StdDevs, BetaWeights,
                     BWeights, Constant, StdErrEst, NoIndepVars);
                doneonce = true;
             }
          }
          if (doneonce) PredictChk->Checked = false;

         // Get partial correlation matrix
         for (i = 1; i <= NoVars; i++)
              for (j = 1; j <= NoVars; j++)
                   InverseMat[i-1][j-1] = corrs[i-1][j-1];
         SVDinverse(InverseMat,NoVars);
         for (i = 1; i <= NoVars; i++)
         {
    	        for (j = 1; j <= NoVars; j++)
             {
                   ProdMat[i-1][j-1] = -(1.0 / sqrt(InverseMat[i-1][i-1])) *
            	   InverseMat[i-1][j-1] * (1.0 / sqrt(InverseMat[j-1][j-1]));
             }
         }
         LowestPartial = 1.0;
         Index = NoIndepVars;
         for (i = 1; i <= NoIndepVars; i++)
         {
              BetaWeights[i-1] = ProdMat[i-1][NoVars-1];
              if (fabs(BetaWeights[i-1]) < LowestPartial)
              {
                   LowestPartial = fabs(BetaWeights[i-1]);
                   Index = i;
              }
         }
         VPrint(BetaWeights,NoIndepVars,ColLabels,"Partial Correlations");
//         FrmOutPut->ShowModal();

         // eliminate variable with lowest partial }
         if (NoVars > 2)
         {
              sprintf(outline,"Variable %d (%s) eliminated",Index,ColLabels[Index-1].c_str());
              FrmOutPut->RichOutPut->Lines->Add(outline);
              for (i = Index; i < NoVars; i++)
              {
                   ColNoSelected[i-1] = ColNoSelected[i];
                   ColLabels[i-1] = ColLabels[i];
                   RowLabels[i-1] = RowLabels[i];
              }
              NoVars = NoVars - 1;
              StepNo = StepNo + 1;
              FrmOutPut->ShowModal();
         }
         else NoVars = 0;
     }
     FrmOutPut->ShowModal();
     
CleanUp:
     delete[] ColNoSelected;
     delete[] Candidate;
     delete[] Partial;
     delete[] Bprobs;
     delete[] Bttests;
     delete[] BStdErrs;
     delete[] BWeights;
     delete[] BetaWeights;
     delete[] IndColLabels;
     delete[] IndRowLabels;
     delete[] IndepIndex;
     delete[] XYCorrs;
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
     ClearDblMatMem(ProdMat,OriginNoVars);
     ClearDblMatMem(InverseMat,OriginNoVars);
     ClearDblMatMem(CorrMat,OriginNoVars+1);
     ClearDblMatMem(corrs,OriginNoVars+1);
}
//---------------------------------------------------------------------------
