//---------------------------------------------------------------------------

#ifndef ABRAnovaH
#define ABRAnovaH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TABRForm : public TForm
{
__published:	// IDE-managed Components
    TListBox *VarList;
    TLabel *Label1;
    TEdit *AEdit;
    TEdit *BEdit;
    TListBox *RListBox;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TGroupBox *GroupBox1;
    TCheckBox *HomoCovarChkBox;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TBitBtn *AinBtn;
    TBitBtn *AoutBtn;
    TBitBtn *BinBtn;
    TBitBtn *BoutBtn;
    TBitBtn *CinBtn;
    TBitBtn *CoutBtn;
    TLabel *Label2;
    TEdit *NinGrpEdit;
    TMemo *Memo1;
    TCheckBox *MeansChkBox;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall AinBtnClick(TObject *Sender);
    void __fastcall BinBtnClick(TObject *Sender);
    void __fastcall CinBtnClick(TObject *Sender);
    void __fastcall AoutBtnClick(TObject *Sender);
    void __fastcall BoutBtnClick(TObject *Sender);
    void __fastcall CoutBtnClick(TObject *Sender);

private:	// User declarations
    void __fastcall GetData(TObject *Sender);
    void __fastcall Calculations(TObject *Sender);
    void __fastcall Summary(TObject *Sender);
    void __fastcall MeansReport(TObject *Sender);
    void __fastcall BoxTests(TObject *Sender);
    void __fastcall GraphMeans(TObject *Sender);
    void __fastcall CleanUp(TObject *Sender);
    
    double GrandTotal, SumXSqr, *ASums, *BSums, *CSums, **ABSums;
    double **ACSums, **BCSums, ***ABCSums, *SumPSqr, **Matrix, **PooledMat;
    double Term1, Term2, Term3, Term4, Term5, Term6, Term7, Term8;
    double Term9, Term10, SSBetweenSubjects, SSA, SSB, SSAB, SSerrorBetween;
    double SSWithinSubjects, SSC, SSAC, SSBC, SSABC, SSerrorWithin;
    double DFBetween, DFA, DFB, DFAB, DFerrorBetween, DFWithin, DFC, DFAC;
    double DFBC, DFABC, DFerrorWithin, MSA, MSB, MSAB, MSerrorBetween;
    double MSC, MSAC, MSBC, MSABC, MSerrorWithin, FA, FB, FAB, FC, FAC;
    double FBC, FABC, ProbA, ProbB, ProbAB, ProbC, ProbAC, ProbBC, ProbABC;
    int MinA, MaxA, MinB, MaxB, group, NoAGrps, NoBGrps, SubjA, SubjB, SubjC;
    int *ColNoSelected, NoSelected, ACol, BCol, *Ccolumns, NinGrp;
    int MaxRows, MaxCols;
    AnsiString *RowLabels, *ColLabels;
    
public:		// User declarations
    __fastcall TABRForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TABRForm *ABRForm;
//---------------------------------------------------------------------------
#endif
