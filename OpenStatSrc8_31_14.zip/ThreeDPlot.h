//---------------------------------------------------------------------------
#ifndef ThreeDPlotH
#define ThreeDPlotH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrm3DPlot : public TForm
{
__published:	// IDE-managed Components
    TButton *PrintBtn;
    TButton *OkBtn;
    TScrollBar *XScroll;
    TScrollBar *YScroll;
    TScrollBar *ZScroll;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *XEdit;
    TEdit *YEdit;
    TEdit *ZEdit;
    TLabel *Label4;
    TListBox *ListBox1;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *XVarEdit;
    TLabel *Label7;
    TEdit *YVarEdit;
    TLabel *Label8;
    TEdit *ZVarEdit;
    TButton *CancelBtn;
    void __fastcall OkBtnClick(TObject *Sender);
    void __fastcall PrintBtnClick(TObject *Sender);
    void __fastcall XScrollScroll(TObject *Sender, TScrollCode ScrollCode,
          int &ScrollPos);
    void __fastcall YScrollScroll(TObject *Sender, TScrollCode ScrollCode,
          int &ScrollPos);
    void __fastcall ZScrollScroll(TObject *Sender, TScrollCode ScrollCode,
          int &ScrollPos);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ListBox1Click(TObject *Sender);
private:	// User declarations
    typedef struct {
        float x,y,z;
    } POINT3D;
    typedef struct {
        int x,y;
    } POINTint;
    // World limits in 2D
    float WXleft;
    float WXright;
    float WYtop;
    float WYbottom;
    // Device limits
    int DXmin;
    int DYmin;
    int DYmax;
    int DXmax;
    // Rotations for 3D view in radians
    float RX;
    float RY;
    float RZ;
    float COSRX;
    float SINRX;
    float COSRY;
    float SINRY;
    float COSRZ;
    float SINRZ;
    // pointers to scaled x, y and z points
    float *XScaled;
    float *YScaled;
    float *ZScaled;
    // Slider degree angles
    float degX;
    float degY;
    float degZ;
public:		// User declarations
    __fastcall TFrm3DPlot(TComponent* Owner);
    void __fastcall Rotate(TObject* Sender);
    POINT3D __fastcall World3DToWorld2D(POINT3D p, TObject *Sender);
    POINTint __fastcall World2DToDevice(POINT3D p, TObject *Sender);
    void __fastcall drawpoint(POINT3D p1, TObject *Sender);
    void __fastcall drawline(POINT3D p1, POINT3D p2, TObject *Sender);
    void __fastcall SetAxesAngles(float rx, float ry, float rz, TObject *Sender);
    float __fastcall DegToRad(float deg,TObject *Sender);
    float __fastcall RadToDeg(float rad,TObject *Sender);
    void __fastcall drawaxis(TObject *Sender);
    void __fastcall ScaleValues(TObject *Sender);
    void __fastcall TFrm3DPlot::eraseaxis(TObject *Sender);
    int GridColX;
    int GridColY;
    int GridColZ;
};
//---------------------------------------------------------------------------
extern PACKAGE TFrm3DPlot *Frm3DPlot;
//---------------------------------------------------------------------------
#endif


