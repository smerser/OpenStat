//---------------------------------------------------------------------------

#ifndef StepFwdUnitH
#define StepFwdUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TStepFwdForm : public TForm
{
__published:	// IDE-managed Components
     TListBox *VarList;
     TListBox *SelList;
     TBitBtn *DepInBtn;
     TBitBtn *DepOutBtn;
     TBitBtn *AllBtn;
     TBitBtn *IndInBtn;
     TBitBtn *IndOutBtn;
     TEdit *DepEdit;
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label3;
     TGroupBox *GroupBox1;
     TCheckBox *MatInChk;
     TCheckBox *SaveCorrsChk;
     TCheckBox *PredictChk;
     TCheckBox *CrossProdChk;
     TCheckBox *CovarChk;
     TCheckBox *CorrsChk;
     TCheckBox *InverseChk;
     TCheckBox *MeansChk;
     TCheckBox *VariancesChk;
     TGroupBox *GroupBox2;
     TLabel *Label4;
     TLabel *Label5;
     TEdit *InProbEdit;
     TEdit *OutProbEdit;
     TCheckBox *StdDevsChk;
     TCheckBox *BPGChk;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TOpenDialog *OpenDialog1;
     TSaveDialog *SaveDialog1;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall DepInBtnClick(TObject *Sender);
     void __fastcall DepOutBtnClick(TObject *Sender);
     void __fastcall IndInBtnClick(TObject *Sender);
     void __fastcall IndOutBtnClick(TObject *Sender);
     void __fastcall AllBtnClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TStepFwdForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStepFwdForm *StepFwdForm;
//---------------------------------------------------------------------------
#endif
