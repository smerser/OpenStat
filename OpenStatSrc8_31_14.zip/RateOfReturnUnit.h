//---------------------------------------------------------------------------

#ifndef RateOfReturnUnitH
#define RateOfReturnUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TRateReturnFrm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TEdit *FileNameEdit;
     TLabel *Label2;
     TEdit *SizeEdit;
     TLabel *Label3;
     TEdit *GuessEdit;
     TButton *ComputeBtn;
     TLabel *Label4;
     TEdit *ROREdit;
     TButton *ReturnBtn;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TRateReturnFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRateReturnFrm *RateReturnFrm;
//---------------------------------------------------------------------------
#endif
