//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "OptionsUnit.h"
#include "DataFuncs.h"
#include "PrevFileUnit.h"
#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOptionsForm *OptionsForm;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TOptionsForm::TOptionsForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOptionsForm::OKBtnClick(TObject *Sender)
{
// save results in an options file
        SetCurrentDir(DataPathEdit->Text);
        DirectoryList->OpenCurrent();
        SaveOptions();
//   GetOptions();
}
//---------------------------------------------------------------------------
void __fastcall TOptionsForm::FormShow(TObject *Sender)
{
     FILE *stream;
     if ((stream = fopen("OPTIONS.FIL", "r"))
       == NULL)
     {
        ShowMessage("Create an OPTIONS.FIL by completing the dialog information.");
        HomePathEdit->Text = GetCurrentDir();
        DataPathEdit->Text = GetCurrentDir();
     }
     else
     {
        fread(&ops,sizeof(ops),1,stream);
        NumbersGrp->ItemIndex = ops.format; // american or european
        FldWidthEdit->Text = IntToStr(ops.gridfldwidth);
        DecimalsEdit->Text = IntToStr(ops.gridnodecimals);
        MissValEdit->Text = ops.missval;
//        NumberPrintGrp->ItemIndex = ops.printformat;
//        PrntWideEdit->Text = IntToStr(ops.printwidth);
//        PrintNoDecEdit->Text = IntToStr(ops.printdecimals);
//        PrintMissValEdit->Text = ops.printmissvals;
//        PrintSpacesEdit->Text = IntToStr(ops.printspaces);
        if (strlen(ops.HomePath) < 2) HomePathEdit->Text = GetCurrentDir();
        else HomePathEdit->Text = ops.HomePath;
        if (strlen(ops.DataPath) < 2) DataPathEdit->Text = GetCurrentDir();
        else DataPathEdit->Text = ops.DataPath;
        SetCurrentDir(DataPathEdit->Text);
        for (int i = 0; i < 10; i++)
        {
            PrevFileForm->Grid->Cells[0][i+1] = ops.PrevFiles[i].FileName;
            PrevFileForm->Grid->Cells[1][i+1] = ops.PrevFiles[i].Date;
            PrevFileForm->Grid->Cells[2][i+1] = ops.PrevFiles[i].Time;
        }
     }
     fclose(stream);
}
//---------------------------------------------------------------------------


void __fastcall TOptionsForm::DriveComboDblClick(TObject *Sender)
{
        // drive double clicked here
        DirectoryList->Drive = DriveCombo->Drive;
        FileListBox1->Drive = DriveCombo->Drive;
}
//---------------------------------------------------------------------------


void __fastcall TOptionsForm::DirectoryListDblClick(TObject *Sender)
{
        FileListBox1->Directory = DirectoryList->Directory;
        DataPathEdit->Text = "";
        DataPathEdit->Text = DirectoryList->Directory;
        strcpy(ops.DataPath,DataPathEdit->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TOptionsForm::DriveComboChange(TObject *Sender)
{
        DriveComboDblClick(this);        
}
//---------------------------------------------------------------------------

