//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "PlotUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "FreqDistUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "SingleValuePlot.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSingleValuePlotForm *SingleValuePlotForm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TSingleValuePlotForm::TSingleValuePlotForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSingleValuePlotForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     DescChk->Checked = false;
     YEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSingleValuePlotForm::YInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     YEdit->Text = Varlist->Items->Strings[index];        
}
//---------------------------------------------------------------------------
void __fastcall TSingleValuePlotForm::OKBtnClick(TObject *Sender)
{
     double Xmin, Xmax, Ymin, Ymax, SSx, t, DF;
     double Xmean, Ymean, Yvariance, Ystddev;
     double X, Y, temp, SEPred, Slope, Intercept, predicted, sedata;
     int i, j, Xcol, Ycol, N, NoSelected;
     double *Xpoints,  *Ypoints;
     AnsiString cellstring;
     int *ColNoSelected;
     char outline[121];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     GetDblVecMem(Xpoints,NoCases+1); //SetLength(Xpoints,NoCases + 1);
     GetDblVecMem(Ypoints,NoCases+1); //SetLength(Ypoints,NoCases + 1);
     ColNoSelected = new int[2];
     Xcol = 0;
     Ycol = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == YEdit->Text) Ycol = i;
     }
     if (Ycol == 0)
     {
        ShowMessage("ERROR! First, select a Y variable.");
        goto cleanup;
     }
     NoSelected = 1;
     ColNoSelected[0] = Ycol;
     N = 0;
     Xmax = NoCases;
     Xmin = 1;
     Ymax = -1.0e20;
     Ymin = 1.0e20;
     Ymean = 0.0;
     Yvariance = 0.0;
     for (i = 1; i <= NoCases; i++)
     {
          if (!ValidRecord(i,ColNoSelected,NoSelected)) continue;
          if (!ValidValue(i,ColNoSelected[0])) continue;
          N = N + 1;
          X = float(i);
          Y = StrToFloat(MainForm->Grid->Cells[Ycol][i]);
          Xpoints[N] = X;
          Ypoints[N] = Y;
          if (Y > Ymax) Ymax = Y;
          if (Y < Ymin) Ymin = Y;
          Ymean = Ymean + Y;
          Yvariance = Yvariance + (Y * Y);
     }
     // sort on Y
     for (i = 1; i <= N - 1; i++)
     {
          for (j = i + 1; j <= N; j++)
          {
               if (Ypoints[i] > Ypoints[j]) //swap
               {
                    temp = Ypoints[i];
                    Ypoints[i] = Ypoints[j];
                    Ypoints[j] = temp;
               }
          }
     }

     // calculate statistics
     Yvariance = Yvariance - (Ymean * Ymean / N);
     Yvariance = Yvariance / (N - 1);
     Ystddev = sqrt(Yvariance);
     Ymean = Ymean / N;

     // Now, print the descriptive statistics if requested
     if (DescChk->Checked)
     {
          FrmOutPut->RichOutPut->Lines->Add("Y Plot");
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Y = %s from file: %s",
                YEdit->Text.c_str(),MainForm->FileNameEdit->Text.c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("Variable     Mean   Variance  Std.Dev.");
          sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f",YEdit->Text.c_str(),Ymean,Yvariance,Ystddev);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Number of good cases = %d",N);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->ShowModal();
     }
     // plot the values (and optional line and confidence band if elected)
     plotxy(Xpoints, Ypoints, Ymean, Xmax, Xmin, Ymax, Ymin, N);

     PlotForm->ShowModal();

cleanup:
     delete[] ColNoSelected;
     delete[] Ypoints;
     delete[] Xpoints;
}
//---------------------------------------------------------------------------

void __fastcall TSingleValuePlotForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double Ymean,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];

     Title = "Y PLOT Using File: " + MainForm->FileNameEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // Draw vertical axis
     Title = YEdit->Text;
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YEdit->Text);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 1; i <= N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }

}
//-------------------------------------------------------------------

