//---------------------------------------------------------------------------

#ifndef CombinationsUnitH
#define CombinationsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TCombinationsForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TEdit *XEdit;
        TLabel *Label2;
        TEdit *NEdit;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *CombosEdit;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TCombinationsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCombinationsForm *CombinationsForm;
//---------------------------------------------------------------------------
#endif
