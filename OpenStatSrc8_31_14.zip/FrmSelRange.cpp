//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FrmSelRange.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TSelRange *SelRange;
//---------------------------------------------------------------------------
__fastcall TSelRange::TSelRange(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelRange::BtnOKClick(TObject *Sender)
{
	SelRange->Visible = false;	
}
//---------------------------------------------------------------------------
void __fastcall TSelRange::BtnCancelClick(TObject *Sender)
{
	SelRange->Visible = false;	
}
//---------------------------------------------------------------------------
void __fastcall TSelRange::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OpenStat.hlp";
  Application->HelpJump("selectif");

}
//---------------------------------------------------------------------------
