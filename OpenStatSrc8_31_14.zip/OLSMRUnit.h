//---------------------------------------------------------------------------

#ifndef OLSMRUnitH
#define OLSMRUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TOLSMRForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *LstVariables;
        TBitBtn *DepInBtn;
        TLabel *Label1;
        TEdit *DepVarEdit;
        TBitBtn *IndInBtn;
        TBitBtn *IndOutBtn;
        TListBox *IndepList;
        TLabel *Label4;
        TEdit *SigInEdit;
        TButton *BtnReset;
        TButton *BtnCancel;
        TButton *ComputeBtn;
        TButton *BtnOK;
        TGroupBox *OptionsBox;
        TCheckBox *DescChk;
        TCheckBox *XMatChk;
        TCheckBox *XTransChk;
        TCheckBox *XTXChk;
        TCheckBox *XTXInvChk;
        TCheckBox *XTXInvXTChk;
        TCheckBox *bVectorChk;
        TCheckBox *PredYVecChk;
        TCheckBox *ResidVecChk;
        TCheckBox *SavePredChk;
        TCheckBox *ResidSaveChk;
        TCheckBox *YvsPredYChk;
        TCheckBox *YvsResidChk;
        TLabel *Label3;
        void __fastcall DepInBtnClick(TObject *Sender);
        void __fastcall IndInBtnClick(TObject *Sender);
        void __fastcall IndOutBtnClick(TObject *Sender);
        void __fastcall BtnResetClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
        __fastcall TOLSMRForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOLSMRForm *OLSMRForm;
//---------------------------------------------------------------------------
#endif
