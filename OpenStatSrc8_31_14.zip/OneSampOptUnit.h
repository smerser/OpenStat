//---------------------------------------------------------------------------

#ifndef OneSampOptUnitH
#define OneSampOptUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TOneSampOptForm : public TForm
{
__published:	// IDE-managed Components
    TButton *CancelBtn;
    TButton *OKBtn;
    TLabel *Label1;
    TListBox *VarList;
    TBitBtn *XVarInBtn;
    TBitBtn *XVarOutBtn;
    TEdit *XVarEdit;
    TLabel *Label2;
    TBitBtn *YVarInBtn;
    TBitBtn *YVarOutBtn;
    TEdit *YVarEdit;
    TLabel *Label3;
    TMemo *Memo1;
    TLabel *Label4;
    TEdit *TestForEdit;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall XVarInBtnClick(TObject *Sender);
    void __fastcall YVarInBtnClick(TObject *Sender);
    void __fastcall XVarOutBtnClick(TObject *Sender);
    void __fastcall YVarOutBtnClick(TObject *Sender);
private:	// User declarations
    int SelItem, XCol, YCol;
public:		// User declarations
    __fastcall TOneSampOptForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOneSampOptForm *OneSampOptForm;
//---------------------------------------------------------------------------
#endif
