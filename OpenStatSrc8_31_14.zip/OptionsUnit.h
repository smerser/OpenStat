//---------------------------------------------------------------------------

#ifndef OptionsUnitH
#define OptionsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TOptionsForm : public TForm
{
__published:	// IDE-managed Components
   TRadioGroup *NumbersGrp;
   TGroupBox *InputBox;
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TEdit *FldWidthEdit;
   TEdit *DecimalsEdit;
   TEdit *MissValEdit;
   TRadioGroup *NumberPrintGrp;
   TButton *CancelBtn;
   TButton *OKBtn;
        TLabel *Label8;
        TDriveComboBox *DriveCombo;
        TDirectoryListBox *DirectoryList;
        TFileListBox *FileListBox1;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TEdit *HomePathEdit;
        TLabel *Label4;
        TEdit *DataPathEdit;
   void __fastcall OKBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
        void __fastcall DriveComboDblClick(TObject *Sender);
        void __fastcall DirectoryListDblClick(TObject *Sender);
        void __fastcall DriveComboChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TOptionsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOptionsForm *OptionsForm;
//---------------------------------------------------------------------------
#endif
