//---------------------------------------------------------------------------

#ifndef AboutMeUnitH
#define AboutMeUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
//---------------------------------------------------------------------------
class TAboutFrm : public TForm
{
__published:	// IDE-managed Components
     TLabel *ProductName;
     TLabel *Copyright;
     TLabel *Comments;
     TLabel *Label1;
     TImage *Image1;
     TButton *CloseBtn;
private:	// User declarations
public:		// User declarations
     __fastcall TAboutFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAboutFrm *AboutFrm;
//---------------------------------------------------------------------------
#endif
