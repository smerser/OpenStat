//---------------------------------------------------------------------------

#ifndef MedianPolishUnitH
#define MedianPolishUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TMedianPolishForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *DepIn;
        TBitBtn *DepOut;
        TBitBtn *Fact1In;
        TBitBtn *Fact1Out;
        TBitBtn *Fact2In;
        TBitBtn *Fact2Out;
        TEdit *DepVar;
        TEdit *Factor1;
        TEdit *Factor2;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TButton *CancelBtn;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TLabel *Label5;
        TEdit *MaxEdit;
        TRadioButton *ItersBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall DepInClick(TObject *Sender);
        void __fastcall DepOutClick(TObject *Sender);
        void __fastcall Fact1InClick(TObject *Sender);
        void __fastcall Fact1OutClick(TObject *Sender);
        void __fastcall Fact2InClick(TObject *Sender);
        void __fastcall Fact2OutClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
//        void __fastcall ItersBtnClick(TObject *Sender);
private:	// User declarations
        double *CumRowResiduals;
        double *CumColResiduals;
        double Median(Double *X, int size);
        void PrintObsTable(double **ObsTable, int nrows, int ncols);
        void PrintResults(double **ObsTable, double *rowmedian,
             double *rowresid, double *colmedian, double *colresid,
             int nrows, int ncols);
        void sortvalues(double *X, int size);
        void TwoWayPlot(int NF1cells, double *RowSums,
           AnsiString graphtitle, AnsiString Heading);
        void InteractPlot(int NF1cells, int NF2Cells,
           double **ObsTable, AnsiString graphtitle, AnsiString Heading);
public:		// User declarations
        __fastcall TMedianPolishForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMedianPolishForm *MedianPolishForm;
//---------------------------------------------------------------------------
#endif
