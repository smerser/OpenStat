//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PlotUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "FreqDistUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "DictionaryUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "MultGrpXYPlotUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMultGrpXYPlot *MultGrpXYPlot;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TMultGrpXYPlot::TMultGrpXYPlot(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     DescChk->Checked = false;
     XEdit->Text = "";
     YEdit->Text = "";
     GroupEdit->Text = "";
     XInBtn->Visible = true;
     XOutBtn->Visible = false;
     YInBtn->Visible = true;
     YOutBtn->Visible = false;
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
     PlotTitleEdit->Text = "";
     LinesBox->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::FormShow(TObject *Sender)
{
     ResetBtnClick(this);        
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::XInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     XEdit->Text = Varlist->Items->Strings[index];
     Varlist->Items->Delete(index);
     XOutBtn->Visible = true;
     XInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::XOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(XEdit->Text);
     XEdit->Text = "";
     XInBtn->Visible = true;
     XOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::YInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     YEdit->Text = Varlist->Items->Strings[index];
     Varlist->Items->Delete(index);
     YOutBtn->Visible = true;
     YInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::YOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(YEdit->Text);
     YEdit->Text = "";
     YInBtn->Visible = true;
     YOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::GrpInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     GroupEdit->Text = Varlist->Items->Strings[index];
     Varlist->Items->Delete(index);
     GrpOutBtn->Visible = true;
     GrpInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::GrpOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(GroupEdit->Text);
     GroupEdit->Text = "";
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TMultGrpXYPlot::OKBtnClick(TObject *Sender)
{
        int i, j, N, NoGrps, XCol, YCol, GrpCol, Grp, MinGrp, MaxGrp, NoSelected;
        int tempcol;
        int MaxGrpSize = 0;
        int *selected, *NoInGrp;
        double **YValues, **XValues, *Means, *StdDevs;
        double MinX, MaxX, MinY, MaxY, X, Y, temp;
        AnsiString cellstring;
        char prtline[101];
        bool results;
        int result, intvalue;
        double dblvalue;
        AnsiString strvalue;

        selected = new int[3];
        MaxX = -1.0e20;
        MinX = 1.0e20;
        MaxY = -1.0e20;
        MinY = 1.0e20;
        MinGrp = 1000;
        MaxGrp = -1000;
        N = 0;

        // Get selected variables
        for (i = 1;i <= NoVariables; i++)
        {
                cellstring = MainForm->Grid->Cells[i][0];
                if (cellstring == XEdit->Text) selected[0] = i;
                if (cellstring == YEdit->Text) selected[1] = i;
                if (cellstring == GroupEdit->Text) selected[2] = i;
        }
        XCol= selected[0];
        YCol = selected[1];
        GrpCol = selected[2];
        NoSelected = 3;

        // check to see if strcol is a string variable
        cellstring = DictionaryForm->DGrid->Cells[3][GrpCol];
        if (cellstring == "2") // recode into an integer code
        {
                results = StringsToInt(GrpCol, tempcol, true);
                GrpCol = NoVariables;
                selected[2] = GrpCol;
        }
/*
        // check type of variables
        result = VarTypeChk(XCol,0);
        if (result == 1)
        {
                delete[] selected;
                return;
        }
        result = VarTypeChk(YCol,0);
        if (result == 1)
        {
                delete[] selected;
                return;
        }
        result = VarTypeChk(GrpCol,1);
        if (result == 1)
        {
                delete[] selected;
                return;
        }
*/
        // Get number of groups
        for (int i = 1; i <= NoCases; i++)
        {
                Grp = floor(StrToFloat(MainForm->Grid->Cells[GrpCol][i]));
                //result = GetValue(i,GrpCol,intvalue,dblvalue,strvalue);
                //if (result == 1) Grp = 0;
                //else Grp = intvalue;
                if (Grp > MaxGrp) MaxGrp = Grp;
                if (Grp < MinGrp) MinGrp = Grp;
        }
        NoGrps = (MaxGrp - MinGrp) + 1;

        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("X VERSUS Y FOR GROUPS PLOT");
        FrmOutPut->RichOutPut->Lines->Add("");
        GetDblMatMem(YValues,NoCases+1,NoGrps+1);
        GetDblMatMem(XValues,NoCases+1,NoGrps+1);
        GetDblVecMem(Means,2);
        GetDblVecMem(StdDevs,2);
        GetIntVecMem(NoInGrp,NoGrps);

        for (i = 0; i < 2; i++)
        {
                Means[i] = 0.0;
                StdDevs[i] = 0.0;
        }
        for (i = 0; i < NoGrps; i++) NoInGrp[i] = 0;

        for (i = 1; i <= NoCases; i++)
        {
                if (!ValidRecord(i,selected,NoSelected)) continue;
                N = N + 1;
                X = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                //result = GetValue(i,XCol,intvalue,dblvalue,strvalue);
                //if (result == 1) X = 0.0;
                //else X = dblvalue;
                if (X > MaxX) MaxX = X;
                if (X < MinX) MinX = X;
                Y = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                //result = GetValue(i,YCol,intvalue,dblvalue,strvalue);
                //if (result == 1) Y = 0.0;
                //else Y = dblvalue;
                if (Y > MaxY) MaxY = Y;
                if (Y < MinY) MinY = Y;
        }

        for (i = 1; i <= NoCases; i++)
        {
                if (!ValidRecord(i,selected,NoSelected)) continue;
                Y = StrToFloat(MainForm->Grid->Cells[YCol][i]);
//                if (Y > MaxY) MaxY = Y;
//                if (Y < MinY) MinY = Y;
                Grp = floor(StrToFloat(MainForm->Grid->Cells[GrpCol][i]));
                Grp = Grp - MinGrp;
                NoInGrp[Grp] += 1;
                if (NoInGrp[Grp] > MaxGrpSize) MaxGrpSize = NoInGrp[Grp];
                YValues[NoInGrp[Grp]-1][Grp] = Y;
                XValues[NoInGrp[Grp]-1][Grp] = StrToFloat(MainForm->Grid->Cells[XCol][i]);
        }

        // get descriptive data
        if (DescChk->Checked)
        {
                for (i = 1; i <= NoCases; i++)
                {
                        if (!ValidRecord(i,selected,NoSelected)) continue;
                        Y = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                        X = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                        Means[0] += X;
                        StdDevs[0] += (X * X);
                        Means[1] +=  Y;
                        StdDevs[1] += (Y * Y);
                }
                for (i = 0; i < 2; i++)
                {
                        StdDevs[i] = StdDevs[i] - (Means[i] * Means[i]) / N;
                        StdDevs[i] = StdDevs[i] / (N - 1);
                        StdDevs[i] = sqrt(StdDevs[i]);
                        Means[i] = Means[i] / N;
                }
                FrmOutPut->RichOutPut->Lines->Add("VARIABLE  MEAN    STANDARED DEVIATION");
                sprintf(prtline,"   X      %9.3f %8.3f",Means[0],StdDevs[0]);
                FrmOutPut->RichOutPut->Lines->Add(prtline);
                sprintf(prtline,"   Y      %9.3f %8.3f",Means[1],StdDevs[1]);
                FrmOutPut->RichOutPut->Lines->Add(prtline);
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->ShowModal();
        }

        // sort on X
        for (i = 0; i < NoGrps; i++)
        {
                for (j = 0; j < MaxGrpSize-1; j++)
                {
                        for (int k = j+1; k < MaxGrpSize; k++)
                        {
                                if (XValues[j][i] > XValues[k][i]) // swap
                                {
                                        temp = XValues[j][i];
                                        XValues[j][i] = XValues[k][i];
                                        XValues[k][i] = temp;
                                        temp = YValues[j][i];
                                        YValues[j][i] = YValues[k][i];
                                        YValues[k][i] = temp;
                                }
                        }
                }
        }

        plotxy(XValues, YValues, MaxX, MinX, MaxY, MinY, MaxGrpSize, NoGrps, MinGrp);
        PlotForm->ShowModal();

        ClearIntVecMem(NoInGrp);
        ClearDblVecMem(StdDevs);
        ClearDblVecMem(Means);
        ClearDblMatMem(XValues,NoCases+1);
        ClearDblMatMem(YValues,NoCases+1);
     if (results == false) DeleteaCol(NoVariables);
}
//---------------------------------------------------------------------------

void __fastcall TMultGrpXYPlot::plotxy(double **XValues, double **YValues,
                double MaxX, double MinX, double MaxY, double MinY, int N,
                int NoY, int MinGrp)
{
     // routine to plot X versus multiple Y values
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];
     TColor Colors[12];

     Colors[1] = clRed;
     Colors[2] = clBlue;
     Colors[3] = clGreen;
     Colors[4] = clNavy;
     Colors[5] = clTeal;
     Colors[6] = clAqua;
     Colors[7] = clLime;
     Colors[8] = clFuchsia;
     Colors[9] = clGray;
     Colors[10] = clPurple;
     Colors[11] = clOlive;
     Colors[0] = clMaroon;
     Title = PlotTitleEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (MaxX - MinX) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = MinX + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - MinX) / (MaxX - MinX)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit->Text) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XEdit->Text);

     // Draw vertical axis
     Title = "Y VALUES";
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (MaxY - MinY) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = MaxY - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = MaxY - (valincr * (i-1));
          ypos = ceil(vhi * ( (MaxY - Yvalue) / (MaxY - MinY)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs

     for (int j = 0; j < NoY; j++)
     {
        PlotForm->Image1->Canvas->Brush->Style = bsSolid;
        PlotForm->Image1->Canvas->Brush->Color = Colors[j % 12];
        PlotForm->Image1->Canvas->Pen->Color = Colors[j % 12];
        int Grp = MinGrp + j;
        Title = "GROUP " + IntToStr(Grp);
        for (int i = 1; i <= N; i++)
        {
                ypos = ceil(vhi * ( (MaxY - YValues[i-1][j]) / (MaxY - MinY)));
                ypos = ypos + vtop;
                xpos = ceil(hwide * ( (XValues[i-1][j] - MinX) / (MaxX - MinX)));
                xpos = xpos + hleft;
                if (i == 1) PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
                if (LinesBox->Checked) PlotForm->Image1->Canvas->LineTo(xpos,ypos);
                PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
        }
        strhi = PlotForm->Image1->Canvas->TextHeight(Title);
        PlotForm->Image1->Canvas->Brush->Color = clWhite;
        xpos = hwide + hleft;
        PlotForm->Image1->Canvas->MoveTo(xpos,ypos-strhi);
        PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
}
