//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "BankUpdate.h"
#include "ItemStem.h"
#include "ItemFoil.h"
//#include "ItemBank.h"
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBankUpdateFrm *BankUpdateFrm;
//---------------------------------------------------------------------------
__fastcall TBankUpdateFrm::TBankUpdateFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBankUpdateFrm::CancelBtnClick(TObject *Sender)
{
    if (fileopen)
    {
        fclose(bankfileptr);
        fclose(hdrfileptr);
        fclose(minorptr);
        fclose(majorptr);
    }
    BankUpdateFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TBankUpdateFrm::ExitBtnClick(TObject *Sender)
{
    if (itemsaved == false)
    {
        AnsiString InputString = InputBox("ITEM NOT SAVED!",
            "Save last item (Y or N)?", "Y");
        if ((InputString == "Y") || (InputString == "y"))
            SaveItemBtnClick(this);
    }
    if (fileopen)
    {
        // save and close the index (header) file
        hdrptr = &bankhdr;
        fseek(hdrfileptr,0,0);
        fwrite(hdrptr,sizeof(header),1,hdrfileptr);
        fclose(hdrfileptr);
        // close the item file
        fclose(bankfileptr);
        // save the combo box entries and close their files
        fclose(majorptr);
        strcpy(majorfile,bankhdr.majorfile);
        if ((majorptr = fopen(majorfile,"wt")) != NULL)
        {
            for (int i = 0; i < MajorCombo->Items->Count; i++)
            {
                fputs(MajorCombo->Items->Strings[i].c_str(),majorptr);
                fputc('\n',majorptr);
            }
        }
        fclose(majorptr);
        fclose(minorptr);
        strcpy(minorfile,bankhdr.minorfile);
        if ((minorptr = fopen(minorfile,"wt")) != NULL)
        {
            for (int i = 0; i < MinorCombo->Items->Count; i++)
            {
                fputs(MinorCombo->Items->Strings[i].c_str(),minorptr);
                fputc('\n',minorptr);
            }
        }
        fclose(minorptr);
        fileopen = false;
    }
    BankUpdateFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TBankUpdateFrm::FormShow(TObject *Sender)
{
    BankEdit->Text = "";
    ItemFileEdit->Text = "";
    BMPFileEdit->Text = "";
    ChanceEdit->Text = "";
    CorrectEdit->Text = "";
    DiffEdit->Text = "";
    FoilEdit->Clear();
    ItemNoEdit->Text = "";
    ItemTypeEdit->Text = "";
    MajCodeEdit->Text = "";
    MeanEdit->Text = "";
    MinCodeEdit->Text = "";
    NewNoEdit->Text = "";
    NoFoilsEdit->Text = "";
    NoInEdit->Text = "";
    ParmTypeEdit->Text = "";
    SlopeEdit->Text = "";
    FoilNoEdit->Text = "1";
    StemREdit->Clear();
    UpDown1->Position = 1;
    ItemScroll->Position = 1;
    fileopen = false;
    itemsaved = false;
    hdrfileptr = NULL;    // for the item bank header (index) file
    bankfileptr = NULL;   // for the items in the item bank
    majorptr = NULL;      // for the major codes of the user for item types
    minorptr = NULL;      // for the file of minor codes of the user
    MaxItemNo = 0;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::OpenNewBtnClick(TObject *Sender)
{
    if (fileopen)
    {
        ShowMessage("A file is open.  Save and close it first.");
        return;
    }
    opennewbank(this);

}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::OpenOldBtnClick(TObject *Sender)
{
    openoldbank(this);
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::ReviseBtnClick(TObject *Sender)
{
    NewNoEdit->Text = ItemNoEdit->Text;
    //get item and load right panel
    int item = atoi(ItemNoEdit->Text.c_str());
    getitem(item);
    reviseitem = true;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MajorComboKeyPress(TObject *Sender,
      char &Key)
{
    AnsiString response;

    if (Key == 13) // new text entered
    {
        response = InputBox("ADD ITEM?","Should I add this to the list?","NO");
        if (response != "NO")
        {
            MajorCombo->Items->Add(MajorCombo->Text);
            fixeditem.majorcode = MajorCombo->Items->Count - 1;
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MajorComboClick(TObject *Sender)
{
    fixeditem.majorcode = MajorCombo->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MinorComboKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) // new text entered
    {
        MinorCombo->Items->Add(MinorCombo->Text);
        fixeditem.minorcode = MinorCombo->Items->Count - 1;
    }
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MinorComboClick(TObject *Sender)
{
    fixeditem.minorcode = MinorCombo->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::RadioGroup1Click(TObject *Sender)
{
    fixeditem.itemtype = RadioGroup1->ItemIndex;
    if (fixeditem.itemtype == 1) Panel3->Visible = false;// TF
    else Panel3->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::RadioGroup2Click(TObject *Sender)
{
    fixeditem.difftype = RadioGroup2->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MeanEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) // return key pressed
    {
        fixeditem.mean = atof(MeanEdit->Text.c_str());
    }
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::DiffEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) fixeditem.difficulty = atof(DiffEdit->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::SlopeEditKeyPress(TObject *Sender,
      char &Key)
{
    if(Key == 13) fixeditem.slope = atof(SlopeEdit->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::ChanceEditKeyPress(TObject *Sender,
      char &Key)
{
    if(Key == 13) fixeditem.chance = atof(ChanceEdit->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::BMPBrowseBtnClick(TObject *Sender)
{
    OpenPictureDialog1->Execute();
    BMPFileEdit->Text = OpenPictureDialog1->FileName;
    strcpy(fixeditem.BMPfile,BMPFileEdit->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::SaveItemBtnClick(TObject *Sender)
{
    long int whereat;
    int item;

    if (fileopen)
    {
        item = atoi(NewNoEdit->Text.c_str());
        whereat = (item-1) * sizeof(itemdesc); // where will it be written ?
        bankhdr.ItemStart[item-1] = whereat;// save position in index header
        if (item > MaxItemNo) MaxItemNo = item;
        bankhdr.NoItems = MaxItemNo;
        fixeditem.ItemNo = item;
        fixeditem.mean = atof(MeanEdit->Text.c_str());
        fixeditem.difficulty = atof(DiffEdit->Text.c_str());
        fixeditem.slope = atof(SlopeEdit->Text.c_str());
        fixeditem.chance = atof(ChanceEdit->Text.c_str());
        fixeditem.correctno = atoi(CorFoilEdit->Text.c_str());
        fixeditem.stemlines = stemlines;
        fixeditem.nofoils = nochoices;
        for (int i = 0; i < 10; i++) fixeditem.foillines[i] = foillines[i];
        strcpy(fixeditem.BMPfile,BMPFileEdit->Text.c_str());
        for (int i = 0; i < stemlines; i++) strcpy(fixeditem.Stem[i],Stem[i]);
        for (int i = 0; i < nochoices; i++)
            for (int j = 0; j < foillines[i]; j++)
                strcpy(fixeditem.Foil[i][j],Foil[i][j]);
        fseek(bankfileptr,whereat,0);
        descptr = &fixeditem;
        fwrite(descptr,sizeof(itemdesc),1,bankfileptr);
        itemsaved = true;
        reviseitem = false;
        NoInEdit->Text = MaxItemNo;
        ItemNoEdit->Text = fixeditem.ItemNo;
        ItemTypeEdit->Text = RadioGroup1->Items->Strings[fixeditem.itemtype];
        ParmTypeEdit->Text = RadioGroup2->Items->Strings[fixeditem.difftype];
        MajCodeEdit->Text = MajorCombo->Items->Strings[fixeditem.majorcode];
        MinCodeEdit->Text = MinorCombo->Items->Strings[fixeditem.minorcode];
        CorrectEdit->Text = fixeditem.correctno;
        NoFoilsEdit->Text = fixeditem.nofoils;
        ItemScroll->Max = MaxItemNo;
        UpDown1->Max = (short) nochoices;
        // load item stem in left panel
        StemEditFrm->StemMemo->Clear();
        for (int i = 0; i < fixeditem.stemlines; i++) // load stem
           StemEditFrm->StemMemo->Lines->Add(Stem[i]);
        ItemFoilFrm->Memo1->Clear();
        for (int j = 0; j < fixeditem.foillines[0]; j++) // load first foil
            ItemFoilFrm->Memo1->Lines->Add(Foil[0][j]);
        StemREdit->Text = "";
        for (int i = 0; i < stemlines; i++)
            StemREdit->Text = StemREdit->Text + Stem[i];
        // load firt foil in left panel
        FoilEdit->Text = "";
        for (int i = 0; i < foillines[0]; i++)
            FoilEdit->Text = FoilEdit->Text + Foil[0][i];

    }
    else
    {
        Application->MessageBox("Error in saving an item.","FILE ERROR!",MB_OK);
        return;
    }
}
//---------------------------------------------------------------------------

int __fastcall TBankUpdateFrm::opennewbank(TObject *Sender)
{
    AnsiString tempfile;

    OpenDialog1->Filter = "Item Bank (*.bnk)|*.BNK|All files (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
    if ((OpenDialog1->Execute()) == NULL) return (1);
    tempfile = ExtractFileName(OpenDialog1->FileName);
    strcpy(filename,tempfile.c_str());
    strcat(filename,".BNK");
//    strcpy(filename,OpenDialog1->FileName.c_str());
    if (!FileExists(filename)) // file does not exist - ok
    {
        hdrfileptr = fopen(filename,"wb");
        if (hdrfileptr == NULL)
        {
            Application->MessageBox("Could not open the new item bank index.",
                "FILE ERROR!",MB_OK);
            return(1);
        }
        fileopen = true;
        BankEdit->Text = filename;
        NoInEdit->Text = "0";
        ItemNoEdit->Text = "1";
        bankhdr.NoItems = 0;
        MaxItemNo = 0;
        for (int i = 0; i < 500; i++) bankhdr.ItemStart[i] = 0;
        strcpy(bankname,filename);
        strcat(bankname,".ITM");
        strcpy(bankhdr.bankname,bankname);
        strcpy(majorfile,filename);
        strcat(majorfile,".MAJ");
        if ((majorptr = fopen(majorfile,"wt")) == NULL)
        {
            Application->MessageBox("Could not open new major codes file.","FILE ERROR",MB_OK);
            fclose(hdrfileptr); // we can't leave the index file open
            return(1);
        }
        strcpy(bankhdr.majorfile,majorfile);  // save name in header file
        strcpy(minorfile,filename);
        strcat(minorfile,".MIN");
        if ((minorptr = fopen(minorfile,"wt")) == NULL)
        {
            Application->MessageBox("Could not open new minor codes file.","FILE ERROR",MB_OK);
            fclose(hdrfileptr); // close those already successfully opened
            fclose(majorptr);
            return(1);
        }
        strcpy(bankhdr.minorfile,minorfile); // save name in header file
        // Now open a file for the items
        if ((bankfileptr = fopen(bankname,"wb")) == NULL)
        {
            Application->MessageBox("Could not open new minor codes file.","FILE ERROR",MB_OK);
            fclose(hdrfileptr); // close those already successfully opened
            fclose(majorptr);
            fclose(minorptr);
            return(1);
        }
        ItemFileEdit->Text = bankname;
    }
    else
    {
        Application->MessageBox("A file by this name already exists!","FILE MESSAGE",MB_OK);
        return(1);
    }
    return(0);
}
//------------------------------------------------------------------------

int __fastcall TBankUpdateFrm::openoldbank(TObject *Sender)
{
    char astring[81];
    AnsiString tempfile;

    OpenDialog1->Filter = "Item Bank (*.bnk)|*.BNK|All files (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
    if (OpenDialog1->Execute())
    {
        tempfile = ExtractFileName(OpenDialog1->FileName);
        strcpy(filename,tempfile.c_str());
    //   strcpy(filename,OpenDialog1->FileName.c_str());
    }
    else return (1);
    if (FileExists(filename)) // existing bank
    {
        hdrfileptr = fopen(filename,"r+b");
        if (hdrfileptr == NULL)
        {
            Application->MessageBox("Could not open old item bank index header.",
                "FILE ERROR!",MB_OK);
            return(1);
        }
        hdrptr = &bankhdr;
        fread(hdrptr,sizeof(header),1,hdrfileptr);
        NoInEdit->Text = bankhdr.NoItems;
        ItemScroll->Max = bankhdr.NoItems;
        MaxItemNo = bankhdr.NoItems;
        BankEdit->Text = filename;
        // open and load the major and minor code files
        strcpy(majorfile,bankhdr.majorfile);
        if ((majorptr = fopen(majorfile,"rt")) != NULL)
        {
            while (!feof(majorptr))
            {
                fgets(astring,81,majorptr);
                astring[strlen(astring)-1] = 0;
                if (feof(majorptr)) break;
                MajorCombo->Items->Add(astring);
            }
        }
        strcpy(minorfile,bankhdr.minorfile);
        if ((minorptr = fopen(minorfile,"rt")) != NULL)
        {
            while (!feof(minorptr))
            {
                fgets(astring,31,minorptr);
                astring[strlen(astring)-1] = 0;
                if (feof(minorptr)) break;
                MinorCombo->Items->Add(astring);
            }
        }
        strcpy(bankname,bankhdr.bankname);
        if ((bankfileptr = fopen(bankname,"r+b")) == NULL)
        {
            Application->MessageBox("Can't open items file.","FILE ERROR!",MB_OK);
            fclose(hdrfileptr);
            fclose(majorptr);
            fclose(minorptr);
            return 1;
        }
        ItemFileEdit->Text = bankname;
        fileopen = true;
        getitem(1); // read the first item information
        ItemNoEdit->Text = IntToStr(1);
    }
    else
    {
        Application->MessageBox("The file selected does not exist.","FILE MESSAGE",MB_OK);
        return(1);
    }
    return(0);
}
//-------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::AddNewBtnClick(TObject *Sender)
{
    if (!fileopen)
    {
        Application->MessageBox("First, open an item bank file.","ERROR!",MB_OK);
        return;
    }
    
    MaxItemNo++;
    NewNoEdit->Text = MaxItemNo;
    RadioGroup1->ItemIndex = 0;
    RadioGroup2->ItemIndex = 0;
    BMPFileEdit->Text = "";
    MajorCombo->Text = "";
    MinorCombo->Text = "";
    MeanEdit->Text = "";
    DiffEdit->Text = "";
    SlopeEdit->Text = "";
    ChanceEdit->Text = "";
    itemsaved = false;
    reviseitem = false;
    NoChoicesEdit->Text = "";
    CorFoilEdit->Text = "";
    StemEditFrm->StemMemo->Clear();
    ItemFoilFrm->Memo1->Clear();
    for (int i = 0; i < 10; i++)
    {
        foillines[i] = 0;
        for (int j = 0; j < 10; j++) strcpy(Foil[i][j],"");
    }
    for (int i = 0; i < 30; i++) strcpy(Stem[i],"");
    stemlines = 0;
    nochoices = 0;
    CorFoilEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::ItemTextBtnClick(TObject *Sender)
{
    StemEditFrm->ShowModal();
    stemlines = StemEditFrm->StemMemo->Lines->Count;
    for (int i = 0; i < stemlines; i++)
        strcpy(Stem[i],StemEditFrm->StemMemo->Lines->Strings[i].c_str());
    int itemtype = RadioGroup1->ItemIndex;
    switch (itemtype)
    {
        case 0: // multiple choice
        {
            nochoices = atoi(NoChoicesEdit->Text.c_str());
            for (int i = 0; i < nochoices; i++)
            {
                ItemFoilFrm->FoilNoEdit->Text = i+1;
                ItemFoilFrm->Memo1->Clear();
                if (reviseitem) // if revising load existing choices
                {
                    for (int j = 0; j < fixeditem.foillines[i]; j++) // load foil
                    ItemFoilFrm->Memo1->Lines->Add(Foil[i][j]);
                }
                ItemFoilFrm->ShowModal();
                foillines[i] = ItemFoilFrm->Memo1->Lines->Count;
                for (int j = 0; j < foillines[i]; j++)
                    strcpy(Foil[i][j],ItemFoilFrm->Memo1->Lines->Strings[j].c_str());
            }
            break;
        } // end case 0
        case 1: // true - false
        {
              AnsiString response = InputBox("TRUE OR FALSE",
                  "Is the statement true (Y or N)?","Y");
              Panel3->Visible = true;
              if ((response == "Y") || (response == "y")) CorFoilEdit->Text = 1;
              else CorFoilEdit->Text = 2;
              NoChoicesEdit->Text = 2;
              fixeditem.nofoils = 2;
              fixeditem.foillines[0] = 1;
              fixeditem.foillines[1] = 1;
              strcpy(fixeditem.Foil[0][0],"TRUE");
              strcpy(fixeditem.Foil[1][0],"FALSE");
              nochoices = 2;
              foillines[0] = 1;
              foillines[1] = 1;
              strcpy(Foil[0][0],"TRUE");
              strcpy(Foil[1][0],"FALSE");  
        }
        break;
        case 2: // single word
        { // Note: more than one word is acceptable.  Preferred is "correctno".
            nochoices = atoi(NoChoicesEdit->Text.c_str());
            for (int i = 0; i < nochoices; i++)
            {
                ItemFoilFrm->FoilNoEdit->Text = i+1;
                ItemFoilFrm->Memo1->Clear();
                if (reviseitem) // if revising load existing choices
                {
                    for (int j = 0; j < fixeditem.foillines[i]; j++) // load foil
                    ItemFoilFrm->Memo1->Lines->Add(Foil[i][j]);
                }
                ItemFoilFrm->ShowModal();
                foillines[i] = ItemFoilFrm->Memo1->Lines->Count;
                for (int j = 0; j < foillines[i]; j++)
                    strcpy(Foil[i][j],ItemFoilFrm->Memo1->Lines->Strings[j].c_str());
                CorFoilEdit->Text = 1;
            }
        }
        break;
        case 3: // phrase
        {  // only 1 choice.  Correction by % of matching words
            nochoices = 1;
            NoChoicesEdit->Text = 1;
            CorFoilEdit->Text = "";
            for (int i = 0; i < nochoices; i++)
            {
                ItemFoilFrm->FoilNoEdit->Text = i+1;
                ItemFoilFrm->Memo1->Clear();
                if (reviseitem) // if revising load existing choices
                {
                    for (int j = 0; j < fixeditem.foillines[i]; j++) // load foil
                    ItemFoilFrm->Memo1->Lines->Add(Foil[i][j]);
                }
                ItemFoilFrm->ShowModal();
                foillines[i] = ItemFoilFrm->Memo1->Lines->Count;
                for (int j = 0; j < foillines[i]; j++)
                    strcpy(Foil[i][j],ItemFoilFrm->Memo1->Lines->Strings[j].c_str());
                CorFoilEdit->Text = 1;
            }
        }
        break;
        case 4: // sentence completion
        {  // only 1 choice.  Correction by % of matching words
            nochoices = 1;
            NoChoicesEdit->Text = 1;
            CorFoilEdit->Text = "";
            for (int i = 0; i < nochoices; i++)
            {
                ItemFoilFrm->FoilNoEdit->Text = i+1;
                ItemFoilFrm->Memo1->Clear();
                if (reviseitem) // if revising load existing choices
                {
                    for (int j = 0; j < fixeditem.foillines[i]; j++) // load foil
                    ItemFoilFrm->Memo1->Lines->Add(Foil[i][j]);
                }
                ItemFoilFrm->ShowModal();
                foillines[i] = ItemFoilFrm->Memo1->Lines->Count;
                for (int j = 0; j < foillines[i]; j++)
                    strcpy(Foil[i][j],ItemFoilFrm->Memo1->Lines->Strings[j].c_str());
                CorFoilEdit->Text = 1;
            }
        }
        break;
        case 5: // essay.  Provide paper to make response
        { // No choices.  Graded by hand.
            nochoices = 0;
            NoChoicesEdit->Text = 0;
            CorFoilEdit->Text = "";
        }
        break;
        case 6: // sketch
        {  // graded by hand.  Provide paper to make a sketch.
            nochoices = 0;
            NoChoicesEdit->Text = 0;
            CorFoilEdit->Text = "";
        }
        break;
    } // end switch
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::getitem(int ino)
{
    long int whereat;

    if (fileopen)
    {
        whereat = (ino-1) * sizeof(itemdesc); // where ?
//        whereat = bankhdr.ItemStart[ino-1];
        fseek(bankfileptr,whereat,0);
        // get fixed values
        descptr = &fixeditem;
        fread(descptr,sizeof(itemdesc),1,bankfileptr);
        NewNoEdit->Text = fixeditem.ItemNo;
        ItemNoEdit->Text = fixeditem.ItemNo;
        ItemTypeEdit->Text = RadioGroup1->Items->Strings[fixeditem.itemtype];
        ParmTypeEdit->Text = RadioGroup2->Items->Strings[fixeditem.difftype];
        MajCodeEdit->Text = MajorCombo->Items->Strings[fixeditem.majorcode];
        MinCodeEdit->Text = MinorCombo->Items->Strings[fixeditem.minorcode];
        CorrectEdit->Text = fixeditem.correctno;
        NoFoilsEdit->Text = fixeditem.nofoils;
        MeanEdit->Text = fixeditem.mean;
        DiffEdit->Text = fixeditem.difficulty;
        SlopeEdit->Text = fixeditem.slope;
        ChanceEdit->Text = fixeditem.chance;
        NoChoicesEdit->Text = fixeditem.nofoils;
        CorFoilEdit->Text = fixeditem.correctno;
        UpDown1->Max = (short)fixeditem.nofoils;
        nochoices = fixeditem.nofoils;
        stemlines = fixeditem.stemlines;
        RadioGroup1->ItemIndex = fixeditem.itemtype;
        RadioGroup2->ItemIndex = fixeditem.difftype;
        for (int i = 0; i < fixeditem.stemlines; i++)
            strcpy(Stem[i],fixeditem.Stem[i]);
        for (int i = 0; i < fixeditem.nofoils; i++)
            foillines[i] = fixeditem.foillines[i];
        for (int i = 0; i < fixeditem.nofoils; i++)
            for (int j = 0; j < fixeditem.foillines[i]; j++)
                strcpy(Foil[i][j],fixeditem.Foil[i][j]);

        // load item stem in left panel
        StemEditFrm->StemMemo->Clear();
        for (int i = 0; i < fixeditem.stemlines; i++) // load stem
           StemEditFrm->StemMemo->Lines->Add(Stem[i]);
        ItemFoilFrm->Memo1->Clear();
        for (int j = 0; j < fixeditem.foillines[0]; j++) // load first foil
            ItemFoilFrm->Memo1->Lines->Add(Foil[0][j]);
        StemREdit->Text = "";
        for (int i = 0; i < stemlines; i++)
            StemREdit->Text = StemREdit->Text + Stem[i];
        // load firt foil in left panel
        FoilEdit->Text = "";
        for (int i = 0; i < foillines[0]; i++)
            FoilEdit->Text = FoilEdit->Text + Foil[0][i];
    }
    else
    {
        Application->MessageBox("Item file is not open.", "FILE ERROR!",MB_OK);
    }
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::ItemScrollChange(TObject *Sender)
{
    int pos = ItemScroll->Position;
    int item = atoi(ItemNoEdit->Text.c_str());
    if (pos == item) return;
    if (pos > MaxItemNo) return;
    // load the selected item
    getitem(pos);
    StemREdit->Text = "";
    for (int i = 0; i < stemlines; i++)
        StemREdit->Text = StemREdit->Text + Stem[i];
}
//---------------------------------------------------------------------------


void __fastcall TBankUpdateFrm::MajorComboDblClick(TObject *Sender)
{
       AnsiString response;

       response = InputBox("DELETE?","Delete? (Use single click to select.)","Y");
       if ((response == "Y") || (response == "y"))
           MajorCombo->Items->Delete(MajorCombo->ItemIndex);
}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::MinorComboDblClick(TObject *Sender)
{
       AnsiString response;

       response = InputBox("DELETE?","Delete? (Use single click to select.)","Y");
       if ((response == "Y") || (response == "y"))
           MinorCombo->Items->Delete(MinorCombo->ItemIndex);

}
//---------------------------------------------------------------------------

void __fastcall TBankUpdateFrm::DeleteBtnClick(TObject *Sender)
{
    // Copy all items but the deleted one to a temp file, then delete the
    // original and rename the new one to the old name.  Change the number
    // of items in the header file.
    int delitem;
    FILE *tempptr;
    long int whereat;
    int newitem = 0;

    delitem = atoi(ItemNoEdit->Text.c_str());
    if ((tempptr = fopen("temp.ITM","wb")) == NULL)
    {
        Application->MessageBox("Could not open temporary item file.","FILE ERROR",MB_OK);
        return;
    }
    for (int i = 0; i < MaxItemNo; i++)
    {
       if (i != delitem)
       {
           getitem(i);
           whereat = (newitem) * sizeof(itemdesc); // where will it be written ?
           bankhdr.ItemStart[newitem] = whereat;// save position in index header
           fseek(tempptr,whereat,0);
           descptr = &fixeditem;
           fwrite(descptr,sizeof(itemdesc),1,tempptr);
           newitem++;
       }
    }
    fclose(tempptr);
    fclose(bankfileptr);
    bankhdr.NoItems = MaxItemNo-1;
    fclose(hdrfileptr);
    // delete original bank
    DeleteFile(bankname);
    // rename the temp file
    RenameFile("temp.ITM",bankname);
    openoldbank(this);
}
//---------------------------------------------------------------------------


void __fastcall TBankUpdateFrm::UpDown1Change(TObject *Sender)
{
        int pos = UpDown1->Position;
        FoilNoEdit->Text = IntToStr(pos);
        // copy choice lines to foil edit box
        FoilNoEdit->Text = IntToStr(pos);
        FoilEdit->Text = "";
        for (int i = 0; i < foillines[pos-1]; i++)
            FoilEdit->Text = FoilEdit->Text + Foil[pos-1][i];
}
//---------------------------------------------------------------------------

