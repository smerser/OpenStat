//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "functions.h"
#include "HugeFileUnit.h"
#include "BFEqualVarUnit.h"
extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
extern bool ReadDiskFile;
extern FILE * datafile;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBFEqualVarTestForm *BFEqualVarTestForm;
//---------------------------------------------------------------------------
__fastcall TBFEqualVarTestForm::TBFEqualVarTestForm(TComponent* Owner)
        : TForm(Owner)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::ResetBtnClick(TObject *Sender)
{
        GroupVarEdit->Text = "";
        DepVarEdit->Text = "";
        GrpInBtn->Visible = true;
        GrpOutBtn->Visible = true;
        DepInBtn->Visible = true;
        DepOutBtn->Visible = true;
        Varlist->Clear();
        for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::GrpInBtnClick(TObject *Sender)
{
      int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              GroupVarEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     GrpInBtn->Visible = false;
     GrpOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::GrpOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(GroupVarEdit->Text);
     GroupVarEdit->Text = "";
     GrpInBtn->Visible = true;
     GrpOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::DepInBtnClick(TObject *Sender)
{
      int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              DepVarEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     DepInBtn->Visible = false;
     DepOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::DepOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::OKBtnClick(TObject *Sender)
{
        int noselected, grpvarcol, depvarcol;
        int *ColNoSelected;
        double *scores;
        double median;
        AnsiString cellstring;
        int i, N;
        AnsiString strvalue;
        char outline[121];

        noselected = 2;
        ColNoSelected = new int(noselected);
        scores = new double(NoCases);
        for (int i = 1; i <= NoVariables; i++)
        {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GroupVarEdit->Text) grpvarcol = i;
          if (cellstring == DepVarEdit->Text) depvarcol = i;
        }
        ColNoSelected[0] = grpvarcol;
        ColNoSelected[1] = depvarcol;
        // update definitions and grid
        NoVariables = NoVariables + 1;
        MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
        NewVar(NoVariables,false);
        cellstring = MainForm->Grid->Cells[depvarcol][0];
        strvalue = cellstring + "absdev";
        DictionaryForm->DGrid->Cells[1][NoVariables] = strvalue;
        MainForm->Grid->Cells[NoVariables][0] = strvalue;
        strvalue = MainForm->Grid->Cells[depvarcol][0];
        for (i = 1; i <= NoCases; i++) scores[i-1] = StrToFloat(MainForm->Grid->Cells[depvarcol][i]);
        median = scores[(NoCases / 2)-1];
        for (i = 1; i <= NoCases; i++)
        {
                scores[i-1] = fabs(scores[i-1] - median);
                sprintf(outline,"%8.5f",scores[i-1]);
                MainForm->Grid->Cells[NoVariables][i] = outline;
        }
        delete[] scores;
        delete[] ColNoSelected;
}
//---------------------------------------------------------------------------
void __fastcall TBFEqualVarTestForm::ReturnBtnClick(TObject *Sender)
{
        BFEqualVarTestForm->Hide();
}
//---------------------------------------------------------------------------

