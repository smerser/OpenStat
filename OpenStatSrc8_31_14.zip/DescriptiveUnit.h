//---------------------------------------------------------------------------

#ifndef DescriptiveUnitH
#define DescriptiveUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TDescriptiveForm : public TForm
{
__published:	// IDE-managed Components
   TMemo *Memo1;
   TLabel *Label1;
   TListBox *Varlist;
   TBitBtn *InBtn;
   TBitBtn *OutBtn;
   TBitBtn *AllBtn;
   TLabel *Label2;
   TListBox *ListBox1;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *OKBtn;
   TGroupBox *OptionsBox;
   TCheckBox *CaseDelChk;
   TCheckBox *zScoresChk;
        TLabel *Label3;
        TEdit *CIEdit;
        TCheckBox *PcntileChk;
        TCheckBox *QuartilesChk;
        TCheckBox *SizeSumChk;
        TCheckBox *MeanVarSDChk;
        TCheckBox *SDMeanChk;
        TCheckBox *CIChk;
        TCheckBox *RangeChk;
        TCheckBox *SkewChk;
        TCheckBox *KurtosisChk;
        TCheckBox *MedianChk;
        TCheckBox *GeoMeanChk;
        TCheckBox *HarmMeanChk;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall InBtnClick(TObject *Sender);
   void __fastcall OutBtnClick(TObject *Sender);
   void __fastcall AllBtnClick(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    double sum, variance, stddev, value, mean, min, max, range, skew;
    double kurtosis, z, semean, seskew, sekurtosis, deviation, devsqr, M2, M3, M4;
    int ncases, noselected;
    AnsiString cellstring, gridstring, outline;
    int *selected;
public:		// User declarations
   __fastcall TDescriptiveForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDescriptiveForm *DescriptiveForm;
//---------------------------------------------------------------------------
#endif
