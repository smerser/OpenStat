//---------------------------------------------------------------------------

#ifndef MatManUnitH
#define MatManUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TMatManForm : public TForm
{
__published:	// IDE-managed Components
     TMainMenu *MainMenu1;
     TMenuItem *Files1;
     TMenuItem *Operations1;
     TMenuItem *VectorOperations1;
     TMenuItem *ScalarOperations1;
     TMenuItem *Help1;
     TLabel *Label1;
     TEdit *GridNoEdit;
     TComboBox *MatrixCombo;
     TComboBox *ColCombo;
     TComboBox *RowCombo;
     TComboBox *ScalerCombo;
     TLabel *Label2;
     TListBox *ScriptList;
     TStringGrid *Grid1;
     TStringGrid *Grid3;
     TStringGrid *Grid2;
     TStringGrid *Grid4;
     TLabel *Label3;
     TLabel *Label4;
     TLabel *Label5;
     TLabel *Label6;
     TEdit *Obj1NameEdit;
     TEdit *Obj2NameEdit;
     TEdit *Obj3NameEdit;
     TEdit *Obj4NameEdit;
     TLabel *Label7;
     TEdit *OperationEdit;
     TEdit *Operand1Edit;
     TEdit *Operand2Edit;
     TEdit *Operand3Edit;
     TMenuItem *Transpose1;
     TMenuItem *SVDInverse1;
     TMenuItem *Eigens;
     TMenuItem *ColumnAugment1;
     TMenuItem *Tridiagonalize1;
     TMenuItem *MATxMAT;
     TMenuItem *Add1;
     TMenuItem *Subtract1;
     TMenuItem *mnuTrace;
     TMenuItem *Transpose2;
     TMenuItem *ScalerRecip;
     TMenuItem *ScalerProd;
     TMenuItem *ScriptOperations1;
     TMenuItem *Execute1;
     TMenuItem *Clear1;
     TMenuItem *Save2;
     TMenuItem *Load1;
     TButton *ExitBtn;
     TButton *CancelBtn;
     TMenuItem *mnuKeyIn;
     TMenuItem *KeyMat;
     TMenuItem *KeyVect;
     TMenuItem *KeyScalar;
     TMenuItem *N1;
     TMenuItem *mnuOpen;
     TMenuItem *mnuSave;
     TMenuItem *N2;
     TMenuItem *RowAugment1;
     TMenuItem *DiagonaltoVector1;
     TMenuItem *NormalizeRows1;
     TMenuItem *NormalizeColumns1;
     TMenuItem *MatPostMat;
     TMenuItem *RowVectorxMatrix1;
     TMenuItem *mnuMatxCol;
     TMenuItem *ScalarxMatrix1;
     TMenuItem *Determinant1;
     TMenuItem *Print1;
     TMenuItem *ScalarxVector1;
     TMenuItem *SquareRootofVector1;
     TMenuItem *PrintVector1;
     TMenuItem *VectRecips;
     TMenuItem *ScalerSqRt;
     TMenuItem *ScalarPrint;
     TMenuItem *Print3;
     TMenuItem *Edit1;
     TOpenDialog *OpenDialog1;
     TSaveDialog *SaveDialog1;
     TMenuItem *N3;
     TMenuItem *mnuDelRow;
     TMenuItem *mnuDelColumn;
     TMenuItem *Reset1;
     TMenuItem *RvecxCvec;
     TMenuItem *ColumnVectorxRowVector1;
     TMenuItem *UpLowDecomp;
     TMenuItem *ExtractVector;
     TMenuItem *InsertaRow1;
     TMenuItem *InsertaColumn1;
     TMenuItem *VectortoDiagonal1;
     TMenuItem *About1;
     TMenuItem *Contents1;
     TMenuItem *IDMatrix;
     TGroupBox *GroupBox1;
     TCheckBox *NoOpenChk;
     TCheckBox *NoSaveChk;
     TLabel *Label8;
     TLabel *Label9;
     TLabel *Label10;
     TButton *FormatBtn;
        TMenuItem *SVDUWVanalysis1;
        TMenuItem *GetMainData;
        TMenuItem *N4;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall mnuSaveClick(TObject *Sender);
     void __fastcall KeyMatClick(TObject *Sender);
     void __fastcall KeyVectClick(TObject *Sender);
     void __fastcall KeyScalarClick(TObject *Sender);
     void __fastcall mnuOpenClick(TObject *Sender);
     void __fastcall Grid1KeyPress(TObject *Sender, char &Key);
     void __fastcall Grid2KeyPress(TObject *Sender, char &Key);
     void __fastcall Grid3KeyPress(TObject *Sender, char &Key);
     void __fastcall Grid4KeyPress(TObject *Sender, char &Key);
     void __fastcall Save2Click(TObject *Sender);
     void __fastcall Load1Click(TObject *Sender);
     void __fastcall Execute1Click(TObject *Sender);
     void __fastcall RowAugment1Click(TObject *Sender);
     void __fastcall Grid1Click(TObject *Sender);
     void __fastcall Grid2Click(TObject *Sender);
     void __fastcall Grid3Click(TObject *Sender);
     void __fastcall Grid4Click(TObject *Sender);
     void __fastcall ColumnAugment1Click(TObject *Sender);
     void __fastcall mnuDelRowClick(TObject *Sender);
     void __fastcall mnuDelColumnClick(TObject *Sender);
     void __fastcall SVDInverse1Click(TObject *Sender);
     void __fastcall MATxMATClick(TObject *Sender);
     void __fastcall Reset1Click(TObject *Sender);
     void __fastcall MatrixComboClick(TObject *Sender);
     void __fastcall ColComboClick(TObject *Sender);
     void __fastcall RowComboClick(TObject *Sender);
     void __fastcall ScalerComboClick(TObject *Sender);
     void __fastcall Tridiagonalize1Click(TObject *Sender);
     void __fastcall UpLowDecompClick(TObject *Sender);
     void __fastcall Print1Click(TObject *Sender);
     void __fastcall DiagonaltoVector1Click(TObject *Sender);
     void __fastcall Determinant1Click(TObject *Sender);
     void __fastcall EigensClick(TObject *Sender);
     void __fastcall Transpose1Click(TObject *Sender);
     void __fastcall ScriptListClick(TObject *Sender);
     void __fastcall NormalizeColumns1Click(TObject *Sender);
     void __fastcall mnuTraceClick(TObject *Sender);
     void __fastcall RowVectorxMatrix1Click(TObject *Sender);
     void __fastcall ScalarxMatrix1Click(TObject *Sender);
     void __fastcall mnuMatxColClick(TObject *Sender);
     void __fastcall Add1Click(TObject *Sender);
     void __fastcall Subtract1Click(TObject *Sender);
     void __fastcall NormalizeRows1Click(TObject *Sender);
     void __fastcall Transpose2Click(TObject *Sender);
     void __fastcall ScalarxVector1Click(TObject *Sender);
     void __fastcall SquareRootofVector1Click(TObject *Sender);
     void __fastcall VectRecipsClick(TObject *Sender);
     void __fastcall RvecxCvecClick(TObject *Sender);
     void __fastcall ColumnVectorxRowVector1Click(TObject *Sender);
     void __fastcall ScalerSqRtClick(TObject *Sender);
     void __fastcall ScalerRecipClick(TObject *Sender);
     void __fastcall ScalerProdClick(TObject *Sender);
     void __fastcall Print3Click(TObject *Sender);
     void __fastcall Edit1Click(TObject *Sender);
     void __fastcall ExtractVectorClick(TObject *Sender);
     void __fastcall Grid1MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
     void __fastcall Grid2MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
     void __fastcall Grid3MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
     void __fastcall Grid4MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
     void __fastcall About1Click(TObject *Sender);
     void __fastcall Contents1Click(TObject *Sender);
     void __fastcall InsertaRow1Click(TObject *Sender);
     void __fastcall InsertaColumn1Click(TObject *Sender);
     void __fastcall VectortoDiagonal1Click(TObject *Sender);
     void __fastcall IDMatrixClick(TObject *Sender);
     void __fastcall Clear1Click(TObject *Sender);
     void __fastcall MatPostMatClick(TObject *Sender);
     void __fastcall FmtCells(TObject *Sender);
     void __fastcall FormatBtnClick(TObject *Sender);
    void __fastcall PrintVector1Click(TObject *Sender);
    void __fastcall ScalarPrintClick(TObject *Sender);
    void __fastcall Grid4DblClick(TObject *Sender);
    void __fastcall Grid3DblClick(TObject *Sender);
    void __fastcall Grid2DblClick(TObject *Sender);
    void __fastcall Grid1DblClick(TObject *Sender);
        void __fastcall SVDUWVanalysis1Click(TObject *Sender);
        void __fastcall GetMainDataClick(TObject *Sender);
     
private:	// User declarations
    int CurrentObjType;
    AnsiString CurrentObjName;
    int MatCount;
    int ColVecCount;
    int RowVecCount;
    int ScaCount;
    double **Matrix1;
    double **Matrix2;
    double **Matrix3;
    double **Matrix4;
    bool ScriptOp;
    int LastScript;
    int LastGridNo;
    int CurrentGrid;
    int Rows1, Rows2, Rows3, Rows4;
    int Cols1, Cols2, Cols3, Cols4;
    int Rows, Cols;
    bool Saved;
    int Opergrid;
    AnsiString Operation, Op1, Op2, Op3, OpStr;
    int Op1grid, Op2grid, Op3grid;
    AnsiString ScriptName;
    void __fastcall ResetGrids(TObject *Sender);
    void __fastcall GetFile(TObject *Sender);
    void __fastcall ComboAdd(AnsiString FileName);
    bool DuplicateMat(AnsiString str);
    bool DuplicateColVec(AnsiString str);
    bool DuplicateRowVec(AnsiString str);
    bool DuplicateScaler(AnsiString str);
    void __fastcall GetGridData(int gridno);
    int TMatManForm::OpParse(int &Opergrid, int &Op1grid, int &Op2grid,
                         int &Op3grid);
    void OperExec(void);
    
public:		// User declarations
     __fastcall TMatManForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMatManForm *MatManForm;
//---------------------------------------------------------------------------
#endif
