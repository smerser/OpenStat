//---------------------------------------------------------------------------

#ifndef DistCompareUnitH
#define DistCompareUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TDistCompareForm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *CumGroup;
    TGroupBox *ParmBox;
    TLabel *ParmLabel1;
    TLabel *ParmLabel2;
    TLabel *ParmLabel3;
    TLabel *ParmLabel4;
    TLabel *ParmLabel5;
    TLabel *ParmLabel6;
    TLabel *ParmLabel7;
    TEdit *ParmEdit1;
    TEdit *ParmEdit2;
    TEdit *ParmEdit3;
    TEdit *ParmEdit4;
    TEdit *ParmEdit5;
    TEdit *ParmEdit6;
    TEdit *ParmEdit7;
    TRadioGroup *ProbGroup;
    TButton *ExitBtn;
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TEdit *VarEdit;
    TMemo *Memo1;
    TCheckBox *PrintChk;
    TRadioGroup *TypeGroup;
    TButton *ComputeBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CumCompBtnClick(TObject *Sender);
    void __fastcall ProbCompBtnClick(TObject *Sender);
    void __fastcall CumGroupClick(TObject *Sender);
    void __fastcall ProbGroupClick(TObject *Sender);
    void __fastcall VarListClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall TypeGroupClick(TObject *Sender);

private:	// User declarations
     int ImageHi;
     int ImageWide;
     int Xstart;
     int Xend;
     int Ystart;
     int Yend;
     int Which;
     int Status;
     int selected;
     int col, nints, plottype;
     double value, min, max, range, incrsize, nointervals, mean, stddev;
     double P;
     double Q;
     double X;
     double Y;
     double A;
     double B;
     double Bound;
     double *freq;
     double *pcnt;
     double *cumpcnt;
     double *pcntrank;
     double *cumfreq;
     double *XValue;
     double *sampprob;
     double *theoretic;
     double *observed;
     double Xplot[101];
     double Yplot[101];
     void PlotXY(double *Xplot, double *Yplot, AnsiString Xlabel,
                 AnsiString Ylabel, AnsiString Caption, bool continuous);

public:		// User declarations
    __fastcall TDistCompareForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDistCompareForm *DistCompareForm;
//---------------------------------------------------------------------------
#endif
