//---------------------------------------------------------------------------
#ifndef SimCorUnitH
#define SimCorUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSimCorFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TLabel *Label1;
    TEdit *XmeanEdit;
    TLabel *Label2;
    TEdit *YmeanEdit;
    TLabel *Label3;
    TEdit *SDXEdit;
    TLabel *Label4;
    TEdit *SDYEdit;
    TLabel *Label5;
    TEdit *CorrEdit;
    TLabel *Label6;
    TEdit *NoObsEdit;
    TButton *CancelBtn;
    TButton *DoneBtn;
    TButton *ReturnBtn;
    void __fastcall XmeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall YmeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall SDXEditKeyPress(TObject *Sender, char &Key);
    void __fastcall SDYEditKeyPress(TObject *Sender, char &Key);
    void __fastcall CorrEditKeyPress(TObject *Sender, char &Key);
    void __fastcall NoObsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall DoneBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
    double meanx;
    double meany;
    double corr;
    double sdx;
    double sdy;
    double *x;
    double *y;
    double newb;
    double newconstant;
    double newmeanx;
    double newmeany;
    double newsdx;
    double newsdy;
    double newcorr;
    int N;
    int *freqx;
    int *freqy;
    void __fastcall plot(void);
public:		// User declarations
    __fastcall TSimCorFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSimCorFrm *SimCorFrm;
//---------------------------------------------------------------------------
#endif
