//---------------------------------------------------------------------------

#ifndef FreqDistUnitH
#define FreqDistUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFreqDistFrm : public TForm
{
__published:	// IDE-managed Components
   TListBox *Varlist;
   TListBox *ListBox1;
   TLabel *Label1;
   TLabel *Label2;
   TBitBtn *InBtn;
   TBitBtn *OutBtn;
   TBitBtn *AllBtn;
   TRadioGroup *PlotGrp;
   TRadioGroup *BarTypeGrp;
   TGroupBox *NDGrp;
   TCheckBox *NormDistChk;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *OKBtn;
        TGroupBox *GroupBox1;
        TCheckBox *GrpCodeChk;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall CancelBtnClick(TObject *Sender);
   void __fastcall InBtnClick(TObject *Sender);
   void __fastcall OutBtnClick(TObject *Sender);
   void __fastcall AllBtnClick(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TFreqDistFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFreqDistFrm *FreqDistFrm;
//---------------------------------------------------------------------------
#endif
