//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "PlotUnit.h"
#include "CorrespondenceUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCorrespondenceForm *CorrespondenceForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TCorrespondenceForm::TCorrespondenceForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TCorrespondenceForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TCorrespondenceForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Clear();
     ColList->Clear();
     RowEdit->Text = "";
     RowIn->Visible = true;
     RowOut->Visible = false;
     ColIn->Visible = true;
     ColOut->Visible = false;
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------

void __fastcall TCorrespondenceForm::RowInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     RowEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RowIn->Visible = false;
     RowOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TCorrespondenceForm::RowOutClick(TObject *Sender)
{
     VarList->Items->Add(RowEdit->Text);
     RowEdit->Text = "";
     RowIn->Visible = true;
     RowOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCorrespondenceForm::ColInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            ColList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     ColOut->Visible = true;

}
//---------------------------------------------------------------------------
void __fastcall TCorrespondenceForm::ColOutClick(TObject *Sender)
{
     int index;

     index = ColList->ItemIndex;
     if (index < 0)
     {
          ColOut->Visible = false;
          return;
     }
     VarList->Items->Add(ColList->Items->Strings[index]);
     ColList->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TCorrespondenceForm::ComputeBtnClick(TObject *Sender)
{
     int i, j, RowNo, ColNo, DepNo;
     int Row, Col, NoSelected, Ncases, Nrows, Ncols, FObs, df;
     AnsiString *RowLabels, *ColLabels;
     int *ColNoSelected;
     AnsiString cellstring;
     char outline[101];
     int **Freq;
     double **Prop, **Expected, **CellChi;
     double PObs, ChiSquare, ProbChi;
     bool yates;
     AnsiString title;
     AnsiString filename;
     double Adjchisqr, Adjprobchi, G;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     GetIntVecMem(ColNoSelected,NoVariables+1);
     yates = false;
     RowNo = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == RowEdit->Text) RowNo = i;
     }
     Nrows = NoCases;
     Ncols = ColList->Items->Count;
     RowLabels = new AnsiString[Nrows+1];
     ColLabels = new AnsiString[Ncols+1];

     if (RowNo == 0)
     {
        ShowMessage("ERROR! A variable for the row labels was not entered.");
        delete[] ColNoSelected;
        delete[] RowLabels;
        delete[] ColLabels;
        return;
     }
     ColNoSelected[0] = RowNo;

     // Get Column labels
     for (i = 0; i < Ncols; i++)
     {
        ColLabels[i] = ColList->Items->Strings[i];
        for (j = 1; j <= NoVariables; j++)
        {
                cellstring = MainForm->Grid->Cells[j][0];
                if (cellstring == ColLabels[i]) ColNoSelected[i+1] = j;
        }
/*
        result = VarTypeChk(ColNoSelected[i+1],1);
        if (result == 1)
        {
                delete[] ColNoSelected;
                delete[] RowLabels;
                delete[] ColLabels;
                return;
        }
*/
     }
     // Get row labels
     for (i = 1; i <= NoCases; i++)
     {
        RowLabels[i-1] = MainForm->Grid->Cells[RowNo][i];
     }

     // allocate and initialize
     GetIntMatMem(Freq,Nrows+1,Ncols+1);
     GetDblMatMem(Prop,Nrows+1,Ncols+1);
     GetDblMatMem(Expected,Nrows,Ncols);
     GetDblMatMem(CellChi,Nrows,Ncols);
     for (i = 1; i <= Nrows + 1; i++)
         for (j = 1; j <= Ncols + 1; j++) Freq[i-1][j-1] = 0;
    RowLabels[Nrows] = "Total";
    ColLabels[Ncols] = "Total";

     // get cell data
     Ncases = 0;
     for (i = 1; i <= NoCases; i++)
     {
        Row = i;
        for (j = 1; j <= Ncols; j++)
        {
                   Col = ColNoSelected[j];
                   Freq[i-1][j-1] = floor(StrToFloat(MainForm->Grid->Cells[Col][Row]));
                   //result = GetValue(Row,Col,intvalue,dblvalue,strvalue);
                   //if (result == 1) Freq[i-1][j-1] = 0;
                   //else Freq[i-1][j-1] = intvalue;
                   Ncases = Ncases + Freq[i-1][j-1];
        }
     }
     Freq[Nrows][Ncols] = Ncases;

     // Now, calculate expected values
     // Get row totals first
     for (i = 1; i <= Nrows; i++)
     {
          for (j = 1; j <= Ncols; j++)
          {
               Freq[i-1][Ncols] = Freq[i-1][Ncols] + Freq[i-1][j-1];
          }
     }
     // Get col totals next
     for (j = 1; j <= Ncols; j++)
     {
         for (i = 1; i <= Nrows; i++)
         {
             Freq[Nrows][j-1] = Freq[Nrows][j-1] + Freq[i-1][j-1];
         }
     }

     // Then get expected values and cell chi-squares
     ChiSquare = 0.0;
     Adjchisqr = 0.0;
     if ((YatesChk->Checked) && (Nrows == 2) && (Ncols == 2)) yates = true;
     if ((Nrows > 1) && (Ncols > 1))
     {
        for (i = 1; i <= Nrows; i++)
        {
          for (j = 1; j <= Ncols; j++)
          {
               Expected[i-1][j-1] = (double) Freq[Nrows][j-1] * (double) Freq[i-1][Ncols] / (double)Ncases;
               if (Expected[i-1][j-1] > 0.0)
                  CellChi[i-1][j-1] = sqr((double)Freq[i-1][j-1] - Expected[i-1][j-1])
                                    / Expected[i-1][j-1];
               else
               {
                    ShowMessage("ERROR! Zero expected value found.");
                    CellChi[i-1][j-1] = 0.0;
               }
               ChiSquare = ChiSquare + CellChi[i-1][j-1];
          }
        }
        df = (Nrows - 1) * (Ncols - 1);
        if (yates == true)  // 2 x 2 corrected chi-square
        {
          Adjchisqr = fabs((Freq[0][0] * Freq[1][1]) - (Freq[0][1] * Freq[1][0]));
          Adjchisqr = sqr(Adjchisqr - Ncases / 2.0) * Ncases; // numerator
          Adjchisqr = Adjchisqr / (Freq[0][2] * Freq[1][2] * Freq[2][0] * Freq[2][1]);
          Adjprobchi = 1.0 - chisquaredprob(Adjchisqr,df);
        }
     }
     if (Nrows == 1) // equal probability
     {
        for (j = 0; j < Ncols; j++)
        {
                Expected[0][j] = (double) Ncases / (double) Ncols;
                if (Expected[0][j] > 0)
                   CellChi[0][j] = sqr((double)Freq[0][j] - Expected[0][j]) / Expected[0][j];
                ChiSquare += CellChi[0][j];
        }
        df = Ncols - 1;
     }

     if (Ncols == 1) // equal probability
     {
        for (i = 0; i < Nrows; i++)
        {
                Expected[i][0] = (double) Ncases / (double) Nrows;
                if (Expected[i][0] > 0)
                   CellChi[i][0] = sqr((double)Freq[i][0] - Expected[i][0]) / Expected[i][0];
                ChiSquare += CellChi[i][0];
        }
        df = Nrows - 1;
     }

     ProbChi = 1.0 - chisquaredprob(ChiSquare,df); // prob. larger chi

    // Print acknowledgements
    FrmOutPut->RichOutPut->Lines->Add("CORRESPONDENCE ANALYSIS");
    FrmOutPut->RichOutPut->Lines->Add("Based on formulations of Bee-Leng Lee");
    FrmOutPut->RichOutPut->Lines->Add("Chapter 11 Correspondence Analysis for ViSta");
    FrmOutPut->RichOutPut->Lines->Add("Results are based on the Generalized Singular Value Decomposition");
    FrmOutPut->RichOutPut->Lines->Add("of P = A x D x B' where P is the relative frequencies observed,");
    FrmOutPut->RichOutPut->Lines->Add("A are the left generalized singular vectors,");
    FrmOutPut->RichOutPut->Lines->Add("D is a diagonal matrix of generalized singular values, and");
    FrmOutPut->RichOutPut->Lines->Add("B' is the transpose of the right generalized singular vectors.");
    FrmOutPut->RichOutPut->Lines->Add("NOTE: The first value and corresponding vectors are 1 and are");
    FrmOutPut->RichOutPut->Lines->Add("to be ignored.");
    FrmOutPut->RichOutPut->Lines->Add("An intermediate step is the regular SVD of the matrix Q = UDV'");
    FrmOutPut->RichOutPut->Lines->Add("where Q = Dr^-1/2 x P x Dc^-1/2 where Dr is a diagonal matrix");
    FrmOutPut->RichOutPut->Lines->Add("of total row relative frequencies and Dc is a diagonal matrix");
    FrmOutPut->RichOutPut->Lines->Add("of total column relative frequencies.");
    FrmOutPut->ShowModal();
    
    //Print results to output form
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Chi-square Analysis Results");
    sprintf(outline,"No. of Cases = %d",Ncases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    // print tables requested by use
    if (ObsChk->Checked)
    {
       IntArrayPrint(Freq, Nrows+1, Ncols+1,"Frequencies",
                     RowLabels, ColLabels,"OBSERVED FREQUENCIES");
       FrmOutPut->ShowModal();
    }

    if (ExpChk->Checked)
    {
         strcpy(outline,"EXPECTED FREQUENCIES");
         ArrayPrint(Expected, Nrows, Ncols, "Expected Values", RowLabels, ColLabels,
                    outline);
         FrmOutPut->ShowModal();
    }

    strcpy(outline,"ROW PROPORTIONS");
    for (i = 1; i <= Nrows + 1; i++)
    {
              for (j = 1; j <= Ncols; j++)
              {
                   if (Freq[i-1][Ncols] > 0.0)
                        Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[i-1][Ncols];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[i-1][Ncols] > 0.0)  Prop[i-1][Ncols] = 1.0;
              else Prop[i-1][Ncols] = 0.0;
    }
    if (PropsChk->Checked)
    {
        ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
        FrmOutPut->ShowModal();
    }

    strcpy(outline,"COLUMN PROPORTIONS");
    for (j = 1; j <= Ncols + 1; j++)
    {
              for (i = 1; i <= Nrows; i++)
              {
                   if (Freq[Nrows][j-1] > 0.0)
                       Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[Nrows][j-1];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[Nrows][j-1] > 0.0)  Prop[Nrows][j-1] = 1.0;
              else Prop[Nrows][j-1] = 0.0;
    }
    if (PropsChk->Checked)
    {
        ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
        FrmOutPut->ShowModal();
    }

    strcpy(outline,"PROPORTIONS OF TOTAL N");
    for (i = 1; i <= Nrows + 1; i++)
              for (j = 1; j <= Ncols + 1; j++) Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double) Ncases;
    Prop[Nrows][Ncols] = 1.0;
    ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
    FrmOutPut->ShowModal();

    if (ChiChk->Checked)
    {
         strcpy(outline,"CHI-SQUARED VALUE FOR CELLS");
         ArrayPrint(CellChi, Nrows, Ncols, "Chi-square Values", RowLabels, ColLabels,
                    outline);
         FrmOutPut->ShowModal();
    }

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Chi-square = %8.3f with D.F. = %d. Prob. > value = %8.3f",
                    ChiSquare,df,ProbChi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    if (yates == true)
    {
         sprintf(outline,"Chi-square using Yates correction = %8.3f and Prob > value = %8.3f",
                 Adjchisqr,Adjprobchi);
         FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    double liklihood = 0.0;
    for (int i = 0; i < Nrows; i++)
        for (int j = 0; j < Ncols; j++)
             if (Freq[i][j] > 0.0) liklihood += (double)Freq[i][j] * (log(Expected[i][j] / (double)Freq[i][j]));
    liklihood = -2.0 * liklihood;
    double probliklihood = 1.0 - chisquaredprob(liklihood,df);
    sprintf(outline,"Liklihood Ratio = %8.3f with prob. > value = %6.4f",
            liklihood,probliklihood);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    if ((Nrows > 1) && (Ncols > 1))
    {
        double phi = sqrt(ChiSquare / (double) Ncases);
        sprintf(outline,"phi correlation = %6.4f",phi);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double pearsonr = 0.0;
        double SumX = 0.0;
        double SumY = 0.0;
        double VarX = 0.0;
        double VarY = 0.0;
        for (int i = 0; i < Nrows; i++) SumX += ( (double)(i+1) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) SumY += ( (double)(j+1) * (double) Freq[Nrows][j] );
        for (int i = 0; i < Nrows; i++) VarX += ( (double)((i+1)*(i+1)) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) VarY += ( (double)((j+1)*(j+1)) * (double) Freq[Nrows][j] );
        VarX = VarX - ((SumX * SumX) / (double) Ncases);
        VarY = VarY - ((SumY * SumY) / (double) Ncases);
        for (int i = 0; i < Nrows; i++)
                for (int j = 0; j < Ncols; j++)
                        pearsonr += (double) ((i+1)*(j+1) * Freq[i][j]);
        pearsonr = pearsonr - (SumX * SumY / (double) Ncases);
        pearsonr = pearsonr / sqrt(VarX * VarY);
        sprintf(outline,"Pearson Correlation r = %6.4f",pearsonr);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double MantelHaenszel = (double) (Ncases-1) * (pearsonr * pearsonr);
        double MHprob = 1.0 - chisquaredprob(MantelHaenszel,1);
        sprintf(outline,"Mantel-Haenszel Test of Linear Association = %8.3f with probability > value = %6.4f",
            MantelHaenszel, MHprob);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CoefCont = sqrt(ChiSquare / (ChiSquare + (double) Ncases));
        sprintf(outline,"The coefficient of contingency = %8.3f",CoefCont);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CramerV;
        if (Nrows < Ncols) CramerV = sqrt(ChiSquare / (Ncases * ((double) (Nrows-1))));
        else CramerV = sqrt(ChiSquare / (Ncases * ((double) (Ncols-1))));
        sprintf(outline,"Cramer's V = %8.3f",CramerV);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();

    double **Trans; // transpose work matrix
    double **P; // relative frequencies (n by q correspondence matrix)
    double *r; // row vector of proportions
    double *c; // column vector of proportions
    double **Dr; // Diagonal matrix of row proportions
    double **Dc; // Diagonal matric of column proportions
    double **A; // n by q matrix whose columns are theleft generalized SVD vectors
    double **Du; // q by q diagonal matrix of singular values
    double **B; // m by q matrix whose columns are the right generalized SVD vectors
    double **Q; // matrix to be decomposed by SVD into U x Da x V'
    double **U; // left column vectors of SVD of Q
    double **V; // right vectors of SVD of Q
    double **W; // work matrix for transposing a matrix
    double **F; // Row Coordinates
    double **Gc; // Column Coordinates
    int n, q, m; // number of rows and columns of the P matrix
    int largest;
    bool errorcode;

    double *X, *Y, Xmax, Xmin, Ymax, Ymin;
    n = Nrows;
    q = Ncols;
    if (n > q) largest = n;
    else largest = q;
    GetDblMatMem(P,n,q);
    GetDblVecMem(r,largest+1);
    GetDblVecMem(c,q);
    GetDblMatMem(Dr,n,n);
    GetDblMatMem(Dc,q,q);
    GetDblMatMem(A,n,q);
    GetDblMatMem(Du,largest,largest);
    GetDblMatMem(B,n,q);
    GetDblMatMem(Q,n,q);
    GetDblMatMem(U,n,n);
    GetDblMatMem(V,q,q);
    GetDblMatMem(W,largest+1,largest+1);
    GetDblMatMem(Trans,q,q);
    GetDblMatMem(F,n,q);
    GetDblMatMem(Gc,q,q);

    // get proportion matices and vectors
    for (i = 0; i < n; i++)
        for (j = 0; j < q; j++) P[i][j] = Prop[i][j];
    for (i = 0; i < n; i++) r[i] = Prop[i][q];
    for (j = 0; j < q; j++) c[j] = Prop[n][j];

    // get Dr^-1/2 and Dc^-1/2
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
                if (i != j) Dr[i][j] = 0.0;
                else Dr[i][j] = 1.0 / sqrt(r[i]);
        }
    }
    for (i = 0; i < q; i++)
    {
        for (j = 0; j < q; j++)
        {
                if (i != j) Dc[i][j] = 0.0;
                else Dc[i][j] = 1.0 / sqrt(c[j]);
        }
    }

    // get Q = Dr^-1/2 times P times Dc^-1/2
    MATAxB(W,Dr,P,n,n,n,q,errorcode);
    MATAxB(Q,W,Dc,n,q,q,q,errorcode);
    if (ShowQChk->Checked)
    {
        ArrayPrint(Q,n,q,"Q Matrix",RowLabels,ColLabels,"Q Matrix");
//        FrmOutPut->ShowModal();
        AnsiString Instr = InputBox("Save Q to Main Grid?","Y","N");
        if (Instr == "Y")
        {
                MainForm->CloseFile1Click(this);
                MainForm->Grid->RowCount = n + 1;
                MainForm->Grid->ColCount = q + 1;
                for (i = 0; i < n; i++)
                        for (j = 0; j < q; j++)
                                MainForm->Grid->Cells[j+1][i+1] = Q[i][j];
                for (i = 1; i <= n; i++)
                        MainForm->Grid->Cells[0][i] = "CASE " + IntToStr(i);
                for (j = 1; j <= q; j++)
                        MainForm->Grid->Cells[j][0] = "VAR" + IntToStr(j);
        }
    }

    //Obtain ordinary SVD analysis of Q
    svd(Q,n,q,U,Du,V);

    if (EigenChk->Checked)
    {
        ArrayPrint(U,n,q,"U matrix",RowLabels,ColLabels,"U Matrix");
//        FrmOutPut->ShowModal();
        ArrayPrint(Du,q,q,"Singular values",ColLabels,ColLabels,"Du Matrix");
//        FrmOutPut->ShowModal();
        ArrayPrint(V,q,q,"V Matrix",ColLabels,ColLabels,"V Matrix");
//        FrmOutPut->ShowModal();
    }
    if (QCheckChk->Checked)
    {
        // Check to see if Q is reproduced by U x D x V'
        MATAxB(W,U,Du,n,q,q,q,errorcode);
        for (i = 0; i < q; i++)
                for (j = 0; j < q; j++) Trans[i][j] = V[j][i];
        MATAxB(Q,W,Trans,n,q,q,q,errorcode);
        ArrayPrint(Q,n,q,"Reproduced Q = UDV'",RowLabels,ColLabels,"Rep.Q");
//        FrmOutPut->ShowModal();
    }

    // Get A = Dr^1/2 times U
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
                if (i != j) Dr[i][j] = 0.0;
                else Dr[i][j] = sqrt(r[i]);
        }
    }
    MATAxB(A,Dr,U,n,n,n,q,errorcode);
    if (ShowABChk->Checked)
    {
        ArrayPrint(A,n,q,"A matrix",RowLabels,ColLabels,"A Matrix");
//        FrmOutPut->ShowModal();
    }

    // Get B = Dc^1/2 times V
    for (i = 0; i < q; i++)
    {
        for (j = 0; j < q; j++)
        {
                if (i != j) Dc[i][j] = 0.0;
                else Dc[i][j] = sqrt(c[j]);
        }
    }
    MATAxB(B,Dc,V,q,q,q,q,errorcode);
    if (ShowABChk->Checked)
    {
        ArrayPrint(B,q,q,"B matrix",ColLabels,ColLabels,"B Matrix");
//        FrmOutPut->ShowModal();
    }

    if (CheckPChk->Checked)
    {    // see if P = A x Du x B'
        for (i = 0; i < q; i++)
                for (j = 0; j < q; j++) Trans[j][i] = B[i][j];
        MATAxB(W,A,Du,n,q,q,q,errorcode);
        MATAxB(P,W,Trans,n,q,q,q,errorcode);
        ArrayPrint(P,n,q,"P = ADB'",RowLabels,ColLabels,"Repro.P");
//        FrmOutPut->ShowModal();
    }

    // show intertia and scree plot
    double Inertia = ChiSquare / (double)Freq[Nrows][Ncols];
    sprintf(outline,"Inertia = %8.4f",Inertia);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();
    if (PlotChk->Checked)
    {
        GetDblVecMem(X,n);
        GetDblVecMem(Y,n);
        AnsiString *labels;
        labels = new AnsiString[q];
        Xmax = -10000.0;
        Ymax = Xmax;
        Xmin = 10000.0;
        Ymin = Xmin;
        X[0] = 1;
        Y[0] = sqr(Du[1][1]);
        for (i = 1; i < q; i++)
        {
                X[i] = i;
                Y[i] = sqr(Du[i][i]);
                sprintf(outline,"%4.3f%",(Y[i] / Inertia)*100.0);
                labels[i] = outline; // "Dim." + IntToStr(i);
                if (X[i] > Xmax) Xmax = X[i];
                if (X[i] < Xmin) Xmin = X[i];
                if (Y[i] > Ymax) Ymax = Y[i];
                if (Y[i] < Ymin) Ymin = Y[i];
        }
        title = "Goodness of Fit Plot";
        plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,q,labels, title,"Dimension"," ");
        PlotForm->ShowModal();
        delete[] labels;
        delete[] Y;
        delete[] X;
    }

//    if (RowCorres->Checked)
//    {
        // Get Row coordinates F (for row profile analysis)
        for (i = 0; i < n; i++)
        {
                for (j = 0; j < n; j++)
                {
                        if (i != j) Dr[i][j] = 0.0;
                        else Dr[i][j] = 1.0 / r[i];
                }
        }
        MATAxB(W,Dr,A,n,n,n,q,errorcode);
//        ArrayPrint(W,n,q,"Dr x A matrix",RowLabels,ColLabels,"Dr x A Matrix");
//        FrmOutPut->ShowModal();
        MATAxB(F,W,Du,n,q,q,q,errorcode);
        if (RowCorres->Checked)
        {
                ArrayPrint(F,n,q,"(Ignore Column 1)",RowLabels,ColLabels,"Row Dimensions");
//                FrmOutPut->ShowModal();
        }
        // Get Column coordinates G (row profile analysis)
        for (i = 0; i < q; i++)
        {
                for (j = 0; j < q; j++)
                {
                        if (i != j) Dc[i][j] = 0.0;
                        else Dc[i][j] = 1.0 / c[j];
                }
        }
        MATAxB(Gc,Dc,B,q,q,q,q,errorcode);
        if (RowCorres->Checked)
        {
                ArrayPrint(Gc,q,q,"(Ignore Column 1)",ColLabels,ColLabels,"Column Dimensions");
//                FrmOutPut->ShowModal();
        }
        if ((PlotChk->Checked) && (RowCorres->Checked))
        {
                int IX, IY;
                AnsiString prompt, xtitle, ytitle;
                prompt = InputBox("X Axis Dimension","1","1");
                IX = StrToInt(prompt);
                prompt = InputBox("Y Axis Dimension","2","2");
                IY = StrToInt(prompt);
                xtitle = "Dimension " + IntToStr(IX);
                ytitle = "Dimension " + IntToStr(IY);
                GetDblVecMem(X,n);
                GetDblVecMem(Y,n);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < n; i++)
                {
                        X[i] = F[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = F[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Row Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,n,RowLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
                GetDblVecMem(X,q);
                GetDblVecMem(Y,q);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < q; i++)
                {
                        X[i] = Gc[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = Gc[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Column Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,q,ColLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
        }
//    }

    // do column correspondence analysis if checked
//    if (ColCorrChk->Checked)
//    {
        for (i = 0; i < q; i++)
           for (j = 0; j < q; j++) W[i][j] = Gc[i][j]; // use last Gc
        MATAxB(Gc,W,Du,q,q,q,q,errorcode); // multiply times Du
        if (ColCorrChk->Checked)
        {
                ArrayPrint(Gc,q,q,"(Ignore Column 1)",ColLabels,ColLabels,"Column Dimensions");
                FrmOutPut->ShowModal();
        }
        MATAxB(F,Dr,A,n,n,n,q,errorcode); // Get new F
        if (ColCorrChk->Checked)
        {
                ArrayPrint(F,n,q,"(Ignore Column 1)",RowLabels,ColLabels,"Row Dimensions");
                FrmOutPut->ShowModal();
        }
        if ((PlotChk->Checked) && (ColCorrChk->Checked))
        {
                int IX, IY;
                AnsiString prompt, xtitle, ytitle;
                prompt = InputBox("X Axis Dimension","1","1");
                IX = StrToInt(prompt);
                prompt = InputBox("Y Axis Dimension","2","2");
                IY = StrToInt(prompt);
                GetDblVecMem(X,q);
                GetDblVecMem(Y,q);
                xtitle = "Dimension " + IntToStr(IX);
                ytitle = "Dimension " + IntToStr(IY);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < q; i++)
                {
                        X[i] = Gc[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = Gc[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Column Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,q,ColLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
                GetDblVecMem(X,n);
                GetDblVecMem(Y,n);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < n; i++)
                {
                        X[i] = F[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = F[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Row Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,n,RowLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
        }
//    }

    // do both if checked
    if (BothCorrChk->Checked)
    {
        // F is same as for Row correspondence and Gc is same as for columns
        for (i = 0; i < n; i++)
                for (j = 0; j < q; j++) W[i][j] = F[i][j];
        MATAxB(F,W,Du,n,q,q,q,errorcode);
        ArrayPrint(F,n,q,"(Ignore Column 1)",RowLabels,ColLabels,"Row Dimensions");
        FrmOutPut->ShowModal();
        ArrayPrint(Gc,q,q,"(Ignore Column 1)",ColLabels,ColLabels,"Column Dimensions");
        FrmOutPut->ShowModal();
        if (PlotChk->Checked)
        {
                int IX, IY;
                AnsiString prompt, xtitle, ytitle;
                prompt = InputBox("X Axis Dimension","1","1");
                IX = StrToInt(prompt);
                prompt = InputBox("Y Axis Dimension","2","2");
                IY = StrToInt(prompt);
                xtitle = "Dimension " + IntToStr(IX);
                ytitle = "Dimension " + IntToStr(IY);
                GetDblVecMem(X,n);
                GetDblVecMem(Y,n);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < n; i++)
                {
                        X[i] = F[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = F[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Row Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,n,RowLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
                GetDblVecMem(X,q);
                GetDblVecMem(Y,q);
                Xmax = -10000.0;
                Ymax = Xmax;
                Xmin = 10000.0;
                Ymin = Xmin;
                for (i = 0; i < q; i++)
                {
                        X[i] = Gc[i][IX];
                        if (X[i] > Xmax) Xmax = X[i];
                        if (X[i] < Xmin) Xmin = X[i];
                        Y[i] = Gc[i][IY];
                        if (Y[i] > Ymax) Ymax = Y[i];
                        if (Y[i] < Ymin) Ymin = Y[i];
                }
                title = "Column Dimensions";
                plotxy(X,Y,Xmax,Xmin,Ymax,Ymin,q,ColLabels, title,xtitle,ytitle);
                PlotForm->ShowModal();
                delete[] Y;
                delete[] X;
        }
    }
//    FrmOutPut->ShowModal();
    
    // clean up memory
    ClearDblMatMem(Gc,q);
    ClearDblMatMem(F,n);
    ClearDblMatMem(Trans,q);
    ClearDblMatMem(W,largest);
    ClearDblMatMem(V,q);
    ClearDblMatMem(Q,n);
    ClearDblMatMem(B,n);
    ClearDblMatMem(Du,q);
    ClearDblMatMem(A,n);
    ClearDblMatMem(Dc,q);
    ClearDblMatMem(Dr,n);
    delete[] c;
    delete[] r;
    ClearDblMatMem(P,n);
    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(CellChi,Nrows);
    ClearDblMatMem(Expected,Nrows);
    ClearDblMatMem(Prop,Nrows+1);
    ClearIntMatMem(Freq,Nrows+1);
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

void __fastcall TCorrespondenceForm::plotxy(double *Xpoints, double *Ypoints,
                double Xmax, double Xmin, double Ymax, double Ymin, int N,
                AnsiString *PtLabels, AnsiString titlestr,
                AnsiString Xlabel, AnsiString Ylabel)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title, astring;
     char outline[121];

     Title = "X versus Y PLOT";
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     astring = Xlabel; // "Dimension 1";
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(astring) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,astring);

     // Draw vertical axis
     Title = Ylabel; // "Dimension 2";
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.3f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     PlotForm->Image1->Canvas->Font->Size =  8;
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos+3,ypos-5,PtLabels[i]);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(titlestr) / 2);
     ypos = vbottom + 40;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,titlestr);
}
//-------------------------------------------------------------------




