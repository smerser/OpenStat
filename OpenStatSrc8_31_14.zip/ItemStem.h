//---------------------------------------------------------------------------
#ifndef ItemStemH
#define ItemStemH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TStemEditFrm : public TForm
{
__published:	// IDE-managed Components
    TMemo *StemMemo;
    TPanel *Panel1;
    TButton *OKBtn;
    TButton *CancelBtn;
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TStemEditFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStemEditFrm *StemEditFrm;
//---------------------------------------------------------------------------
#endif
