//---------------------------------------------------------------------------

#ifndef DirectoryUnitH
#define DirectoryUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TDirectoryForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label8;
        TLabel *Label9;
        TDriveComboBox *DriveCombo;
        TLabel *Label10;
        TDirectoryListBox *DirectoryList;
        TLabel *Label11;
        TFileListBox *FileListBox1;
        TButton *ReturnBtn;
        TLabel *Label12;
        TEdit *PathEdit;
        TLabel *Label1;
        TButton *CancelBtn;
        TLabel *Label2;
        void __fastcall DriveComboDblClick(TObject *Sender);
        void __fastcall DirectoryListDblClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall DriveComboChange(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TDirectoryForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDirectoryForm *DirectoryForm;
//---------------------------------------------------------------------------
#endif
