//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "MainUnit.h"
#include "DictionaryUnit.h"
#include "DataFuncs.h"
#include "SeqValsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmSeqValues *FrmSeqValues;
extern long int NoVariables;
extern long int NoCases;
extern bool openfile;

//extern bool VarDefined[200];
//extern TMainForm::ItemDefs *varDefinition[200];

//---------------------------------------------------------------------------
__fastcall TFrmSeqValues::TFrmSeqValues(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmSeqValues::FormShow(TObject *Sender)
{
    AnsiString VarLabel;

    VarLabel = "VAR";
    VarLabel = VarLabel + (NoVariables + 1);
    GenNoEdit->Text = NoCases;
    StartEdit->Text = "";
    IncrEdit->Text = "";
    LabelEdit->Text = VarLabel;
}
//---------------------------------------------------------------------------
void __fastcall TFrmSeqValues::ResetBtnClick(TObject *Sender)
{
    FormShow(this);    
}
//---------------------------------------------------------------------------
void __fastcall TFrmSeqValues::CancelBtnClick(TObject *Sender)
{
    FrmSeqValues->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmSeqValues::OKBtnClick(TObject *Sender)
{
    double First;
    double Increment;
    int NoValues, col;
    AnsiString label;
    char cellstring[11];

    NoValues = atoi(GenNoEdit->Text.c_str());
    if (NoValues == 0) return;
    if (MainForm->Grid->RowCount < NoValues)
    {
        MainForm->Grid->RowCount = NoValues+1;
        MainForm->NoCasesEdit->Text = NoValues;
        NoCases = NoValues;
    }
    if (MainForm->Grid->Cells[1][1] == "")
    {
        for (int i = 0; i < NoCases; i++)
        {
            sprintf(cellstring,"CASE %d",i+1);
            MainForm->Grid->Cells[0][i+1] = cellstring;
        }
    }

    First = atof(StartEdit->Text.c_str());
    Increment = atof(IncrEdit->Text.c_str());
    label = LabelEdit->Text;
    col = NoVariables + 1;
    NoVariables++;
    MainForm->NoVarsEdit->Text = NoVariables;
    MainForm->Grid->ColCount++;
    MainForm->Grid->Cells[col][0] = label;
    NewVar(col,true);
    for (int i = 0; i < NoValues; i++)
    {
        MainForm->Grid->Cells[col][i+1] = First;
        First += Increment;
    }
    openfile = true;
    if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "SeqData.TEX";
    FrmSeqValues->Hide();
}
//---------------------------------------------------------------------------
