//---------------------------------------------------------------------------

#ifndef LogRegUnitH
#define LogRegUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TLogisticForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TBitBtn *DepInBtn;
     TBitBtn *DepOutBtn;
     TBitBtn *IndInBtn;
     TBitBtn *IndOutBtn;
     TLabel *Label2;
     TEdit *DepEdit;
     TLabel *Label3;
     TListBox *SelList;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TLabel *Label4;
     TEdit *MaxItersEdit;
     TGroupBox *GroupBox1;
     TCheckBox *DescChk;
     TCheckBox *ProbsChk;
     TCheckBox *ItersChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall DepInBtnClick(TObject *Sender);
     void __fastcall DepOutBtnClick(TObject *Sender);
     void __fastcall IndInBtnClick(TObject *Sender);
     void __fastcall IndOutBtnClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
     double __fastcall ChiSq(double x, int n);
     double __fastcall Norm(double z);
     int __fastcall ix(int j, int k, int nCols);

     private:	// User declarations

public:		// User declarations
     __fastcall TLogisticForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLogisticForm *LogisticForm;
//---------------------------------------------------------------------------
#endif
