//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "functions.h"
#include "math.h"
#include "OutPut.h"
#include "TwoPropsUnit.h"
#include "cdflib.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTwoPropsForm *TwoPropsForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TTwoPropsForm::TTwoPropsForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::ResetBtnClick(TObject *Sender)
{
     int i;

     RadioGroup1->ItemIndex = 0;
     RadioGroup2->ItemIndex = 0;
     Panel1->Visible = true;
     Panel2->Visible = false;
     VarList->Clear();
     Var1->Text = "";
     Var2->Text = "";
     Grp->Text = "";
     CInterval->Text = "95";
     independent = true;
     griddata = false;
     for (i = 1; i <= NoVariables; i++)
     	VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     Label11->Visible = false;
     Grp->Visible = false;
     Label8->Visible = false;
     Label9->Visible = false;
     DepFreq00->Visible = false;
     DepFreq00->Text = "";
     DepFreq01->Visible = false;
     DepFreq01->Text = "";
     DepFreq10->Visible = false;
     DepFreq10->Text = "";
     DepFreq11->Visible = false;
     DepFreq11->Text = "";
     IndFreq1->Text = "";
     IndFreq2->Text = "";
     IndSize1->Text = "";
     IndSize2->Text = "";
     Group1->Text = "";
     Group2->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::RadioGroup1Click(TObject *Sender)
{
     int index;
     index = RadioGroup1->ItemIndex;
     if (index == 0) // enter data on the form
     {
          Panel1->Visible = true;
          Panel2->Visible = false;
          griddata = false;
     }
     else // enter data from the grid
     {
          Panel1->Visible = false;
          Panel2->Visible = true;
          griddata = true;
          if (RadioGroup2->ItemIndex == 1)  // dependent proportions
          {
               Label11->Visible = true;
               Var2->Visible = true;
               Grp->Visible = false;
               Label12->Visible = false;
          }
          else // independent proportions
          {
               Label11->Visible = false;
               Var2->Visible = false;
               Grp->Visible = true;
               Label12->Visible = true;
          }
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::RadioGroup2Click(TObject *Sender)
{
     int index;

     index = RadioGroup2->ItemIndex;
     if (index == 0)
     {
          independent = true;
          Grp->Visible = true;
          Label12->Visible = true;
          Label11->Visible = false;
          Var2->Visible = false;
          Label1->Visible = true;
          Label2->Visible = true;
          Label3->Visible = true;
          Label4->Visible = true;
          IndFreq1->Visible = true;
          IndFreq2->Visible = true;
          IndSize1->Visible = true;
          IndSize2->Visible = true;
          Label5->Visible = false;
          Label6->Visible = false;
          Label7->Visible = false;
          Label8->Visible = false;
          Label14->Visible = false;
          DepFreq00->Visible = false;
          DepFreq01->Visible = false;
          DepFreq10->Visible = false;
          DepFreq11->Visible = false;
          Label15->Visible = true;
          Label16->Visible = true;
          Group1->Visible = true;
          Group2->Visible = true;
     }
     else
     {
          independent = false;
          Label12->Visible = false;
          Grp->Visible = false;
          Label11->Visible = true;
          Var2->Visible = true;
          Label1->Visible = false;
          Label2->Visible = false;
          Label3->Visible = false;
          Label4->Visible = false;
          IndFreq1->Visible = false;
          IndFreq2->Visible = false;
          IndSize1->Visible = false;
          IndSize2->Visible = false;
          Label5->Visible = true;
          Label6->Visible = true;
          Label7->Visible = true;
          Label8->Visible = true;
          Label14->Visible = true;
          DepFreq00->Visible = true;
          DepFreq01->Visible = true;
          DepFreq10->Visible = true;
          DepFreq11->Visible = true;
          Label15->Visible = false;
          Label16->Visible = false;
          Group1->Visible = false;
          Group2->Visible = false;
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     if (! independent)
     {
          if (Var1->Text != "")  Var2->Text = VarList->Items->Strings[index];
          else Var1->Text = VarList->Items->Strings[index];
     }
     if (independent)
     {
          if (Var1->Text != "") Grp->Text = VarList->Items->Strings[index];
          else Var1->Text = VarList->Items->Strings[index];
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoPropsForm::ContinueBtnClick(TObject *Sender)
{
     double ConfInt, Prop1, Prop2, Prop3, Prop4, zstatistic, zprobability;
     double PropDif, stderror, criticalz, UCL, LCL, ztest;
     double P, Q;
     int i, j, v1, v2, NoSelected, f1, f2, f3, f4, ncases1, ncases2;
     int min, max, group, AB, AC, CD, BD, value1, value2;
     int *ColNoSelected;
     AnsiString label1, label2;
     char outline[121];
     bool errorstate;
     double ch, chi, chi2, chi3, Q2, Pb, s;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     // Initialize output form
     FrmOutPut->RichOutPut->Clear();
     stderror = 0.0;
     PropDif = 0.0;
     v2 = 0;
     ztest = 0.0;
     Prop1 = 0.0;
     Prop2 = 0.0;
     v1 = 0;
     zstatistic = 0.0;
     zprobability = 0.0;
     UCL = 0.0;
     LCL = 0.0;

     FrmOutPut->RichOutPut->Lines->Add("  COMPARISON OF TWO PROPORTIONS\n");
     FrmOutPut->RichOutPut->Lines->Add("");
     ColNoSelected = new int[NoVariables];

     ConfInt = (100.0 - StrToFloat(CInterval->Text)) / 2.0 ;
     ConfInt = (100.0 - ConfInt) / 100.0; // one tail
     ncases1 = 0;
     ncases2 = 0;
     f1 = 0;
     f2 = 0;
     f3 = 0;
     f4 = 0;
     if (independent)  Var2->Text = Grp->Text;

     if (griddata)  // data read from grid
     {
          for (i = 1; i <= NoVariables; i++)
          {
               if (Var1->Text == MainForm->Grid->Cells[i][0])
               {
                    v1 = i;
                    ColNoSelected[0] = i;
                    label1 = Var1->Text;
               }
               if (Var2->Text == MainForm->Grid->Cells[i][0])
               {
                    v2 = i;
                    ColNoSelected[1] = i;
                    label2 = Var2->Text;
               }
          } // next variable
          if ((v1 == 0) || (v2 == 0))
          {
                ShowMessage("ERROR!  Select a first and second variable.");
                delete[] ColNoSelected;
                return;
          }
          NoSelected = 2;

          if (! independent)  // correlated data
          {
               for (i = 1; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
                    if (!ValidValue(i,v1)) continue;
                    if (!ValidValue(i,v2)) continue;
                    ncases1 = ncases1 + 1;
                    value1 = floor(StrToFloat(Trim(MainForm->Grid->Cells[v1][i])));
                    //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                    //if (result == 1) value1 = 0;
                   // else value1 = intvalue;
                    value2 = floor(StrToFloat(Trim(MainForm->Grid->Cells[v2][i])));
                    //result = GetValue(i,v2,intvalue,dblvalue,strvalue);
                    //if (result == 1) value2 = 0;
                    //else value2 = intvalue;
                    if (value1 == 0 && value2 == 0) f1 = f1 + 1;
                    else if (value1 == 0 && value2 == 1) f2 = f2 + 1;
                    else if (value1 == 1 && value2 == 0) f3 = f3 + 1;
                    else if (value1 == 1 && value2 == 1) f4 = f4 + 1;
               } // next case
               ch = f2 - f3;
               chi = f2 + f3;
               chi2 = (fabs(ch)-1)/ chi * (fabs(ch)-1);
               chi3 = ch / chi * ch;
               P = chisquaredprob(chi3,1);
               Q = 1 - P;
               P = chisquaredprob(chi2,1);
               Q2 = 1 - P;
               int Which = 1;
               int Status;
               double Bound;
               double Qb;
               s = f2;
               double pr = 0.5;
               double ompr = 1 - pr;
               cdfbin(&Which,&Pb,&Qb,&s,&chi,&pr,&ompr,&Status,&Bound);
               if (Pb < 0.5)
               {Pb = 2 * Pb;}
               else {Pb = 2 - 2 * Pb;}
          } // if not independent

          if (independent)
          {
               min = StrToInt(Group1->Text);
               max = StrToInt(Group2->Text);
    /*         min = ceil(StrToFloat(Trim(MainForm->Grid->Cells[v2][1])));
               max = min;
               for (i = 2; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
                    group = ceil(StrToFloat(Trim(MainForm->Grid->Cells[v2][i])));
                    if (group < min)  min = group;
                    if (group > max)  max = group;
               }
    */
               for (i = 1; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected, NoSelected)) continue;
                    if (!ValidValue(i,v1)) continue;
                    if (!ValidValue(i,v2)) continue;
                    value1 = floor(StrToFloat(Trim(MainForm->Grid->Cells[v1][i])));
                    //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                    //if (result == 1) value1 = 0;
                    //else value1 = intvalue;
                    group = floor(StrToFloat(Trim(MainForm->Grid->Cells[v2][i])));
                    //result = GetValue(i,v2,intvalue,dblvalue,strvalue);
                    //if (result == 1) group = 0;
                    //else group = intvalue;
                    if (group == min && (value1 == 0 || value1 == 1))
                    {
                         f1 = f1 + value1;
                         ncases1 = ncases1 + 1;
                    }
                    else if (group == max && (value1 == 0 || value1 == 1))
                    {
                         f2 = f2 + value1;
                         ncases2 = ncases2 + 1;
                    }
                    else continue;
               } // next case
               Prop1 = (double) f1 / (double) ncases1;
               Prop2 = (double) f2 / (double) ncases2;
               PropDif = Prop1 - Prop2;
               P = (double)(f1 + f2) / (double)(ncases1 + ncases2);
               Q = 1.0 - P;
               stderror = sqrt(P * Q * ((1.0 / ncases1) + (1.0 / ncases2)));
               zstatistic = (Prop1 - Prop2) / stderror;
               zprobability = 2.0 - 2 * probz(fabs(zstatistic));
               ztest = inversez(ConfInt);
               UCL = PropDif + ztest * stderror;
               LCL = PropDif - ztest * stderror;
          } // end if independent
     } // if reading grid data

     if (! griddata)  // data read from form
     {
          if (! independent)  // correlated data
          {
               f1 = ceil(StrToInt(DepFreq00->Text));
               f2 = ceil(StrToInt(DepFreq01->Text));
               f3 = ceil(StrToInt(DepFreq10->Text));
               f4 = ceil(StrToInt(DepFreq11->Text));
               ncases1 = f1 + f2 + f3 + f4;
               ch = f2 - f3;
               chi = f2 + f3;
               chi2 = (fabs(ch)-1)/ chi * (fabs(ch)-1);
               chi3 = ch / chi * ch;
               P = chisquaredprob(chi3,1);
               Q = 1 - P;
               P = chisquaredprob(chi2,1);
               Q2 = 1 - P;
               int Which = 1;
               int Status;
               double Bound;
               double Qb;
               s = f2;
               double pr = 0.5;
               double ompr = 1 - pr;
               cdfbin(&Which,&Pb,&Qb,&s,&chi,&pr,&ompr,&Status,&Bound);
               if (Pb < 0.5)
               {Pb = 2 * Pb;}
               else {Pb = 2 - 2 * Pb;}
          } // if not independent

          if (independent)  // independent data
          {
               f1 = StrToInt(IndFreq1->Text);
               f2 = StrToInt(IndFreq2->Text);
               ncases1 = StrToInt(IndSize1->Text);
               ncases2 = StrToInt(IndSize2->Text);
               if (f1 > ncases1 || f2 > ncases2 || f1 < 0 || f2 < 0)
                {
                ShowMessage("ERROR! Proportions must have values between 0 and 1");
                return;
                }
               Prop1 = (double) f1 / (double) ncases1;
               Prop2 = (double) f2 / (double) ncases2;
               PropDif = Prop1 - Prop2;
               P = (double) (f1 + f2) / (double) (ncases1 + ncases2);
               Q = 1.0 - P;
               stderror = sqrt(P * Q * ((1.0 / (double) ncases1) + (1.0 / (double) ncases2)));
               zstatistic = (Prop1 - Prop2) / stderror;
               zprobability = 2.0 - 2 * probz(fabs(zstatistic));
               ztest = inversez(ConfInt);
               UCL = PropDif + ztest * stderror;
               LCL = PropDif - ztest * stderror;
          }
     }

     // Print the results
     if (! independent)
     {
        double AB = f1 + f2;
        double AC = f1 + f3;
        double AD = f1 + f4;
        double BC = f2 + f3;
        double B = f2;
        double C = f3;
        double ncases = ncases1;
        Prop1 = AB / ncases;
        Prop2 = AC / ncases;
        stderror = AD * BC + 4 * B * C;
        stderror = sqrt(stderror/(ncases * ncases * ncases));
        PropDif = Prop1 - Prop2;
        ztest = inversez(ConfInt);
        UCL = PropDif + stderror * ztest;
        LCL = PropDif - stderror * ztest;
          FrmOutPut->RichOutPut->Lines->Add
          (" --> McNemar Test (Test for the Difference Between two Correlated Proportions)");
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("Sample               2");
          FrmOutPut->RichOutPut->Lines->Add("                 0      1       sum");
          FrmOutPut->RichOutPut->Lines->Add("           --------------------");
          sprintf(outline,"       0  |%6d   %6d   %6d |",f1,f2,f1+f2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("  1        ---------|---------|");
          sprintf(outline,"       1  |%6d   %6d   %6d |",f3,f4,f3+f4);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("           ---------|---------|");
          sprintf(outline," sum      |%6d   %6d   %6d |",f1+f3,f2+f4,ncases1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Chi-Square statistic = %9.4f\tp-value two-tailed =%6.4f\n",chi3,Q);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Chi-Square statistic with Continuity Correction =%9.4f\t\tp-value two-tailed =%6.4f\n",chi2,Q2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Binomial p-value for the two-tailed exact test =%6.4f\n",Pb);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
 //         sprintf(outline,"Confidence Level selected = %s%%",CInterval->Text);
  //        FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Proportion of zeros in Sample 1 =%5.4f\tProportion of zeros in Sample 2 =%5.4f\t%d cases",
          Prop1, Prop2, ncases1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference in proportions = %5.4f",PropDif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Standard Error of Difference = %6.4f",stderror);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z value for confidence interval =%6.4f",ztest);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Confidence Interval %s%% = ( %5.4f,%5.4f )",CInterval->Text, LCL,UCL);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     if (independent)
     {
          FrmOutPut->RichOutPut->Lines->Add(" --> Test for the Difference Between Two Independent Proportions");
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Sample 1: Frequency =%6d for %6d cases.",
               f1, ncases1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Sample 2: Frequency =%6d for %6d cases.",
              f2, ncases2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Proportion 1 =%5.4f\tProportion 2 =%5.4f\tDifference = %5.4f",
              Prop1, Prop2, PropDif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Standard Error of Difference =%5.4f",stderror);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z test statistic =%9.4f\tp-value =%6.4f two-tailed",
              zstatistic,zprobability);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"z value for confidence interval =%7.4f",ztest);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Confidence Interval %s%% = ( %6.4f,%6.4f )",CInterval->Text,LCL,UCL);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->ShowModal();
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------
