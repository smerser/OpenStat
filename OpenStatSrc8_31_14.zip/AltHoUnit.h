//---------------------------------------------------------------------------
#ifndef AltHoUnitH
#define AltHoUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TAltHoFrm : public TForm
{
__published:	// IDE-managed Components
    TButton *ContBtn;
    TButton *CancelBtn;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TEdit *NullMeanEdit;
    TEdit *AltMeanEdit;
    TEdit *StdDevEdit;
    TEdit *TypeIEdit;
    TEdit *TypeIIEdit;
    TButton *ResetBtn;
    void __fastcall NullMeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall AltMeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall StdDevEditKeyPress(TObject *Sender, char &Key);
    void __fastcall TypeIEditKeyPress(TObject *Sender, char &Key);
    void __fastcall TypeIIEditKeyPress(TObject *Sender, char &Key);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TAltHoFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAltHoFrm *AltHoFrm;
//---------------------------------------------------------------------------
#endif
