//---------------------------------------------------------------------------
#ifndef PathAnalH
#define PathAnalH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmPath : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TEdit *CausedEdit;
    TLabel *Label3;
    TListBox *ListBox2;
    TLabel *Label4;
    TEdit *ModelNoEdit;
    TScrollBar *ScrollBar1;
    TButton *ResetModBtn;
    TButton *CancelBtn;
    TButton *ResetBtn;
    TButton *OKBtn;
    TGroupBox *GroupBox1;
    TCheckBox *ShowModRChk;
    TCheckBox *ShowDescChk;
    TCheckBox *ShowRepdChk;
    TBitBtn *CausedInBtn;
    TBitBtn *CausedOutBtn;
    TBitBtn *CausingInBtn;
    TBitBtn *CausingOutBtn;
    TLabel *Label5;
    TListBox *ListBox3;
    TBitBtn *SelInBtn;
    TBitBtn *SelOutBtn;
    TButton *AllBtn;
    TGroupBox *GroupBox2;
    TLabel *Label6;
    TCheckBox *SaveRChkBox;
    void __fastcall CausingInBtnClick(TObject *Sender);
    void __fastcall CausedInBtnClick(TObject *Sender);
    void __fastcall CausedOutBtnClick(TObject *Sender);
    void __fastcall CausingOutBtnClick(TObject *Sender);
    void __fastcall ScrollBar1Change(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ResetModBtnClick(TObject *Sender);
    void __fastcall SelInBtnClick(TObject *Sender);
    void __fastcall SelOutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    
private:	// User declarations
    int ModelNo;
    int NoModels;
    double *v, **IndMatrix, *beta, **InvMatrix, **PathCoef, **e, **W, *p;
    double *means, *stddevs, **rmat, **WorkMat, *WorkVector, **TempMat;
    int *exogenous, **causal, *causedseq, *nocausing, **causingseq;
    int *ColNoSelected, *causing;
    bool *ModelDefined;
    int row, col, i, j, k, L, L2, t, nocaused, noexogenous, NoSelected;
    double d2, absdiff, sum, Temp, s2;
    bool matched, allocated;
    char outline[81];
public:		// User declarations
    __fastcall TFrmPath(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmPath *FrmPath;
//---------------------------------------------------------------------------
#endif
