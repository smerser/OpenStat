//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DictionaryUnit.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
#include "stdio.h"
#include "PlotUnit.h"
#include "CATROC.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCatROCFrm *CatROCFrm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TCatROCFrm::TCatROCFrm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TCatROCFrm::ResetBtnClick(TObject *Sender)
{
        VarList->Clear();
             for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
         CatVarEdit->Text = "";
         NormVarEdit->Text = "";
         PosVarEdit->Text = "";
         ScaleInBtn->Visible = true;
         ScaleOutBtn->Visible = false;
         NormInBtn->Visible = true;
         NormOutBtn->Visible = false;
         PosInBtn->Visible = true;
         PosOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TCatROCFrm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TCatROCFrm::ComputeBtnClick(TObject *Sender)
{
/*
C
C                        :---------------------:
C                        :                     :
C                        :  'ROCFIT' PROGRAM   :                 Jan 1994
C                        :                     :
C                        :---------------------:
C
C
C*******************************************************************************
C                                                                              *
C       A PROGRAM FOR MAXIMUM LIKELIHOOD ESTIMATION OF A BINORMAL              *
C       ROC CURVE AND ITS ASSOCIATED PARAMETERS FROM A SET OF CATEGORICAL      *
C       RATING-SCALE DATA. FOR INHERENTLY CONTINUOUS DATA, THE 'LABROC4'       *
C       PROGRAM SHOULD BE USED INSTEAD.                                        *
C                                                                              *
C       THE MATHEMATICAL BASIS OF THE CURVE-FITTING ALGORITHM IS DESCRIBED     *
C       IN REFERENCES (1) AND (2) BELOW. THIS PROGRAM IS A MODIFIED VERSION    *
C       OF THE PROGRAM 'RSCORE II' BY:                                         *
C                                                                              *
C                    DONALD D. DORFMAN                                         *
C                    DEPARTMENT OF PSYCHOLOGY                                  *
C                    THE UNIVERSITY OF IOWA                                    *
C                    IOWA CITY, IOWA 52242                                     *
C                                                                              *
C       AS LISTED IN REFERENCE (3) BELOW.  MODIFICATIONS TO 'RSCORE II'        *
C       IMPLEMENTED IN 'ROCFIT' WERE DESIGNED BY:                              *
C                                                                              *
C                    CHARLES E. METZ, JONG-HER SHEN, PU-LAN WANG,              *
C                       AND HELEN B. KRONMAN                                   *
C                    DEPARTMENT OF RADIOLOGY                                   *
C                       AND THE FRANKLIN MCLEAN MEMORIAL                       *
C                       RESEARCH INSTITUTE                                     *
C                    THE UNIVERSITY OF CHICAGO                                 *
C                    CHICAGO, ILLINOIS 60637                                   *
C                                                                              *
C       AND WERE WRITTEN BY JONG-HER SHEN, PU-LAN WANG, AND HELEN B. KRONMAN.  *
C       THESE MODIFICATIONS INCLUDE:                                           *
C          (A). PROVIDING FOR INPUT OF A FREE-TEXT LINE TO DESCRIBE THE        *
C               DATA SET IN THE OUTPUT HEADING.                                *
C          (B). ALLOWING THE USE OF FREE FORMAT FOR DATA INPUT.                *
C          (C). ALLOWING EITHER HIGHER OR LOWER CATEGORY NUMBERS TO            *
C               INDICATE GREATER CONFIDENCE THAT A SIGNAL (E.G., 'ABNORMALITY) *
C               IS PRESENT.                                                    *
C          (D). CHECKING CONSISTENCY OF INPUT DATA.                            *
C          (E). GIVING VARIABLES MORE MNEMONIC NAMES.                          *
C          (F). RENUMBERING STATEMENTS IN ORDER OF APPEARANCE.                 *
C          (G). TESTING THE RATING-SCALE DATA SET FOR 'DEGENERACY'             *
C               BEFORE ATTEMPTING THE ITERATIVE CALCULATIONS.                  *
C          (H). CALCULATION OF 'DIFFSN' AND 'DIFFN' BETWEEN STATEMENTS         *
C               1060 AND 1065 IN SUBROUTINE 'TERMS', AND USE OF THESE IN       *
C               SUBSEQUENT COMPUTATIONS.                                       *
C          (I). MODIFICATION OF THE ITERATIVE PROCEDURE TO ENSURE THAT         *
C               TWO CONDITIONS ARE SATISFIED AT EACH STEP: (1) THE MATRIX      *
C               OF SECOND PARTIAL DERIVATIVES MUST NOT BECOME NUMERICALLY      *
C               SINGULAR, AND (2) THE LOG-LIKELIHOOD FUNCTION MUST NOT         *
C               DECREASE BY MORE THAN 10**(-5) OF ITS PREVIOUS ABSOLUTE        *
C               VALUE.  IF EITHER OF THESE CONDITIONS IS VIOLATED AT SOME      *
C               STEP, THE ADJUSTMENTS OF ALL PARAMETER ESTIMATES ARE           *
C               REDUCED SUCCESSIVELY BY 50% UNTIL THE CONDITIONS ARE           *
C               SATISFIED. ITERATION THEN PROCEEDS TO THE NEXT STEP.           *
C          (J). MODIFICATION OF THE STOPPING CRITERION TO REFLECT THE          *
C               NUMBER OF CATEGORIES EMPLOYED IN THE DATA (I.E., TO            *
C               REFLECT THE NUMBER OF ADJUSTABLE PARAMETERS).                  *
C          (K). CALCULATION AND OUTPUT OF A 'CORRELATION MATRIX' FOR           *
C               THE PARAMETER ESTIMATES IN ADDITION TO THE 'VARIANCE-          *
C               COVARIANCE MATRIX'.                                            *
C          (L). CALCULATION AND OUTPUT OF 'TRUE POSITIVE FRACTIONS' ON         *
C               THE FITTED ROC CURVE AT A VARIETY OF 'FALSE POSITIVE           *
C               FRACTIONS', TO ALLOW THE FITTED ROC CURVE TO BE PLOTTED        *
C               EASILY ON LINEAR AXES.                                         *
C          (M). CALCULATION AND OUTPUT OF THE ASYMMETRIC 95% CONFIDENCE        *
C               INTERVAL FOR 'TRUE POSITIVE FRACTION' AT EACH 'FALSE           *
C               POSITIVE FRACTION'.                                            *
C          (N). CALCULATION AND OUTPUT OF EXPECTED OPERATING POINTS            *
C               ESTIMATED ON THE FITTED ROC CURVE, TOGETHER WITH ASSYMETRIC    *
C               95% CONFIDENCE INTERVALS FOR THOSE POINTS ALONG THE            *
C               FITTED CURVE.                                                  *
C                                                                              *
C       REFERENCES:                                                            *
C          (1). DORFMAN, D. D. AND ALF, E. - JOURNAL OF MATHEMATICAL           *
C               PSYCHOLOGY, 6: 487-496, 1969.                                  *
C          (2). GREY, D. R. AND MORGAN, B. J. T. - JOURNAL OF                  *
C               MATHEMATICAL PSYCHOLOGY, 9: 128-139, 1972.                     *
C          (3). SWETS, J. A. AND PICKETT, R. M. - EVALUATION OF                *
C               DIAGNOSTIC SYSTEMS: METHODS FROM SIGNAL DETECTION              *
C               THEORY.  (NEW YORK: ACADEMIC PRESS), 1982.                     *
C                                                                              *
C                                                                              *
C       INQUIRIES OR COMMENTS CONCERNING THIS PROGRAM SHOULD BE DIRECTED       *
C       TO C. E. METZ AT THE ADDRESS ABOVE.                                    *
C                                                                              *
C                                                                              *
C       ACKNOWLEDGEMENT:                                                       *
C          MODIFICATION OF THIS PROGRAM AT THE UNIVERSITY OF CHICAGO           *
C          WAS SUPPORTED BY THE U.S. DEPARTMENT OF ENERGY UNDER                *
C          CONTRACTS DE-AC02-80EV10359 AND DE-AC02-82ER60033 AND               *
C          UNDER GRANT DE-FG02-86ER60418.                                      *
C                                                                              *
C                                                                              *
C*******************************************************************************
*/
        // Variables Used in the procedure
        int lowcat, hicat, lowcount, hicount;
        int catvarcol, negcntcol, poscntcol;
        int catval, negval, posval;
        char outline[101];
        GetIntVecMem(cat,NoCases);
        GetIntVecMem(CATN,NoCases);
        GetIntVecMem(CATS,NoCases);
        lowcat = 1000;
        hicat = -1000;
        lowcount = 10000;
        hicount = -1000;
        EMN = 0;
        EMS = 0;
        AAA = 0.0;
        BBB = 0.0;
        A = 0.0;
        B = 0.0;
        FUNLIK = 0.0;
        KSN = 0;

        for (int i = 1; i <= NoVariables; i++)
        {
                if (MainForm->Grid->Cells[i][0] == CatVarEdit->Text) catvarcol = i;
                if (MainForm->Grid->Cells[i][0] == NormVarEdit->Text) negcntcol = i;
                if (MainForm->Grid->Cells[i][0] == PosVarEdit->Text) poscntcol = i;
        }
        for (int i = 1; i <= NoCases; i++)
        {
                catval = StrToInt(MainForm->Grid->Cells[catvarcol][i]);
                if (catval > hicat) hicat = catval;
                if (catval < lowcat) lowcat = catval;
                negval = StrToInt(MainForm->Grid->Cells[negcntcol][i]);
                if (negval > hicount) hicount = negval;
                if (negval < lowcount) lowcount = negval;
                posval = StrToInt(MainForm->Grid->Cells[poscntcol][i]);
                if (posval > hicount) hicount = posval;
                if (posval < lowcount) lowcount = posval;
                cat[i-1] = catval;
                CATN[i-1] = negval;
                CATS[i-1] = posval;
        }
        KAT = hicat - lowcat + 1;
        for (int i = 0; i < NoCases; i++)
        {
                EMN += CATN[i];
                EMS += CATS[i];
        }
        GetIntVecMem(catcount,KAT);
        for (int i = 1; i <= NoCases; i++)
        {
                catval = StrToInt(MainForm->Grid->Cells[catvarcol][i]);
                catval = catval - lowcat;
                negval = StrToInt(MainForm->Grid->Cells[negcntcol][i]);
                posval = StrToInt(MainForm->Grid->Cells[poscntcol][i]);
                catcount[catval] = negval + posval;
        }

        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("Categorical ROC Analysis Results");
        sprintf(outline,"No. of Cases = %d",NoCases);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"No. of Categories = %d",KAT);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Low category = %d, Highest category = %d",hicat,lowcat);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Total negative count = %d",EMN);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Total positive count = %d",EMS);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("TOTAL");
        FrmOutPut->RichOutPut->Lines->Add("CATEGORY COUNT");
        for (int i = 0; i < KAT; i++)
        {
                sprintf(outline," %5d  %5d",lowcat+i,catcount[i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();

        // Do Analysis
        // collapse categories with 0 entries
        int KAT1 = KAT;
        for (int i = 0; i < KAT; i++)
        {
                int it = KAT - i;
                if ((CATN[it] != 0) && (CATS[it] != 0)) continue;
                KAT1 = KAT1 - 1;
                if (it > KAT1) continue;
                for (int j = it; j > 0; j--)
                {
                        CATN[j-1] = CATN[j];
                        CATS[j-1] = CATS[j];
                }
        }
        KAT = KAT1;
        // sort into descending order
/*        for (int i = 0; i < KAT-1; i++)
        {
                for (int j = i; j < KAT; j++)
                {
                        if (CATN[i] < CATN[j]) // swap
                        {
                                int temp = CATN[i];
                                CATN[i] = CATN[j];
                                CATN[j] = temp;
                        }
                        if (CATS[i] < CATS[j]) // swap
                        {
                                int temp = CATS[i];
                                CATS[i] = CATS[j];
                                CATS[j] = temp;
                        }
                }
        }
*/
        // calculate observed operating points
        int nn = KAT + 1;
        GetDblVecMem(fpf,nn);
        GetDblVecMem(tpf,nn);
        GetDblVecMem(PX,KAT+2);
        GetDblVecMem(DX,KAT+2);
        GetDblVecMem(PXBA,KAT+2);
        GetDblVecMem(DXBA,KAT+2);
        GetDblMatMem(XX,KAT+2,KAT+2);
        GetDblMatMem(XXDUM,KAT+2,KAT+2);
        GetDblVecMem(ADJX,KAT+2);
        GetDblMatMem(XP,KAT+2,KAT+2);
        GetDblVecMem(PARX,KAT+2);
        GetDblVecMem(DIFFN,KAT+2);
        GetDblVecMem(DIFFSN,KAT+2);
        GetDblVecMem(X,KAT+2);
        GetDblVecMem(XS,KAT+2);
        for (int i = 0; i < KAT+2; i++)
        {
            for (int j = 0; j < KAT+2; j++)
            {
                XX[i][j] = 0.0;
                XXDUM[i][j] = 0.0;
                XP[i][j] = 0.0;
            }
        }
        for (int i = 0; i < KAT+2; i++)
        {
            PX[i] = 0.0;
            DX[i] = 0.0;
            PXBA[i] = 0.0;
            DXBA[i] = 0.0;
            ADJX[i] = 0.0;
            PARX[i] = 0.0;
            DIFFN[i] = 0.0;
            DIFFSN[i] = 0.0;
            X[i] = 0.0;
            XS[i] = 0.0;
        }
        for (int i = 0; i < nn; i++) // initialize arrays
        {
                fpf[i] = 0.0;
                tpf[i] = 0.0;
        }
        fpf[nn-1] = 0.0;
        tpf[nn-1] = 0.0;
        fpf[KAT-1] = CATN[KAT-1];
        tpf[KAT-1] = CATS[KAT-1];
        for (int i = 1; i <= KAT; i++)
        {
                fpf[KAT-i] = fpf[KAT-i+1] + CATN[KAT-i];
                tpf[KAT-i] = tpf[KAT-i+1] + CATS[KAT-i];
        }
        for (int i = 0; i < nn; i++)
        {
                fpf[i] = fpf[i] / EMN;
                tpf[i] = tpf[i] / EMS;
        }
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("Observed Operating Points");
        FrmOutPut->RichOutPut->Lines->Add("NORMAL   POSITIVE");
        for (int i = 0; i < nn; i++)
        {
                sprintf(outline,"%6.4f   %6.4f",fpf[nn-i-1],tpf[nn-i-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();

        // check for degeneracy of the data set
        int iclass, icon;
        GetIntVecMem(iary,KAT+1);
        check(iclass, KAT, fpf, tpf, icon, iary);
        // if iclass not equal 0 report degeneracy
        if (iclass != 0)
        {
                FrmOutPut->RichOutPut->Clear();
                degen(iclass, iary, fpf, tpf);
                FrmOutPut->ShowModal();
        }

        // get initial estimates of the parameters
        inifit(KAT,EMN,EMS,fpf,tpf);

        // use "Method of Scoring" to get final estimates
        int LL = 0;
        MOSLOP(LL,XP);
        OUTRSL(LL,XP);

        // clear memory
        ClearIntVecMem(iary);
        ClearDblVecMem(XS);
        ClearDblVecMem(X);
        ClearDblVecMem(DIFFSN);
        ClearDblVecMem(DIFFN);
        ClearDblVecMem(PARX);
        ClearDblMatMem(XP,KAT+2);
        ClearDblVecMem(ADJX);
        ClearDblMatMem(XXDUM,KAT+2);
        ClearDblMatMem(XX,KAT+2);
        ClearDblVecMem(DXBA);
        ClearDblVecMem(PXBA);
        ClearDblVecMem(DX);
        ClearDblVecMem(PX);
        ClearDblVecMem(tpf);
        ClearDblVecMem(fpf);
        ClearIntVecMem(catcount);
        ClearIntVecMem(CATS);
        ClearIntVecMem(CATN);
        ClearIntVecMem(cat);
}
//---------------------------------------------------------------------------

void TCatROCFrm::check(int &iclass, int KAT, double *fpf, double *tpf,
                      int icon, int *iary)
{
// check for degeneracy
        double t;
        int nn, i0, i1, i2, ica, icb, ii1, ii2, k1, kk1, k2, kk2;
/*

      PURPOSE
        CHECK DEGENERACY OF DATA SET.

      DESCRIPTION OF PARAMETERS
        iclass    -  OUTPUT CLASS NUMBER OF DEGENERACY. (USED BY
                     SUBROUTINE 'DEGENE' IF NECESSARY)
        KAT     -  NUMBER OF CATEGORIES OF DATA SET.
        fpf,tpf   -  OBSERVED OPERATING POINTS.
        icon,iary -  STORAGE SPACE FOR INFORMATION IN MESSAGE.  (USED BY
                     SUBROUTINE 'DEGENE' IF NECESSARY)
*/
        nn = KAT + 1;
        iclass = 0;
        icon = 0;
        i0 = 0;
        i1 = 0;
        for (int i = 0; i < nn; i++) iary[i] = 0;
        for (int i = 2; i <= KAT; i++)
        {
                t = fpf[i-1] * tpf[i-1] * (1.0 - fpf[i-1]) * (1.0 - tpf[i-1]);
                if (t == 0.0) continue;
                icon = icon + 1;
                iary[icon-1] = i;
        }
        if (KAT == 1) goto pt20;
        if (icon == 0) goto pt40;
        i0 = iary[0] - 1;
        i1 = iary[icon-1] + 1;
        if ((KAT == 2) && (icon != 0)) goto pt30;
        if (icon >= 2) goto pt15;
        if ( ((tpf[i0] != 1.0) || (tpf[i1] != 0.0)) &&
           ((fpf[i0] == 1.0) && (fpf[i1] == 0.0)) ) iclass = 5;
        if (((fpf[i0] != 1.0) || (fpf[i1] != 0.0)) &&
           ((tpf[i0] == 1.0) && (tpf[i1] == 0.0))) iclass = 6;
        return;

pt15:   if ( (tpf[iary[0]] == tpf[iary[icon]]) &&
           ((fpf[i0-1] == 1) && (fpf[i1-1] == 0)) ) iclass = 7;

        if ( ((tpf[i0-1] == 1) && (tpf[i1-1] == 0)) &&
           (fpf[iary[0]] == fpf[iary[icon]]) ) iclass = 8;
        return;
pt20:   iclass = 1;
        return;
pt30:   iclass = 2;
        return;
pt40:   ica = 0;
        icb = 0;
        for (int i = 0; i < nn; i++)
        {
                if ((fpf[i] != 0) && (fpf[i] != 1)) ica = ica + 1;
                if ((tpf[i] != 0) && (tpf[i] != 1)) icb = icb + 1;
        }
        i1 = 0;
        i2 = 0;
        for (int i = 2; i <= KAT; i++)
        {
                if ((fpf[i-1] == 1) && (tpf[i-1] != 1)) goto pt55;
                if ((fpf[i-1] == 0) && (tpf[i-1] != 0)) i2 = i2 + 1;
                if (i2 == 1) iary[1] = i-1;
                continue;
pt55:           i1 = i1 + 1;
                iary[0] = i;
        }
        ii1 = 0;
        ii2 = 0;
        for (int i = 2; i <= KAT; i++)
        {
                if ((fpf[i-1] != 1) && (tpf[i-1] == 1)) goto pt65;
                if ((fpf[i-1] != 0) && (tpf[i-1] == 0)) ii2 = ii2 + 1;
                if (ii2 == 1) iary[3] = i;
                continue;
pt65:           ii1 = ii1 + 1;
                iary[2] = i;
        }
        if (((ica != 0) && (icb != 0)) || (((ica == 0) &&
           ((i1 == 0) || (i2 == 0))) || ((icb == 0) && ((ii1 == 0) || (ii2 == 0)))))
        goto pt80;
        if ((ica == 0) && (i1 >= 1) && (i2 >= 1)) goto pt75;

        if ((icb == 0) && (ii1 >= 1) && (ii2 >= 1)) iclass = 4;
        iary[0] = iary[2];
        iary[1] = iary[3];
        return;
pt75:   iclass = 3;
        return;

pt80:   kk1 = iary[2] + 1;
        k1 = iary[0] + 1;
        kk2 = iary[3] - 1;
        k2 = iary[1] - 1;
        if (((ii1 != 0) && (fpf[kk1] == 0)) || ((i2 != 0) && (tpf[k2] == 1))) iclass = 9;
        if (((i1 != 0) && (tpf[k1] == 0)) || ((ii2 != 0) && (fpf[kk2] == 1))) iclass = 10;
}

//===================================================================

void TCatROCFrm::degen(int &iclass, int *iary, double *fpf, double *tpf)
{
// report type of degeneracy
        double P, QF, QT, D, DD;
        int IER;
        char outline[110];
//---------------------------------------------------------
//      SUBROUTINE DEGENE(ICLASS,IARY,FPF,TPF)
//---------------------------------------------------------
//
//     PURPOSE
//       OUTPUT MESSAGE FOR EACH DEGENERACY CLASS.
//
//     DESCRIPTION OF PARAMETERS
//       ICLASS    -  INPUT CLASS NUMBER OF DEGENERACY FROM SUBROUTINE
//                    'CHECK'.
//       IARY      -  INPUT INFORMATION FROM SUBROUTINE 'CHECK'.
//       FPF,TPF   -  OBSERVED OPERATING POINTS.
//

        FrmOutPut->RichOutPut->Clear();
        if (iclass == 1)
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND IMPLY PERFECT (BUT PERVERSE)");
                FrmOutPut->RichOutPut->Lines->Add("OFF THE (0,0) AND (1,1) CORNERS.");
        }
        if (iclass == 2)
        {
                P = fpf[iary[0]];
                QF = inversez(P);
                P = tpf[iary[0]];
                QT = inversez(P);
                DD = QT - QF;
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND PROVIDE ONLY A SINGLE ");
                FrmOutPut->RichOutPut->Lines->Add("OPERATING POINT OFF THE (0,0) AND (1,1) CORNERS.");
                FrmOutPut->RichOutPut->Lines->Add("BINORMAL ROC CURVE CANNOT BE ESTIMATED UNIQUELY.");
                sprintf(outline,"UNIT SLOPE ROC CURVE (B=1) WOULD HAVE A=D %8.4f .",DD);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                return;
        }
        if (iclass == 3)
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND PRODUCE NO OPERATING POINTS");
                FrmOutPut->RichOutPut->Lines->Add("OFF THE BORDERS OF THE UNIT SQUARE.  IMPLIED");
                FrmOutPut->RichOutPut->Lines->Add("EXACT-FIT BINORMAL ROC CURVE IS HORIZONTAL AT");
                sprintf(outline,"UNDETERMINED HEIGHT BETWEEN TPF = %8.4f AND TPF = %8.4f .",
                        tpf[iary[1]],tpf[iary[0]]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                return;
        }
        if (iclass == 4)
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND PRODUCE NO OPERATING POINTS");
                FrmOutPut->RichOutPut->Lines->Add("OFF THE BORDERS OF THE UNIT SQUARE.  IMPLIED");
                FrmOutPut->RichOutPut->Lines->Add("EXACT-FIT BINORMAL ROC CURVE IS VERTICAL AT");
                sprintf(outline,"UNDETERMINED POSITION BETWEEN FPF = %8.4f AND FPF = %8.4f .",
                       fpf[iary[1]],fpf[iary[0]]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                return;
        }
        if ((iclass == 5) || (iclass == 7))
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE.  IMPLIED EXACT-FIT");
                sprintf(outline,"BINORMAL ROC CURVE IS HORIZONTAL AT CONSTANT TPF = %8.4f .", tpf[iary[0]]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                return;
        }
        if ((iclass == 6) || (iclass == 8))
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE.  IMPLIED EXACT-FIT");
                sprintf(outline,"BINORMAL ROC CURVE IS VERTICAL AT CONSTANT FPF = %8.4f .", fpf[iary[0]]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                return;
        }
        if (iclass == 9)
        {
                FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND IMPLY PERFECT DECISION PERFORMANCE.");
                return;
        }

        FrmOutPut->RichOutPut->Lines->Add("DATA ARE DEGENERATE AND IMPLY PERFECT (BUT PERVERSE) DECISION PERFORMANCE.");
}
//===================================================================

void TCatROCFrm::inifit(int KAT, int EMN, int EMS,
                      double *fpf, double *tpf)
{
// get initial estimates by linear regression
        double Q = 0.0;
        double P, D, SUMX, SUMY, SUMXY, SUMX2, XMEAN, YMEAN, XK;
        int KK, IZ, IER;
        char outline[110];

        KK = KAT - 1;
        for (int i = 1; i <= KK; i++)
        {
                X[i-1] = fpf[i];
                XS[i-1] = tpf[i];
        }
        for (int i = 1; i <= KK; i++)
        {
                if (X[i-1] == 0.0) X[i-1] = 1.0 / (2.0 * EMN);
                if ((fabs(X[i-1]-1.0)) < 1.0e-05) X[i-1] = 1.0 - (1.0 / (2.0 * EMN));
                P = X[i-1];
                Q = inversez(P);
                X[i-1] = Q;
                if (XS[i-1] == 0.0)XS[i-1] = 1.0 / (2.0 * EMS);
                if ((fabs(XS[i-1]-1.0)) < 1.0e-05) XS[i-1] = 1.0 - (1.0 / (2.0 * EMS));
                P = XS[i-1];
                Q = inversez(P);
                XS[i-1] = Q;
        }
        IZ = KK - 1;
        for (int i = 1; i <= IZ; i++)
        {
                if (X[IZ-i] <= X[IZ-i+1]) X[IZ-i] = X[IZ-i+1] + 0.1;
                if (XS[IZ-i] <=XS[IZ-i+1]) XS[IZ-i] = XS[IZ-i+1] + 0.1;
        }
        SUMX = 0.0;
        SUMY = 0.0;
        SUMXY = 0.0;
        SUMX2 = 0.0;
        XK = (double) KK;
        for (int i = 1; i <= KK; i++)
        {
                SUMX = SUMX + X[i-1];
                SUMX2 = SUMX2 + (X[i-1] * X[i-1]);
                SUMY = SUMY + XS[i-1];
                SUMXY = SUMXY + (XS[i-1] * X[i-1]);
        }
        XMEAN = SUMX / XK;
        YMEAN = SUMY / XK;
        B = (XK * SUMXY - SUMX * SUMY) / (XK * SUMX2 - (SUMX * SUMX));
        A = YMEAN - B * XMEAN;
//
//      WRITE OUT INITIAL ESTIMATES OF PARAMETER VALUES
//
        sprintf(outline,"INITIAL VALUES OF PARAMETERS: A = %7.4f, B = %7.4f", A,B);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 1; i <= KK; i++)
        {
                X[i-1] = -X[i-1];
                sprintf(outline,"i = %3d  Z(i) = %7.4f",i, X[i-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
}
//========================================================================

void TCatROCFrm::MOSLOP(int &LL, double **XP)
{
        double TNET, ALPHA, ADJA, ADJB, FUNLI1, FUNDIF;
        int KK, NN, SWT, IER;
        char outline[101];
        char value[11];

	TNET = 1.0;
	ALPHA = 1.0;
        NN = KAT + 1;
        KK = KAT - 1;
        SWT = 0;
        LL = 0;
        IER = 0;
pt1050: LL = LL + 1;
//
//      GET INTEGRALS AND DENSITIES
//
        TERMS();
        if ((LL == 1) && (KAT > 3)) CHISQR();
//
//      CALCULATES PARTIAL DERIVATIVES
//
        PDEV();
//
//      INVERT MATRIX
//
        for (int i = 1; i <= NN; i++)
                for (int j = 1; j <= NN; j++)
                        XX[i-1][j-1] = -XX[i-1][j-1];
// my substituted procedure
        for (int i = 1; i <= NN; i++)
                for (int j = 1; j <= NN; j++)
                        XXDUM[i-1][j-1] = XX[i-1][j-1];
        IER = 0;
/*
        char Title[14] = "XX Matrix";
        AnsiString *Rows, *Cols;
        Rows = new AnsiString[NN];
        Cols = new AnsiString[NN];
        for (int i = 0;i < NN; i++)
        {
                Rows[i] = IntToStr(i);
                Cols[i] = IntToStr(i);
        }
        ArrayPrint(XXDUM, NN, NN, "Row/Col",Rows, Cols, Title);
        delete [] Cols;
        delete [] Rows;
        FrmOutPut->ShowModal();
*/
        IER = SVDinverse(XXDUM,NN);
/*
        char ATitle[21] = "XX Inverse Matrix";
//        AnsiString *Rows, *Cols;
        Rows = new AnsiString[NN];
        Cols = new AnsiString[NN];
        for (int i = 0;i < NN; i++)
        {
                Rows[i] = IntToStr(i);
                Cols[i] = IntToStr(i);
        }
        ArrayPrint(XXDUM, NN, NN, "Row/Col",Rows, Cols, ATitle);
        FrmOutPut->ShowModal();

        // check for accuracy of inverse by multiply inverse times original
        double **Repro;
        bool errorcode;
        GetDblMatMem(Repro,NN,NN);
        MATAxB(Repro, XXDUM, XX, NN, NN, NN,NN, &errorcode);
        ArrayPrint(Repro,NN,NN,"Row/Col",Rows,Cols,Title);
        FrmOutPut->ShowModal();
        delete [] Cols;
        delete [] Rows;
        ClearDblMatMem(Repro,NN);
*/
// end of my procedure
//
//      IF PROBLEMS ARE ENCOUNTERED IN MATRIX INVERSION, REDUCE
//      ADJUSTMENTS TO SOLUTION VECTOR AND GO ON TO TEST CHANGE
//      IN LOG-LIKELIHOOD FUNCTION

        if (IER >= 0) goto pt1137;
        ALPHA = -0.5 * fabs(ALPHA);
        goto pt1157;
//
pt1137: if (IER > 0)
        {
                sprintf(outline,"Loss of Significance. Step %5d",IER);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        for (int i = 1; i <= NN; i++)
                for (int j = 1; j <= NN; j++)
                        XP[i-1][j-1] = XXDUM[i-1][j-1];

        if (SWT == 1) return;
        if (KAT <= 3) return;
//
//      FORM SOLUTION VECTOR
//
        ADJA = AAA * XP[0][0] + BBB * XP[0][1];
        for (int i = 1; i <= KK; i++)
                ADJA = ADJA + PARX[i-1] * XP[0][i+1];
        ADJB = AAA * XP[1][0] + BBB * XP[1][1];
        for (int i = 1; i <= KK; i++)
                ADJB = ADJB + PARX[i-1] * XP[1][i+1];
        for (int i = 1; i <= KK; i++)
        {
                ADJX[i-1] = AAA * XP[i+1][0] + BBB * XP[i+1][1];
                for (int k = 3; k <= NN; k++)
                        ADJX[i-1] = ADJX[i-1] + PARX[k-1] * XP[i+1][k-1];
        }
//
//      ITERATE
//
pt1156: ALPHA = 1.0;
pt1157: A = A + ALPHA * ADJA;
        B = B + ALPHA * ADJB;
        for (int i = 1; i <= KK; i++) X[i-1] = X[i-1] + ALPHA * ADJX[i-1];
        TERMS();
        if (ALPHA != 1.0) goto pt1175;
//
//      CHECK FOR MAXIMIZATION OF LOG-LIKELIHOOD
//
        if (LL == 1) goto pt1175;
        TNET = fabs(ADJA) + fabs(ADJB);
        for (int i = 1; i <= KK; i++) TNET = TNET + fabs(ADJX[i-1]);
        TNET = 6.0 * TNET / (double)(1 + KAT);
        if (TNET >= 0.001) goto pt1175;
        SWT = 1;
        goto pt1050;
//
//      CHECK THAT LOG-LIKELIHOOD FUNCTION VALUE INCREASES, OR AT LEAST
//      DOESN'T DECREASE BY MORE THAN 0.001%; OTHERWISE, HALVE THE
//      CORRECTION VECTOR UNTIL REQUIREMENT IS SATISFIED.
//

pt1175: if (ALPHA == 1.0) FUNLI1 = FUNLIK;
        FUNLIK = 0.0;
        for (int i = 1; i <= KAT; i++)
        FUNLIK = FUNLIK + CATN[i-1] * log(DIFFN[i-1]) + CATS[i-1] * log(DIFFSN[i-1]);
        if (FUNLIK >= FUNLI1) goto pt1185;
        FUNDIF = fabs((FUNLIK - FUNLI1) / TNET);
        if ((ALPHA <= 1.0e-5) || (FUNDIF <= 1.0e-4)) goto pt1185;
        ALPHA = -0.5 * fabs(ALPHA);
        goto pt1157;
pt1185: if (LL <= 0) goto pt1050;
//        sprintf(outline,"Does not converge after %d interations",LL);
//        FrmOutPut->RichOutPut->Lines->Add(outline);
//        FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------

void TCatROCFrm::TERMS(void)
{
        // Calculate integrals and densities
        int NN;
        double Y;

        NN = KAT + 1;
        PXBA[0] = 0.0;
        PXBA[NN-1] = 1.0;
        DXBA[0] = 0.0;
        DXBA[NN-1] = 0.0;
        PX[0] = 0.0;
        PX[NN-1] = 1.0;
        DX[0] = 0.0;
        DX[NN-1] = 0.0;
        for (int i = 2; i <= KAT; i++)
        {
                Y = X[i-2] * B - A;
                if (Y > 4.0) Y = 4.0;
                if (Y < -4.0) Y = -4.0;
                PXBA[i-1] = normalprob(Y);
                DXBA[i-1] = ord(Y);
        }
        for (int i = 2; i <= KAT; i++)
        {
                Y = X[i-2];
                if (Y > 4.0) Y = 4.0;
                if (Y < -4.0) Y = -4.0;
                PX[i-1] = normalprob(Y);
                DX[i-1] = ord(Y);
        }
        for (int i = 1; i <= KAT; i++)
        {
                DIFFSN[i-1] = PXBA[i] - PXBA[i-1];
                DIFFN[i-1] = PX[i] - PX[i-1];
                if (DIFFSN[i-1] < 5.0E-8) DIFFSN[i-1] = 5.0E-8;
                if (DIFFN[i-1] < 5.0E-8) DIFFN[i-1] = 5.0E-8;
        }
        FUNLIK = 0.0;
        for (int i = 1; i <= KAT; i++)
                FUNLIK = FUNLIK + CATN[i-1] * log(DIFFN[i-1]) + CATS[i-1] * log(DIFFSN[i-1]);
}
//====================================================================

void TCatROCFrm::PDEV(void)
{
//      CALCULATES PARTIAL DERIVATIVES
        double Q1, Q2, D, DD, DDD, XIL2, CHNG;
//
//      GET FIRST PARTIAL DERIVATIVES
//      WITH RESPECT TO A
//
        AAA = 0.0;

        for (int i = 2; i <= KAT; i++)
                AAA = AAA - DXBA[i-1] * (CATS[i-2] / DIFFSN[i-2] - CATS[i-1] / DIFFSN[i-1]);
//
//      WITH RESPECT TO B
//
        BBB = 0.0;
        for (int i = 2; i <= KAT; i++)
                BBB = BBB + DXBA[i-1] * X[i-2] * (CATS[i-2] / DIFFSN[i-2] -CATS[i-1] / DIFFSN[i-1]);
//
//       WITH RESPECT TO Z'S
//
        for (int i = 2; i <= KAT; i++)
        {
                Q1 = DXBA[i-1] * B * (CATS[i-2] / DIFFSN[i-2] - CATS[i-1] / DIFFSN[i-1]);
                Q2 = DX[i-1] * (CATN[i-2] / DIFFN[i-2] - CATN[i-1] / DIFFN[i-1]);
                PARX[i-2] = Q1 + Q2;
        }
//
//      GET EXPECTED SECOND AND MIXED PARTIAL DERIVATIVES
//      WITH RESPECT TO A
//
        XX[0][0] = 0.0;
        for (int i = 2; i <= KAT; i++)
                XX[0][0] = XX[0][0] - DXBA[i-1] * ((DXBA[i-1] - DXBA[i-2]) /
                DIFFSN[i-2] - (DXBA[i] - DXBA[i-1]) / DIFFSN[i-1]);
        XX[0][0] = EMS * XX[0][0];
//
//      WITH RESPECT TO B
//
        XX[1][1] = 0.0;
        for (int i = 2; i <= KAT; i++)
        {
                D = X[i-2];
                if(i == KAT) goto pt1090;
                if (i == 2) goto pt1085;
                DD = X[i-3];
                DDD = X[i-1];
                goto pt1095; // GO TO 1095
pt1085:         DD = 0.0;
                DDD = X[i-1];
                goto pt1095; //GO TO 1095
pt1090:         DD = X[i-3];
                DDD = 0.0;
pt1095:         XX[1][1] = XX[1][1] - DXBA[i-1] * X[i-2] * ((DXBA[i-1] * D - DXBA[i-2] * DD) /
                  DIFFSN[i-2] - (DXBA[i] * DDD - DXBA[i-1] * D ) / DIFFSN[i-1]);
        }
        XX[1][1] = EMS * XX[1][1];
//
//      WITH RESPECT TO A AND B
//
        XX[0][1] = 0.0;
        for (int i = 2; i <= KAT; i++)
          XX[0][1] = XX[0][1] + DXBA[i-1] * X[i-2] * ((DXBA[i-1] - DXBA[i-2]) /
                DIFFSN[i-2] - (DXBA[i] - DXBA[i-1]) / DIFFSN[i-1]);
        XX[0][1] = EMS * XX[0][1];
        XX[1][0] = XX[0][1];
//
//      WITH RESPECT TO A AND Z'S
//
        for (int i = 2; i <= KAT; i++)
        {
                XX[0][i] = (EMS * B * DXBA[i-1] * ((DXBA[i-1] - DXBA[i-2]) / DIFFSN[i-2] -
                  (DXBA[i] - DXBA[i-1]) / DIFFSN[i-1]));
                XX[i][0] = XX[0][i];
        }
//
//      WITH RESPECT TO B AND Z'S
//
        for (int i = 2; i <= KAT; i++)
        {
                XIL2 = 0.0;
                if (i > 2) XIL2 = X[i-3];
                if (i == KAT) goto pt1110;
                CHNG = X[i-1];
                goto pt1115;
pt1110:         CHNG = 0.0;
pt1115:         XX[1][i] = -(EMS * DXBA[i-1] * B * ((DXBA[i-1] * X[i-2] - DXBA[i-2] * XIL2) /
                   DIFFSN[i-2] - (DXBA[i] * CHNG - DXBA[i-1] * X[i-2]) / DIFFSN[i-1]));
                XX[i][1] = XX[1][i];
        }
//
//      WITH RESPECT TO Z'S AND MIXED WITH RESPECT TO Z'S
//
        for (int i = 2; i <= KAT; i++)
        {
                if (i == KAT) goto pt1125;
                XX[i][i+1] = (EMS * DXBA[i-1] * DXBA[i] * B * B) / DIFFSN[i-1] + (EMN *
                   DX[i-1] * DX[i]) / DIFFN[i-1];
                XX[i+1][i] = XX[i][i+1];
pt1125:         XX[i][i]= -(EMS * sqr(DXBA[i-1] * B) * (1.0 / DIFFSN[i-2] + 1.0 /
                   DIFFSN[i-1]) + EMN * DX[i-1] * DX[i-1] * (1.0 / DIFFN[i-2] + 1.0 / DIFFN[i-1]));
        }
}
//=====================================================================

void TCatROCFrm::CHISQR(void)
{
        int NN, IDCH;
        double SUMN, SUMM, FLOGL, CHI, DEGCHI, PVAL;
        char outline[101];
//-------------------------------------
//	SUBROUTINE CHISQR
//-------------------------------------
        NN = KAT + 1;
pt1120: SUMN = 0.0;
        SUMM = 0.0;
        for (int i = 2; i <= NN; i++)
        { //        DO 1130 I=2,NN
                SUMM = SUMM + CATS[i-2] * log(DIFFSN[i-2]);
                SUMN = SUMN + CATN[i-2] * log(DIFFN[i-2]);
        }
        FLOGL = SUMN + SUMM;
        sprintf(outline,"LOGL = %10.4f",FLOGL);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (KAT > 3) goto pt2020;  // IF (KAT.GT.3)GO TO 2020
        FrmOutPut->RichOutPut->Lines->Add("CHI-SQUARE GOODNESS OF FIT NOT CALCULATED");
        FrmOutPut->RichOutPut->Lines->Add("BECAUSE THERE ARE NO RESIDUAL DEGREES OF FREEDOM WHEN ONLY 3");
        FrmOutPut->RichOutPut->Lines->Add("CATEGORIES ARE EMPLOYED.");
        return; // RETURN
pt2020: for (int i = 1; i <= KAT; i++)
        { //        DO 2110 I=1,KAT
                if ((CATN[i-1] >= 5) && (CATS[i-1] >= 5)) goto pt2110; //GO TO 2110
                FrmOutPut->RichOutPut->Lines->Add("CHI-SQUARE GOODNESS OF FIT NOT CALCULATED");
                FrmOutPut->RichOutPut->Lines->Add("BECAUSE SOME EXPECTED CELL FREQUENCIES ARE LESS THAN 5.");
                return; // RETURN
        } //  2110   CONTINUE
pt2110: IDCH = KAT - 3; // KAT-3
        SUMM = 0.0;
        SUMN = 0.0;
        for (int i = 2; i <= NN; i++)
        { //        DO 2130 I=2,NN
                SUMN = SUMN + EMS * sqr(CATS[i-2] / EMS - DIFFSN[i-2]) / DIFFSN[i-2];
                SUMM = SUMM + EMN * sqr(CATN[i-2] / EMN - DIFFN[i-2]) / DIFFN[i-2];
        }
        CHI = SUMM + SUMN;
        PVAL = chisquaredprob(CHI,IDCH);
        PVAL = 1.0 - PVAL;
        sprintf(outline,"GOODNES OF FIT CHI-SQUARE = %10.4f WITH %2d D.F. p = %7.4f",
                CHI,IDCH,PVAL);
        FrmOutPut->RichOutPut->Lines->Add(outline);
//        FrmOutPut->ShowModal();
}
//====================================================================

void TCatROCFrm::OUTRSL(int &LL, double **XP)
{
//------------------------------------
//	SUBROUTINE OUTRSL(LL,XP)
//------------------------------------
//
//     WRITE OUT FINAL VALUES
//
        double **CX;
        double *BDLOW, *BDUPP, *EFPF, *ETPF, *FPUPP;
        double *TPFUPP, *FPFLOW, *TPFLOW, *FPFUPP, *TPVAL;
        double WORKV, ADEV, CA2, CB2, CAB, VAREA, P, TPDEV, SI, BOUND1, BOUND2;
        double Q, QU, QL, DENS, D, AREA;
        double FPVAL[26] = { 0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07,
            0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14, 0.15, 0.20, 0.25, 0.30,
            0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95 };
        int NN, KK, II;
        char outline[110];
        char valuestr[11];

        WORKV = 0.0;
        ADEV = 0.0;
        CA2 = 0.0;
        CB2 = 0.0;
        CAB = 0.0;
        VAREA = 0.0;
        P = 0.0;
        TPDEV = 0.0;
        SI = 0.0;
        BOUND1 = 0.0;
        BOUND2 = 0.0;
        Q = 0.0;
        QU = 0.0;
        QL = 0.0;
        DENS = 0.0;
        D = 0.0;
        AREA = 0.0;
        GetDblMatMem(CX,13,13);
//        GetDblVecMem(FPVAL,28);
        GetDblVecMem(BDLOW,28);
        GetDblVecMem(BDUPP,28);
        GetDblVecMem(EFPF,11);
        GetDblVecMem(ETPF,11);
        GetDblVecMem(FPFUPP,11);
        GetDblVecMem(TPFUPP,11);
        GetDblVecMem(FPFLOW,11);
        GetDblVecMem(TPFLOW,11);
        GetDblVecMem(TPVAL,28);
        NN = KAT + 1;
        KK = KAT - 1;
        if (KAT <= 3) LL = 0; // IF(KAT.LE.3)LL=0
//        sprintf(outline,"Procedure converges after %3d iterations.",LL);
//        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (KAT > 3) goto pt1350; // IF(KAT.GT.3)GO TO 1350
        sprintf(outline,"Initial estimates provide an exact fit because only");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"three categories were employed.");
        FrmOutPut->RichOutPut->Lines->Add(outline);
pt1350: sprintf(outline,"Final values of parameters: A = %7.4f  B = %7.4f",A, B);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 1; i <= KK; i++)
        {
                sprintf(outline,"Z(%d) = %7.4f",i,X[i-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        CHISQR(); // CALL CHISQR
//        FrmOutPut->ShowModal();

        for (int i = 1; i <= NN; i++)
                for (int j = 1; j <= NN; j++)
                        CX[i-1][j-1] = XP[i-1][j-1] / sqrt(XP[i-1][i-1] * XP[j-1][j-1]);
/*        FrmOutPut->RichOutPut->Lines->Add("Variance-Covariance Matrix");
        strcpy(outline,"A   ");
        for (int j = 1; j <= NN; j++)
        {
                sprintf(valuestr,"%7.4f",XP[0][j-1]);
                strcat(outline,valuestr);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"B   ");
        for (int j = 1; j <= NN; j++)
        {
                sprintf(valuestr,"%7.4f",XP[1][j-1]);
                strcat(outline,valuestr);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 3; i <= NN; i++)
        {
                II = i - 2;
                sprintf(outline,"z(%2d) ",II);
                for (int j = 1; j <= NN; j++)
                {
                        sprintf(valuestr,"%7.4f ",XP[i-1][j-1]);
                        strcat(outline,valuestr);
                }
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
//        FrmOutPut->ShowModal();
*/
        FrmOutPut->RichOutPut->Lines->Add("Correlation Matrix:");
        strcpy(outline,"A     ");
        for (int j = 1; j <= NN; j++)
        {
                sprintf(valuestr,"%7.4f ",CX[0][j-1]);
                strcat(outline,valuestr);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"B     ");
        for (int j = 1; j <= NN; j++)
        {
                sprintf(valuestr,"%7.4f ",CX[1][j-1]);
                strcat(outline,valuestr);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 3; i <= NN; i++)
        {
                II = i - 2;
                sprintf(outline,"Z(%d)  ",II);
                for (int j = 1; j <= NN; j++)
                {
                        sprintf(valuestr,"%7.4f ",CX[i-1][j-1]);
                        strcat(outline,valuestr);
                }
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
//        FrmOutPut->ShowModal();

//
//     SUMMARY OF ROC CURVE
//
        WORKV = 1.0 + B * B;
        ADEV = A / sqrt(WORKV);
        AREA = normalprob(ADEV);
        DENS = ord(ADEV);
        CA2 = XP[0][0];
        CB2 = XP[1][1];
        CAB = XP[0][1];
        VAREA = sqrt((DENS * DENS) * (CA2 / WORKV + (sqr(A * B)) * CB2 / pow(WORKV,3)
        - 2 * A * B * CAB / (WORKV * WORKV)));
        sprintf(outline,"AREA = %7.4f  Std.Dev. (AREA) = %7.4f",AREA,VAREA);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
//
//     WITH GIVEN FALSE-POSITIVE FRACTIONS, COMPUTE THE TRUE-
//     POSITIVE FRACTIONS ON THE ESTIMATED ROC CURVE, WITH
//     LOWER AND UPPER BOUNDS OF THE ASYMMETRIC 95% CONFIDENCE
//     INTERVAL.
//
        for (int i = 1; i <= 26; i++) //DO 2205 I=1,26
        {
                P = FPVAL[i-1];
                Q = inversez(P);
                D = ord(Q);
                TPDEV = A + B * Q;
                SI = sqrt(Q * Q * CB2 + CA2 + 2.0 * Q * CAB);
                BOUND1 = TPDEV - 1.96 * SI;
                BOUND2 = TPDEV + 1.96 * SI;
                P = normalprob(TPDEV);
                D = ord(TPDEV);
                TPVAL[i-1] = P;
                P = normalprob(BOUND1);
                D = ord(BOUND1);
                BDLOW[i-1]= P;
                P = normalprob(BOUND2);
                D = ord(BOUND2);
                BDUPP[i-1] = P;
        } // 2205 CONTINUE

        sprintf(outline,"Estimated Binormal ROC Curve with Lower and Upper");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Bounds on Asymetric 95% Confidence Interval for");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"True-Positive Fraction at each specified");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"False-Positive fraction:");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"   FPF      TPF        (Lower bound, Upper bound)");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 1; i <= 26; i++)
        {
                sprintf(outline,"  %5.3f    %6.4f      %6.4f,   %6.4f",
                   FPVAL[i-1],TPVAL[i-1],BDLOW[i-1],BDUPP[i-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
        // create a temp array that includes 0 and 1 points to plot
        double *tplotpts, *fplotpts, *upper, *lower;
        GetDblVecMem(tplotpts,28);
        GetDblVecMem(fplotpts,28);
        GetDblVecMem(upper,28);
        GetDblVecMem(lower,28);
        for (int i = 1; i <= 26; i++)
        {
                fplotpts[i] = FPVAL[i-1];
                tplotpts[i] = TPVAL[i-1];
                upper[i] = BDUPP[i-1];
                lower[i] = BDLOW[i-1];
        }
        fplotpts[0] = 0.0;
        fplotpts[27] = 1.0;
        tplotpts[0] = 0.0;
        tplotpts[27] = 1.0;
        upper[0] = 0.0;
        upper[27] = 1.0;
        lower[0] = 0.0;
        lower[27] = 1.0;

//
//     COMPUTE THE LOWER AND UPPER BOUNDS (ALONG THE FITTED CURVE)
//     OF THE ASYMMETRIC 95% CONFIDENCE INTERVAL FOR EACH
//     EXPECTED OPERATING POINT ESTIMATED ON THE FITTED CURVE.
//
        for (int i = 1; i <= KK; i++) //DO 2305 I=1,KK
        {
                Q = X[i-1];
                P = normalprob(Q);
                D = ord(Q);
                EFPF[i-1]  = 1 - P;
                QU = Q - 1.96 * sqrt(XP[i+1][i+1]);
                QL = Q + 1.96 * sqrt(XP[i+1][i+1]);
                P = normalprob(QU);
                D = ord(QU);
                FPFUPP[i-1] = 1.0 - P;
                P = normalprob(QL);
                D = ord(QL);
                FPFLOW[i-1] = 1.0 - P;
                Q = B * X[i-1] - A;
                P = normalprob(Q);
                D = ord(Q);
                ETPF[i-1] = 1.0 - P;
                QU = Q - 1.96 * B * sqrt(XP[i+1][i+1]);
                QL = Q + 1.96 * B * sqrt(XP[i+1][i+1]);
                P = normalprob(QU);
                D = ord(QU);
                TPFUPP[i-1] = 1.0 - P;
                P = normalprob(QL);
                D = ord(QL);
                TPFLOW[i-1] = 1.0 - P;
        } //2305 CONTINUE
        sprintf(outline,"ESTIMATES OF EXPECTED OPERATING POINTS ON FITTED ROC");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"CURVE, WITH LOWER AND UPPER BOUNDS OF ASYMMETRIC 95%");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"CONFIDENCE INTERVALS ALONG THE CURVE FOR THOSE POINTS:");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"EXPECTED OPERATING POINT         LOWER BOUND         UPPER BOUND");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"(FPF ,   TPF)           (  FPF ,   TPF)     (  FPF ,     TPF )");
        FrmOutPut->RichOutPut->Lines->Add(outline);

        for (int i = 1; i <= KK; i++) // DO 2320 I=1,KK
        {
                II = KK - i + 1;
                sprintf(outline,"{%6.4f, %6.4f)          (%6.4f, %6.4f)     (%6.4f, %6.4f",
                        EFPF[II-1],ETPF[II-1],FPFLOW[II-1],TPFLOW[II-1],FPFUPP[II-1],TPFUPP[II-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
//        PlotPts(FPVAL,TPVAL,BDLOW,BDUPP);
        PlotPts(fplotpts,tplotpts,lower,upper);
        PlotForm->ShowModal();

        delete[] lower;
        delete[] upper;
        delete[] fplotpts;
        delete[] tplotpts;
        delete[] TPVAL;
        delete[] TPFLOW;
        delete[] FPFLOW;
        delete[] TPFUPP;
        delete[] FPFUPP;
        delete[] ETPF;
        delete[] EFPF;
        delete[] BDUPP;
        delete[] BDLOW;
//        delete[] FPVAL;
        ClearDblMatMem(CX,13);
}
//=====================================================================

void __fastcall TCatROCFrm::ScaleInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     CatVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ScaleInBtn->Visible = false;
     ScaleOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TCatROCFrm::NormInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     NormVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     NormInBtn->Visible = false;
     NormOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TCatROCFrm::PosInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     PosVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     PosInBtn->Visible = false;
     PosOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void TCatROCFrm::PlotPts(double *Xpoints,double *Ypoints, double *Ylow, double *Yup)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     int N = 28;
     double maxval, minval, valincr, Yvalue, Xvalue, Xmin, Xmax, Ymin,Ymax;
     AnsiString Title, XTitle, YTitle;
     char outline[121];

     Xmin = 0.0;
     Xmax = 1.0;
     Ymin = 0.0;
     Ymax = 1.0;
     Title = "ROC CURVE";
     XTitle = "FALSE POSITIVE FRACTION";
     YTitle = "TRUE POSITIVE FRACTION";
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XTitle) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XTitle);
     sprintf(outline,"Green = Expected Curve, Red and Blue = Lower and upper 95 Percent Confidence Levels");
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(outline) / 2);
     ypos = ypos + 15;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,outline);

     // Draw vertical axis
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(YTitle) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(YTitle);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YTitle);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs - main curve
     ypos = ceil(vhi * ( (Ymax - Ypoints[0]) / (Ymax - Ymin)));
     ypos = ypos + vtop;
     xpos = ceil(hwide * ( (Xpoints[0] - Xmin) / (Xmax - Xmin)));
     xpos = xpos + hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clGreen;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }
     // draw points for x and y pairs - lower confidence curve
     ypos = ceil(vhi * ( (Ymax - Ylow[0]) / (Ymax - Ymin)));
     ypos = ypos + vtop;
     xpos = ceil(hwide * ( (Xpoints[0] - Xmin) / (Xmax - Xmin)));
     xpos = xpos + hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ylow[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clRed;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clRed;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }
     // draw points for x and y pairs - upper curve
     ypos = ceil(vhi * ( (Ymax - Yup[0]) / (Ymax - Ymin)));
     ypos = ypos + vtop;
     xpos = ceil(hwide * ( (Xpoints[0] - Xmin) / (Xmax - Xmin)));
     xpos = xpos + hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Yup[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }
}
//===========================================================================
