//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <stdio.h>
#include "Output.h"
#include <math.h>
#include "functions.h"
#include "DataFuncs.h"
#include <stdlib.h>

#include "MWUFormUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMWUForm *MWUForm;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;

//---------------------------------------------------------------------------
__fastcall TMWUForm::TMWUForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMWUForm::FormShow(TObject *Sender)
{
    AnsiString cellstring;

    ListBox1->Clear();
    for (int i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        ListBox1->Items->Add(cellstring);
    }
    GroupEdit->Text = "";
    DependEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TMWUForm::OKBtnClick(TObject *Sender)
{
    int i, j, ind_var, dep_var, min_grp, max_grp,group, total_n = 0,
        NoTies, NoTieGroups =0, n1, n2, nogroups, TieSum, largestn;
    int *group_count;
    int ColNoSelected[2];
    int NoSelected = 2;
    double score, t, SumT = 0.0, Avg, z, probz, U, U2, SD,  Temp;
    double **Ranks, **X, *RankSums;
    AnsiString cellstring;
    char outline[81];

    // Check for data
    if (NoVariables < 1)
    {
        Application->MessageBox("You must have grid data!","ERROR",MB_OK);
        return;
    }
    // Get column numbers of the independent and dependent variables
    ind_var = 0;
    dep_var = 0;
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = GroupEdit->Text;
        if (cellstring == MainForm->Grid->Cells[i+1][0]) ind_var = i+1;
        cellstring = DependEdit->Text;
        if (cellstring == MainForm->Grid->Cells[i+1][0]) dep_var = i+1;
    }
    if ((ind_var == 0) || (dep_var == 0))
    {
        ShowMessage("ERROR!  Select both the dependent and independent variable.");
        return;
    }
    ColNoSelected[0] = ind_var;
    ColNoSelected[1] = dep_var;

    //get minimum and maximum group codes
    min_grp = 10000; //atoi(MainForm->Grid->Cells[ind_var][1].c_str());
    max_grp = -10000;
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        group = floor(StrToFloat(MainForm->Grid->Cells[ind_var][i+1]));
        if (group < min_grp) min_grp = group;
        if (group > max_grp) max_grp = group;
    }
    nogroups = max_grp - min_grp + 1;

    // Allocate storage space
    try  {
        Ranks = new double *[NoCases];
        for (i = 0; i < NoCases; i++) Ranks[i] = new double[2];
        X = new double *[NoCases];
        for (i = 0; i < NoCases; i++) X[i] = new double[2];
        group_count = new int[nogroups];
        RankSums = new double[nogroups];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Mann-Whitney.","MEMORY ERROR!",MB_OK);
        return;
    }

    // Initialize arrays
    for (i = 0; i < nogroups; i++)
    {
        group_count[i] = 0;
        RankSums[i] = 0.0;
    }

    // Setup for printer output
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Mann-Whitney U Test");
    FrmOutPut->RichOutPut->Lines->Add("See pages 116-127 in S. Siegel's Nonparametric Statistics for the Behavioral Sciences");
    FrmOutPut->RichOutPut->Lines->Add("");

    // Get data
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        score = StrToFloat(MainForm->Grid->Cells[dep_var][i+1]);
        group = StrToFloat(MainForm->Grid->Cells[ind_var][i+1]);
        if (group > 2)
        {
            Application->MessageBox("Group codes must be 1 or 2!","ERROR!",MB_OK);
            goto cleanup;
        }
        group_count[group-min_grp]++;
        X[total_n][0] = score;
        X[total_n][1] = group-min_grp;
        total_n++;
    }

    //Sort all scores in ascending order
    for (i = 0; i < total_n-1; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (j = i+1; j < total_n; j++)
        {
//            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            if (X[i][0] > X[j][0])
            {
                Temp = X[i][0];
                X[i][0] = X[j][0];
                X[j][0] = Temp;
                Temp = X[i][1];
                X[i][1] = X[j][1];
                X[j][1] = Temp;
            }
        }
    }

    // Store ranks
    for (i = 0; i < total_n; i++)
    {
//        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        Ranks[i][0] = i+1;
        Ranks[i][1] = X[i][1];
    }

    //Check for ties in ranks - replace with average rank and calculate
    //T for each tie and sum of the T's
    for (i = 0; i < total_n-1; i++)
    {
        j = i + 1;
        TieSum = 0.0;
        NoTies = 0;
        while (j < total_n)
        {
            if (X[j][0] > X[i][0]) goto Check1;
            if (X[j][0] == X[i][0]) // match
            {
                TieSum += Ranks[j][0];
                NoTies++;
            }
            j++;
        }
Check1:
        if (NoTies > 0) //At least one tie found
        {
            TieSum += Ranks[i][0];
            NoTies++;
            Avg = TieSum / double(NoTies);
            for (j = i; j < i+NoTies; j++) Ranks[j][0] = Avg;
            t = pow(NoTies,3) - NoTies;
            SumT += t;
            NoTieGroups++;
            i += (NoTies - 1);
        }
    } // next i

    // Calculate sum of ranks in each group
    for (i = 0; i < total_n; i++)
    {
//        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        group = Ranks[i][1];
        RankSums[group] += Ranks[i][0];
    }

    //Calculate U for larger and smaller groups
    n1 = group_count[0];
    n2 = group_count[1];
    if (n1 > n2)
        U = double(n1 * n2) + (double(n1 * (n1 + 1)) / 2.0) - RankSums[0];
    else
        U = double(n1 * n2) + (double(n2 * (n2 + 1)) / 2.0) - RankSums[1];
    U2 = double (n1 * n2) - U;
    SD = double(n1 * n2 * (n1 + n2 + 1)) / 12.0;
    SD = sqrt(SD);
    if (U2 > U) z = (U2 - double(n1 * n2 / 2)) / SD;
    else z = (U - double(n1 * n2 / 2)) / SD;
    probz = 1.0 - normalprob(z);

    //Report results
    FrmOutPut->RichOutPut->Lines->Add("     Score     Rank      Group");
    FrmOutPut->RichOutPut->Lines->Add("");
    for (i = 0; i < total_n; i++)
    {
//        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        sprintf(outline,"%10.2f %10.2f %10.0f",
            X[i][0], Ranks[i][0], Ranks[i][1]+1);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sum of Ranks in each Group");
    FrmOutPut->RichOutPut->Lines->Add("Group   Sum    No. in Group");
    for (i = 0; i < nogroups; i++)
    {
        sprintf(outline,"%3d  %10.2f %5d", i+min_grp, RankSums[i],group_count[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No. of tied rank groups = %3d",NoTieGroups);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (n1 > n2) largestn = n1;
    else largestn = n2;
    if (largestn < 20)
        sprintf(outline,"Statistic U = %8.4f",U);
    else
    {
        if (U > U2) sprintf(outline,"Statistic U = %8.4f",U);
        else sprintf(outline,"Statistic U = %8.4f",U2);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"z Statistic (corrected for ties) = %8.4f, Prob. > z = %6.4f",
                     z, probz);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (n2 < 20)
    {
        FrmOutPut->RichOutPut->Lines->Add("z test is approximate.  Use tables of exact probabilities in Siegel.");
        FrmOutPut->RichOutPut->Lines->Add("(Table J or K, pages 271-277)");
    }
    FrmOutPut->ShowModal();
    // Clean up the heap
cleanup:
    delete[] RankSums;
    delete[] group_count;
    for (i = 0; i < NoCases; i++) delete[] X[i];
    delete[] X;
    for (i = 0; i < NoCases; i++) delete[] Ranks[i];
    delete[] Ranks;

    MWUForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMWUForm::CancelBtnClick(TObject *Sender)
{
        MWUForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMWUForm::ResetBtnClick(TObject *Sender)
{
        FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TMWUForm::ListBox1Click(TObject *Sender)
{
    int index;

    index = ListBox1->ItemIndex;
    if (GroupEdit->Text == "") GroupEdit->Text = ListBox1->Items->Strings[index];
    else DependEdit->Text = ListBox1->Items->Strings[index];
}
//---------------------------------------------------------------------------
