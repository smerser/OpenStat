//---------------------------------------------------------------------------

#ifndef DateFuncH
#define DateFuncH
//---------------------------------------------------------------------------
#endif
long ymd_to_date(int year, int month, int day);
int valid_ymd(int year, int month, int day);

