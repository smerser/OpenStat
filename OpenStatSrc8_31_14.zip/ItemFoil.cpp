//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ItemFoil.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TItemFoilFrm *ItemFoilFrm;
//---------------------------------------------------------------------------
__fastcall TItemFoilFrm::TItemFoilFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TItemFoilFrm::OKBtnClick(TObject *Sender)
{
    ItemFoilFrm->Hide();    
}
//---------------------------------------------------------------------------

void __fastcall TItemFoilFrm::CancelBtnClick(TObject *Sender)
{
    ItemFoilFrm->Hide();    
}
//---------------------------------------------------------------------------

void __fastcall TItemFoilFrm::FormShow(TObject *Sender)
{
    Memo1->SetFocus();    
}
//---------------------------------------------------------------------------

