//---------------------------------------------------------------------------

#ifndef RecodeUnitH
#define RecodeUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmRecode : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *IntoRadioGrp;
    TLabel *Label1;
    TEdit *VarNameEdit;
    TLabel *Label2;
    TEdit *NewNameEdit;
    TGroupBox *OldValGrpBox;
    TRadioButton *ValueBtn;
    TEdit *OldValEdit;
    TRadioButton *BlanksBtn;
    TRadioButton *RangeBtn;
    TEdit *LowRangeEdit;
    TLabel *Label3;
    TEdit *HiRangeEdit;
    TRadioButton *LowestToBtn;
    TEdit *TopRangeEdit;
    TRadioButton *DownToBtn;
    TEdit *DownToEdit;
    TRadioButton *AllButBtn;
    TEdit *AllButEdit;
    TGroupBox *NewValueGrpBox;
    TRadioButton *NewValueBtn;
    TEdit *NewValueEdit;
    TRadioButton *NewBlankBtn;
    TButton *ApplyBtn;
    TButton *CancelBtn;
    TButton *AnotherBtn;
    TButton *ReturnBtn;
        TMemo *Memo1;
        TButton *AllVarBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall IntoRadioGrpClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ApplyBtnClick(TObject *Sender);
    void __fastcall AnotherBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
     void __fastcall FormHide(TObject *Sender);
        void __fastcall AllVarBtnClick(TObject *Sender);
private:	// User declarations
    int OldColNo;
    int NewColNo;
    int BtnNo;
    bool newmade;
    bool AllVars;
public:		// User declarations
    __fastcall TFrmRecode(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmRecode *FrmRecode;
//---------------------------------------------------------------------------
#endif
