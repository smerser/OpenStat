//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "OutPut.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "AutoPlotUnit.h"
#include "MainUnit.h"
#include "functions.h"
#include "GraphUnit.h"
#include "InterruptedUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TInterruptedForm *InterruptedForm;
extern int NoCases;
extern int NoVariables;
//---------------------------------------------------------------------------
__fastcall TInterruptedForm::TInterruptedForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     PreList->Clear();
     PostList->Clear();
     PreInBtn->Visible = true;
     PreOutBtn->Visible = false;
     PostInBtn->Visible = true;
     PostOutBtn->Visible = false;
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);     
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::PreInBtnClick(TObject *Sender)
{
   int index, i;

   index = VarList->Items->Count;
   i = 0;
   while (i < index)
   {
         if (VarList->Selected[i])
         {
              PreList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index = index - 1;
              i = 0;
         }
         else i = i + 1;
   }
   PreOutBtn->Visible = true;
   if (VarList->Items->Count == 0) PreInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::PostInBtnClick(TObject *Sender)
{
   int index, i;

   index = VarList->Items->Count;
   i = 0;
   while (i < index)
   {
         if (VarList->Selected[i])
         {
              PostList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index = index - 1;
              i = 0;
         }
         else i = i + 1;
   }
   PostOutBtn->Visible = true;
   if (VarList->Items->Count == 0) PostInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::PreOutBtnClick(TObject *Sender)
{
     int index = PreList->ItemIndex;
     VarList->Items->Add(PreList->Items->Strings[index]);
     PreList->Items->Delete(index);
     PreInBtn->Visible = true;
     if (PreList->Items->Count < 1) PreOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::PostOutBtnClick(TObject *Sender)
{
     int index = PostList->ItemIndex;
     VarList->Items->Add(PostList->Items->Strings[index]);
     PostList->Items->Delete(index);
     PostInBtn->Visible = true;
     if (PostList->Items->Count < 1) PostOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TInterruptedForm::ComputeBtnClick(TObject *Sender)
{
   int i, i1, j, j2, j3, k;
   int *ColNoSelected;
   double *rxy;
   AnsiString heading;
   char outline[121];
   g1s = "t..change in level  ";
   g2s = "t..change in slope  ";
   g3s = "scaled posterior    ";
   g4s = "lower 99 percent    ";
   g5s = "lower 95 percent    ";
   g6s = "delta               ";
   g7s = "upper 95 percent    ";
   g8s = "upper 99 percent    ";
   c9 = 1.0E-15;
   n1 = 0;
   n2 = 0;
   g = 0.01;
   NoGoodCases = 0;

   FrmOutPut->RichOutPut->Clear();
   FrmOutPut->RichOutPut->Lines->Add("Interrupted Time Series Analysis");
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("Adapted from the Fortran program written by Glass and Maguire");
   FrmOutPut->RichOutPut->Lines->Add("and based on Box and Tiao IMA(1,1) procedure.  Published in");
   FrmOutPut->RichOutPut->Lines->Add("How To Psychotherapy and How to Evaluate It by");
   FrmOutPut->RichOutPut->Lines->Add("John M. Gottman and Sandra R. Leiblum, Holt, Rinehart and ");
   FrmOutPut->RichOutPut->Lines->Add("Winston, Inc., New York, 1974.");
   FrmOutPut->RichOutPut->Lines->Add("");

   n1 = PreList->Items->Count;
   n2 = PostList->Items->Count;
   if ((n1 < 2) || (n2 < 2))
   {
        ShowMessage("ERROR! Select 2 or more pre and post variables.");
        return;
   }
   
   t1 = n1 + n2;

   // allocate space
   z = new double[t1];
   y = new double[t1];
   GetDblMatMem(x1,4,4);
   GetDblMatMem(x2,4,4);
   GetDblMatMem(ii3,4,3);
   GetDblMatMem(b,4,1);
   GetDblMatMem(x4,50,10);
   GetDblMatMem(d,50,5);
   GetDblMatMem(x5,50,11);
   GetDblMatMem(f2,5,10);
   x3 = new double[4];
   t = new double[4];
   p = new double[100];
   p1 = new double[4];
   p2 = new double[4];
   s = new double[4];
   t2 = new double[4];
   r = new double[50];
   a1 = new double[10];
   a2 = new double[10];
   r2 = new double[10];
   e = new double[10];
   GetDblMatMem(x,t1,4);
   ColNoSelected = new int[t1];
   rxy = new double[t1];

   // Get column numbers of variables selected
   for (i = 1; i <= n1; i++)
   {
        for (j = 1; j <= NoVariables; j++)
        {
             if (PreList->Items->Strings[i-1] == MainForm->Grid->Cells[j][0])
                  ColNoSelected[i-1] = j;
        }
   }
   for (i = 1; i <= n2; i++)
   {
        for (j = 1; j <= NoVariables; j++)
        {
             if (PostList->Items->Strings[i-1] == MainForm->Grid->Cells[j][0])
                  ColNoSelected[n1+i-1] = j;
        }
   }

   // read pre and post values - average for the cases
   for (j = 0; j < t1; j++) z[j] = 0.0;
   for (i = 1; i <= NoCases; i++)
   {
        if (! ValidRecord(i,ColNoSelected,t1))  continue;
        for (j = 0; j < t1; j++)
        {
             col = ColNoSelected[j];
             z[j] = z[j] + atof(MainForm->Grid->Cells[col][i].c_str());
             NoGoodCases = NoGoodCases + 1;
        }
   }
   for (j = 0; j < t1; j++) z[j] = z[j] / (double)NoGoodCases;

   // plot correlograms
   for (j3 = 1; j3 <= 4; j3++)
   {
        switch (j3)
        {
        case 1 : {
                 f1s = "Pre-Treatment Data";
                 n4 = n1;
                 l1 = 1;
                 l2 = n1;
                 FrmOutPut->RichOutPut->Lines->Add("Correlogram of Pre-Treatment Raw Data");
                 heading = "Correlogram of Pre-Treatment Raw Data";
                 i2 = 0;
                 for (i = l1; i <= l2; i++)
                 {
                      i2 = i2 + 1;
                      y[i2-1] = z[i-1];
                 }
            }
            break;
        case 2 : {
                 f1s = "Post-Treatment Data";
                 n4 = n2;
                 l1 = n1 + 1;
                 l2 = t1;
                 FrmOutPut->RichOutPut->Lines->Add("");
                 FrmOutPut->RichOutPut->Lines->Add("Correlogram of Post-Treatment Raw Data");
                 heading = "Correlogram of Post-Treatment Raw Data";
                 i2 = 0;
                 for (i = l1; i <= l2; i++)
                 {
                      i2 = i2 + 1;
                      y[i2-1] = z[i-1];
                 }
            }
            break;
        case 3 : {
                 f1s = "Pre-Treatment Data";
                 n4 = n1 - 1;
                 l1 = 1;
                 l2 = n1 - 1;
                 FrmOutPut->RichOutPut->Lines->Add("");
                 FrmOutPut->RichOutPut->Lines->Add("Correlogram of Pre-Treatment Differences");
                 heading = "Correlogram of Pre-Treatment Differences";
                 i2 = 0;
                 for (i = l1; i <= l2; i++)
                 {
                      i2 = i2 + 1;
                      i3 = i + 1;
                      y[i2-1] = z[i3-1] - z[i-1];
                 }
            }
            break;
        case 4 : {
                 f1s = "Post-Treatment Data";
                 n4 = n2-1;
                 l1 = n1 + 1;
                 l2 = t1 - 1;
                 FrmOutPut->RichOutPut->Lines->Add("");
                 FrmOutPut->RichOutPut->Lines->Add("Correlogram of Post-Treatment Differences");
                 heading = "Correlogram of Post-Treatment Differences";
                 i2 = 0;
                 for (i = l1; i <= l2; i++)
                 {
                      i2 = i2 + 1;
                      i3 = i + 1;
                      y[i2-1] = z[i3-1] - z[i-1];
                 }
            }
        }

        j2 = n4 * 3 / 4;
        for (k = 1; k <= j2; k++)
        {
             n5 = n4 - k;
             c = 0.0;
             t3 = 0.0;
             t4 = 0.0;
             t5 = 0.0;
             t6 = 0.0;
             for (i = 1; i <= n5; i++)
             {
                  n6 = i + k;
                  c = c + y[i-1] * y[n6-1];
                  t3 = t3 + y[i-1];
                  t4 = t4 + y[n6-1];
                  t5 = t5 + y[i-1] * y[i-1];
                  t6 = t6 + y[n6-1] * y[n6-1];
             }
             f4 = (double) n5;
             n7 = c - (t3 * t4) / f4;
             d7 = (t5 - (t3 * t3) / f4) * (t6 - (t4 * t4) / f4);
             if (d7 > 0.0)
             {
                  d7 = sqrt(d7);
                  r[k-1] = n7 / d7;
             }
             else r[k-1] = 1.0;
             sprintf(outline,"lag %3d  r = %4.2f",k,r[k-1]);
             pl = outline;
             FrmOutPut->RichOutPut->Lines->Add(pl);
        } // next k
        s4 = 1;
        n = 1;
        m = j2;
        for (i = 1; i <= j2; i++) x4[i-1][0] = r[i-1];
//        plotit(Self);
        if (ShowChk->Checked)
        {
             rxy[0] = 0.0;
             for (i = 1; i <= j2; i++) rxy[i] = r[i-1];
             AutoPlotFrm->PlotPartCors = false;
             AutoPlotFrm->PlotLimits = false;
             AutoPlotFrm->correlations = rxy;
             AutoPlotFrm->partcors = rxy;
             AutoPlotFrm->uplimit = 0.99;
             AutoPlotFrm->lowlimit = -0.99;
             AutoPlotFrm->npoints = j2+1;
             AutoPlotFrm->DepVarEdit = heading;
             AutoPlotFrm->ShowModal();
        }
   } // next j3
   FrmOutPut->ShowModal();
   FrmOutPut->RichOutPut->Clear();

   // Now the analysis
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("             residual             t for    change in  t for");
   FrmOutPut->RichOutPut->Lines->Add("    gamma    variance    level    level    level      change");
L300:
   y[0] = z[0];
   for (i = 1; i < t1; i++)
   {
        i1 = i - 1;
        y1 = fabs(y[i1]);
        if ((y1 - c9) <= 0.0)  y[i] = z[i] - z[i1];
        else if ((y1 - 0.000001) > 0.0)  y[i] = (z[i] - z[i1]) + (1.0 - g) * y[i1];
        g1 = fabs(1.0 - g);
        if ((g1 - 0.001) > 0)  y[i] = (z[i] - z[i1]) + (1.0 - g) * y[i1];
        else y[i] = z[i] - z[i1];
   }
   for (i = 0; i < t1; i++) x[i][0] = 1;
   for (i = 1; i <= n1; i++) x[i-1][1] = 0.0;
   for (i = n1 + 1; i <= t1; i++) x[i-1][1] = 1.0;
   x[0][2] = 1.0;
   x[1][2] = 1.0 - g;
   for (i = 2; i < t1; i++)
   {
        i1 = i - 1;
        x[i][2] = x[1][2] * x[i1][2];
        xx3 = fabs(x[i][2]);
        if ((c9 - xx3) <= 0.0)  continue;
        x[i][2] = 0.0;
   }
   for (i = 1; i <= n1; i++) x[i-1][3] = 0.0;
   for (i = n1; i < t1; i++)
   {
        i1 = i-n1;
        x[i][3] = x[i1][2];
        xx3 = fabs(x[i][3]);
        if ((c9 - xx3) <= 0.0)  continue;
        x[i][3] = 0.0;
   }
   for (i = 1; i <= 4; i++)
   {
        for (j = 1; j <= 4; j++)
        {
             x2[i-1][j-1] = 0.0;
             x1[i-1][j-1] = 0.0;
        }
   }

   for (i = 1; i <= 4; i++)
       for (j = 1; j <= 4; j++)
           for (k = 1; k <= t1; k++)
               x2[i-1][j-1] = x2[i-1][j-1] + x[k-1][i-1] * x[k-1][j-1];

   for (i = 1; i <= 4; i++)
       for (j = 1; j <= 4; j++)
           x1[i-1][j-1] = x2[i-1][j-1];

   for (i = 1; i <= 4; i++) x3[i-1] = 0.0;

   for (i = 1; i <= 4; i++)
       for (j = 1; j <= t1; j++)
           x3[i-1] = x3[i-1] + x[j-1][i-1] * y[j-1];

   for (i = 1; i <= 4; i++) b[i-1][0] = x3[i-1];

   matinverse(this);

   for (i = 1; i <= 4; i++) t[i-1] = b[i-1][0];
   for (i = 1; i <= 4; i++) s[i-1] = x1[i-1][i-1];
   f1 = (double) t1;
   y1 = 0.0;
   for (i = 0; i < t1; i++) y1 = y1 + y[i] * y[i];
   for (i = 1; i <= 4; i++) x3[i-1] = 0.0;
   for (j = 1; j <= 4; j++)
       for (i = 1; i <= 4; i++) x3[j-1] = x3[j-1] + t[i-1] * x2[i-1][j-1];
   f2x = 0.0;
   for (i = 1; i <= 4; i++)
   {
       f2x = f2x + x3[i-1] * t[i-1];
   }
   s1 = y1 - f2x;
   s1 = s1 / (f1 - 4.0);
   for (i = 1; i <= 4; i++)
   {
        s[i-1] = sqrt(s1 * s[i-1]);
        t2[i-1] = t[i-1] / s[i-1];
   }
   s3 = log(s1);
   det = log(det);
   h = (-0.5 * det) - (0.5 * (f1 - 4.0) * s3);
   h = 0.4342945 * h;
   j1 = j1 + 1;
   x5[j1-1][0] = g;
   x5[j1-1][1] = s1;
   x5[j1-1][2] = t[2];
   x5[j1-1][3] = t2[2];
   x5[j1-1][4] = t[3];
   x5[j1-1][5] = t2[3];
   x5[j1-1][6] = t[0];
   x5[j1-1][7] = t2[0];
   x5[j1-1][8] = t[1];
   x5[j1-1][9] = t2[1];
   if ((t1 - 30) >= 0)
   {
        d[j1-1][0] = t[3] - 2.58 * s[3];
        d[j1-1][1] = t[3] - 1.96 * s[3];
        d[j1-1][2] = t[3];
        d[j1-1][3] = t[3] + 1.96 * s[3];
        d[j1-1][4] = t[3] + 2.58 * s[3];
   }
   n3 = n3 + 1;
   p[n3-1] = h;
   g = g + 0.04;
   if ((n3 - 49) <= 0)  goto L300;
   f3 = p[0];
   for (i = 2; i <= 49; i++) if ((f3 - p[i-1]) < 0)  f3 = p[i-1];
   for (i = 1; i <= 49; i++)
   {
        p[i-1] = p[i-1] - f3;
        y2 = fabs(p[i-1]);
        if ((y2 - 35) >= 0)  p[i-1] = 0.0;
        else {
             p[i-1] = p[i-1] / 0.4342945;
             p[i-1] = exp(p[i-1]);
        }
   }
   a = 0.0;
   for (i = 2; i <= 49; i++)
   {
        i2 = i - 1;
        a = a + 0.005 * (p[i-1] + p[i1-1]);
   }
   for (i = 1; i <= 49; i++) p[i-1] = p[i-1] / a;
   for (i = 1; i <= 49; i++) x5[i-1][11-1] = p[i-1];
   for (i = 1; i <= 49; i++)
   {
        sprintf(outline,"%2d    ",i);
        pl = outline;
        for (j = 1; j <= 6; j++)
        {
             sprintf(outline,"%6.2f   ",x5[i-1][j-1]);
             pl = pl + outline;
        }
        FrmOutPut->RichOutPut->Lines->Add(pl);
   }

   FrmOutPut->ShowModal();
   FrmOutPut->RichOutPut->Clear();
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("");
   pl = "                    t for     change in   t for      scaled";
   FrmOutPut->RichOutPut->Lines->Add(pl);
   pl = "         slope      slope     slope       change     posterior";
   FrmOutPut->RichOutPut->Lines->Add(pl);
   for (i = 1; i <= 49; i++)
   {
        sprintf(outline,"%2d    ",i);
        pl = outline;
        for (j = 7; j <= 11; j++)
        {
            sprintf(outline,"%6.2f      ",x5[i-1][j-1]);
            pl = pl + outline;
        }
        FrmOutPut->RichOutPut->Lines->Add(pl);
   }

   FrmOutPut->ShowModal();
   FrmOutPut->RichOutPut->Clear();
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("");
   for (i = 1; i <= 49; i++)
   {
        x4[i-1][0] = x5[i-1][4];
        x4[i-1][1] = x5[i-1][8];
        x4[i-1][2] = x5[i-1][10];
   }
   m = 49;
   n = 3;
   i3 = 1;
   f1s = g1s + g2s + g3s;
   PlotFuncs(this);
   plotit(this); // plot the f[i,j] values
   FrmOutPut->ShowModal();
   FrmOutPut->RichOutPut->Clear();
   n = 5;
   if ((t1 - 30) >= 0)
   { // confidence intervals around delta
         for (i = 1; i <= 49; i++)
             for (j = 1; j <= 5; j++)
                 x4[i-1][j-1] = d[i-1][j-1];
         f1s = g4s + g5s + g6s + g7s + g8s;
         pl = "Confidence Intervals Around Delta";
         FrmOutPut->RichOutPut->Lines->Add(pl);
         pl = "gamma          lower 99      lower 95      delta       upper 95      upper 99";
         FrmOutPut->RichOutPut->Lines->Add(pl);
         for (i = 1; i <= 49; i++)
         {
              sprintf(outline,"%6.2f        ",x5[i-1][0]);
              pl = outline;
              for (j = 1; j <= 5; j++)
              {
                  sprintf(outline,"%6.2f        ",d[i-1][j-1]);
                  pl = pl + outline;
              }
              FrmOutPut->RichOutPut->Lines->Add(pl);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
         pl = "Graph of Confidence Intervals Around Delta Hat";
         FrmOutPut->RichOutPut->Lines->Add(pl);
         plotit(this); // plot f matrix
   }

   FrmOutPut->ShowModal();

   // clean up
   delete[] rxy;
   delete[] ColNoSelected;
   ClearDblMatMem(x,t1);
   delete[] e;
   delete[] r2;
   delete[] a2;
   delete[] a1;
   delete[] r;
   delete[] t2;
   delete[] s;
   delete[] p2;
   delete[] p1;
   delete[] p;
   delete[] t;
   delete[] x3;
   ClearDblMatMem(f2,5);
   ClearDblMatMem(x5,50);
   ClearDblMatMem(d,50);
   ClearDblMatMem(x4,50);
   ClearDblMatMem(b,4);
   ClearDblMatMem(ii3,4);
   ClearDblMatMem(x2,4);
   ClearDblMatMem(x1,4);
   delete[] y;
   delete[] z;
}
//---------------------------------------------------------------------------

void __fastcall TInterruptedForm::plotit(TObject *Sender)
{
    int i, i2, ip, j, k, L, n8;
    char bstr[81], p1str[81], p2str[81];
    double c5, z2;
    char outline[121];
    char prtline[121];

    for (i = 1; i <= n; i++)
    {
        a1[i-1] = 1E+37;
        a2[i-1] = -1E+37;
    }
    strcpy(bstr,"153510cmha");
    for (i = 1; i <= m; i++)
    {
        for (j = 1; j <= n; j++)
        {
            c5 = x4[i-1][j-1] - a1[j-1];
            if (c5 >= 0)  goto L2180;
            a1[j-1] = x4[i-1][j-1];
L2180:      c5 = x4[i-1][j-1] - a2[j-1];
            if (c5 <= 0)  continue;
            a2[j-1] = x4[i-1][j-1];
        }
    }
    if ((n - 5) == 0)
    {
        for (j = 1; j <= 5; j++)
        {
            a2[j-1] = a2[4];
            a1[j-1] = a1[0];
        }
    }
    n8 = n;
    for (j = 1; j <= n; j++) r2[j-1] = (a2[j-1] - a1[j-1]) / 55.0;
    for (j = 1; j <= n; j++)
    {
        e[j-1] = (a2[j-1] - a1[j-1]) / 4.0;
        f2[0][j-1] = a1[j-1] + 0.05;
        c5 = a1[j-1];
        if (c5 < 0) f2[0][j-1] = f2[0][j-1] - 0.1;
        f2[4][j-1] = a2[j-1] - 0.05;
        c5 = a2[j-1];
        if (c5 < 0)  f2[4][j-1] = f2[4][j-1] - 0.1;
        f2[1][j-1] = a1[j-1] + e[j-1] + 0.05;
        c5 = f2[1][j-1];
        if (c5 < 0) f2[1][j-1] = f2[1][j-1] - 0.1;
        f2[2][j-1] = a1[j-1] + e[j-1] * 2 + 0.05;
        c5 = f2[2][j-1];
        if (c5 < 0) f2[2][j-1] = f2[2][j-1] - 0.1;
        f2[3][j-1] = a2[j-1] - e[j-1] + 0.05;
        c5 = f2[3][j-1];
        if (c5 < 0)  f2[3][j-1] = f2[3][j-1] - 0.1;
    }

    strcpy(prtline,"");
    for (j = 1; j <= n8; j++)
    {
//        pl = bstr[j] + " ";
        prtline[0] = bstr[j];
        prtline[1] = 0;
        for (i = 1; i <= 5; i++)
        {
            sprintf(outline,"%6.2f        ",f2[i-1][j-1]);
//            pl = pl + outline;
            strcat(prtline,outline);
        }
//        pl = pl + bstr[j];
//        strcat(prtline,bstr[j]);
//        pl = pl + copy(bstr, j, 1);
        FrmOutPut->RichOutPut->Lines->Add(prtline);
    }
//    pl = "";
    strcpy(prtline,"");
    FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");

    for (i2 = 1; i2 <= 73; i2++)
    {
        strcpy(p2str," ");
        strcpy(p1str," ");
//         p2str = p2str + " ";
//         p1str = p1str + " ";
    }
    for (i = 1; i <= m; i++)
    {
        for (i2 = 1; i2 <= 72; i2++) p1str[i2] = ' ';
        p1str[73] = 0;
        k = 0;
        p1str[1] = '.';
        for (i2 = 1; i2 <= 5; i2++)
        {
            k = k + 14;
            p1str[k] = '.';
        }
        n7 = i;
        while (n7 >= 0)
        {
            n7 = n7 - 10;
        }
        if (n7 >= 0)
        {
            k = 3;
            p1str[k] = '-';
            for (i2 = 3; i2 <= 30; i2++)
            {
                k = k + 2;
                p1str[k] = '-';
            }
        }
        for (k = 1; k <= n; k++)
        {
            if (r2[k-1] > 0) z2 = (x4[i-1][k-1] - a1[k-1]) / r2[k-1] + 1;
            else z2 = 0;
            L = ceil(z2);
            if ((L - 1) < 0)  L = 1;
            if ((55 - L) < 0)  L = 55;
            if ((p1str[L] == ' ') || (p1str[L] == '.') || (p1str[L] == '-'))
            {
                p2str[k] = bstr[k];
                p1str[L] = p2str[k];
            }
            else p1str[L] = '+';
        }
        if ((s4 - 1) == 0)  goto L2660;
        FrmOutPut->RichOutPut->Lines->Add("");
L2660:
        sprintf(outline,"%2d.          ",i);
        pl = outline;
        for (ip = 1; ip <= 55; ip++) pl = pl + p1str[ip];
        sprintf(outline,".  %2d",i);
        pl = pl + outline;
        FrmOutPut->RichOutPut->Lines->Add(pl);
    }
    FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("");
    for (j = 1; j <= n8; j++)
    {
        pl = bstr[j];
        pl = pl + " ";
        strcpy(prtline,"");
        strcpy(prtline,pl.c_str());
        for (i = 1; i <= 5; i++)
        {
            sprintf(outline,"%6.2f        ",f2[i-1][j-1]);
            strcat(prtline,outline);
        }
        pl = "";
        pl = pl + bstr[j];
        strcat(prtline,pl.c_str());
        FrmOutPut->RichOutPut->Lines->Add(prtline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("          Plot Description");
    FrmOutPut->RichOutPut->Lines->Add("title               character           minimum        maximum    resolution");

    for (j = 1; j <= n; j++)
    {
        switch (j)
        {
               case 1: pl = g4s; break;
               case 2: pl = g5s; break;
               case 3: pl = g6s; break;
               case 4: pl = g7s; break;
               case 5: pl = g8s; break;
        }
        pl = pl + "     " + bstr[j];
        sprintf(outline,"%6.2f",a1[j-1]);
        pl = pl + "               " + outline;
        sprintf(outline,"%6.2f",a2[j-1]);
        pl = pl + "     " + outline;
        sprintf(outline,"%6.2f",r2[j-1]);
        pl = pl + "     " + outline;
        FrmOutPut->RichOutPut->Lines->Add(pl);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
}
//-------------------------------------------------------------------

void __fastcall TInterruptedForm::PlotFuncs(TObject *Sender)
{
    int i, j;
    AnsiString title;
    double gamma;

    // Allocate space for point sets of means
    GetDblMatMem(GraphForm->Ypoints,3,50);
    GetDblMatMem(GraphForm->Xpoints,3,50);
    // store points for means
    gamma = 0.0;
    for (i = 1; i <= 49; i++)
    {
         for (j = 1; j <= 3; j++)
         {
              GraphForm->Ypoints[j-1][i-1] = x4[i-1][j-1];
              GraphForm->Xpoints[j-1][i-1] = gamma;
         }
         gamma = gamma + 0.04;
    }
    title = "Plot of ts for change in level and slope and posterior";
    GraphForm->nosets = 3;
    GraphForm->nbars = 49;
    GraphForm->Heading = title;
    GraphForm->SetLabels[1] = "level";
    GraphForm->SetLabels[2] = "slope";
    GraphForm->SetLabels[3] = "posterior";
    GraphForm->XTitle = "Gamma Increment";
    GraphForm->YTitle = "t";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = true;
    GraphForm->GraphType = 6; // 2d line chart
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();

    ClearDblMatMem(GraphForm->Xpoints,3);
    ClearDblMatMem(GraphForm->Ypoints,3);
}
//-------------------------------------------------------------------

void __fastcall TInterruptedForm::matinverse(TObject *Sender)
{
    int i, j, j2, j4, k, L, L1;
    double t2;

    //Matrix inverse and determinant

    det = 1;
    m1 = 1;
    n = 4;
    for (i = 1; i <= 4; i++)
    {
        p1[i-1] = 0.0;
        for (j = 1; j <= 2; j++) ii3[i-1][j-1] = 0.0;
    }
    for (i = 1; i <= n; i++)
    {
        amax = 0.0;
        for (j = 1; j <= n; j++)
        {
            if ((p1[j-1] - 1) != 0)
            {
                for (k = 1; k <= n; k++)
                {
                    if ((p1[k-1] - 1) != 0)
                    {
                        if ((p1[k-1] - 1) > 0) return;
                        if (fabs(amax) - fabs(x1[j-1][k-1]) <= 0)
                        {
                            R1 = j;
                            i1 = k;
                            amax = x1[j-1][k-1];
                        }
                    }
                }
            }
        }
        p1[i1-1] = p1[i1-1] + 1;
        if ((R1 - i1) != 0) //Swap
        {
            det = -det;
            for (L = 1; L <= n; L++)
            {
                s4 = x1[R1-1][ L-1];
                x1[R1-1][L-1] = x1[i1-1][L-1];
                x1[i1-1][L-1] = s4;
            }
            if (m1 > 0) //Swap
            {
                for (L = 1; L <= m1; L++)
                {
                    s4 = b[R1-1][L-1];
                    b[R1-1][L-1] = b[i1-1][L-1];
                    b[i1-1][L-1] = s4;
                }
            }
        }
        ii3[i-1][0] = R1;
        ii3[i-1][1] = i1;
        p2[i-1] = x1[i1-1][i1-1];
        det = det * p2[i-1];
        if (p2[i-1] == 0)
        {
            ShowMessage("A singular matrix was found.");
            return;
        }
        x1[i1-1][i1-1] = 1;
        for (L = 1; L <= n; L++)
        {
            x1[i1-1][L-1] = x1[i1-1][L-1] / p2[i-1];
        }
        if (m1 > 0)
        {
            for (L = 1; L <= m1; L++)
            {
                b[i1-1][L-1] = b[i1-1][L-1] / p2[i-1];
            }
        }
        for (L1 = 1; L1 <= n; L1++)
        {
            if ((L1 - i1) != 0)
            {
                t2 = x1[L1-1][i1-1];
                x1[L1-1][i1-1] = 0.0;
                for (L = 1; L <= n; L++)
                {
                    x1[L1-1][L-1] = x1[L1-1][L-1] - x1[i1-1][L-1] * t2;
                }
                if (m1 > 0)
                {
                    for (L = 1; L <= m1; L++)
                        b[L1-1][L-1] = b[L1-1][L-1] - b[i1-1][L-1] * t2;
                }
            }
        }
    }
    for (i = 1; i <= n; i++)
    {
        L = n + 1 - i;
        if ((ii3[L-1][0] - ii3[L-1][1]) != 0)
        {
            j2 = ceil(ii3[L-1][0]);
            j4 = ceil(ii3[L-1][1]);
            for (k = 1; k <= n; k++)
            {
                s4 = x1[k-1][j2-1];
                x1[k-1][j2-1] = x1[k-1][j4-1];
                x1[k-1][j4-1] = s4;
            }
        }
    }
}
//--------------------------------------------------------------------


