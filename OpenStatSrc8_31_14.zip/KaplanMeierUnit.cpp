//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "stdio.h"
#include "functions.h"
//#include "GraphUnit.h"
#include "OutPut.h"
#include "MemMgrUnit.h"
#include "math.hpp"
#include "math.h"
#include "limits.h"
#include "PlotUnit.h"
#include "DataFuncs.h"
#include "KaplanMeierUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKaplanMeierForm *KaplanMeierForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TKaplanMeierForm::TKaplanMeierForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKaplanMeierForm::ResetBtnClick(TObject *Sender)
{
     TimeEdit->Text = "";
     EndpointEdit->Text = "";
     GroupEdit->Text = "";
     SurvivalChk->Checked = true;
     PrintChk->Checked = true;
     TimeOutBtn->Visible = false;
     EventOutBtn->Visible = false;
     GroupOutBtn->Visible = false;
     TimeInBtn->Visible = true;
     EventInBtn->Visible = true;
     GroupInBtn->Visible = true;
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::ComputeBtnClick(TObject *Sender)
{
     char outline[101];
     bool PrintIt = false;
     int Size1, Size2, TotalSize, NoDeaths, ThisTime, FoundIn, GraphType;
     int mintime, maxtime, tempint, nopoints, noprobs, tempvalue, NoCensored;
     AnsiString astring;
     double minprob, maxprob;
     double E1, E2, O1, O2, Chisquare, ProbChi, Risk, LogRisk, SELogRisk;
     double HiConf;
     double LowConf;
     double HiLogLevel;
     double LowLogLevel;
     int *TimePlot;
     double *ProbPlot;
     double *ProbPlot2;
     int *Dropped;
     int *Dropped2;
     int *Time;
     int *AtRisk;
     int *Dead;
     double *CondProb;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     int nocats = 0;

     // get options
     if (SurvivalChk->Checked == true) Graph1 = true;
     else Graph1 = false;
     if (PrintChk->Checked) PrintIt = true;

     // get variable columns and labels
     TimeLabel = TimeEdit->Text;
     GroupLabel = GroupEdit->Text;
     DeathsLabel = EndpointEdit->Text;
     TimeCol = 0;
     DeathsCol = 0;
     CensoredCol = 0;
     GroupCol = 0;
     for (int i = 1; i <= NoVariables; i++)
     {
         if (TimeLabel == MainForm->Grid->Cells[i][0]) TimeCol = i;
         if (DeathsLabel == MainForm->Grid->Cells[i][0]) DeathsCol = i;
         if (GroupLabel == MainForm->Grid->Cells[i][0]) GroupCol = i;
     }
     if ((TimeCol == 0) || (DeathsCol == 0))
     {
         ShowMessage("ERROR!  One or more variables not selected.");
         return;
     }
     //result = VarTypeChk(TimeCol,1);
     //if (result == 1) return;
     //result = VarTypeChk(DeathsCol,1);
     //if (result == 1) return;
     if (GroupEdit->Text == "")
     {
        TwoGroups = false;
        Size1 = NoCases;
        Size2 = 0;
     }
     else
     {
         //result = VarTypeChk(GroupCol,1);
         //if (result == 1) return;
         Size1 = 0;
         Size2 = 0;
         TwoGroups = true;
         for (int i = 1; i <= NoCases; i++)
         {
             if (floor(StrToFloat(MainForm->Grid->Cells[GroupCol][i])) == 1) Size1++;
             else Size2++;
             //result = GetValue(i,GroupCol,intvalue,dblvalue,strvalue);
             //if (intvalue == 1) Size1++;
             //else Size2++;
         }
     }

     // allocate space for the data
    SurvivalTimes = new int[NoCases+2];
    ExpCnt = new int[NoCases+2];
    CntrlCnt = new int[NoCases+2];
    TotalatRisk = new int[NoCases+2];
    ExpatRisk = new double[NoCases+2];
    CntrlatRisk = new double[NoCases+2];
    ExpProp = new double[NoCases+2];
    CntrlProp = new double[NoCases+2];
    Deaths = new int[NoCases+2];
    Group = new int[NoCases+2];
    Censored = new int[NoCases+2];
    CumPropExp = new double[NoCases+2];
    CumPropCntrl = new double[NoCases+2];

    // initialize arrays
    for (int i = 0; i < NoCases+1; i++)
    {
        SurvivalTimes[i] = 0;
        ExpCnt[i] = 0;
        CntrlCnt[i] = 0;
        TotalatRisk[i] = 0;
        ExpatRisk[i] = 0;
        CntrlatRisk[i] = 0;
        ExpProp[i] = 0.0;
        CntrlProp[i] = 0.0;
        Deaths[i] = 0;
        Group[i] = 0;
        Censored[i] = 0;
        CumPropExp[i] = 0.0;
        CumPropCntrl[i] = 0.0;
    }
    mintime = 0;
    maxtime = 0;

    // Get Data
    if (!TwoGroups)
    {
       for (int i = 1; i <= NoCases; i++)
       {
           SurvivalTimes[i] = floor(StrToFloat(MainForm->Grid->Cells[TimeCol][i]));
           //result = GetValue(i,TimeCol,intvalue,dblvalue,strvalue);
           //if (result == 1) SurvivalTimes[i] = 0;
           //else SurvivalTimes[i] = intvalue;
           if (SurvivalTimes[i] > maxtime) maxtime = SurvivalTimes[i];
           tempvalue = floor(StrToFloat(MainForm->Grid->Cells[DeathsCol][i]));
           //result = GetValue(i,DeathsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) tempvalue = 0;
           //else tempvalue = intvalue;
           if (tempvalue == 1) Deaths[i] = 1;
           else Deaths[i] = 0;
           if (tempvalue == 2) Censored[i] = 1;
           else Censored[i] = 0;
       }

       // sort cases by time
       for (int i = 0; i < NoCases; i++)
       {
           for (int j = i + 1; j <= NoCases; j++)
           {
                if (SurvivalTimes[i] > SurvivalTimes[j])
                {
                    tempint = SurvivalTimes[i];
                    SurvivalTimes[i] = SurvivalTimes[j];
                    SurvivalTimes[j] = tempint;
                    tempint = Censored[i];
                    Censored[i] = Censored[j];
                    Censored[j] = tempint;
                    tempint = Deaths[i];
                    Deaths[i] = Deaths[j];
                    Deaths[j] = tempint;
                }
           }
       }

       // get number censored in each time slot
       nopoints = maxtime + 1;
       Dropped = new int[nopoints+2];
       Dropped2 = new int[nopoints+2];
       for (int j = 0; j <= nopoints; j++)
       {
            Dropped[j] = 0;
            Dropped2[j] = 0;
       }
       ThisTime = SurvivalTimes[0];
       for (int i = 0; i <= NoCases; i++)
       {
           if (ThisTime == SurvivalTimes[i])
           {
                if(Censored[i] > 0)
                {
                     tempint = SurvivalTimes[i] - mintime;
                     Dropped[tempint] += Censored[i];
                }
           }
           else // new time
           {
                ThisTime = SurvivalTimes[i];
                if(Censored[i] > 0)
                {
                     tempint = SurvivalTimes[i] - mintime;
                     Dropped[tempint] += Censored[i];
                }
           }
       }

       // calculate expected proportions and adjust survival counts
       double cumprop = 1.0;
       ExpCnt[0] = NoCases;
       ExpProp[0] = 1.0;
       CumPropExp[0] = 1.0;

       // collapse deaths and censored into first time occurance
       int icase = 0;
       int oldtime = SurvivalTimes[0];
       for (int i = 1; i <= NoCases; i++)
       {
           if (SurvivalTimes[i] != oldtime)
           {
                oldtime = SurvivalTimes[i];
                icase = i;
           }

           // find no. of deaths at this time
           NoDeaths = Deaths[i];
           for (int j = i+1; j <= NoCases; j++)
           {
                  ThisTime = SurvivalTimes[j];
                  if ((Deaths[j] > 0) && (oldtime == ThisTime))
                  {
                     NoDeaths = NoDeaths + Deaths[j];
                     Deaths[icase] = Deaths[icase] + Deaths[j];
                     Deaths[j] = 0;
                  }
           }
           // find no. of censored at this time
           NoCensored = Censored[i];
           for (int j = i+1; j <= NoCases; j++)
           {
                  ThisTime = SurvivalTimes[j];
                  if((Censored[j] > 0) && (oldtime == ThisTime))
                  {
                     NoCensored = NoCensored + Censored[j];
                     Censored[icase] = Censored[icase] + Censored[j];
                     Censored[j] = 0;
                  }
           }
       }
/*
       // debug check
       FrmOutPut->RichOutPut->Clear();
       for (int i = 0; i <= NoCases; i++)
       {
            sprintf(outline,"case %d  Day %d  Deaths %d  Censored  %d",
               i,SurvivalTimes[i], Deaths[i],Censored[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->ShowModal();
*/
       // get no. of categories
       for (int i = 0; i <= NoCases; i++)
                if ((Deaths[i] > 0) || (Censored[i] > 0)) nocats++;
       double *CondProb;
       Time = new int[nocats+2];
       AtRisk = new int[nocats+2];
       Dead = new int[nocats+2];
       CondProb = new double[nocats+2];
       for (int i = 0; i <= nocats; i++)
       {
                Time[i] = 0;
                AtRisk[i] = 0;
                Dead[i] = 0;
                CondProb[i] = 0.0;
       }
       int position = 0;
       for (int i = 0; i <= NoCases; i++)
       {
                if ((Deaths[i] > 0) || (Censored[i] > 0))
                {
                        position++;
                        Time[position] = SurvivalTimes[i];
                        Dead[position] = Deaths[i];
                        Dropped[position] = Censored[i];
                }
       }
       Time[0] = 0;
       AtRisk[0] = NoCases;
       Dead[0] = 0;
       Dropped[0] = 0;
       CondProb[0] = 0.0;
       FrmOutPut->RichOutPut->Clear();
       sprintf(outline,"   Time  Censored    Dead   At Risk  Probability");
       FrmOutPut->RichOutPut->Lines->Add(outline);
       for (int i = 1; i <= nocats; i++)
       {
                AtRisk[i] = AtRisk[i-1] - Dead[i-1] - Dropped[i-1];
                CondProb[i-1] = 1.0 - double(Dead[i-1]) / double(AtRisk[i-1]);
       }
       for (int i =0; i <= nocats; i++)
       {
                sprintf(outline," %3d        %3d      %3d      %3d     %6.3f",
                     Time[i],Dropped[i],Dead[i],AtRisk[i],CondProb[i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->ShowModal();

       // Get cumulative proportions
       for (int i = 0; i <= nocats; i++)
       {
           if (AtRisk[i] > 0)
           {
              CumPropExp[i] = cumprop * CondProb[i];
              cumprop = CumPropExp[i];
           }
       }
       cumprop = 1.0;
       if (Graph1) // plot Y = cumulative proportion surviving, x = time
       {
             // Get points to plot
             nopoints = maxtime + 1;
             TimePlot = new int[nocats+2];
             ProbPlot = new double[nocats+2];
             ProbPlot[0] = 1.0;
             for (int j=0; j <= nocats; j++)
             {
                TimePlot[j] = Time[j];
                ProbPlot[j] = CumPropExp[j];
             }
             plotxy(TimePlot, ProbPlot, Dropped, Dropped2,
                    maxtime,0,1.0, 0.0, nocats,"TIME","PROBABILITY",1);
             PlotForm->ShowModal();
       } // end if graph1
       delete[] ProbPlot;
       delete[] TimePlot;
       FrmOutPut->RichOutPut->Clear();
       FrmOutPut->RichOutPut->Lines->Add("Kaplan-Meier Survival Test");
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("No Control Group Method");
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("TIME  NO.ALIVE  CENSORED DEATHS  COND. PROB.  CUM.PROP.SURVIVING");
       for (int i = 0; i <= nocats; i++)
       {
           sprintf(outline," %4d %4d     %4d     %4d   %7.4f        %7.4f",
               Time[i],
               AtRisk[i],Dropped[i],Deaths[i],CondProb[i],CumPropExp[i]);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->ShowModal();
    delete[] CondProb;
    delete[] Dead;
    delete[] AtRisk;
    delete[] Time;

    } // end if not two groups
//============================================================================//
    else  // Experimental and control groups
    {
       // obtain no. in experimental and control groups
       ExpCnt[0] = Size1;
       CntrlCnt[0] = Size2;
       TotalSize = Size1 + Size2;
       CumPropExp[0] = 1.0;
       CumPropCntrl[0] = 1.0;
       TotalatRisk[0] = TotalSize;
       O1 = 0;
       O2 = 0;
       sprintf(outline,"Total Group 1 = %d, Total Group 2 = %d, Grand Total = %d",
           ExpCnt[0], CntrlCnt[0], TotalSize);
       astring = outline;
       ShowMessage(astring);

       // Now read values.  Note storage starts in 1, not 0!
       for (int i = 1; i <= NoCases; i++)
       {
           SurvivalTimes[i] = floor(StrToFloat(MainForm->Grid->Cells[TimeCol][i]));
           //result = GetValue(i,TimeCol,intvalue,dblvalue,strvalue);
           //if (result == 1) SurvivalTimes[i] = 0;
           //else SurvivalTimes[i] = intvalue;
           if (SurvivalTimes[i] > maxtime) maxtime = SurvivalTimes[i];
           tempvalue = floor(StrToFloat(MainForm->Grid->Cells[DeathsCol][i]));
           //result = GetValue(i,DeathsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) tempvalue = 0;
           //else tempvalue = intvalue;
           if (tempvalue == 1) Deaths[i] = 1;
           else Deaths[i] = 0;
           if (tempvalue == 2) Censored[i] = 1;
           else Censored[i] = 0;
           Group[i] = floor(StrToFloat(MainForm->Grid->Cells[GroupCol][i]));
           //result = GetValue(i,GroupCol,intvalue,dblvalue,strvalue);
           //if (result == 1) Group[i] = 0;
           //else Group[i] = intvalue;
       }

       // sort cases by time
       for (int i = 1; i < NoCases; i++)
       {
           for (int j = i + 1; j <= NoCases; j++)
           {
                if (SurvivalTimes[i] > SurvivalTimes[j])
                {
                    tempint = SurvivalTimes[i];
                    SurvivalTimes[i] = SurvivalTimes[j];
                    SurvivalTimes[j] = tempint;
                    tempint = Censored[i];
                    Censored[i] = Censored[j];
                    Censored[j] = tempint;
                    tempint = Deaths[i];
                    Deaths[i] = Deaths[j];
                    Deaths[j] = tempint;
                    tempint = Group[i];
                    Group[i] = Group[j];
                    Group[j] = tempint;
                }
           }
       }

       // sort cases within each time slot by deaths first then censored
       ThisTime = SurvivalTimes[1];
       int first = 1;
       int last = 1;
       for (int i = 1; i <= NoCases; i++)
       {
           if (ThisTime == SurvivalTimes[i])
           {
                last = i;
                continue;
           }
           else // sort the cases from first to last on event (descending)
           {
                if (last > first) // more than 1 to sort
                {
                   for (int j = first; j < last; j++)
                   {
                      for (int k = j + 1; k <= last; k++)
                      {
                        if (Deaths[j] < Deaths[k] ) // swap
                        {
                                tempint = Censored[j];
                                Censored[j] = Censored[k];
                                Censored[k] = tempint;
                                tempint = Deaths[j];
                                Deaths[j] = Deaths[k];
                                Deaths[k] = tempint;
                                tempint = Group[j];
                                Group[j] = Group[k];
                                Group[k] = tempint;
                        }
                      } // next k
                   } // next j
                } // if last > first
           } // end else sort
           first = last + 1;
           ThisTime = SurvivalTimes[first];
           last = first;
       } // next i

       // get number censored in each time slot
       nopoints = maxtime + 1;
       Dropped = new int[nopoints+2];
       Dropped2 = new int[nopoints+2];
       for (int j = 0; j <= nopoints; j++)
       {
            Dropped[j] = 0;
            Dropped2[j] = 0;
       }
       ThisTime = SurvivalTimes[1];
       for (int i = 1; i <= NoCases; i++)
       {
           if (ThisTime == SurvivalTimes[i])
           {
                if(Censored[i] > 0)
                {
                     tempint = SurvivalTimes[i] - mintime;
                     if (Group[i] == 1) Dropped[tempint] += Censored[i];
                     else Dropped2[tempint] += Censored[i];
                }
           }
           else // new time
           {
                ThisTime = SurvivalTimes[i];
                if(Censored[i] > 0)
                {
                     tempint = SurvivalTimes[i] - mintime;
                     if (Group[i] == 1) Dropped[tempint] += Censored[i];
                     else Dropped2[tempint] += Censored[i];
                }
           }
       }

       for (int i = 0; i <= NoCases; i++)
       {
           int noinexp = 0;
           int noincntrl = 0;
           if (Deaths[i] > 0)
           {
              // find no. of deaths at this time
              NoDeaths = Deaths[i];
              ThisTime = SurvivalTimes[i];
              for (int j = i+1; j <= NoCases; j++)
              {
                  if ((Deaths[j] > 0) && (SurvivalTimes[j] == ThisTime))
                  {
                     NoDeaths = NoDeaths + Deaths[j];
                     Deaths[i] = Deaths[i] + Deaths[j];
                     Deaths[j] = 0;
                  }
              }
              if (TotalatRisk[i] > 0)
              {
                 ExpatRisk[i] = ((double)ExpCnt[i] / (double) TotalatRisk[i]) * (double) NoDeaths;
                 CntrlatRisk[i] = ((double)CntrlCnt[i] / (double)TotalatRisk[i]) * (double) NoDeaths;
              }
              if (i < NoCases-1) TotalatRisk[i+1] = TotalatRisk[i] - Deaths[i];
              // find no. in exp. or control groups and decrement their counts
              for (int j = 1; j <= NoCases; j++)
              {
                  if ( (ThisTime == SurvivalTimes[j]) && (Censored[j] == 0) )
                  {
                     if (Group[j] == 1)
                     {
                        noinexp++;
                        O1++;
                     }
                     if (Group[j] == 2)
                     {
                        noincntrl++;
                        O2++;
                     }
                  }
              }
              if ( (i < NoCases) && (noinexp > 0) )
              {
                 ExpProp[i] = ((double)ExpCnt[i] - (double)noinexp) / (double)ExpCnt[i];
                 if (i > 0) CumPropExp[i] = CumPropExp[i-1] * ExpProp[i];
                 ExpCnt[i+1] = ExpCnt[i] - noinexp;
                 CumPropExp[i+1] = CumPropExp[i];
              }
              if ( (i < NoCases) && (noinexp == 0) )
              {
                  ExpCnt[i+1] = ExpCnt[i];
                  CumPropExp[i+1] = CumPropExp[i];
              }
              if ( (i < NoCases) && (noincntrl > 0) )
              {
                 CntrlProp[i] = ((double)CntrlCnt[i] - (double)noincntrl) / (double)CntrlCnt[i];
                 if (i > 0) CumPropCntrl[i] = CumPropCntrl[i-1] * CntrlProp[i];
                 CntrlCnt[i+1] = CntrlCnt[i] - noincntrl;
                 CumPropCntrl[i+1] = CumPropCntrl[i];
              }
              if ( (i < NoCases) && (noincntrl == 0) )
              {
                  CntrlCnt[i+1] = CntrlCnt[i];
                  CumPropCntrl[i+1] = CumPropCntrl[i];
              }
           }  // end if deaths[i] > 0

           if ( (Censored[i] > 0) && (i < NoCases) )
           {
              if (Group[i] == 1)
              {
                 ExpCnt[i+1] = ExpCnt[i] - 1;
                 CntrlCnt[i+1] = CntrlCnt[i];
                 ExpProp[i+1] = ExpProp[i];
                 CumPropExp[i+1] = CumPropExp[i];
                 CumPropCntrl[i+1] = CumPropCntrl[i];
              }
              if (Group[i] == 2)
              {
                 CntrlCnt[i+1] = CntrlCnt[i] - 1;
                 ExpCnt[i+1] = ExpCnt[i];
                 CntrlProp[i+1] = CntrlProp[i];
                 CumPropCntrl[i+1] = CumPropCntrl[i];
                 CumPropExp[i+1] = CumPropExp[i];
              }
              TotalatRisk[i+1] = TotalatRisk[i] - 1;
           }
           if ( (Deaths[i] == 0) && (Censored[i] == 0) && (i < NoCases) )
           {
               ExpCnt[i+1] = ExpCnt[i];
               CntrlCnt[i+1] = CntrlCnt[i];
               CumPropExp[i+1] = CumPropExp[i];
               CumPropCntrl[i+1] = CumPropCntrl[i];
               TotalatRisk[i+1] = TotalatRisk[i];
           }
       } // next case i

       // Now calculate chisquare, relative risk (r), logr, and S.E. of log risk
       E1 = 0.0;
       for (int i = 0; i <= NoCases; i++) E1 = E1 + ExpatRisk[i];
       E2 = (O1 + O2) - E1;
       Chisquare = ((O1 - E1) * (O1 - E1)) / E1 + ((O2 - E2) * (O2 - E2)) / E2;
       ProbChi = chisquaredprob(Chisquare,1);
       Risk = (O1 / E1) / (O2 / E2);
       LogRisk = log(Risk);
       SELogRisk = sqrt(1.0/E1 + 1.0/E2);
       HiConf = LogRisk + (inversez(0.975) * SELogRisk);
       LowConf = LogRisk - (inversez(0.975) * SELogRisk);
       HiLogLevel = exp(HiConf);
       LowLogLevel = exp(LowConf);
    }

    // Print Results
    if (TwoGroups && PrintIt) // both experimental and control groups
    {
       FrmOutPut->RichOutPut->Clear();
       FrmOutPut->RichOutPut->Lines->Add("Kaplan-Meier Survival Test");
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("Comparison of Two Groups Methd");
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("TIME GROUP CENSORED  TOTAL AT  EVENTS  AT RISK IN  EXPECTED NO.  AT RISK IN  EXPECTED NO.");
       FrmOutPut->RichOutPut->Lines->Add("                     RISK              GROUP 1     EVENTS IN 1     GROUP 2   EVENTS IN 2");
       for (int i = 1; i <= NoCases+1; i++)
       {
           sprintf(outline,"%4d %4d     %4d     %4d     %4d      %4d      %7.4f        %4d        %7.4f",
               SurvivalTimes[i-1],Group[i-1],Censored[i-1],TotalatRisk[i-1],
               Deaths[i-1],ExpCnt[i-1],ExpatRisk[i-1],CntrlCnt[i-1],CntrlatRisk[i-1]);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }

       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("TIME  DEATHS  GROUP  AT RISK  PROPORTION  CUMULATIVE");
       FrmOutPut->RichOutPut->Lines->Add("                              SURVIVING   PROP.SURVIVING");
       int count;
       double proportion, cumprop;
       for (int i = 1; i <= NoCases; i++)
       {
           if (Group[i] == 1)
           {
              count = ExpCnt[i];
              proportion = ExpProp[i];
              cumprop = CumPropExp[i];
           }
           else
           {
              count = CntrlCnt[i];
              proportion = CntrlProp[i];
              cumprop = CumPropCntrl[i];
           }
           sprintf(outline,"%4d   %4d   %4d     %4d     %7.4f       %7.4f",
              SurvivalTimes[i],Deaths[i],Group[i],count,proportion,cumprop);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->RichOutPut->Lines->Add("");
       sprintf(outline,"Total Expected Events for Experimental Group = %8.3f",E1);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"Observed Events for Experimental Group = %8.3f",O1);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"Total Expected Events for Control Group = %8.3f",E2);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"Observed Events for Control Group = %8.3f",O2);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"Chisquare = %8.3f with probability = %5.3f",Chisquare,ProbChi);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"Risk = %8.3f, Log Risk = %8.3f, Std.Err. Log Risk = %8.3f",
           Risk, LogRisk, SELogRisk);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"95 Percent Confidence interval for Log Risk = (%5.3f,%5.3f)",LowConf,HiConf);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       sprintf(outline,"95 Percent Confidence interval for Risk = (%5.3f,%5.3f)",LowLogLevel,HiLogLevel);
       astring = outline;
       FrmOutPut->RichOutPut->Lines->Add(astring);
       FrmOutPut->ShowModal();

       // Plot data output
       FrmOutPut->RichOutPut->Clear();
       FrmOutPut->RichOutPut->Lines->Add("EXPERIMENTAL GROUP CUMULATIVE PROBABILITY");
       FrmOutPut->RichOutPut->Lines->Add("CASE TIME DEATHS CENSORED CUM.PROB.");
       for (int i = 1; i <= NoCases; i++)
       {
            if (Group[i] == 1)
            {
                 sprintf(outline,"%3d    %3d   %3d     %3d      %5.3f",i,
                    SurvivalTimes[i], Deaths[i], Censored[i], CumPropExp[i]);
                 FrmOutPut->RichOutPut->Lines->Add(outline);
            }
       }
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->ShowModal();
       FrmOutPut->RichOutPut->Clear();
       FrmOutPut->RichOutPut->Lines->Add("CONTROL GROUP CUMULATIVE PROBABILITY");
       FrmOutPut->RichOutPut->Lines->Add("CASE TIME DEATHS CENSORED CUM.PROB.");
       for (int i = 1; i <= NoCases; i++)
       {
            if (Group[i] == 2)
            {
                 sprintf(outline,"%3d    %3d   %3d     %3d      %5.3f",i,
                    SurvivalTimes[i], Deaths[i], Censored[i], CumPropCntrl[i]);
                 FrmOutPut->RichOutPut->Lines->Add(outline);
            }
       }
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->ShowModal();

       if (Graph1) // plot cumulative proportion surviving (Y) against time (X)
       {
          double lastexp;
          double lastctr;
          nopoints = maxtime + 1;
          TimePlot = new int[nopoints+2];
          ProbPlot = new double[nopoints+2];
          ProbPlot2 = new double[nopoints+2];
          ProbPlot[0] = 1.0;
          ProbPlot2[0] = 1.0;
          lastexp = 1.0;
          lastctr = 1.0;
          for (int i = 0; i <= nopoints; i++)
          {
               TimePlot[i] = 0.0;
               ProbPlot[i] = 1.0;
               ProbPlot2[i] = 1.0;
          }
          TimePlot[0] = 0;
          mintime = 0;
          for (int i = 1; i <= nopoints; i++)
          {
               TimePlot[i] = i;
               for (int j = 1; j <= NoCases; j++)
               {
                   if (SurvivalTimes[j] == i)
                   {
                        if (Group[j] == 1)
                        {
                             ProbPlot[i] = CumPropExp[j]; // ExpProp[j];
                             lastexp = CumPropExp[j]; // ExpProp[j];
                        }
                        if (Group[j] == 2)
                        {
                             ProbPlot2[i] = CumPropCntrl[j]; //CntrlProp[j];
                             lastctr = CumPropCntrl[j]; // CntrlProp[j];
                        }
                   }
                   else
                   {
                        if (Group[j] == 1) ProbPlot[i] = lastexp;
                        if (Group[j] == 2) ProbPlot2[i] = lastctr;
                   }
               }
          }

          plotxy(TimePlot, ProbPlot, Dropped, Dropped2,
              maxtime, 0, 1.0, 0.0, nopoints, "TIME", "PROBABILITY",1);

          plotxy(TimePlot, ProbPlot2, Dropped, Dropped2,
              maxtime, 0, 1.0, 0.0, nopoints, "TIME", "PROBABILITY",2);

          PlotForm->ShowModal();
          delete[] ProbPlot2;
          delete[] ProbPlot;
          delete[] TimePlot;
        } // if graph plot = 1
        delete[] Dropped2;
        delete[] Dropped;
    } // if two groups

    // clean up memory
    delete[] Dropped2;
    delete[] Dropped;
    delete[] CumPropCntrl;
    delete[] CumPropExp;
    delete[] Censored;
    delete[] Group;
    delete[] Deaths;
    delete[] CntrlProp;
    delete[] ExpProp;
    delete[] CntrlatRisk;
    delete[] ExpatRisk;
    delete[] TotalatRisk;
    delete[] CntrlCnt;
    delete[] ExpCnt;
    delete[] SurvivalTimes;

}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::TimeInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     if (index >= 0)
     {
        TimeEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        TimeInBtn->Visible = false;
        TimeOutBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::TimeOutBtnClick(TObject *Sender)
{
     if (TimeEdit->Text != "")
     {
        VarList->Items->Add(TimeEdit->Text);
        TimeEdit->Text = "";
        TimeOutBtn->Visible = false;
        TimeInBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::EventInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     if (index >= 0)
     {
        EndpointEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        EventInBtn->Visible = false;
        EventOutBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::EventOutBtnClick(TObject *Sender)
{
     if (EndpointEdit->Text != "")
     {
        VarList->Items->Add(EndpointEdit->Text);
        EndpointEdit->Text = "";
        EventOutBtn->Visible = false;
        EventInBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::GroupInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     if (index >= 0)
     {
        GroupEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        GroupInBtn->Visible = false;
        GroupOutBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKaplanMeierForm::GroupOutBtnClick(TObject *Sender)
{
     if (GroupEdit->Text != "")
     {
        VarList->Items->Add(GroupEdit->Text);
        GroupEdit->Text = "";
        GroupOutBtn->Visible = false;
        GroupInBtn->Visible = true;
     }
}
//---------------------------------------------------------------------------

void TKaplanMeierForm::plotxy(int *Xpoints, double *Ypoints,
                              int *Dropped, int *Dropped2, double Xmax,
                              double Xmin, double Ymax, double Ymin, int N,
                              char *XEdit, char *YEdit, int curveno)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     int noxvalues, digitwidth, Xvalue, xvalincr;
     double maxval, minval, valincr, Yvalue;
     AnsiString Title;
     char outline[121];

     if (curveno == 2) goto second;
     PlotForm->Image1->Canvas->Font->Color = clBlack;
     Title = "SURVIVAL CURVE";
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     noxvalues = N;
     xvalincr =  1;
     digitwidth = PlotForm->Image1->Canvas->TextWidth("9");
again:
     if ( (noxvalues * 4 * digitwidth) > hwide)
     {
         noxvalues /= 2;
         xvalincr = 2 * xvalincr;
         goto again;
     }
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     for (i = 1; i <= noxvalues; i++)
     {
          ypos = vbottom;
          Xvalue = Xpoints[i] + xvalincr * (i - 1); // Xmin + xvalincr * (i - 1);
          xpos = ceil(double(hwide) * ((double(Xvalue) - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%d",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit) / 2);
     ypos = vbottom + 22;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XEdit);

     // Draw vertical axis
     Title = YEdit;
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YEdit);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }
second:
     // get xpos and ypos for first point to second point
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos); // Probability = 1 at time 0
     if (curveno == 1) PlotForm->Image1->Canvas->Pen->Color = clNavy;
     else PlotForm->Image1->Canvas->Pen->Color = clRed;
     ypos = ceil(vhi * ( (Ymax - Ypoints[0]) / (Ymax - Ymin)));
     ypos = ypos + vtop;
     xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
     xpos = xpos + hleft;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);

     // draw points for x and y pairs
     int oldxpos = xpos;
     double oldypos = ypos;
     for (i = 1; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          if (ypos != oldypos) // draw line down to new ypos using old xpos
          {
              if (curveno == 1) PlotForm->Image1->Canvas->Pen->Style = psSolid;
              else PlotForm->Image1->Canvas->Pen->Style = psDot;
              PlotForm->Image1->Canvas->LineTo(oldxpos,ypos);
          }
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          oldxpos = xpos;
          oldypos = ypos;
          PlotForm->Image1->Canvas->Pen->Style = psSolid;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // show censored
     PlotForm->Image1->Canvas->Pen->Style = psSolid;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     for (i = 1; i <= N; i++)
     {
          if ((Dropped[i] == 0) && (curveno == 1)) continue;
          if ((Dropped2[i] == 0) && (curveno == 2)) continue;
          if (curveno == 1)
          {
                PlotForm->Image1->Canvas->Font->Color = clNavy;
                ypos = vbottom + 35;
                xpos = ceil(hwide * ((Xpoints[i] - Xmin) / (Xmax - Xmin)));
                xpos = xpos + hleft;
                sprintf(outline,"%d",Dropped[i]);
                Title = outline;
                PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          }
          else
          {
                PlotForm->Image1->Canvas->Font->Color = clRed;
                ypos = vbottom + 48;
                xpos = ceil(hwide * ((Xpoints[i] - Xmin) / (Xmax - Xmin)));
                xpos = xpos + hleft;
                sprintf(outline,"%d",Dropped2[i]);
                Title = outline;
                PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          }
     }

     PlotForm->Image1->Canvas->Font->Color = clBlack;
     ypos = vbottom + 60;
     Title = "NUMBER CENSORED";
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     PlotForm->Image1->Canvas->Font->Color = clNavy;
     Title = "EXPERIMENTAL";
     xpos = 5;
     ypos = vbottom + 35;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     if (curveno == 2)
     {
          PlotForm->Image1->Canvas->Font->Color = clRed;
          Title = "CONTROL";
          xpos = 5;
          ypos = vbottom + 48;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
}
//-------------------------------------------------------------------

