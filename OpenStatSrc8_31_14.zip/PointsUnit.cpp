//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <math.h>
#include "Printers.hpp"
#include "PointsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPointsFrm *PointsFrm;
//---------------------------------------------------------------------------
__fastcall TPointsFrm::TPointsFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void TPointsFrm::PtsPlot(void)
{
    int topmarg, botmarg, leftmarg, rightmarg, height, width, verthi, horizlong;
    int X, Y, yincrement, labelheight, noxsteps;
    AnsiString labelstring;
    char label[11];
    double Xstep, Ystep, yprop, scaley, xprop, scalex, Min, Max;

    height = PointsFrm->ClientHeight - PointsFrm->Panel1->Height;
    width = PointsFrm->ClientWidth;
    topmarg = height / 10;
    verthi = height - (2 * topmarg);
    botmarg = topmarg + verthi;
    leftmarg = width / 10;
    horizlong = width - 2 * leftmarg;
    rightmarg = leftmarg + horizlong;
    // get max and min of values to plot
    Max = -1000.0;
    Min = 1000.0;
    for (int i = 0; i < NoCases; i++)
    {
        if (pts[i] > Max) Max = pts[i];
        if (avg[i] > Max) Max = avg[i];
        if (pts[i] < Min) Min = pts[i];
        if (avg[i] < Min) Min = avg[i];
    }
    if (Max <  0.001)
    {
        char astr[81];
        sprintf(astr,"Can't plot with Max = %8.3g, Min = %8.3g",Max,Min);
        Application->MessageBox(astr,"ERROR!",MB_OK);
        return;
    }
    PointsFrm->Canvas->Pen->Color = clBlack;
    PointsFrm->Canvas->Brush->Color = clWhite;
    PointsFrm->Canvas->Rectangle(0,0,width,height);

    yincrement = verthi / 20;
    PointsFrm->Canvas->Pen->Color = clBlack;

    // print title at top, centered
    labelstring = "Plot of Original and ";
    labelstring = labelstring + Title;
//    labelstring = labelstring + DepVarEdit->Text;
    X = (leftmarg + horizlong / 2) - (PointsFrm->Canvas->TextWidth(labelstring) / 2);
    Y = 1;
    PointsFrm->Canvas->TextOut(X,Y,labelstring);

    // draw left axis
    X = leftmarg;
    Y = botmarg;
    PointsFrm->Canvas->MoveTo(X,Y);
    Y = topmarg;
    PointsFrm->Canvas->LineTo(X,Y);

    // scale to left of vertical axis
    Ystep = (Max - Min) / 20;
    for (int i = 0; i < 21; i++)
    {
        Y = topmarg + (i * yincrement);
        sprintf(label,"%4.2f -",Max - (Ystep * i));
        labelstring = label;
        X = leftmarg - PointsFrm->Canvas->TextWidth(labelstring);
        PointsFrm->Canvas->TextOut(X,Y,labelstring);
    }

    // Make legend axis on bottom
    X = leftmarg;
    Y = botmarg;
    if (NoCases >= 20)
    {
        Xstep = horizlong / 20;
        xprop = (double) NoCases / 20.0;
        noxsteps = 21;
    }
    else
    {
        Xstep = horizlong / NoCases;
        xprop = 1.0;
        noxsteps = NoCases + 1;
    }
    PointsFrm->Canvas->MoveTo(X,Y);
    X = rightmarg;
    PointsFrm->Canvas->LineTo(X,Y);
    for (int i = 0; i < noxsteps; i++)
    {
        X = leftmarg + (Xstep * i);
        labelstring = "|";
        PointsFrm->Canvas->TextOut(X,Y,labelstring);
        labelstring = xprop * (double)i + 1.0;
        Y = Y + 5;
        PointsFrm->Canvas->TextOut(X,Y,labelstring);
        Y = botmarg;
    }
    labelstring = "CASES";
    X = (leftmarg + horizlong / 2) - (PointsFrm->Canvas->TextWidth(labelstring) / 2);
    Y = botmarg + PointsFrm->Canvas->TextHeight(labelstring);
    PointsFrm->Canvas->TextOut(X,Y,labelstring);

    // Plot lines from point to point
    PointsFrm->Canvas->Pen->Color = clRed;
    for (int i = 0; i < NoCases; i++)
    {
        yprop = (Max - pts[i]) / (Max - Min);
        if ((yprop < 0.0) || (yprop > 1.0)) continue;
        scaley = yprop * verthi;
        xprop = double(i) / double(NoCases);
        scalex = xprop * horizlong;
        X = leftmarg + scalex;
        Y = topmarg + scaley;
        if (i == 0) PointsFrm->Canvas->MoveTo(X,Y);
        else PointsFrm->Canvas->LineTo(X,Y);
        PointsFrm->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
    }

    // Plot average points
    PointsFrm->Canvas->Pen->Color = clBlue;
    for (int i = 0; i < NoCases; i++)
    {
        if ((Max - avg[i]) < 0.0001) continue;
        yprop = (Max - avg[i]) / (Max - Min);
        if ((yprop < 0.0) || (yprop > 1.0)) continue;
        scaley = yprop * verthi;
        xprop = double(i) / double(NoCases);
        scalex = xprop * horizlong;
        X = leftmarg + scalex;
        Y = topmarg + scaley;
        if (i == 0) PointsFrm->Canvas->MoveTo(X,Y);
        else PointsFrm->Canvas->LineTo(X,Y);
        PointsFrm->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
    }

    // Show legend at right
    X = rightmarg;
    labelstring = LabelOne;
    labelheight = PointsFrm->Canvas->TextHeight(labelstring);
    Y = 5 * labelheight;
    PointsFrm->Canvas->Font->Color = clRed;
    PointsFrm->Canvas->TextOut(X,Y,labelstring);
    labelstring = LabelTwo;
    Y = 6 * labelheight;
    PointsFrm->Canvas->Font->Color = clBlue;
    PointsFrm->Canvas->TextOut(X,Y,labelstring);
}
//----------------------------------------------------------------------------

void __fastcall TPointsFrm::ReturnBtnClick(TObject *Sender)
{
    PointsFrm->Hide();
}
//---------------------------------------------------------------------------



void __fastcall TPointsFrm::FormShow(TObject *Sender)
{
    PtsPlot();
}
//---------------------------------------------------------------------------

void __fastcall TPointsFrm::FormPaint(TObject *Sender)
{
    PtsPlot();    
}
//---------------------------------------------------------------------------

void __fastcall TPointsFrm::FormResize(TObject *Sender)
{
    PtsPlot();    
}
//---------------------------------------------------------------------------

void __fastcall TPointsFrm::PrintBtnClick(TObject *Sender)
{
    int topmarg, botmarg, leftmarg, rightmarg, height, width, verthi, horizlong;
    int X, Y, yincrement, labelheight;
    AnsiString labelstring;
    char label[11];
    double Xstep, Ystep, yprop, scaley, xprop, scalex, Min, Max;

    Printer()->Orientation = poLandscape;
    height = Printer()->PageHeight;
    width = Printer()->PageWidth;
    topmarg = height / 4;
    verthi = height - (2 * topmarg);
    botmarg = topmarg + verthi;
    leftmarg = width / 10;
    horizlong = width - 2 * leftmarg;
    rightmarg = leftmarg + horizlong;
    // get max and min of values to plot
    Max = -1000.0;
    Min = 1000.0;
    for (int i = 0; i < NoCases; i++)
    {
        if (pts[i] > Max) Max = pts[i];
        if (avg[i] > Max) Max = avg[i];
        if (pts[i] < Min) Min = pts[i];
        if (avg[i] < Min) Min = avg[i];
    }
    yincrement = verthi / 20;
    Printer()->BeginDoc();
    Printer()->Canvas->Pen->Color = clBlack;

    // print title at top, centered
    labelstring = "Plot of Original and ";
    labelstring = labelstring + Title;
    X = (leftmarg + horizlong / 2) - (Printer()->Canvas->TextWidth(labelstring) / 2);
    Y = 1;
    Printer()->Canvas->TextOut(X,Y,labelstring);

    // draw left axis
    X = leftmarg;
    Y = botmarg;
    Printer()->Canvas->MoveTo(X,Y);
    Y = topmarg;
    Printer()->Canvas->LineTo(X,Y);

    // scale to left of vertical axis
    Ystep = (Max - Min) / 20;
    for (int i = 0; i < 21; i++)
    {
        Y = topmarg + (i * yincrement);
        sprintf(label,"%4.2f -",Max - (Ystep * i));
        labelstring = label;
        X = leftmarg - Printer()->Canvas->TextWidth(labelstring);
        Printer()->Canvas->TextOut(X,Y,labelstring);
    }

    // Make legend axis on bottom
    X = leftmarg;
    Y = botmarg;
    Xstep = horizlong / 20;
    xprop = NoCases / 20;
    Printer()->Canvas->MoveTo(X,Y);
    X = rightmarg;
    Printer()->Canvas->LineTo(X,Y);
    for (int i = 0; i < 21; i++)
    {
        X = leftmarg + (Xstep * i);
        labelstring = "|";
        Printer()->Canvas->TextOut(X,Y,labelstring);
        labelstring = int((xprop * i) + 1);
        Y = Y + 5;
        Printer()->Canvas->TextOut(X,Y,labelstring);
        Y = botmarg;
    }
    labelstring = "CASES";
    X = (leftmarg + horizlong / 2) - (Printer()->Canvas->TextWidth(labelstring) / 2);
    Y = botmarg + Printer()->Canvas->TextHeight(labelstring);
    Printer()->Canvas->TextOut(X,Y,labelstring);

    // Plot lines from point to point
    Printer()->Canvas->Pen->Color = clRed;
    for (int i = 0; i < NoCases; i++)
    {
        yprop = (Max - pts[i]) / (Max - Min);
        scaley = yprop * verthi;
        xprop = double(i) / double(NoCases);
        scalex = xprop * horizlong;
        X = leftmarg + scalex;
        Y = topmarg + scaley;
        if (i == 0) Printer()->Canvas->MoveTo(X,Y);
        else Printer()->Canvas->LineTo(X,Y);
        Printer()->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
    }

    // Plot average points
    Printer()->Canvas->Pen->Color = clBlue;
    for (int i = 0; i < NoCases; i++)
    {
        yprop = (Max - avg[i]) / (Max - Min);
        scaley = yprop * verthi;
        xprop = double(i) / double(NoCases);
        scalex = xprop * horizlong;
        X = leftmarg + scalex;
        Y = topmarg + scaley;
        if (i == 0) Printer()->Canvas->MoveTo(X,Y);
        else Printer()->Canvas->LineTo(X,Y);
        Printer()->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
    }

    // Show legend at right
    X = rightmarg;
    labelstring = "Original";
    labelheight = Printer()->Canvas->TextHeight(labelstring);
    Y = 5 * labelheight;
    Printer()->Canvas->Font->Color = clRed;
    Printer()->Canvas->TextOut(X,Y,labelstring);
    labelstring = "Smoothed";
    Y = 6 * labelheight;
    Printer()->Canvas->Font->Color = clBlue;
    Printer()->Canvas->TextOut(X,Y,labelstring);
    Printer()->EndDoc();
    Printer()->Orientation = poPortrait;

}
//---------------------------------------------------------------------------

