//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "AttnRelUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmCorrectedR *FrmCorrectedR;
//---------------------------------------------------------------------------
__fastcall TFrmCorrectedR::TFrmCorrectedR(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::FirstrEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) FirstVarEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::FirstVarEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) SecdVarEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::SecdVarEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) ComputeBtn->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::ComputeBtnClick(TObject *Sender)
{
    double s1, s2, r, NewR;

    s1 = atof(FirstVarEdit->Text.c_str());
    s2 = atof(SecdVarEdit->Text.c_str());
    r = atof(FirstrEdit->Text.c_str());
    if (s2 <= 0.0)
    {
        ShowMessage("ERROR! Variances must be greater than 0.");
        return;
    }
    NewR = 1.0 - (s1 / s2) * (1.0 - r);
    EstREdit->Text = NewR;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::ResetBtnClick(TObject *Sender)
{
    FirstVarEdit->Text = "";
    SecdVarEdit->Text = "";
    FirstrEdit->Text = "";
    EstREdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TFrmCorrectedR::FormShow(TObject *Sender)
{
    FirstVarEdit->Text = "";
    SecdVarEdit->Text = "";
    FirstrEdit->Text = "";
    EstREdit->Text = "";
}
//---------------------------------------------------------------------------
