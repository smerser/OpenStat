//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MemMgrUnit.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

//---------------------------------------------------------------------------
int GetDblQuadMem(double ****&matrix, int Nrows, int Ncols, int Nslices, int Nblocks)
{
    try
    {    matrix = new double ***[Nrows];
         for (int i = 0; i < Nrows; i++)
         {
             matrix[i] = new double **[Ncols];
             for (int j = 0; j < Ncols; j++)
             {
                 matrix[i][j] = new double *[Nslices];
                 for (int k = 0; k < Nslices; k++) matrix[i][j][k] = new double[Nblocks];
             }
         }
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    for (int i = 0; i < Nrows; i++)
       for (int j = 0; j < Ncols; j++)
          for (int k = 0; k < Nslices; k++)
              for (int l = 0; l < Nblocks; l++)
                 matrix[i][j][k][l] = 0.0;
    return (1);
}
//-------------------------------------------------------------------------

void ClearDblQuadMem(double ****&matrix, int Nrows, int Ncols, int Nslices)
{
     for (int i = 0; i < Nrows; i++)
     {
         for (int j = 0; j < Ncols; j++)
         {
             for (int k = 0; k < Nslices; k++) delete[] matrix[i][j][k];
             delete[] matrix[i][j];
         }
         delete[] matrix[i];
     }
     delete[] matrix;
//     matrix = NULL;
}
//------------------------------------------------------------------------

int GetDblCubeMem(double ***&matrix, int Nrows, int Ncols, int Nslices)
{
// creates a double cube
    try
    {    matrix = new double **[Nrows];
         for (int i = 0; i < Nrows; i++)
         {
             matrix[i] = new double *[Ncols];
             for (int j = 0; j < Ncols; j++) matrix[i][j] = new double[Nslices];
         }
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//---------------------------------------------------------------------------

void ClearDblCubeMem(double ***&matrix, int Nrows, int Ncols)
{
     for (int i = 0; i < Nrows; i++)
     {
         for (int j = 0; j < Ncols; j++) delete[] matrix[i][j];
         delete[] matrix[i];
     }
     delete[] matrix;
     matrix = NULL;
}
//---------------------------------------------------------------------------

int GetIntCubeMem(int ***&matrix, int Nrows, int Ncols, int Nslices)
{
// creates a double cube
    try
    {    matrix = new int **[Nrows];
         for (int i = 0; i < Nrows; i++)
         {
             matrix[i] = new int *[Ncols];
             for (int j = 0; j < Ncols; j++) matrix[i][j] = new int[Nslices];
         }
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//---------------------------------------------------------------------------

void ClearIntCubeMem(int ***&matrix, int Nrows, int Ncols)
{
     for (int i = 0; i < Nrows; i++)
     {
         for (int j = 0; j < Ncols; j++) delete[] matrix[i][j];
         delete[] matrix[i];
     }
     delete[] matrix;
     matrix = NULL;
}
//---------------------------------------------------------------------------

int GetDblMatMem(double **&matrix, int Nrows, int Ncols)
{
// Creates a double matrix with Nrows and Ncolumns on the heap
    try
    {    matrix = new double *[Nrows];
         for (int i = 0; i < Nrows; i++) matrix[i] = new double [Ncols];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}

//---------------------------------------------------------------------------

void ClearDblMatMem(double **&matrix, int Nrows)
{
// clears a double matrix of Nrows from the heap
     for (int i = 0; i < Nrows; i++) delete[] matrix[i];
     delete[] matrix;
     matrix = NULL;
}

//---------------------------------------------------------------------------

int GetDblVecMem(double *&vector, int Nrows)
{
    try
    {
       vector = new double[Nrows];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}

//---------------------------------------------------------------------------

void ClearDblVecMem(double *&vector)
{
     delete[] vector;
     vector = NULL;
}

//---------------------------------------------------------------------------

int GetIntMatMem(int **&matrix, int Nrows, int Ncols)
{
// Creates an integer matrix with Nrows and Ncolumns on the heap
    try
    {    matrix = new int *[Nrows];
         for (int i = 0; i < Nrows; i++) matrix[i] = new int[Ncols];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//---------------------------------------------------------------------------

void ClearIntMatMem(int **&matrix, int Nrows)
{
// clears an integer matrix of Nrows from the heap
     for (int i = 0; i < Nrows; i++) delete[] matrix[i];
     delete[] matrix;
//     matrix = NULL;
}
//---------------------------------------------------------------------------

int GetIntVecMem(int *&vector, int Nrows)
{
    try
    {
       vector = new int[Nrows];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//---------------------------------------------------------------------------

void ClearIntVecMem(int *&vector)
{
     delete[] vector;
//     vector = NULL;
}
//---------------------------------------------------------------------------

int GetLongDblMatMem(long double **&matrix, int Nrows, int Ncols)
{
// Creates a double matrix with Nrows and Ncolumns on the heap
    try
    {    matrix = new long double *[Nrows];
         for (int i = 0; i < Nrows; i++) matrix[i] = new long double [Ncols];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//=============================================================================

int GetLongDblVecMem(long double *&vector, int Nrows)
{
    try
    {
       vector = new long double[Nrows];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return (0);
    }
    return (1);
}
//---------------------------------------------------------------------------

void ClearLongDblVecMem(long double *&vector)
{
     delete[] vector;
     vector = NULL;
}
//---------------------------------------------------------------------------

void ClearLongDblMatMem(long double **&matrix, int Nrows)
{
// clears a double matrix of Nrows from the heap
     for (int i = 0; i < Nrows; i++) delete[] matrix[i];
     delete[] matrix;
     matrix = NULL;
}
//--------------------------------------------------------------------------
