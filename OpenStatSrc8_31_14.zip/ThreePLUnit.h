//---------------------------------------------------------------------------

#ifndef ThreePLUnitH
#define ThreePLUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TThreePLForm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *CalibrateOps;
    TGroupBox *ItemParamBox;
    TOpenDialog *OpenDialog1;
    TLabel *Label1;
    TEdit *ParamFileEdit;
    TGroupBox *OutOpsBox;
    TCheckBox *PlotAbilityChk;
    TCheckBox *PlotbChk;
    TCheckBox *PlotaChk;
    TCheckBox *PlotcChk;
    TMemo *Memo1;
    TListBox *VarList;
    TLabel *Label8;
    TBitBtn *IDInBtn;
    TBitBtn *IDOutBtn;
    TBitBtn *ThetaInBtn;
    TBitBtn *ThetaOutBtn;
    TBitBtn *ItemInBtn;
    TBitBtn *ItemOutBtn;
    TLabel *Label9;
    TEdit *ExamineeIDEdit;
    TLabel *Label10;
    TEdit *ThetaEdit;
    TLabel *Label11;
    TListBox *ItemList;
    TButton *ResetBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TButton *CancelBtn;
    TEdit *ResponseFileEdit;
    TLabel *Label2;
    TCheckBox *CurvesChk;
    TSaveDialog *SaveDialog1;
    TStringGrid *ParamGrid;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *ItersEdit;
    TButton *ParmBtn;
    TProgressBar *Pbar;
    TButton *DefaultsBtn;
    TLabel *Label5;
    TCheckBox *FilterChk;
    TCheckBox *InitialzChk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall IDInBtnClick(TObject *Sender);
    void __fastcall IDOutBtnClick(TObject *Sender);
    void __fastcall ThetaInBtnClick(TObject *Sender);
    void __fastcall ThetaOutBtnClick(TObject *Sender);
    void __fastcall ItemInBtnClick(TObject *Sender);
    void __fastcall ItemOutBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall ParmBtnClick(TObject *Sender);
    void __fastcall DefaultsBtnClick(TObject *Sender);
private:	// User declarations
    int iopt;
    AnsiString ParmFileName, ResponseFileName;
    void __fastcall GetTotalScores(int NoItems, int *ItemCols, double *TotScrs, TObject *Sender);
    void __fastcall SetThetaz(int ThetaCol, double *TotScrs, TObject *Sender);
public:		// User declarations
    __fastcall TThreePLForm(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TThreePLForm *ThreePLForm;
//---------------------------------------------------------------------------
#endif
