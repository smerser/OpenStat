//---------------------------------------------------------------------------

#include <vcl.h>
#include "MainUnit.h"
#include "math.h"
#include "DataFuncs.h"
#include "PlotUnit.h"
#include "MemMgrUnit.h"
#include "ThreePLUnit.h"
#include "OutPut.h"
#include "functions.h"

#pragma hdrstop

#include "ThreePFuncs.h"

extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
extern char prtfmt[121];

//---------------------------------------------------------------------------

#pragma package(smart_init)

double probt(double theta, double a, double b, double c)
{
       // probability of a correct response on item j for examine of ability theta
       double dem, pr;

//       pr = 0;
       dem = 1.0 + exp( -1.700 * a * ( theta - b ));
       pr = c + (( 1.0 - c ) / dem );
       if (pr < 0.001) pr = 0.001;
       if (pr > 0.999) pr = 0.999;
       return (pr);
}
//---------------------------------------------------------------------------


double lik(int ItemCol, double *th, double a, double b, double c, int nobs)
{
       //log likelihood
       // obs is the observed 0 and 1 response to an item in the main form grid
       // at ItemCol
       int i;
       double pr, lk, obs;

       lk = 1.0;
//       nobs = 0;
       for (i = 1; i < NoCases; i++) //FOR i = 1 TO N
       {
           if (ValidValue(i,ItemCol)) // IF obs( i ) < > 9 THEN
           {
//                nobs++;
                obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][i]));
                pr = probt( th[i-1], a, b, c );
                lk = lk * ( pow(pr, obs) * pow(( 1.0 - pr ),( 1.0 - obs)));
           }
       }
       return (log(lk));
}
//---------------------------------------------------------------------------

void calib_theta(double &seeth, double &th, int ii, double *a, double *b,
                 double *c, int subject, int &nvalid, int *ItemCols)
{
     int n1, i, j, ItemCol;
     double tdem, tnum, tho, theta, pr, obs;
     bool test = true;

     // see - standard error - returned
     // th  - theta in and updated
     // ii  - number of administered subjects
     // ui  - reponse (correct=1, else=0)
     // formula is from Lord, p 61 ; 2PL = Baker () Basics if Item Response Theory, p 66
     n1 = 0;
     nvalid = 0;
     theta = th;
     do // DO
     {
        tdem = 0.0;
        tnum = 0.0;
        tho = theta;
        n1++;
        for (i = 1; i <= ii; i++) // items
        {
            ItemCol = ItemCols[i-1];
            if (ValidValue(subject,ItemCol)) // if (obs( i ) < > 9 THEN
            {
               obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][subject]));
               if (n1 == 1) nvalid++;
               // j = i
               pr = probt( theta, a[i-1], b[i-1], c[i-1]);
               tnum = tnum + ( obs - pr ) * 1.7 * ( a[i-1] /
                    (1.0 - c[i-1])) * (pr - c[i-1]) / pr;
               tdem = tdem + 1.7 * 1.7 * a[i-1] * a[i-1] * ((1.0 - pr) / pr ) *
                    (pow( (pr - c[i-1]) / ( 1.0 - c[i-1]), 2.0));
            } // END IF
        } // NEXT i
        theta = theta + ( tnum / tdem );
        if (theta > 3.0)
        {
            theta = 3.0;
            tho = 3.0;
        }
        if (theta < -3.0)
        {
            theta = -3.0;
            tho = -3.0;
        }
        if (fabs(theta - tho) < 0.00001) test = false;
        if (n1 > 200) test = false;
     } while (test);
     // UNTIL ABS( theta - tho ) < .00001 OR nl > 200
     seeth = 1.0 / sqrt( tdem );
     if (seeth > 99.0) seeth = 99.0;
     th = theta;
} // END SUB
//---------------------------------------------------------------------------

void Calib_a(double &seea, int ItemCol, double *th, double &a, double &b, double &c, int N)
{
     int nl, i, j;
     double tdem, tnum, da, pr, aold, qr, obs;
     bool test = true;

     if (N < 10) return;
     nl = 0;
     do // DO
     {
        aold = a;
        tdem = 0.0;
        tnum = 0.0;
        nl++;
        for (i = 1; i <= N; i++)
        {
            if (ValidValue(i,ItemCol))
            {
                obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][i]));
                pr = probt( th[i-1], a, b, c );
                qr = 1 - pr;
                da = 1.7 * ( th[i-1] - b ) * qr * ( pr - c ) / ( 1.0 - c );
                tnum = tnum + (( obs - pr ) / ( pr * qr )) * da;
                tdem = tdem + ( da * da ) / ( pr * qr );
            } // END IF
        } // NEXT
        if (fabs(tdem) > 0.0) a = a + ( tnum / tdem );
        else a = 2.0;
        if (a > 2.0)
        {
           a = 2.0;
           aold = a;
        }
        if (a < 0.0)
        {
           a = .0001;
           aold = a;
        }
        if (fabs(a - aold) < 0.0001) test = false;
        if (nl > 200) test = false;
     } while (test);
     if (fabs(tdem) > 0.0) seea = 1.0 / sqrt( tdem );
     else seea = 99.0;
     if (seea > 99.0) seea = 99.0;
} // END SUB
//---------------------------------------------------------------------------

void Calib_b(double &seeb, int ItemCol, double *th, double &a, double &b, double &c, int N)
{
     int nl, i, j;
     double tdem, tnum, db, pr, bold, qr, obs;
     bool test = true;

     seeb = -1.0;
     if (N < 10) return;
     nl = 0;
     do
     {
          bold = b;
          tdem = 0.0;
          tnum = 0.0;
          nl++;
          for (i = 1; i <= N; i++) // FOR i = 1 TO N
          {
              if (ValidValue(i,ItemCol))
              {
                 obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][i]));
                 pr = probt( th[i-1], a, b, c );
                 qr = 1 - pr;
                 db = -1.7 * a * qr * ( pr - c ) / ( 1.0 - c );
                 tnum = tnum + (( obs - pr ) / ( pr * qr )) * db;
                 tdem = tdem + ( db * db ) / ( pr * qr );
              } //END IF
          } // NEXT
          if (tdem != 0.0) b = b + ( tnum / tdem );
          if (b > 5.0)
          {
             b = 5.0000;
             bold = b;
          }
          if (b < -5.0)
          {
             b = -5.0000;
             bold = b;
          }
          if (fabs(b - bold) < 0.0001) test = false;
          if (nl > 200) test = false;
     } while (test);
     if (fabs(tdem) > 0.0) seeb = 1.0 / sqrt( tdem );
     else seeb = 99.0;
     if (seeb > 99.0) seeb = 99.0;
} // END SUB
//---------------------------------------------------------------------------

void Calib_c(double &seec, int ItemCol, double *th, double &a, double &b, double &c, int N)
{
     int nl, i, j;
     double tdem, tnum, DC, pr, cold, qr, obs;

     seec = -1.0;
     nl = 0;
     if (N < 10) return;
     do
     {
        cold = c;
        tdem = 0.0;
        tnum = 0.0;
        nl++;
        for (i = 1; i <= N; i++) //FOR i = 1 TO N
        {
            if (ValidValue(i,ItemCol))
            {
               obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][i]));
               pr = probt( th[i-1], a, b, c );
               qr = 1 - pr;
               if (c != 1.0) DC = qr / ( 1 - c );
               else DC = qr / (1.0 - .2);
               tnum = tnum + (( obs - pr ) / ( pr * qr )) * DC;
               tdem = tdem + ( DC * DC ) / ( pr * qr );
            } //END IF
        } //NEXT
        if (tdem != 0.0) c = c + ( tnum / tdem );
        else c = c + 0.01;
        if (c > 1.0)
        {
           c = 0.999;
           cold = c;
        }
        if (c < 0.0)
        {
           c = 0.0001;
           cold = c;
        }
     } while (( fabs(c - cold) >= 0.0001) && (nl <= 200));
     if (tdem != 0.0) seec = 1.0 / sqrt( tdem );
     if (seec > 99.0) seec = 99.0;
} // END SUB
//---------------------------------------------------------------------------

void calib_abc(double &seea, double &seeb, double &seec, int ItemCol, double *th,
               double &a, double &b, double &c, int N)
{
     int iopt, nl = 0;
     double ao, bo, co;
     bool test = true;
     iopt = ThreePLForm->CalibrateOps->ItemIndex + 1;
     do
     {
          nl++;
          ao = a;
          bo = b;
          co = c;
          Calib_b( seeb, ItemCol, th, a, b, c, N );
          Calib_a( seea, ItemCol, th, a, b, c, N );
          if ((iopt == 2) || (iopt == 3)) Calib_c(seec, ItemCol, th, a, b, c, N);
          if (nl > 199) test = false;
          if ((fabs(bo - b) < 0.0001) && (fabs(co - c) < 0.0001) && (fabs(ao - a) < 0.0001)) test = false;
     } while (test);
} // END SUB
//---------------------------------------------------------------------------

double mse(int ItemCol, double *th, double a, double b, double c, int N, int &nobs)
{
     //FUNCTION mse( obs() AS WORD, th() AS DOUBLE, a AS DOUBLE, b AS DOUBLE,
     //              c AS DOUBLE, N AS DWORD, nobs AS DWORD ) AS DOUBLE
     // mean square error
     int i;
     double pr, ms, obs;

     ms = -1.0;
     if(N == 0) return (ms);
     ms = 0;
     nobs = 0;
     for (i = 1; i <= N; i++) //FOR i = 1 TO N
     {
          if (ValidValue(i,ItemCol)) // if (obs( i ) < > 9 THEN
          {
               obs = StrToFloat(Trim(MainForm->Grid->Cells[ItemCol][i]));
               nobs++;
               pr = probt( th[i-1], a, b, c);
               ms = pow((obs - pr ),2.0);
          } //END IF
     } // NEXT
     if (nobs > 9) ms = ms / nobs;
     return (ms);
} // END FUNCTION
//---------------------------------------------------------------------------

void plotxy(double *Ypoints, double *Xpoints, double Xmax, double Xmin,
            double Ymax, double Ymin, int N, char *Title)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     char outline[121];

//     Title = "Log Ability Using File: " + MainForm->FileNameEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
//     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit->Text) / 2);
//     ypos = vbottom + 20;

     // Draw vertical axis
     Title = "Log";
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 1; i <= N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i-1]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i-1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }
     PlotForm->ShowModal();
}
//-------------------------------------------------------------------

void ItemFit(double *Parma, double *Parmb,double *Parmc, double *TotScrs,
             double *Theta, int NoItems, int NoCases)
{
     double *ScrGroups;
     double *ScrTheta;
     double *ChiVals;
     double ProbTheta;
     double minx, maxx, X, probtheta, chivalue, Prob, propitems, exponent;
     int NoGrps, index;
     char astring[81];

     ScrGroups = new double[NoCases];
     ScrTheta = new double[NoCases];
     ChiVals = new double[NoItems];

     FrmOutPut->RichOutPut->Clear();
     minx = NoItems + 1.0;
     maxx = 0.0;
     // Get minimum and maximum subject scores
     for (int i = 0; i < NoCases; i++)
     {
         if (TotScrs[i] < minx) minx = TotScrs[i];
         if (TotScrs[i] > maxx) maxx = TotScrs[i];
     }

     // Count subjects in each score group and get corresponding thetas
     NoGrps = maxx - minx + 1;
     for (int i = 0; i < NoGrps; i++) ScrGroups[i] = 0.0;
     for (int i = 0; i < NoCases; i++)
     {
         X = TotScrs[i] - minx;
         index = floor(X);
         ScrGroups[index]++;
         ScrTheta[index] = Theta[i];
     }

     // Calculate chi-squares for log difficulty of the ability groups
     FrmOutPut->RichOutPut->Lines->Add("ITEM  CHI-SQUARED  PROB.  PROB. > CHI-SQR.");
     for (int i = 0; i < NoItems; i++)
     {
         chivalue = 0.0;
         for (int j = 0; j < NoGrps; j++)
         {
             X = j + minx; // raw score of group
             propitems = X / double(NoItems);
             exponent = exp(-Parma[i]*(ScrTheta[j] - Parmb[i]));
             ProbTheta = Parmc[i] + (1.0 - Parmc[i]) * (1.0 / (1.0 + exponent));
             chivalue += ScrGroups[j] * pow( (propitems - ProbTheta ),2) /
                      (ProbTheta * (1.0 - ProbTheta));
         }
         Prob = chisquaredprob(chivalue,NoGrps);
         sprintf(astring,"%4d  %8.4f     %6.4f     %6.4f",i+1,chivalue,Prob,1.0-Prob);
         FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     FrmOutPut->ShowModal();

     delete[] ChiVals;
     delete[] ScrTheta;
     delete[] ScrGroups;
}
//-------------------------------------------------------------------

