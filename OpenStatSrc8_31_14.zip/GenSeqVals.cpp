//---------------------------------------------------------------------------

#include <vcl.h>
#include "MainUnit.h"
#include "DataFuncs.h"

#pragma hdrstop

#include "GenSeqVals.h"
extern bool openfile;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGenSeqForm *GenSeqForm;
//---------------------------------------------------------------------------
__fastcall TGenSeqForm::TGenSeqForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGenSeqForm::GenBtnClick(TObject *Sender)
{
     int col;

     if (OptionGrp->ItemIndex == 0) // generate in current column of grid
     {
         col = MainForm->Grid->Col;
         for (int i = 1; i < MainForm->Grid->RowCount; i++)
             MainForm->Grid->Cells[col][i] = IntToStr(i);
     }
     else
     {
         col = MainForm->Grid->ColCount;
         NewVar(col,false);
         for (int i = 1; i < MainForm->Grid->RowCount; i++)
             MainForm->Grid->Cells[col][i] = IntToStr(i);
     }
     openfile = true;
     if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "SeqData.TEX";
}
//---------------------------------------------------------------------------
