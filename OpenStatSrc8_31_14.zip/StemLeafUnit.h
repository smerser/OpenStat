//---------------------------------------------------------------------------

#ifndef StemLeafUnitH
#define StemLeafUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TStemLeafForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TListBox *Varlist;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TListBox *SelectList;
    TLabel *Label2;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TBitBtn *AllBtn;
    TCheckBox *TestChk;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
    int noselected, ncases, largest, intrange, leafpos, nobins, leafvalue;
    int counter, leafbin, smallcount, smallest;
    int *selected;
    double *values;
    double min, max, stemsize;
    AnsiString *ValueString;
    int *frequency, *bins;
//    char leafs[10][1000];
//    int leafcounts[10];
    char leafslow[10][1000];
    char leafshi[10][1000];
    char templeafs[101];
    int counterlow[10];
    int counterhi[10];

public:		// User declarations
    __fastcall TStemLeafForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStemLeafForm *StemLeafForm;
//---------------------------------------------------------------------------
#endif
