//---------------------------------------------------------------------------

#ifndef FFTUnitH
#define FFTUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFFTFrm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *NptsEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
private:	// User declarations
public:		// User declarations
    __fastcall TFFTFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFFTFrm *FFTFrm;
//---------------------------------------------------------------------------
#endif
