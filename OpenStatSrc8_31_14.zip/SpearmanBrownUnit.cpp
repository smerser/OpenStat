//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include "SpearmanBrownUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmSB *FrmSB;
//---------------------------------------------------------------------------
__fastcall TFrmSB::TFrmSB(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmSB::FirstRelEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) KEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmSB::KEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) CalcBtn->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TFrmSB::CalcBtnClick(TObject *Sender)
{
    double SBR, FirstR, ConstantK, FirstValidity, FinalValidity;

    FirstR = atof(FirstRelEdit->Text.c_str());
    if (FirstR <= 0)
    {
        Application->MessageBox("Enter a positive Value for a reliability.","ERROR",MB_OK);
        return;
    }
    ConstantK = atof(KEdit->Text.c_str());
    if (ConstantK <= 0)
    {
        Application->MessageBox("Enter a positive Value for K.","ERROR",MB_OK);
        return;
    }
    SBR = (ConstantK * FirstR) / (1.0 + (ConstantK - 1.0) * FirstR);
    FirstValidity = atof(ValidityEdit->Text.c_str());
    EstREdit->Text = SBR;
    if (FirstValidity > 0)
    {
        Label6->Visible = true;
        EstValEdit->Visible = true;
        FinalValidity = (FirstValidity * sqrt(ConstantK)) /
            sqrt(1.0 + (ConstantK - 1.0) * FirstR);
        EstValEdit->Text = FinalValidity;
    }
    ReturnBtn->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TFrmSB::ResetBtnClick(TObject *Sender)
{
    KEdit->Text = "";
    FirstRelEdit->Text = "";
    EstREdit->Text = "";
    FirstRelEdit->SetFocus();
    Label6->Visible = false;
    EstValEdit->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmSB::FormShow(TObject *Sender)
{
    KEdit->Text = "";
    FirstRelEdit->Text = "";
    EstREdit->Text = "";
    FirstRelEdit->SetFocus();
    Label6->Visible = false;
    EstValEdit->Visible = false;
}
//---------------------------------------------------------------------------
