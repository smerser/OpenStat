//---------------------------------------------------------------------------
#ifndef TestGenrUnitH
#define TestGenrUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTestGenrFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *NoItemsEdit;
    TLabel *Label2;
    TEdit *NoCasesEdit;
    TLabel *Label3;
    TEdit *MeanEdit;
    TLabel *Label4;
    TEdit *StdDevEdit;
    TLabel *Label5;
    TEdit *RelEdit;
    TRadioGroup *ItemTypeGroup;
    TButton *CancelBtn;
    TButton *ContBtn;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ContBtnClick(TObject *Sender);
    void __fastcall NoItemsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall NoCasesEditKeyPress(TObject *Sender, char &Key);
    void __fastcall MeanEditKeyPress(TObject *Sender, char &Key);
    void __fastcall StdDevEditKeyPress(TObject *Sender, char &Key);
    void __fastcall RelEditKeyPress(TObject *Sender, char &Key);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TTestGenrFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestGenrFrm *TestGenrFrm;
//---------------------------------------------------------------------------
#endif
