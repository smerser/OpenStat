//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "functions.h"
#include "FrmFDSpecs.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "Math.h"
#include "DataFuncs.h"
#include "AnovaTestsUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "GraphUnit.h"
#include "MatrixUnit.h"
#include "TwoWayRepUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTwoWayRepForm *TwoWayRepForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoVariables;
extern int NoCases;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TTwoWayRepForm::TTwoWayRepForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::ResetBtnClick(TObject *Sender)
{
     int i;

     SubjectEdit->Text = "";
     FactorAEdit->Text = "";
     FactorBEdit->Text = "";
     MeasurementEdit->Text = "";
     PlotAChk->Checked = false;
     PlotBChk->Checked = false;
     PlotABChk->Checked = false;
     PostHocChk->Checked = false;
     if (ops.format == 0) SigLevelEdit->Text = "0.05";
     else SigLevelEdit->Text = "0,05";
     VarList->Clear();
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     SubjInBtn->Visible = true;
     SubjOutBtn->Visible = false;
     FactAInBtn->Visible = true;
     FactAOutBtn->Visible = false;
     FactBInBtn->Visible = true;
     FactBOutBtn->Visible = false;
     MeasInBtn->Visible = true;
     MeasOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::SubjInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     SubjectEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     SubjInBtn->Visible = false;
     SubjOutBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::SubjOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(SubjectEdit->Text);
     SubjectEdit->Text = "";
     SubjOutBtn->Visible = false;
     SubjInBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::FactAInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     FactorAEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     FactAInBtn->Visible = false;
     FactAOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::FactAOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FactorAEdit->Text);
     FactorAEdit->Text = "";
     FactAOutBtn->Visible = false;
     FactAInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::FactBInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     FactorBEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     FactBInBtn->Visible = false;
     FactBOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::FactBOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FactorBEdit->Text);
     FactorBEdit->Text = "";
     FactBOutBtn->Visible = false;
     FactBInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::MeasInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     MeasurementEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     MeasInBtn->Visible = false;
     MeasOutBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::MeasOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(MeasurementEdit->Text);
     MeasurementEdit->Text = "";
     MeasOutBtn->Visible = false;
     MeasInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TTwoWayRepForm::ComputeBtnClick(TObject *Sender)
{
     int i, j, k, rangeA, rangeB, NoSelected, row, col, NoSubjects, subject;
     double **SbyASums, **SbyBSums, **AbyBSums;
     double *SSums, *ASums, *BSums;
     double *Means;
     double TotalSum, SSTotal;   // for calculation of total sum of squares
     AnsiString cellstring;      // temporary place for grid cell values
     int *ColNoSelected;         // variables selected for analysis
     int Acol, Bcol, Scol, Mcol; // grid columns of variables
     int minA, minB, maxA, maxB; // min and max values of Factors A and B
     int ivalue;                 // for input of integer values from the grid
     double dvalue;              // for input of double values from the grid
     double terma, termb, termc, termd, terme, termf, termg, termh, termi, termj;
     char outline[101];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     // Get variables and locations
     GetIntVecMem(ColNoSelected,4);
     NoSelected = 4;
     Scol = 0;
     Acol = 0;
     Bcol = 0;
     Mcol = 0;
     for (i = 1; i <= NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i][0];
         if (cellstring == SubjectEdit->Text) Scol = i;
         if (cellstring == FactorAEdit->Text) Acol = i;
         if (cellstring == FactorBEdit->Text) Bcol = i;
         if (cellstring == MeasurementEdit->Text) Mcol = i;
     }
     if ((Scol == 0) || (Acol == 0) || (Bcol == 0) || (Mcol == 0))
     {
         ShowMessage("ERROR!  One or more variables not selected.");
         delete[] ColNoSelected;
         return;
     }
     ColNoSelected[0] = Scol;
     ColNoSelected[1] = Acol;
     ColNoSelected[2] = Bcol;
     ColNoSelected[3] = Mcol;
/*
     // check on variable types
     result = VarTypeChk(Scol,1);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
     result = VarTypeChk(Acol,1);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
     result = VarTypeChk(Bcol,1);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
     result = VarTypeChk(Mcol,0);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
*/
     // get min and max values of the A and B factors
     minA = 1000;
     maxA = -1000;
     minB = 1000;
     maxB = -1000;
     for (i = 1; i <= NoCases; i++)
     {
         ivalue = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         //result = GetValue(i,Acol,intvalue,dblvalue,strvalue);
         //if (result == 1) ivalue = 0;
         //else ivalue = intvalue;
         if (ivalue < minA) minA = ivalue;
         if (ivalue > maxA) maxA = ivalue;
         ivalue = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         //result = GetValue(i,Bcol,intvalue,dblvalue,strvalue);
         //if (result == 1) ivalue = 0;
         //else ivalue = intvalue;
         if (ivalue < minB) minB = ivalue;
         if (ivalue > maxB) maxB = ivalue;
     }
     rangeA = maxA - minA + 1;
     rangeB = maxB - minB + 1;
     NoSubjects = NoCases / (rangeA * rangeB); // no. of unique subjects

     // allocate memory for arrays
     GetDblMatMem(SbyASums,NoSubjects,rangeA);
     GetDblMatMem(SbyBSums,NoSubjects,rangeB);
     GetDblMatMem(AbyBSums,rangeA,rangeB);
     GetDblVecMem(SSums,NoSubjects);
     GetDblVecMem(ASums,rangeA);
     GetDblVecMem(BSums,rangeB);
     GetDblVecMem(Means,rangeA*rangeB);

     // Initialize arrays
     for (i = 0; i < NoSubjects; i++)
     {
         for (j = 0; j < rangeA; j++)
         SSums[i] = 0.0;
     }
     for (i = 0; i < NoSubjects; i++)
     {
         for (j = 0; j < rangeA; j++) SbyASums[i][j] = 0.0;
         for (k = 0; k < rangeB; k++) SbyBSums[i][k] = 0.0;
     }
     for (j = 0; j < rangeA; j++)
         for (k = 0; k < rangeB; k++)
             AbyBSums[j][k] = 0.0;
     for (j = 0; j < rangeA; j++) ASums[j] = 0.0;
     for (k = 0; k < rangeB; k++) BSums[k] = 0.0;
     TotalSum = 0.0;
     SSTotal = 0.0;

     // Get measurement scores and store them
     for (i = 1; i <= NoCases; i++)
     {
         row = floor(StrToFloat(MainForm->Grid->Cells[Acol][i]));
         col = floor(StrToFloat(MainForm->Grid->Cells[Bcol][i]));
         subject = StrToInt(MainForm->Grid->Cells[Scol][i]);
         dvalue = StrToFloat(MainForm->Grid->Cells[Mcol][i]);
         //result = GetValue(i,Mcol,intvalue,dblvalue,strvalue);
         //if (result == 1) dvalue = 0.0;
         //else dvalue = dblvalue;
         subject = subject - 1;
         row = row - minA;
         col = col - minB;
         SbyASums[subject][row] += dvalue;
         SbyBSums[subject][col] += dvalue ;
         AbyBSums[row][col] += dvalue;
         SSums[subject] += dvalue;
         ASums[row] += dvalue;
         BSums[col] += dvalue;
         TotalSum += dvalue;
         SSTotal += (dvalue * dvalue);
     }

     FrmOutPut->RichOutPut->Clear();
     //  Get terms a-f from Quinn McNemar "Psychological Statistics", page 366
     //  row (subjects) by Factor A (term a):
     terma = 0.0;
     for (i = 0; i < NoSubjects; i++)
         for (k = 0; k < rangeB; k++)
             terma += (SbyBSums[i][k]*SbyBSums[i][k]);
     terma *= (double) (NoSubjects * rangeB);
     terma -= (TotalSum * TotalSum);
     terma /= (double) (NoSubjects * rangeA * rangeB);

     // row (subjects by Factor B (term b)
     termb = 0.0;
     for (i = 0; i < NoSubjects; i++)
         for (j = 0; j < rangeA; j++)
             termb += (SbyASums[i][j]*SbyASums[i][j]);
//     sprintf(outline,"initial termb = %10.3f",termb);
//     FrmOutPut->RichOutPut->Lines->Add(outline);
     termb *= (double) (NoSubjects * rangeA);
     termb -= (TotalSum * TotalSum);
     termb /= (double) (NoSubjects * rangeA * rangeB);

     // Factor a by Factor B (term c)
     termc = 0.0;
     for (j = 0; j < rangeA; j++)
         for (k = 0; k < rangeB; k++)
             termc += (AbyBSums[j][k]*AbyBSums[j][k]);
     termc *= (double) (rangeA * rangeB);
     termc -= (TotalSum * TotalSum);
     termc /= (double) (NoSubjects * rangeA * rangeB);

     // between subjects (term d)
     termd = 0.0;
     for (i = 0; i < NoSubjects; i++) termd += (SSums[i]*SSums[i]);
     termd *= (double) NoSubjects;
     termd -= (TotalSum * TotalSum);
     termd /= (double) (NoSubjects * rangeA * rangeB);

     // between Factor A (term e)
     terme = 0.0;
     for (j = 0; j < rangeA; j++) terme += (ASums[j] * ASums[j]);
     terme *= (double) rangeA;
     terme -= (TotalSum * TotalSum);
     terme /= (double) (NoSubjects * rangeA * rangeB);

     // between Factor B (term f)
     termf = 0.0;
     for (k = 0; k < rangeB; k++) termf += (BSums[k] * BSums[k]);
     termf *= (double) rangeB;
     termf -= (TotalSum * TotalSum);
     termf /= (double) (NoSubjects * rangeA * rangeB);

     // subjects by Factor A interaction (termg)
     termg = termb - termd - terme;

     // subjects by Factor B interaction (termh)
     termh = terma - termd - termf;

     // Factor A by Factor B interaction
     termi = termc - terme - termf;

     // Total sum of squares
     SSTotal = SSTotal - ((TotalSum * TotalSum) / (double) NoCases);

     // Subject by Factor A by Factor B interaction
     termj = SSTotal - (termd + terme + termf + termg + termh + termi);

     // show output
     int dfs = NoSubjects - 1;
     int dfa = rangeA - 1;
     int dfb = rangeB - 1;
     int dfab = dfa * dfb;
     int dfas = dfa * dfs;
     int dfbs = dfb * dfs;
     int dfabs = dfa * dfb * dfs;
     int dft = NoCases - 1;
     double mss = termd / dfs;
     double msa = terme / (double) dfa;
     double msb = termf / (double) dfb;
     double msab = termi / (double) dfab;
     double msas = termg / dfas;
     double msbs = termh / dfbs;
     double msabs = termj / dfabs;
     double fa = msa / msas;
     double fb = msb / msbs;
     double fab = msab / msabs;

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("-------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE           DF          SS          MS         F     Prob.>F");
     FrmOutPut->RichOutPut->Lines->Add("-------------------------------------------------------------------");
     sprintf(outline,"Factor A          %2d     %10.3f  %10.3f   %8.3f  %5.3f", dfa,terme,msa,fa,ftest(dfa,dfas,fa));
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Factor B          %2d     %10.3f  %10.3f   %8.3f  %5.3f", dfb,termf,msb,fb,ftest(dfb,dfbs,fb));
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Subjects          %2d     %10.3f  %10.3f",dfs,termd,mss);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"A x B Interaction %2d     %10.3f  %10.3f   %8.3f  %5.3f",dfab,termi,msab,fab,ftest(dfab,dfabs,fab));
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"A x S Interaction %2d     %10.3f  %10.3f",dfas,termg,msas);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"B x S Interaction %2d     %10.3f  %10.3f",dfbs,termh,msbs);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"A x B x S Inter.  %2d     %10.3f  %10.2f",dfabs,termj,msabs);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("-------------------------------------------------------------------");
     sprintf(outline,"Total             %2d     %10.3f",dft,SSTotal);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("-------------------------------------------------------------------");

     // print group means
     int pair = 0;
//     int nopairs = 0;
     double contrast;
     double mean1, mean2;
     for (i = 0; i < rangeA; i++)
     {
         for (j = 0; j < rangeB; j++)
         {
             mean1 = AbyBSums[i][j] / (double) NoSubjects;
             sprintf(outline,"Group %d : Mean for cell A %d and B %d = %10.3f",pair+1,i+1,j+1,mean1);
             FrmOutPut->RichOutPut->Lines->Add(outline);
             pair++;
         }
     }
/*
     nopairs = pairs;
     pair = 0;
     row = 0;
     col = 0;
     for (i = 0; i < rangeA; i++)
     {
         for (j = 0; j < rangeB; j++)
         {
             row = i * rangeA;
             col = row + j;
             mean1 = Means[row]
             mean2 = Means[ccl];
             contrast = mean1 - mean2;
             sprintf(outline,"PAIR %d: Factor A Group %d Mean = %10.3f, Factor B Group %d Mean = %10.3f, Difference = %10.3f",
                  pair+1,row+1,mean1,col+1,mean2,contrast);
             FrmOutPut->RichOutPut->Lines->Add(outline);
             pair++;
         }
     }
*/
     // Plot means if elected
     if (PlotAChk->Checked)
     {
        double *ColMeans;
        ColMeans = new double[rangeA];
        for (i = 0; i < rangeA; i++) ColMeans[i] = ASums[i] / (double) (rangeB * NoSubjects);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Means for Factor A");
        for (i = 0; i < rangeA; i++)
        {
            sprintf(outline,"Group %d Mean = %10.3f",i+1,ColMeans[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        GetDblMatMem(GraphForm->Xpoints,1,rangeA);
        GetDblMatMem(GraphForm->Ypoints,1,rangeA);
        // Get maximum mean
        double MaxMean = 0.0;
        for (int i = 0; i < rangeA; i++)
            if (ColMeans[i] > MaxMean) MaxMean = ColMeans[i];
        {
            for (int j = 0; j < rangeA; j++)
            {
                GraphForm->Ypoints[0][j] = ColMeans[j];
                GraphForm->Xpoints[0][j] = j+1;
            }
        }
        GraphForm->nosets = 1;
        GraphForm->nbars = rangeA;
        GraphForm->Heading = "Factor A Means";
        GraphForm->XTitle = "COLUMN";
        GraphForm->YTitle = "VALUE";
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = false;
        GraphForm->miny = 0.0;
        GraphForm->maxy = MaxMean;
        GraphForm->GraphType = OptionsBox->ItemIndex;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clBlack;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowBackWall = true;
        GraphForm->ShowModal();
        ClearDblMatMem(GraphForm->Ypoints,1);
        ClearDblMatMem(GraphForm->Xpoints,1);
        delete[] ColMeans;
     }

     if (PlotBChk->Checked)
     {
        double *ColMeans;
        ColMeans = new double[rangeB];
        for (i = 0; i < rangeB; i++) ColMeans[i] = BSums[i] / (double) (rangeA * NoSubjects);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Means for Factor B");
        for (i = 0; i < rangeB; i++)
        {
            sprintf(outline,"Group %d Mean = %10.3f",i+1,ColMeans[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        GetDblMatMem(GraphForm->Xpoints,1,rangeB);
        GetDblMatMem(GraphForm->Ypoints,1,rangeB);
        // Get maximum mean
        double MaxMean = 0.0;
        for (int i = 0; i < rangeB; i++)
            if (ColMeans[i] > MaxMean) MaxMean = ColMeans[i];
        {
            for (int j = 0; j < rangeB; j++)
            {
                GraphForm->Ypoints[0][j] = ColMeans[j];
                GraphForm->Xpoints[0][j] = j+1;
            }
        }
        GraphForm->nosets = 1;
        GraphForm->nbars = rangeB;
        GraphForm->Heading = "Factor B Means";
        GraphForm->XTitle = "COLUMN";
        GraphForm->YTitle = "VALUE";
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = false;
        GraphForm->miny = 0.0;
        GraphForm->maxy = MaxMean;
        GraphForm->GraphType = OptionsBox->ItemIndex;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clBlack;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowBackWall = true;
        GraphForm->ShowModal();
        ClearDblMatMem(GraphForm->Ypoints,1);
        ClearDblMatMem(GraphForm->Xpoints,1);
        delete[] ColMeans;
     }

     if (PlotABChk->Checked)
     {
        double **ColMeans;
        GetDblMatMem(ColMeans,rangeA,rangeB);
        for (i = 0; i < rangeA; i++)
        {
            for (j = 0; j < rangeB; j++)
            {
                ColMeans[i][j] = AbyBSums[i][j] / (double) (NoSubjects);
            }
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        GetDblMatMem(GraphForm->Xpoints,1,rangeB);
        GetDblMatMem(GraphForm->Ypoints,rangeA,rangeB);
        // Get maximum mean
        double MaxMean = 0.0;
        for (i = 0; i < rangeA; i++)
        {
            cellstring = MainForm->Grid->Cells[Acol][0] + " " + IntToStr(i+1);
            GraphForm->SetLabels[i] = cellstring;
            for (j = 0; j < rangeB; j++)
            {
                if (ColMeans[i][j] > MaxMean) MaxMean = ColMeans[i][j];
                GraphForm->Ypoints[i][j] = ColMeans[i][j];
            }
        }
        for (j = 0; j < rangeB; j++) GraphForm->Xpoints[0][j] = j+1;
        GraphForm->nosets = rangeA;
        GraphForm->nbars = rangeB;
        GraphForm->Heading = "Factor A x Factor B";
        GraphForm->XTitle = "Factor B";
        GraphForm->YTitle = "Mean";
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = false;
        GraphForm->miny = 0.0;
        GraphForm->maxy = MaxMean;
        GraphForm->GraphType = OptionsBox->ItemIndex;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clBlack;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowBackWall = true;
        GraphForm->ShowModal();
        ClearDblMatMem(GraphForm->Ypoints,rangeA);
        ClearDblMatMem(GraphForm->Xpoints,1);
        ClearDblMatMem(ColMeans,rangeA);
     }

     // Do post-hoc tests if elected
     if (PostHocChk->Checked)
     {
       row = 0;
       double alpha = StrToFloat(SigLevelEdit->Text);
       NoSelected = rangeA * rangeB; // total number of cells
       double *group_total, *group_count;
       group_total = new double[NoSelected];
       group_count = new double[NoSelected];
       for (i = 0; i < rangeA; i++)
       {
           for (j = 0; j < rangeB; j++)
           {
               group_count[row] = (double) NoSubjects;
               group_total[row] = AbyBSums[i][j];
               row++;
           }
       }
       TUKEY(msabs,dfabs,NoSubjects,group_total,group_count,1,NoSelected,alpha);

       row = 0;
       for (i = 0; i < rangeA; i++)
       {
           for (j = 0; j < rangeB; j++)
           {
               group_count[row] = (double) NoSubjects;
               group_total[row] = (double) AbyBSums[i][j];
               row++;
           }
       }
       TUKEY_KRAMER(msabs,dfabs,NoSubjects,group_total,group_count,1,NoSelected,alpha);

       row = 0;
       for (i = 0; i < rangeA; i++)
       {
           for (j = 0; j < rangeB; j++)
           {
               group_count[row] = (double) NoSubjects;
               group_total[row] = (double) AbyBSums[i][j];
               row++;
           }
       }
       TUKEYBTEST(msabs,dfabs,group_total,group_count,1,NoSelected,NoSubjects,alpha);

       row = 0;
       for (i = 0; i < rangeA; i++)
       {
           for (j = 0; j < rangeB; j++)
           {
               group_count[row] = (double) NoSubjects;
               group_total[row] = (double) AbyBSums[i][j];
               row++;
           }
       }

       SCHEFFETEST(msabs,group_total,group_count,1,NoSelected,NoSubjects*NoSelected,alpha);

       row = 0;
       for (i = 0; i < rangeA; i++)
       {
           for (j = 0; j < rangeB; j++)
           {
               group_count[row] = (double) NoSubjects;
               group_total[row] = (double) AbyBSums[i][j];
               row++;
           }
       }
       Newman_Keuls(msabs,dfabs,NoSubjects,group_total,group_count,1,NoSelected,alpha);

       delete[] group_count;
       delete[] group_total;
     }

     FrmOutPut->ShowModal();

     // Clean up the memory
     ClearDblVecMem(BSums);
     ClearDblVecMem(ASums);
     ClearDblVecMem(SSums);
     ClearDblMatMem(AbyBSums,rangeA);
     ClearDblMatMem(SbyBSums,NoSubjects);
     ClearDblMatMem(SbyASums,NoSubjects);
     ClearIntVecMem(ColNoSelected);

}
//---------------------------------------------------------------------------
