//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "math.h"
#include "Printers.hpp"
#include "MemMgrUnit.h"
#include "GraphUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGraphForm *GraphForm;
//---------------------------------------------------------------------------
__fastcall TGraphForm::TGraphForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGraphForm::FormResize(TObject *Sender)
{
     Invalidate();
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Bar2D(TComponent* Owner)
{
     int j, x1, y1, x2, y2, bwidth, xpos;
     double yprop, ydist;
     TPoint points[4];

     MakeXAxis(this);
     MakeYAxis(this);

     //   Make bar for each y data point
     for (j = 1; j <=NoBars; j++)
     {
          Image1->Canvas->Brush->Color = Colors[j % 12];
          bwidth = ceil(XProp * BarWidth);
          xpos = XStart + (BarWidth * j) - (BarWidth / 2);
          x1 = xpos - (bwidth / 2);
          x2 = x1 + bwidth;
          y1 = YStart;
          if (YMax - YMin > 0)
             yprop = (Ypoints[0][j-1] - YMin) / (YMax - YMin);
          else if (YMax > 0) yprop = 1.0;
          else yprop = 0;
          ydist = yprop * YAxisLength;
          y2 = YStart - ceil(ydist);
          points[0] = Point(x1,y1);
          points[1] = Point(x2,y1);
          points[2] = Point(x2,y2);
          points[3] = Point(x1,y2);
          Image1->Canvas->Polygon(points,3);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Bar3D(TComponent* Owner)
{
     int i, j, x1, x2, x3, x4, y1, y2, y3, y4, triheight, bwidth;
     double yprop;
     int yoffset, xoffset, xpos, ydist, triwidth;
     TPoint points[4];

     Walls(this); // create left and bottom wall and axes
     Image1->Canvas->Brush->Color = BackColor;
     MakeXAxis(this);
     MakeYAxis(this);
     bwidth = ceil(XProp * BarWidth);
     triwidth = ceil(bwidth * cos(RadAngle));
     triheight = ceil(bwidth * sin(RadAngle));
     triheight = triheight / 2; // scale down depth of view
     for (i = NSets; i >= 1; i--)
     {
          xoffset = triwidth * (i - 1);
          yoffset = triheight * (i - 1);
          for (j = 1; j <= NoBars;j++)
          {
               Image1->Canvas->Brush->Color = Colors[j % 12];
               xpos = XStart + (BarWidth * j) - (BarWidth / 2);
               x1 = xpos - (bwidth / 2);
               x2 = x1 + bwidth;
               y1 = YStart;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               ydist = ceil(yprop * YAxisLength);
               y2 = YStart - ceil(ydist);
               x1 = x1 + xoffset;
               x2 = x2 + xoffset;
               y1 = y1 - yoffset;
               y2 = y2 - yoffset;
               // draw face
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y1);
               points[2] = Point(x2,y2);
               points[3] = Point(x1,y2);
               Image1->Canvas->Polygon(points,3);
//               Image1->Canvas->Polygon([Point(x1,y1),Point(x2,y1),Point(x2,y2),Point(x1,y2)]);
               // draw side
               x1 = x2;
               x2 = x1 + triwidth;
               y2 = y1 - triheight;
               y3 = y1 - ceil(ydist);
               y4 = y2 - ceil(ydist);
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y2);
               points[2] = Point(x2,y4);
               points[3] = Point(x1,y3);
               Image1->Canvas->Polygon(points,3);
//               Image1->Canvas->Polygon([Point(x1,y1),Point(x2,y2),Point(x2,y4),Point(x1,y3)]);
               // draw top
               x1 = xpos - (bwidth / 2) + xoffset;
               x2 = x1 + bwidth;
               x3 =  x2 + triwidth;
               x4 = x1 + triwidth;
               y1 = YStart - yoffset - ceil(ydist);
               y2 = y1 - triheight;
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y1);
               points[2] = Point(x3,y2);
               points[3] = Point(x4,y2);
               Image1->Canvas->Polygon(points,3);
//               Image1->Canvas->Polygon([Point(x1,y1),Point(x2,y1),Point(x3,y2),Point(x4,y2)]);
          }
          x1 = XStart + XAxisLength + xoffset;
          y1 = YStart - triheight * i;
          Image1->Canvas->Brush->Color = clWhite;
          Image1->Canvas->TextOut(x1,y1,SetLabels[i]);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Pie2D(TComponent* Owner)
{

   int i, x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, radius;
   double yprop, xcenter, ycenter, Total, radians, cum;
   AnsiString value;
   char outline[121];

   xcenter = ImageWidth / 2;
   ycenter = ImageHeight / 2;

   // get the total for obtaining proportions that each y point is of the total
   Total = 0.0;
   cum = 0.0;
   radius = ceil(ycenter) - YOffset;
   x1 = ImageWidth / 2 - Image1->Canvas->TextWidth(XTitle) / 2;
   Image1->Canvas->TextOut(x1,YStart + 25,XTitle);
   x1 = ceil(xcenter-radius); // left of rectangle
   y1 = ceil(ycenter-radius); // top of rectangle
   x2 = ceil(xcenter + radius); // right of rectangle
   y2 = ceil(ycenter + radius); // bottom of rectangle
   x3 = x2;
   y3 = ceil(ycenter);
   for (i = 1; i <= NoBars; i++) Total = Total + Ypoints[0][i-1];

   // plot an arc corresponding to each proportion starting at radian 0
   for (i = 1; i <= NoBars; i++)
   {
        yprop = Ypoints[0][i-1] / Total;
        cum = cum + yprop;
        radians = cum * 2 * M_PI;
        x4 = ceil(xcenter + radius * cos(radians));
        y4 = ceil(ycenter - (radius * sin(radians)));
        Image1->Canvas->Brush->Color = Colors[i % 12];
        if (yprop > 0.0)
        {
           Image1->Canvas->Pie(x1,y1,x2,y2,x3,y3,x4,y4);
           radians = (cum - (yprop / 2.0)) * 2.0 * M_PI;
           x5 = ceil(xcenter + radius * cos(radians));
           y5 = ceil(ycenter - radius * sin(radians));
           Image1->Canvas->MoveTo(x5,y5);
           if (x5 >= ceil(xcenter)) x6 = x5 + 20;
           else x6 = x5 - 20;
           if (y5 >= ceil(ycenter)) y6 = y5 + 20;
           else y6 = y5 - 20;
           Image1->Canvas->LineTo(x6,y6);
           Image1->Canvas->Brush->Color = BackColor;
           sprintf(outline,"%8.5g",Xpoints[0][i-1]);
           value = outline;
           Image1->Canvas->TextOut(x6,y6,value);
           if (x5 >= ceil(xcenter)) x6 = x5 - 20;
           else x6 = x5 + 20;
           if (y5 >= ceil(ycenter)) y6 = y5 - 20;
           else y6 = y5 + 20;
           sprintf(outline,"%4.2f",yprop * 100.0);
           value = outline;
           value = value + '%';
           Image1->Canvas->TextOut(x6,y6,value);
           x3 = x4;
           y3 = y4;
        }
   }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Pie3D(TComponent* Owner)
{

   int i, x1, y1, x2, y2, x3, y3, x4, y4, x5, y5, x6, y6, radius;
   double yprop, xcenter, ycenter, Total, radians, midradians, cum;
   AnsiString value;
   char outline[121];

   ycenter = ImageHeight / 2;
   // get the total for obtaining proportions that each y point is of the total
   Total = 0.0;
   cum = 0.0;
   radius = ceil(ycenter) - YOffset;
   x1 = ImageWidth / 2 - Image1->Canvas->TextWidth(XTitle) / 2;
   Image1->Canvas->TextOut(x1,YStart + 25,XTitle);
   for (i = 1; i <= NoBars; i++) Total = Total + Ypoints[0][i-1];
   // plot an arc corresponding to each proportion starting at radian 0
   for (i = 1; i <= NoBars; i++)
   {
        xcenter = ImageWidth / 2;
        ycenter = ImageHeight / 2;
        yprop = Ypoints[0][i-1] / Total;
        cum = cum + yprop;
        radians = cum * 2.0 * M_PI;
        midradians = (cum - (yprop / 2.0)) * 2.0 * M_PI;
        x5 = ceil(xcenter + radius * cos(midradians));
        y5 = ceil(ycenter - radius * sin(midradians));
        // explode pie by shifting slices away from center
        if (x5 >= ceil(xcenter)) xcenter = xcenter + 10;
        else xcenter = xcenter - 10;
        if (y5 >= ceil(ycenter)) ycenter = ycenter + 10;
        else ycenter = ycenter - 10;
        x1 = ceil(xcenter-radius); // left of rectangle
        y1 = ceil(ycenter-radius); // top of rectangle
        x2 = ceil(xcenter + radius); // right of rectangle
        y2 = ceil(ycenter + radius); // bottom of rectangle
        midradians = (cum - yprop ) * 2.0 * M_PI;
        x3 = ceil(xcenter + radius * cos(midradians));
        y3 = ceil(ycenter - radius * sin(midradians));
        x4 = ceil(xcenter + radius * cos(radians));
        y4 = ceil(ycenter - (radius * sin(radians)));
        Image1->Canvas->Brush->Color = Colors[i % 12];
        if (yprop > 0.0)
        {
           Image1->Canvas->Pie(x1,y1,x2,y2,x3,y3,x4,y4);
           radians = (cum - (yprop / 2.0)) * 2.0 * M_PI;
           x5 = ceil(xcenter + radius * cos(radians));
           y5 = ceil(ycenter - radius * sin(radians));
           Image1->Canvas->MoveTo(x5,y5);
           if (x5 >= ceil(xcenter)) x6 = x5 + 20;
           else x6 = x5 - 20;
           if (y5 >= ceil(ycenter)) y6 = y5 + 20;
           else y6 = y5 - 20;
           Image1->Canvas->LineTo(x6,y6);
           Image1->Canvas->Brush->Color = BackColor;
           sprintf(outline,"%8.5g",Xpoints[0][i-1]);
           value = outline;
           Image1->Canvas->TextOut(x6,y6,value);
           if (x5 >= ceil(xcenter)) x6 = x5 - 20;
           else x6 = x5 + 20;
           if (y5 >= ceil(ycenter)) y6 = y5 - 20;
           else y6 = y5 + 20;
           sprintf(outline,"%4.2f",yprop * 100.0);
           value = outline;
           value = value + '%';
           Image1->Canvas->TextOut(x6,y6,value);
        }
   }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Line2D(TComponent* Owner)
{
// This procedure draws lines for 1 or more sets (on top of each other if
//  multiple sets)

     int i, j, x1, y1, x2, y2, xpos;
     double yprop, ydist;

     MakeXAxis(this);
     MakeYAxis(this);
     // Make lines for each set of y data point
     for (i = NSets; i >= 1; i--)
     {
          Image1->Canvas->Pen->Color = Colors[i % 12];
          x1 = XStart + BarWidth / 2;
          x2 = x1;
          yprop = (Ypoints[i-1][0] - YMin) / (YMax - YMin);
          ydist = yprop * YAxisLength;
          y1 = YStart - ceil(ydist);
          y2 = y1;
          Image1->Canvas->MoveTo(x1,y1);
          for (j = 2; j <= NoBars; j++)
          {
               xpos = XStart + (BarWidth * j) - (BarWidth / 2);
               x2 = xpos;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               ydist = yprop * YAxisLength;
               y2 = YStart - ceil(ydist);
               Image1->Canvas->LineTo(x2,y2);
          }
          Image1->Canvas->Pen->Color = clBlack;
          x1 = x2;
          y1 = y2;
          Image1->Canvas->Brush->Color = clWhite;
          Image1->Canvas->TextOut(x1,y1,SetLabels[i]);
     }
     Image1->Canvas->Pen->Color = clBlack;
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Line3D(TComponent* Owner)
{
// This procedure draws lines for multiple sets but staggers each set back and
//  to the right
     int i, j, x1, x2, x3, x4, y1, y2, y3, y4, triheight, bwidth;
     double yprop;
     int yoffset, xoffset, xpos, ydist, triwidth;
     int oldx1, oldy1;
     TPoint points[4];

     Walls(this); // create left and bottom wall and axes
     Image1->Canvas->Brush->Color = BackColor;
     MakeXAxis(this);
     MakeYAxis(this);
     bwidth = BarWidth;
     triwidth = ceil(bwidth * cos(RadAngle));
     triheight = ceil(bwidth * sin(RadAngle));
     triheight = triheight / 2; // scale down depth of view
     for (i = NSets; i >= 1; i--)
     {
          xoffset = triwidth * (i - 1);
          yoffset = triheight * (i - 1);
          Image1->Canvas->Brush->Color = Colors[j % 12];
          for (j = 1; j < NoBars;j++)
          {
               xpos = XStart + (BarWidth * j) - (BarWidth / 2);
               x1 = xpos - (bwidth / 2) + xoffset;
               x2 = x1 + bwidth;
               x3 =  x2 + triwidth;
               x4 = x1 + triwidth;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               ydist = ceil(yprop * YAxisLength);
               y1 = YStart - yoffset - ceil(ydist);
               y2 = y1 - triheight;
               yprop = (Ypoints[i-1][j] - YMin) / (YMax - YMin);
               ydist = ceil(yprop * YAxisLength);
               y3 = YStart - yoffset - ceil(ydist);
               y4 = y3 - triheight;
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y2);
               points[2] = Point(x3,y4);
               points[3] = Point(x4,y3);
               Image1->Canvas->Polygon(points,3);
          }
          x1 = XStart + XAxisLength + xoffset;
          y1 = YStart - triheight * i;
          Image1->Canvas->Brush->Color = clWhite;
          Image1->Canvas->TextOut(x1,y1,SetLabels[i]);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Plot2D(TComponent* Owner)
{

     int i, j, x1, y1, triheight, bwidth, yoffset, xoffset, xpos, ydist, triwidth;
     double yprop;

     Walls(this); // create left and bottom wall and axes
     Image1->Canvas->Brush->Color = BackColor;
     MakeXAxis(this);
     MakeYAxis(this);
     bwidth = ceil(XProp * BarWidth);
     triwidth = ceil(bwidth * cos(RadAngle));
     triheight = ceil(bwidth * sin(RadAngle));
     triheight = triheight / 2; // scale down depth of view
     // Make points for each set of y data point
     for (i = NSets; i >= 1; i--)
     {
          Image1->Canvas->Brush->Color = Colors[i % 12];
          xoffset = triwidth * (i - 1);
          yoffset = triheight * (i - 1);
          for (j = 1; j <= NoBars; j++)
          {
               xpos = XStart + (BarWidth * j) - (BarWidth / 2);
               x1 = xpos;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               ydist = ceil(yprop * YAxisLength);
               y1 = YStart - ceil(ydist);
               x1 = x1 + xoffset;
               y1 = y1 - yoffset;
               if (PtLabels)
               {
                    Image1->Canvas->Brush->Color = BackColor;
                    Image1->Canvas->TextOut(x1,y1,PointLabels[j-1]);
               }
               else Image1->Canvas->Ellipse(x1-5,y1-5,x1+5,y1+5);
          }
          Image1->Canvas->Pen->Color = clBlack;
          x1 = XStart + XAxisLength + xoffset;
          y1 = YStart - triheight * i;
          Image1->Canvas->Brush->Color = clWhite;
          Image1->Canvas->TextOut(x1,y1,SetLabels[i]);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Plot3D(TComponent* Owner)
{

     int i, j, x1, y1, triheight, bwidth, yoffset, xoffset, xpos, ydist, triwidth;
     double yprop;

     Walls(this); // create left and bottom wall and axes
//     Image1->Canvas->Brush->Color = BackColor;
     MakeXAxis(this);
     MakeYAxis(this);
     bwidth = ceil(XProp * BarWidth);
     triwidth = ceil(bwidth * cos(RadAngle));
     triheight = ceil(bwidth * sin(RadAngle));
     triheight = triheight / 2; // scale down depth of view
     // Make points for each set of y data point
     for (i = NSets; i >= 1; i--)
     {
          Image1->Canvas->Brush->Color = Colors[i % 12];
          xoffset = triwidth * (i - 1);
          yoffset = triheight * (i - 1);
          for (j = 1; j <= NoBars; j++)
          {
               xpos = XStart + (BarWidth * j) - (BarWidth / 2);
               x1 = xpos;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               ydist = ceil(yprop * YAxisLength);
               y1 = YStart - ceil(ydist);
               x1 = x1 + xoffset;
               y1 = y1 - yoffset;
               // change next to a ball by drawing multiple Ellipses aceil
               // vertical axis ?
               Image1->Canvas->Brush->Color = Colors[i % 12];
               Image1->Canvas->Ellipse(x1-5,y1-5,x1+5,y1+5);
               Image1->Canvas->Ellipse(x1-4,y1-5,x1+4,y1+5);
               Image1->Canvas->Ellipse(x1-3,y1-5,x1+3,y1+5);
               Image1->Canvas->Ellipse(x1-2,y1-5,x1+2,y1+5);
               Image1->Canvas->Brush->Color = clWhite;
               Image1->Canvas->TextOutA(x1+5,y1-5,PointLabels[j-1]);
          }
          Image1->Canvas->Pen->Color = clBlack;
          x1 = XStart + XAxisLength + xoffset;
          y1 = YStart - triheight * i;
          Image1->Canvas->Brush->Color = clWhite;
          Image1->Canvas->TextOut(x1,y1,SetLabels[i]);
     }
}
//---------------------------------------------------------------------------

void __fastcall  TGraphForm::MakeXAxis(TComponent* Owner)
{

     int i, valstart, valend, oldend, xpos;
     AnsiString value;
     char outline[121];

     Image1->Canvas->MoveTo(XStart,YStart);
     Image1->Canvas->LineTo(XEnd,YStart);
     oldend = 0;
     for (i = 1; i <= NoBars; i++)
     {
          xpos = XStart + (BarWidth * i) - (BarWidth / 2);
          Image1->Canvas->MoveTo(xpos,YStart);
          Image1->Canvas->LineTo(xpos,YStart + 5);
          sprintf(outline,"%6.5g",Xpoints[0][i-1]);
          value = outline;
          valstart = xpos - Image1->Canvas->TextWidth(value) / 2;
          valend = valstart + Image1->Canvas->TextWidth(value);
          if (valstart > oldend)
          {
             Image1->Canvas->TextOut(valstart,YStart+10,value);
             oldend = valend;
          }
     }
     xpos = ImageWidth / 2 - Image1->Canvas->TextWidth(XTitle) / 2;
     Image1->Canvas->TextOut(xpos,YStart + 25,XTitle);
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::MakeYAxis(TComponent* Owner)
{

     int ypos, i;
     double incr, value;
     AnsiString valstring;
     char outline[121];

     Image1->Canvas->MoveTo(XStart,YStart);
     Image1->Canvas->LineTo(XStart,YEnd);
     incr = (YMax - YMin) / 20.0;
     for (i = 1; i <= 21; i++)
     {
          value = YMin + (incr * (i-1));
          ypos = YStart - ((i-1) * YAxisLength / 20);
          Image1->Canvas->MoveTo(XStart,ypos);
          Image1->Canvas->LineTo(XStart-10,ypos);
          sprintf(outline,"%8.2f",value);
          valstring = outline;
          Image1->Canvas->TextOut(5, ypos,valstring);
     }
     ypos = YEnd - 10 - Canvas->TextHeight(YTitle);
     Image1->Canvas->TextOut(0,ypos,YTitle);
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::MakeHXaxis(TComponent* Owner)
{

     int xpos,i;
     double incr, value;
     AnsiString valstring;
     char outline[121];

     Image1->Canvas->MoveTo(XStart,YStart);
     Image1->Canvas->LineTo(XEnd,YStart);
     incr = (YMax - YMin) / 20.0;
     for (i = 1; i <= 21; i++)
     {
          value = YMin + (incr * (i-1));
          xpos = XStart + ((i-1) * XAxisLength / 20);
          Image1->Canvas->MoveTo(xpos,YStart);
          Image1->Canvas->LineTo(xpos,YStart + 5);
          sprintf(outline,"%6.2f",value);
          valstring = outline;
          Image1->Canvas->TextOut(xpos - Image1->Canvas->TextWidth(valstring) / 2,
               YStart + 10,FloatToStr(value));
     }
     xpos = XAxisLength / 2 - Image1->Canvas->TextWidth(YTitle) / 2;
     Image1->Canvas->TextOut(xpos,YStart + 20,YTitle);
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::MakeHYaxis(TComponent* Owner)
{

     int i, ypos;
     AnsiString value;
     char outline[121];

     Image1->Canvas->MoveTo(XStart,YStart);
     Image1->Canvas->LineTo(XStart,YEnd);
     for (i = 1; i <= NoBars; i++)
     {
          ypos = YStart - (BarWidth * i) + (BarWidth / 2);
          Image1->Canvas->MoveTo(XStart,ypos);
          Image1->Canvas->LineTo(XStart - 10,ypos);
          sprintf(outline,"%6.5g",Xpoints[0][i-1]);
          value = outline;
          Image1->Canvas->TextOut(XStart-10-Image1->Canvas->TextWidth(value),
              ypos,value);
     }
     ypos = YEnd;
     Image1->Canvas->TextOut(0,ypos,XTitle);
}
//---------------------------------------------------------------------------

double __fastcall TGraphForm::DegToRad(double Deg, TComponent* Owner)
{
     return (Deg * M_PI / 180.0);
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::HBar2D(TComponent* Owner)
{
     int j, x1, y1, x2, y2, bwidth, ypos;
     double xdist, yprop;
     TPoint points[4];

     BarWidth = YAxisLength / NoBars;
     MakeHXaxis(this);
     MakeHYaxis(this);
     // Make bar for each y data point
     for (j = 1; j <= NoBars; j++)
     {
          Image1->Canvas->Brush->Color = Colors[j % 12];
          bwidth = ceil(XProp * BarWidth);
          ypos = YStart - (BarWidth * j) + (BarWidth / 2); // bar center
          y1 = ypos - (bwidth / 2);
          y2 = y1 + bwidth;
          x1 = XStart;
          yprop = (Ypoints[0][j-1] - YMin) / (YMax - YMin);
          xdist = yprop * XAxisLength;
          x2 = XStart + ceil(xdist);
          points[0] = Point(x1,y1);
          points[1] = Point(x2,y1);
          points[2] = Point(x2,y2);
          points[3] = Point(x1,y2);
          Image1->Canvas->Polygon(points,3);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::HBar3D(TComponent* Owner)
{

     int i, j, x1, x2, x3, x4, y1, y2, y3, y4, triheight, bwidth, ypos;
     double xdist, yprop;
     int yoffset, xoffset, triwidth;
     TPoint points[4];

     Walls(this); // create left and bottom wall and axes
     BarWidth = YAxisLength / NoBars;
     Image1->Canvas->Brush->Color = BackColor;
     MakeHXaxis(this);
     MakeHYaxis(this);
     bwidth = ceil(XProp * BarWidth);
     triwidth = ceil(bwidth * cos(RadAngle));
     triheight = ceil(bwidth * sin(RadAngle));
     triheight = triheight / 2; // scale down depth of view
     for (i = NSets; i >= 1; i--)
     {
          xoffset = triwidth * (i - 1);
          yoffset = triheight * (i - 1);
          // Make bar for each y data point
          for (j = 1; j <= NoBars; j++)
          {
               // do face
               Image1->Canvas->Brush->Color = Colors[j % 12];
               ypos = YStart - (BarWidth * j) + (BarWidth / 2); // bar center
               y1 = ypos - (bwidth / 2) - yoffset;
               y2 = y1 + bwidth;
               x1 = XStart + xoffset;
               yprop = (Ypoints[i-1][j-1] - YMin) / (YMax - YMin);
               xdist = yprop * XAxisLength;
               x2 = XStart + ceil(xdist) + xoffset;
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y1);
               points[2] = Point(x2,y2);
               points[3] = Point(x1,y2);
               Image1->Canvas->Polygon(points,3);
               // do side begin end of bar
               x1 = x2;
               x2 = x1 + triwidth;
               y1 = y2;
               y2 = y1 - triheight;
               y3 = y2 - bwidth;
               y4 = y1 - bwidth;
               points[0] = Point(x1,y1);
               points[1] = Point(x2,y2);
               points[2] = Point(x2,y3);
               points[3] = Point(x1,y4);
               Image1->Canvas->Polygon(points,3);
//               Image1->Canvas->Polygon([Point(x1,y1),Point(x2,y2),Point(x2,y3),Point(x1,y4)]);
               // do top of bar
               x3 = XStart + xoffset;
               x4 = x3 + triwidth;
               points[0] = Point(x3,y4);
               points[1] = Point(x1,y4);
               points[2] = Point(x2,y3);
               points[3] = Point(x4,y3);
               Image1->Canvas->Polygon(points,3);
//               Image1->Canvas->Polygon([Point(x3,y4),Point(x1,y4),Point(x2,y3),Point(x4,y3)]);
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::Walls(TComponent* Owner)
{

     int deep, triheight, x1, x2,x3, x4, y1, y2, y3, y4, bwide, xoffset;
     TPoint points[4];

     bwide = ceil(BarWidth * XProp);
     xoffset = ceil(bwide * cos(RadAngle));
     XAxisLength = XAxisLength - (NSets * xoffset); // new length of X Axis
     XEnd = XStart + XAxisLength;
     BarWidth = XAxisLength / NoBars; //Adjusted bar width
     xoffset = ceil(bwide * cos(RadAngle));
     deep = xoffset * NSets;
     triheight = ceil(bwide * sin(RadAngle) * NSets); // total height of additional y needed
     triheight = triheight / 2; // scale down depth of view
     YAxisLength = YAxisLength - triheight;
     YEnd = YStart - YAxisLength;
     // do left wall
     x1 = XStart;
     x2 = x1 + deep;
     y1 = YStart;
     y2 = YStart - triheight;
     y3 = YStart - YAxisLength - triheight;
     y4 = YEnd;
     Image1->Canvas->Brush->Color = WallColor;
     points[0] = Point(x1,y1);
     points[1] = Point(x2,y2);
     points[2] = Point(x2,y3);
     points[3] = Point(x1,y4);
     Image1->Canvas->Polygon(points,3);
//     Image1->Canvas->Polygon([Point(x1,y1),Point(x2,y2),Point(x2,y3),Point(x1,y4)]);
     // do floor
     x1 = XStart;
     x2 = XStart + deep;
     x3 = XEnd;
     x4 = XEnd + deep;
     y1 = YStart;
     y2 = YStart - triheight;
     Image1->Canvas->Brush->Color = FloorColor;
     points[0] = Point(x1,y1);
     points[1] = Point(x3,y1);
     points[2] = Point(x4,y2);
     points[3] = Point(x2,y2);
     Image1->Canvas->Polygon(points,3);
//     Image1->Canvas->Polygon([Point(x1,y1),Point(x3,y1),Point(x4,y2),Point(x2,y2)]);
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::FormShow(TObject *Sender)
{

     int i, j;

     Gtype = 10; // default type is a 2 dimension bar graph (value = 2)
     ImageWidth = Image1->Width;
     ImageHeight = Image1->Height;
     XOffset = ImageWidth / 10;
     YOffset = ImageHeight / 10;
     XStart = XOffset;
     XEnd = ImageWidth - XOffset;
     XAxisLength = XEnd - XStart;
     YStart = ImageHeight - YOffset;
     YEnd = YOffset;
     YAxisLength = YStart - YEnd;
     DegAngle = 45.0;
     RadAngle = DegToRad(DegAngle,this);
     TanAngle = tan(RadAngle);
     NoBars = nbars;
     NSets = nosets;
     XProp = barwideprop;
     BarWidth = XAxisLength / NoBars;
     Gtype = GraphType;
     Colors[1] = clRed;
     Colors[2] = clBlue;
     Colors[3] = clGreen;
     Colors[4] = clNavy;
     Colors[5] = clTeal;
     Colors[6] = clAqua;
     Colors[7] = clLime;
     Colors[8] = clFuchsia;
     Colors[9] = clGray;
     Colors[10] = clPurple;
     Colors[11] = clOlive;
     Colors[0] = clMaroon;
     // draw border around graph
     Image1->Canvas->Brush->Color = BackColor;
     Image1->Canvas->Rectangle(0,0,ImageWidth,ImageHeight);
     Image1->Canvas->TextOut(ImageWidth / 2 - Canvas->TextWidth(Heading)/2,0,Heading);
     GraphForm->Caption = Heading;
     if (AutoScale)
     {
          YMin = Ypoints[0][0];
          YMax = YMin;
          for (i = 1; i <= NSets; i++)
          {
               for (j = 1; j <= NoBars; j++)
               {
                      if (Ypoints[i-1][j-1] > YMax) YMax = Ypoints[i-1][j-1];
                      if (Ypoints[i-1][j-1] < YMin) YMin = Ypoints[i-1][j-1];
               }
          }
     }
     else
     {
         YMin = miny;
         YMax = maxy;
     }
     if (Gtype > 9)
     {
          Application->MessageBox("No graph type defined.","ERROR!",MB_OK);
          exit;
     }
     else
     {
          switch (Gtype)
          {
               case 0 : HBar2D(this); break;
               case 1 : HBar3D(this); break;
               case 2 : Bar2D(this); break;
               case 3 : Bar3D(this); break;
               case 4 : Pie2D(this); break;
               case 5 : Pie3D(this); break;
               case 6 : Line2D(this); break;
               case 7 : Line3D(this); break;
               case 8 : Plot2D(this); break;
               case 9 : Plot3D(this); break;
          }
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::SaveBtnClick(TObject *Sender)
{
     SaveDialog1->Filter = "BitMap File *.BMP|*.BMP";
     SaveDialog1->FilterIndex = 1;
     SaveDialog1->DefaultExt = "BMP";
     if (SaveDialog1->Execute())
     {
        Image1->Picture->SaveToFile(SaveDialog1->FileName);
     }
}
//---------------------------------------------------------------------------

void __fastcall TGraphForm::PrintBtnClick(TObject *Sender)
{
       TPrinter *Prntr = Printer();
       Prntr->Orientation = poPortrait;

       TRect r = Rect(20,20,Prntr->PageWidth-20,Prntr->PageHeight / 2 + 20);
       Prntr->BeginDoc();
       Prntr->Canvas->StretchDraw(r, Image1->Picture->Bitmap);
       Prntr->EndDoc();
}
//---------------------------------------------------------------------------



