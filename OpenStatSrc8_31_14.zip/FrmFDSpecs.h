//---------------------------------------------------------------------------
#ifndef FrmFDSpecsH
#define FrmFDSpecsH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
class TFDSpecs : public TForm
{
__published:	// IDE-managed Components
	TEdit *TxtVariable;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TEdit *TxtMin;
	TEdit *TxtMax;
	TEdit *TxtRange;
	TEdit *TxtIntSize;
	TEdit *TxtNoIntervals;
	TButton *BtnOK;
	TButton *BtnCancel;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
   void __fastcall TxtIntSizeKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:	// User declarations
public:		// User declarations
	__fastcall TFDSpecs(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFDSpecs *FDSpecs;
//---------------------------------------------------------------------------
#endif

   void FreqDist(void);
