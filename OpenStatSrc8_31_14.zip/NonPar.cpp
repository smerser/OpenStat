//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Binom.h"
#include "NonPar.h"
#include "MainUnit.h"
#include <stdio.h>
#include "Output.h"
#include <math.h>
#include "functions.h"
#include "ChiSqr.h"
#include "VarSelect.h"
#include "MatrixUnit.h"
//#include "KruskWall.h"
#include "DataFuncs.h"
#include <stdlib.h>
#include "GraphUnit.h"
#include "MemMgrUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;

//---------------------------------------------------------------------------
void printtable(double **obs, double **theor, double *rowtot,
     double *coltot, double grandtot, int *levels, double *minvalue,
     double *maxvalue, int row, int col)
{
    int i, j, start, endpt, maxcols, var1, var2;
    bool done;
    char outline[81];
    char value[81];

    var1 = row;
    var2 = col;
    sprintf(outline,"Analysis for %s by %s",
        MainForm->Grid->Cells[var1][0].c_str(),MainForm->Grid->Cells[var2][0].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    maxcols = 4;
    start = 1;
    done = false;
    while (!done)
    {
        endpt = start + maxcols - 1;
        if (endpt > levels[1]) endpt = levels[1];

        FrmOutPut->RichOutPut->Lines->Add("                    COLUMN");
        sprintf(outline,"       ");
        for (j = start; j <= endpt; j++)
        {
            sprintf(value,"%10d",j);
            strcat(outline,value);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("ROW");
/*
        sprintf(outline,"Values  ");
        for (j = start; j <= endpt; j++)
        {
            sprintf(value,"%10.0f",minvalue[1] + j - 1);
            strcat(outline,value);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
*/
        sprintf(outline,"          ");
        for (j = start; j <= endpt; j++) strcat(outline,"----------");
        strcat(outline," Row Total  Pcnt Tot");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (i = 0; i < levels[0]; i++)
        {
            sprintf(outline,"%3.0f",minvalue[0]+i);
            strcat(outline," FREQ  ");
            for (j = start; j <= endpt; j++)
            {
                sprintf(value," %9.0f",obs[i][j-1]);
                strcat(outline,value);
            }
            sprintf(value," %6.0f     %5.3f",rowtot[i],100.0 * rowtot[i] / grandtot);
            strcat(outline,value);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline," ROW PCNT ");
            for (j = start; j <= endpt; j++)
            {
                if (rowtot[i] > 0)
                {
                    sprintf(value," %9.3f",100.0 * obs[i][j-1] / rowtot[i]);
                    strcat(outline,value);
                }
                else
                {
                    strcat(outline,"          ");
                }
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline," COL PCNT ");
            for (j = start; j <= endpt; j++)
            {
                if (coltot[j-1] > 0)
                {
                    sprintf(value," %9.3f",100.0 * obs[i][j-1] / coltot[j-1]);
                    strcat(outline,value);
                }
                else
                {
                    strcat(outline,"          ");
                }
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline," TOT PCNT ");
            for (j = start; j <= endpt; j++)
            {
                sprintf(value," %9.3f",100.0 * obs[i][j-1] / grandtot);
                strcat(outline,value);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(outline,"    THEOR ");
            for (j = start; j <= endpt; j++)
            {
                sprintf(value," %9.3f",theor[i][j-1]);
                strcat(outline,value);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(outline,"          ");
            for (j = start; j <= endpt; j++) strcat(outline,"----------");
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
        } // next i
        sprintf(outline,"  COL TOT ");
        for (j = start; j <= endpt; j++)
        {
            sprintf(value," %9.0f",coltot[j-1]);
            strcat(outline,value);
        }
        sprintf(value,"%10.0f",grandtot);
        strcat(outline,value);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline," PCNT TOT ");
        for (j = start; j <= endpt; j++)
        {
            sprintf(value,"%9.3f ",100.0 * coltot[j-1] / grandtot);
            strcat(outline,value);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        if (endpt == levels[1]) done = true;
        else start = endpt + 1;
    } // end while not done
}
//-------------------------------------------------------------------------

double ProdSums(double N, double A)
{
    double Total = 0.0; // set equal to 1 if using actual values (commented out)
    double i;

//    for (i = A; i <= N; i++) Total *= i;
    for (i = A; i <= N; i++) Total = Total + log(i);
    Total = exp(Total);
    return (Total);
}
//------------------------------------------------------------------------

double combos(double X, double N)
{
    double Y, numerator, denominator;

    Y = N - X;
    if (Y > X)
    {
        numerator = ProdSums(N, Y + 1);
        denominator = ProdSums(X, 1);
    }
    else
    {
        numerator = ProdSums(N, X + 1);
        denominator = ProdSums(Y, 1);
    }
    return (numerator / denominator);
}
//------------------------------------------------------------------------

void binomial(void)
{
    double N, p, Q, Probability, z, A, b, CorrectedA, X, SumProb = 0.0;
    char outline[81];

    BinomFrm->CatAEdit->Text = "";
    BinomFrm->CatBEdit->Text = "";
    BinomFrm->PropAEdit->Text = "";
    BinomFrm->PlotChk->Checked = false;
    if (BinomFrm->ShowModal() == mrCancel) return;
    A = atof(BinomFrm->CatAEdit->Text.c_str());
    b = atof(BinomFrm->CatBEdit->Text.c_str());
    p = atof(BinomFrm->PropAEdit->Text.c_str());
    N = A + b;
    Q = 1.0 - p;

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Binomial Probability Test");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Frequency of %5.2f out of %5.2f observed",
            A, N);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"The theoretical proportion expected in category A was %5.3f",
            p);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"The test is for the probability of a value in category A as small or smaller");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"than that observed given the expected proportion.");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (N > 35) //Use normal distribution approximation
    {
        CorrectedA = A;
        if (A < N * p)  CorrectedA = A + 0.5;
        if (A > N * p)  CorrectedA = A - 0.5;
        z = (CorrectedA - N * p) / sqrt(N * p * Q);
        sprintf(outline,"Z value for Normal Distribution approximation = %5.3f",
                        z);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        Probability = zcumsimp(z);
        sprintf(outline,"Probability = %6.4f",Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Binomial Probability of %5.2f or less out of %5.2f = %6.4f",
                        A,N,Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Probability of more than %5.2f out of %5.2f = %6.4f",
                        A,N,1.0-Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("NOTE: For values > 35 the binomial is nearly a normal distribution.");
    }
    else //Use binomial fomula
    {
        for (X = 0; X <= A; X++)
        {
            Probability = combos(X, N) * pow(p,X) * pow(Q,(N - X));
            sprintf(outline,"Probability of %3.0f = %6.4f",X,Probability);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            SumProb = SumProb + Probability;
        }
        sprintf(outline,"Binomial Probability of %5.2f or less out of %5.2f = %6.4f",
                        A,N,SumProb);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Probability of more than %5.2f out of %5.2f = %6.4f",
                        A,N,1.0-SumProb);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();
    // plot binomial probabilities for 0 to N if elected
    if (BinomFrm->PlotChk->Checked)
    {
       if (N <= 35)
       {
           GetDblMatMem(GraphForm->Xpoints,1,N+1);
           GetDblMatMem(GraphForm->Ypoints,1,N+1);
           for (int i = 0; i <= N; i++) GraphForm->Xpoints[0][i] = (double)i;
           for (int i = 0; i <= N; i++)
           {
               Probability = combos(i, N) * pow(p,i) * pow(Q,(N - i));
               GraphForm->Ypoints[0][i] = Probability;
           }
           GraphForm->GraphType = 3;
           GraphForm->nosets = 1;
           GraphForm->nbars = N;
           GraphForm->BackColor = clYellow;
           GraphForm->WallColor = clBlue;
           GraphForm->FloorColor = clGray;
           GraphForm->Heading = "Binomial Distribution";
           GraphForm->XTitle = "Values";
           GraphForm->YTitle = "Probability";
           GraphForm->barwideprop = 0.5;
           GraphForm->AutoScale = true;
           GraphForm->ShowLeftWall = true;
           GraphForm->ShowRightWall = true;
           GraphForm->ShowBottomWall = true;
           GraphForm->ShowModal();
       }
       ClearDblMatMem(GraphForm->Xpoints,1);
       ClearDblMatMem(GraphForm->Ypoints,1);
    }
}
//--------------------------------------------------------------------------


void Concord(void)
{
    int i, j, k, index, No_Judges, No_Objects, col, ties, start, last, nocases;
    double Temp, TotalCorrect, JudgeCorrect, ChiSquare, Probability;
    double TotalRankSums, Concordance, AvgRankCorr, AvgTotalRanks,
           statistic = 0.0;
    double *temprank, *ObjRankSums, **scorearray;
    int *ColNoSelected, *tempindex;
    bool done;
    AnsiString cellstring;
    char outline[81];
    char value[81];

    No_Judges = NoCases;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    FrmVarSel->Caption = "Kendall's Coefficient of Concordance";
    FrmVarSel->ChkBox->Visible = false;
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        FrmVarSel->LstBoxVars->Items->Add(cellstring);
    }
    if(FrmVarSel->ShowModal() == mrCancel) return;

    // Allocate space for selected variable column no.s
    try  {
        ColNoSelected = new int[NoVariables];
        scorearray = new double *[No_Judges];
        for (i = 0; i < No_Judges; i++) scorearray[i] = new double[NoVariables];
        tempindex = new int[NoVariables];
        temprank = new double[NoVariables];
        ObjRankSums = new double[NoVariables];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in Concordance.","ALLOCATE ERROR!",MB_OK);
        FrmVarSel->ChkBox->Visible = true;
        goto cleanup;
    }

    No_Objects = FrmVarSel->LstBoxSelected->Items->Count;

    // get columns of variables selected
    for (i = 0; i < No_Objects; i++)
    {
        cellstring = FrmVarSel->LstBoxSelected->Items->Strings[i];
        for (index = 0; index < NoVariables; index++)
        {
            if (cellstring == MainForm->Grid->Cells[index+1][0])
                ColNoSelected[i] = index+1;
        }
    }

    //Read data from grid
    for (i = 0; i < No_Judges; i++) // rows
    {
        if (!ValidRecord(i+1,ColNoSelected,No_Objects)) continue;
        for (j = 0; j < No_Objects; j++)
        {
            col = ColNoSelected[j];
            scorearray[i][j] = atof(MainForm->Grid->Cells[col][i+1].c_str());
        }
    }

    //Rank the scores in the rows
    TotalCorrect = 0.0;
    for (i = 0; i < No_Judges; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,No_Objects)) continue;
        JudgeCorrect = 0.0;
        for (j = 0; j < No_Objects; j++)
        {
            tempindex[j] = j;
            temprank[j] = scorearray[i][j];
        }
        //Sort the temp arrays
        for (j = 0; j < No_Objects - 1; j++)
        {
            for (k = j + 1; k < No_Objects; k++)
            {
                if (temprank[j] > temprank[k])
                {
                    Temp = temprank[j];
                    temprank[j] = temprank[k];
                    temprank[k] = Temp;
                    index = tempindex[j];
                    tempindex[j] = tempindex[k];
                    tempindex[k] = index;
                }
            }
        }

        //Now convert temporary score array to ranks (correcting for ties)
        j = 0;
        while (j < No_Objects)
        {
            ties = 0;
            k = j;
            done = false;
            while (!done)
            {
                k++;
                if (k < No_Objects)
                {
                    if (temprank[j] == temprank[k]) ties++;
                }
                else done = true;
            }
            if (ties == 0.0)
            {
                temprank[j] = j+1;
                j++;
            }
            else
            {
                for (k = j; k < j + ties; k++)
                {
                    temprank[k] = double(j+1) + (double(ties) / 2.0);
                }
                j = j + ties + 1;
                ties = ties + 1;
                JudgeCorrect = JudgeCorrect + (pow(ties,3) - ties);
            }
        }

        //Now, restore ranks in their position equivalent to original scores
        for (j = 0; j < No_Objects; j++)
        {
            k = tempindex[j];
            scorearray[i][k] = temprank[j];
        }
        TotalCorrect += (JudgeCorrect / 12.0);
    }

    // Get actual no. of judges if filtering is turned on
    nocases = 0;
    for (i = 0; i < NoCases; i++)
        if (ValidRecord(i+1,ColNoSelected,No_Objects)) nocases++;

    //Calculate statistics
    statistic = 0.0;
    TotalRankSums = 0.0;
    for (j = 0; j < No_Objects; j++)
    {
        ObjRankSums[j] = 0.0;
        for (i = 0; i < No_Judges; i++) ObjRankSums[j] += scorearray[i][j];
        TotalRankSums += ObjRankSums[j];
    }
    AvgTotalRanks = TotalRankSums / double(No_Objects);
    for (j = 0; j < No_Objects; j++)
        statistic += pow((ObjRankSums[j] - AvgTotalRanks), 2);
    Concordance = statistic / ( (double(nocases * nocases) / 12.0) *
       (pow(No_Objects,3) - double(No_Objects)) -
       (double(nocases) * TotalCorrect) );
    AvgRankCorr = (double(nocases) * Concordance - 1.0) /
        (double(nocases - 1));
    ChiSquare = double(nocases) * Concordance * (double(No_Objects - 1));
    Probability = 1.0 - chisquaredprob(ChiSquare, No_Objects - 1);

    //Report results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Kendall's Coefficient of Concordance Analysis");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Ranks Assigned to Judge's Ratings of Objects");
    FrmOutPut->RichOutPut->Lines->Add("");

    for (i = 0; i < No_Judges; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,No_Objects)) continue;
        done = false;
        start = 0;
        last = 9;
        while (! done)
        {
            if (last > No_Objects) last = No_Objects;
            sprintf(outline,"Judge %3d",i+1);
            strcat(outline,"            Objects");
            FrmOutPut->RichOutPut->Lines->Add(outline);
            strcpy(outline," ");
            for (j = start; j < last; j++)
            {
                col = ColNoSelected[j];
                sprintf(value,"%8s",MainForm->Grid->Cells[col][0].c_str());
                strcat(outline,value);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            strcpy(outline," ");
            for (j = start; j < last; j++)
            {
                sprintf(value,"%8.4f",scorearray[i][j]);
                strcat(outline,value);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            if (last == No_Objects) done = true;
            else
            {
                start = last;
                last = start + 9;
            }
            strcpy(outline,"");
        } // while end
        FrmOutPut->RichOutPut->Lines->Add("");
    } // next i

    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sum of Ranks for Each Object Judged");
    done = false;
    start = 0;
    last = 9;
    while (! done)
    {
        if (last > No_Objects) last = No_Objects;
        FrmOutPut->RichOutPut->Lines->Add("            Objects");
        strcpy(outline," ");
        for (j = start; j < last; j++)
        {
            col = ColNoSelected[j];
            sprintf(value,"%8s",MainForm->Grid->Cells[col][0].c_str());
            strcat(outline,value);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline," ");
        for (j = start; j < last; j++)
        {
            sprintf(value,"%8.4f",ObjRankSums[j]);
            strcat(outline,value);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        if (last == No_Objects) done = true;
        else
        {
            start = last;
            last = start + 9;
        }
    }
    sprintf(outline,"Coefficient of concordance = %10.3f",Concordance);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Average Spearman Rank Correlation = %10.3f",AvgRankCorr);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Chi-Square Statistic = %8.3f",ChiSquare);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Probability of a larger Chi-Square = %6.4f",Probability);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    if (No_Objects < 7)
        FrmOutPut->RichOutPut->Lines->Add("Warning - Above Chi-Square is very approximate with only 7 variables!");
    FrmOutPut->ShowModal();
cleanup:
    delete[] ObjRankSums;
    delete[] temprank;
    delete[] tempindex;
    for (i = 0; i < No_Judges; i++) delete[] scorearray[i];
    delete[] scorearray;
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------


void qtest(void)
{
    int i, j, k;
    int *ColNoSelected;
    double R1, L1, L2, C1 = 0.0, g1, Q, g2, chiprob;
    AnsiString cellstring;
    char outline[81];

    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    FrmVarSel->Caption = "q test";
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        FrmVarSel->LstBoxVars->Items->Add(cellstring);
    }
    if (FrmVarSel->ShowModal() == mrCancel) return;
    FrmVarSel->ChkBox->Visible = true;
    k = FrmVarSel->LstBoxSelected->Items->Count;
    if (k == 0)
    {
        ShowMessage("ERROR!  Please select variables.");
        return;
    }

    // Allocate memory
    try  {
        ColNoSelected = new int[k];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Cochran Q test.","ERROR",MB_OK);
        return;
    }

    // Get column numbers and labels of variables selected
    for (i = 0; i < k; i++)
    {
        cellstring = FrmVarSel->LstBoxSelected->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
                ColNoSelected[i] = j+1;
        }
    }

    // Calculate results
    R1 = 0.0;
    L1 = 0.0;
    L2 = 0.0;
    g1 = 0.0;
    g2 = 0.0;
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,k)) continue;
        for (j = 0; j < k; j++)
        {
            int col = ColNoSelected[j];
            R1 += StrToFloat(MainForm->Grid->Cells[col][i+1]);
        }
        L1 += R1;
        L2 += (R1 * R1);
        R1 = 0.0;
    }
    for (j = 0; j < k; j++)
    {
        for (i = 0; i < NoCases; i++)
        {
            if (!ValidRecord(i+1,ColNoSelected,k)) continue;
            int col = ColNoSelected[j];
            C1 += StrToFloat(MainForm->Grid->Cells[col][i+1]);
        }
        g1 += C1;
        g2 += (C1 * C1);
        C1 = 0.0;
    }

    Q = ( double(k - 1) * (double(k) * g2 - (g1 * g1))) / (double(k) * L1 - L2);
    chiprob = 1.0 - chisquaredprob(Q, k - 1);

    //present results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Cochran Q Test for Related Samples");
    FrmOutPut->RichOutPut->Lines->Add("See pages 161-166 in S. Siegel's Nonparametric Statistics for the Behavioral Sciences");
    FrmOutPut->RichOutPut->Lines->Add("McGraw-Hill Book Company, New York, 1956");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Cochran Q Statistic = %6.3f",Q);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"which is distributed as chi-square with %d D.F. and probability = %6.4f",
            k-1, chiprob);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // Clean up the heap
    delete[] ColNoSelected;
}
//--------------------------------------------------------------------------

void signtest(void)
{
    int i,j,k;
    int *DifSigns, *ColNoSelected;
    double N, p, Q, Probability, z, A, b, NoDiff, CorrectedA, x1, x2,
           SumProb = 0.0, X, Temp;
    AnsiString cellstring;
    char outline[81];

    cellstring = FrmVarSel->Caption;
    FrmVarSel->Caption = "Sign Test: Select Two Matched Pair Variables";
    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        FrmVarSel->LstBoxVars->Items->Add(cellstring);
    }
    if (FrmVarSel->ShowModal() == mrCancel) return;
    FrmVarSel->Caption = cellstring;
    FrmVarSel->ChkBox->Visible = true;
    k = FrmVarSel->LstBoxSelected->Items->Count;
    if (k == 0)
    {
        ShowMessage("ERROR!  Please select variables.");
        return;
    }

    // Allocate memory
    try  {
        ColNoSelected = new int[k];
        DifSigns = new int[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Cochran Q test.","ERROR",MB_OK);
        return;
    }

    // Get column numbers and labels of variables selected
    for (i = 0; i < k; i++)
    {
        cellstring = FrmVarSel->LstBoxSelected->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
                ColNoSelected[i] = j+1;
        }
    }

    p = 0.5;
    Q = 0.5;

    // Get sign of difference between pairs '(-1 = - ; 0 = no difference; +1 = +
    A = 0.0;
    b = 0.0;
    NoDiff = 0.0;
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,k)) continue;
        int col1 = ColNoSelected[0];
        int col2 = ColNoSelected[1];
        x1 = StrToFloat(MainForm->Grid->Cells[col1][i+1]);
        x2 = StrToFloat(MainForm->Grid->Cells[col2][i+1]);
        if (x1 > x2)
        {
            DifSigns[i] = 1;
            A += 1.0;
        }
        if (x1 < x2)
        {
            DifSigns[i] = -1;
            b += 1.0;
        }
        if (x1 == x2)
        {
            DifSigns[i] = 0;
            NoDiff += 1.0;
        }
    }

    // Show results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Results for the Sign Test");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Frequency of %3.0f out of %d observed + sign differences.",
            A, NoCases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Frequency of %3.0f out of %d observed - sign differences.",
            b, NoCases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Frequency of %3.0f out of %d observed no differences.",
            NoDiff, NoCases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"The theoretical proportion expected for +'s or -'s is 0.5 ");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"The test is for the probability of the +'s or -'s (which ever is fewer)");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"as small or smaller than that observed given the expected proportion.");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    // Swap A and B around if A > B
    if (A > b)
    {
        Temp = A;
        A = b;
        b = Temp;
    }

    N = A + b;
    if (N > 25) // Use normal distribution approximation
    {
        CorrectedA = A;
        if (A < (N * p)) CorrectedA = A + 0.5;
        if (A > (N * p)) CorrectedA = A - 0.5;
        z = (CorrectedA - N * p) / sqrt(N * p * Q);
        sprintf(outline,"Z value for Normal Distribution approximation = %5.3f",
                z);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        Probability = normalprob(z);
        sprintf(outline,"Probability = %6.4f",Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    else // Use binomial fomula
    {
        for (X = 0; X <= A; X++)
        {
            Probability = combos(X, N) * pow(p,X) * pow(Q,(N - X));
            sprintf(outline,"Binary Probability of %3.0f = %6.4f", X, Probability);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            SumProb +=  Probability;
        }
        sprintf(outline,"Binomial Probability of %5.2f or smaller out of %5.2f = %6.4f",
                A, N, SumProb);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    FrmOutPut->ShowModal();

    // Clean up heap
    delete[] DifSigns;
    delete[] ColNoSelected;
}
//-------------------------------------------------------------------------

void Spearman(void)
{
    int i, j, k, itemp, NoTies, NoTieGroups, ncases = 0;
    int **index, *ColNoSelected;
    double Probability, sumsqrx, sumsqry, Temp, TieSum, Avg,
           t, SumT, r, z, sumdsqr;
    double **Ranks, **X, *d;
    AnsiString cellstring;
    char outline[81];

    cellstring = FrmVarSel->Caption;
    FrmVarSel->Caption = "Spearman: Select the two variables to correlate.";
    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        FrmVarSel->LstBoxVars->Items->Add(cellstring);
    }
    if (FrmVarSel->ShowModal() == mrCancel) return;
    FrmVarSel->Caption = cellstring;
    FrmVarSel->ChkBox->Visible = true;
    k = FrmVarSel->LstBoxSelected->Items->Count;
    if (k == 0)
    {
        ShowMessage("ERROR!  Please select variables.");
        return;
    }

    // Allocate memory
    try  {
        ColNoSelected = new int[k];
        Ranks = new double *[NoCases];
        for (i = 0; i < NoCases; i++) Ranks[i] = new double[2];
        index = new int *[NoCases];
        for (i = 0; i < NoCases; i++) index[i] = new int[2];
        X = new double *[NoCases];
        for (i = 0; i < NoCases; i++) X[i] = new double[2];
        d = new double[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Spearman Rank test.","ERROR",MB_OK);
        return;
    }

    // Get column numbers and labels of variables selected
    for (i = 0; i < k; i++)
    {
        cellstring = FrmVarSel->LstBoxSelected->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
                ColNoSelected[i] = j+1;
        }
    }

    // Get scores
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,k)) continue;
        int col1 = ColNoSelected[0];
        int col2 = ColNoSelected[1];
        X[ncases][0] = StrToFloat(MainForm->Grid->Cells[col1][i+1]);
        Ranks[ncases][0] = X[ncases][0];
        X[ncases][1] = StrToFloat(MainForm->Grid->Cells[col2][i+1]);
        Ranks[ncases][1] = X[ncases][1];
        index[ncases][0] = ncases;
        index[ncases][1] = ncases;
        ncases++;
    }

    // Rank the first variable
    for (i = 0; i < ncases-1; i++)
    {
        for (j = i+1; j < ncases; j++)
        {
            if (Ranks[i][0] > Ranks[j][0]) // swap
            {
                Temp = Ranks[i][0];
                Ranks[i][0] = Ranks[j][0];
                Ranks[j][0] = Temp;
                itemp = index[i][0];
                index[i][0] = index[j][0];
                index[j][0] = itemp;
                Temp = X[i][0];
                X[i][0] = X[j][0];
                X[j][0] = Temp;
            }
        }
    }

    // Assign ranks
    for (i = 0; i < ncases; i++) Ranks[i][0] = i+1;

    // Check for ties in each
    NoTieGroups = 0;
    SumT = 0.0;
    for (i = 0; i < ncases-1; i++)
    {
        j = i+1;
        TieSum = 0.0;
        NoTies = 0;
        while (j < ncases)
        {
            if (X[j][0] > X[i][0])  goto Check1;
            if (X[j][0] == X[i][0])
            {
                TieSum += Ranks[j][0];
                NoTies++;
            }
            j++;
        }
Check1:
        if (NoTies > 0) // at least one tie found
        {
            TieSum += Ranks[i][0];
            NoTies++;
            Avg = TieSum / double(NoTies);
            for (j = i; j < i+NoTies; j++) Ranks[j][0] = Avg;
            t = ( pow(NoTies,3) - NoTies) / 12.0;
            SumT += t;
            NoTieGroups += 1.0;
            i += (NoTies-1);
        }
    }
    sumsqrx = ( (pow(ncases,3) - ncases) / 12.0) - SumT;

    // reorder according to index of the case
    for (i = 0; i < ncases-1; i++)
    {
		  for (j = i+1; j < ncases; j++)
        {
            if (index[i][0] > index[j][0]) // swap
            {
            	itemp = index[i][0];
               index[i][0] = index[j][0];
               index[j][0] = itemp;
               Temp = Ranks[i][0];
               Ranks[i][0] = Ranks[j][0];
               Ranks[j][0] = Temp;
               Temp = X[i][0];
               X[i][0] = X[j][0];
               X[j][0] = Temp;
            }
        }
    }

    // Repeat sort for second variable
    for (i = 0; i < ncases-1; i++)
    {
        for (j = i+1; j < ncases; j++)
        {
            if (Ranks[i][1] > Ranks[j][1]) // swap
            {
                Temp = Ranks[i][1];
                Ranks[i][1] = Ranks[j][1];
                Ranks[j][1] = Temp;
                itemp = index[i][1];
                index[i][1] = index[j][1];
                index[j][1] = itemp;
                Temp = X[i][1];
                X[i][1] = X[j][1];
                X[j][1] = Temp;
            }
        }
    }

    // Assign ranks
    for (i = 0; i < ncases; i++)Ranks[i][1] = i+1;

    // Check for ties in each
    SumT = 0.0;
    NoTieGroups = 0;
    for (i = 0; i < ncases-1; i++)
    {
        j = i+1;
        TieSum = 0.0;
        NoTies = 0;
        while (j < ncases)
        {
            if (X[j][1] > X[i][1])  goto Check2;
            if (X[j][1] == X[i][1])
            {
                TieSum += Ranks[j][1];
                NoTies++;
            }
            j++;
        }
Check2:
        if (NoTies > 0) // at least one tie found
        {
            TieSum += Ranks[i][1];
            NoTies++;
            Avg = TieSum / double(NoTies);
            for (j = i; j < i+NoTies; j++) Ranks[j][1] = Avg;
            t = ( pow(NoTies,3) - NoTies) / 12.0;
            SumT += t;
            NoTieGroups += 1.0;
            i += (NoTies-1);
        }
    }
    sumsqry = ( (pow(ncases,3) - ncases) / 12.0) - SumT;

    // reorder according to index of the case
    for (i = 0; i < ncases-1; i++)
    {
		  for (j = i+1; j < ncases; j++)
        {
            if (index[i][1] > index[j][1]) // swap
            {
            	itemp = index[i][1];
               index[i][1] = index[j][1];
               index[j][1] = itemp;
               Temp = Ranks[i][1];
               Ranks[i][1] = Ranks[j][1];
               Ranks[j][1] = Temp;
               Temp = X[i][1];
               X[i][1] = X[j][1];
               X[j][1] = Temp;
            }
        }
    }
/*
    // Rearrange ranks into original score pair order
//    for (int k = 0; k < 2; k++)
//    {
        for (i = 0; i < NoCases - 1; i++)
        {
            if (!ValidRecord(ColNoSelected,k,i+1)) continue;
            for (j = i+1; j < NoCases; j++)
            {
                if (!ValidRecord(ColNoSelected,k,j+1)) continue;
                if (index[i][k] > index[j][k]) // swap
                {
                    itemp = index[i][0];
                    index[i][0] = index[j][0];
                    index[j][0] = itemp;
                    Temp = Ranks[i][0];
                    Ranks[i][0] = Ranks[j][0];
                    Ranks[j][0] = Temp;
                    Temp = Ranks[i][1];
                    Ranks[i][1] = Ranks[j][1];
                    Ranks[j][1] = Temp;
                }
            }
        }
//    }
*/
    // Calculate difference scores
    sumdsqr = 0.0;
    for (i = 0; i < ncases; i++)
    {
        d[i] = Ranks[i][0] - Ranks[i][1];
        sumdsqr += (d[i] * d[i]);
    }

    // Calculate corrected spearman rank correlation
    r = (sumsqrx + sumsqry - sumdsqr) / (2.0 * sqrt(sumsqrx * sumsqry));

    // Output the results
    FrmOutPut->RichOutPut->Clear();
    AnsiString label1 = MainForm->Grid->Cells[ColNoSelected[0]][0];
    AnsiString label2 = MainForm->Grid->Cells[ColNoSelected[1]][0];
    sprintf(outline,"Spearman Rank Correlation Between ");
    strcat(outline,label1.c_str());
    strcat(outline," & ");
    strcat(outline,label2.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Number of cases without missing values = %d",ncases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Observed scores, their ranks and differences between ranks");
    sprintf(outline,"%10s    Ranks %10s     Ranks Rank Difference",
            label1.c_str(), label2.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (i = 0; i < ncases; i++)
    {
        sprintf(outline,"%10.2f%10.2f%10.2f%10.2f%10.2f",
                X[i][0], Ranks[i][0], X[i][1], Ranks[i][1], d[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    sprintf(outline,"Spearman Rank Correlation = %6.3f",r);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    // Get actual no. of cases if filtering turned on
    int nocases = 0;
    for (i = 0; i < NoCases; i++)
        if (ValidRecord(i+1,ColNoSelected,k)) nocases++;

    if (nocases > 10) // Use normal distribution approximation
    {
        z = r * sqrt(double(nocases - 2) / (1.0 - (r * r)));
        sprintf(outline,"t-test value for hypothesis r = 0 is %5.3f",z);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        Probability = ftest(1.0, double(nocases - 2),z * z);
        sprintf(outline,"Probability > t = %6.4f",Probability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    else
    {
        sprintf(outline,"Use table P, page 284 in Siegel for testing significance of r.");
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();

    // clean up the heap
    delete[] d;
    for (i = 0; i < NoCases; i++) delete[] X[i];
    delete[] X;
    for (i = 0; i < NoCases; i++) delete[] index[i];
    delete[] index;
    for (i = 0; i < NoCases; i++) delete[] Ranks[i];
    delete[] Ranks;
    delete[] ColNoSelected;
}
//-------------------------------------------------------------------------

void Wilcoxon(void)
{
    long double numerator, denominator;
    double probz, z, negsum = 0.0,
        possum = 0.0, t, sum, Avg;
    double *A, *b, *d, *r;
    int M,  N, negcnt = 0, poscnt = 0, i, j, k, itemp;
    int *index, *ColNoSelected;
    AnsiString cellstring;
    char outline[81];

    cellstring = FrmVarSel->Caption;
    FrmVarSel->Caption = "Wilcoxon: Select two matched-pairs variables.";
    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        FrmVarSel->LstBoxVars->Items->Add(cellstring);
    }
    if (FrmVarSel->ShowModal() == mrCancel) return;
    FrmVarSel->Caption = cellstring;
    FrmVarSel->ChkBox->Visible = true;
    k = FrmVarSel->LstBoxSelected->Items->Count;
    if (k == 0)
    {
        ShowMessage("ERROR!  Please select variables.");
        return;
    }

    // Allocate memory
    try  {
        ColNoSelected = new int[k];
        A = new double[NoCases];
        b = new double[NoCases];
        d = new double[NoCases];
        index = new int[NoCases];
        r = new double[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Wilcoxon test.","ERROR",MB_OK);
        return;
    }

    // Get column numbers and labels of variables selected
    for (i = 0; i < k; i++)
    {
        cellstring = FrmVarSel->LstBoxSelected->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
                ColNoSelected[i] = j+1;
        }
    }

    // Store case indexes
    for (i = 0; i < NoCases; i++) index[i] = i;

    // Get scores and differences
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,k)) d[i] = 0.0;
        else
        {
            int col1 = ColNoSelected[0];
            int col2 = ColNoSelected[1];
            A[i] = StrToFloat(MainForm->Grid->Cells[col1][i+1]);
            b[i] = StrToFloat(MainForm->Grid->Cells[col2][i+1]);
            d[i] = A[i] - b[i];
        }
    }

    // Rank on absolute score differences.
    // First, sort on differences
    for (i = 0; i < NoCases - 1; i++)
    {
        for (j = i+1; j < NoCases; j++)
        {
            if (fabs(d[i]) > fabs(d[j])) // switch cases
            {
                t = d[i];
                d[i] = d[j];
                d[j] = t;
                t = A[i];
                A[i] = A[j];
                A[j] = t;
                t = b[i];
                b[i] = b[j];
                b[j] = t;
                itemp = index[i];
                index[i] = index[j];
                index[j] = itemp;
            }
        }
    }
    N = NoCases;

    // Eliminate cases with 0 score differences
    i = 0;
    while (i < NoCases)
    {
        if (d[i] == 0.0) // found a 0 score difference - move all up one
        {
            for (j = i+1; j < NoCases; j++)
            {
                d[j-1] = d[j];
                A[j-1] = A[j];
                b[j-1] = b[j];
                index[j-1] = index[j];
            }
            N--;
        }
        if (d[i] != 0.0) i++;
    }

    // Assign ranks
    for (i = 0; i < N; i++) r[i] = double(i) + 1.0;

    // Find matching differences and assign common rank
    i = 0;
    while (i < N)
    {
        M = 0;
        sum = 0.0;
        for (j = i+1; j < N; j++)
        {
            if ( fabs(d[j]) == fabs(d[i]) )
            {
                M = M + 1;
                sum = sum + r[j];
            }
        }
        if (M > 0) //matched differences found - assign average rank
        {
            sum = sum + r[i];
            Avg = sum / double(M + 1);
            for (j = i; j <= i+M; j++) r[j] = Avg;
            i = i + M + 1;
//            M = 0;
//            sum = 0.0;
        }
        else i = i + 1;
    }

    // Assign sign of difference to ranks
    for (i = 0; i < N; i++) if (d[i] < 0.0) r[i] = -r[i];

    // Get sum of negative and positive difference ranks
    for (i = 0; i < N; i++)
    {
        if (d[i] < 0.0)
        {
            negsum += fabs(r[i]);
            negcnt++;
        }
        else
        {
            possum += fabs(r[i]);
            poscnt++;
        }
    }
    if (negsum < possum) t = negsum;
    else t = possum;
    numerator = t - (double(N * (N + 1)) / 4.0);
    denominator = double (N * (N + 1)) * (double (2 * N + 1) / 24.0);
    denominator = sqrt(denominator);
    z = fabs(numerator / denominator);
    if (z > 3.5) probz = 0.0;
    else probz = 1.0 - normalprob(z);

    // Now, display results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("The Wilcoxon Matched-Pairs Signed-Ranks Test");
    FrmOutPut->RichOutPut->Lines->Add("See pages 75-83 in S. Seigel's Nonparametric Statistics for the Social Sciences");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Ordered Cases with cases having 0 differences eliminated:");
    sprintf(outline,"Number of cases with absolute differences greater than 0 = %d",N);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    AnsiString label1 = MainForm->Grid->Cells[ColNoSelected[0]][0];
    AnsiString label2 = MainForm->Grid->Cells[ColNoSelected[1]][0];
    sprintf(outline,"CASE %10s  %10s    Difference   Signed Rank",
            label1.c_str(), label2.c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (i = 0; i < N; i++)
    {
        sprintf(outline,"%3d      %6.2f      %6.2f    %6.2f    %6.2f",
            index[i]+1, A[i], b[i], d[i], r[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Smaller sum of ranks (T) = %8.2f", t);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Approximately normal z for test statistic T = %6.3f",z);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Probability (1-tailed) of greater z = %6.4f",probz);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("NOTE: For N < 25 use tabled values for Wilcoxon Test");
    FrmOutPut->ShowModal();

    // clean up the heap
    delete[] r;
    delete[] index;
    delete[] d;
    delete[] b;
    delete[] A;
    delete[] ColNoSelected;
}
//--------------------------------------------------------------------------




