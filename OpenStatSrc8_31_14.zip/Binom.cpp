//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "NonPar.h"
#include "Binom.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBinomFrm *BinomFrm;
//---------------------------------------------------------------------------
__fastcall TBinomFrm::TBinomFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBinomFrm::ClearBtnClick(TObject *Sender)
{
    CatAEdit->Text = "";
    CatBEdit->Text = "";
    PropAEdit->Text = "";
    PlotChk->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TBinomFrm::CancelBtnClick(TObject *Sender)
{
    BinomFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TBinomFrm::OKBtnClick(TObject *Sender)
{
    BinomFrm->Hide();
}
//---------------------------------------------------------------------------
