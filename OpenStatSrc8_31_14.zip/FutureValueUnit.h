//---------------------------------------------------------------------------

#ifndef FutureValueUnitH
#define FutureValueUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFutureValueForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TRadioGroup *WhenGroup;
     TLabel *Label5;
     TButton *ComputeBtn;
     TEdit *PresentEdit;
     TEdit *PaymentEdit;
     TEdit *NPeriodsEdit;
     TEdit *RateEdit;
     TEdit *FutureEdit;
     TButton *ResetBtn;
     TButton *ReturnBtn;
     TMemo *Memo1;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TFutureValueForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFutureValueForm *FutureValueForm;
//---------------------------------------------------------------------------
#endif
