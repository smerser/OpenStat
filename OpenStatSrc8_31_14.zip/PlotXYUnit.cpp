//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PlotUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "FreqDistUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "PlotXYUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TXvsYPlotForm *XvsYPlotForm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TXvsYPlotForm::TXvsYPlotForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TXvsYPlotForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     RegLineChk->Checked = false;
     ConfIntvlEdit->Text = "95";
     ConfBandChk->Checked = false;
     DescChk->Checked = false;
     MeansChk->Checked = false;
     XEdit->Text = "";
     YEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TXvsYPlotForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TXvsYPlotForm::XInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     XEdit->Text = Varlist->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TXvsYPlotForm::YInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     YEdit->Text = Varlist->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TXvsYPlotForm::OKBtnClick(TObject *Sender)
{

     double Xmin, Xmax, Ymin, Ymax, SSx, t, DF;
     double Xmean, Ymean, Xvariance, Yvariance, Xstddev, Ystddev, ConfBand;
     double X, Y, R, temp, SEPred, Slope, Intercept, predicted, sedata;
     int i, j, Xcol, Ycol, N, NoSelected;
     double *Xpoints,  *Ypoints, *UpConf, *lowConf;
     AnsiString cellstring;
     int *ColNoSelected;
     char outline[121];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     GetDblVecMem(Xpoints,NoCases+1); //SetLength(Xpoints,NoCases + 1);
     GetDblVecMem(Ypoints,NoCases+1); //SetLength(Ypoints,NoCases + 1);
     GetDblVecMem(UpConf,NoCases+1);  //SetLength(UpConf,NoCases + 1);
     GetDblVecMem(lowConf,NoCases+1); //SetLength(lowConf,NoCases + 1);
     ColNoSelected = new int[2];
     Xcol = 0;
     Ycol = 0;

     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == XEdit->Text) Xcol = i;
          if (cellstring == YEdit->Text) Ycol = i;
     }
     if ((Xcol == 0) || (Ycol == 0))
     {
        ShowMessage("ERROR! First, select an X and a Y variable.");
        goto cleanup;
     }
     //result = VarTypeChk(Xcol,0);
     //if (result == 1) goto cleanup;
     //result = VarTypeChk(Ycol,0);
     //if (result == 1) goto cleanup;
     
     NoSelected = 2;
     ColNoSelected[0] = Xcol;
     ColNoSelected[1] = Ycol;
     N = 0;
     Xmax = -1.0e20;
     Xmin = 1.0e20;
     Ymax = -1.0e20;
     Ymin = 1.0e20;
     Xmean = 0.0;
     Ymean = 0.0;
     Xvariance = 0.0;
     Yvariance = 0.0;
     R = 0.0;

     for (i = 1; i <= NoCases; i++)
     {
          if (!ValidRecord(i,ColNoSelected,NoSelected)) continue;
          if (!ValidValue(i,ColNoSelected[0])) continue;
          if (!ValidValue(i,ColNoSelected[1])) continue;
          N = N + 1;
          X = StrToFloat(MainForm->Grid->Cells[Xcol][i]);
          Y = StrToFloat(MainForm->Grid->Cells[Ycol][i]);
          //result = GetValue(i, Xcol,intvalue, dblvalue, strvalue);
          //if (result != 0) X = 0.0;
          //else X = dblvalue;
          //result = GetValue(i, Ycol,intvalue, dblvalue, strvalue);
          //if (result != 0) Y = 0.0;
          //else Y = dblvalue;
          Xpoints[N] = X;
          Ypoints[N] = Y;
          if (X > Xmax) Xmax = X;
          if (X < Xmin) Xmin = X;
          if (Y > Ymax) Ymax = Y;
          if (Y < Ymin) Ymin = Y;
          Xmean = Xmean + X;
          Ymean = Ymean + Y;
          Xvariance = Xvariance + (X * X);
          Yvariance = Yvariance + (Y * Y);
          R = R + (X * Y);
     }

     // sort on X
     for (i = 1; i <= N - 1; i++)
     {
          for (j = i + 1; j <= N; j++)
          {
               if (Xpoints[i] > Xpoints[j]) //swap
               {
                    temp = Xpoints[i];
                    Xpoints[i] = Xpoints[j];
                    Xpoints[j] = temp;
                    temp = Ypoints[i];
                    Ypoints[i] = Ypoints[j];
                    Ypoints[j] = temp;
               }
          }
     }

     // calculate statistics
     Xvariance = Xvariance - (Xmean * Xmean / N);
     SSx = Xvariance;
     Xvariance = Xvariance / (N - 1);
     Xstddev = sqrt(Xvariance);

     Yvariance = Yvariance - (Ymean * Ymean / N);
     Yvariance = Yvariance / (N - 1);
     Ystddev = sqrt(Yvariance);

     R = R - (Xmean * Ymean / N);
     R = R / (N - 1);
     R = R / (Xstddev * Ystddev);
     SEPred = sqrt(1.0 - (R * R)) * Ystddev;
     SEPred = SEPred * sqrt((N - 1) / (N - 2));
     Xmean = Xmean / N;
     Ymean = Ymean / N;
     Slope = R * Ystddev / Xstddev;
     Intercept = Ymean - Slope * Xmean;

     // Now, print the descriptive statistics if requested
     if (DescChk->Checked)
     {
          FrmOutPut->RichOutPut->Lines->Add("X versus Y Plot");
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"X = %s, Y = %s from file: %s",XEdit->Text.c_str(),
                YEdit->Text.c_str(),MainForm->FileNameEdit->Text.c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("Variable     Mean   Variance  Std.Dev.");
          sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f",XEdit->Text.c_str(),Xmean,Xvariance,Xstddev);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f",YEdit->Text.c_str(),Ymean,Yvariance,Ystddev);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Correlation = %6.4f, Slope = %8.2f, Intercept = %8.2f",
              R, Slope, Intercept);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Standard Error of Estimate = %8.2f",SEPred);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Number of good cases = %d",N);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->ShowModal();
     }

     // get upper and lower confidence points for each X value
     if (ConfBandChk->Checked)
     {
          ConfBand = StrToFloat(ConfIntvlEdit->Text) / 100.0;
          DF = N - 2;
          t = inverset(ConfBand,DF);
          for (i = 1; i <= N; i++)
          {
               X = Xpoints[i];
               predicted = Slope * X + Intercept;
               sedata = SEPred * sqrt(1.0 + (1.0 / N) + ((X - Xmean) * (X - Xmean) / SSx));
               UpConf[i] = predicted + (t * sedata);
               lowConf[i] = predicted - (t * sedata);
               if (UpConf[i] > Ymax) Ymax = UpConf[i];
               if (lowConf[i] < Ymin)Ymin = lowConf[i];
          }
     }
     else ConfBand = 0.0;

     // plot the values (and optional line and confidence band if elected)
     plotxy(Xpoints, Ypoints, UpConf, lowConf, ConfBand, Xmean, Ymean, R,
            Slope, Intercept, Xmax, Xmin, Ymax, Ymin, N);

     PlotForm->ShowModal();
     
cleanup:
     delete[] ColNoSelected;
     delete[] lowConf;
     delete[] UpConf;
     delete[] Ypoints;
     delete[] Xpoints;
}
//--------------------------------------------------------------

void __fastcall TXvsYPlotForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double *UpConf,
                                      double *LowConf,
                                      double ConfBand,
                                      double Xmean,
                                      double Ymean,
                                      double R,
                                      double Slope,
                                      double Intercept,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];

     Title = "X versus Y PLOT Using File: " + MainForm->FileNameEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw Means
     if (MeansChk->Checked)
     {
          ypos = ceil(vhi * ( (Ymax - Ymean) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + YEdit->Text;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

          xpos = ceil(hwide * ( (Xmean - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          ypos = vtop;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = vbottom;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + XEdit->Text;
          strhi = PlotForm->Image1->Canvas->TextWidth(Title);
          xpos = xpos - strhi / 2;
          ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw slope line
     if (RegLineChk->Checked)
     {
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          Yvalue = (Xpoints[1] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1]- Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          Yvalue = (Xpoints[N] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[N] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit->Text) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XEdit->Text);
     sprintf(outline,"R(X,Y) = %5.3f, Slope = %6.2f, Intercept = %6.2f",
              R,Slope,Intercept);
     Title = outline;
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
     ypos = ypos + 15;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // Draw vertical axis
     Title = YEdit->Text;
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YEdit->Text);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 1; i <= N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }

     // draw confidence bands if requested
     if (ConfBand != 0.0)
     {
          PlotForm->Image1->Canvas->Pen->Color = clRed;
          ypos = ceil(vhi * ((Ymax - UpConf[1]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 2; i <= N; i++)
          {
               ypos = ceil(vhi * ((Ymax - UpConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
          ypos = ceil(vhi * ((Ymax - LowConf[1]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 2; i <= N; i++)
          {
               ypos = ceil(vhi * ((Ymax - LowConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
     }
}
//-------------------------------------------------------------------


