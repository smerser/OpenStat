//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SplashUnit.h"
#include "OptionsUnit.h"
#include "MainUnit.h";
#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSplashForm *SplashForm;
extern struct Options ops;

//---------------------------------------------------------------------------
__fastcall TSplashForm::TSplashForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSplashForm::Button1Click(TObject *Sender)
{
        AnsiString HomePath, DataPath, MissingValue;
        int GridFldWidth, GridNoDecimals;

/*
        FILE *stream;
        HomePath = GetCurrentDir();
        DataPath = HomePath;
        MissingValue = "99999";
        stream = fopen("OPTIONS.FIL","w");
        ops.format = 0;
        ops.gridfldwidth = 8;
        ops.gridnodecimals = 3;
        strcpy(ops.missval, MissingValue.c_str());
        strcpy(ops.DataPath,DataPath.c_str());
        strcpy(ops.HomePath,HomePath.c_str());
        for (int i = 0; i < 10; i++)
        {
            strcpy(ops.PrevFiles[i].FileName," ");
            strcpy(ops.PrevFiles[i].Date," ");
            strcpy(ops.PrevFiles[i].Time," ");
        }
        fclose(stream);
        ShowMessage("An OPTIONS.FIL has been created in your program directory.");
*/
        accepted = 1;
        SplashForm->Hide();
//        MainForm->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TSplashForm::Button2Click(TObject *Sender)
{
        accepted = 0;
        exit (0);
}
//---------------------------------------------------------------------------


