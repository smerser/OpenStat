//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <Printers.hpp>
#include "functions.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "dcdflib.h"
#include "Plot.h"
#include "AltHoUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmPlot *FrmPlot;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
int PlotNo;
//---------------------------------------------------------------------------
__fastcall TFrmPlot::TFrmPlot(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmPlot::Zdist(void)
{
     AnsiString Response;
     long int Clwidth;
     long int Clheight;
     long int X;
     long int Y;
     long int XaxisStart;
     long int XaxisEnd;
     long int YaxisStart;
     long int YaxisEnd;
     long int Xrange;
     long int Yrange;
     double alpha;
     double realpts[2][100];
     double h;
     double z;
     double hprop;
     double zprop;
     String Label("Normal Distribution. Alpha = ");
     char outline[21];

//     FrmPlot->Image1->Canvas->Pen->Color = clBlack;
     FrmPlot->Image1->Canvas->Pen->Color = clRed;
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;
     FrmPlot->Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);
     PlotNo = 1;
     Clwidth =  FrmPlot->Width;
     Clheight = FrmPlot->Height;
     XaxisStart = Clwidth / 8;
     XaxisEnd = Clwidth - (Clwidth / 8);
     YaxisStart = (Clheight * 7) / 10;
     YaxisEnd = Clheight / 10;
     Xrange = XaxisEnd - XaxisStart;
     Yrange = YaxisStart - YaxisEnd;
     Response = InputBox("ALPHA","Enter the Type I Error Rate (1-tailed)","0.05");
//     FrmPlot->Show();

     // Create values of normal curve
     NormPts(-4.0, 4.0, 100, realpts);
     PltPts(realpts, 4.0, -4.0, 0.5, 0.0, 100, XaxisStart, YaxisStart, Xrange,
            Yrange, clRed);

    // Draw line for alpha z = 1.645
     alpha = atof(Response.c_str());
     Label = Label + Response;
     FrmPlot->Caption = Label;
     z = inversez(1.0 - alpha);
     Label = Label + ", z for alpha = ";
     sprintf(outline,"%5.3f",z);
     Label = Label + outline;
     zprop = (4.0 + z) / 8.0;
     h = (1.0 / sqrt(2.0 * 3.1415)) * (1.0 / exp(z * z / 2.0));
     hprop = (0.5 - h) / 0.5;
     X = int( zprop * double(Xrange))+ XaxisStart;
     Y = YaxisEnd + int( hprop * double(Yrange));
     FrmPlot->Image1->Canvas->Pen->Color = clRed;
     FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
     FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff

     // Draw vertical lines in the rejection region
     double zincr = 0.05;
     while (z < 3.0)
     {
        z += zincr;
        zprop = (4.0 + z) / 8.0;
        h = (1.0 / sqrt(2.0 * 3.1415)) * (1.0 / exp(z * z / 2.0));
        hprop = (0.5 - h) / 0.5;
        X = int( zprop * double(Xrange))+ XaxisStart;
        Y = YaxisEnd + int( hprop * double(Yrange));
        FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
        FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff
     }

     // create labeled axis
     Hscale(-4.0, 4.0, 11, clWhite, 10, XaxisStart, YaxisStart, Xrange,"z SCALE");
     Vscale(0.0, 0.5, 11, clWhite, 10, XaxisStart, YaxisStart, Yrange, "DENSITY");

     // Print Heading
     long int t;
     t = FrmPlot->Image1->Canvas->TextWidth(Label);
     X = (FrmPlot->Image1->Width / 2) - (t / 2);
     FrmPlot->Image1->Canvas->TextOut(X,0,Label);
     FrmPlot->ShowModal();
     FrmPlot->Image1->DestroyComponents();
}
//---------------------------------------------------------------------------

void __fastcall TFrmPlot::Hscale(double Xmin, double Xmax, int Nsteps, TColor color, int FontSize,\
            long int X, long int Y, long int Xlength, char * Label)
{
    int TickEnd;
    int Xpos;
    int Ypos;
    int TextX;
    double Xincr;
    double Xval;
    char Svalue[21];
    AnsiString Ast;

    FrmPlot->Image1->Canvas->MoveTo(X,Y);
    FrmPlot->Image1->Canvas->LineTo(X+Xlength,Y);
    FrmPlot->Image1->Canvas->Font->Size = FontSize;
    FrmPlot->Image1->Canvas->Brush->Color = color;
    TickEnd = Y + 10;
    Xincr = (Xmax - Xmin) / Nsteps;
    for (int i = 0; i < Nsteps+1; i++)
    {
        Xpos = ((Xlength / Nsteps) * i) + X;
        FrmPlot->Image1->Canvas->MoveTo(Xpos,Y);
        FrmPlot->Image1->Canvas->LineTo(Xpos,TickEnd);
        TextX = Xpos - 8;
        Xval = Xmin + ( i * Xincr);
        sprintf(Svalue,"%4.2f",Xval);
        Ast = Svalue;
        FrmPlot->Image1->Canvas->TextOut(TextX, Y+15, Ast);
    }
    // print label below X axis
    Ypos = Y + 30;
    Xpos = (FrmPlot->Image1->Width / 2) - (FrmPlot->Image1->Canvas->TextWidth(Label) / 2);
    FrmPlot->Image1->Canvas->TextOut(Xpos,Ypos,Label);
}

//---------------------------------------------------------------------------

void __fastcall TFrmPlot::Vscale(double Ymin, double Ymax, int Nsteps, TColor color, int FontSize,\
            long int X, long int Y, long int Ylength, char * Label)
{
    int TickEnd;
    int Ypos;
    int Xpos;
    int TextY;
    double Yincr;
    double Yval;
    char Svalue[5];
    char symbol[2];
    AnsiString Ast;

    FrmPlot->Image1->Canvas->MoveTo(X,Y);
    FrmPlot->Image1->Canvas->LineTo(X,Y-Ylength);
    FrmPlot->Image1->Canvas->Font->Size = FontSize;
    FrmPlot->Image1->Canvas->Brush->Color = color;
    TickEnd = X - 10;
    Yincr = (Ymax - Ymin) / Nsteps;
    for (int i = 0; i < Nsteps+1; i++)
    {
        Ypos = Y - ((Ylength / Nsteps) * i) ;
        FrmPlot->Image1->Canvas->MoveTo(X,Ypos);
        FrmPlot->Image1->Canvas->LineTo(TickEnd,Ypos);
        TextY = TickEnd - 30;
        Yval = Ymin + ( i * Yincr);
        sprintf(Svalue,"%4.2f",Yval);
        Ast = Svalue;
        FrmPlot->Image1->Canvas->TextOut(TextY, Ypos-8, Ast);
    }
    // print label vertically
    Xpos = TextY - 15;
    for (unsigned int i = 0; i < strlen(Label); i++)
    {
        int chpixs = FrmPlot->Image1->Canvas->TextHeight(Label);
        Ypos = Y - (Ylength / 2) - ( (strlen(Label) * chpixs) / 2 ) + (chpixs * i);
        symbol[0] = Label[i];
        symbol[1] = 0;
        FrmPlot->Image1->Canvas->TextOut(Xpos,Ypos,symbol);
    }
}

//---------------------------------------------------------------------------

void __fastcall TFrmPlot::NormPts(double zMin, double zMax, int Npts, double realpts[][100])
{
     double zIncr;
     double z;
     double h;

     zIncr = (zMax - zMin) / Npts;
     for (int i = 0; i < Npts; i++)
     {
         z = zMin + (zIncr * i);
         h = (1.0 / sqrt(2.0 * 3.14159265358979)) * ( 1.0 / exp(z * z / 2.0));
         realpts[0][i] = z;
         realpts[1][i] = h;
     }
}

//-------------------------------------------------------------------------

void __fastcall TFrmPlot::PltPts(double realpts[][100], double Xmax, double Xmin, double Ymax, double Ymin,\
            int Npts, long int XaxisStart, long int YaxisStart, long int XaxisRange,
            long int YaxisRange, TColor color)
{
      double hprop;
      double zprop;
      int X;
      int Y;
      TPoint intpts[100];
      double z;
      double h;

      for (int i = 0; i < Npts; i++)
      {
          z = realpts[0][i];
          h = realpts[1][i];
          zprop = (z - Xmin) / (Xmax - Xmin);
          X = int(zprop * double(XaxisRange)) + XaxisStart;
          hprop = (h - Ymin) / (Ymax - Ymin);
          Y = YaxisStart - int(hprop * double(YaxisRange));
          intpts[i] = Point(X,Y);
      }
      FrmPlot->Image1->Canvas->Pen->Color = color;
      FrmPlot->Image1->Canvas->Polyline(intpts,Npts-1);
}

//---------------------------------------------------------------------------
void __fastcall TFrmPlot::FrmResize(TObject *Sender)
{
     FrmPlot->Image1->Repaint();
}
//---------------------------------------------------------------------------

void __fastcall TFrmPlot::ChiSqrDist(void)
{
     AnsiString Response;
     long int Clwidth;
     long int Clheight;
     long int X;
     long int Y;
     long int XaxisStart;
     long int XaxisEnd;
     long int YaxisStart;
     long int YaxisEnd;
     long int Xrange;
     long int Yrange;
     int df;
     double alpha;
     double realpts[2][100];
     double h;
     double z;
     double hprop;
     double zprop;
     double MaxChi;
     double MaxProb = 0.0;
     char outline[81];

     String Label("Chi-Square Distribution. Alpha = ");
     FrmPlot->Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);
     FrmPlot->Image1->Canvas->Pen->Color = clRed;
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;
     PlotNo = 2;
     Clwidth =  FrmPlot->Image1->Width;
     Clheight = FrmPlot->Image1->Height;
     XaxisStart = Clwidth / 8;
     XaxisEnd = Clwidth - (Clwidth / 8);
     YaxisStart = (Clheight * 7) / 10;
     YaxisEnd = Clheight / 10;
     Xrange = XaxisEnd - XaxisStart;
     Yrange = YaxisStart - YaxisEnd;
     Response = InputBox("ALPHA","Enter the Type I Error Rate (1-tailed)","0.05");
     alpha = atof(Response.c_str());
     Label = Label + Response;
     Response = InputBox("DF","Enter the degrees of freedom (3-30): ","20");
     df = atoi(Response.c_str());
     if ((df < 3) || (df > 30))
     {
        ShowMessage("D.F. must be between 3 and 30) - setting to 20");
        df = 20;
        Response = df;
     }
     Label = Label + " D.F. = ";
     Label = Label + Response;
     FrmPlot->Caption = Label;
//     FrmPlot->Show();

     // Create values of chi-squared curve
     MaxChi = 70.0;
     ChiPts(0.0, MaxChi, 100, df, realpts);
     for (int i = 0; i < 100; i++)
     {
         if (realpts[1][i] > MaxProb) MaxProb = realpts[1][i];
     }
     PltPts(realpts, MaxChi, 0.0, MaxProb, 0.0, 100, XaxisStart, YaxisStart, Xrange,
            Yrange, clRed);

    // Draw line for alpha
     z = inversechi(1.0-alpha,df);
     sprintf(outline,", chi-square for alpha =  %5.3f",z);
     Label = Label + outline;
     zprop = z / MaxChi;
     h = chi2func(z,df);
     hprop = (MaxProb - h) / MaxProb;
     X = int( zprop * double(Xrange))+ XaxisStart;
     Y = YaxisEnd + int( hprop * double(Yrange));
     FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
     FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff

     // Draw vertical lines in the rejection region
     double zincr = 0.05;
     while (z < MaxChi)
     {
        z += zincr;
        zprop = z / MaxChi;
        h = chi2func(z,df);
        hprop = (MaxProb - h) / MaxProb;
        X = int( zprop * double(Xrange))+ XaxisStart;
        Y = YaxisEnd + int( hprop * double(Yrange));
        FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
        FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff
     }

     // create labeled axis
     Hscale(0.0, MaxChi, 11, clWhite, 10, XaxisStart, YaxisStart,
        Xrange,"CHI SQUARED SCALE");
     Vscale(0.0, MaxProb, 11, clWhite, 10, XaxisStart, YaxisStart,
        Yrange, "DENSITY");

     // Print Heading
     long int t;
     t = FrmPlot->Image1->Canvas->TextWidth(Label);
     X = (FrmPlot->Image1->Width / 2) - (t / 2);
     FrmPlot->Image1->Canvas->TextOut(X,0,Label);
     FrmPlot->ShowModal();
}

//----------------------------------------------------------------------

void __fastcall TFrmPlot::ChiPts(double cMin, double cMax, int Npts, int df, double realpts[][100])
{
     double ratio1, ratio2, ratio3, cIncr, chi, h;

     ratio1 = df / 2.0;
     ratio2 = (df - 2.0) / 2.0;
     cIncr = (cMax - cMin) / Npts;
     for (int i = 0; i < Npts; i++)
     {
         chi = cMin + (cIncr * i);
         ratio3 = chi / 2.0;
         h = (1.0 / (pow(2.0,ratio1) * exp(lngamma(ratio1)))) * pow(chi,ratio2) * ( 1.0 / exp(ratio3));
         realpts[0][i] = chi;
         realpts[1][i] = h;
     }
}

//-------------------------------------------------------------------------


void __fastcall TFrmPlot::Fdistribution(void)
{
     AnsiString Response;
     long int Clwidth;
     long int Clheight;
     long int X;
     long int Y;
     long int XaxisStart;
     long int XaxisEnd;
     long int YaxisStart;
     long int YaxisEnd;
     long int Xrange;
     long int Yrange;
     int df1;
     int df2;
     double alpha;
     double realpts[2][100];
     double h;
     double F;
     double hprop;
     double Fprop;
     double MaxF;
     double MaxProb = 0.0;
     String Label("F Distribution. Alpha = ");
     bool done = false;
     char outline[81];

     FrmPlot->Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);
     FrmPlot->Image1->Canvas->Pen->Color = clRed;
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;
     PlotNo = 3;
     Clwidth =  FrmPlot->Image1->Width;
     Clheight = FrmPlot->Image1->Height;
     XaxisStart = Clwidth / 8;
     XaxisEnd = Clwidth - (Clwidth / 8);
     YaxisStart = (Clheight * 7) / 10;
     YaxisEnd = Clheight / 10;
     Xrange = XaxisEnd - XaxisStart;
     Yrange = YaxisStart - YaxisEnd;
     Response = InputBox("ALPHA","Enter the Type I Error Rate (1-tailed)","0.05");
     alpha = atof(Response.c_str());
     Label = Label + Response;
     Response = InputBox("DF1","Enter the numerator degrees of freedom (3-20): ","5");
     df1 = atoi(Response.c_str());
     if ((df1 < 3) || (df1 > 30))
     {
        ShowMessage("Numerator degrees of freedom must be between 3 and 20");
        return;
     }
     Label = Label + " D.F.1 = ";
     Label = Label + Response;
     Response = InputBox("DF2","Enter the denominator degrees of freedom (2-200): ","10");
     df2 = atoi(Response.c_str());
     if ((df2 < 2) || (df2 > 200))
     {
        ShowMessage("Denominator d.f. must be beween 2 and 200");
        return;
     }
     Label = Label + " , D.F.2 = ";
     Label = Label + Response;
     FrmPlot->Caption = Label;
//     FrmPlot->Show();

     // Create values of F curve
     MaxF = 20.0;
     do
     {
          h = Ffunc(MaxF, df1, df2);
          if (h < 0.001)  MaxF = MaxF -1.0;
          else done = true;
     } while (!done);

     FPts(0.0, MaxF, 100, df1, df2, realpts);
     for (int i = 0; i < 100; i++)
     {
         if (realpts[1][i] > MaxProb) MaxProb = realpts[1][i];
     }
     PltPts(realpts, MaxF, 0.0, MaxProb, 0.0, 100, XaxisStart, YaxisStart, Xrange,
             Yrange, clRed);

     // Draw line for alpha
     F = fpercentpoint(1.0-alpha,df1,df2);
     sprintf(outline,", F for Alpha = %5.3f",F);
     Label = Label + outline;
     Fprop = F / MaxF;
     h = Ffunc(F,df1,df2);
     hprop = (MaxProb - h) / MaxProb;
     X = int( Fprop * double(Xrange))+ XaxisStart;
     Y = YaxisEnd + int( hprop * double(Yrange));
     FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
     FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff

     // Draw vertical lines in the rejection region
     double fincr = 0.05;
     while (F < MaxF)
     {
        F += fincr;
        Fprop = F / MaxF;
        h = Ffunc(F,df1,df2);
        hprop = (MaxProb - h) / MaxProb;
        X = int( Fprop * double(Xrange))+ XaxisStart;
        Y = YaxisEnd + int( hprop * double(Yrange));
        FrmPlot->Image1->Canvas->MoveTo(X,YaxisStart);
        FrmPlot->Image1->Canvas->LineTo(X,Y); // alpha cutoff
     }

     // create labeled axis
     Hscale(0.0, MaxF, 11, clWhite, 10, XaxisStart, YaxisStart,
        Xrange,"F SCALE");
     Vscale(0.0, MaxProb, 11, clWhite, 10, XaxisStart, YaxisStart,
        Yrange, "DENSITY");

     // Print Heading
     long int t;
     t = FrmPlot->Image1->Canvas->TextWidth(Label);
     X = (FrmPlot->Image1->Width / 2) - (t / 2);
     FrmPlot->Image1->Canvas->TextOut(X,0,Label);
     FrmPlot->ShowModal();
}

//-----------------------------------------------------------------------

void __fastcall TFrmPlot::FPts(double FMin, double FMax, int Npts, int df1, int df2, double realpts[][100])
{
     double FIncr, F, h;

     FIncr = (FMax - FMin) / Npts;
     for (int i = 0; i < Npts; i++)
     {
         F = FMin + (FIncr * i);
         h = Ffunc(F, df1, df2);
         realpts[0][i] = F;
         realpts[1][i] = h;
     }
}

//-------------------------------------------------------------------------

void __fastcall TFrmPlot::AltHypothesis(void)
{
    // generate a null and alternate hypothesis for a specified effect
    // size, Type I error rate and Type II error rate using the normal
    // distribution z-test. Estimate the N needed.
    // Uses the Plot.h header file and form  FrmPlot.
     long int Clwidth;
     long int Clheight;
     long int X;
     long int Y;
     long int XaxisStart;
     long int XaxisEnd;
     long int YaxisStart;
     long int YaxisEnd;
     long int Xrange;
     long int Yrange;
     long int t;
     double alpha;
     double beta;
     double nullmean;
     double altmean;
     double Diff;
     double StdDev;
     double CriticalX;
     double realpts[2][100];
     double zalpha;
     double zbeta;
     double Xprop;
     double stderrmean;
     double xlow;
     double xhigh;
     long int range;
     int Nsize;
     String Label;
     char valuestr[8];

//     FrmPlot->Image1->Canvas->FloodFill(5,5,clWhite,fsBorder);
     FrmPlot->Image1->Canvas->FloodFill(5,5,clGreen,fsBorder);
     FrmPlot->Image1->Canvas->Pen->Color = clBlack;
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;
     PlotNo = 6;
     AltHoFrm->ShowModal();
     if (AltHoFrm->ModalResult== mrCancel) return ;
     alpha = atof(AltHoFrm->TypeIEdit->Text.c_str());
     beta = atof(AltHoFrm->TypeIIEdit->Text.c_str());
     nullmean = atof(AltHoFrm->NullMeanEdit->Text.c_str());
     altmean = atof(AltHoFrm->AltMeanEdit->Text.c_str());
     StdDev = atof(AltHoFrm->StdDevEdit->Text.c_str());
     zalpha = inversez(1.0 - alpha);
     zbeta = inversez(1.0 - beta);
     Diff = fabs(nullmean - altmean);
     Nsize = ceil((StdDev / Diff) * fabs(zbeta + zalpha));
     Nsize *= Nsize;
     CriticalX = zalpha * (StdDev / sqrt(Nsize)) + nullmean;
     stderrmean = StdDev / sqrt(Nsize);
     Clwidth =  FrmPlot->Image1->Width;
     Clheight = FrmPlot->Image1->Height;

     // Determine X scale and print it
     YaxisStart = (Clheight * 6) / 10;
     YaxisEnd = Clheight / 10;
     Yrange = YaxisStart - YaxisEnd;
     xlow = nullmean - 4 * stderrmean;
     xhigh = altmean + 4 * stderrmean;
     XaxisStart = Clwidth / 8;
     XaxisEnd = Clwidth - (Clwidth / 8);
     Xrange = XaxisEnd - XaxisStart;
     Hscale(xlow, xhigh, 9, clWhite, 8, XaxisStart, YaxisStart, Xrange,"X SCALE");

     // Create values of the alternative distribution
     Xprop = ( (nullmean + 4*stderrmean) - xlow) / (xhigh - xlow);
     range = Xprop * Xrange;
     NormPts(-4.0, 4.0, 100, realpts);
     Xprop = ((altmean - 4 * stderrmean) - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart; // where to start curve
     PltPts(realpts, 4.0, -4.0, 0.5, 0.0, 100, X, YaxisStart, range,
            Yrange, clBlack);

     //Draw vertical axis at the critical X value
     Xprop = (CriticalX - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart;
     Y = YaxisStart;
     FrmPlot->Image1->Canvas->MoveTo(X,Y);
     FrmPlot->Image1->Canvas->LineTo(X,YaxisEnd);
     Label = "Critical X = ";
     sprintf(valuestr,"%6.2f",CriticalX);
     Label = Label + valuestr;
     t = FrmPlot->Image1->Canvas->TextWidth(Label) / 2;
     FrmPlot->Image1->Canvas->TextOut(X-t,YaxisEnd-15,Label);

     // floodfill Alternate distribution area with blue
     Xprop = (CriticalX - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart;
     Y = YaxisStart - 3;
     FrmPlot->Image1->Canvas->Brush->Color = clBlue;
     FrmPlot->Image1->Canvas->FloodFill(X-2,Y,clBlack,fsBorder );
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;

     // Create values of normal curve for null distribution
     NormPts(-4.0, 4.0, 100, realpts);
     Xprop = ( (nullmean + 4*stderrmean) - xlow) / (xhigh - xlow);
     range = Xprop * Xrange;
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;
     PltPts(realpts, 4.0, -4.0, 0.5, 0.0, 100, XaxisStart, YaxisStart, range,
            Yrange, clBlack);

     //Draw vertical axis at null mean
     Xprop = (nullmean - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart;
     Y = YaxisStart;
     FrmPlot->Image1->Canvas->MoveTo(X,Y);
     FrmPlot->Image1->Canvas->LineTo(X,YaxisEnd);
     Label = "Null Mean";
     t = FrmPlot->Image1->Canvas->TextWidth(Label) / 2;
     FrmPlot->Image1->Canvas->TextOut(X-t,YaxisEnd,Label);

     // floodfill alpha area with red
     Xprop = (CriticalX - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart;
     Y = YaxisStart - 3;
     FrmPlot->Image1->Canvas->Brush->Color = clRed;
     FrmPlot->Image1->Canvas->FloodFill(X+2,Y,clBlack,fsBorder );
     FrmPlot->Image1->Canvas->Brush->Color = clWhite;

     //Draw vertical axis at alternative mean
     FrmPlot->Image1->Canvas->Pen->Color = clBlack;
     Xprop = (altmean - xlow) / (xhigh - xlow);
     X = (Xprop * Xrange) + XaxisStart;
     Y = YaxisStart;
     FrmPlot->Image1->Canvas->MoveTo(X,Y);
     FrmPlot->Image1->Canvas->LineTo(X,YaxisEnd);
     Label = "Alternative Mean";
     t = FrmPlot->Image1->Canvas->TextWidth(Label) / 2;
     FrmPlot->Image1->Canvas->TextOut(X-t,YaxisEnd,Label);

     // draw the vertical density axis scale values
     Vscale(0.0, 0.5, 11, clWhite, 10, XaxisStart, YaxisStart, Yrange, "DENSITY");

     // Print Heading
     Label = "Sample size estimation for a z-test";
     FrmPlot->Caption = Label;
     Label = "Alpha = ";
     Label = Label + AltHoFrm->TypeIEdit->Text.c_str();
     Label = Label + ", Beta = ";
     Label = Label + AltHoFrm->TypeIIEdit->Text.c_str();
     Label = Label + ", N = ";
     Label = Label + Nsize;
     t = FrmPlot->Image1->Canvas->TextWidth(Label);
     X = (FrmPlot->Image1->Width / 2) - (t / 2);
     FrmPlot->Image1->Canvas->TextOut(X,0,Label);

     // print z scale for the null distribution
     Xprop = ( (nullmean + 4*stderrmean) - xlow) / (xhigh - xlow);
     range = Xprop * Xrange;
     Hscale(-4.0, 4.0, 11, clWhite, 8, XaxisStart, YaxisStart+50, range,"NULL Z SCALE");
     FrmPlot->ShowModal();
}
//--------------------------------------------------------------------


void __fastcall TFrmPlot::BtnPrintClick(TObject *Sender)
{
       TPrinter *Prntr = Printer();
       Prntr->Orientation = poPortrait;

       TRect r = Rect(20,20,Prntr->PageWidth-20,Prntr->PageHeight / 2 + 20);
       Prntr->BeginDoc();
       Prntr->Canvas->StretchDraw(r, Image1->Picture->Bitmap);
       Prntr->EndDoc();
}
//---------------------------------------------------------------------------

