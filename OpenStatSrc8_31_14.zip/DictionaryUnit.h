//---------------------------------------------------------------------------

#ifndef DictionaryUnitH
#define DictionaryUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TDictionaryForm : public TForm
{
__published:	// IDE-managed Components
	TStringGrid *DGrid;
	TPanel *Panel1;
	TPanel *Panel2;
	TComboBox *TypeCombo;
	TButton *ReturnBtn;
	TButton *DelRowBtn;
	TButton *CancelBtn;
    TLabel *Label2;
    TButton *DefaultBtn;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall DGridKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
	void __fastcall DelRowBtnClick(TObject *Sender);
	void __fastcall TypeComboClick(TObject *Sender);
	void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall DefaultBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TDictionaryForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDictionaryForm *DictionaryForm;
//---------------------------------------------------------------------------
#endif
