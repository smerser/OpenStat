//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "AboutMeUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutFrm *AboutFrm;
//---------------------------------------------------------------------------
__fastcall TAboutFrm::TAboutFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
