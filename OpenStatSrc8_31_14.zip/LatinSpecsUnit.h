//---------------------------------------------------------------------------

#ifndef LatinSpecsUnitH
#define LatinSpecsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TLatinSpecsFrm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label3;
     TListBox *VarList;
     TBitBtn *AinBtn;
     TBitBtn *AoutBtn;
     TBitBtn *BinBtn;
     TBitBtn *BoutBtn;
     TBitBtn *CinBtn;
     TBitBtn *CoutBtn;
     TBitBtn *DinBtn;
     TBitBtn *DoutBtn;
     TEdit *ACodeEdit;
     TEdit *BCodeEdit;
     TEdit *CCodeEdit;
     TEdit *DCodeEdit;
     TBitBtn *GrpInBtn;
     TBitBtn *GrpOutBtn;
     TEdit *GroupCodeEdit;
     TLabel *Label1;
     TLabel *Label2;
     TLabel *Label4;
     TLabel *Label5;
     TLabel *Label6;
     TLabel *Label7;
     TEdit *NPerCellEdit;
     TBitBtn *DataInBtn;
     TBitBtn *DataOutBtn;
     TLabel *Label8;
     TEdit *DepVarEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall AinBtnClick(TObject *Sender);
     void __fastcall BinBtnClick(TObject *Sender);
     void __fastcall CinBtnClick(TObject *Sender);
     void __fastcall DinBtnClick(TObject *Sender);
     void __fastcall GrpInBtnClick(TObject *Sender);
     void __fastcall DataInBtnClick(TObject *Sender);
     void __fastcall AoutBtnClick(TObject *Sender);
     void __fastcall BoutBtnClick(TObject *Sender);
     void __fastcall CoutBtnClick(TObject *Sender);
     void __fastcall DoutBtnClick(TObject *Sender);
     void __fastcall GrpOutBtnClick(TObject *Sender);
     void __fastcall DataOutBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TLatinSpecsFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLatinSpecsFrm *LatinSpecsFrm;
//---------------------------------------------------------------------------
#endif
