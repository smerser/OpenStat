//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <math.h>
#include "Factor.h"
#include "FrmGraphOut.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TGraphOut *GraphOut;
extern double **Loadings;
extern int rows;
extern int cols;
//---------------------------------------------------------------------------
__fastcall TGraphOut::TGraphOut(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGraphOut::BtnCloseClick(TObject *Sender)
{
	GraphOut->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TGraphOut::BtnPrintClick(TObject *Sender)
{
	GraphOut->Redit->Print(GraphOut->Caption);
}
//---------------------------------------------------------------------------

void rotate(void)
{
     int i, j, L, i1, j1,col1, col2;
     double A, b, d, **Q;
     double xvector[200];
     double yvector[200];
     AnsiString titlestr, x_axis, y_axis;
     char outline[81];

     L = rows;
     col1 = GraphOut->col1;
     col2 = GraphOut->col2;
     if (cols > rows) L = cols;
     Q = new double *[L];
     for (i = 0; i < L; i++) Q[i] = new double[L];

     for (i = 0; i < rows; i++)
         for (j = 0; j < cols; j++)
             Q[i][j] = Loadings[i][j];

     d = GraphOut->XScBar->Position;
     if (d != GraphOut->oldx)
     {
        d = d - GraphOut->oldx; //increment in change
        d = d / 57.2958; // convert to radians
        for (L = 0; L < rows; L++)
        {
            A = sin(d);
            b = cos(d);
            Q[L][col1] = Loadings[L][col1] * b - Loadings[L][col2] * A;
            Q[L][col2] = Loadings[L][col1] * A + Loadings[L][col2] * b;
        }
        for (i1 = 0; i1 < rows; i1++)
            for (j1 = 0; j1 < cols; j1++) Loadings[i1][j1] = Q[i1][j1];
     }
     for (L = 0; L < rows; L++)
     {
         xvector[L] = Q[L][col1];
         yvector[L] = Q[L][col2];
     }
     titlestr = "Plot of Orthogonal Factors";
     sprintf(outline,"Factor %2d",col1+1);
     x_axis = outline;
     sprintf(outline,"Factor %2d",col2+1);
     y_axis = outline;
     factplot(xvector, yvector, rows, titlestr.c_str(),
              x_axis.c_str(), y_axis.c_str(), -1.0, 1.0, -1.0, 1.0);
     for (i = 0; i < L; i++) delete[] Q[i];
     delete[] Q;
} // end of graphical rotation

//------------------------------------------------------------------------
void factplot(double *X, double *Y, int NoCases, char *titlestr,
     char *x_axis, char *y_axis, double x_min, double x_max, double y_min,
     double y_max)
{
     int i, j, xslot, height, row;
     double MaxY, incrementx, incrementy, rangex, rangey, swap;
     bool overlap;
     char plotstring[62][61];
     char ValueString[11];
     char outline[81];

     GraphOut->Redit->Clear();
     height = 20;
     rangex = x_max - x_min;
     incrementx = rangex / 9.0;
     rangey = y_max - y_min;
     incrementy = rangey / height;
     // sort in ascending order
     for (i = 0; i < NoCases - 1; i++)
     {
          for (j = i + 1; j < NoCases; j++)
          {
               if (Y[i] < Y[j])
               {
                    swap = Y[i];
                    Y[i] = Y[j];
                    Y[j] = swap;
                    swap = X[i];
                    X[i] = X[j];
                    X[j] = swap;
               }
          }
     }
     // Print Heading
     sprintf(outline,"             SCATTERPLOT - %s",titlestr);
     GraphOut->Redit->Lines->Add(outline);
     GraphOut->Redit->Lines->Add("");
     MaxY = y_max;
     for (i = 0; i <  60; i++)
          for (j = 0; j < height + 1; j++) plotstring[j][i] = ' ';
     // Set up the plot strings with the data
     row = -1;
     while (MaxY > y_min)
     {
          row++;
          plotstring[row][30] = '|';
          if (row == (height / 2))
          {
               for (i = 0; i < 60; i++) plotstring[row][i] = '-';
          }
          for (i = 0; i < NoCases; i++)
          {
               if ((MaxY >= Y[i]) && (Y[i] > (MaxY - incrementy)))
               {
                    xslot = int(((X[i] - x_min) / rangex) * 60.0);
                    if (xslot < 0) xslot = 0;
                    if (xslot > 59) xslot = 59;
                    overlap = false;
                    //itoa(i,ValueString,10);
                    //howlong = strlen(ValueString);
                    //for (L = xslot; L < (xslot + howlong - 1); L++)
                    //{
                      if (plotstring[row][xslot] != ' ') overlap = true;
                    //}
                    if (overlap == true) plotstring[row][xslot] = '*';
                    else
                    {
                      //for (L = 0; L < howlong; L++)
                      //    plotstring[row][xslot+L] = ValueString[L];
                      plotstring[row][xslot] = '.';
                    }
               }
          }
          MaxY = MaxY - incrementy;
     } // end of while statement
     // print the plot
     sprintf(outline,"%70s",y_axis);
     GraphOut->Redit->Lines->Add(outline);
     for (i = 0; i < row; i++)
     {
          strcpy(outline,"");
          for (j = 0; j < 60; j++) outline[j] = plotstring[i][j];
          outline[60] = '\0';
          strcat(outline,"|-");
          sprintf(ValueString,"%6.2f",y_max - i * incrementy + incrementy);
          strcat(outline,ValueString);
          GraphOut->Redit->Lines->Add(outline);
     }
     sprintf(outline,"_______________________________________________________________");
     GraphOut->Redit->Lines->Add(outline);
     strcpy(outline,"");
     for (i = 0; i < 10; i++)
        strcat(outline,"   |  ");
     GraphOut->Redit->Lines->Add(outline);
     sprintf(outline,"%s",x_axis);
     GraphOut->Redit->Lines->Add(outline);
     strcpy(outline,"");
     for (i = 0; i < 10; i++)
     {
         sprintf(ValueString,"%6.2f",x_min + (i * incrementx));
         strcat(outline,ValueString);
     }
     GraphOut->Redit->Lines->Add(outline);
} //End of factplot procedure
//------------------------------------------------------------------------

void __fastcall TGraphOut::XScBarChange(TObject *Sender)
{
     int d = XScBar->Position;
     XDegEdit->Text = d;
     if (d != oldx) rotate();
     oldx = d;
}
//---------------------------------------------------------------------------

void __fastcall TGraphOut::FormShow(TObject *Sender)
{
     factend = false;
     oldx = 0;
     col1 = 0;
     col2 = 1;
     XDegEdit->Text = 0;
     rotate();
}
//---------------------------------------------------------------------------


void __fastcall TGraphOut::NextBtnClick(TObject *Sender)
{
     if ((col2 == cols-1) && (col1 == cols-2))
     {
        Application->MessageBox("All factors plotted.","END PLOT",MB_OK);
        return;
     }
     col2++;
     if (col2 > cols-1)
     {
        col1++;
        col2 = col1 + 1;
     }
     XScBar->Position = 0;
     rotate();
}
//---------------------------------------------------------------------------

