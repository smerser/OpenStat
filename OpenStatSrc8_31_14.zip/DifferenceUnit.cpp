//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DifferenceUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDifferenceFrm *DifferenceFrm;
//---------------------------------------------------------------------------
__fastcall TDifferenceFrm::TDifferenceFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
