//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "DblDeclineUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TDblDeclineForm *DblDeclineForm;
//---------------------------------------------------------------------------
__fastcall TDblDeclineForm::TDblDeclineForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TDblDeclineForm::ResetBtnClick(TObject *Sender)
{
    CostEdit->Text = "";
    LifeEdit->Text = "";
    EndEdit->Text = "";
    PeriodEdit->Text = "";
    DeprecEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TDblDeclineForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TDblDeclineForm::ComputeBtnClick(TObject *Sender)
{
     Extended  Depreciation, Cost, Salvage;
     int Life, Period;

     Cost = StrToFloat(CostEdit->Text);
     Salvage = StrToFloat(EndEdit->Text);
     Life = StrToInt(LifeEdit->Text);
     Period = StrToInt(PeriodEdit->Text);
     Depreciation = DoubleDecliningBalance(Cost, Salvage, Life, Period);
     DeprecEdit->Text = FloatToStr(Depreciation);
}
//---------------------------------------------------------------------------
