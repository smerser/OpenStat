//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BrowserUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"
TBrowserForm *BrowserForm;
//---------------------------------------------------------------------------
__fastcall TBrowserForm::TBrowserForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
