//---------------------------------------------------------------------------

#ifndef AnovaUnitH
#define AnovaUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAnovaForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TListBox *VarList;
   TBitBtn *DepInBtn;
   TBitBtn *Factor1InBtn;
   TBitBtn *Factor2InBtn;
   TBitBtn *Factor3InBtn;
   TBitBtn *DepOutBtn;
   TBitBtn *Factor1OutBtn;
   TBitBtn *Factor2OutBtn;
   TBitBtn *Factor3OutBtn;
   TLabel *Label2;
   TLabel *Label3;
   TLabel *Label4;
   TLabel *Label5;
   TEdit *DepVarEdit;
   TEdit *Factor1Edit;
   TEdit *Factor2Edit;
   TEdit *Factor3Edit;
   TMemo *Memo1;
   TRadioGroup *Factor1TypeGrp;
   TRadioGroup *Factor2TypeGrp;
   TRadioGroup *Factor3TypeGrp;
   TGroupBox *GroupBox1;
   TCheckBox *ScheffeChk;
   TCheckBox *TukeyHSDChk;
   TCheckBox *TukeyBChk;
   TCheckBox *TukeyKramerChk;
   TCheckBox *NewmanKeulsChk;
   TCheckBox *BonferroniChk;
   TCheckBox *OrthogonalChk;
   TRadioGroup *OptionsBox;
   TLabel *Label6;
   TLabel *Label7;
   TEdit *OverAllEdit;
   TEdit *PostHocEdit;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *OKBtn;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall DepInBtnClick(TObject *Sender);
   void __fastcall Factor1InBtnClick(TObject *Sender);
   void __fastcall Factor2InBtnClick(TObject *Sender);
   void __fastcall Factor3InBtnClick(TObject *Sender);
   void __fastcall DepOutBtnClick(TObject *Sender);
   void __fastcall Factor1OutBtnClick(TObject *Sender);
   void __fastcall Factor2OutBtnClick(TObject *Sender);
   void __fastcall Factor3OutBtnClick(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
//   char outline[121];
   AnsiString outline;
   AnsiString cellstring;
   double SSDep, SSErr, SSF1, SSF2, SSF3, SSF1F2, SSF1F3, SSF2F3, SSF1F2F3;
   double MSDep, MSErr, MSF1, MSF2, MSF3, MSF1F2, MSF1F3, MSF2F3, MSF1F2F3;
   double DFTot, DFErr, DFF1, DFF2, DFF3, DFF1F2, DFF1F3, DFF2F3, DFF1F2F3;
   double Omega, OmegaF1, OmegaF2, OmegaF3, OmegaF1F2, F, MinSize, MaxSize;
   double OmegaF1F3, OmegaF2F3, OmegaF1F2F3;
   double FF1, FF2, FF1F2, ProbF1, ProbF2, ProbF3, ProbF1F2, ProbF1F3;
   double FF3, FF2F3, FF1F3, FF1F2F3, ProbF2F3, ProbF1F2F3;
   double MeanDep, MeanF1, MeanF2, MeanF3, X;
   double *cellcnts;    // array of cell counts
   double *cellvars;    // arrray of cell sums of squares then variances
   double *cellsums;    // array of cell sums then means
   double **counts;     // matrix for 2-way containing cell sizes
   double **sums;       // matrix for 2-way containing cell sums
   double **vars;       // matrix for 2-way containing sums of squares
   double *RowSums;     // 2 way row sums
   double *ColSums;     // 2 way col sums
   double *RowCount;    // 2 way row count
   double *ColCount;    // 2 way col count
   double *SlcSums;     // 3 way slice sums
   double *SlcCount;    // 3 way slice counts
   double *OrdMeansA, *OrdMeansB, *OrdMeansC; // reordered means for f1, f2, f3
   double OverallAlpha, PostHocAlpha; // alphas for tests
   double ***wsum, ***wx2; // : DblDyneCube
   int NoSelected, intvalue, N;
   int *ColNoSelected;
   int DepVarCol, F1Col, F2Col, F3Col, Nf1cells, Nf2cells, Nf3cells;
   int minf1, maxf1, minf2, maxf2, minf3, maxf3, nofactors, totcells;
   int NoGrpsA, NoGrpsB, NoGrpsC;
   int ***ncnt; // : IntDyneCube;
   int OKterms[15];
   bool CompError;
   bool equal_grp;   // check for equal groups for post-hoc tests

   void __fastcall getlevels(TObject *Sender);
   void __fastcall Calc1Way(TObject *Sender);
   void __fastcall OneWayTable(TObject *Sender);
   void __fastcall OneWayPlot(TObject *Sender);
   void __fastcall Calc2Way(TObject *Sender);
   void __fastcall TwoWayTable(TObject *Sender);
   void __fastcall TwoWayPlot(TObject *Sender);
   void __fastcall Calc3Way(TObject *Sender);
   void __fastcall ThreeWayTable(TObject *Sender);
   void __fastcall ThreeWayPlot(TObject *Sender);
   void __fastcall TwoWayContrasts(TObject *Sender);
   void __fastcall TAnovaForm::ThreeWayContrasts(TObject *Sender);

public:		// User declarations
   __fastcall TAnovaForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAnovaForm *AnovaForm;
//---------------------------------------------------------------------------
#endif
