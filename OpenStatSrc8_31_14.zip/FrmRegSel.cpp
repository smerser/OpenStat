//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "stdlib.h"
#include "FrmRegSel.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TRegVarSel *RegVarSel;
int BlkCnt = 0;
int BlkNo = 0;
int NoInBlock[11];
AnsiString Blocks[11][50];
//---------------------------------------------------------------------------
__fastcall TRegVarSel::TRegVarSel(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BtnOKClick(TObject *Sender)
{
	if (BlkCnt > 0) // clear independent list and load with blocks
    {
        if (LstIndependent->Items->Count > 0) //another block
        	BtnNextClick(this);

    	LstIndependent->Items->Clear();
        for (int i = 0; i <BlkCnt; i++)
        {
        	for (int j = 0; j < NoInBlock[i]; j++)
            {
            	LstIndependent->Items->Add(Blocks[i][j]);
            }
            LstIndependent->Items->Add("$$$$$");
        }
    }
	RegVarSel->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BtnCancelClick(TObject *Sender)
{
	RegVarSel->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BitBtn1Click(TObject *Sender)
{
	int index;

    index = LstVariables->ItemIndex;
    DepVar->Text = LstVariables->Items->Strings[index];
    LstVariables->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BitBtn2Click(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstVariables->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstVariables->Selected[i])
         {
            cellstring = LstVariables->Items->Strings[i];
            LstIndependent->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstVariables->Items->Count; i++)
           {
               if (LstVariables->Selected[i])
               {
                  LstVariables->Items->Delete(i);
                  count--;
               }
           }
     }
    BtnOK->Enabled = true;
    if (BtnNext->Enabled) BtnPrevious->Enabled = true;
    BtnNext->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BtnResetClick(TObject *Sender)
{
	//int noselected;
    AnsiString cellstring;
    char BlkNoStr[5];
    char BlkCntStr[5];
    char LabelStr[15] = "";

    /*
    noselected = LstIndependent->Items->Count;
    if (noselected > 0)
    {
    	for (int i = 0; i < noselected; i++)
        {
    		cellstring = LstIndependent->Items->Strings[i];
            LstVariables->Items->Add(cellstring);
        }
    }
    */
	if (BlkCnt > 0)
    {
    	for (int i = 0; i < BlkCnt; i++)
        {
        	//for (int j = 0; j < NoInBlock[i]; j++)
            //{
            //	LstVariables->Items->Add(Blocks[i][j]);
            //}
            NoInBlock[i] = 0;
        }
        BlkCnt = 0;
        BlkNo = 0;
    }

 	LstIndependent->Clear();
    itoa(BlkNo+1,BlkNoStr,10);
    itoa(BlkCnt+1,BlkCntStr,10);
    strcat(LabelStr,"Block ");
    strcat(LabelStr,BlkNoStr);
    strcat(LabelStr," of ");
    strcat(LabelStr,BlkCntStr);
    LblBlock->Caption = LabelStr;
    cellstring = DepVar->Text;
    LstVariables->Items->Add(cellstring);
    BtnNext->Enabled = false;
    BtnPrevious->Enabled = false;
	CmbMethod->ItemIndex = 0;
	CmbMethod->Text = "Enter";
    DepVar->Text = "";
}

//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BtnNextClick(TObject *Sender)
{
    char BlkNoStr[5];
    char BlkCntStr[5];
    char LabelStr[15] = "";

    //First, save current block list and clear the list space
    for (int i = 0; i < LstIndependent->Items->Count;i++)
    {
    	Blocks[BlkNo][i] = LstIndependent->Items->Strings[i];
    }
	NoInBlock[BlkNo] = LstIndependent->Items->Count;
    LstIndependent->Clear();
    ++BlkNo;
    if (BlkNo > BlkCnt) ++BlkCnt;
    itoa(BlkNo+1,BlkNoStr,10);
    itoa(BlkCnt+1,BlkCntStr,10);
    strcat(LabelStr,"Block ");
    strcat(LabelStr,BlkNoStr);
    strcat(LabelStr," of ");
    strcat(LabelStr,BlkCntStr);
	LblBlock->Caption = LabelStr;
}

//---------------------------------------------------------------------------

void __fastcall TRegVarSel::BtnPreviousClick(TObject *Sender)
{
    char BlkNoStr[5];
    char BlkCntStr[5];
    char LabelStr[15] = "";

	if (BlkNo > 1)
    {
        // Save the current block list and load previous block list
	    for (int i = 0; i < LstIndependent->Items->Count;i++)
    	{
    		Blocks[BlkNo][i] = LstIndependent->Items->Strings[i];
        	LstIndependent->Clear();
    	}
     	--BlkNo;
        for (int i = 0; i < NoInBlock[BlkNo]; i++)
        {
        	LstIndependent->Items->Add(Blocks[BlkNo][i]);
        }
    	itoa(BlkNo+1,BlkNoStr,10);
    	itoa(BlkCnt+1,BlkCntStr,10);
    	strcat(LabelStr,"Block ");
    	strcat(LabelStr,BlkNoStr);
    	strcat(LabelStr," of ");
    	strcat(LabelStr,BlkCntStr);
		LblBlock->Caption = LabelStr;
    }
}

//--------------------------------------------------------------------------
void __fastcall TRegVarSel::CmbMethodChange(TObject *Sender)
{
	if ((CmbMethod->ItemIndex + 1) > 1)
    {
     	ChkRawPredict->Enabled = false;
        ChkzPredicted->Enabled = false;
        ChkRawResid->Enabled = false;
        ChkzResid->Enabled = false;
    }
    else
    {
     	ChkRawPredict->Enabled = true;
        ChkzPredicted->Enabled = true;
        ChkRawResid->Enabled = true;
        ChkzResid->Enabled = true;
	}
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::FormCreate(TObject *Sender)
{
	CmbMethod->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void __fastcall TRegVarSel::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OpenStat.hlp";
  Application->HelpJump("mlr");

}
//---------------------------------------------------------------------------

