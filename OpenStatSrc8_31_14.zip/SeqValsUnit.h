//---------------------------------------------------------------------------

#ifndef SeqValsUnitH
#define SeqValsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmSeqValues : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *GenNoEdit;
    TLabel *Label2;
    TEdit *StartEdit;
    TLabel *Label3;
    TEdit *IncrEdit;
    TLabel *Label4;
    TEdit *LabelEdit;
    TButton *CancelBtn;
    TButton *ResetBtn;
    TButton *OKBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmSeqValues(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmSeqValues *FrmSeqValues;
//---------------------------------------------------------------------------
#endif
