//---------------------------------------------------------------------------

#ifndef MDSUnitH
#define MDSUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TMDSForm : public TForm
{
__published:	// IDE-managed Components
     TStringGrid *Grid;
     TLabel *Label1;
     TEdit *NIEdit;
     TLabel *Label6;
     TLabel *Label7;
     TButton *FileOpenBtn;
     TButton *SaveFileBtn;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TMemo *Memo1;
     TSaveDialog *SaveDialog1;
     TOpenDialog *OpenDialog1;
     TButton *PrintBtn;
	TLabel *Label2;
	TEdit *NDEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall NIEditKeyPress(TObject *Sender, char &Key);
     void __fastcall GridKeyPress(TObject *Sender, char &Key);
     void __fastcall SaveFileBtnClick(TObject *Sender);
     void __fastcall FileOpenBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PrintBtnClick(TObject *Sender);
private:	// User declarations
     int NI, ND, NN, I, J, K, L1, VD, KI, IT, IZ, IW, N1, I1, I2, MA;
//     double E1, E2, E3, E4, E5, E6, PD, MD, SIG, U, T, ST, GN, EI, CC, T1, T2, SM;
//     double R1, RU, FR, U3, XD;
//     double AD;
//     double **D, **X, **Y, **G, **CQ, **R, **B;
//     double *DS, *DH, *V;
//     int *Q4, *Q5, *Q6;
//     int *NT, *L, *LB;
//     char outline[101];
//     char valstr[12];
//     void __fastcall NORMALIZE(TObject *Sender);
//     void __fastcall DISTANCE(TObject *Sender);
//     void __fastcall REGRESSION(TObject *Sender);
//     void __fastcall GRADIENT(TObject *Sender);
//     void __fastcall MINIMIZE(TObject *Sender);
//     void __fastcall CENTER(TObject *Sender);
//     void __fastcall Plotit(void);

     void __fastcall MDSCAL(TObject *Sender);
     void __fastcall CMDS(int N, double **A, int IPRINT, double *W,
                          double *FV1, double **Z, int IERR);
     void __fastcall TMDSForm::PROJN(int N, double *EVALS, double **A,
                double **Z, double *VEC);
     void __fastcall OUTMAT(int N, double **ARRAY, char *Title);
     void __fastcall OUTEVL(int NVALS, double *VALS);
//     void __fastcall OUTEVC(int NDIM, double **VECS, char *Title);
public:		// User declarations
     __fastcall TMDSForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMDSForm *MDSForm;
//---------------------------------------------------------------------------
#endif
