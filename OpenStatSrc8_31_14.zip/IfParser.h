//---------------------------------------------------------------------------
#ifndef IfParserH
#define IfParserH
//---------------------------------------------------------------------------
#endif
#include "MainUnit.h"
void CheckParens(int &LeftCnt, int &RightCnt, char *Expression);
void GetExpression(char *Expression, char *SubExpr, int &LeftParen,\
	 int &RightParen);
void DelSubSt(char * Expression, unsigned int FromPos, unsigned int ToPos);
void TrimParens(char *Expression);
int LeadOp(char *Expression);
int OpPosition(char *Expression, char operation[], int &opleft, int &opright);
void RemoveBlanks(char *Expression);
void GetLeftSt(char *Expression, char *LeftSt, unsigned int FromPos);
void GetRightSt(char *Expression, char *RightSt, unsigned int FromPos);
int isnumeric(char *Expression);
int GetVarIndex(char *varstring, char **VarLabels, int NoVars);
void BuildIfList(char *Expression, char **ExprList, int &NoExpr, char **JoinOps);
void parse(char *Expression, char **ExprList, int &NoExpr, char **Ops,\
		char **LeftValue, char **RightValue, char **JoinOps);
bool TruthValue(int caseno, int ExpNo, char *LeftStr, char *RightStr,\
				char **OpCode, char **VarLabels, int NoVars);
                
