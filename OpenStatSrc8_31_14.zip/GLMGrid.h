//---------------------------------------------------------------------------
#ifndef GLMGridH
#define GLMGridH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TGLMGridFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *SaveBtn;
    TButton *ReturnBtn;
    TStringGrid *Grid;
    TSaveDialog *SaveDialog1;
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall SaveBtnClick(TObject *Sender);
private:	// User declarations
    struct VarDefs {
        int VarNo; // Column number in grid
        char Label[9]; // column heading label
        char LongLabel[21]; // descriptive label
        int NoValLabels; // no. of labels for values of the variable
        double Values[20]; // values for which there are labels
        char ValLabels[20][11]; // Labels for values
    	int Type; //0=numeric, 1 = alphanumeric, etc.
        int VarWidth; // 8=default value
        int VarDecimals; // 2=default value
        int ValAlign; // 1= left, 2=center; 3=right (default)
        int ColWidth; // Column Width in pixels(uses default value=0 if zero)
        bool BlankMiss; // default is false
        bool MissingVals; // default is false
        double LowMiss; // lowest in a range for missing values
        double HighMiss; // highest in a range for missing values
        char DiscreteMiss[17]; // a specific value for missing values
    };

public:		// User declarations
    __fastcall TGLMGridFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGLMGridFrm *GLMGridFrm;
//---------------------------------------------------------------------------
#endif
