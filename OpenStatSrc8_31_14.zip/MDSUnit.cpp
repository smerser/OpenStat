//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "stdio.h"
#include "math.h"
#include "MatrixUnit.h"
#include "MDSUnit.h"
#include "GraphUnit.h"
#include "functions.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMDSForm *MDSForm;
//---------------------------------------------------------------------------
__fastcall TMDSForm::TMDSForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMDSForm::ResetBtnClick(TObject *Sender)
{
     NIEdit->Text = "";
     NDEdit->Text = 2;
     for (int i = 0; i <= Grid->RowCount; i++)
         for (int j = 0; j <= Grid->ColCount; j++)
             Grid->Cells[j][i] = "";
     Grid->RowCount = 2;
     Grid->ColCount = 2;
     Grid->Cells[0][0] = "LABEL";
}
//---------------------------------------------------------------------------
void __fastcall TMDSForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TMDSForm::NIEditKeyPress(TObject *Sender, char &Key)
{
    double value;
    char valstring[21];

    if (Key == 13) // return
    {
            NI = atoi(NIEdit->Text.c_str());
            NN = NI * (NI - 1) / 2;
            Grid->ColCount = NI + 1;
            Grid->RowCount = NI + 1;
            char label[11];
/*
            for (int i = 0; i < NI; i++)
            {
                sprintf(label,"Object %d",i+1);
                Grid->Cells[i+1][0] = label;
                Grid->Cells[0][i+1] = label;
            }
*/
            Grid->Row = 1;
            Grid->Col = 1;
            Grid->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TMDSForm::GridKeyPress(TObject *Sender, char &Key)
{
     int row, col;

     row = Grid->Row;
     col = Grid->Col;
     if ((Key == 13) || (Key == VK_TAB))
     {
        if (row != col) Grid->Cells[row][col] = Grid->Cells[col][row];
     }
}
//---------------------------------------------------------------------------

void __fastcall TMDSForm::SaveFileBtnClick(TObject *Sender)
{
     FILE *SaveFile;
     int i, j;
     AnsiString OpStr;
     AnsiString BackUpName;
     char astring[121];
     int Rows1 = Grid->RowCount;
     int Cols1 = Grid->ColCount;

     SaveDialog1->Filter = "MDS Matrix (*.mds)|*.MDS|All (*.*)|*.*";
     SaveDialog1->FilterIndex = 1;
     SaveDialog1->DefaultExt = ".MDS";
     if (SaveDialog1->Execute())
     {
          SaveFile = fopen(SaveDialog1->FileName.c_str(),"w");
          fwrite(&Rows1,sizeof(Rows1),1,SaveFile);
          fwrite(&Cols1,sizeof(Cols1),1,SaveFile);
          for (i = 0; i < Rows1; i++)
          {
              for (j = 0; j < Cols1; j++)
              {
                  strcpy(astring,Grid->Cells[j][i].c_str());
                  fwrite(astring,sizeof(astring),1,SaveFile);
              }
          }
          fclose(SaveFile);
     }
}
//---------------------------------------------------------------------------

void __fastcall TMDSForm::FileOpenBtnClick(TObject *Sender)
{
     FILE *SaveFile;
     int i, j, Rows, Cols;
     AnsiString cellstring;
     AnsiString OpStr;
     AnsiString FName;
     char filename[121];

     OpenDialog1->Filter = "MDS Matrix (*.mds)|*.MDS|All (*.*)|*.*";
     OpenDialog1->FilterIndex = 1;
     OpenDialog1->DefaultExt = ".MDS";
     if (OpenDialog1->Execute())
     {
          strcpy(filename,OpenDialog1->FileName.c_str());
          SaveFile = fopen(filename,"r");
          fread(&Rows,sizeof(Rows),1,SaveFile);
          Grid->RowCount = Rows;
          fread(&Cols,sizeof(Cols),1,SaveFile);
          Grid->ColCount = Cols;
          for (i = 0; i < Rows; i++)
          {
               for (j = 0; j < Cols; j++)
               {
                    fread(filename,sizeof(filename),1,SaveFile);
                    cellstring = filename;
                    Grid->Cells[j][i] = Trim(cellstring);
               }
          }
          fclose(SaveFile);
          NI = Rows-1;
          NIEdit->Text = IntToStr(NI);
     }
}
//---------------------------------------------------------------------------


void __fastcall TMDSForm::ComputeBtnClick(TObject *Sender)
{
	MDSCAL(this);
}
//---------------------------------------------------------------------------
/*
void __fastcall TMDSForm::NORMALIZE(TObject *Sender)
{
     T1 = 0.0;
     EI = EI + 1;
     for (I = 1; I <= ND; I++)
     {
         T2 = 0.0;
         for (J = 1; J <= NI; J++) T2 = T2 + X[I][J];
         T2 = T2 / NI;
         for (J = 1; J <= NI; J++)
         {
             X[I][J] = X[I][J] - T2;
             T1 = T1 + pow(X[I][J],2);
         }
     }
     T1 = sqrt(1.0 / T1);
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             X[I][J] = T1 * X[I][J];
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::DISTANCE(TObject *Sender)
{
     for (J = 1; J <= NN; J++)
     {
         I1 = D[J][1];
         I2 = D[J][2];
         SM = 0.0;
         for (I = 1; I <= ND; I++)
         {
             AD = X[I][I1] - X[I][I2];
             SM = SM + (AD * AD);
         }
         SM = sqrt(SM);
         DS[J] = SM;
     }
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::REGRESSION(TObject *Sender)
{
     int KC, MB, LU, NZ, MY, KD, MZ, KW, MU, KU, MW, MA;
     double DV, DX, WF, WE, WT, DU;

     MA = 1;
pos2040:
     KC = NT[MA];
     MB = MA + KC - 1;
     LB[MA] = KC;
     LB[MB] = KC;
     T1 = 0.0;
     for (I = MA; I <= MB; I++) T1 = T1 + DS[I];
     DH[MA] = T1;
     if ((KC - 1) != 0) DH[MB] = MB - MA + 1;
     MA = MA + KC;
     if ((MA - NN - 1) < 0) goto pos2040;
     MA = 1;
pos2140:
     LU = 2;
     NZ = 0;
pos2150:
     KC = LB[MA];
     MB = MA + KC - 1;
     if ((KC - 1) > 0) goto pos2180;
     WT = 1.0;
     goto pos2190;
pos2180:
     WT = DH[MB];
pos2190:
     DV = DH[MA] / WT;
     if (LU == 2) goto pos2310;
     if ((MA - 1) == 0) goto pos2300;
     MY = MA - 1;
     KD = LB[MY];
     MZ = MY - KD + 1;
     if ((KD - 1) > 0) goto pos2250;
     WE = 1.0;
     goto pos2260;
pos2250:
     WE = DH[MY];
pos2260:
     DX = DH[MZ] / WE;
     if ((DX - DV) < 0.0) goto pos2300;
     KW = KC + KD;
     LB[MZ] = KW;
     LB[MB] = KW;
     DH[MZ] = DH[MZ] + DH[MA];
     DH[MB] = WT + WE;
     NZ = 0;
     MA = MZ;
     goto pos2410;
pos2300:
     NZ = NZ + 1;
     goto pos2410;
pos2310:
     if ((MB - NN) == 0) goto pos2400;
     MU = MB + 1;
     KU = LB[MU];
     MW = MU + KU - 1;
     if ((KU - 1) > 0) goto pos2350;
     WF = 1.0;
     goto pos2360;
pos2350:
     WF = DH[MW];
pos2360:
     DU = DH[MU] / WF;
     if ((DV - DU) < 0.0) goto pos2400;
     KW = KC + KU;
     LB[MA] = KW;
     LB[MW] = KW;
     DH[MA] = DH[MA] + DH[MU];
     DH[MW] = WT + WF;
     NZ = 0;
     goto pos2410;
pos2400:
     NZ = NZ + 1;
pos2410:
     LU = 3 - LU;
     if ((NZ - 1) <= 0) goto pos2150;
     if ((MB - NN) == 0) goto pos2450;
     MA = MB + 1;
     goto pos2140;
pos2450:
     MA = 1;
pos2460:
     KC = LB[MA];
     MB = MA + KC - 1;
     if ((KC - 1) == 0) goto pos2520;
     T1 = DH[MA] / DH[MB];
     for (I = MA; I <= MB; I++) DH[I] = T1;
     goto pos2530;
pos2520:
     DH[MA] = DS[MA];
pos2530:
     MA = MB + 1;
     if ((MA - NN - 1) < 0) goto pos2460;
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::GRADIENT(TObject *Sender)
{
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             G[I][J] = 0.0;
     T1 = T * T;
     RU = 1 / (U * T);
     U3 = U / (T1 * T);
     for (int L = 1; L <= NN; L++)
     {
         if (DS[L] == 0.0) goto pos2680;
         FR = U3 * DS[L] - RU * (DS[L] - DH[L]);
         FR = -FR / DS[L];
         for (K = 1; K <= ND; K++)
         {
             I = D[L][1];
             J = D[L][2];
             XD = X[K][I] - X[K][J];
             T1 = FR * XD;
             G[K][I] = G[K][I] + T1;
             G[K][J] = G[K][J] - T1;
         }
pos2680:
     }
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::MINIMIZE(TObject *Sender)
{
     double E7, E8, TT, A, PX;
     int IK;

     R1 = 1.0;
     E8 = 2 * ST;
     IK = 1;
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             Y[I][J] = X[I][J];
pos2740:
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             X[I][J] = Y[I][J] - R1 * G[I][J] / GN;
     NORMALIZE(this);
     DISTANCE(this);
     REGRESSION(this);
     U = 0.0;
     T = 0.0;
     for (I = 1; I <= NN; I++)
     {
         U = U + pow((DS[I] - DH[I]),2);
         T = T + pow(DS[I],2);
     }
     U = sqrt(U);
     T = sqrt(T);
     E7 = U / T;
     if (E8 <= ST) goto pos2890;
     IK = IK + 1;
     if (IK > E3) goto pos3120;
     R1 = R1 / 2.0;
     E8 = E7;
     goto pos2740;
pos2890:
     if (E7 <= E8) goto pos2910;
     A = 2;
     TT = E8;
     E8 = E7;
     E7 = TT;
     R1 = R1 * A;
     goto pos2920;
pos2910:
     A = 0.5;
pos2920:
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             X[I][J] = Y[I][J] - A * R1 * G[I][J] / GN;
     NORMALIZE(this);
     DISTANCE(this);
     REGRESSION(this);
     U = 0;
     T = 0;
     for (I = 1; I <= NN; I++)
     {
         U = U + pow((DS[I] - DH[I]),2);
         T = T + pow(DS[I],2);
     }
     U = sqrt(U);
     T = sqrt(T);
     E6 = U / T;
     PX = (E8 - E7) * (E7 - E6);
     if (PX <= 0) goto pos3070;
     R1 = R1 * A;
     E8 = E7;
     E7 = E6;
     IK = IK + 1;
     if ((IK - E3) < 0) goto pos2920;
     goto pos3120;
pos3070:
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             X[I][J] = Y[I][J] - R1 * G[I][J] / GN;
     E6 = E7;
     IW = 1;
     NORMALIZE(this);
     return;
pos3120:
     for (I = 1; I <= ND; I++)
         for (J = 1; J <= NI; J++)
             X[I][J] = Y[I][J];
     IW = 0;
     sprintf(outline,"Value of RHO = %10.6f too SMALL to continue with iterations.",R1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::CENTER(TObject *Sender)
{
     double S1, S2, S3, S4, Q7, S0, A, C, O, T, Z, E, F, H, AA, Q3, Q2, Y, RM;
     double D, W, FACT, V, Q, G, P, K1;
     double *EV;
     double **MAT, **Vectors;
     int L, M;

     GetDblVecMem(EV,ND+1);
     GetDblMatMem(MAT,ND+1,ND+1);
     GetDblMatMem(Vectors,ND+1,ND+1);

     for (K = 1; K <= ND; K++)
     {
         S1 = 0.0;
         S2 = 0.0;
         for (I = 1; I <= NI; I++)
         {
             S1 = S1 + X[K][I];
             S2 = S2 + (X[K][I] * X[K][I]);
         }
         S3 = S1 / (double)NI;
         S4 = sqrt(S2 - ((S1 * S1) / (double)NI));
         for (I = 1; I <= NI; I++) X[K][I] = (X[K][I] - S3) / S4;
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("R Matrix (Correlations between MDS Components)");
     FrmOutPut->RichOutPut->Lines->Add("");
     Q7 = 0.0;
     for (I = 1; I <= ND; I++)
     {
         for (J = 1; J <= ND; J++)
         {
             S0 = 0.0;
             for (K = 1; K <= NI; K++) S0 = S0 + (X[I][K] * X[J][K]);
             R[I][J] = S0;
             R[J][I] = S0;
         }
         Q7 = Q7 + R[I][I];
         strcpy(outline,"");
         for (J = 1; J <= ND; J++)
         {
             sprintf(valstr,"%7.3f ",R[I][J]);
             strcat(outline,valstr);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Examine these correlations between UNROTATED MDS Axes");
     FrmOutPut->RichOutPut->Lines->Add("If the correlations are small (near zero) this Unrotated");
     FrmOutPut->RichOutPut->Lines->Add("configuration is adequate for the final Sampling Unit");
     FrmOutPut->RichOutPut->Lines->Add("ordination.  However, if the correlation is large, this");
     FrmOutPut->RichOutPut->Lines->Add("suggests that the configuration needs to be ROTATED to its");
     FrmOutPut->RichOutPut->Lines->Add("Principal Axes.  The rotation is shown next.");
     FrmOutPut->ShowModal();

     // Calculate the principle components of R
     for (int i = 0; i < ND; i++)
         for (int j = 0; j < ND; j++) MAT[i][j] = R[i+1][j+1];
     SymMatRoots(MAT,ND,EV,Vectors);
     N1 = 0;
     for (int i = 0; i < ND; i++) if (EV[i] > 0.0) N1++;
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("               Percent of    Accumulated");
     FrmOutPut->RichOutPut->Lines->Add("Eigenvalue       Trace        % of Trace");
     FrmOutPut->RichOutPut->Lines->Add("-----------    ----------    -----------");

     W = 0.0;
     Q7 = 0.0;
     for (int i = 0; i < N1; i++) Q7 += EV[i];
     for (int i = 0; i < N1; i++)
     {
         sprintf(outline,"%3d = ",i+1);
         sprintf(valstr,"%7.3f",EV[i]);
         strcat(outline,valstr);
         sprintf(valstr,"%10.1f%", 100.0 * EV[i] / Q7);
         strcat(outline,valstr);
         W += EV[i] / Q7;
         sprintf(valstr,"%10.1f%",100.0 * W);
         strcat(outline,valstr);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         Q4[i+1] = i+1;
     }
     for (int i = 0; i < N1; i++)
     {
         sprintf(outline,"Eigenvector %3d = ", i+1);
         for (int j = 0; j < N1; j++)
         {
             sprintf(valstr,"%7.3f ",Vectors[i][j]);
             strcat(outline,valstr);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     for (I = 1; I <= N1; I++)
     {
         K = Q4[I];
         for (J = 1; J <= NI; J++)
         {
             CQ[I][J] = 0.0;
             for (int H = 1; H <= N1; H++) CQ[I][J] += Vectors[H-1][I-1] * X[H][J];
         }
     }
     ClearDblMatMem(Vectors,ND+1);
     ClearDblMatMem(MAT,ND+1);
     ClearDblVecMem(EV);
}
//---------------------------------------------------------------------
*/
void __fastcall TMDSForm::PrintBtnClick(TObject *Sender)
{
     double **mat;
     char ColHeader[21];
     char Title[41];
     AnsiString *RowLabels, *ColLabels;
     int Nrows, Ncols;

     Nrows = Grid->RowCount;
     Ncols = Grid->ColCount;
     GetDblMatMem(mat,Nrows,Ncols);
     RowLabels = new AnsiString[Nrows];
     ColLabels = new AnsiString[Ncols];

     strcpy(Title,"ENTERED DISTANCE MATRIX");
     strcpy(ColHeader,"COLUMN");

     for (int i = 1; i < Nrows; i++)
     {
         RowLabels[i-1] = Grid->Cells[i][0];
         ColLabels[i-1] = RowLabels[i-1];
         for (int j = 1; j < Ncols; j++)
         {
             mat[i-1][j-1] = StrToFloat(Grid->Cells[j][i]);
         }
     }
     ArrayPrint(mat, Nrows-1, Ncols-1, ColHeader, RowLabels, ColLabels, Title);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();
     delete[] ColLabels;
     delete[] RowLabels;
     ClearDblMatMem(mat,Nrows);
}
//---------------------------------------------------------------------------
/*
void __fastcall TMDSForm::Plotit(void)
{
          double **Xpoints, **Ypoints;
          double temp;

          GetDblMatMem(Xpoints,1,NI);
          GetDblMatMem(Ypoints,1,NI);

          for (int i = 1; i <= NI; i++)
          {
              	 Xpoints[0][i-1] = CQ[1][i];
                Ypoints[0][i-1] = CQ[2][i];
          } // next case i
          // sort on x's
          for (int i = 0; i < NI-1; i++)
          {
             		for (int k = i+1; k < NI; k++)
                  {
                  	if (Xpoints[0][i] > Xpoints[0][k]) // swap
                     {
          					temp = Xpoints[0][i];
                        Xpoints[0][i] = Xpoints[0][k];
                        Xpoints[0][k] = temp;
                        temp = Ypoints[0][i];
                        Ypoints[0][i] = Ypoints[0][k];
                        Ypoints[0][k] = temp;
                     }
                  }
          } // end of sort
          GraphForm->Heading = "COORDINATE 1 VERSUS COORDINATE 2";
          GraphForm->nosets = 1;
          GraphForm->nbars = NI;
          GraphForm->XTitle = "Coordinate 1";
          GraphForm->YTitle = "Coordinate 2";
          GraphForm->Ypoints = Ypoints;
          GraphForm->Xpoints = Xpoints;
          GraphForm->GraphType = 8;  // 2d plot
          GraphForm->barwideprop = 1.0;
          GraphForm->AutoScale = true;
          GraphForm->ShowLeftWall = true;
          GraphForm->ShowRightWall = true;
          GraphForm->ShowBottomWall = true;
          GraphForm->ShowBackWall = true;
          GraphForm->BackColor = clWhite;
          GraphForm->WallColor = clBlue;
          GraphForm->FloorColor = clTeal;
          GraphForm->ShowModal();
cleanup:
          ClearDblMatMem(Ypoints,1);
          ClearDblMatMem(Xpoints,1);
}
//---------------------------------------------------------------------------
*/
void __fastcall TMDSForm::MDSCAL(TObject *Sender)
{
   int N = StrToInt(NIEdit->Text); // size of distance matrix
   double **A, **A2, **DIST, *W1, *W2;
   int M = StrToInt(NDEdit->Text); // no. of projections desired

   GetDblMatMem(DIST,N+1,N+1);
   GetDblMatMem(A,N+1,N+1);
   GetDblMatMem(A2,N+1,N+1);
   GetDblVecMem(W1,N+1);
   GetDblVecMem(W2,N+1);

   // begin with input of data from grid above the diagonal
   for (int i = 0; i < N; i++)
   {
       for (int j = 0; j < N; j++)
       {
           A[i][j] = StrToFloat(Grid->Cells[j+1][i+1]);
           A2[i][j] = A[i][j];
       }
   }

   OUTMAT(N,A,"RAW INPUT MATIX");
   FrmOutPut->RichOutPut->Lines->Add("");

   double VALM = 0.0;
   for (int i = 0; i < N; i++)
   {
   	for (int i2 = 0; i2 < N; i2++)
      {
      	DIST[i][i2] = 0.0;
         for (int j = 0; j < M; j++)
                    DIST[i][i2] = DIST[i][i2] + pow(A[i][j] - A[i2][j],2);
         DIST[i][i2] = sqrt(DIST[i][i2]);
         if (DIST[i][I2] > VALM) VALM = DIST[i][i2];
      }
   }

//   FrmOutPut->RichOutPut->Lines->Add("Raw Distance Matrix");
//   OUTMAT(N,DIST,"DISTANCE MATIX");
//   FrmOutPut->RichOutPut->Lines->Add("");


//-----  Normalize to maximum distance = unity  ----------------------

	for (int i = 0; i < N; i++)
   {
   	for (int j = 0; j < N; j++)
      {
			DIST[i][j] = DIST[i][j] / VALM;
      }
   }

//   FrmOutPut->RichOutPut->Lines->Add("Normalized Distance Matrix");
   OUTMAT(N,DIST,"Normalized Distance Matrix");
   FrmOutPut->RichOutPut->Lines->Add("");

	int IERR = 0;
	int IPRINT = 2;
	CMDS(N,DIST,IPRINT, W1,W2,A2,IERR);
	if (IERR != 0) ShowMessage("Abnormal end. IERR = " + IntToStr(IERR));
   FrmOutPut->ShowModal();

   ClearDblVecMem(W2);
   ClearDblVecMem(W1);
   ClearDblMatMem(A2,N+1);
   ClearDblMatMem(A,N+1);
   ClearDblMatMem(DIST,N+1);
	return;
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::CMDS(int N, double **A, int IPRINT, double *W,
                               double *FV1, double **Z, int IERR)
{
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++C
//                                                                         C
//  Carry out a PRINCIPAL COORDINATES ANALYSIS                             C
//              (CLASSICAL MULTIDIMENSIONAL SCALING).                      C
//                                                                         C
//  To call:   CALL PCA(N,A,IPRINT,W1,W2,A2,IERR)    where                 C
//                                                                         C
//                                                                         C
//  N     : integer number of objects.                                     C
//  A     : input distances array, real, of dimensions N by N.             C
//          On output, A contains in the first 7 columns the projections   C
//          of the objects on the first 7 principal components.            C
//  IPRINT: print options.                                                 C
//          = 3: full printing of items calculated.                        C
//          = 2: printing of everything except the input distance matrix.  C
//          Otherwise: no printing.                                        C
//  W1,W2 : real vectors of dimension M (see called routines for use).     C
//          On output, W1 contains the eigenvalues (in increasing order of C
//          magnitude).                                                    C
//  A2    : real array of dimensions M * M (see called routines for use).  C
// IERR  : error indicator (normally zero).                               C
//                                                                         C
//                                                                         C
//  Inputs here are N, A, IPRINT (and IERR).                               C
//  Output information is contained in A, and W1.                          C
//  All printed outputs are carried out in easily recognizable subroutines C
//  called from the first subroutine following.                            C
//                                                                         C
//                                                                         C
//  F. Murtagh, ST-ECF/ESA/ESO, Garching-bei-Muenchen, January 1986.       C
//                                                                         C
//-------------------------------------------------------------------------C
   double **tempmat;
	double TOT = 0.0;
   GetDblMatMem(tempmat,N,N);

   for (int i1 = 0; i1 < N; i1++)
   {
   	W[i1] = 0.0;
      for (int i2 = 0; i2 < N; i2++)
      {
      	W[i1] += A[i1][i2];
         TOT += A[i1][i2];
      }
      W[i1] /= double (N);
   }
   TOT /= double (N * N);

   for (int i1 = 0; i1 < N; i1++)
   	for (int i2 = 0; i2 < N; i2++)
      	A[i1][i2] = -0.5 * ( A[i1][i2] - W[i1] - W[i2] - TOT );

//   FrmOutPut->RichOutPut->Lines->Add("A MATRIX");
   OUTMAT(N,A,"Matrix Analyzed"); // print the A matrix
   FrmOutPut->RichOutPut->Lines->Add("");

	// Carry out the eigenreduction.
   for (int i = 0; i < N; i++)
   	for (int j = 0; j < N; j++)
      	tempmat[i][j] = A[i][j]; // save A matrix (destroyed by root proc.)
//	int N2 = N;
   SymMatRoots(A, N, W, Z);
   for (int i = 0; i < N; i++)
   	for (int j = 0; j < N; j++)
			A[i][j] = tempmat[i][j]; // restore A matrix
   if (IERR != 0) return;

   // Output eigenvalues and eigenvectors.
	if (IPRINT >= 2)
   {
   	OUTEVL(N,W);
      OUTMAT(N,Z,"EIGENVECTORS");
   }

	// Determine projections and output them.
   PROJN(N,W,A,Z,FV1);
   ClearDblMatMem(tempmat,N);
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::OUTMAT(int N, double **ARRAY, char *Title)
{
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++C
//                                                                         C
//  Output array.                                                          C
//                                                                         C
//-------------------------------------------------------------------------C

   AnsiString *RowLabels, *ColLabels;

   RowLabels = new AnsiString[N];
   ColLabels = new AnsiString[N];
   for (int i = 1; i <= N; i++)
   {
   	RowLabels[i-1] = Grid->Cells[i][0];
      ColLabels[i-1] = RowLabels[i-1];
   }
   ArrayPrint(ARRAY, N, N, "OBJECT",RowLabels,ColLabels,Title);

   delete[] ColLabels;
   delete[] RowLabels;
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::OUTEVL(int NVALS, double *VALS)
{
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++C
//                                                                         C
//  Output eigenvalues in order of decreasing value.                       C
//  Ignore first (trivial) eigenvalue.                                     C
//                                                                         C
//-------------------------------------------------------------------------C
	int K;
   double CUM, VPC, VCPC, TOT;
   char outline[101];

   TOT = 0.0;
   for (K = 0; K < NVALS; K++) //DO 100 K = 1, NVALS-1
   	TOT = TOT + VALS[K]; // 100   CONTINUE

   FrmOutPut->RichOutPut->Lines->Add("EIGENVALUES FOLLOW.");
   CUM = 0.0;
   K = NVALS;
   FrmOutPut->RichOutPut->Lines->Add(" Eigenvalues       As Percentages    Cumul. Percentages");
   FrmOutPut->RichOutPut->Lines->Add(" -----------       --------------    ------------------");
   for (K = 0; K < NVALS; K++)
   {
      CUM = CUM + VALS[K];
      VPC = VALS[K] * 100.0 / TOT;
      VCPC = CUM * 100.0 / TOT;
      sprintf(outline,"%10.4f         %10.4f          %10.4f",VALS[K],VPC,VCPC);
      FrmOutPut->RichOutPut->Lines->Add(outline);
	}
   FrmOutPut->RichOutPut->Lines->Add("");
//   FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------

void __fastcall TMDSForm::PROJN(int N, double *EVALS, double **A,
                double **Z, double *VEC)
{
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++C
//                                                                         C
//  Determine projections of objects on 7 principal components.            C
//  Ignore first (trivial) axis.                                           C
//                                                                         C
//-------------------------------------------------------------------------C
	int NUM, J1, J3, L, J2;

//   NUM = MIN0(N,7);
   if (N > 7) NUM = 7;
   else NUM = N;

   for (J1 = 0; J1 < N; J1++) // DO 300 J1 = 1, N
   {
   	for (L = 0; L < N; L++)
      {
      	VEC[L] = A[J1][L];
      }
      for (J2 = 0; J2 < NUM; J2++) // DO 200 J2 = 1, NUM
      {
      	A[J1][J2] = 0.0;
         for (J3 = 0; J3 < N; J3++) // DO 100 J3 = 1, N
         {
         	A[J1][J2] = A[J1][J2] + VEC[J3] * Z[J3][J2];
         }
         if (EVALS[J2] > 0.0) A[J1][J2] =  A[J1][J2] / sqrt(EVALS[J2]);
         if (EVALS[J2] <= 0.0) A[J1][J2] = 0.0;
      } // 200      CONTINUE
   } // 300   CONTINUE
   AnsiString *RowLabels, *ColLabels;
   RowLabels = new AnsiString[N];
   ColLabels = new AnsiString[N];
   for (int i = 0; i < N; i++)
   {
   	ColLabels[i] = Grid->Cells[i+1][0];
      RowLabels[i] = ColLabels[i];
   }
//   int N2 = StrToInt(NDEdit->Text);
	ArrayPrint(A, N, N, "OBJECTS", RowLabels, ColLabels, "PROJECTIONS");
   delete[] ColLabels;
   delete[] RowLabels;
}

