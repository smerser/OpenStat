//---------------------------------------------------------------------------
#ifndef ItemBankH
#define ItemBankH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TItemBankFrm : public TForm
{
__published:	// IDE-managed Components
    TButton *OpenBtn;
    TButton *NewBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TLabel *Label2;
    TEdit *BankEdit;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OpenBtnClick(TObject *Sender);
    void __fastcall NewBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
    void __fastcall BankUpdate(void);
public:		// User declarations
    __fastcall TItemBankFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TItemBankFrm *ItemBankFrm;
//---------------------------------------------------------------------------
#endif
