//---------------------------------------------------------------------------
#ifndef FrmSelIfH
#define FrmSelIfH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Buttons.hpp>
//---------------------------------------------------------------------------
class TSelIf : public TForm
{
__published:	// IDE-managed Components
	TListBox *LstVars;
	TBitBtn *BtnVarIn;
	TEdit *TxtIfExpr;
	TGroupBox *GroupBox1;
	TButton *BtnPlus;
	TButton *BtnMinus;
	TButton *BtnMult;
	TButton *BtnDivide;
	TButton *BtnPower;
	TButton *BtnLT;
	TButton *BtnLE;
	TButton *BtnEQ;
	TButton *BtnAND;
	TButton *BtnApprox;
	TButton *BtnSeven;
	TButton *BtnEight;
	TButton *BtnNine;
	TButton *BtnFour;
	TButton *BtnFive;
	TButton *BtnSix;
	TButton *BtnOne;
	TButton *BtnTwo;
	TButton *BtnThree;
	TButton *BtnPeriod;
	TButton *BtnZero;
	TButton *BtnDelete;
	TButton *BtnGT;
	TButton *BtnGE;
	TButton *BtnApEQ;
	TButton *BtnOR;
	TButton *BtnParens;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnHelp;
   TButton *NotBtn;
        TMemo *Memo1;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
	void __fastcall BtnVarInClick(TObject *Sender);
	void __fastcall BtnPlusClick(TObject *Sender);
	void __fastcall BtnMinusClick(TObject *Sender);
	void __fastcall BtnMultClick(TObject *Sender);
	void __fastcall BtnDivideClick(TObject *Sender);
	void __fastcall BtnPowerClick(TObject *Sender);
	void __fastcall BtnLTClick(TObject *Sender);
	void __fastcall BtnLEClick(TObject *Sender);
	void __fastcall BtnEQClick(TObject *Sender);
	void __fastcall BtnANDClick(TObject *Sender);
	void __fastcall BtnApproxClick(TObject *Sender);
	void __fastcall BtnGTClick(TObject *Sender);
	void __fastcall BtnGEClick(TObject *Sender);
	void __fastcall BtnApEQClick(TObject *Sender);
	void __fastcall BtnORClick(TObject *Sender);
	void __fastcall BtnParensClick(TObject *Sender);
	void __fastcall BtnSevenClick(TObject *Sender);
	void __fastcall BtnEightClick(TObject *Sender);
	void __fastcall BtnNineClick(TObject *Sender);
	void __fastcall BtnFourClick(TObject *Sender);
	void __fastcall BtnFiveClick(TObject *Sender);
	void __fastcall BtnSixClick(TObject *Sender);
	void __fastcall BtnOneClick(TObject *Sender);
	void __fastcall BtnTwoClick(TObject *Sender);
	void __fastcall BtnThreeClick(TObject *Sender);
	void __fastcall BtnZeroClick(TObject *Sender);
	void __fastcall BtnPeriodClick(TObject *Sender);
	void __fastcall BtnDeleteClick(TObject *Sender);
//	void __fastcall BtnFunctionClick(TObject *Sender);
    void __fastcall BtnHelpClick(TObject *Sender);
   void __fastcall NotBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TSelIf(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TSelIf *SelIf;
//---------------------------------------------------------------------------
#endif
