//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "PlotUnit.h"
#include "SPCpChartUnit.h"
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSPCpChartForm *SPCpChartForm;
//---------------------------------------------------------------------------
__fastcall TSPCpChartForm::TSPCpChartForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSPCpChartForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     SigmaGroup->ItemIndex = 0;
     SigmaEdit->Text = "";
     MeasEdit->Text = "";
     PEdit->Text = "";
     NEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSPCpChartForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TSPCpChartForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     MeasEdit->Text = VarList->Items->Strings[index];
}
//---------------------------------------------------------------------------
void __fastcall TSPCpChartForm::ComputeBtnClick(TObject *Sender)
{
     double P, N, variance, stddev, UCL, LCL, X, Sigma, AVG;
     int i, MeasVar;
     AnsiString cellstring;
     char outline[101];
     double *Obsp;

     FrmOutPut->RichOutPut->Clear();
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == MeasEdit->Text) MeasVar = i;
     }
     if (SigmaGroup->ItemIndex == 3) Sigma = StrToFloat(SigmaEdit->Text);
     if (SigmaGroup->ItemIndex == 0)  Sigma = 3.0;
     if (SigmaGroup->ItemIndex == 1)  Sigma = 2.0;
     if (SigmaGroup->ItemIndex == 2)  Sigma = 1.0;

     AVG = 0.0;
//     Sigma = 3;
     N = StrToFloat(NEdit->Text);
     P = StrToFloat(PEdit->Text);
     variance = P * (1.0 - P) / N;
     stddev = sqrt(variance);
     GetDblVecMem(Obsp,NoCases + 1);

     for (i = 1; i <= NoCases; i++)
     {
          X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
          Obsp[i-1] = X;
          AVG = AVG + X;
     }
     AVG = AVG / NoCases;
     UCL = P + Sigma * stddev;
     LCL = P - Sigma * stddev;

     // output results
     FrmOutPut->RichOutPut->Lines->Add("Defects p Control Chart Results");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Sample No.  Proportion");
     FrmOutPut->RichOutPut->Lines->Add("__________  __________");
     for (i = 1; i <= NoCases; i++)
     {
          sprintf(outline,"   %5d        %6.3f",i,Obsp[i-1]);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Target proportion = %6.4f",P);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Sample size for each observation = %6.0f",N);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Average proportion observed = %6.4f",AVG);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Sigma = %6.4f",stddev);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();

     // Now create plot
     PlotMeans(Obsp,NoCases,UCL,LCL, AVG, P,this);
     ClearDblVecMem(Obsp);
}
//---------------------------------------------------------------------------

void __fastcall TSPCpChartForm::PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean, double Target,
                             TObject *Sender)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, oldxpos;
     double imagehi, maxval, minval, valincr, Yvalue;
     char Title[101];

     maxval = -10000.0;
     minval = 10000.0;
     for (i = 0; i < NoGrps; i++)
     {
          if (means[i] > maxval) maxval = means[i];
          if (means[i] < minval) minval = means[i];
     }
     if (UCL > maxval) maxval = UCL;
     if (LCL < minval) minval = LCL;

     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(hleft,vtop-10,hleft+hwide,vtop+vhi+10);

     // draw Grand Mean
     ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clBlue;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     sprintf(Title,"MEAN");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->Brush->Color = clLtGray;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw target
     ypos = ceil(vhi * ( (maxval - Target) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"TARGET");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->Brush->Color = clLtGray;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw horizontal axis
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom + 20);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom + 20);
     oldxpos = 0;
     for (i = 1; i <= NoGrps; i++)
     {
          ypos = vbottom + 10;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(Title,"%d",i+1);
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = xpos - offset;
          ypos = ypos + strhi;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          if (xpos > oldxpos)
          {
               PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
               oldxpos = xpos + (offset * 2);
          }
          xpos = 10;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,"GROUPS:");
     }

     // Draw vertical axis
     valincr = (maxval - minval) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          sprintf(Title,"%8.2f",maxval - ((i-1)*valincr));
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = maxval - (valincr * (i-1));
          ypos = ceil(vhi * ( (maxval - Yvalue) / (maxval - minval)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw lines for means of the groups
     ypos = ceil(vhi * ( (maxval - means[0]) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = ceil((hwide / NoGrps) + hleft);
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     for (i = 2; i < NoGrps; i++)
     {
          ypos = ceil(vhi * ( (maxval - means[i-1]) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // Draw upper and lower confidence intervals
     ypos = ceil(vhi * ( (maxval - UCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"UCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     ypos = ceil(vhi * ( (maxval - LCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"LCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     strcpy(Title,"p CONTROL CHART FOR : ");
     strcat(Title,MainForm->FileNameEdit->Text.c_str());
     ypos = PlotForm->Image1->Height - PlotForm->Image1->Canvas->TextHeight(Title);
     xpos = PlotForm->Image1->Width / 2 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     PlotForm->ShowModal();
}
//-------------------------------------------------------------------
