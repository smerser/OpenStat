//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <math.h>
#include <stdio.h>
#include "MatrixUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "CompRelUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmCompRel *FrmCompRel;
extern int NoVariables;
extern int NoCases;
extern struct VarDef *vdef[1000];

//---------------------------------------------------------------------------
__fastcall TFrmCompRel::TFrmCompRel(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::InBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = VarListBox->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (VarListBox->Selected[i])
         {
            cellstring = VarListBox->Items->Strings[i];
            SelectedListBox->Items->Add(cellstring);
            count++;
         }
     }
     cellstring = 1.0;
     for (int i = 0; i < count; i++)
     {
        WghtListBox->Items->Add(cellstring);
        RelListBox->Items->Add(cellstring);
     }

     while (count > 0)
     {
           for (int i = 0; i < VarListBox->Items->Count; i++)
           {
               if (VarListBox->Selected[i])
               {
                  VarListBox->Items->Delete(i);
                  count--;
               }
           }
     }
     OutBtn->Visible = true;
     if (VarListBox->Items->Count < 1) InBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::OutBtnClick(TObject *Sender)
{
    int index = SelectedListBox->ItemIndex;
    if (index < 0) return;
    AnsiString Label = SelectedListBox->Items->Strings[index];
    VarListBox->Items->Add(Label);
    SelectedListBox->Items->Delete(index);
    WghtListBox->Items->Delete(index);
    RelListBox->Items->Delete(index);
    if (SelectedListBox->Items->Count < 1) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::ResetBtnClick(TObject *Sender)
{
    VarListBox->Clear();
    SelectedListBox->Clear();
    RelListBox->Clear();
    WghtListBox->Clear();
    OutBtn->Visible = false;
    InBtn->Visible = true;
    for (int i = 0; i < NoVariables; i++)
    {
        AnsiString Label = MainForm->Grid->Cells[i+1][0];
        VarListBox->Items->Add(Label);
    }
    CorMatChk->Checked = false;
    Comp2GridChk->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::RelListBoxClick(TObject *Sender)
{
    AnsiString response = InputBox("Reliabilty","Estimated reliability?","1.0");
    int index = RelListBox->ItemIndex;
    RelListBox->Items->Strings[index] = response;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::WghtListBoxClick(TObject *Sender)
{
    AnsiString response = InputBox("Weight","Weight for this test?","1.0");
    int index = WghtListBox->ItemIndex;
    WghtListBox->Items->Strings[index] = response;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::ComputeBtnClick(TObject *Sender)
{
    double **Rmat, **RelMat, *Weights, *Reliabilities, CompRel, compscore;
    double *VectProd, *means, *stddevs, numerator, denominator;
    int *colnoselected;
    int count, IER, col;
    int NoVars = SelectedListBox->Items->Count;
    char outline[81];
    int outops;
    AnsiString cellstring;
    
    if (NoVars <= 0)
    {
        ShowMessage("ERROR! Two or more tests must be selected.");
        return;
    }

    try
    {
        Rmat = new double *[NoVars];
        for (int i = 0; i < NoVars; i++) Rmat[i] = new double[NoVars];
        RelMat = new double *[NoVars];
        for (int i = 0; i < NoVars; i++) RelMat[i] = new double[NoVars];
        Weights = new double[NoVars];
        Reliabilities = new double[NoVars];
        means = new double[NoVars];
        stddevs = new double[NoVars];
        colnoselected = new int[NoVars];
        VectProd = new double[NoVars];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory!","ERROR!",MB_OK);
        return;
    }

    FrmOutPut->RichOutPut->Clear();
    // get variable col. no.s selected
    for (int i = 0; i < NoVars; i++)
    {
        AnsiString Label = SelectedListBox->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
            if (Label == MainForm->Grid->Cells[j+1][0]) colnoselected[i] = j+1;
    }
    count = NoCases;

    // get correlation matrix
    if (CorMatChk->Checked) outops = 1;
    else outops = 0;
    IER = Correlations(means,stddevs,Rmat,NoVars,colnoselected,count,3,false,outops);
    if (IER == 1)
        Application->MessageBox("Zero variance found for a variable.","ERROR!",MB_OK);

    for (int i = 0; i < NoVars; i++)
        for (int j = 0; j < NoVars; j++)
            RelMat[i][j] = Rmat[i][j];
    for (int i = 0; i < NoVars; i++)
    {
        Reliabilities[i] = atof(RelListBox->Items->Strings[i].c_str());
        RelMat[i][i] = Reliabilities[i];
        Weights[i] = atof(WghtListBox->Items->Strings[i].c_str());
    }
    // get numerator and denominator of composite reliability
    for (int i = 0; i < NoVars; i++) VectProd[i] = 0.0;
    numerator = 0.0;
    denominator = 0.0;
    for (int i = 0; i < NoVars; i++)
        for (int j = 0; j < NoVars; j++)
            VectProd[i] += Weights[i] * RelMat[j][i];
    for (int i = 0; i < NoVars; i++) numerator += VectProd[i] * Weights[i];

    for (int i = 0; i < NoVars; i++) VectProd[i] = 0.0;
    for (int i = 0; i < NoVars; i++)
        for (int j = 0; j < NoVars; j++)
            VectProd[i] += Weights[i] * Rmat[j][i];
    for (int i = 0; i < NoVars; i++) denominator += VectProd[i] * Weights[i];
    CompRel = numerator / denominator;
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Composite reliability = %6.3f",CompRel);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    if (Comp2GridChk->Checked)
    {
         cellstring = "Composite";
         col = NoVariables + 1;
         MainForm->Grid->Cells[col][0] = cellstring;
         NewVar(col,true);
         col = NoVariables;
         for (int i = 1; i <= NoCases; i++)
         {
               compscore = 0.0;
               if (! ValidRecord(i,colnoselected,NoVars)) continue;
               for (int j = 1; j <= NoVars; j++)
               {
                    compscore = compscore + (Weights[j-1] *
                       StrToFloat(Trim(MainForm->Grid->Cells[colnoselected[j-1]][i])));
               }
               MainForm->Grid->Cells[col][i] = FloatToStr(compscore);
         }
    }

cleanup:
    delete[] VectProd;
    delete[] colnoselected;
    delete[] stddevs;
    delete[] means;
    delete[] Reliabilities;
    delete[] Weights;
    for (int i = 0; i < NoVars; i++) delete[] RelMat[i];
    delete[] RelMat;
    for (int i = 0; i < NoVars; i++) delete[] Rmat[i];
    delete[] Rmat;
}
//---------------------------------------------------------------------------
void __fastcall TFrmCompRel::AllBtnClick(TObject *Sender)
{
    AnsiString cellstring = 1.0;

    for (int i = 0; i < NoVariables; i++)
    {
        AnsiString Label = MainForm->Grid->Cells[i+1][0];
        SelectedListBox->Items->Add(Label);
        WghtListBox->Items->Add(cellstring);
        RelListBox->Items->Add(cellstring);
    }
    for (int i = NoVariables-1; i >= 0; i--) VarListBox->Items->Delete(i);
    OutBtn->Visible = true;
    InBtn->Visible = false;
}
//---------------------------------------------------------------------------
