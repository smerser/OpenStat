//---------------------------------------------------------------------------
#ifndef ItemFoilH
#define ItemFoilH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TItemFoilFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *OKBtn;
    TButton *CancelBtn;
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *FoilNoEdit;
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TItemFoilFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TItemFoilFrm *ItemFoilFrm;
//---------------------------------------------------------------------------
#endif
