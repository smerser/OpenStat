//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "dcdflib.h"
#include "stdio.h"
#include <math.h>
#include "Printers.hpp"
#include "MainUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "functions.h"
#include "PlotUnit.h"
#include "QQPPUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
TQQPPForm *QQPPForm;
//---------------------------------------------------------------------------
__fastcall TQQPPForm::TQQPPForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TQQPPForm::FormShow(TObject *Sender)
{
     int Yincr, Xincr;
     AnsiString astring;
     char valstr[5];

//     ParmBox->Visible = false;
//     PlotLabel->Visible = false;
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     ObsVarEdit->Text = "";
     ParmEdit1->Text = "";
     ParmEdit2->Text = "";
     ParmEdit3->Text = "";
     ParmEdit4->Text = "";
     ParmEdit5->Text = "";
     ParmEdit6->Text = "";
     ParmEdit7->Text = "";
     DistType->ItemIndex = -1;
     PlotType->ItemIndex = -1;
     PrintChk->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TQQPPForm::VarListClick(TObject *Sender)
{
     AnsiString CellVal, VarName, outline;
     char lineout[101];
     int j, k, Ncases;
     int index = VarList->ItemIndex;
     double theor, temp;
     double zx;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     plottype = PlotType->ItemIndex + 1;
     disttype = DistType->ItemIndex + 1;
     ObsVarEdit->Text = VarList->Items->Strings[index];
     CellVal = ObsVarEdit->Text;
     VarName = CellVal;
     Ncases = 0;
     col = 0;
     for (j = 1; j <= NoVariables; j++)
     {
           if (MainForm->Grid->Cells[j][0] == CellVal)
           {
              col = j;
              outline = "Frequency Analysis for " + CellVal;
              FrmOutPut->RichOutPut->Lines->Add(outline);
              break;
           }
     }
     if (col == 0)
     {
        ShowMessage("ERROR!  Select a variable to analyze.");
        return;
     }
     //result = VarTypeChk(col,0);
     //if (result == 1) return;

     // Get min, max, mean, stddev values for this variable
     min = 1.0e32;
     max = -1.0e32;
     mean = 0.0;
     stddev = 0.0;

     GetDblVecMem(observed,NoCases);
     GetDblVecMem(freq,NoCases);
     GetDblVecMem(XValue,NoCases);

     for (j = 1; j <= NoCases; j++)
     {
            if (! ValidValue(j,col)) continue;
            value = StrToFloat(MainForm->Grid->Cells[col][j]);
            //result = GetValue(j, col,intvalue, dblvalue, strvalue);
            //if (result != 0) value = 0.0;
            //else value = dblvalue;
            observed[j-1] = value;
            mean += value;
            stddev += value * value;
            if (value > max) max = value;
            if (value < min) min = value;
            Ncases++;
     }
     stddev = stddev - ((mean * mean) / Ncases);
     stddev = sqrt(stddev / (Ncases-1));
     mean /= Ncases;
     range = max - min + 1;

     // sort observed scores
     for (int i = 0; i < Ncases-1; i++)
     {
         for (int j = i+1; j < Ncases; j++)
         {
             if (observed[i] > observed[j]) // swap
             {
                  temp = observed[i];
                  observed[i] = observed[j];
                  observed[j] = temp;
             }
         }
     }

     // obtain unique values and their frequencies
     nints = 0;
     temp = observed[0];
     freq[0] = 0;
     XValue[0] = temp;
     for (int i = 0; i < Ncases; i++)
     {
         if (observed[i] == temp) freq[nints]++;
         else
         {
             nints++;
             temp = observed[i];
             XValue[nints] = temp;
             freq[nints] = 1;
         }
     }

     // Get additional memory for analysis
     GetDblVecMem(pcnt,nints+2);
     GetDblVecMem(cumpcnt,nints+2);
     GetDblVecMem(pcntrank,nints+2);
     GetDblVecMem(cumfreq,nints+2);
     GetDblVecMem(sampprob,nints+2);
     GetDblVecMem(theoretic,nints+2);

     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(lineout,"MEAN = %8.3f, STANDARD DEVIATION = %8.3f",mean,stddev);
     FrmOutPut->RichOutPut->Lines->Add(lineout);
     FrmOutPut->RichOutPut->Lines->Add("");
     if (disttype == 1) // binomial
     {
           ParmEdit1->Text = "1";
           ParmEdit2->Text = ceil(max);
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "0.5";
     }
     if (disttype == 2) // normal
     {
           ParmEdit2->Text = mean;
           ParmEdit3->Text = stddev;
     }
     if (disttype == 3) // chi-square
     {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = Ncases-1;
           ParmEdit3->Text = "";
           ParmEdit4->Text = "";
     }
     if (disttype == 4) // t distribution
     {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = Ncases-1;
           ParmEdit3->Text = "";
           ParmEdit4->Text = "";
     }
     if (disttype == 5) // F distribution
     {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = "1";
           ParmEdit3->Text = NoCases;
           ParmEdit4->Text = "";
           ParmEdit5->Text = "";
     }
     if (disttype == 6) //Poison distribution
     {
           ParmEdit1->Text = "1.0";
           ParmEdit2->Text = mean;
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "";
     }
     if (disttype == 7) // beta distribution
     {
           ParmEdit1->Text = "6";
           ParmEdit2->Text = "10";
           ParmEdit3->Text = "0.5";
           ParmEdit4->Text = "0.5";
           ParmEdit5->Text = "";
     }

        // Get frequency of cases in each interval
        for (j = 0; j < nints + 1; j++)
        {
            pcnt[j] = 0.0;
            cumpcnt[j] = 0.0;
            pcntrank[j] = 0.0;
            cumfreq[j] = 0.0;
            theoretic[j] = 0.0;
        }

        for (k = 0; k <= nints; k++) sampprob[k] = freq[k] / Ncases;

        // get cumulative frequencies and percents to midpoints
        cumfreq[0] = freq[0];
        pcnt[0] = freq[0] / Ncases;
        cumpcnt[0] = pcnt[0];
        pcntrank[0] = (freq[0] / 2.0) / Ncases;
        for (k = 2; k <= nints+1; k++)
        {
           cumfreq[k-1] = cumfreq[k-2] + freq[k-1];
           pcnt[k-1] = freq[k-1] / Ncases;
           cumpcnt[k-1] = cumfreq[k-1] / Ncases;
           pcntrank[k-1] = (cumfreq[k-2] + freq[k-1] / 2.0) / Ncases;
        }
        for (k = 0; k <= nints+1; k++)
        {
           if (pcntrank[k] > 0.0) zx = inversez(pcntrank[k]);
           if (pcntrank[k] == 0.0) zx = -3.0;
           if (pcntrank[k] == 1.0) zx = 3.0;
           zx = zx * stddev + mean;
           theoretic[k] = zx;
        }
}
//---------------------------------------------------------------------------

void __fastcall TQQPPForm::DistTypeClick(TObject *Sender)
{
     selected = DistType->ItemIndex + 1;
     switch (selected)
     {
           case 1 : // binomial cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "N Trials:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = ceil(max);
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Even Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "P";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "Q";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "0.5";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 2 : // normal cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "z value:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = mean;
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = mean;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Std. Dev.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = stddev;
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 3 : // chi-square cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "Chi-squared:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "1";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = false;
                ParmEdit5->Visible = false;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 4 : // student t cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "t Value:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Deg.Freedom:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = NoCases-1;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Prob.";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "1-Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = false;
                ParmEdit5->Visible = false;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 5 : // F cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "F Statistic";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Num.Deg.F.:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "5.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "Den.Deg.F.:";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = NoCases;
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Prob.";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Visible = false;
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 6 : // Poisson cdf
           {
                ParmBox->Visible = true;
                ParmLabel1->Caption = "N Observed:";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "1.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "Mean:";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = mean;
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "";
                ParmLabel3->Visible = false;
                ParmEdit3->Text = "";
                ParmEdit3->Visible = false;
                ParmLabel4->Caption = "Prob.:";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "1-Prob.";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "";
                ParmLabel6->Visible = false;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = false;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
           case 7 : // beta cdf
           {
                ParmBox->Visible = true;
                Which = 1;
                ParmLabel1->Caption = "A = ";
                ParmLabel1->Visible = true;
                ParmEdit1->Text = "6.0";
                ParmEdit1->Visible = true;
                ParmLabel2->Caption = "B = ";
                ParmLabel2->Visible = true;
                ParmEdit2->Text = "10.0";
                ParmEdit2->Visible = true;
                ParmLabel3->Caption = "X = ";
                ParmLabel3->Visible = true;
                ParmEdit3->Text = "0.5";
                ParmEdit3->Visible = true;
                ParmLabel4->Caption = "Y = ";
                ParmLabel4->Visible = true;
                ParmEdit4->Text = "0.5";
                ParmEdit4->Visible = true;
                ParmLabel5->Caption = "P = ";
                ParmLabel5->Visible = true;
                ParmEdit5->Text = "";
                ParmEdit5->Visible = true;
                ParmLabel6->Caption = "Q = ";
                ParmLabel6->Visible = true;
                ParmEdit6->Text = "";
                ParmEdit6->Visible = true;
                ParmLabel7->Caption = "Status:";
                ParmLabel7->Visible = true;
                ParmEdit7->Text = "";
                ParmEdit7->Visible = true;
                break;
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TQQPPForm::ComputeBtnClick(TObject *Sender)
{
     AnsiString Caption, Xlabel, Ylabel;
     char title[100];
     double s, xn, pr, ompr;
     char lineout[101];

     plottype = PlotType->ItemIndex + 1;
     if (plottype == 1) // QQ Plot
     {
        Which = 2;
        switch (disttype)
        {
           case 1 : // binomial cdf
           {
                s = StrToFloat(ParmEdit1->Text);
                xn = StrToFloat(ParmEdit2->Text);
                pr = 0.5;
                ompr = 1.0 - pr;

                // plot distribution for X = min to max
                Caption = "Normal";
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot upper part and lower part
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    Xplot[i] = XValue[i];
                    theoretic[i] = s;
                }
                   PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
           case 2 : // normal cdf
           {
                double Mean = StrToFloat(ParmEdit2->Text);
                double StdDev = StrToFloat(ParmEdit3->Text);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"Normal CDF (%5.2f,%5.2f,%5.2f)",X,Mean,StdDev);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
                    Xplot[i] = XValue[i];
                    theoretic[i] = X;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
           case 3 : // chi-square cdf
           {
                X = StrToFloat(ParmEdit1->Text); // sample chi-square
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for observed vs theoretical
                sprintf(title,"Chi-square CDF (%5.2f,%5.0f)",X,Y);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot chi-square from 0 to 100
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = XValue[i];
                    Yplot[i] = X;
                    X += 1.0;
                }
                PlotXY(nints+1,Xplot,Yplot,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 4 : // student t cdf
           {
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = -4 to 4
                Caption = "t Distribution";
                Xlabel = "Observed";
                Ylabel = "Expected";
                for (int i = 0; i <= nints; i++) // plot
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    X = inverset(P,Y);
                    if (P < 0.5) X = -X;
                    X = X * stddev + mean;
                    Xplot[i] = XValue[i];
                    theoretic[i] = X;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 5 : // F cdf
           {
                double df1 = StrToFloat(ParmEdit2->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit3->Text); // deg. freedom denominator
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"F CDF (%5.2f,%5.0f,%5.0f)",X,df1,df2);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot F
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
                    Xplot[i] = XValue[i];
                    theoretic[i] = X;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 6 : // Poisson cdf
           {
                double Mean = StrToFloat(ParmEdit2->Text);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"Poisson CDF (%5.2f,%5.2f)",X,Mean);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot from 0 to 100
                {
                    P = pcntrank[i];
                    Q = 1.0 - P;
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    Xplot[i] = XValue[i];
                    theoretic[i] = X;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
         } // end switch
     } // end if plottype = 1

     if (plottype == 2) // PP Plot
     {
        Which = 1;
        switch (disttype)
        {
           case 1 : // binomial cdf
           {
                s = StrToFloat(ParmEdit1->Text);
                xn = StrToFloat(ParmEdit2->Text);
                pr = 0.5;
                ompr = 1.0 - pr;

                // plot distribution for X = min to max
                Caption = "Normal";
                Xlabel = "Observed";
                Ylabel = "Expected";
                for (int i = 0; i <= nints; i++) // plot upper part and lower part
                {
                    s = XValue[i];
                    cdfbin(&Which,&P,&Q,&s,&xn,&pr,&ompr,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                   PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
           case 2 : // normal cdf
           {
                double Mean = StrToFloat(ParmEdit2->Text);
                double StdDev = StrToFloat(ParmEdit3->Text);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"Normal CDF (%5.2f,%5.2f,%5.2f)",X,Mean,StdDev);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot
                {
                    X = XValue[i];
                    cdfnor(&Which,&P,&Q,&X,&Mean,&StdDev,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
           case 3 : // chi-square cdf
           {
                X = StrToFloat(ParmEdit1->Text); // sample chi-square
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for observed vs theoretical
//                sprintf(title,"Chi-square CDF (%5.2f,%5.0f)",X,Y);
//                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot
                {
                    X = XValue[i];
                    cdfchi(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 4 : // student t cdf
           {
                Y = StrToFloat(ParmEdit2->Text); // deg. freedom
                ParmEdit3->Text = FloatToStr(P);
                ParmEdit4->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution for X = -4 to 4
                Caption = "t Distribution";
                Xlabel = "Observed";
                Ylabel = "Expected";
                for (int i = 0; i <= nints; i++) // plot
                {
                    X = XValue[i];
                    X = (X - mean) / stddev;
                    cdft(&Which,&P,&Q,&X,&Y,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 5 : // F cdf
           {
                double df1 = StrToFloat(ParmEdit2->Text); // deg. freedom numerator
                double df2 = StrToFloat(ParmEdit3->Text); // deg. freedom denominator
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"F CDF (%5.2f,%5.0f,%5.0f)",X,df1,df2);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot F
                {
                    X = (XValue[i]-mean) / stddev;
                    cdff(&Which,&P,&Q,&X,&df1,&df2,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }

           case 6 : // Poisson cdf
           {
                double Mean = StrToFloat(ParmEdit2->Text);
                ParmEdit4->Text = FloatToStr(P);
                ParmEdit5->Text = FloatToStr(Q);
                ParmEdit7->Text = IntToStr(Status);

                // plot distribution
                sprintf(title,"Poisson CDF (%5.2f,%5.2f)",X,Mean);
                Caption = title;
                Xlabel = "Observed";
                Ylabel = "Expected";
//                PlotLabel->Visible = true;
                for (int i = 0; i <= nints; i++) // plot from 0 to 100
                {
                    X = XValue[i];
                    cdfpoi(&Which,&P,&Q,&X,&Mean,&Status,&Bound);
                    Xplot[i] = pcntrank[i];
                    theoretic[i] = P;
                }
                PlotXY(nints+1,Xplot,theoretic,Xlabel,Ylabel,Caption,false);
                break;
           }
         } // end switch
     } // end if plottype = 2
     PlotForm->ShowModal();

        // Print results if elected
        if (PrintChk->Checked == true)
        {
            FrmOutPut->RichOutPut->Clear();
            FrmOutPut->RichOutPut->Lines->Add("FREQUENCY ANALYSIS BY BILL MILLER");
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("    VALUE     FREQ.   PCNT    CUM.FREQ.  CUM.PCNT. %ILE RANK  THEORETIC X");
            FrmOutPut->RichOutPut->Lines->Add("");
            for (int k = 0; k <= nints; k++)
            {
               sprintf(lineout,"%8.2f  %8.0f %8.2f  %8.2f  %8.2f  %8.2f  %8.2f",
                 XValue[k],
                 freq[k],            // freq
                 pcnt[k],            // percent
                 cumfreq[k],         // cumulative freqency
                 cumpcnt[k],         // cumulative percent to midpoint
                 pcntrank[k],       // percentile rank
                 theoretic[k]);       // theoretic X
               FrmOutPut->RichOutPut->Lines->Add(lineout);
            }
            FrmOutPut->ShowModal();
        }

        ClearDblVecMem(theoretic);
        ClearDblVecMem(sampprob);
        ClearDblVecMem(cumfreq);
        ClearDblVecMem(pcntrank);
        ClearDblVecMem(cumpcnt);
        ClearDblVecMem(pcnt);
        ClearDblVecMem(XValue);
        ClearDblVecMem(freq);
        ClearDblVecMem(observed);
        FormShow(this);
}
//---------------------------------------------------------------------------

void TQQPPForm::PlotXY(int npts, double *Xplot, double *Yplot, AnsiString Xlabel,
                           AnsiString Ylabel, AnsiString Caption, bool continuous)
{
     int Yincr, Xincr, xprop, yprop, TextHi;
     int LabelWide;
     double Yrange, Ymin, Ymax, Xrange, Xmin, Xmax, Xstep, Ystep;
     char valstr[95];
     AnsiString astring;

     ImageHi = PlotForm->Image1->Height;
     ImageWide = PlotForm->Image1->Width;
     Xstart = ImageWide / 10;
     Xend = (ImageWide * 9) / 10;
     Ystart = ImageHi / 10;
     Yend = (ImageHi * 9) / 10;

     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,ImageWide,ImageHi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     PlotForm->Image1->Canvas->TextOut(Xstart-10,Ystart-30,Ylabel);
//     PlotLabel->Text = Caption;
     LabelWide = PlotForm->Image1->Canvas->TextWidth(Xlabel);
     PlotForm->Image1->Canvas->TextOut((Xend-Xstart)/2- LabelWide / 2,Yend + 25,Xlabel);

     // draw axis lines
     PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
     PlotForm->Image1->Canvas->LineTo(Xend,Yend);
     PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
     PlotForm->Image1->Canvas->LineTo(Xstart,Ystart);

     // get min, max and range of Y
     Ymin = 1.0e300;
     Ymax = -1.0e300;
     for (int i = 0; i < npts; i++)
     {
         if (Yplot[i] > Ymax) Ymax = Yplot[i];
         if (Yplot[i] < Ymin) Ymin = Yplot[i];
     }

     // get min, max and range of X
     Xmin = 1.0e300;
     Xmax = -1.0e300;
     for (int i = 0; i < npts; i++)
     {
         if (Xplot[i] > Xmax) Xmax = Xplot[i];
         if (Xplot[i] < Xmin) Xmin = Xplot[i];
     }

     if (Xmax > Ymax) Ymax = Xmax;
     else Xmax = Ymax;
     if (Xmin < Ymin) Ymin = Xmin;
     else Xmin = Ymin;
     Yrange = Ymax - Ymin;
     Ystep = Yrange / 10;
     Xrange = Xmax - Xmin;
     Xstep = Xrange / 10;

     // create y axis values
     Yincr = (Yend - Ystart) / 10;
     for (int i = 0; i < 11; i++) // print Y axis values
     {
         int place = Yend - (i * Yincr);
         float value = Ymin + (Ystep * i);
         sprintf(valstr,"%4.2f",value);
         astring = valstr;
         TextHi = PlotForm->Image1->Canvas->TextHeight(astring);
         PlotForm->Image1->Canvas->TextOutA(Xstart-30,place-TextHi,astring);
     }

     // create x axis values
     Xincr = (Xend - Xstart) / 10;
     for (int i = 0; i < 11; i++) // print x axis
     {
         int place = Xstart + (i * Xincr);
         float value = Xmin + (i * Xstep);
         sprintf(valstr,"%4.2f",value);
         astring = valstr;
         PlotForm->Image1->Canvas->TextOutA(place,Yend + 10,astring);
     }

     // plot the x, y values
     xprop = Xstart + ceil(((Xplot[0]-Xmin) / Xrange) * (Xend - Xstart));
     yprop = Yend - ceil(((Yplot[0]-Ymin) / Yrange) * (Yend - Ystart));
     if (continuous) PlotForm->Image1->Canvas->MoveTo(xprop,yprop);
     else PlotForm->Image1->Canvas->MoveTo(xprop,Yend);
     for (int i = 0; i < npts; i++)
     {
         xprop = Xstart + ceil(((Xplot[i]-Xmin) / Xrange) * (Xend - Xstart));
         yprop = Yend - ceil(((Yplot[i]-Ymin) / Yrange) * (Yend - Ystart));
         if (continuous) PlotForm->Image1->Canvas->LineTo(xprop,yprop);
         else
         {
             PlotForm->Image1->Canvas->MoveTo(xprop,Yend);
//             PlotForm->Image1->Canvas->LineTo(xprop,yprop);
//             PlotForm->Image1->Canvas->Rectangle(xprop-2,yprop-2,xprop+2,yprop+2);
             PlotForm->Image1->Canvas->Ellipse(xprop-2,yprop-2,xprop+2,yprop+2);
         }
     }
     // draw expected line
     xprop = Xstart + ceil(((Xmin-Xmin) / Xrange) * (Xend - Xstart));
     yprop = Yend - ceil(((Ymin-Ymin) / Yrange) * (Yend - Ystart));
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->MoveTo(xprop,yprop);
     xprop = Xstart + ceil(((Xmax-Xmin) / Xrange) * (Xend - Xstart));
     yprop = Yend - ceil(((Ymax-Ymin) / Yrange) * (Yend - Ystart));
     PlotForm->Image1->Canvas->LineTo(xprop,yprop);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
//     PlotForm->ShowModal();
}
//---------------------------------------------------------------------------

int TQQPPForm::combinations(int X, int N)
{
    int combos;
    double logfact1, logfact2, logfact3;

    logfact1 = 0.0;
    logfact2 = 0.0;
    logfact3 = 0.0;
    if (N > 0)
    {
       for (int i = 1; i <= N; i++) logfact1 += log(i);
    }
    else logfact1 = log(1);
    if (X > 0)
    {
       for (int i = 1; i <= X; i++) logfact2 += log(i);
    }
    else logfact2 = log(1);
    if (N-X > 0)
    {
       for (int i = 1; i <= (N-X); i++) logfact3 += log(i);
    }
    else logfact3 = log(1);
    combos = ceil(exp(logfact1 - logfact2 - logfact3));
    return (combos);
}
//---------------------------------------------------------------------------

void __fastcall TQQPPForm::ResetBtnClick(TObject *Sender)
{
        FormShow(this);        
}
//---------------------------------------------------------------------------

