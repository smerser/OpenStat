//---------------------------------------------------------------------------

#ifndef SSRegUnitH
#define SSRegUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSSbyRegForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TLabel *VariablesLabel;
    TListBox *TreatmentList;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TRadioGroup *CodeTypeGrp;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TButton *StartInterBtn;
    TListBox *InteractList;
    TButton *EndItnterActBtn;
    TLabel *Label5;
    TListBox *AllInteractList;
    TGroupBox *OutPutGrp;
    TCheckBox *DescriptChk;
    TCheckBox *MRegChk;
    TEdit *DepVarEdit;
    TLabel *Label6;
    TLabel *Label7;
    TListBox *RepeatList;
    TLabel *Label8;
    TListBox *CovariateList;
    TBitBtn *TrtInBtn;
    TBitBtn *RepInBtn;
    TBitBtn *CovInBtn;
    TBitBtn *TrtOutBtn;
    TBitBtn *RepOutBtn;
    TBitBtn *CovOutBtn;
    TMemo *Memo1;
    TCheckBox *GenVecsChk;
    TLabel *Label2;
    TListBox *WithinList;
    TBitBtn *WithInBtn;
    TBitBtn *WithOutBtn;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall TrtInBtnClick(TObject *Sender);
    void __fastcall TrtOutBtnClick(TObject *Sender);
    void __fastcall RepInBtnClick(TObject *Sender);
    void __fastcall RepOutBtnClick(TObject *Sender);
    void __fastcall CovInBtnClick(TObject *Sender);
    void __fastcall CovOutBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall StartInterBtnClick(TObject *Sender);
    void __fastcall DepVarEditDblClick(TObject *Sender);
    void __fastcall TreatmentListDblClick(TObject *Sender);
    void __fastcall RepeatListDblClick(TObject *Sender);
    void __fastcall CovariateListDblClick(TObject *Sender);
    void __fastcall EndItnterActBtnClick(TObject *Sender);
    void __fastcall WithInBtnClick(TObject *Sender);
    void __fastcall WithOutBtnClick(TObject *Sender);
    void __fastcall WithinListClick(TObject *Sender);

private:	// User declarations
    int NoRepVars; // number of repeated measurement variables
    int NoTrtVars; // number of treatment variables
    int NoCovVars; // number of covariate variables
    int NoIntVars; // number of interaction variables
    int NoMainInts; // number of interactions involving non-repeat measures
    int NoWithVars; // number of within replication variables
    int DepCol;    // column number of dependent variable
    AnsiString DepVar;          // label of dependent variable
    AnsiString Treatments[4];   // (original) Treatment variable labels
    int TrtVarCols[4];          // (original) Treatment variable columns
    AnsiString RepeatedMeas[5]; // (original) Repeated Measure labels
    int RepVarCols[3];          // (original) Repeated Measure columns
    AnsiString Covariates[5];   // covariate labels
    int CovVarCols[5];          // covariate columns
    AnsiString Withins[3];      // within variable labels
    int WithinCols[3];          // within variable columns
    AnsiString Interaction[60]; // Interaction variable labels
    int NoRepVectors[3];        // no. of vectors created for each repeated measure
    int NoTrtVectors[4];        // no. of vectors created for each treatment variable
    int NoWithVectors[3];       // no. of vectors created for each within variable
    int NoIntVectors[60];       // no. vectors created for each interaction
    int MinTrtValue[4];         // minimum codes of original treatment variables
    int MaxTrtValue[4];         // maximum codes of original treatment variables
    int MinRepValue[5];         // minimum codes of original repeated measurements
    int MaxRepValue[5];         // maximum codes of original repeated measurements
    int MinWithValue[3];        // minimum codes of original within variables
    int MaxWithValue[3];        // maximum codes of original within variables
    int TrtVecColStart[4];      // grid position of beginning vector for each treatment
    int RepVecColStart[5];      // grid position of beginning vector for each repeated meas.
    int IntVecColStart[60];     // grid position of beginning vector for each interaction
    int WithVecColStart[3];     // grid position of beginning vector for each within variable
    bool intdef;                // true if defining an interaction else false;
    double SSTrt[4], SSRep[5], SSCov[5], SSInt[60], SSWith[3];
    int DFTrt[4], DFRep[5], DFInt[60], DFWith[3];
    double MSTrt[4], MSCov[5], MSRep[6], MSInt[60], MSWith[3];
    int DFE, DFCovs, DFReps, DFTrts, DFInts, DFWiths;
    double SST, SSE, SSCovs, SSReps, SSTrts, SSInts, SSWiths, SSReg;
    double MST, MSE, MSCovs, MSReps, MSTrts, MSInts, MSWiths, MSBetween;
    double SS[80];
    bool IsWithin[80]; // false if between, true if vector is within source
    int ncnt;  // vector counter of treatment and within vectors
    bool WithinInteract[60]; // false if an interaction is a between source else true
    int tempcols[80];
    AnsiString *templabels;
    
    void __fastcall GenTrtVectors(TObject *Sender);
    void __fastcall GenWithinVectors(TObject *Sender);
    void __fastcall GenRepVectors(TObject *Sender);
    void __fastcall GenInteractVectors(TObject *Sender);
    void __fastcall strparse(int i, AnsiString astring[], int &cnt, TObject *Sender);
    void __fastcall DoRegressions(TObject *Sender);

public:		// User declarations
    __fastcall TSSbyRegForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSSbyRegForm *SSbyRegForm;
//---------------------------------------------------------------------------
#endif
