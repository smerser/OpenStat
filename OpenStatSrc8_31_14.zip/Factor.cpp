//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include <math.h>
#include "Factor.h"
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "FrmGraphOut.h"
#include "DataFuncs.h"
//#include "PlotUnit.h"
#include "MemMgrUnit.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFactorFrm *FactorFrm;
extern long int NoVariables;
extern long int NoCases;
extern FILE *OutPutFile;
extern int FileType;
extern struct Options ops;
//extern char PrintFile[10];
double **Loadings;
int cols;
int rows;

//---------------------------------------------------------------------------
__fastcall TFactorFrm::TFactorFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFactorFrm::FormShow(TObject *Sender)
{
     AnsiString cellstring;

     ListBox1->Clear();
     ListBox2->Clear();
     OutBtn->Enabled = false;
     DescChkBox->Checked = false;
     CorrChkBox->Checked = false;
     UnVectChkBox->Checked = false;
     PcntTrChkBox->Checked = false;
     ScreeChkBox->Checked = false;
     CommunChkBox->Checked = false;
     PrCompBtn->Checked = false;
     FactScrsChkBox->Checked = false;
     SaveRChkBox->Checked = false;
     SaveFChkBox->Checked = false;
     SortChkBox->Checked = false;
	  Label6->Visible = false;
     NoObsEdit->Visible = false;
     InputType = 0;
     MaxIterEdit->Text = 25;
     if (ops.format == 0) MinRootEdit->Text = "1.0";
     else MinRootEdit->Text = "1,0";
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
}
//---------------------------------------------------------------------------
void __fastcall TFactorFrm::ResetBtnClick(TObject *Sender)
{
     FormShow(this);
}
//---------------------------------------------------------------------------
void __fastcall TFactorFrm::OkBtnClick(TObject *Sender)
{
    double **TempMat, *Eigenvector, *pcnttrace, *b, *communality,
           *xvector, *yvector, *d2, *means, *stddevs, **corrmat, **V, *W;
    double *DCORR, *EVAL, **EVEC, **COMP, *PERVAR, *ICL, *CU, **ainverse, **A;
    double MaxRoot = 0.0;
    int i, j, k, L, Nroots, noiterations=0, NoSelected, factorchoice, maxiters;
    int IER, N, prtopts = 0, maxnoroots = 0, count;
    int *ColNoSelected;
    double criterion, Difference, minroot, maxk, trace;
    AnsiString cellstring;
    char outline[81];
    AnsiString *RowLabels, *ColLabels;
    bool MatInput = false;
    int result;

    criterion = 0.0001; //Convergence of communality estimates
    factorchoice = 1;  // assume principal component
    if (PartImageBtn->Checked) factorchoice = 2;
    if (GuttmanBtn->Checked) factorchoice = 3;
    if (HarrisBtn->Checked) factorchoice = 4;
    if (CanonicalBtn->Checked) factorchoice = 5;
    if (AlphaBtn->Checked) factorchoice = 6;
    if (PAFBtn->Checked) factorchoice = 7;
    if (DescChkBox->Checked) prtopts = 3;
    if (CorrChkBox->Checked) prtopts = 2;
    if ((CorrChkBox->Checked) && (DescChkBox->Checked)) prtopts = 1;
    maxiters = atoi(MaxIterEdit->Text.c_str());
    if (MaxFactorsEdit->Text != "")
       maxnoroots = atoi(MaxFactorsEdit->Text.c_str());
    // Setup the output
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Factor Analysis");
    FrmOutPut->RichOutPut->Lines->Add("See Rummel, R.J., Applied Factor Analysis");
    FrmOutPut->RichOutPut->Lines->Add("Northwestern University Press, 1970");
    FrmOutPut->RichOutPut->Lines->Add("");

    if (InputType == 0) // data grid
    {
       N = NoCases;
       NoSelected = ListBox2->Items->Count;
       if (NoSelected < 2)
       {
          ShowMessage("ERROR! Select 2 or more variables.");
          return;
       }
    }
    if (InputType == 1) // Main form grid matrix input
    {
        MatInput = true;
        NoSelected = NoVariables;
        N = 0;
        N = StrToFloat(NoObsEdit->Text);
        if (N <= 0) {
           ShowMessage("First, enter the number of observations on which the matrix was derived.");
           return;
        }
    }
    if (InputType == 2) // binary matrix input (.MAT)
    {
    	  if (NoVariables > 1)
     	  {
               ShowMessage("Close (or Save and Close) the current work.");
               return;
    	  }
          MatInput = true;
          LoadMatrix();
          N = NoCases;
          NoSelected = NoVariables;
          for (int i = 1; i <= NoSelected; i++)
          {
               ListBox2->Items->Add(MainForm->Grid->Cells[i][0]);
          }
    }
    // Allocate space on heap
    try  {
        DCORR = new double [(NoSelected+1)*(NoSelected+2)/2];
        EVAL = new double [NoSelected+1];
        EVEC = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) EVEC[i] = new double[NoSelected+1];
        COMP = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) COMP[i] = new double[NoSelected+1];
        PERVAR = new double [NoSelected+1];
        ICL = new double [NoSelected+1];
        CU = new double [NoSelected+1];
        ColNoSelected = new int[NoSelected];
        corrmat = new double *[NoSelected];
        for (i = 0; i < NoSelected; i++) corrmat[i] = new double[NoSelected];
        TempMat = new double *[NoSelected+1];
        for (i = 0; i < NoSelected+1; i++) TempMat[i] = new double[NoSelected+1];
        ainverse = new double *[NoSelected+1];
        for (i = 0; i < NoSelected+1; i++) ainverse[i] = new double[NoSelected+1];
        V = new double *[NoSelected+1];
        for (i = 0; i < NoSelected+1; i++) V[i] = new double[NoSelected+1];
        W = new double [NoSelected+1];
        Loadings = new double *[NoSelected];
        for (i = 0; i < NoSelected; i++) Loadings[i] = new double[NoSelected];
        Eigenvector = new double[NoSelected];
        communality = new double[NoSelected];
        pcnttrace = new double[NoSelected];
        b = new double[NoSelected];
        d2 = new double[NoSelected];
        xvector = new double[NoSelected];
        yvector = new double[NoSelected];
        means = new double[NoSelected];
        stddevs = new double[NoSelected];
        RowLabels = new AnsiString[NoSelected];
        ColLabels = new AnsiString[NoSelected];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Factor Analysis","ERROR!",MB_OK);
	  return;
    }

    if (InputType != 0) // a matrix was input to the grid
    {
        for (int i = 0; i < NoSelected; i++) ColNoSelected[i] = i+1;
        for (int i = 0; i < NoSelected; i++)
        {
            ColLabels[i] = MainForm->Grid->Cells[i+1][0];
            RowLabels[i] = ColLabels[i];
            means[i] = 0.0;
            stddevs[i] = 1.0;
            for (j = 0; j < NoSelected; j++)
                corrmat[i][j] = StrToFloat(MainForm->Grid->Cells[i+1][j+1]);
        }
        if ((prtopts == 1) || (prtopts == 2))
        {
            ArrayPrint(corrmat,NoSelected,NoSelected,"Variables",RowLabels,
                ColLabels,"MATRIX ENTERED");
            FrmOutPut->ShowModal();
        }
    }

    else
    {
        MatInput = false;
        for (i = 0; i < NoSelected; i++)
        {
            cellstring = ListBox2->Items->Strings[i];
            for (j = 0; j < NoVariables; j++)
            {
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                {
                   ColNoSelected[i] = j+1;
                   ColLabels[i] = cellstring;
                   RowLabels[i] = cellstring;
                   //result = VarTypeChk(j+1,0);
                   //if (result == 1) return;
                }
            }
        }
    }

    count = NoCases;
    //Obtain correlation matrix and, if required simultaneous Multiple Correlations
    if (MatInput == false)
    {
       IER = Correlations(means, stddevs, corrmat, NoSelected, ColNoSelected, count,
                 3, false, prtopts);
       if (IER == 1)
           Application->MessageBox("Zero variance found for a variable.","ERROR!",MB_OK);

    }
    k = NoSelected;

    //check the Kaiser-Meyer-Olkin MSA for matrix sufficiency
    KMO(k,corrmat);

    // Save correlation matrix if checked
    if (FactorFrm->SaveRChkBox->Checked)
    {
     	  SaveDialog1->Filter = "Matrix files (*.mat)|*.MAT|All files (*.*)|*.*";
          SaveDialog1->FilterIndex = 1;
     	  if (SaveDialog1->Execute())
     	  {
                char FileName[131];
        		FileType = 7; // matrix file
        		strcpy(FileName,SaveDialog1->FileName.c_str());
                if (MatInput == false) // clear grid values
                {
                   for (int i = 1; i <= NoVariables; i++)
                   {
                       for (int j = 1; j <= NoCases; j++) MainForm->Grid->Cells[j][i] = "";
                   }
                   MainForm->Grid->RowCount = NoVariables + 1;
                   for (int i = 1; i <= NoVariables; i++)
                   {
                       for (int j = 1; j <= NoVariables; j++)
                           MainForm->Grid->Cells[j][i] = corrmat[i-1][j-1];
                   }
                }
                SaveMatrixFile(FileName);
          }
    }
    maxk = k;
    Nroots = k;

    if ( factorchoice != 1) //not a principal component analysis
    {
        //get matrix inverse, squared Multiple Correlations
        //Uniqueness (1-squared multiple Correlations, and
        //variance of residuals (D squared)
        for (i = 0; i < NoSelected; i++)
            for (j = 0; j < NoSelected; j++)
                TempMat[i+1][j+1] = corrmat[i][j];
                // Note - offset by one for inverse routine
        matinv(TempMat, k, ainverse, V, W);
        // reset inverse to 0 offset
        for (i = 0; i < NoSelected; i++)
            for (j = 0; j < NoSelected; j++)
                TempMat[i][j] = ainverse[i+1][j+1];
        for ( i = 0; i < k; i++)
        {
            d2[i] = 1.0 / TempMat[i][i];
            communality[i] = 1.0 - d2[i];
        }

        switch (factorchoice)
        {
         case 2:
             {
               strcpy(outline,"Partial Image Analysis");
                 // Save corrmat in ainverse for temporary use
                 for (i=0; i < k; i++)
                     for (j=0; j < k; j++) ainverse[i][j] = corrmat[i][j];
               for ( i = 0; i < k; i++) corrmat[i][i] = communality[i];
               if ((prtopts == 1) || (prtopts == 2))
               {
                  FrmOutPut->RichOutPut->Lines->Add("Communality Estimates are Squared Multiple Correlations.");
                  ArrayPrint(corrmat, k, k, "Partial Image Matrix", ColLabels,
                          ColLabels,outline);
                  FrmOutPut->ShowModal();
               }
             } break;
         case 3:
              {
                  strcpy(outline,"Guttman Image Analysis");
                  //pre and post multiply inverse of R by D2 to obtain anti-image matrix
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          TempMat[i][j] = d2[i] * TempMat[i][j] * d2[j];
                  if ((prtopts == 1) || (prtopts == 2))
                  {
                     ArrayPrint(TempMat, k, k, "Anti-image covariance matrix", ColLabels,
                              ColLabels, outline);
                     FrmOutPut->ShowModal();
                  }
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          corrmat[i][j] = corrmat[i][j] + TempMat[i][j];
                  for ( i = 0; i < k; i++)
                      corrmat[i][i] = corrmat[i][i] - (2.0 * d2[i]);
                  if ((prtopts == 1) || (prtopts == 2))
                  {
                     ArrayPrint(corrmat, k, k, "Image Covariance Matrix Analyzed", ColLabels,
                             ColLabels, outline);
                     FrmOutPut->ShowModal();
                  }
              } break;
         case 4:
              {
                  //pre and post multiply inverse of R by D2 to obtain anti-image matrix
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          TempMat[i][j] = d2[i] * TempMat[i][j] * d2[j];
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          corrmat[i][j] = corrmat[i][j] + TempMat[i][j];
                  for ( i = 0; i < k; i++)
                      corrmat[i][i] = corrmat[i][i] - (2.0 * d2[i]);
                  strcpy(outline,"Harris Scaled Image Analysis");
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          corrmat[i][j] = (1.0 / sqrt(d2[i]) *
                                corrmat[i][j] * (1.0 / sqrt(d2[j])));
                  if ((prtopts == 1) || (prtopts == 2))
                  {
                     ArrayPrint(corrmat, k, k, "Harris Scaled Image Covariance Matrix",
                                ColLabels, ColLabels, outline);
                     FrmOutPut->ShowModal();
                  }
              } break;
         case 5:
              {
                  strcpy(outline,"Canonical Factor Analysis");
                  for ( i = 0; i < k; i++) corrmat[i][i] = communality[i];
                  for ( i = 0; i < k; i++)
                      for ( j = 0; j < k; j++)
                          corrmat[i][j] = (1.0 / sqrt(d2[i])) *
                             corrmat[i][j] * (1.0 / sqrt(d2[j]));
                  if ((prtopts == 1) || (prtopts == 2))
                  {
                     ArrayPrint(corrmat, k, k, "Canonical Covariance Matrix",
                             ColLabels, ColLabels, outline);
                     FrmOutPut->ShowModal();
                  }
              } break;
        case 6:
             {
                 strcpy(outline,"Alpha Factor Analysis");
                 // Save corrmat in ainverse for temporary use
                 for (i=0; i < k; i++)
                     for (j=0; j < k; j++) ainverse[i][j] = corrmat[i][j];
                 for ( i = 0; i < k; i++) corrmat[i][i] = communality[i];
                 for ( i = 0; i < k; i++)
                     for ( j = 0; j < k; j++)
                         corrmat[i][j] = (1.0 / sqrt(communality[i])) *
                             corrmat[i][j] * (1.0 / sqrt(communality[j]));

                 if ((prtopts == 1) || (prtopts == 2))
                 {
                    ArrayPrint(corrmat, k, k, "Initial Alpha Factor Matrix",
                            ColLabels, ColLabels, outline);
                    FrmOutPut->ShowModal();
                 }
             }
        case 7:  // Principal Axis Factor Analysis
             {
                 // Save corrmat in ainverse for temporary use
                 for (i=0; i < k; i++)
                     for (j=0; j < k; j++) ainverse[i][j] = corrmat[i][j];
               for ( i = 0; i < k; i++) corrmat[i][i] = communality[i];
               if ((prtopts == 1) || (prtopts == 2))
               {
                  FrmOutPut->RichOutPut->Lines->Add("Initial Communality Estimates are Squared Multiple Correlations.");
                  ArrayPrint(corrmat, k, k, "Principal Axis Factor Analysis Matrix", ColLabels,
                          ColLabels,outline);
                  FrmOutPut->ShowModal();
               }
             } break;
        } // end switch
    } // end if
    else  // principal components analysis
    {
        strcpy(outline, "Principal Components Analysis");
        if ((prtopts == 1) || (prtopts == 2))
        {
           ArrayPrint(corrmat, k, k, "Correlation Matrix Factor Analyzed",
                   ColLabels, ColLabels,outline);
           FrmOutPut->ShowModal();
        }
    }

    //Calculate trace of the matrix to be analyzed
    trace = 0.0;
    for ( i = 0; i < k; i++) trace += corrmat[i][i];
    sprintf(outline,"Original matrix trace = %6.2f",trace);
    FrmOutPut->RichOutPut->Lines->Add(outline);

again:
    // Move correlations up one subscript in array since the roots routine
    // counts from 1, not zero. Store only lower half matrix
    TCursor Save_Cursor = Screen->Cursor; // save current cursor
    Screen->Cursor = crHourGlass;    // Show hourglass cursor
    L = 1;
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            DCORR[L] = corrmat[i][j];
            L++;
        }
    }
    DCORR[0] = 0.0;

    // Get the iegenvalues and vectors of the correlation matrix.
    // EVAL holds the values and EVEC holds the vectors
    if (MatInput == false) ICL[1] = count;
    else ICL[1] = N;
    IER = 0;

    OPRINC(DCORR,k,k,EVAL,EVEC,COMP,PERVAR,ICL,CU,IER);
    // Put results in 0 referenced arrays
    for (i = 0; i < NoSelected; i++)
    {
        Eigenvector[i] = EVAL[i+1];
        if (Eigenvector[i] > MaxRoot) MaxRoot = Eigenvector[i];
        for (j = 0; j < NoSelected; j++) TempMat[i][j] = EVEC[i+1][j+1];
    }

    // reflect vectors if needed
    for ( j = 0; j < NoSelected; j++)
    {
          double negsum = 0.0;
          double possum = 0.0;
          for ( i = 0; i < NoSelected; i++)
          {
              if (TempMat[i][j] < 0) negsum += TempMat[i][j];
              else possum += TempMat[i][j];
          }
          if (fabs(negsum) > possum)
          {
             for ( i = 0; i < NoSelected; i++)  TempMat[i][j] *= -1.0;
          }
    }

    if ((factorchoice == 6)|| (factorchoice == 7)) //iteratively solve for communalities
    {
        //denormalize eigenvectors
        for ( i = 0; i < k; i++)
        {
            for ( j = 0; j < k; j++)
            {
                if ( Eigenvector[j] > 0.0)
                    TempMat[i][j] = TempMat[i][j] * sqrt(Eigenvector[j]);
                else
                {
                    TempMat[i][j] = 0.0;
                    Eigenvector[j] = 0.0;
                }
            }
            b[i] = 0.0;
        }

        //get communality estimate from sum of squared loadings in TempMat
        for ( j = 0; j < k; j++)
            for ( i = 0; i < k; i++)
                b[i] += (TempMat[i][j] * TempMat[i][j]);
        for (i = 0; i < k; i++)
        {
            if (b[i] > 1.0)
            {
               b[i] = 1.0;
               sprintf(outline,"WARNING! A communality estimate greater than 1.0 found.");
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Value replaced by 1.0.  View results with skepticism.");
               FrmOutPut->RichOutPut->Lines->Add(outline);
            }
        }
        Difference = 0.0;
        for ( i = 0; i < k; i++) Difference += fabs(b[i] - communality[i]);
        if ((Difference > criterion) && (noiterations < maxiters))
        {
           for (i = 0; i < k; i++) // restore original r matrix
               for (j=0; j < k; j++) corrmat[i][j] = ainverse[i][j];
           // Place new communalities in the diagonal
           for ( i = 0; i < k; i++) corrmat[i][i] = b[i];
           // scale for alpha analysis
           if (factorchoice == 6)
           {
                  for ( i = 0; i < k; i++)
                     for ( j = 0; j < k; j++)
                         corrmat[i][j] = (1.0 / sqrt(b[i])) *
                             corrmat[i][j] * (1.0 / sqrt(b[j]));
           }
           // Save new communality estimates
           for (i = 0; i < k; i++) communality[i] = b[i];
            noiterations = noiterations + 1;
            goto again;
        }
        else
        {
            if (noiterations >= maxiters)
            {
               sprintf(outline,"Factor Analysis failed to converge in %d iterations.",maxiters);
               FrmOutPut->RichOutPut->Lines->Add(outline);
            }
            factREORDER(Eigenvector,ColNoSelected,TempMat,RowLabels,k);
        }
    }
    else //principal components
    {
        FACTORS(Eigenvector, d2, TempMat, k, factorchoice);
        factREORDER(Eigenvector, ColNoSelected, TempMat, RowLabels, k);
    }
    Screen->Cursor = Save_Cursor;  // restore regular cursor

    for ( i = 0; i < k; i++)
        for ( j = 0; j < k; j++)
            Loadings[i][j] = TempMat[i][j];

    if (ScreeChkBox->Checked)
    {
        for ( i = 0; i < k; i++) xvector[i] = double(i+1);
        scatplot(xvector, Eigenvector, k, "Scree Plot",
                 "Sequence Number of Eigenvalues", "Values",1.0, maxk,
                  0.0, MaxRoot);
//        FrmPlot->PlotIt(xvector,Eigenvector,k,1,"ROOT NO.","VALUE","SCREE PLOT");
    }

    // Setup labels for factors
    for (i = 0; i < k; i++ )
    {
        sprintf(outline,"Factor %d",i+1);
        ColLabels[i] = outline;
    }

    //print results if requested
    if (UnVectChkBox->Checked)
    {
       FrmOutPut->RichOutPut->Lines->Add("Roots (Eigenvalues) Extracted:");
       for ( i = 0; i < Nroots; i++)
       {
            sprintf(outline,"%4d %6.3f", i+1, Eigenvector[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->RichOutPut->Lines->Add("");
       strcpy(outline,"Unrotated Factor Loadings");
       ArrayPrint(Loadings,k,Nroots,"FACTORS",RowLabels,ColLabels,outline);
       FrmOutPut->RichOutPut->Lines->Add("Percent of Trace In Each Root:");
       for ( i = 0; i < Nroots; i++)
       {
           sprintf(outline,"%4d Root = %6.3f Trace = %6.3f Percent = %7.3f",
                i+1, Eigenvector[i], trace, (Eigenvector[i]/ trace) * 100.0);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->ShowModal();
    }

    // final communality estimates
    trace = 0.0;
    for (i = 0; i < k; i++)
    {
        b[i] = 0.0;
        for (j = 0; j < Nroots; j++) b[i] += (Loadings[i][j] * Loadings[i][j]);
        trace += b[i];
    }

    if (CommunChkBox->Checked)
    {
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->RichOutPut->Lines->Add("COMMUNALITY ESTIMATES");
       for (i = 0; i < k; i++)
       {
           sprintf(outline,"%3d %-10s %6.3f",i+1,RowLabels[i].c_str(),b[i]);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->RichOutPut->Lines->Add("");
       FrmOutPut->ShowModal();
    }

    if ( Nroots > 1)
    {
        minroot = atof(MinRootEdit->Text.c_str());
        Nroots = 0;
        for ( i = 0; i < k; i++)
           if ( Eigenvector[i] > minroot) Nroots = Nroots + 1;
        if (maxnoroots == 0) maxnoroots = Nroots;
        if (Nroots > maxnoroots) Nroots = maxnoroots;
        if (RadioGroup2->ItemIndex == 0)
           VARIMAX(Loadings, k, Nroots, RowLabels, ColLabels, ColNoSelected);
        if (RadioGroup2->ItemIndex == 1)
           PROMAX(Loadings, k, Nroots, RowLabels, ColLabels, ColNoSelected);
//           FrmOutPut->RichOutPut->Lines->Add("Oblique rotations not yet available. Sorry!");
        if (RadioGroup2->ItemIndex == 2)
           QUARTIMAX(Loadings, k, Nroots, RowLabels, ColLabels, ColNoSelected);
        if (RadioGroup2->ItemIndex == 3) // graphical (manual) rotation
        {
           cols = Nroots;
           rows = k;
           GraphOut->ShowModal();
           strcpy(outline,"Rotated Factor Loadings");
           ArrayPrint(Loadings,k,Nroots,"FACTORS",RowLabels,ColLabels,outline);
           FrmOutPut->ShowModal();
        }
        if (RadioGroup2->ItemIndex == 4) // Procrustean rotation to target
        { // procrustean rotation
            PROCRUST(Loadings,k,Nroots,RowLabels,ColLabels);
            MatInput = true;
        }
    }
    if (( factorchoice == 6) || (factorchoice == 7))
    {
        sprintf(outline,"No. of iterations = %d",noiterations);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    if (( Nroots > 1) && (PlotFactChkBox->Checked))
    {
        for ( i = 0; i < Nroots - 1; i++)
        {
            for ( j = i + 1; j < Nroots; j++)
            {
                for ( L = 0; L < k; L++)
                {
                    xvector[L] = Loadings[L][i];
                    yvector[L] = Loadings[L][j];
                }
                char xtitle[11];
                char ytitle[11];
                sprintf(xtitle,"Factor %d",i+1);
                sprintf(ytitle,"Factor %d",j+1);
                scatplot(xvector, yvector, k, "FACTOR PLOT", xtitle,
                         ytitle, -1.0, 1.0, -1.0, 1.0);
//                FrmPlot->PlotIt(xvector,yvector,k,0,ColLabels[i],ColLabels[j],"FACTOR PLOT");
            }  //Next j
        } //Next i
    }

    if (( Nroots > 1) && (PlotFactChkBox->Checked))
    {
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("COORDINATES OF THE PLOTS (LOADINGS)");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("VARIABLE  FACTOR  LOADING");
        for ( i = 0; i < Nroots; i++)
        {
            for ( L = 0; L < k; L++)
            {
                sprintf(outline,"%-10s   %3d   %8.4f",RowLabels[L].c_str(),i+1,Loadings[L][i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
            }
            FrmOutPut->RichOutPut->Lines->Add("");
        }
        FrmOutPut->ShowModal();
    }

    // Compute factor scores if checked
    if (FactorFrm->FactScrsChkBox->Checked)
    {
        if (MatInput == true)
            Application->MessageBox("Original subject scores unavailable (matrix in grid.)",
                "DATA NOT LOADED",MB_OK);
        else LSFactScores(Loadings,k,Nroots,NoCases,ColNoSelected);
    }

    // Save factor loadings if checked
    if (FactorFrm->SaveFChkBox->Checked)
    {
       for (i = 0; i < k; i++)
       {
           j = ColNoSelected[i];
           RowLabels[i] = MainForm->Grid->Cells[j][0];
       }
       for (i = 0; i < Nroots; i++)
       {
           sprintf(outline,"FACTOR%d",i+1);
           ColLabels[i] = outline;
       }
       SaveFactors(Loadings,k,Nroots,RowLabels,ColLabels);
    }

//    FrmOutPut->ShowModal();

    // Clean up the heap
cleanup:
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] stddevs;
     delete[] means;
     delete[] yvector;
     delete[] xvector;
     delete[] d2;
     delete[] b;
     delete[] pcnttrace;
     delete[] communality;
     delete[] Eigenvector;
     for (i = 0; i < NoSelected; i++) delete[] Loadings[i];
     delete[] Loadings;
     delete[] W;
     for (i = 0; i < NoSelected+1; i++) delete[] V[i];
     delete[] V;
     for (i = 0; i < NoSelected+1; i++) delete[] ainverse[i];
     delete[] ainverse;
     for (i = 0; i < NoSelected+1; i++) delete[] TempMat[i];
     delete[] TempMat;
     for (i = 0; i < NoSelected; i++) delete[] corrmat[i];
     delete[] corrmat;
     delete[] ColNoSelected;
     delete[] CU;
     delete[] ICL;
     delete[] PERVAR;
     for (int i = 0; i < NoSelected+1; i++) delete[] COMP[i];
     delete[] COMP;
     for (int i = 0; i < NoSelected+1; i++) delete[] EVEC[i];
     delete[] EVEC;
     delete[] EVAL;
     delete[] DCORR;
     FactorFrm->Hide();
}

//---------------------------------------------------------------------------

void __fastcall TFactorFrm::InBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFactorFrm::OutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TFactorFrm::EnterAllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox1->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox1->Items->Strings[index];
          ListBox2->Items->Add(cellstring);
     }
     ListBox1->Clear();
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TFactorFrm::FACTORS(double *eigenvalues, double *d2, double **A, int N,int factorchoice)
{
     //eigenvalues is the vector of N roots, a is the matrix of column eigenvectors, n is the order of the vector
     //and matrix, factorchoice is an integer indicating the type of factor analysis, and d2 is
     //a scaling weight for scaled factor analysis types
     //The results are the normalized factor loadings returned in a.
     int i, j;

     for ( i = 0; i < N; i++)
     {
         for ( j = 0; j < N; j++)
         {
             if ( eigenvalues[j] > 0) A[i][j] *=  sqrt(eigenvalues[j]);
             else  A[i][j] = 0.0;
         }
     }
     if ((factorchoice == 4) || (factorchoice == 5))
     {
         for ( i = 0; i < N; i++)
         {
             for ( j = 0; j < N; j++)
             {
                 if (d2[i] > 0)  A[i][j] *= sqrt(d2[i]);
                 else  A[i][j] = 0.0;
             }
         }
     }
     if ( factorchoice == 6) //alpha factor analysis
     {
        for ( i = 0; i < N; i++)
        {
            for ( j = 0; j < N; j++)
            {
                if ( eigenvalues[j] > 0 ) A[i][j] *= sqrt(1.0 - d2[i]);
                else A[i][j] = 0.0;
            }
        }
     }
} //factors

//---------------------------------------------------------------------------

void __fastcall TFactorFrm::factREORDER(double *d, int *d2, double **A,AnsiString *var_label, int N)
{
     //d is the vector of eigenvalues, d2 is the variable number, a is the eigenvalues matrix,
     //var_label is the array of variable labels and n is the vector and matrix order.
     int i, j, k;
     double Temp;
     AnsiString cellstring;

     for ( i = 0; i < (N - 1); i++)
     {
          for ( j = i + 1; j < N; j++)
          {
               if ( d[i] < d[j])
               {
                    Temp = d[i];   // swap eigenvectors
                    d[i] = d[j];
                    d[j] = Temp;
                    for ( k = 0; k < N; k++)  // swap columns in iegenvector matrix
                    {
                         Temp = A[k][i];
                         A[k][i] = A[k][j];
                         A[k][j] = Temp;
                    }
               }
          }
     }
} //End reorder procedure

//-----------------------------------------------------------------------------

void __fastcall TFactorFrm::SORT_LOADINGS(double **v, int n1, int n2, int *High_Factor, double *A,
     double *b, AnsiString *var_label, int *order)
{

     int i, j, k, itemp;
     int *NoInFact;
     double maxval, Temp;
     AnsiString tempstr;

     NoInFact = new int[n2];

     // Reorder factors in descending sequence ( left to right )
     for ( j = 0; j < n2 - 1; j++)
     {                                 // factor j
          for ( k = j + 1; k < n2; k++)
          {                            // factor k
               if ( A[j] < A[k])
               {                       // variance and factors need swapping
                    for ( i = 0; i < n1; i++)
                    {                  // swap factors
                         Temp = v[i][j];
                         v[i][j] = v[i][k];
                         v[i][k] = Temp;
                    }
                    Temp = A[j];          // variance swap
                    A[j] = A[k];
                    A[k] = Temp;
               }
          }
     }
     // Now select largest loading in each variable
     for ( j = 0; j < n2; j++) NoInFact[j] = 0.0;
     for ( i = 0; i < n1; i++)
     {
          High_Factor[i] = 0;
          maxval = 0.0;
          for ( j = 0; j < n2; j++)
          {
               if ( fabs(v[i][j]) > fabs(maxval))
               {
                    maxval = fabs(v[i][j]);
                    High_Factor[i] = j;
               }
          }
     }
     // Now sort matrix loadings
     for ( i = 0; i < n1 - 1; i++)
     {
          for ( j = i + 1; j < n1; j++)
          {
               if ( High_Factor[i] > High_Factor[j])
               {
                    itemp = High_Factor[i];
                    High_Factor[i] = High_Factor[j];
                    High_Factor[j] = itemp;
                    for ( k = 0; k < n2; k++)
                    {                            // loading swap
                         Temp = v[i][k];
                         v[i][k] = v[j][k];
                         v[j][k] = Temp;
                    }
                    tempstr = var_label[i];         // label swap
                    var_label[i] = var_label[j];
                    var_label[j] = tempstr;
                    Temp = b[i];                    // communality swap
                    b[i] = b[j];
                    b[j] = Temp;
                    itemp = order[i];
                    order[i] = order[j];
                    order[j] = itemp;
               }
          }
     }
     delete[] NoInFact;
} //End end of procedure

//-----------------------------------------------------------------------------

void  __fastcall TFactorFrm::VARIMAX(double **v, int n1, int n2, AnsiString * RowLabels,
              AnsiString *ColLabels, int *order)
{
     double pi = 3.14159265358979;
     double *A, *b, *C;
     int i, j, k, M, N, minuscount;
     int *High_Factor;
     double a1, b1, c1, c2, c3, c4, d1, x1, x2, Y, s1, Q, TotalPercent, t;
     char outline[81];
     double possum, negsum;

     A = new double[n1];
     b = new double[n1];
     C = new double[n1];
     High_Factor = new int[n1];

    // calculate proportion of variance accounted for by each factor
    //before rotation
    t = double(n1);
    for ( j = 0; j < n2; j++)
    {
         A[j] = 0.0;
         for ( i = 0; i < n1; i++)  A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
    if (FactorFrm->PcntTrChkBox->Checked)
    {
         FrmOutPut->RichOutPut->Lines->Add("Proportion of variance in unrotated factors");
         FrmOutPut->RichOutPut->Lines->Add("");
         for ( j = 0; j < n2; j++)
         {
             sprintf(outline,"%3d %6.3f",j+1, A[j]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    for ( i = 0; i < n1; i++)
    {
         b[i] = 0.0;
         High_Factor[i] = 0;
    }
    // Reflect factors 180 degrees if more negative than positive loadings
     for ( j = 0; j < n2; j++)
     {
//          minuscount = 0;
          negsum = 0.0;
          possum = 0.0;
          for ( i = 0; i < n1; i++)
          {
//              if ( v[i][j] < 0) minuscount++;
              if (v[i][j] < 0) negsum += v[i][j];
              else possum += v[i][j];
          }
//          if ( minuscount > (n1 / 2))
          if (fabs(negsum) > possum)
          {
             for ( i = 0; i < n1; i++)  v[i][j] *= -1.0;
          }
     }

     t = double(n1);
     // normalize rows of v
     for ( i = 0; i < n1; i++)
     {
         for ( j = 0; j < n2; j++)
         {
             b[i] += (v[i][j] * v[i][j]);
         }
         b[i] = sqrt(b[i]);
         for ( j = 0; j < n2; j++) v[i][j] /= b[i];
     }
label1:
     k = 0;
     for ( M = 0; M < n2; M++)
     {
         for ( N = M; N < n2; N++)
         {
              if ( M != N) // compute angle of rotation
              {
                   for ( i = 0; i < n1; i++)
                   {
                        A[i] = (v[i][M] * v[i][M]) - (v[i][N] * v[i][N]);
                        C[i] = 2.0 * v[i][M] * v[i][N];
                   }
                   a1 = 0.0;
                   for ( i = 0; i < n1; i++) a1 = a1 + A[i];
                   b1 = 0.0;
                   for ( i = 0; i < n1; i++)  b1 = b1 + C[i];
                   c1 = 0.0;
                   for ( i = 0; i < n1; i++) c1 = c1 + (A[i] * A[i]);
                   c2 = 0.0;
                   for ( i = 0; i < n1; i++) c2 = c2 + (C[i] * C[i]);
                   c3 = c1 - c2;
                   d1 = 0.0;
                   for ( i = 0; i < n1; i++) d1 = d1 + A[i] * C[i];
                   d1 = 2 * d1;
                   x1 = d1 - 2.0 * a1 * b1 / t;
                   x2 = c3 - ((a1 * a1) - (b1 * b1)) / t;
                   Y = atan(x1 / x2);
                   if ( x2 < 0)
                   {
                        if ( x1 >= 0.0) Y = Y + 2.0 * pi;
                        Y = Y - pi;
                   }
                   Y = Y / 4.0;
                   //if (fabs(Y) >= 0.0175) // rotate pair of axes
                   if ( fabs(Y) >= 0.000001)
                   {
                        c4 = cos(Y);
                        s1 = sin(Y);
                        k = 1;
                        for ( i = 0; i < n1; i++)
                        {
                             Q = v[i][M] * c4 + v[i][N] * s1;
                             v[i][N] = v[i][N] * c4 - v[i][M] * s1;
                             v[i][M] = Q;
                        }
                   } // if y
              }  // if m <> n
         } // next n
    }  // next m
    if ( k > 0)  goto label1;
    // denormalize rows of v
    for ( j = 0; j < n2; j++)
    {
         for ( i = 0; i < n1; i++) v[i][j] *= b[i];
         A[j] = 0.0;
         for ( i = 0; i < n1; i++) A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
    for ( i = 0; i < n1; i++) b[i] = (b[i] * b[i]) * 100.0;
    if (FactorFrm->CommunChkBox->Checked)
    {
         FrmOutPut->RichOutPut->Lines->Add("");
         FrmOutPut->RichOutPut->Lines->Add("Communality Estimates as percentages:");
         for ( i = 0; i < n1; i++)
         {
             sprintf(outline,"%3d %6.3f",i+1,b[i]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    if (FactorFrm->SortChkBox->Checked)
        SORT_LOADINGS(v, n1, n2, High_Factor, A, b, RowLabels, order);
    // Reflect factors 180 degrees if more negative than positive loadings
    for ( j = 0; j < n2; j++)
    {
//          minuscount = 0;
          negsum = 0.0;
          possum = 0.0;
          for ( i = 0; i < n1; i++)
          {
//              if ( v[i][j] < 0) minuscount++;
              if (v[i][j] < 0) negsum += v[i][j];
              else possum += v[i][j];
          }
//          if ( minuscount > (n1 / 2))
          if (fabs(negsum) > possum)
          {
             for ( i = 0; i < n1; i++)  v[i][j] *= -1.0;
          }
    }    // recalculate proportion of variance accounted for by each factor
    for ( j = 0; j < n2; j++)
    {
         A[j] = 0.0;
         for ( i = 0; i < n1; i++) A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
    // print results
    ArrayPrint(v, n1, n2,"FACTORS", RowLabels, ColLabels, "Varimax Rotated Loadings");
    TotalPercent = 0.0;
    FrmOutPut->RichOutPut->Lines->Add("Percent of Variation in Rotated Factors");
    for ( j = 0; j < n2; j++)
    {
        sprintf(outline,"Factor %3d %6.3f", j+1,A[j]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        TotalPercent += A[j];
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Total Percent of Variance in Factors : %6.3f",TotalPercent);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("Communalities as Percentages");
    for ( i = 0; i < n1; i++)
    {
        sprintf(outline,"%3d for %s %6.3f",i+1, RowLabels[i].c_str(), b[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();

    // clean up heap
     delete[] High_Factor;
     delete[] C;
     delete[] b;
     delete[] A;
} //{end of Varimax }

//-----------------------------------------------------------------------
void __fastcall TFactorFrm::PROCRUST(double **b, int nv, int nb, AnsiString *RowLabels,
              AnsiString *ColLabels)
{
     // nv is the no. of variables, nb the number of factors in the loadings
     // matrix.  nb is the number of factors in the b matrix.  b is the
     // obtained factor matrix, a is the target matrix.
     // ColLabels is the set of labels for the obtained factors
     // ColALabels is the set of labels for the target factor matrix
     int na; // number of factors in target matrix
     int nf; // nf is the no. of roots and vectors extracted from routine sevs
     int  i, j, k, nd;
     double ee, p, sum, **A, **C, **d, **v, *e, *f, *g, **trans;
     AnsiString response, Title;
     AnsiString *ColALabels;
     char outline[81];
     bool errorcode = false;

     nd = nv;
     na = MainForm->Grid->ColCount-1; // max. no. of factors (columns) in b matrix
     try  {
            A = new double *[nv];
            for (i = 0; i < nv; i++) A[i] = new double[nv];
            C = new double *[nv];
            for (i = 0; i < nv; i++) C[i] = new double[nv];
            d = new double *[nv];
            for (i = 0; i < nv; i++) d[i] = new double[nv];
            v = new double *[nv];
            for (i = 0; i < nv; i++) v[i] = new double[nv];
            trans = new double *[nv];
            for (i = 0; i < nv; i++) trans[i] = new double[nv];
            e = new double[nv];
            f = new double[nv];
            g = new double[nv];
            ColALabels = new AnsiString[na];
     }
     catch (...)
     {
             Application->MessageBox("Memory error in Procrust","MEMORY ERROR",MB_OK);
             return;
     }
     ArrayPrint(b, nv, nb, "FACTOR",RowLabels, ColLabels, "Source Factor Loadings");
     LoadFactors(A,nv,na,RowLabels,ColALabels);
     ArrayPrint(A,nv,na,"FACTOR",RowLabels,ColALabels,"Target Factor Loadings");

     // normalize matrix A by rows.
     for (i = 0; i < nv; i++)
     {
        sum = 0.0;
        for (j = 0; j < na; j++) sum += (A[i][j] * A[i][j]);
        p = 1.0 / sqrt(sum);
        for (j = 0; j < na; j++) A[i][j] *= p;
     }
     for (i = 0; i < nv; i++) // normalize matrix b by rows. Save lengths in g.
     {
        sum = 0.0;
        for (j = 0; j < nb; j++) sum += (b[i][j] * b[i][j]);
        g[i] = sqrt(sum);
        for (j = 0; j < nb; j++) b[i][j] = b[i][j] / g[i];
     }
     // compute cosines between factor axes and print results
     // get A transpose x B into C
     MATTRN(trans,A,nv,na);
     MATAxB(C,trans,b,na,nv,nv,nb,errorcode);
     // get D = C x C transpose
     MATTRN(trans,C,na,nb);
     MATAxB(d,C,trans,na,nb,nb,na,errorcode);
     // get roots and vectors of D.
     nf = SEVS(na, na, 0.0, d, v, e, f, nd); //nf is new no. of factors (nb)
     nb = nf;
     // get d = C transpose x V
     MATTRN(trans,C,na,nb);
     MATAxB(d,trans,v,nb,na,na,nb,errorcode);
     for (j = 0; j < nb; j++)
     {
        ee = pow(e[j],-1.5);
        for (i = 0; i < nb; i++) d[i][j] *= ee;
     }
     // get D x V'
     MATTRN(trans,v,na,nb);
     MATAxB(C,d,trans,nb,nb,nb,na,errorcode);
     FrmOutPut->RichOutPut->Lines->Add("Factor Pattern Comparison:");
     ArrayPrint(C,na,nb,"FACTORS",ColALabels,ColLabels,"Cosines Among Factor Axis");
     // get B x C
     for (i = 0; i < nv; i++)
     {
         for (j = 0; j < na; j++)
        {
            d[i][j] = 0.0;
            for (k = 0; k < nb; k++) d[i][j] += (b[i][k] * C[j][k]);
        }
     }
     for (i = 0; i < nv; i++)
        for (j = 0; j < na; j++)
            v[i][j] = d[i][j] * g[i];
     ArrayPrint(v,nv,na,"FACTORS",RowLabels,ColALabels,
        "New Factor Matrix Rotated to Maximum Congruence with Target");
     for (i = 0; i < nv; i++)
     {
        double sum = 0.0; // Get column products of the two matrices
        for (j = 0; j < na; j++) sum += (A[i][j] * d[i][j]);
        g[i] = sum;
     }
     FrmOutPut->RichOutPut->Lines->Add("Cosines (Correlations) Between Corresponding Variables");
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 0; i < nv; i++)
     {
        sprintf(outline,"%-10s %8.6f",RowLabels[i].c_str(),g[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     FrmOutPut->ShowModal();
     delete[] ColALabels;
     delete[] g;
     delete[] f;
     delete[] e;
     for (i = 0; i < nv; i++) delete[] trans[i];
     delete[] trans;
     for (i = 0; i < nv; i++) delete[] v[i];
     delete[] v;
     for (i = 0; i < nv; i++) delete[] d[i];
     delete[] d;
     for (i = 0; i < nv; i++) delete[] C[i];
     delete[] C;
     for (i = 0; i < nv; i++) delete[] A[i];
     delete[] A;
} // end of procrust
//-------------------------------------------------------------------------

void __fastcall TFactorFrm::LSFactScores(double **F, int NoVars, int NoFacts, int NCases,
                  int *ColNoSelected)
{
     double **R; // correlation matrix
     double **Rinv; // inverse of the correlation matrix
     double **Beta; // regression coefficients for predicting factor scores
     double **TempMat; // work area for inverse routine
     double **V; // work area for inverse routine
     double **ainverse; // temporary storate for R inverse (offset by 1)
     double *W;  // work vector for inverse routine
     double Score; // predicted factor score for one subject
     double *Means; // means of original variables
     double *StdDevs; // standard deviations of original variables
     double Sigma; // standard deviations of estimated common factor scores
     AnsiString *ColLabels; // factor loading headings
     AnsiString *RowLabels; // variable labels
     int i, j; // subscript variables
     int colno; // no. of grid column for a factor score
     char outline[81];
     bool errorcode = false;

     try  {
          R = new double *[NoVars];
          for (i = 0; i < NoVars; i++) R[i] = new double[NoVars];
          Rinv = new double *[NoVars];
          for (i = 0; i < NoVars; i++) Rinv[i] = new double[NoVars];
          Beta = new double *[NoVars];
          for (i = 0; i < NoVars; i++) Beta[i] = new double[NoVars];
          TempMat = new double *[NoVars+1];
          for (i = 0; i < NoVars+1; i++) TempMat[i] = new double[NoVars+1];
          V = new double *[NoVars+1];
          for (i = 0; i < NoVars+1; i++) V[i] = new double[NoVars+1];
          ainverse = new double *[NoVars+1];
          for (i = 0; i < NoVars+1; i++) ainverse[i] = new double[NoVars+1];
          W = new double[NoVars+1];
          Means = new double[NoVars];
          StdDevs = new double[NoVars];
          ColLabels = new AnsiString[NoVars];
          RowLabels = new AnsiString[NoVars];
     }
     catch (...)
     {
           Application->MessageBox("Memory error in Factor Scores","ERROR!",MB_OK);
           return;
     }

     // setup labels and print routine
     for (i = 0; i < NoVars; i++)
     {
         j = ColNoSelected[i];
         RowLabels[i] = MainForm->Grid->Cells[j][0];
     }
     for (i = 0; i < NoFacts; i++)
     {
         sprintf(outline,"Factor %d",i+1);
         ColLabels[i] = outline;
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SUBJECT FACTOR SCORE RESULTS:");

     // Obtain correlations
     Correlations(Means, StdDevs, R, NoVars, ColNoSelected, NCases,
                 3, false, 0);
     for (i = 0; i < NoVars; i++)
         for (j = 0; j < NoVars; j++)
             TempMat[i+1][j+1] = R[i][j];

     // Get inverse of the correlation matrix
     // Note - offset by one for inverse routine
     matinv(TempMat, NoVars, ainverse, V, W);
     // reset inverse to 0 offset
     for (i = 0; i < NoVars; i++)
         for (j = 0; j < NoVars; j++)
             Rinv[i][j] = ainverse[i+1][j+1];

     // Multiply the inverse matrix times the factor loadings matrix
     MATAxB(Beta,Rinv,F,NoVars,NoVars,NoVars,NoFacts,errorcode);

     ArrayPrint(Beta,NoVars,NoFacts,"FACTORS",RowLabels,ColLabels,
                "Regression Coefficients");

     // Calculate standard errors of factor scores
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Standard Error of Factor Scores:");
     for (i = 0; i < NoFacts; i++)
     {
         Sigma = 0.0;
         for (j = 0; j < NoVars; j++)
         {
             Sigma += (Beta[j][i] * F[j][i]);
         }
         Sigma = sqrt(Sigma);
         sprintf(outline,"%-10s %6.3f",ColLabels[i].c_str(),Sigma);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");

     //Calculate subject factor scores and place in the data grid
     int colstart = MainForm->Grid->ColCount;
     MainForm->Grid->ColCount += NoFacts;

     // place labels in new grid columns and define
     for (i = 0; i < NoFacts; i++)
     {
         sprintf(outline,"Fact.Scr.%d",i+1);
         MainForm->Grid->Cells[colstart+i][0] = outline;
         NewVar(NoVariables+1,true);
     }
     for (i = 0; i < NCases; i++) // subject
     {
         if (!ValidRecord(i+1,ColNoSelected,NoVars)) continue;
         for (j = 0; j < NoFacts; j++) // factor
         {
             Score = 0.0;
             for (int k = 0; k < NoVars; k++) // variables
             {
                 int m = ColNoSelected[k];
                 double x = atof(MainForm->Grid->Cells[m][i+1].c_str());
                 double z = (x - Means[k]) / StdDevs[k];
                 Score += (z * Beta[k][j]);
             }
             colno = colstart+j;
             sprintf(outline,"%6.4f",Score);
             MainForm->Grid->Cells[colno][i+1] = outline;
         }
     }
     FrmOutPut->ShowModal();
     // clean up the heap
     delete[] RowLabels;
     delete[] ColLabels;
     delete[] StdDevs;
     delete[] Means;
     delete[] W;
     for (i = 0; i < NoVars+1; i++) delete[] ainverse[i];
     delete[] ainverse;
     for (i = 0; i < NoVars+1; i++) delete[] V[i];
     delete[] V;
     for (i = 0; i < NoVars+1; i++) delete[] TempMat[i];
     delete[] TempMat;
     for (i = 0; i < NoVars; i++) delete[] Beta[i];
     delete[] Beta;
     for (i = 0; i < NoVars; i++) delete[] Rinv[i];
     delete[] Rinv;
     for (i = 0; i < NoVars; i++) delete[] R[i];
     delete[] R;
}
//--------------------------------------------------------------------------
void  __fastcall TFactorFrm::QUARTIMAX(double **v, int n1, int n2, AnsiString * RowLabels,
              AnsiString *ColLabels, int *order)
{
     double *A, *b, *C;
     int i, j, M, N, minuscount, NoIters = 0;
     int *High_Factor;
     double c4, s1, Q, NewQ, TotalPercent, t;
     double theta, tan4theta, ssqrp, ssqrj, prodjp, numerator, denominator;
     char outline[81];
     bool done;

     A = new double[n1];
     b = new double[n1];
     C = new double[n1];
     High_Factor = new int[n1];

    // calculate proportion of variance accounted for by each factor
    //before rotation
    t = double(n1);
    for ( j = 0; j < n2; j++)
    {
         A[j] = 0.0;
         for ( i = 0; i < n1; i++)  A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
    if (FactorFrm->PcntTrChkBox->Checked)
    {
         FrmOutPut->RichOutPut->Lines->Add("Proportion of variance in unrotated factors");
         FrmOutPut->RichOutPut->Lines->Add("");
         for ( j = 0; j < n2; j++)
         {
             sprintf(outline,"%3d %6.3f",j+1, A[j]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("");
    }
    for ( i = 0; i < n1; i++)
    {
         b[i] = 0.0;
         High_Factor[i] = 0;
    }
    // Reflect factors 180 degrees if more negative than positive loadings
     for ( j = 0; j < n2; j++)
     {
          minuscount = 0;
          for ( i = 0; i < n1; i++)
          {
              if ( v[i][j] < 0) minuscount++;
          }
          if ( minuscount > (n1 / 2))
          {
             for ( i = 0; i < n1; i++)  v[i][j] *= -1.0;
          }
     }

     t = double(n1);
     // normalize rows of v
     for ( i = 0; i < n1; i++)
     {
         for ( j = 0; j < n2; j++)
         {
             b[i] += (v[i][j] * v[i][j]);
         }
         b[i] = sqrt(b[i]);
//         for ( j = 0; j < n2; j++) v[i][j] /= b[i];
     }

     done = false;
     Q = 0.0;
     for (i = 0; i < n1; i++)
         for (j = 0; j < n2; j++)
             Q += pow(v[i][j],4.0);
     while (!done)
     {
         for ( M = 0; M < n2-1; M++)
         {
             for ( N = M+1; N < n2; N++)
             {
                 // compute angle of rotation for this pair of factors
//                 prodjp = 0.0;
//                 ssqrj = 0.0;
//                 ssqrp = 0.0;
                 numerator = 0.0;
                 denominator = 0.0;
                 for ( i = 0; i < n1; i++)
                 {
                     ssqrp = v[i][M] * v[i][M];
                     ssqrj = v[i][N] * v[i][N];
                     prodjp = 2.0 * v[i][M] * v[i][N];
                     numerator += prodjp * (ssqrp - ssqrj);
                     denominator += (pow(ssqrp - ssqrj,2.0) - pow(prodjp,2));
                 }
                 tan4theta = (2.0 * numerator) / denominator;
                 theta = atan(tan4theta) / 4.0;
                 c4 = cos(theta);
                 s1 = sin(theta);
                 // transform factor loadings
                 for ( i = 0; i < n1; i++)
                {
                    v[i][M] = v[i][M] * c4 + v[i][N] * s1;
                    v[i][N] = v[i][N] * c4 - v[i][M] * s1;
                }
             } // next n
         }  // next m
         NewQ = 0.0;
         for (i = 0; i < n1; i++)
             for (j = 0; j < n2; j++)
                 NewQ += pow(v[i][j],4.0);
         if (fabs(Q - NewQ) < 0.00001) done = true;
         if (n2 < 3) done = true;
         if (!done)
         {
            NoIters++;
            if (NoIters > 25)
            {
               sprintf(outline,"Quartimax failed to converge in 25 iterations.");
               FrmOutPut->RichOutPut->Lines->Add(outline);
               done = true;
            }
            Q = NewQ;
         }
     } // while not done

/*
    // denormalize rows of v
    for ( j = 0; j < n2; j++)
    {
         for ( i = 0; i < n1; i++) v[i][j] *= b[i];
         A[j] = 0.0;
         for ( i = 0; i < n1; i++) A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
*/
    for ( i = 0; i < n1; i++) b[i] = (b[i] * b[i]) * 100.0;
    if (FactorFrm->SortChkBox->Checked)
        SORT_LOADINGS(v, n1, n2, High_Factor, A, b, RowLabels, order);
    // Reflect factors 180 degrees if more negative than positive loadings
    for ( j = 0; j < n2; j++)
    {
         minuscount = 0;
         for ( i = 0; i < n1; i++)
         {
              if ( v[i][j] < 0) minuscount++;
         }
         if ( minuscount > (n1 / 2))
         {
            for ( i = 0; i < n1; i++) v[i][j] *= -1.0;
         }
    }
    // recalculate proportion of variance accounted for by each factor
    for ( j = 0; j < n2; j++)
    {
         A[j] = 0.0;
         for ( i = 0; i < n1; i++) A[j] += (v[i][j] * v[i][j]);
         A[j] = A[j] / t * 100.0;
    }
    // print results
    ArrayPrint(v, n1, n2,"FACTORS", RowLabels, ColLabels, "Quartimax Rotated Loadings");
    TotalPercent = 0.0;
    FrmOutPut->RichOutPut->Lines->Add("Percent of Variation in Rotated Factors");
    for ( j = 0; j < n2; j++)
    {
        sprintf(outline,"Factor %3d %6.3f", j+1,A[j]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        TotalPercent += A[j];
    }
    if (FactorFrm->CommunChkBox->Checked)
    {
       FrmOutPut->RichOutPut->Lines->Add("");
       sprintf(outline,"Total Percent of Variance in Factors : %6.3f",TotalPercent);
       FrmOutPut->RichOutPut->Lines->Add(outline);
       FrmOutPut->RichOutPut->Lines->Add("Communalities as Percentages");
       for ( i = 0; i < n1; i++)
       {
           sprintf(outline,"%3d for %s %6.3f",i+1, RowLabels[i].c_str(), b[i]);
           FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->RichOutPut->Lines->Add("");
    }
    FrmOutPut->ShowModal();
    // clean up heap
     delete[] High_Factor;
     delete[] C;
     delete[] b;
     delete[] A;
} //{end of Quartimax }
//----------------------------------------------------------------------------

void __fastcall TFactorFrm::LoadFactors(double **matrix,int &rows,int &cols,
                   AnsiString *RowLabels, AnsiString *ColLabels)
{
   // loads previously save factor loadings from a factor analysis
     FILE *infile;
     int NoRows;
     int NoCols;
     double value;
     char cellstring[21];
     char FileName[181];
     AnsiString astring;

     OpenDialog1->DefaultExt = "LOD";
     OpenDialog1->Filter = "Loadings (*.lod)|*.LOD|All (*.*)|*.*";
     OpenDialog1->FilterIndex = 1;
     OpenDialog1->FileName = "Loadings.LOD";
     if (OpenDialog1->Execute()) strcpy(FileName,OpenDialog1->FileName.c_str());
     else
     {
         astring = InputBox("FILENAME","Enter the name for your loadings:","Loadings.LOD");
         strcpy(FileName,astring.c_str());
     }
     infile = fopen(FileName,"rb");
     fread(&NoRows,sizeof(NoRows),1,infile);
     rows = NoRows;
     fread(&NoCols,sizeof(NoCols),1,infile);
     cols = NoCols;
     MainForm->NoVarsEdit->Text = NoCols;
     for (int i = 0; i < NoRows; i++)
     {
         for (int j = 0; j < NoCols; j++)
         {
             fread(&value,sizeof(value),1,infile);
             matrix[i][j] = value;
         }
     }
     // read row labels
     for (int i = 0; i < NoRows; i++)
     {
         fread(&cellstring,sizeof(cellstring),1,infile);
         RowLabels[i] = cellstring;
     }
     // read column labels
     for (int j = 0; j < NoCols; j++)
     {
         fread(&cellstring,sizeof(cellstring),1,infile);
         ColLabels[j] = cellstring;
     }
     fclose(infile);
}
//----------------------------------------------------------------------------

void __fastcall TFactorFrm::SaveFactors(double **Loadings, int k, int j,
                 AnsiString *RowLabels, AnsiString *ColLabels)
{
    // saves factor loadings
     FILE *outfile;
     int NoRows = k;
     int NoCols = j;
     double value;
     char cellstring[21];
     char FileName[181];
     AnsiString astring;

     SaveDialog1->DefaultExt = "LOD";
     SaveDialog1->Filter = "Loadings (*.lod)|*.LOD";
     SaveDialog1->FilterIndex = 1;
     SaveDialog1->FileName = "Loadings.LOD";
     if (SaveDialog1->Execute()) strcpy(FileName,SaveDialog1->FileName.c_str());
     else
     {
         astring = InputBox("FILENAME","Enter the name for your loadings:","Loadings.LOD");
         strcpy(FileName,astring.c_str());
     }
     outfile = fopen(FileName,"wb");
     fwrite(&NoRows,sizeof(NoRows),1,outfile);
     fwrite(&NoCols,sizeof(NoCols),1,outfile);
     // write grid values
     for (int i = 0; i < NoRows; i++)
     {
         for (int j = 0; j < NoCols; j++)
         {
             value = Loadings[i][j];
             fwrite(&value,sizeof(value),1,outfile);
         }
     }
     // write row labels
     for (int i = 0; i < NoRows; i++)
     {
         strcpy(cellstring,RowLabels[i].c_str());
         fwrite(&cellstring,sizeof(cellstring),1,outfile);
     }
     // write column labels
     for (int j = 0; j < NoCols; j++)
     {
         strcpy(cellstring,ColLabels[j].c_str());
         fwrite(&cellstring,sizeof(cellstring),1,outfile);
     }
     fclose(outfile);
}
//----------------------------------------------------------------------------

void __fastcall TFactorFrm::KMO(int k, double **matrix)
{
     double **workmat;
     double *diagonal;
     double sumr = 0.0;
     double sumi = 0.0;
     double kmo;
     char outline[101];

     GetDblMatMem(workmat,k,k);
     GetDblVecMem(diagonal,k);
     for (int i = 0; i < k; i++)
         for (int j = 0; j < k; j++)
             workmat[i][j] = matrix[i][j];
     SVDinverse(workmat, k);
     for (int i = 0; i < k; i++)
     {
         if (workmat[i][i] <= 0.0)
         {
            ShowMessage("Matrix may be singular!  ");
            diagonal[i] = 0.0;
         }
         else diagonal[i] = 1.0 / sqrt(workmat[i][i]);
     }
     for (int i = 0; i < k; i++)
         for (int j = 0; j < k; j++)
             workmat[i][j] = workmat[i][j] * diagonal[i] * diagonal[j];
     for (int i = 0; i < k - 1; i++)
     {
         for (int j = i + 1; j < k; j++)
         {
             sumi += (workmat[i][j] * workmat[i][j]);
             sumr += (matrix[i][j] * matrix[i][j]);
         }
     }
     kmo = sumr / (sumr + sumi);
     sprintf(outline,"Kaiser-Meyer-Olkin MSA statistic = %8.3f",kmo);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if (sumi >= sumr)
        FrmOutPut->RichOutPut->Lines->Add("MSA statistic indicates that FA is not warranted.");
     delete[] diagonal;
     ClearDblMatMem(workmat,k);
}
//----------------------------------------------------------------------------


void __fastcall TFactorFrm::InputOptGrpClick(TObject *Sender)
{
	InputType = InputOptGrp->ItemIndex;
   if (InputType != 1) {
   	Label6->Visible = false;
      NoObsEdit->Visible = false;
   }
   if (InputType == 1)  {
   	Label6->Visible = true;
      NoObsEdit->Visible = true;
   }
}
//---------------------------------------------------------------------------

void __fastcall TFactorFrm::PROMAX(double **v, int n1, int n2, AnsiString * RowLabels,
              AnsiString *ColLabels, int *order)
{
     // Promax starts with the varimax rotated loadings as initial estimates,
     // then builds a target matrix and uses the procrustean rotation to rotate
     // to this target matrix.
     // See "The Foundations of Factor Analysis" by Stanley A. Mulaik, 1972, pgs. 300-308
     double **G; // intermediate matrix - loading rows scaled by communalities
     double **A; // intermediate matrix - G columns scaled by largest col. val in G
     double **Target; // theoretically optimal oblique matrix
     double * h; // communality estimates (sqrt of sum of squared row values)
     double *kval; // largest column values
     double mpow = 5.0; // power with which to estimate ideal matrix
     double **T1, **T1Trans, **T1T; // transformation matrices
     double **D; // diagonal matrix with square roots of diagonal elements of T1' x T1
     double **FTrans; // transpose of varimax Factor loadings matrix v
     double **FTF; // product of FTrans and v and then the inverse of this product
     bool errorcode = false;
     double **Work; // a temporary work matrix for inverse of FTF x FTrans
     double **T; // transformation matrix
     double **FP; // Oblique factor pattern matrix
     double **D2; // recipricol of square root of T1Trans x T1
     double **F; // original unrotated matrix

     GetDblMatMem(F,n1,n2);
     GetDblMatMem(G,n1,n2);
     GetDblMatMem(A,n1,n2);
     GetDblMatMem(Target,n1,n2);
     h = new double [n1];
     kval = new double [n2];
     GetDblMatMem(T1,n1,n2);
     GetDblMatMem(T1Trans,n2,n1);
     GetDblMatMem(T1T,n2,n2);
     GetDblMatMem(D,n2,n2);
     GetDblMatMem(FTrans,n2,n1);
     GetDblMatMem(FTF,n2,n2);
     GetDblMatMem(Work,n1,n1);
     GetDblMatMem(T,n2,n2);
     GetDblMatMem(FP,n1,n2);
     GetDblMatMem(D2,n2,n2);

     for (int i = 0; i < n1; i++) // save original matrix of loadings
         for (int j = 0; j < n2; j++) F[i][j] = v[i][j];

     // first, get the varimax rotation
     VARIMAX(F, n1, n2, RowLabels, ColLabels, order);
//     ArrayPrint(F, n1, n2,"FACTORS", RowLabels, ColLabels, "Varimax Rotated Matrix");

     // Now build target matrix
     for (int i = 0; i < n1; i++) // get communalities
     {
         h[i] = 0.0;
         for (int j = 0; j < n2; j++) h[i] += (F[i][j] * F[i][j]);
         h[i] = sqrt(h[i]);
         for (int j = 0; j < n2; j++) G[i][j] = F[i][j] / h[i];
     }
     for (int j = 0; j < n2; j++) // get largets column values of G and scale col.
     {
         kval[j] = 0.0;
         for (int i = 0; i < n1; i++) if (fabs(G[i][j]) > kval[j]) kval[j] = fabs(G[i][j]);
         for (int i = 0; i < n1; i++) A[i][j] = G[i][j] / kval[j];
     }
     for (int i = 0; i < n1; i++) // build target with A elements raised to 4th power
     {
         for (int j = 0; j < n2; j++) Target[i][j] = fabs(pow(A[i][j],mpow))/ A[i][j];
     }

     ArrayPrint(Target, n1, n2,"FACTORS", RowLabels, ColLabels, "Rotation Target Matrix");
//     SaveFactors(Target,n1,n2,RowLabels,ColLabels);

     // Do unrestricted rocrustean rotation
     errorcode = MATTRN(FTrans,F,n1,n2);
     MATAxB(FTF,FTrans,F,n2,n1,n1,n2,errorcode);
     SVDinverse(FTF,n2);
     MATAxB(Work,FTF,FTrans,n2,n2,n2,n1,errorcode);
     MATAxB(T1,Work,Target,n2,n1,n1,n2,errorcode);
     errorcode = MATTRN(T1Trans,T1,n2,n2);
     MATAxB(T1T,T1Trans,T1,n2,n2,n2,n2,errorcode);
     for (int i = 0; i < n2; i++) // save diagonal of T1T matrix
         for (int j = 0; j < n2; j++) D2[i][j] = 0.0;
     for (int i = 0; i < n2; i++) D2[i][i] = 1.0 / sqrt(T1T[i][i]);
     SVDinverse(T1T,n2);
     for (int i = 0; i < n2; i++) // save diagonal values of inverted T1T
         for (int j = 0; j < n2; j++) D[i][j] = 0.0;
     for (int i = 0; i < n2; i++) D[i][i] = sqrt(T1T[i][i]);
     MATAxB(T,T1,D,n2,n2,n2,n2,errorcode); // get final transformation matrix
     ArrayPrint(T, n2, n2,"FACTORS", ColLabels, ColLabels, "Transformation Matrix");
     MATAxB(FP,F,T,n1,n2,n2,n2,errorcode);
     ArrayPrint(FP, n1, n2,"FACTORS", RowLabels, ColLabels, "Pattern Matrix");
     MATAxB(Work,F,T1,n1,n2,n2,n2,errorcode);
     MATAxB(v,Work,D2,n1,n2,n2,n2,errorcode);
     ArrayPrint(v, n1, n2,"FACTORS", RowLabels, ColLabels, "Structure Matrix");
     // Get correlations among axis
     MATTRN(T1Trans,T,n2,n2);
     MATAxB(T1T,T1Trans,T,n2,n2,n2,n2,errorcode);
     for (int i = 0; i < n2; i++) // normalize T by rows and columns
     {
         kval[i] = 0.0;
         for (int j = i; j < n2; j++) if (fabs(T1T[i][j])> fabs(kval[i])) kval[i] = fabs(T1T[i][j]);
         for (int j = i; j < n2; j++)
         {
             T1T[i][j] = T1T[i][j] / kval[i];
             T1T[j][i] = T1T[i][j];
         }
     }
     ArrayPrint(T1T, n2, n2,"FACTORS", ColLabels, ColLabels, "Pattern Axis Correlations");

     FrmOutPut->ShowModal();

     // clean up memory
     ClearDblMatMem(D2,n2);
     ClearDblMatMem(FP,n1);
     ClearDblMatMem(T,n2);
     ClearDblMatMem(Work,n2);
     ClearDblMatMem(FTF,n2);
     ClearDblMatMem(FTrans,n2);
     ClearDblMatMem(D,n2);
     ClearDblMatMem(T1T,n2);
     ClearDblMatMem(T1Trans,n2);
     ClearDblMatMem(T1,n1);
     delete[] kval;
     delete[] h;
     ClearDblMatMem(Target,n1);
     ClearDblMatMem(A,n1);
     ClearDblMatMem(G,n1);
     ClearDblMatMem(F,n1);
}
//---------------------------------------------------------------------------



