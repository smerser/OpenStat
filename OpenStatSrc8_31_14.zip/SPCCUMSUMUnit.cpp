//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "Math.hpp"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "PlotUnit.h"
#include "SPCCUMSUMUnit.h"
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSPCCUMSUMForm *SPCCUMSUMForm;
//---------------------------------------------------------------------------
__fastcall TSPCCUMSUMForm::TSPCCUMSUMForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSPCCUMSUMForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     if (ops.format == 0)
     {
        AlphaEdit->Text = "0.05";
        BetaEdit->Text = "0.20";
        DeltaEdit->Text = "0.02";
     }
     else
     {
        AlphaEdit->Text = "0,05";
        BetaEdit->Text = "0,20";
        DeltaEdit->Text = "0,02";
     }
     TargetEdit->Text = "";
     TargetChk->Checked = false;
     ShowUpperChk->Checked = false;
     ShowLowerChk->Checked = false;
     VMaskChk->Checked = false;
     GroupEdit->Text = "";
     MeasEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSPCCUMSUMForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TSPCCUMSUMForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     if (GroupEdit->Text == "") GroupEdit->Text = VarList->Items->Strings[index];
     else MeasEdit->Text = VarList->Items->Strings[index];     
}
//---------------------------------------------------------------------------
void __fastcall TSPCCUMSUMForm::ComputeBtnClick(TObject *Sender)
{
     int i, j, GrpVar, MeasVar, mingrp, maxgrp, G, range, grpsize, oldgrpsize;
     double X, UCL, LCL, xmin, xmax, GrandMean, GrandSD, Target, GrandSum;
     double *means, *stddev, *cumsums;
     int *count;
     AnsiString cellstring;
     char outline[101];
     bool sizeerror;

     GrpVar = 1;
     MeasVar = 2;
     oldgrpsize = 0;
     sizeerror = false;

     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GroupEdit->Text) GrpVar = i;
          if (cellstring == MeasEdit->Text) MeasVar = i;
     }

     mingrp = 10000;
     maxgrp = -10000;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidValue(i,GrpVar)) continue;
          G = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpVar][i])));
          if (G < mingrp) mingrp = G;
          if (G > maxgrp) maxgrp = G;
     }
     range = maxgrp - mingrp + 1;

     GetDblVecMem(means,range);
     GetIntVecMem(count,range);
     GetDblVecMem(stddev,range);
     GetDblVecMem(cumsums,range);
     for (i = 0; i < range; i++)
     {
          count[i] = 0;
          means[i] = 0.0;
          stddev[i] = 0.0;
          cumsums[i] = 0.0;
     }
     semean = 0.0;
     GrandMean = 0.0;
     GrandSum = 0.0;
     if (TargetChk->Checked) Target = StrToFloat(TargetEdit->Text);
     else Target = 0.0;

     // calculate group ranges, grand mean, group sd's, semeans
     for (int j = 0; j < range; j++)
     {
         xmin = 10000.0;
         xmax = -10000.0;
         for (i = 1; i <= NoCases; i++)
         {
             if (! ValidValue(i,GrpVar)) continue;
             G = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpVar][i])));
             G = G - mingrp + 1;
             if (G == j+1)
             {
                X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
                if (X > xmax) xmax = X;
                if (X < xmin) xmin = X;
                means[G-1] = means[G-1] + X;
                count[G-1] = count[G-1] + 1;
                stddev[G-1] = stddev[G-1] + (X * X);
                semean = semean + (X * X);
                GrandMean = GrandMean + X;
             }
         }
          stddev[j] = stddev[j] - (means[j] * means[j] / count[j]);
          stddev[j] = stddev[j] / (count[j] - 1);
          stddev[j] = sqrt(stddev[j]);
          grpsize = count[j];
          means[j] = means[j] / count[j];
          if (j == 0) oldgrpsize = grpsize;
          if (oldgrpsize != grpsize) sizeerror = true;
     } // next group

     // now get cumulative deviations of means from target
     if (Target == 0.0) Target = means[range-1];
     cumsums[0] = means[0] - Target;
     GrandSum = GrandSum + (means[0] - Target);
     for (j = 2; j <= range; j++)
     {
          cumsums[j-1] = cumsums[j-2] + (means[j-1] - Target);
          GrandSum = GrandSum + (means[j-1] - Target);
     }

     if (sizeerror)
     {
          ShowMessage("ERROR! Group sizes must be equal.");
          goto cleanup;
     }

     semean = semean - ((GrandMean * GrandMean) / NoCases);
     semean = semean / (NoCases - 1);
     semean = sqrt(semean);
     GrandSD = semean;
     semean = semean / sqrt(NoCases);
     GrandMean = GrandMean / NoCases; // mean of all observations
     GrandSum = GrandSum / range; // mean of the group means
     UCL = GrandSum + (3.0 * semean);
     LCL = GrandSum - (3.0 * semean);
     if (LCL < 0.0)  LCL = 0.0;

     // printed results
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("CUMSUM Chart Results");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Group Size Mean      Std.Dev.  Cum.Dev. of");
     FrmOutPut->RichOutPut->Lines->Add("                               mean from Target");
     FrmOutPut->RichOutPut->Lines->Add("_____ ____ ________  ________  ___________");
     for (i = 0; i < range; i++)
     {
          sprintf(outline," %3d %3d %8.2f %8.2f      %8.2f",
                  i+1,count[i], means[i], stddev[i], cumsums[i]);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"Mean of group deviations = %6.3f",GrandSum);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Mean of all observations = %6.3f",GrandMean);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Std. Dev. of Observations = %8.3f",GrandSD);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Standard Error of Mean = %8.3f",semean);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Target Specification = %6.3f",Target);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Lower Control Limit = %8.3f, Upper Control Limit = %8.3f",
            LCL, UCL);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();

     // show graph
     PlotMeans(cumsums,range,GrandSum,UCL,LCL,this);
cleanup:
     ClearDblVecMem(cumsums);
     ClearDblVecMem(stddev);
     ClearIntVecMem(count);
     ClearDblVecMem(means);
}
//---------------------------------------------------------------------------

void __fastcall TSPCCUMSUMForm::PlotMeans(double * means,
                             int NoGrps,
                             double GrandMean,
                             double UCL, double LCL,
                             TObject *Sender)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, grpnospc, distx;
     double imagehi, maxval, minval, valincr, Yvalue;
     double alpha, beta, delta, gamma, theta, kfactor, d;
     char Title[101];

     maxval = -10000.0;
     minval = 10000.0;
     for (i = 0; i < NoGrps; i++)
     {
          if (means[i] > maxval) maxval = means[i];
          if (means[i] < minval) minval = means[i];
     }

     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(hleft,vtop-10,hleft+hwide,vtop+vhi+10);

     // draw Grand Mean
     ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     sprintf(Title,"AVG.DEV.");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->Brush->Color = clLtGray;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw horizontal axis
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom + 20);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom + 20);
     for (i = 1; i <= NoGrps; i++)
     {
          ypos = vbottom + 10;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(Title,"%d",i);
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = xpos - offset;
          ypos = ypos + strhi;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = 10;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,"GROUPS:");
     }

     // Draw vertical axis
     valincr = (maxval - minval) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          sprintf(Title,"%8.2f",maxval - ((i-1)*valincr));
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = maxval - (valincr * (i-1));
          ypos = ceil(vhi * ( (maxval - Yvalue) / (maxval - minval)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw lines for means of the groups
     ypos = ceil(vhi * ( (maxval - means[0]) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = ceil((hwide / NoGrps) + hleft);
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     for (i = 2; i <= NoGrps; i++)
     {
          ypos = ceil(vhi * ( (maxval - means[i-1]) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // Draw V Mask
     if (DeltaEdit->Text == "") return; // not elected
     PlotForm->Image1->Canvas->Pen->Color = clBlue;
     delta = StrToFloat(DeltaEdit->Text);
     gamma = delta / semean;
     alpha = StrToFloat(AlphaEdit->Text);
     beta = StrToFloat(BetaEdit->Text);
     kfactor = 2.0 * semean;
     d = (2.0 / (gamma * gamma)) * log((1.0 - beta)/alpha);
     theta = ArcTan2(delta , (2.0 * kfactor));
     grpnospc = ceil(hwide / NoGrps);
     xpos = hleft + (grpnospc * (NoGrps)); // last group
     if (VMaskChk->Checked != true)
        ypos = ceil(vhi * ( (maxval - means[NoGrps-1]) / (maxval - minval)));
     else ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = ceil(xpos + (d * grpnospc / hwide)); // scaled d
     PlotForm->Image1->Canvas->LineTo(xpos,ypos); // line 0 to A

     // draw upper angle line
     xpos = hleft + (grpnospc * NoGrps); // last group
     xpos = ceil(xpos + (d * grpnospc / hwide)); // plus scaled d
     if (VMaskChk->Checked != true)
        ypos = ceil(vhi * ( (maxval - means[NoGrps-1]) / (maxval - minval)));
     else ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vtop; // draw angle up to top of graph
     distx = ceil(vhi / tan(theta)); // x unscaled distance
     xpos = ceil(xpos - (distx * grpnospc / hwide));
     if (xpos < hleft) xpos = hleft;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);

     // draw lower angle line
     xpos = hleft + (grpnospc * NoGrps); // last group
     xpos = ceil(xpos + (d * grpnospc / hwide)); // plus scaled d
     if (VMaskChk->Checked != true)
        ypos = ceil(vhi * ( (maxval - means[NoGrps-1]) / (maxval - minval)));
     else ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     xpos  = ceil(xpos - (distx * grpnospc / hwide));
     if (xpos < hleft) xpos = hleft;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;

     if (UCL > maxval)  maxval = UCL;
     if (LCL < minval)  minval = LCL;
     if (ShowUpperChk->Checked)
     {
          ypos = ceil(vhi * ( (maxval - UCL) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          strcpy(Title,"UPPER SPEC");
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     if (ShowLowerChk->Checked)
     {
          ypos = ceil(vhi * ( (maxval - LCL) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          strcpy(Title,"LOWER SPEC");
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     strcpy(Title,"CUMSUM (Cumulative Deviations from the Mean) CHART FOR : ");
     strcat(Title, MainForm->FileNameEdit->Text.c_str());
     ypos = PlotForm->Image1->Height - PlotForm->Image1->Canvas->TextHeight(Title);
     xpos = PlotForm->Image1->Width / 2 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     PlotForm->ShowModal();

}
//-------------------------------------------------------------------

