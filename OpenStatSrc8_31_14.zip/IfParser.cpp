//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
#include "math.h"
#include "ctype.h"
#include "MainUnit.h"
#include "IfParser.h"
extern struct Options ops;
//---------------------------------------------------------------------------
void CheckParens(int &LeftCnt, int &RightCnt, char *Expression)
{
	LeftCnt = RightCnt = 0;

    for (unsigned int i = 0; i < strlen(Expression); i++)
    {
    	if (Expression[i] == '(') LeftCnt++;
        if (Expression[i] == ')') RightCnt++;
    }
}

//---------------------------------------------------------------------------

void GetExpression(char *Expression, char *SubExpr, int &LeftParen,\
	 int &RightParen)
{
	// Search from left for for first right paren.  Search back for first left
    // paren (corresponding paren.)  Extract sub string.
    RightParen = 0;
    LeftParen = 0;
    for (unsigned int i=0; i < strlen(Expression); i++)
    {
    	if (Expression[i] == ')')
        {
        	RightParen = i;
        	break;
        }
    }

    for (int i = RightParen; i >= 0; i--)
    {
    	if (Expression[i] == '(')
        {
        	LeftParen = i;
            break;
        }
    }

    if (RightParen == 0) // no parentheses - take whole expression
    {
    	strcpy(SubExpr,Expression);
        return;
    }

    int j = 0;
    for (int i = LeftParen; i <= RightParen; i++, j++) SubExpr[j] = Expression[i];
    SubExpr[j] = '\0';
}

//-------------------------------------------------------------------------

void DelSubSt(char * Expression, unsigned int FromPos, unsigned int ToPos)
{
	unsigned int stlength = strlen(Expression);

    if(stlength <= ToPos - FromPos+1) return; // whole expression
    for (unsigned int i = ToPos+1; i < stlength; i++)
    {
    	Expression[FromPos] = Expression[i];
        FromPos++;
    }
    Expression[FromPos] = '\0';
}

//--------------------------------------------------------------------------

void TrimParens(char *Expression)
{
	unsigned int stlength = strlen(Expression);

    if (Expression[stlength-1] == ')') // paren at right end of string
    {
    	Expression[stlength-1] = '\0'; // truncate string
        stlength--;
    }

    if (Expression[0] == '(') // left paren
    {
    	for (unsigned int i = 0; i < stlength; i++) // copy including null char
        	Expression[i] = Expression[i+1];
    }
}

//---------------------------------------------------------------------------

int LeadOp(char *Expression)
{
	char chr = Expression[0];
    if ( (chr == '|') || (chr == '&') || (chr == '!') ) return 1;
    return 0;
}

//--------------------------------------------------------------------------

int OpPosition(char *Expression, char operation[], int &opleft, int &opright)
{
    opleft = 0;
    opright = 0;
	 for (unsigned int i = 0; i < strlen(Expression); i++)
    {
      if (Expression[i] == '.')  // beginning of logical expression
      {
         opleft = i;
         for (unsigned int j = i+1; j < strlen(Expression); j++)
         {
             if (Expression[j] == '.') { // end of logical expression
                opright = j;
                goto next;
             }
         }
      }
    }
next:
    int j = 0;
    for (int i = opleft; i <= opright; i++)
    {
        operation[j] = Expression[i];
        j++;
    }
    if ((opleft > 0) && (opright > 0))
    {
       operation[j] = '\0';
       return opleft;
    }
    else return 0;
}

//-------------------------------------------------------------------------

void RemoveBlanks(char *Expression)
{
	unsigned int stlength = strlen(Expression);
    for (unsigned int i = 0; i < stlength; i++)
    {
    	if (Expression[i] == ' ') // check for blank
        {
        	for (unsigned int j = i+1; j <= stlength; j++)
            	Expression[j-1] = Expression[j];
	        stlength--;
        }
    }
}

//-------------------------------------------------------------------------

void GetLeftSt(char *Expression, char *LeftSt, unsigned int FromPos)
{
	for (unsigned int i = 0; i < FromPos; i++) LeftSt[i] = Expression[i];
   LeftSt[FromPos] = '\0';
}

//-------------------------------------------------------------------------

void GetRightSt(char *Expression, char *RightSt, unsigned int FromPos)
{
	unsigned int j = 0;
    for (unsigned int i = FromPos+1;i < strlen(Expression); i++,j++)
    	RightSt[j] = Expression[i];
    RightSt[j] = '\0';
}

//-------------------------------------------------------------------------

int isnumeric(char *Expression)
{
    bool valid = false;
    char ch;

    for (unsigned int i = 0; i < strlen(Expression); i++)
    {
        ch = Expression[i];
        if (!isalpha(ch)) valid = true;
        if ((ops.format == 0) && (ch == ',')) valid = false;
        if ((ops.format == 1) && (ch == '.')) valid = false;
        if (!valid) break;
    }
    if (valid) return 1;
    else return 0;
}

//-------------------------------------------------------------------------

int GetVarIndex(char *varstring, char **VarLabels, int NoVars)
{
	// find a match, if any, between varstring and a VarLabel.  Return the
    // sequence number of the matching VarLabel if found, else -1.
    int result;

    for (int i = 0; i < NoVars; i++)
    {
    	result = strcmp(varstring, VarLabels[i]);
        if (result == 0) return i;
    }
    return -1;
}

//--------------------------------------------------------------------------

void BuildIfList(char *Expression, char **ExprList, int &NoExpr, char **JoinOps)
{
	 //This routine parses a compound expression into a list of sub-expressions
    // and joining logical operations
    unsigned int stlength;
    int LeftCnt, RightCnt, LeftParen, RightParen;
    char SubExpr[256];
    bool done = false;
	 bool found;

	 NoExpr = 0;
    RemoveBlanks(Expression);
    stlength = strlen(Expression);
    if (stlength == 0) return;
    CheckParens(LeftCnt, RightCnt, Expression);
    if (LeftCnt != RightCnt)
    {
    	  Application->MessageBox("Unmatched parentheses","ERROR!",MB_OK);
        return;
    }
    while (!done)
    {
    	GetExpression(Expression, SubExpr, LeftParen, RightParen);
    	if (LeftParen < RightParen)
      {
        	   TrimParens(SubExpr);
            LeftCnt--;
            RightCnt--;
      }
      stlength = strlen(SubExpr);
      if (stlength == 0)
      {
        	   Application->MessageBox("Empty expression","ERROR!",MB_OK);
            return;
      }
      strcpy(ExprList[NoExpr],SubExpr);

      if (LeftCnt > 0)
      {
	        // Look for a logical connection to next subexpression, if any
    	    found = false;
        	 if (RightParen > 0)
	       {
    	   		for (unsigned int i = RightParen+1; i < strlen(Expression); i++)
	    	      {
    	    	   	if (Expression[i] == '(') // another expression found before an op
        	    	   {
						   Application->MessageBox("No logical operand between expressions","ERROR!",MB_OK);
		                return;
    		         }
        		      else if (Expression[i] == '.') // join operation ?
            		{
		                JoinOps[NoExpr][0] = Expression[i]; // period .
                      JoinOps[NoExpr][1] = Expression[i+1]; // A, O or N
                      JoinOps[NoExpr][2] = '\0'; // terminate string
    		             found = true;
        		          break;
            		}
	            }
    	    }

	       if (!found) JoinOps[NoExpr][0] = ' ';
    	    if (RightParen == 0) //whole expression left
        	 {
        		Expression[0] = '\0'; // make empty
	         done = true;
    	    }
          //delete both the substring and the adjacent operator
        	 if (!done)DelSubSt(Expression, LeftParen, RightParen+5);
        	 if (LeftCnt == 1) // single expression left
          {
             TrimParens(Expression);
             LeftCnt--;
             RightCnt--;
          }

    	    if (strlen(Expression) == 0) done = true;
        	 NoExpr++;
	   } // end if LeftCnt > 0
      else done = true;
    } // end while not done
}

//--------------------------------------------------------------------------

void parse(char *Expression, char **ExprList, int &NoExpr, char **Ops,\
		char **LeftValue, char **RightValue, char **JoinOps)
{
	// An Expression string should contain one or more parenthetical substrings.
    // Each substring should contain an arithmetic or logical operation and have
    // a variable or numeric value to the left and right of the operand.  The
    // substrings should have a logical operand between them (&, |, or !).
    // The parse routine first obtains a list of subexpressions and their
    // logical seperators (operands).  It then parses each subexpression and
    // builds a list of operations, left values and right values.
    int OpPos;
    char operation[5];
    int opleft;
    int opright;

    BuildIfList(Expression, ExprList, NoExpr, JoinOps);
    for (int i = 0; i <= NoExpr; i++)
    {
    	OpPos = OpPosition(ExprList[i], operation, opleft, opright);
     	if (OpPos == 0)
      {
        	Application->MessageBox("Expression missing an operator","ERROR!",MB_OK);
			return;
      }
      strcpy(Ops[i],operation);
      GetLeftSt(ExprList[i], LeftValue[i], opleft);
      GetRightSt(ExprList[i],RightValue[i], opright);
    }
}

//-------------------------------------------------------------------------

bool TruthValue(int caseno, int ExpNo, char *LeftStr, char *RightStr,\
				char **OpCode, char **VarLabels, int NoVars)
{
    double TempValueLeft, TempValueRight;
    int result;
    int LeftVarPos, RightVarPos;
    bool LeftIsNo, RightIsNo, Truth;
	 AnsiString Label;
    int op;

    result = isnumeric(LeftStr);
    if (result)
    {
    	TempValueLeft = atof(LeftStr);
        LeftIsNo = true;
    }
    else //check for a variable label
    {
    	LeftIsNo = false;
        LeftVarPos = GetVarIndex(LeftStr, VarLabels, NoVars);
        if (LeftVarPos == -1)
        {
           Application->MessageBox("Invalid variable label","ERROR!",MB_OK);
           return false;
        }
    }

	result = isnumeric(RightStr);
    if (result)
    {
    	TempValueRight = atof(RightStr);
        RightIsNo = true;
    }
    else //check for a variable label
    {
    	RightIsNo = false;
        RightVarPos = GetVarIndex(LeftStr, VarLabels, NoVars);
        if (RightVarPos == -1)
        {
        	  Application->MessageBox("Invalid variable label","ERROR!",MB_OK);
        	  return false;
        }
    }

    // Now evaluate record truth or falseness
    if ((RightIsNo) && (!LeftIsNo)) // Left is variable, right is value
    {
		TempValueLeft = atof(MainForm->Grid->Cells[LeftVarPos+1][caseno].c_str());
    }
    if ( (!RightIsNo) && (LeftIsNo)) // Left is value, right is variable
    {
    	TempValueRight = atof(MainForm->Grid->Cells[RightVarPos+1][caseno].c_str());
    }
    if ( (!RightIsNo) && (!LeftIsNo)) // Both are variables
    {
       TempValueLeft = atof(MainForm->Grid->Cells[LeftVarPos+1][caseno].c_str());
       TempValueRight = atof(MainForm->Grid->Cells[RightVarPos+1][caseno].c_str());
    }

    Truth = false;
    if (strcmp(OpCode[ExpNo],".EQ.") == 0) op = 1;
    if (strcmp(OpCode[ExpNo],".LT.") == 0) op = 2;
    if (strcmp(OpCode[ExpNo],".GT.") == 0) op = 3;
    if (strcmp(OpCode[ExpNo],".LE.") == 0) op = 4;
    if (strcmp(OpCode[ExpNo],".GE.") == 0) op = 5;
    if (strcmp(OpCode[ExpNo],".NE.") == 0) op = 6;
    if (strcmp(OpCode[ExpNo],".AND.") == 0) op = 7;
    switch (op)
    {
        case 1 : if (TempValueLeft == TempValueRight) Truth = true; break;
        case 2 : if (TempValueLeft < TempValueRight) Truth = true; break;
        case 3 : if (TempValueLeft > TempValueRight) Truth = true; break;
        case 4 : if (TempValueLeft <= TempValueRight) Truth = true; break;
        case 5 : if (TempValueLeft >= TempValueRight) Truth = true; break;
        case 6 : if (TempValueLeft != TempValueRight) Truth = true; break;
        case 7 : if (TempValueLeft && TempValueRight) Truth = true; break;
    }
    return Truth;

}

