//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "MainUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "Math.h"
#include "CrossTabsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCrossTabForm *CrossTabForm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TCrossTabForm::TCrossTabForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCrossTabForm::ResetBtnClick(TObject *Sender)
{
    int i;

    VarList->Clear();
    SelectedBox->Clear();
    OutBtn->Visible = false;
    InBtn->Visible = true;
    for (i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TCrossTabForm::InBtnClick(TObject *Sender)
{
    int index, i;

    index = VarList->Items->Count;
    i = 0;
    while (i < index)
    {
        if (VarList->Selected[i])
        {
            SelectedBox->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index--;
            i = 0;
        }
        else i++;
    }
    OutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TCrossTabForm::OutBtnClick(TObject *Sender)
{
    int index;

    index = SelectedBox->ItemIndex;
    VarList->Items->Add(SelectedBox->Items->Strings[index]);
    SelectedBox->Items->Delete(index);
    InBtn->Visible = true;
    if (SelectedBox->Items->Count == 0) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCrossTabForm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TCrossTabForm::ComputeBtnClick(TObject *Sender)
{
    AnsiString cellstring;
    char outline[81];
    int i, j;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    // Use form to get variables
    NoSelected = SelectedBox->Items->Count;
    no_in_list = NoSelected;
    if (no_in_list <= 0)
    {
        ShowMessage("ERROR!  Select two or more variables to analyze.");
        return;
    }
    var_list = new int[NoSelected+1];
    min_value = new int[NoSelected+1];
    max_value = new int[NoSelected+1];
    levels = new int[NoSelected+1];
    displace = new int[NoSelected+1];
    subscript = new int[NoSelected+1];
    outgrid = new double*[500];
    for (i = 0; i < 500; i++) outgrid[i] = new double[500];
    ColNoSelected = new int[NoSelected+1];

    // initialize arrays
    for (int i = 0; i < NoSelected+1; i++)
    {
        var_list[i] = 0;
        min_value[i] = 0;
        max_value[i] = 0;
        levels[i] = 0;
        displace[i] = 0;
        subscript[i] = 0;
        for (int j = 0; j < NoSelected; j++) outgrid[i][j] = 0.0;
        ColNoSelected[i] = 0;
    }
    index = 0;
    length_array = 0;
    grandsum = 0;
    sum = 0;
    // Get selected variables
    for (i = 0; i < NoSelected; i++)
    {
        cellstring = SelectedBox->Items->Strings[i];
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
            {
                var_list[i] = j+1;
                ColNoSelected[i] = j+1;
            }
        }
/*
        result = VarTypeChk(ColNoSelected[i],1);
        if (result == 1)
        {
                delete[] outgrid;
                delete[] subscript;
                delete[] displace;
                delete[] levels;
                delete[] max_value;
                delete[] min_value;
                delete[] var_list;
                return;
        }
*/
    }

    // Get no. of levels for each variable
    GET_LEVELS(this);

    // set up frequency count array
    freq = new int[length_array+1];
    rowlabels = new AnsiString[length_array+1];
    collabels = new AnsiString[length_array+1];
    for (i = 0; i < length_array+1; i++) freq[i] = 0;

    // tabulate the data
    TABULATE(this);

    // show results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("CROSSTABULATION ANALYSIS PROGRAM");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("VARIABLE SEQUENCE FOR THE CROSSTABS:");
    for (i = 0; i < NoSelected; i++)
    {
        index = ColNoSelected[i];
        sprintf(outline,"%-10s (Variable %3d) Lowest level = %2d Highest level = %2d",
                MainForm->Grid->Cells[index][0].c_str(),i+1, min_value[i], max_value[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    // Do breakdown
    BREAKDOWN(this);
    FrmOutPut->ShowModal();

cleanup:
    delete[] collabels;
    delete[] rowlabels;
    delete[] freq;
    delete[] ColNoSelected;
    for (i = 0; i < 500; i++) delete[] outgrid[i];
    delete[] outgrid;
    delete[] subscript;
    delete[] displace;
    delete[] levels;
    delete[] max_value;
    delete[] min_value;
    delete[] var_list;
}
//---------------------------------------------------------------------------

void TCrossTabForm::GET_LEVELS(TObject *Sender)
{
    int i, j, k, X;
    int intvalue, result;
    double dblvalue;
    AnsiString strvalue;

    for (i = 0; i < no_in_list; i++)
    {
        j = var_list[i];
        if (!ValidRecord(1,ColNoSelected,NoSelected)) continue;
        min_value[i] = floor(StrToFloat(MainForm->Grid->Cells[j][1]));
        //result = GetValue(1, j,intvalue, dblvalue, strvalue);
        //if (result != 0) min_value[i] = 0;
        //else min_value[i] = intvalue;
        max_value[i] = min_value[i];
        for (k = 1; k < NoCases; k++)
        {
            if (ValidRecord(k+1,ColNoSelected,NoSelected))
            {
                X = floor(StrToFloat(MainForm->Grid->Cells[j][k+1]));
                //result = GetValue(k+1, j, intvalue, dblvalue, strvalue);
                //if (result != 0) X = 0;
                //else X = intvalue;
                if (X < min_value[i]) min_value[i] = X;
                if (X > max_value[i]) max_value[i] = X;
            }
        }
    }

    // Calculate number of levels for each variable
    for (i = 1; i <= no_in_list; i++)
        levels[i] = max_value[i-1] - min_value[i-1] + 1;
    displace[no_in_list] = 1;
    for (i = no_in_list-1; i >= 1; i--)
    {
        displace[i] = levels[i+1] * displace[i+1];
    }

    // get length of the arrays required to hold results
    length_array = 1;
    for (i = 1; i <= no_in_list; i++) length_array *= levels[i];
}
//---------------------------------------------------------------------------

int TCrossTabForm::INDEX_POSITION(int *x, TObject *Sender)
{
    int index, i;

    index = x[no_in_list];
    for (i = 1; i <= no_in_list - 1; i++)
        index = index + ((x[i] - 1) * displace[i]);
    return (index);

}
//---------------------------------------------------------------------------

void TCrossTabForm::TABULATE(TObject *Sender)
{
    int i, j, k, x;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    for (i = 0; i < NoCases; i++)
    {
        for (j = 0; j < no_in_list; j++)
        {
            if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
            k = var_list[j];
            x = floor(StrToFloat(MainForm->Grid->Cells[k][i+1]));
            //result = GetValue(i+1, k, intvalue, dblvalue, strvalue);
            //if (result != 0) x = 0;
            //else x = intvalue;
            x = x - min_value[j] + 1;
            subscript[j+1] = x;
        }
        j = INDEX_POSITION(subscript,this);
        freq[j-1] += 1;
    }
}
//---------------------------------------------------------------------------

void TCrossTabForm::BREAKDOWN(TObject *Sender)
{
    int i, j, row, col;
    AnsiString title;
    char outline[81];
    char value[81];

    for (col = 0; col < levels[no_in_list]; col++)
    {
        sprintf(value,"%3d", min_value[no_in_list-1] + col);
        collabels[col] = value;
    }
    for (row = 0; row < length_array; row++) rowlabels[row] = "";
    ptr1 = no_in_list - 1;
    ptr2 = no_in_list;
    for (i = 1; i <= no_in_list; i++) subscript[i] = 1;
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("FREQUENCIES BY LEVEL:");
    sum = 0;
    col = 0;
    row = 0;
Label1:
    index = INDEX_POSITION(subscript,this);
    strcpy(outline,"For Cell Levels: ");
    for (i = 0; i < no_in_list; i++)
    {
        j = var_list[i];
        sprintf(value,"%s:%3d  ",MainForm->Grid->Cells[j][0].c_str(),
                min_value[i] + subscript[i+1] - 1);
        strcat(outline,value);
    }
    sum += freq[index-1];
    outgrid[row][col] = freq[index-1];
    sprintf(value," Frequency = %3d",freq[index-1]);
    strcat(outline,value);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    subscript[ptr2]++;
    col++;
    if (subscript[ptr2] <= levels[ptr2]) goto Label1;
    sprintf(outline,"Number of observations for Block %d = %3d",row+1,sum);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->ShowModal();  // test for a bug
    grandsum += sum;
    sum = 0;
    row++;
    subscript[ptr1]++;
    if (subscript[ptr1] <= levels[ptr1]) goto Label4;
Label3:
    ptr1--;
    if (ptr1 < 0) goto printgrid;
    if (subscript[ptr1] > levels[ptr1]) goto Label3;
    subscript[ptr1]++;
    if (subscript[ptr1] > levels[ptr1]) goto Label3;
Label4:
    for (i = ptr1+1; i <= no_in_list; i++) subscript[i] = 1;
    ptr1 = no_in_list - 1;
    col = 0;
    goto Label1;
printgrid:
    strcpy(outline,"Cell Frequencies by Levels");
    for (i = 0; i < row; i++)
    {
        sprintf(value,"Block %d",i+1);
        rowlabels[i] = value;
    }
    strcpy(value,MainForm->Grid->Cells[var_list[no_in_list-1]][0].c_str());
    ArrayPrint(outgrid, row, levels[no_in_list], value,
     rowlabels, collabels, outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Grand sum for all categories = %d",grandsum);
    FrmOutPut->RichOutPut->Lines->Add(outline);

}
//---------------------------------------------------------------------------



void __fastcall TCrossTabForm::ReturnBtnClick(TObject *Sender)
{
     CrossTabForm->Hide();    
}
//---------------------------------------------------------------------------

