//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "MemMgrUnit.h"
#include "StepFwdUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStepFwdForm *StepFwdForm;
extern int NoCases;
extern int NoVariables;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TStepFwdForm::TStepFwdForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     MatInChk->Checked = false;
     SaveCorrsChk->Checked = false;
     PredictChk->Checked = false;
     CrossProdChk->Checked = false;
     CovarChk->Checked = false;
     CorrsChk->Checked = false;
     InverseChk->Checked = false;
     MeansChk->Checked = false;
     VariancesChk->Checked = false;
     StdDevsChk->Checked = false;
     BPGChk->Checked = false;
     DepEdit->Text = "";
     if (ops.format == 0)
     {
          InProbEdit->Text = "0.05";
          OutProbEdit->Text = "0.10";
     }
     else
     {
          InProbEdit->Text = "0,05";
          OutProbEdit->Text = "0,10";
     }
     DepOutBtn->Visible = false;
     DepInBtn->Visible = true;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::DepOutBtnClick(TObject *Sender)
{
     if (DepEdit->Text == "") return;
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::AllBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     for (int i = 0; i < VarList->Items->Count; i++)
         SelList->Items->Add(VarList->Items->Strings[i]);
     VarList->Clear();
     IndInBtn->Visible = false;
     IndOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TStepFwdForm::OKBtnClick(TObject *Sender)
{
     int i, j, k, k1, col, NoVars, mattype, NCases,errcnt, Index, NoIndepVars;
     bool errorcode, showinverse;
     double largest, R2, Constant, Beta, df1, df2, SSt, SSres, VarEst;
     double StdErrEst, F, FProbF, sum, B, SSx, StdErrB, NewR2, LargestPartial;
     double pdf1, pdf2, PartF, PartProb, LargestProb, POut, SmallestProb;
     double *BetaWeights, *BWeights, *BStdErrs, *Bttests, *Bprobs;
     AnsiString cellstring, valstring, title;
     char outline[121];
     double **corrs;
     double *Means;
     double *Variances;
     double *StdDevs;
     int *ColNoSelected;
     AnsiString *RowLabels;
     AnsiString *ColLabels;
     AnsiString *IndRowLabels;
     AnsiString *IndColLabels;
     double **IndepCorrs;
     double **IndepInverse;
     int *IndepIndex;
     double *XYCorrs;
     bool matched;
     double *Partial;
     int *Candidate;
     int TempNoVars;
     int StepNo, OriginNoVars;
     AnsiString filename;
     int result;

//     if (NoVariables < 2) NoVariables = 200;

     GetDblMatMem(corrs,NoVariables+1,NoVariables+1);
     GetDblMatMem(IndepCorrs,NoVariables,NoVariables);
     GetDblMatMem(IndepInverse,NoVariables,NoVariables);
     Means = new double[NoVariables];
     Variances = new double[NoVariables];
     StdDevs = new double[NoVariables];
     RowLabels = new AnsiString[NoVariables];
     ColLabels = new AnsiString[NoVariables];
     XYCorrs = new double[NoVariables];
     IndepIndex = new int[NoVariables];
     IndColLabels = new AnsiString[NoVariables];
     IndRowLabels = new AnsiString[NoVariables];
     BetaWeights = new double[NoVariables];
     BWeights = new double[NoVariables];
     BStdErrs = new double[NoVariables];
     Bttests = new double[NoVariables];
     Bprobs = new double[NoVariables];
     Partial = new double[NoVariables];
     Candidate = new int[NoVariables];
     ColNoSelected = new int[NoVariables];

     OriginNoVars = NoVariables; // note - additional variables might be created
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Stepwise Multiple Regression by Bill Miller");
     StepNo = 1;
     errcnt = 0;
     errorcode = false;
     if (MatInChk->Checked)
     {
               LoadMatrix();
               NoVars = NoVariables;
               NCases = NoCases;
               for (i = 0; i < NoVars; i++)
               {
                    Means[i] = 0.0;
                    StdDevs[i] = 1.0;
                    Variances[i] = sqr(StdDevs[i]);
                    ColNoSelected[i] = i+1;
                    RowLabels[i] = MainForm->Grid->Cells[i+1][0];
               }
               for (i = 0; i < NoVars; i++)
               {
                   VarList->Items->Add(RowLabels[i]);
                   for (j = 0; j < NoVars; j++)
                       corrs[i][j] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][j+1]));
               }
//          }
     }
     else
     {
          // get independent item columns
          NoVars = SelList->Items->Count;
          if (NoVars < 1)
          {
               ShowMessage("ERROR! No independent variables selected.");
               goto CleanUp;
          }
          for (i = 0; i < NoVars; i++)
          {
               cellstring = SelList->Items->Strings[i];
               for (j = 1; j <= NoVariables; j++)
               {
                    if (cellstring == MainForm->Grid->Cells[j][0])
                    {
                         ColNoSelected[i] = j;
                         // for strong type checking, uncomment the following
                         // result = VarTypeChk(j,0);
                         // if (result == 1) goto CleanUp;
                         RowLabels[i] = cellstring;
                         ColLabels[i] = cellstring;
                    }
               }
          }
          // get dependendent variable column
          if (DepEdit->Text == "")
          {
               ShowMessage("ERROR! No Dependent variable selected.");
               goto CleanUp;
          }
          NoVars = NoVars + 1;
          for (j = 1; j <= NoVariables; j++)
          {
               if (DepEdit->Text == MainForm->Grid->Cells[j][0])
               {
                    ColNoSelected[NoVars-1] = j;
                    // for strong type checking, uncomment the following
                    // result = VarTypeChk(j,0);
                    //if (result == 1) goto CleanUp;
                    RowLabels[NoVars-1] = DepEdit->Text;
                    ColLabels[NoVars-1] = DepEdit->Text;
               }
          }
          NoCases = MainForm->Grid->RowCount - 1;
          NCases = NoCases;

          if ((CrossProdChk->Checked)&& (!MatInChk->Checked))
          {
               Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected,
                  NCases, 1, false, 0);
               MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Cross-Products Matrix");
          }

          if ((CovarChk->Checked)&&(!MatInChk->Checked))
          {
               Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected,
                  NCases, 2, false, 0);
               MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Variance-Covariance Matrix");
          }
          if (!MatInChk->Checked)
             Correlations(Means, StdDevs, corrs, NoVars,ColNoSelected, NCases,
                       3, false, 0);
     } // end else

     if (CorrsChk->Checked)
        MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Product-Moment Correlations Matrix");

     if (SaveCorrsChk->Checked)
     {
          SaveDialog1->Filter = "Stat4Free matrix files (*.MAT)|*.MAT|All files (*.*)|*.*";
          SaveDialog1->FilterIndex = 1;
          if (SaveDialog1->Execute())
          {
               filename = SaveDialog1->FileName;
               SaveSqrMat(corrs, NoVars, NCases, RowLabels, Means, StdDevs);
          }
     }
     for (int i = 0; i < NoVars; i++) Variances[i] = sqr(StdDevs[i]);
     if (MeansChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Means,NoVars,ColLabels,"Means");
     }
     if (VariancesChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(Variances,NoVars,ColLabels,"Variances");
     }
     if (StdDevsChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(StdDevs,NoVars,ColLabels,"Standard Deviations");
     }
     if (errorcode)
     {
          FrmOutPut->RichOutPut->Lines->Add("One or more correlations could not be computed due to zero variance of a variable.");
     }
//     FrmOutPut->ShowModal();

     if (errorcode)
     {
          ShowMessage("ERROR! A selected variable has no variability-run aborted.");
          goto CleanUp;
     }

//     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Stepwise Multiple Regression by Bill Miller");

     if (InverseChk->Checked) showinverse = true;
     else showinverse = false;
     //  Select largest correlation to begin. Note: dependent is last variable
     largest = 0.0;
     Index = 1;
     for (i = 1; i < NoVars; i++)
     {
          if (fabs(corrs[i-1][NoVars-1]) > largest)
          {
               largest = fabs(corrs[i-1][NoVars-1]);
               Index = i;
          }
     }

     NoIndepVars = 1;
     IndepIndex[NoIndepVars-1] = Index;
     POut = StrToFloat(OutProbEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"----------------- STEP %d ------------------",StepNo);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     MReg2(NCases,NoVars,NoIndepVars,IndepIndex,corrs,IndepInverse,
          RowLabels,R2,BetaWeights,
          Means,Variances,errcnt,StdErrEst,Constant,POut,true, true,showinverse);
     FrmOutPut->ShowModal();

     while (NoIndepVars < NoVars-1)
     {
            // select the next independent variable based on the largest
            //  semipartial correlation with the dependent variable.  The
            //  squared semipartial for each remaining independent variable
            //  is the difference between the squared MC of the dependent
            //  variable with all previously entered variables plus a candidate
            //  variable and the squared MC with just the previously entered
            //  variables ( the previously obtained R2 ).
            // build list of candidates
            StepNo = StepNo + 1;
            k = 0;
            for (i = 1; i < NoVars; i++)
            {
                 matched = false;
                 for (j = 0; j < NoIndepVars; j++)
                 {
                      if (IndepIndex[j] == i ) matched = true;
                 }
                 if (matched == false)
                 {
                      k = k + 1;
                      Candidate[k-1] = i;
                 }
            }   // k is the no. of candidates }
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("Candidates for entry in next step.");
            FrmOutPut->RichOutPut->Lines->Add("Candidate  Partial  F Statistic  Prob.  DF1  DF2");
            LargestProb = 0.0;
            SmallestProb = 1.0;
            for (k1 = 1; k1 <= k; k1++)
            {
                 // get Mult Corr. with previously entered plus candidate
                 IndepIndex[NoIndepVars] = Candidate[k1-1];
                 TempNoVars = NoIndepVars + 1;
                 MReg2(NCases,NoVars,TempNoVars,IndepIndex,corrs,IndepInverse,
                    RowLabels,NewR2,BetaWeights, Means,Variances,
                    errcnt, StdErrEst, Constant, POut, false, false,false);
                 Partial[k1-1] = (NewR2 - R2) / (1.0 - R2);
                 pdf1 = 1;
                 pdf2 = NCases - TempNoVars - 1;
                 PartF = ((NewR2 - R2) * pdf2) / (1.0 - NewR2);
                 PartProb = ftest(pdf1,pdf2,PartF);
                 if (PartProb < SmallestProb)  SmallestProb = PartProb;
                 if (PartProb > LargestProb)  LargestProb = PartProb;
                 sprintf(outline,"%-10s  %6.4f   %7.4f    %6.4f   %3.0f  %3.0f",
                    RowLabels[Candidate[k1-1]-1].c_str(), sqrt(fabs(Partial[k1-1])), PartF, PartProb, pdf1, pdf2);
                 FrmOutPut->RichOutPut->Lines->Add(outline);
            }

            if (SmallestProb > StrToFloat(InProbEdit->Text))
            {
                 FrmOutPut->RichOutPut->Lines->Add("No further steps meet criterion for entry.");
                 goto lastone;
            }
            // select variable with largest partial to enter next
            LargestPartial = 0.0;
            Index = 1;
            for (i = 1; i <= k; i++)
            {
                 if (Partial[i-1] > LargestPartial)
                 {
                      Index = Candidate[i-1];
                      LargestPartial = Partial[i-1];
                 }
            }

            sprintf(outline,"Variable %s will be added",RowLabels[Index-1]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            NoIndepVars = NoIndepVars + 1;
            IndepIndex[NoIndepVars-1] = Index;
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(outline,"----------------- STEP %d ------------------",StepNo);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            MReg2(NCases,NoVars,NoIndepVars,IndepIndex,corrs,IndepInverse,
                    RowLabels,R2,BetaWeights, Means,Variances,
                    errcnt, StdErrEst, Constant,POut,true,true,showinverse);
            if ((errcnt > 0) ||(NoIndepVars == NoVars-1)) // out tolerance exceeded - finish up
lastone:    {
                 FrmOutPut->RichOutPut->Lines->Add("");
                 FrmOutPut->RichOutPut->Lines->Add("-------------FINAL STEP-----------");
                 MReg2(NCases,NoVars,NoIndepVars,IndepIndex,corrs,IndepInverse,
                      RowLabels,NewR2,BetaWeights,Means,Variances,
                      errcnt,StdErrEst,Constant,POut,true,false,showinverse);
                 k1 = NoIndepVars; // store temporarily
                 NoIndepVars = NoVars; // this stops loop
            }
     } // while not done
     FrmOutPut->ShowModal();

     if (k1 < NoVars) NoIndepVars = k1;
     else k1 = 1;
     // add [predicted scores, residual scores, etc. to grid if options elected
     if (MatInChk->Checked)  PredictChk->Checked = false;
     if ((PredictChk->Checked) && (k1 < NoVars))
        Predict(ColNoSelected, IndepIndex, NoVars, IndepInverse, Means, StdDevs, BetaWeights,
             BWeights, Constant, StdErrEst, NoIndepVars);
CleanUp:
     delete[] ColNoSelected;
     delete[] Candidate;
     delete[] Partial;
     delete[] Bprobs;
     delete[] Bttests;
     delete[] BStdErrs;
     delete[] BWeights;
     delete[] BetaWeights;
     delete[] IndColLabels;
     delete[] IndRowLabels;
     delete[] IndepIndex;
     delete[] XYCorrs;
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
     ClearDblMatMem(IndepInverse,OriginNoVars);
     ClearDblMatMem(IndepCorrs,OriginNoVars);
     ClearDblMatMem(corrs,OriginNoVars+1);
}
//---------------------------------------------------------------------------
