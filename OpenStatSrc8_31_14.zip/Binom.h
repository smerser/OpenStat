//---------------------------------------------------------------------------
#ifndef BinomH
#define BinomH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TBinomFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *CatAEdit;
    TEdit *CatBEdit;
    TEdit *PropAEdit;
    TButton *ClearBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
     TCheckBox *PlotChk;
    void __fastcall ClearBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TBinomFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBinomFrm *BinomFrm;
//---------------------------------------------------------------------------
#endif
