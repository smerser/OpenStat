//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Discrim.h"
#include "DiscMano.h"
#include "MainUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern int NoVariables;

TDiscrimForm *DiscrimForm;
//---------------------------------------------------------------------------
__fastcall TDiscrimForm::TDiscrimForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::OKBtnClick(TObject *Sender)
{
   DiscrimForm->Hide();
   Discriminant();
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::CancelBtnClick(TObject *Sender)
{
    DiscrimForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::ResetBtnClick(TObject *Sender)
{
    ListBox1->Clear();
    ListBox2->Clear();
    RadioGroup1->ItemIndex = 1;
    for (int i = 0; i < NoVariables; i++)
    {
        AnsiString cellstring = MainForm->Grid->Cells[i+1][0];
        ListBox1->Items->Add(cellstring);
    }
    // Reset all options to false
    CheckBox1->Checked = false;
    CheckBox2->Checked = false;
    CheckBox3->Checked = false;
    CheckBox4->Checked = false;
    CheckBox5->Checked = false;
    CheckBox6->Checked = false;
    CheckBox7->Checked = false;
    CheckBox8->Checked = false;
    CheckBox9->Checked = false;
    CheckBox10->Checked = false;
    CheckBox11->Checked = false;
    CheckBox12->Checked = false;
    CheckBox13->Checked = false;
    CheckBox20->Checked = false;
    CheckBox21->Checked = false;
    CheckBox22->Checked = false;
    CheckBox23->Checked = false;
    
    VarOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------


void __fastcall TDiscrimForm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::VarInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::VarOutBtnClick(TObject *Sender)
{
	int index;
    int noselected;
    AnsiString cellstring;

    noselected = ListBox2->Items->Count;
    if (noselected == 0) return;
    index = ListBox2->ItemIndex;
    if (index < 0) return;
    cellstring = ListBox2->Items->Strings[index];
    ListBox1->Items->Add(cellstring);
    ListBox2->Items->Delete(index);
    noselected = ListBox2->Items->Count;
    if (noselected == 0) VarOutBtn->Enabled = false;

}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::ListBox2Click(TObject *Sender)
{
 	int index;
    AnsiString cellstring;

    index = ListBox2->ItemIndex;
    if (index < 0) return;
    cellstring = ListBox2->Items->Strings[index];
    GroupVar->Text = cellstring;
    ListBox2->Items->Delete(index);    
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::BtnAllClick(TObject *Sender)
{
    int noitems;
    AnsiString cellstring;

    noitems = ListBox1->Items->Count;
    for (int i = 0; i < noitems; i++)
    {
        cellstring = ListBox1->Items->Strings[i];
        ListBox2->Items->Add(cellstring);
    }
    ListBox1->Clear();
    VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::CheckBox21Click(TObject *Sender)
{
        if (CheckBox21->Checked)
        {
                CheckBox22->Checked = true;
                CheckBox23->Checked = true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::CheckBox22Click(TObject *Sender)
{
        if (CheckBox21->Checked)
        {
                CheckBox22->Checked = true;
                CheckBox23->Checked = true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TDiscrimForm::CheckBox23Click(TObject *Sender)
{
        if ((CheckBox21->Checked) || (CheckBox22->Checked))
        {
                CheckBox23->Checked = true;
                CheckBox21->Checked = true;
                CheckBox22->Checked = true;
        }
}
//---------------------------------------------------------------------------

