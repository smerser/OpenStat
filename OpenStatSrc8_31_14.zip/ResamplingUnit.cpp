//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "functions.h"
#include "GraphUnit.h"
#include "MemMgrUnit.h"
#include "MTRandom.h"
#include "ResamplingUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TResamplingForm *ResamplingForm;
//---------------------------------------------------------------------------
__fastcall TResamplingForm::TResamplingForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TResamplingForm::SizeBarChange(TObject *Sender)
{
     int size = SizeBar->Position;
     RndSizeEdit->Text = IntToStr(size);    
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::ResetBtnClick(TObject *Sender)
{
     SizeBar->Position = 100;
     RndSizeEdit->Text = 100;
     PlotChk->Checked = false;
     PrintChk->Checked = false;
     SelVarEdit->Text = "";
     VarList->Clear();
     if (ops.format == 0)CIEdit->Text = "0.95";
     else CIEdit->Text = "0,05";
     ParMeanEdit->Text = "";
     ParSEEdit->Text = "";
     LowCIEdit->Text = "";
     HiCIEdit->Text = "";
     ReMeanEdit->Text = "";
     ReSEEdit->Text = "";
     ReLowCIEdit->Text = "";
     ReHiCIEdit->Text = "";
     BSMeanEdit->Text = "";
     BSSEEdit->Text = "";
     BSLowCIEdit->Text = "";
     BSHiCIEdit->Text = "";
     InBtn->Visible = true;
     OutBtn->Visible = false;
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::InBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index >= 0)
     {
        SelVarEdit->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        OutBtn->Visible = true;
        InBtn->Visible = false;
     }
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::OutBtnClick(TObject *Sender)
{
     if (SelVarEdit->Text != "")
     {
        VarList->Items->Add(SelVarEdit->Text);
        SelVarEdit->Text = "";
        InBtn->Visible = true;
        OutBtn->Visible = false;
     }
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::OKBtnClick(TObject *Sender)
{
     double *Sample;      // original sample data
     double *ResampMeans; // means from resampling
     double *Population;  // bootstrap population values
     double mean, variance, stddev, semean, lowci, hici; // traditional values
     double ReMean, ReSE, ReLow, ReHi; // results for resampling
     double BsMean, BsSe, BsLow, BsHi; // results for bootstrap
     double value, alpha, z, temp;       // work values
     double confint = StrToFloat(CIEdit->Text);
     int col, rndint, prob; // minrnd,maxrnd;
     int size = StrToInt(RndSizeEdit->Text);
     char outline[201];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     // allocate storage for arrays
     try
     {
        Sample = new double[NoCases];
        ResampMeans = new double[size];
        Population = new double[size];
    }
    catch (...)
    {
             ShowMessage("Memory allocation error");
             return;
    }
        

//-----------------------------------------------------------------------
     // do traditional
     mean = 0.0;
     variance = 0.0;
     for (int i = 0; i <= NoVariables; i++)
         if (MainForm->Grid->Cells[i][0] == SelVarEdit->Text) col = i;
     //result = VarTypeChk(col,0);
     //if (result == 1)
     //{
     //   delete[] Population;
     //   delete[] ResampMeans;
     //   delete[] Sample;
     //   return;
     //}
     for (int i = 1; i <= NoCases; i++)
     {
         value = StrToFloat(MainForm->Grid->Cells[col][i]);
         //result = GetValue(i,col,intvalue,dblvalue,strvalue);
         //if (result == 1) value = 0.0;
         //else value = dblvalue;
         Sample[i-1] = value;
         mean += value;
         variance += (value * value);
     }
     variance = variance - (mean * mean) / NoCases;
     variance = variance / (NoCases - 1);
     stddev = sqrt(variance);
     mean = mean / NoCases;
     semean = sqrt(variance / NoCases);
     ParMeanEdit->Text = FloatToStr(mean);
     ParSEEdit->Text = FloatToStr(semean);
     alpha = (1.0 - confint) / 2.0;
     z = inversez(alpha);
     lowci = mean + (z * semean);
     hici = mean - (z * semean);
     LowCIEdit->Text = FloatToStr(lowci);
     HiCIEdit->Text = FloatToStr(hici);

     // print results if elected
     if (PrintChk->Checked)
     {
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("Results for Resampling and Bootstrap Demo");
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"File = %s with %d cases.",MainForm->FileNameEdit->Text.c_str(),NoCases);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Selected Confidence Interval = %5.3f (z = %8.3f)",confint,fabs(z));
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Traditional statistics:");
        FrmOutPut->RichOutPut->Lines->Add("    MEAN     STD. DEV.  SE MEAN   CI LOW    CI HIGH");
        sprintf(outline,"%10.3f%10.3f%10.3f%10.3f%10.3f",mean,stddev,semean,lowci,hici);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
     }

//---------------------------------------------------------------------------
     //  do the resampling - randomly delete one observation and obtain means
     randomize();
     r250_521_init();

     for (int i = 0; i < size; i++)
     {
         mean = 0.0;
         for (int j = 0; j < NoCases-1; j++)
         {
             rndint = r250_521_random() % NoCases;
             mean += Sample[rndint];
         }
         ResampMeans[i] = mean / (double)(NoCases-1);
     }

     mean = 0.0;  // get mean of the means and std.error of means
     ReSE = 0.0;
     for (int i = 0; i < size; i++)
     {
         mean += ResampMeans[i];
         ReSE += (ResampMeans[i] * ResampMeans[i]);
     }
     ReSE = ReSE - (mean * mean) / (double)size;
     ReSE /= (double)(size - 1);
     ReSE = sqrt(ReSE);   // standard deviation of the sample means
     mean /= (double) size;
     ReMeanEdit->Text = FloatToStr(mean);
     ReSEEdit->Text = FloatToStr(ReSE);
     for (int i = 0; i < size-1; i++) // sort the means
     {
         for (int j = i+1; j < size; j++)
         {
             if (ResampMeans[i] > ResampMeans[j])
             {
                 temp = ResampMeans[i];
                 ResampMeans[i] = ResampMeans[j];
                 ResampMeans[j] = temp;
             }
         }
     }
     prob = alpha * size; // number in alpha regions
     lowci = ResampMeans[prob-1];
     hici = ResampMeans[size-prob-1];
     ReLowCIEdit->Text = FloatToStr(lowci);
     ReHiCIEdit->Text = FloatToStr(hici);

     // plot the means if elected
     if (PlotChk->Checked)PlotDist(size, ResampMeans, "Resample Means", this);

     // print results if elected
     if (PrintChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("Resampling statistics:");
        FrmOutPut->RichOutPut->Lines->Add("    MEAN     SE MEAN   CI LOW    CI HIGH");
        sprintf(outline,"%10.3f%10.3f%10.3f%10.3f",mean,ReSE,lowci,hici);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
     }


//-------------------------------------------------------------------------
     // do the bootstrap method - create population of size
     int nocopies = size / NoCases;
     int position = 0;
     for (int i = 0; i < nocopies; i++)
     {
         for (int j = 0; j < NoCases; j++)
         {
             Population[position] = Sample[j];
             position++;
         }
     }
     size = nocopies * NoCases;
     // draw size random samples of N = NoCases from population
     for (int i = 0; i < size; i++)
     {
         BsMean = 0.0;
         for (int j = 0; j < NoCases; j++)
         {
//             rndint = rand() % size;
             rndint = r250_521_random() % size;
             BsMean += Population[rndint];
         }
         BsMean = BsMean / (double)NoCases;
         ResampMeans[i] = BsMean;
     }
     // get mean of means and std. dev. of means
     BsMean = 0.0;
     BsSe = 0.0;
     for (int i = 0; i < size; i++)
     {
         BsMean += ResampMeans[i];
         BsSe += (ResampMeans[i] * ResampMeans[i]);
     }
     BsSe = BsSe - (BsMean * BsMean) / (double)size;
     BsSe /= (double)(size - 1);        // variance
     BsSe = sqrt(BsSe);                 // std.err. of mean
     BsMean /= (double)size;            // mean
     lowci = BsMean + (z * BsSe);
     hici = BsMean - (z * BsSe);
     BSMeanEdit->Text = FloatToStr(BsMean);
     BSSEEdit->Text = FloatToStr(BsSe);
     BSLowCIEdit->Text = FloatToStr(lowci);
     BSHiCIEdit->Text = FloatToStr(hici);

     // plot the means if elected
     if (PlotChk->Checked)PlotDist(size, ResampMeans, "Bootstrap Means", this);

     // print results if elected
     if (PrintChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("Bootstrap statistics:");
        FrmOutPut->RichOutPut->Lines->Add("    MEAN     SE MEAN   CI LOW    CI HIGH");
        sprintf(outline,"%10.3f%10.3f%10.3f%10.3f",BsMean,BsSe,lowci,hici);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
     }

     // clean up storage
     delete[] Population;
     delete[] ResampMeans;
     delete[] Sample;
}
//---------------------------------------------------------------------------

void __fastcall TResamplingForm::PlotDist(int size, double *y, char *title, TObject *Sender)
{
//   procedure to plot distributions of the resampling or bootstrap means

     double *freq;
     double *xvalue;
     double yincrement;
     int nints = 100;
     double minx,maxx,miny,maxy,yrange;

     // allocate memory
     if (size < 100) nints = size;
     freq = new double[nints];
     xvalue = new double[nints];

     // sort y scores into 100 bins
     miny = 1.0e32;
     maxy = 0.0;
     for (int i = 0; i < size; i++)
     {
         if (y[i] > maxy) maxy = y[i];
         if (y[i] < miny) miny = y[i];
     }
     yrange = maxy - miny;
     yincrement = yrange / nints;
     for (int i = 0;  i < nints; i++) freq[i] = 0.0;
     for (int i = 0; i < nints; i++)
     {
         for (int j = 0; j < size; j++)
         {
             if ( (y[j] >= miny + yincrement * i) && (y[j] < miny + yincrement * (i+1)) )
                freq[i]++;
         }
         xvalue[i] = miny + i * yincrement;
     }

     GetDblMatMem(GraphForm->Xpoints,1,nints+1);
     GetDblMatMem(GraphForm->Ypoints,1,nints+1);
     GraphForm->GraphType = 2; // vertical bars
     GraphForm->nosets = 1;
     GraphForm->nbars = nints;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlue;
     GraphForm->FloorColor = clGray;
     GraphForm->Heading = title;
     GraphForm->XTitle = "Category Values";
     GraphForm->YTitle = "Frequency";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = true;
     GraphForm->ShowLeftWall = true;
     GraphForm->ShowRightWall = true;
     GraphForm->ShowBottomWall = true;
     for (int k = 1; k <= nints+1; k++)
     {
            GraphForm->Ypoints[0][k-1] = freq[k-1];
            GraphForm->Xpoints[0][k-1] = xvalue[k-1];
     }
     GraphForm->ShowModal();

     ClearDblMatMem(GraphForm->Ypoints,1);
     ClearDblMatMem(GraphForm->Xpoints,1);
     delete[] xvalue;
     delete[] freq;
}
//---------------------------------------------------------------------------

