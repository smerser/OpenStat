//---------------------------------------------------------------------------
#ifndef HierarchH
#define HierarchH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmHier : public TForm
{
__published:	// IDE-managed Components
    TListBox *ListBox1;
    TListBox *ListBox2;
    TLabel *Label1;
    TLabel *Label2;
    TBitBtn *VarInBtn;
    TBitBtn *VarOutBtn;
    TButton *AllBtn;
    TButton *BtnReset;
    TButton *BtnCancel;
    TButton *BtnOk;
    TGroupBox *GroupBox1;
    TCheckBox *StdChkBox;
    TCheckBox *RepChkBox;
    TLabel *Label3;
    TEdit *MaxGrpsEdit;
    TCheckBox *DescChkBox;
    TCheckBox *PlotChkBox;
    TCheckBox *GridGroupsChk;
    TEdit *GrpNoEdit;
    TLabel *Label4;
    void __fastcall BtnCancelClick(TObject *Sender);
    void __fastcall BtnOkClick(TObject *Sender);
    void __fastcall VarInBtnClick(TObject *Sender);
    void __fastcall VarOutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall BtnResetClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmHier(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmHier *FrmHier;
//---------------------------------------------------------------------------
#endif
