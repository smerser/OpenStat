//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "OutPut.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "functions.h"
#include "AxBLogLinUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAxBLogLinForm *AxBLogLinForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TAxBLogLinForm::TAxBLogLinForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::ResetBtnClick(TObject *Sender)
{
     RowEdit->Text = "";
     ColEdit->Text = "";
     FreqEdit->Text = "";
     NoRowsEdit->Text = "";
     NoColsEdit->Text = "";
     for (int i = 0; i < Grid->RowCount; i++)
          for (int j = 0; j < Grid->ColCount; j++)
             Grid->Cells[j][i] = "";
     Grid->ColCount = 3;
     Grid->RowCount = 2;
     Grid->Cells[0][0] = "ROW";
     Grid->Cells[1][0] = "COL";
     Grid->Cells[2][0] = "FREQ";
     Panel1->Visible = true;
     Panel2->Visible = false;
     RowInBtn->Visible = true;
     RowOutBtn->Visible = false;
     ColInBtn->Visible = true;
     ColOutBtn->Visible = false;
     FreqInBtn->Visible = true;
     FreqOutBtn->Visible = false;
     InputGrp->ItemIndex = 0;
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::RowInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     RowEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RowInBtn->Visible = false;
     RowOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::RowOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(RowEdit->Text);
     RowEdit->Text = "";
     RowOutBtn->Visible = false;
     RowInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::ColInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     ColEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ColInBtn->Visible = false;
     ColOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::ColOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ColEdit->Text);
     ColEdit->Text = "";
     ColOutBtn->Visible = false;
     ColInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::FreqInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     FreqEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     FreqInBtn->Visible = false;
     FreqOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::FreqOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FreqEdit->Text);
     FreqEdit->Text = "";
     FreqOutBtn->Visible = false;
     FreqInBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::InputGrpClick(TObject *Sender)
{
     if (InputGrp->ItemIndex == 0)
     {
        Panel2->Visible = true;
        Panel1->Visible = false;
     }
     else
     {
         Panel2->Visible = false;
         Panel1->Visible = true;
     }
}
//---------------------------------------------------------------------------
void __fastcall TAxBLogLinForm::ComputeBtnClick(TObject *Sender)
{
     double **Data, **NewData, **Prop, **LogData, **Expected;
     int i, j, k, row, col, DF, Nrows, Ncols, RowCol, ColCol, Fcol, value;
     double *RowMarg, *NewRowMarg, *RowLogs, *ColMarg, *NewColMarg, *ColLogs;
     double ***CellLambdas;
     double Total, NewTotal, TotalLogs, mu, ModelTotal, Ysqr, chisqr, prob, odds, Fx;
     AnsiString astr;
     int *GridPos;
     char outline[121];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;
     
     Total = 0.0;
     TotalLogs = 0.0;
     Nrows = 0;
     Ncols = 0;

     if (InputGrp->ItemIndex == 0)  // MainForm input
     {
          GridPos = new int[3];
          for (i = 0; i < 3; i++) GridPos[i] = 0;
          for (i = 1; i <= NoVariables; i++)
          {
               if (RowEdit->Text == MainForm->Grid->Cells[i][0])  GridPos[0] = i;
               if (ColEdit->Text == MainForm->Grid->Cells[i][0])  GridPos[1] = i;
               if (FreqEdit->Text == MainForm->Grid->Cells[i][0])  GridPos[2] = i;
          }
          for (i = 0; i < 3; i++)
          {
                if (GridPos[i] == 0)
                {
                        ShowMessage("Row, Column or Frequency variable missing.");
                        delete[] GridPos;
                        return;
                }
                // if strong type checking desired, remove comments from below.
                //result = VarTypeChk(GridPos[i],1);
                //if (result == 1)
                //{
                //        delete[] GridPos;
                //        return;
                //}
          }
          // get no. of rows and columns
          for (i = 1; i < MainForm->Grid->RowCount; i++)
          {
               if (!ValidRecord(i,GridPos,3)) continue;
               value = floor(StrToFloat(MainForm->Grid->Cells[GridPos[0]][i]));
               //result = GetValue(i,GridPos[0],intvalue,dblvalue,strvalue);
               //if (result == 1) value = 0;
               //else value = intvalue;
               if (value > Nrows)  Nrows = value;
               value = floor(StrToFloat(MainForm->Grid->Cells[GridPos[1]][i]));
               //result = GetValue(i,GridPos[1],intvalue,dblvalue,strvalue);
               //if (result == 1) value = 0;
               //else value = intvalue;
               if (value > Ncols)  Ncols = value;
          }
          // Get data
          GetDblMatMem(Data,Nrows,Ncols);
          for (i = 0; i < Nrows; i++)
              for (j = 0; j < Ncols; j++)
                  Data[i][j] = 0.0;
          RowCol = GridPos[0];
          ColCol = GridPos[1];
          Fcol = GridPos[2];
          for (i = 1; i < MainForm->Grid->RowCount; i++)
          {
               if (! ValidRecord(i,GridPos,3)) continue;
               row = floor(StrToFloat(MainForm->Grid->Cells[RowCol][i]));
               col = floor(StrToFloat(MainForm->Grid->Cells[ColCol][i]));
               Fx = floor(StrToFloat(MainForm->Grid->Cells[Fcol][i]));
               //result = GetValue(i,Fcol,intvalue,dblvalue,strvalue);
               //if (result == 1) Fx = 0;
               //else Fx = intvalue;
               Data[row-1][col-1] = Data[row-1][col-1] + Fx;
               Total = Total + Fx;
          }
          delete[] GridPos;
     }

     if (InputGrp->ItemIndex == 1)  // form data
     {
          Nrows = floor(StrToFloat(NoRowsEdit->Text));
          Ncols = floor(StrToFloat(NoColsEdit->Text));
          GetDblMatMem(Data,Nrows,Ncols);
     }

     //  Allocate heap space
     GetDblCubeMem(CellLambdas,Nrows,Ncols,3);
     GetDblMatMem(Prop,Nrows,Ncols);
     GetDblMatMem(LogData,Nrows,Ncols);
     GetDblMatMem(Expected,Nrows,Ncols);
     GetDblMatMem(NewData,Nrows,Ncols);
     RowMarg = new double[Nrows];
     RowLogs = new double[Nrows];
     ColMarg = new double[Ncols];
     ColLogs = new double[Ncols];
     NewRowMarg = new double[Nrows];
     NewColMarg = new double[Ncols];

     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
              for (k = 0; k < 3; k++) CellLambdas[i][j][k] = 0.0;

     for (i = 0; i < Nrows; i++)
     {
          RowMarg[i] = 0.0;
          RowLogs[i] = 0.0;
          NewRowMarg[i] = 0.0;
     }

     for (j = 0; j < Ncols; j++)
     {
          ColMarg[j] = 0.0;
          ColLogs[j] = 0.0;
          NewColMarg[j] = 0.0;
     }

     if (InputGrp->ItemIndex == 1)  // get data from grid
     {
          for (i = 1; i <= (Nrows * Ncols); i++)
          {
               row = floor(StrToFloat(Grid->Cells[0][i]));
               col = floor(StrToFloat(Grid->Cells[1][i]));
               Data[row-1][col-1] = StrToFloat(Grid->Cells[2][i]);
               Total = Total + Data[row-1][col-1];
          }
     }

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowMarg[i] = RowMarg[i] + Data[i][j];
               ColMarg[j] = ColMarg[j] + Data[i][j];
               Prop[i][j] = Prop[i][j] / Total;
               LogData[i][j] = log(Data[i][j]);
          }
     }

     // report cross-products odds and log odds ratios
     FrmOutPut->RichOutPut->Clear();
     astr = "ANALYSES FOR AN I BY J CLASSIFICATION TABLE";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Reference: G.J.G. Upton, The Analysis of Cross-tabulated Data, 1980";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     if ((Nrows == 2) && (Ncols == 2))
     {
          odds = (Data[0][0] * Data[1][1]) / (Data[0][1] * Data[1][0]);
          sprintf(outline,"Cross-Products Odds Ratio = %6.3f",odds);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Log odds of the cross-products ratio = %6.3f",log(odds));
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
     }
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowLogs[i] = RowLogs[i] + LogData[i][j];
               ColLogs[j] = ColLogs[j] + LogData[i][j];
               TotalLogs = TotalLogs + LogData[i][j];
          }
     }

     for (i = 0; i < Nrows; i++) RowLogs[i] = RowLogs[i] / Ncols;
     for (j = 0; j < Ncols; j++) ColLogs[j] = ColLogs[j] / Nrows;
     TotalLogs = TotalLogs / (Nrows * Ncols);
     mu = TotalLogs;

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               CellLambdas[i][j][0] = RowLogs[i] - TotalLogs;
               CellLambdas[i][j][1] = ColLogs[j] - TotalLogs;
               CellLambdas[i][j][2] = LogData[i][j] - RowLogs[i]  - ColLogs[j] + TotalLogs;
          }
     }

     // Get expected values for saturated model
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               ModelTotal = mu;
               for (k = 0; k < 3; k++)
                    ModelTotal = ModelTotal + CellLambdas[i][j][k];
               Expected[i][j] = exp(ModelTotal);
          }
     }

     // Get Y square for saturated model
     Ysqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Ysqr = Ysqr + Data[i][j] * (log(Data[i][j]) - log(Expected[i][j]));
     Ysqr = 2.0 * Ysqr;

     // write out values for saturated model
     astr = "Saturated Model Results";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Observed Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,Data,RowMarg,ColMarg,Total);
     astr = "Log frequencies, row average and column average of log frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,LogData,RowLogs,ColLogs,TotalLogs);
     astr = "Expected Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,Expected,RowMarg,ColMarg,Total);
     astr = "Cell Parameters";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintLamdas(Nrows,Ncols,CellLambdas, mu);
     sprintf(outline,"Y squared statistic for model fit = %6.3f",Ysqr);
     astr = outline;
     astr = astr + " D.F. = 0";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     //the model of independence
     astr = "Independent Effects Model Results";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     astr = "Expected Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     Iterate(Nrows,Ncols,Data,RowMarg,ColMarg,Total,Expected,NewRowMarg,NewColMarg,NewTotal);
     PrintTable(Nrows,Ncols,Expected,NewRowMarg,NewColMarg,NewTotal);
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
               LogData[i][j] = log(Expected[i][j]);
     for (i = 0; i < Nrows; i++) RowLogs[i] = 0.0;
     for (j = 0; j < Ncols; j++) ColLogs[j] = 0.0;
     TotalLogs = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowLogs[i] = RowLogs[i] + LogData[i][j];
               ColLogs[j] = ColLogs[j] + LogData[i][j];
               TotalLogs = TotalLogs + LogData[i][j];
          }
     }

     for (i = 0; i < Nrows; i++) RowLogs[i] = RowLogs[i] / Ncols;
     for (j = 0; j < Ncols; j++) ColLogs[j] = ColLogs[j] / Nrows;
     TotalLogs = TotalLogs / (Nrows * Ncols);
     mu = TotalLogs;

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               CellLambdas[i][j][0] = RowLogs[i] - TotalLogs;
               CellLambdas[i][j][1] = ColLogs[j] - TotalLogs;
               CellLambdas[i][j][2] = LogData[i][j] - RowLogs[i]  - ColLogs[j] + TotalLogs;
          }
     }
     astr = "Cell Parameters";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintLamdas(Nrows,Ncols,CellLambdas,mu);
     Ysqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Ysqr = Ysqr + Data[i][j] * (log(Data[i][j]) - log(Expected[i][j]));
     Ysqr = 2.0 * Ysqr;
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Y squared statistic for model fit = %6.3f",Ysqr);
     astr = outline;
     DF = (Nrows - 1) * (Ncols - 1);
     astr = astr + " D.F. = " + IntToStr(DF);
     FrmOutPut->RichOutPut->Lines->Add(astr);
     chisqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             chisqr = chisqr + (pow((Data[i][j] - Expected[i][j]),2) / Expected[i][j]);
     sprintf(outline,"Chi-squared = %6.3f with %d D.F.",chisqr,DF);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     //no Column Effects model
     astr = "No Column Effects Model Results";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
    for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Expected[i][j] = RowMarg[i] / Ncols;
     for (i = 0; i < Nrows; i++) NewRowMarg[i] = 0.0;
     for (j = 0; j < Ncols; j++) NewColMarg[j] = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               NewRowMarg[i] = NewRowMarg[i] + Expected[i][j];
               NewColMarg[j] = NewColMarg[j] + Expected[i][j];
          }
     }
     astr = "Expected Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,Expected,NewRowMarg,NewColMarg,NewTotal);
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
               LogData[i][j] = log(Expected[i][j]);
     for (i = 0; i < Nrows; i++) RowLogs[i] = 0.0;
     for (j = 0; j < Ncols; j++) ColLogs[j] = 0.0;
     TotalLogs = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowLogs[i] = RowLogs[i] + LogData[i][j];
               ColLogs[j] = ColLogs[j] + LogData[i][j];
               TotalLogs = TotalLogs + LogData[i][j];
          }
     }

     for (i = 0; i < Nrows; i++) RowLogs[i] = RowLogs[i] / Ncols;
     for (j = 0; j < Ncols; j++) ColLogs[j] = ColLogs[j] / Nrows;
     TotalLogs = TotalLogs / (Nrows * Ncols);
     mu = TotalLogs;

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               CellLambdas[i][j][0] = RowLogs[i] - TotalLogs;
               CellLambdas[i][j][1] = ColLogs[j] - TotalLogs;
               CellLambdas[i][j][2] = LogData[i][j] - RowLogs[i]  - ColLogs[j] + TotalLogs;
          }
     }
     astr = "Cell Parameters";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintLamdas(Nrows,Ncols,CellLambdas,mu);
     Ysqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Ysqr = Ysqr + Data[i][j] * (log(Data[i][j]) - log(Expected[i][j]));
     Ysqr = 2.0 * Ysqr;
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Y squared statistic for model fit = %6.3f",Ysqr);
     astr = outline;
     DF = (Nrows - 1) * Ncols;
     astr = astr + " D.F. = " + IntToStr(DF);
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     //no Row Effects model
     astr = "No Row Effects Model Results";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Expected[i][j] = ColMarg[j] / Nrows;
     for (i = 0; i < Nrows; i++) NewRowMarg[i] = 0.0;
     for (j = 0; j < Ncols; j++) NewColMarg[j] = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               NewRowMarg[i] = NewRowMarg[i] + Expected[i][j];
               NewColMarg[j] = NewColMarg[j] + Expected[i][j];
          }
     }
     astr = "Expected Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,Expected,NewRowMarg,NewColMarg,NewTotal);
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
               LogData[i][j] = log(Expected[i][j]);
     for (i = 0; i < Nrows; i++) RowLogs[i] = 0.0;
     for (j = 0; j < Ncols; j++) ColLogs[j] = 0.0;
     TotalLogs = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowLogs[i] = RowLogs[i] + LogData[i][j];
               ColLogs[j] = ColLogs[j] + LogData[i][j];
               TotalLogs = TotalLogs + LogData[i][j];
          }
     }

     for (i = 0; i < Nrows; i++) RowLogs[i] = RowLogs[i] / Ncols;
     for (j = 0; j < Ncols; j++) ColLogs[j] = ColLogs[j] / Nrows;
     TotalLogs = TotalLogs / (Nrows * Ncols);
     mu = TotalLogs;

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               CellLambdas[i][j][0] = RowLogs[i] - TotalLogs;
               CellLambdas[i][j][1] = ColLogs[j] - TotalLogs;
               CellLambdas[i][j][2] = LogData[i][j] - RowLogs[i]  - ColLogs[j] + TotalLogs;
          }
     }
     astr = "Cell Parameters";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintLamdas(Nrows,Ncols,CellLambdas,mu);
     Ysqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Ysqr = Ysqr + Data[i][j] * (log(Data[i][j]) - log(Expected[i][j]));
     Ysqr = 2.0 * Ysqr;
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Y squared statistic for model fit = %6.3f",Ysqr);
     astr = outline;
     astr = astr + " D.F. = " + IntToStr(DF);
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     //equiprobability model
     astr = "Equiprobability Effects Model Results";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Expected[i][j] = Total / (Nrows * Ncols);
     for (i = 0; i < Nrows; i++) NewRowMarg[i] = Total / (Nrows * Ncols);
     for (j = 0; j < 2; j++) NewColMarg[j] = Total / (Nrows * Ncols);
     astr = "Expected Frequencies";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintTable(Nrows,Ncols,Expected,NewRowMarg,NewColMarg,NewTotal);
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
               LogData[i][j] = log(Expected[i][j]);
     for (i = 0; i < Nrows; i++) RowLogs[i] = 0.0;
     for (j = 0; j < Ncols; j++) ColLogs[j] = 0.0;
     TotalLogs = 0.0;
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               RowLogs[i] = RowLogs[i] + LogData[i][j];
               ColLogs[j] = ColLogs[j] + LogData[i][j];
               TotalLogs = TotalLogs + LogData[i][j];
          }
     }

     for (i = 0; i < Nrows; i++) RowLogs[i] = RowLogs[i] / Ncols;
     for (j = 0; j < Ncols; j++) ColLogs[j] = ColLogs[j] / Nrows;
     TotalLogs = TotalLogs / (Nrows * Ncols);
     mu = TotalLogs;

     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               CellLambdas[i][j][0] = RowLogs[i] - TotalLogs;
               CellLambdas[i][j][1] = ColLogs[j] - TotalLogs;
               CellLambdas[i][j][2] = LogData[i][j] - RowLogs[i]  - ColLogs[j] + TotalLogs;
          }
     }
     astr = "Cell Parameters";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     PrintLamdas(Nrows,Ncols,CellLambdas,mu);
     Ysqr = 0.0;
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             Ysqr = Ysqr + Data[i][j] * (log(Data[i][j]) - log(Expected[i][j]));
     Ysqr = 2.0 * Ysqr;
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Y squared statistic for model fit = %6.3f",Ysqr);
     astr = outline;
     DF = Nrows * Ncols - 1;
     astr = astr + " D.F. = " + IntToStr(DF);
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     // cleanup the heap
     delete[] NewColMarg;
     delete[] NewRowMarg;
     delete[] ColLogs;
     delete[] ColMarg;
     delete[] RowLogs;
     delete[] RowMarg;
     ClearDblMatMem(NewData,Nrows);
     ClearDblMatMem(Expected,Nrows);
     ClearDblMatMem(LogData,Nrows);
     ClearDblMatMem(Prop,Nrows);
     ClearDblCubeMem(CellLambdas,Nrows,Ncols);
     ClearDblMatMem(Data,Nrows);
}
//-------------------------------------------------------------------

void __fastcall TAxBLogLinForm::PrintTable(int Nrows, int Ncols,
                                    double **Data,
                                    double *RowMarg,
                                    double *ColMarg,
                                    double Total)
{
     AnsiString astr;
     char outline[121];
     int i, j;

     astr = "ROW/COL   ";
     for (j = 0; j < Ncols; j++)
     {
         sprintf(outline,"   %3d    ",j+1);
         astr = astr + outline;
     }
     astr = astr + "  TOTAL";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     for (i = 0; i < Nrows; i++)
     {
          sprintf(outline,"   %3d    ",i+1);
          astr = outline;
          for (j = 0; j < Ncols; j++)
          {
               sprintf(outline," %8.2f ",Data[i][j]);
               astr = astr + outline;
          }
          sprintf(outline," %8.2f ",RowMarg[i]);
          astr = astr + outline;
          FrmOutPut->RichOutPut->Lines->Add(astr);
     }
     astr = "TOTAL     ";
     for (j = 0; j < Ncols; j++)
     {
         sprintf(outline," %8.2f ",ColMarg[j]);
         astr = astr + outline;
     }
     sprintf(outline," %8.2f ",Total);
     astr = astr + outline;
     FrmOutPut->RichOutPut->Lines->Add(astr);
     FrmOutPut->RichOutPut->Lines->Add("");
}
//-------------------------------------------------------------------

void __fastcall TAxBLogLinForm::Iterate(int Nrows, int Ncols,
                                 double **Data,
                                 double *RowMarg,
                                 double *ColMarg,
                                 double &Total,
                                 double **expected,
                                 double *newrowmarg,
                                 double *newcolmarg,
                                 double &newtotal)
{
     double **previous;
     int i, j;
     double delta, difference;

     delta = 0.1;
     difference = 0.0;
     GetDblMatMem(previous,Nrows,Ncols);

     // initialize expected values
     for (i = 0; i < Nrows; i++)
     {
         for (j = 0; j < Ncols; j++)
         {
             expected[i][j] = 1.0;
             previous[i][j] = 1.0;
         }
     }

Step:
     // step 1: initialize new row margins and calculate expected value
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
              newrowmarg[i] = newrowmarg[i] + expected[i][j];
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             expected[i][j] = (RowMarg[i] / newrowmarg[i]) * expected[i][j];
     // step 2: initialize new col margins and calculate expected values
     for (i = 0; i < Nrows; i++)
          for (j = 0; j < Ncols; j++)
               newcolmarg[j] = newcolmarg[j] + expected[i][j];
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             expected[i][j] = (ColMarg[j] / newcolmarg[j]) * expected[i][j];

     // step 3: check for change and quit if smaller than delta
     for (i = 0; i < Nrows; i++)
         for (j = 0; j < Ncols; j++)
             if (fabs(previous[i][j]- expected[i][j]) > difference)
                difference = fabs(previous[i][j]-expected[i][j]);
     if (difference < delta)
     {
          newtotal = 0.0;
          for (i = 0; i < Nrows; i++)
              for (j = 0; j < Ncols; j++)
                  newtotal = newtotal + expected[i][j];
          ClearDblMatMem(previous,Nrows);
          return;
     }
     else
     {
          for (i = 0; i < Nrows; i++)
              for (j = 0; j < Ncols; j++)
                  previous[i][j] = expected[i][j];
          for (i = 0; i < Nrows; i++) newrowmarg[i] = 0.0;
          for (j = 0; j < Ncols; j++) newcolmarg[j] = 0.0;
          difference = 0.0;
          goto Step;
     }
}
//-------------------------------------------------------------------

void __fastcall TAxBLogLinForm::PrintLamdas(int Nrows, int Ncols,
                                     double ***CellLambdas,
                                     double mu)
{
     int i, j, k;
     AnsiString astr;
     char outline[121];

     astr = "ROW COL   MU      LAMBDA ROW   LAMBDA COL   LAMBDA ROW x COL";
     FrmOutPut->RichOutPut->Lines->Add(astr);
     for (i = 0; i < Nrows; i++)
     {
          for (j = 0; j < Ncols; j++)
          {
               sprintf(outline,"%3d %3d ",i+1,j+1);
               astr = outline;
               sprintf(outline,"%6.3f    ",mu);
               astr = astr + outline;
               for (k = 0; k < 3; k++)
               {
                    sprintf(outline," %6.3f      ",CellLambdas[i][j][k]);
                    astr = astr + outline;
               }
               FrmOutPut->RichOutPut->Lines->Add(astr);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
}
//-------------------------------------------------------------------


void __fastcall TAxBLogLinForm::NoColsEditKeyPress(TObject *Sender,
      char &Key)
{
     int i, j, row;
     int Ncols, Nrows;

     if (Key == 13)
     {
          Nrows = StrToInt(NoRowsEdit->Text);
          Ncols = StrToInt(NoColsEdit->Text);
          Grid->RowCount = (Nrows * Ncols) + 1;
          // setup row and column values in the grid
          row = 1;
          for (j = 0; j < Ncols; j++)
          {
               for (i = 0; i < Nrows; i++)
               {
                    Grid->Cells[0][row] = IntToStr(i+1);
                    Grid->Cells[1][row] = IntToStr(j+1);
                    row = row + 1;
               }
          }
          Grid->SetFocus();
     }
}
//---------------------------------------------------------------------------

void __fastcall TAxBLogLinForm::NoRowsEditKeyPress(TObject *Sender,
      char &Key)
{
      if (Key == 13) NoColsEdit->SetFocus();
}
//---------------------------------------------------------------------------

