//---------------------------------------------------------------------------

#ifndef CoxRegUnitH
#define CoxRegUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TCoxRegForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label3;
     TListBox *BlockList;
     TBitBtn *InBtn;
     TBitBtn *OutBtn;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TLabel *Label2;
     TLabel *Label4;
     TEdit *DepVar;
     TEdit *StatusEdit;
     TBitBtn *DepInBtn;
     TBitBtn *StatusInBtn;
     TBitBtn *DepOutBtn;
     TBitBtn *StatusOutBtn;
     TLabel *Label5;
     TEdit *MaxItsEdit;
     TGroupBox *GroupBox1;
     TCheckBox *DescChk;
     TCheckBox *ProbsChk;
     TCheckBox *ItersChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall InBtnClick(TObject *Sender);
     void __fastcall OutBtnClick(TObject *Sender);
     void __fastcall DepInBtnClick(TObject *Sender);
     void __fastcall DepOutBtnClick(TObject *Sender);
     void __fastcall StatusInBtnClick(TObject *Sender);
     void __fastcall StatusOutBtnClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
     double __fastcall ChiSq(double x, int n);
     double __fastcall Norm(double z);
     int __fastcall ix(int j, int k, int nCols);
private:	// User declarations
public:		// User declarations
     __fastcall TCoxRegForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCoxRegForm *CoxRegForm;
//---------------------------------------------------------------------------
#endif
