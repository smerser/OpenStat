//---------------------------------------------------------------------------

#ifndef AutoCorUnitH
#define AutoCorUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TAutoCorFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TEdit *DepVarEdit;
    TLabel *Label3;
    TEdit *MaxLagEdit;
    TGroupBox *GroupBox1;
    TCheckBox *PlotCorsChk;
    TCheckBox *PrtPartialsChk;
    TCheckBox *PrtCorsChk;
    TCheckBox *YuleWalkerChk;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ResetBtn;
    TButton *ReturnBtn;
    TLabel *Label4;
    TEdit *ConfidenceEdit;
    TGroupBox *GroupBox2;
    TCheckBox *MeanOutChk;
    TCheckBox *MoveAvgChk;
    TCheckBox *ExpSmoothChk;
    TCheckBox *FourierSmoothChk;
    TCheckBox *ResidPlotChk;
    TCheckBox *DifferenceChk;
    TCheckBox *PolyChk;
    TGroupBox *GroupBox3;
    TRadioButton *ColBtn;
    TRadioButton *RowBtn;
    TGroupBox *GroupBox4;
    TRadioButton *AllCasesBtn;
    TRadioButton *SomeCasesBtn;
    TLabel *Label5;
    TEdit *FromCasesEdit;
    TLabel *Label6;
    TEdit *ToCasesEdit;
    TCheckBox *ProjectChk;
    TEdit *ProjPtsEdit;
    TLabel *Label7;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall VarListClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall RowBtnClick(TObject *Sender);
    void __fastcall ColBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TAutoCorFrm(TComponent* Owner);
    void four1(double *data,unsigned long nn,int isign);
    void realft(double *data,unsigned long n,int isign);
    void fourier(double *data,int n, int pts);
    void TAutoCorFrm::PolyFit(double *pts, double *avg, int NoPts);

};
//---------------------------------------------------------------------------
extern PACKAGE TAutoCorFrm *AutoCorFrm;
//---------------------------------------------------------------------------
#endif
