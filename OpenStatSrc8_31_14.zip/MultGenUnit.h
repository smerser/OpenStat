//---------------------------------------------------------------------------
#ifndef MultGenUnitH
#define MultGenUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TMultGenFrm : public TForm
{
__published:	// IDE-managed Components
    TStringGrid *Grid;
    TLabel *Label1;
    TEdit *NVarsEdit;
    TLabel *InstructLabel;
    TButton *ContBtn;
    TLabel *ObsNoLabel;
    TEdit *NoObsEdit;
    TLabel *DoneInstruct;
    TButton *DoneBtn;
    TButton *CancelBtn;
    void __fastcall NVarsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall DoneBtnClick(TObject *Sender);
    void __fastcall ContBtnClick(TObject *Sender);
    void __fastcall NoObsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall GridSetEditText(TObject *Sender, int ACol, int ARow,
          const AnsiString Value);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
   int NoVars;
   int NoObs;
   double *v;
   double **rmatrix;
   double **d;

public:		// User declarations
    __fastcall TMultGenFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMultGenFrm *MultGenFrm;
//---------------------------------------------------------------------------
#endif
