//---------------------------------------------------------------------------

#ifndef MovAvgUnitH
#define MovAvgUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TMoveAvgFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *OrderEdit;
    TLabel *ThetaLabel;
    TEdit *ThetaEdit;
    TListBox *ThetaList;
    TButton *CancelBtn;
    TButton *Apply;
    TButton *OKBtn;
    TMemo *Memo1;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall OrderEditChange(TObject *Sender);
    void __fastcall ThetaListClick(TObject *Sender);
    void __fastcall ThetaEditKeyPress(TObject *Sender, char &Key);
    void __fastcall ApplyClick(TObject *Sender);
    void __fastcall ThetaEditExit(TObject *Sender);
private:	// User declarations
    int currenttheta;

public:		// User declarations
    __fastcall TMoveAvgFrm(TComponent* Owner);
    int order;
    double W[100];
};
//---------------------------------------------------------------------------
extern PACKAGE TMoveAvgFrm *MoveAvgFrm;
//---------------------------------------------------------------------------
#endif
