//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "PMCorrUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "OutPut.h"
#include "math.h"
#include "functions.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPMCorrForm *PMCorrForm;
extern int NoCases;
extern int NoVariables;
//extern struct VarDef *vdef[1000];
//extern int FileType;
//---------------------------------------------------------------------------
__fastcall TPMCorrForm::TPMCorrForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     SaveChk->Checked = false;
     PairWiseChk->Checked = false;
     CrossProdChk->Checked = false;
     CovarChk->Checked = false;
     DescChk->Checked = false;
     CorrsChk->Checked = true;
}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}

//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::OutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     if (index >= 0)
     {
        VarList->Items->Add(SelList->Items->Strings[index]);
        SelList->Items->Delete(index);
     }
     InBtn->Enabled = true;
     if (VarList->Items->Count == 0) OutBtn->Enabled = false;

}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::BitBtn3Click(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     if (index < 0) return;
     i = 0;
     while (i < index)
     {
           SelList->Items->Add(VarList->Items->Strings[i]);
           VarList->Items->Delete(i);
           index--;
     }
}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::ComputeBtnClick(TObject *Sender)
{
     double *Means, *Variances, *StdDevs, **corrmat, **tMatrix, **ProbMat;
	  double X, Y, sumx, sumy;
     double XMean, XVar, XSD, YMean, YVar, YSD, pmcorr, z, rprob;
     int *ColSelected, NoSelected, colx, coly, PrtOpts = 1;
     int mattype, Npairs, N;
     int **CorCases;
     bool Augment = false;
     AnsiString cellstring;
     AnsiString *RowLabels;
     char outstring[101];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     NoSelected = SelList->Items->Count;
     if (NoSelected < 2) return;
     ColSelected = new int[NoSelected+1];
     RowLabels = new AnsiString[NoSelected+1];
     Means = new double[NoSelected+1];
     Variances = new double[NoSelected+1];
     StdDevs = new double[NoSelected+1];
     GetDblMatMem(corrmat,NoSelected+1,NoSelected+1);
     GetIntMatMem(CorCases,NoSelected+1,NoSelected+1);
     GetDblMatMem(tMatrix,NoSelected+1,NoSelected+1);
     GetDblMatMem(ProbMat,NoSelected+1,NoSelected+1);

     if (AugmentChk->Checked) Augment = true;

     for (int i = 0; i < NoSelected; i++)
     {
         cellstring = SelList->Items->Strings[i];
         for (int j = 0; j < NoVariables; j++)
         {
             if (cellstring == MainForm->Grid->Cells[j+1][0])
             {
             	ColSelected[i] = j+1;
                //result = VarTypeChk(j+1,0);
                //if (result == 1) goto cleanup;
                RowLabels[i] = MainForm->Grid->Cells[j+1][0];
             }
         }
     }

     for (int i = 0; i < NoSelected+1; i++)
     {
         Means[i] = 0.0;
         Variances[i] = 0.0;
         StdDevs[i] = 0.0;
         for (int j = 0; j < NoSelected+1; j++)
         {
                corrmat[i][j] = 0.0;
                tMatrix[i][j] = 0.0;
                ProbMat[i][j] = 0.0;
                CorCases[i][j] = 0;
         }
     }

     // do pairwise computation if elected
     if (PairWiseChk->Checked)
     {
         for (int j = 0; j < NoSelected-1; j++)
         {
         	for (int k = j + 1; k < NoSelected; k++)
            {
               XMean = 0.0;
               YMean = 0.0;
               XVar = 0.0;
               YVar = 0.0;
//               XSD = 0.0;
//               YSD = 0.0;
               pmcorr = 0.0;
               Npairs = 0;
               colx = ColSelected[j];
               coly = ColSelected[k];
               sprintf(outstring,"%s vs %s",RowLabels[j],RowLabels[k]);
               FrmOutPut->RichOutPut->Lines->Add(outstring);
               for (int i = 0; i < NoCases; i++)
               {
                  if (!ValidRecord(i+1,ColSelected,NoSelected)) continue;
                  if (! ValidValue(i+1,colx)) continue;
               	  if (! ValidValue(i+1,coly)) continue;
               	  X = StrToFloat(MainForm->Grid->Cells[colx][i+1]);
                  //result = GetValue(i+1,colx,intvalue,dblvalue,strvalue);
                  //if (result == 1) X = 0.0;
                  //else X = dblvalue;
               	  Y = StrToFloat(MainForm->Grid->Cells[coly][i+1]);
                  //result = GetValue(i+1,coly,intvalue,dblvalue,strvalue);
                  //if (result == 1) Y = 0.0;
                  //else Y = dblvalue;
                  pmcorr += (X * Y);
               	  XMean += X;
                  YMean += Y;
                  XVar += (X * X);
                  YVar += (Y * Y);
               	  Npairs += 1;
               }
               if (CrossProdChk->Checked)
               {
               	  sprintf(outstring,"CrossProducts[%d][%d] = %6.4f, N Cases = %d",
                          j+1,k+1,pmcorr,Npairs);
                  FrmOutPut->RichOutPut->Lines->Add(outstring);
               }
               if (Npairs > 1)
               {
                  pmcorr -= (XMean * YMean / Npairs);
                  pmcorr /= (Npairs-1);
                  if (CovarChk->Checked)
                  {
               	     sprintf(outstring,"Covariance[%d][%d] = %6.4f, N Cases = %d",
                          j+1,k+1,pmcorr,Npairs);
                     FrmOutPut->RichOutPut->Lines->Add(outstring);
                  }
                  XVar -= (XMean * XMean / Npairs);
                  XVar /= (Npairs - 1);
                  YVar -= (YMean * YMean / Npairs);
                  YVar /= (Npairs - 1);
                  XSD = sqrt(XVar);
                  YSD = sqrt(YVar);
                  XMean /= Npairs;
                  YMean /= Npairs;
                  pmcorr /= (XSD * YSD);
                  corrmat[j][k] = pmcorr;
                  corrmat[k][j] = pmcorr;
                  CorCases[j][k] = Npairs;
                  CorCases[k][j] = Npairs;
                  N = Npairs - 2;
                  if ((N > 0) && (pmcorr < 1.0))
                  {
                     z = fabs(pmcorr) * (sqrt((N)/(1.0 - (pmcorr * pmcorr))));
                     rprob = tprob(z,N);
                  }
                  else
                  {
                      z = 999.9;
                      rprob = 0.0;
                  }
                  sprintf(outstring,"Correlation[%d][%d] = %6.4f, N Cases = %d",
                          j+1,k+1,pmcorr,Npairs);
                  FrmOutPut->RichOutPut->Lines->Add(outstring);
                  sprintf(outstring,"t value with %d degrees of freedom = %8.4f with prob. > t = %6.4f",
                      N,z,rprob);
                  FrmOutPut->RichOutPut->Lines->Add(outstring);
                  tMatrix[j][k] = z;
                  tMatrix[k][j] = z;
                  ProbMat[j][k] = rprob;
                  ProbMat[k][j] = rprob;
                  if (DescChk->Checked)
                  {
               	     sprintf(outstring,"X Mean = %8.4f, Variance = %8.4f, Standard Deviation = %8.4f",
                                 XMean, XVar, XSD);
                     FrmOutPut->RichOutPut->Lines->Add(outstring);
               	     sprintf(outstring,"Y Mean = %8.4f, Variance = %8.4f, Standard Deviation = %8.4f",
                                 YMean, YVar, YSD);
                     FrmOutPut->RichOutPut->Lines->Add(outstring);
                  }
                  FrmOutPut->RichOutPut->Lines->Add("");
               } // end if Npairs > 1
               else
               {
                  corrmat[j][k] = 999.9;
                  corrmat[k][j] = 999.9;
                  CorCases[j][k] = Npairs;
                  CorCases[k][j] = Npairs;
               }
            } // next k variable
            corrmat[j][j] = 1.0;
         } // next j variable
         MatPrint(corrmat,NoSelected,NoSelected,ColSelected,"CORRELATION MATRIX");
         MatPrint(tMatrix,NoSelected,NoSelected,ColSelected,"t-test Values for prob. |corr.| > 0 test");
         MatPrint(ProbMat,NoSelected,NoSelected,ColSelected,"Probability of greater t");
         FrmOutPut->RichOutPut->Lines->Add("");
         IntArrayPrint(CorCases, NoSelected, NoSelected, "VARIABLES",
                   RowLabels, RowLabels, "No. of Cases Per Cell");
         FrmOutPut->ShowModal();
     } // end if pairwise

     else // full matrix with list-wise deletion
     {
         N =  NoCases;
         if (CrossProdChk->Checked)
         {
            mattype = 1;
         	if (! DescChk->Checked) PrtOpts = 2;
            Correlations(Means,StdDevs,corrmat,NoSelected,ColSelected,N,mattype,
                Augment, PrtOpts);
            FrmOutPut->ShowModal();
            FrmOutPut->RichOutPut->Clear();
         }
         N = NoCases;
         if (CovarChk->Checked)
         {
            mattype = 2;
         	if (! DescChk->Checked) PrtOpts = 2;
            Correlations(Means,StdDevs,corrmat,NoSelected,ColSelected,N,mattype,
                Augment, PrtOpts);
            FrmOutPut->ShowModal();
            FrmOutPut->RichOutPut->Clear();
         }
         N = NoCases;
         mattype = 3;
         if (CorrsChk->Checked)
         {
         	if (! DescChk->Checked) PrtOpts = 2;
         	Correlations(Means,StdDevs,corrmat,NoSelected,ColSelected,N,mattype,
            	Augment, PrtOpts);
            N = N - 2;
            for (int i = 0; i < NoSelected-1; i++)
            {
            	for (int j = i + 1; j  < NoSelected; j++)
               {
                  pmcorr = corrmat[i][j];
                  if ((N > 0) && (pmcorr < 1.0))
                  {
                     z = fabs(pmcorr) * (sqrt((N)/(1.0 - (pmcorr * pmcorr))));
                     rprob = tprob(z,N);
               	     tMatrix[i][j] = z;
               	     tMatrix[j][i] = z;
               	     ProbMat[i][j] = rprob;
               	     ProbMat[j][i] = rprob;
                  }
                  else
                  {
                      z = 999.9;
                      tMatrix[i][j] = z;
                      tMatrix[j][i] = z;
                      ProbMat[i][j] = 0.0;
                      ProbMat[j][i] = 0.0;
                  }
               }
            }
         	MatPrint(tMatrix,NoSelected,NoSelected,ColSelected,"t-test Values for prob. |corr.| > 0 test");
         	MatPrint(ProbMat,NoSelected,NoSelected,ColSelected,"Probability of greater t");
            FrmOutPut->ShowModal();
         }
	 }
        if (SaveChk->Checked) SaveSqrMat(corrmat, NoSelected, N, RowLabels, Means, StdDevs);
     if (SaveChk->Checked)
     {
     	 CloseFile();
         MainForm->Grid->RowCount = NoSelected + 1;
         MainForm->Grid->ColCount = NoSelected + 1;
         for (int i = 0; i < NoSelected; i++)
         {
            MainForm->Grid->Cells[i+1][0] = RowLabels[i];
            MainForm->Grid->Cells[0][i+1] = RowLabels[i];
            NewVar(i+1,true);
         }
         for (int i = 0; i < NoSelected; i++)
         	for (int j = 0; j < NoSelected; j++)
            	MainForm->Grid->Cells[i+1][j+1] = FloatToStr(corrmat[i][j]);
/*
         SaveDialog1->Filter = "Matrix files (*.mat)|*.MAT|All files (*.*)|*.*";
         SaveDialog1->FilterIndex = 1;
         if (SaveDialog1->Execute())
         {
            char FileName[131];
//            FileType = 7; // matrix file
            strcpy(FileName,SaveDialog1->FileName.c_str());
            SaveMatrixFile(FileName);
         }
*/
    }
cleanup:
    ClearDblMatMem(ProbMat,NoSelected+1);
    ClearDblMatMem(tMatrix,NoSelected+1);
    ClearIntMatMem(CorCases,NoSelected+1);
    ClearDblMatMem(corrmat,NoSelected+1);
    delete[] StdDevs;
    delete[] Variances;
    delete[] Means;
    delete[] RowLabels;
    delete[] ColSelected;
}
//---------------------------------------------------------------------------
void __fastcall TPMCorrForm::PairWiseChkClick(TObject *Sender)
{
	if (!CorrsChk->Checked) CorrsChk->Checked = true;	
}
//---------------------------------------------------------------------------

