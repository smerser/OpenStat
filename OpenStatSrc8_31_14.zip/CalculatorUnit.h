//---------------------------------------------------------------------------

#ifndef CalculatorUnitH
#define CalculatorUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TCalculatorForm : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TBitBtn *Btn7;
        TBitBtn *Btn8;
        TBitBtn *Btn9;
        TBitBtn *Btn4;
        TBitBtn *Btn5;
        TBitBtn *Btn6;
        TBitBtn *Btn1;
        TBitBtn *Btn2;
        TBitBtn *Btn3;
        TBitBtn *Btn0;
        TBitBtn *BtnMemIn;
        TBitBtn *BtnMemOut;
        TBitBtn *BtnChangeSign;
        TBitBtn *BtnPlus;
        TBitBtn *BtnMinus;
        TBitBtn *BtnTimes;
        TBitBtn *BtnDivide;
        TBitBtn *BtnEqual;
        TBitBtn *BtnSqrt;
        TBitBtn *BtnNatLog;
        TBitBtn *BtnLog10;
        TBitBtn *BtnExp;
        TBitBtn *BtnExpBase10;
        TBitBtn *BtnSin;
        TBitBtn *BtnCos;
        TBitBtn *BtnArcSin;
        TBitBtn *BtnArcCos;
        TBitBtn *BtnArcTan;
        TBitBtn *BtnRecip;
        TBitBtn *BtnClear;
        TBitBtn *BtnTan;
        TBitBtn *BtnReturn;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *ResultEdit;
        TEdit *MemoryEdit;
        TLabel *Label3;
        TEdit *ValueEdit;
        TBitBtn *BtnPeriod;
        TBitBtn *BtnPi;
        TBitBtn *Btne;
        TBitBtn *BtnSquare;
        TBitBtn *BtnClrVal;
        TBitBtn *BtnClrRes;
        TBitBtn *BtnPow;
        TBitBtn *BtnRadDeg;
        TBitBtn *BtnCSC;
        TBitBtn *BtnSEC;
        TBitBtn *BtnCOT;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Btn7Click(TObject *Sender);
        void __fastcall Btn8Click(TObject *Sender);
        void __fastcall Btn9Click(TObject *Sender);
        void __fastcall Btn4Click(TObject *Sender);
        void __fastcall Btn5Click(TObject *Sender);
        void __fastcall Btn6Click(TObject *Sender);
        void __fastcall Btn1Click(TObject *Sender);
        void __fastcall Btn2Click(TObject *Sender);
        void __fastcall Btn3Click(TObject *Sender);
        void __fastcall Btn0Click(TObject *Sender);
        void __fastcall BtnPeriodClick(TObject *Sender);
        void __fastcall BtnMemInClick(TObject *Sender);
        void __fastcall BtnMemOutClick(TObject *Sender);
        void __fastcall BtnChangeSignClick(TObject *Sender);
        void __fastcall BtnPlusClick(TObject *Sender);
        void __fastcall BtnMinusClick(TObject *Sender);
        void __fastcall BtnTimesClick(TObject *Sender);
        void __fastcall BtnDivideClick(TObject *Sender);
        void __fastcall BtnSqrtClick(TObject *Sender);
        void __fastcall BtnTanClick(TObject *Sender);
        void __fastcall BtnNatLogClick(TObject *Sender);
        void __fastcall BtnArcSinClick(TObject *Sender);
        void __fastcall BtnLog10Click(TObject *Sender);
        void __fastcall BtnArcCosClick(TObject *Sender);
        void __fastcall BtnExpClick(TObject *Sender);
        void __fastcall BtnArcTanClick(TObject *Sender);
        void __fastcall BtnExpBase10Click(TObject *Sender);
        void __fastcall BtnRecipClick(TObject *Sender);
        void __fastcall BtnSinClick(TObject *Sender);
        void __fastcall BtnClearClick(TObject *Sender);
        void __fastcall BtnCosClick(TObject *Sender);
        void __fastcall BtnPiClick(TObject *Sender);
        void __fastcall BtneClick(TObject *Sender);
        void __fastcall BtnClrValClick(TObject *Sender);
        void __fastcall BtnClrResClick(TObject *Sender);
        void __fastcall BtnRadDegClick(TObject *Sender);
        void __fastcall BtnSquareClick(TObject *Sender);
        void __fastcall BtnPowClick(TObject *Sender);
        void __fastcall BtnCSCClick(TObject *Sender);
        void __fastcall BtnSECClick(TObject *Sender);
        void __fastcall BtnCOTClick(TObject *Sender);
        void __fastcall BtnEqualClick(TObject *Sender);
private:	// User declarations
        double Result, Memory, Value;
        bool Radians;
public:		// User declarations
        __fastcall TCalculatorForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCalculatorForm *CalculatorForm;
//---------------------------------------------------------------------------
#endif
