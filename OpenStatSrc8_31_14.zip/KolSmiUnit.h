//---------------------------------------------------------------------------

#ifndef KolSmiUnitH
#define KolSmiUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TKSForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TMemo *Memo1;
    TRadioGroup *CompareGrp;
    TLabel *Label2;
    TEdit *ObservedEdit;
    TBitBtn *ObsInBtn;
    TBitBtn *ObsOutBtn;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TLabel *PlotLabel;
    TGroupBox *GroupBox1;
    TCheckBox *PlotChk;
    TCheckBox *PrintChk;
    TRadioGroup *TypeGrp;
    TBitBtn *FreqIn;
    TBitBtn *FreqOut;
    TLabel *FreqLabel;
    TEdit *FrequencyEdit;
        TBitBtn *GroupIn;
        TBitBtn *GroupOut;
        TEdit *GroupEdit;
        TLabel *GroupLabel;
        TCheckBox *CumDistChk;
        TBitBtn *Obs2InBtn;
        TBitBtn *Obs2OutBtn;
        TLabel *Values2Label;
        TEdit *Observed2Edit;
        TRadioGroup *PlotTypeGrp;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ObsInBtnClick(TObject *Sender);
    void __fastcall ObsOutBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall FreqInClick(TObject *Sender);
    void __fastcall FreqOutClick(TObject *Sender);
    void __fastcall TypeGrpClick(TObject *Sender);
    void __fastcall GroupInClick(TObject *Sender);
    void __fastcall GroupOutClick(TObject *Sender);
    void __fastcall CompareGrpClick(TObject *Sender);
        void __fastcall Obs2InBtnClick(TObject *Sender);
        void __fastcall Obs2OutBtnClick(TObject *Sender);

private:	// User declarations
     int Which;
     int Status;
     int selected;
     int col, nints, plottype;
     AnsiString heading;
     AnsiString ytitle;
     AnsiString ObsLabel;
     AnsiString CompLabel;
     double value, min, max, range, incrsize, nointervals, mean, stddev;
     double ObsMean,ObsStdDev, ObsMin, ObsMax, ObsRange, ObsIncr;
     double df1, df2;
     double P;
     double Q;
     double X;
     double Y;
     double Bound;
     double KSProb(double D, int N);
    void __fastcall TKSForm::GetCombo1Data(int GroupCol, int ObsCol,
          double *ObsFreq, double *CompFreq, double *ObsData, double *CompData);
    void __fastcall TKSForm::GetCombo2Data(int ObsCol, int CompareTo, double *ObsFreq,
          double *freqcomp, double *XValue, double *ObsData, double *CompData);
    void __fastcall TKSForm::GetCombo3Data(int GroupCol, int ObsCol, int FreqCol,
          double *ObsFreq, double *CompFreq, double *ObsData, double *CompData);
    void __fastcall TKSForm::GetCombo4Data(int ObsCol, int FreqCol, int CompareTo,
          double *freq, double *freqcomp, double *ObsData, double *CompData,
          double *XValue);
void __fastcall TKSForm::GetCombo5Data(int ObsCol, int Obs2Col, double *ObsFreq,
       double *CompFreq, double *ObsData, double *CompData);
    void __fastcall TKSForm::GetTheoretical(int CompareTo, int Ncases,
          double *CompData, double *XValue, double *freqccomp);
    void __fastcall TKSForm::PlotIt(double *freq, double *freqcomp, double *XValue);
    
public:		// User declarations
    __fastcall TKSForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKSForm *KSForm;
//---------------------------------------------------------------------------
#endif
