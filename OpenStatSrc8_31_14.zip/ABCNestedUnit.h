//---------------------------------------------------------------------------

#ifndef ABCNestedUnitH
#define ABCNestedUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TABCNestedForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TBitBtn *AInBtn;
    TBitBtn *AOutBtn;
    TBitBtn *BInBtn;
    TBitBtn *BOutBtn;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TLabel *Label2;
    TEdit *FactorAEdit;
    TLabel *Label3;
    TEdit *FactorBEdit;
    TLabel *Label4;
    TEdit *DepEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TMemo *Memo1;
    TRadioGroup *OptionsBox;
    TLabel *Label5;
    TEdit *FactorCEdit;
    TBitBtn *CInBtn;
    TBitBtn *COutBtn;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall AInBtnClick(TObject *Sender);
    void __fastcall AOutBtnClick(TObject *Sender);
    void __fastcall BInBtnClick(TObject *Sender);
    void __fastcall BOutBtnClick(TObject *Sender);
    void __fastcall CInBtnClick(TObject *Sender);
    void __fastcall COutBtnClick(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall GetVars(TObject *Sender);
    void __fastcall GetMemory(TObject *Sender);
    void __fastcall GetSums(TObject *Sender);
    void __fastcall ShowMeans(TObject *Sender);
    void __fastcall GetResults(TObject *Sender);
    void __fastcall ShowResults(TObject *Sender);
    void __fastcall ReleaseMemory(TObject *Sender);
    void __fastcall TwoWayPlot(TObject *Sender);
    
private:	// User declarations
    AnsiString DepVar, FactorA, FactorB, FactorC;
    double SSTot, SumSqrTot, SSA, SumSqrA, SSB, SSC, SumSqrB, SSAC, YValue, TotMean;
    double SSW, SSBwAC, SSAB, MSBwAC, MSA, MSB, MSC, MSAC, MSAB, MSW, MSTot;
    double ***SS, ***SumSqr, ***CellMeans, ***CellSDs, **ACSS, **ABSS;
    double *ASS, *BSS, *CSS, *ASumSqr, *BSumSqr, *CSumSqr, **ACSumSqr, **ABSumSqr;
    double *AMeans, *BMeans, *CMeans, **ACMeans, *ASDs, *CSDs, **ABMeans, **ACSDs;
    double **ABSDs, *BSDs;
    int ACol, BCol, CCol, YCol, NoALevels, NoBLevels, NoCLevels;
    int MinA, MaxA, MinB, MaxB, MinC, MaxC, AValue, BValue, CValue;
    int TotN, celln, dfA, dfBwA, dfC, dfAC, dfBwAC, dfwcell, dftotal;
    int ***CellCount, *ACount, *BCount, *CCount, **ACCount, **ABCount;
    int *ColNoSelected, NoSelected;
    
public:		// User declarations
    __fastcall TABCNestedForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TABCNestedForm *ABCNestedForm;
//---------------------------------------------------------------------------
#endif
