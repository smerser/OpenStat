//---------------------------------------------------------------------------

#ifndef AnovaTestsUnitH
#define AnovaTestsUnitH
//---------------------------------------------------------------------------
#endif

void TUKEY(double error_ms,            //  { mean squared for residual }
           double error_df,            //  { deg. freedom for residual }
           double value,               //  { size of smallest group }
           double *group_total,        //  { sum of scores in a group }
           double *group_count,        //  { no. of cases in a group }
           int min_grp,                //  { minimum group code }
           int max_grp,                //  { maximum group code }
           double alpha);              //  { alpha test level }

void SCHEFFETEST(double error_ms,      // { mean squared residual }
                 double *group_total,  // { sum of scores in a group }
                 double *group_count,  // { count of cases in a group }
                 int min_grp,          // { code of first group }
                 int max_grp,          // { code of last group  }
                 double total_n,       // { total number of cases }
                 double alpha);        // { alpha test level }

void Newman_Keuls(double error_ms,     // { residual mean squared }
                  double error_df,     // { deg. freedom for error }
                  double value,        // { number in smallest group }
                  double *group_total, // { sum of scores in a group }
                  double *group_count, // { count of cases in a group }
                  int min_grp,         // { lowest group code }
                  int max_grp,         // { largest group code }
                  double alpha);       // { alpha test level }

void TUKEY_KRAMER(double error_ms,     // { residual mean squared }
                  double error_df,     // { deg. freedom for error }
                  double value,        // { number in smallest group }
                  double *group_total, // { sum of scores in group }
                  double *group_count, // { number of caes in group }
                  int min_grp,         // { code of lowest group }
                  int max_grp,         // { code of highst group }
                  double alpha);       // { alpha test level }

void CONTRASTS(double error_ms,        // { residual ms }
               double error_df,        // { residual df }
               double *group_total,    // { group sums  }
               double *group_count,    // { group cases }
               int min_grp,            // { lowest code }
               int max_grp,            // { highest code }
               double overall_probf,   // { prob of overall test }
               double alpha);          // { alpha test level }

void Bonferroni(double *group_total,   // { sum of scores in group }
                double *group_count,   // { number of caes in group }
                double *group_var,     // { group variances }
                int min_grp,           // { code of lowest group }
                int max_grp,           // { code of highst group }
                double alpha);         // { alpha test level }

void TUKEYBTEST(double ErrorMS,        // { within groups error }
                double ErrorDF,        // { degrees of freedom within }
                double *group_total,   // { vector of group sums }
                double *group_count,   // { vector of group n's }
                int min_grp,           // { smallest group code }
                int max_grp,           // { largest group code }
                double groupsize,      // { size of groups (all equal)
                double alpha);         // { alpha test level }

void welchttests(int NoCompares,       // { no. of cells }
                 double *cellsums,     // { mean of values in a cell }
                 double *cellcnts,     // { count of values in a cell }
                 double *cellvars,     // { cell standard deviations }
                 double alpha);        // { alpha test level }
