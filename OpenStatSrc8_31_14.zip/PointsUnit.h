//---------------------------------------------------------------------------

#ifndef PointsUnitH
#define PointsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TPointsFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *ReturnBtn;
    TButton *PrintBtn;
    TEdit *MsgEdit;
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormPaint(TObject *Sender);
    void __fastcall FormResize(TObject *Sender);
    void __fastcall PrintBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TPointsFrm(TComponent* Owner);
    void PtsPlot(void);
    double *pts, *avg;
    int NoCases;
    char Title[81];
    char LabelOne[21];
    char LabelTwo[21];
};
//---------------------------------------------------------------------------
extern PACKAGE TPointsFrm *PointsFrm;
//---------------------------------------------------------------------------
#endif
