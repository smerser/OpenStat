//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include <stdlib.h>
#include "TestSpecUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestSpecFrm *TestSpecFrm;
//---------------------------------------------------------------------------
__fastcall TTestSpecFrm::TTestSpecFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestSpecFrm::FormShow(TObject *Sender)
{
    RndLabel->Visible = true;
    RndLabel2->Visible = true;
    RndNoEdit->Visible = true;
    MajLabel->Visible = true;
    MajorCombo->Visible = true;
    MinLabel->Visible = true;
    MinorCombo->Visible = true;
    RadioGroup1->Visible = true;
    SelLabel->Visible = true;
    SelEdit->Visible = true;
    StemMemo->Clear();
    FoilMemo->Clear();
    fileopen = false;
    for (int i = 0; i < 500; i++) selected[i] = 0;
    for (int i = 0; i < 100; i++) strcpy(parms.IDs[i],"");
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::CancelBtnClick(TObject *Sender)
{
    if (fileopen) fclose(bankfileptr);
    TestSpecFrm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::OKBtnClick(TObject *Sender)
{
    // save parameter file
    strcpy(parms.bankfilename,filename);
    strcpy(parms.itemfilename,bankname);
    parms.AdminOpt = AdminOpts->ItemIndex;
    int noselected = 0;
    for (int i = 0; i < NoItems; i++) if (selected[i] == 1) noselected++;
    parms.noselected = noselected;
    int j = 0;
    for (int i = 0; i < NoItems; i++)
    {
        if (selected[i] == 1)
        {
            parms.selected[j] = i+1; // item no. selected
            j++;
        }
    }
    parmsptr = &parms;
    strcpy(parmfile,filename);
    strcat(parmfile,".PRM");
    if ((prmfileptr = fopen(parmfile,"wb")) == NULL)
    {
        Application->MessageBox("Could not open test specification file.",
            "FILE ERROR!",MB_OK);
        TestSpecFrm->Hide();
    }
    fwrite(parmsptr,sizeof(testparms),1,prmfileptr);
    fclose(prmfileptr);
    fclose(bankfileptr);
    TestSpecFrm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::SelectOptsClick(TObject *Sender)
{
    AnsiString response;

    if (SelectOpts->ItemIndex == 0) // select all items
    {
        RndLabel->Visible = false;
        RndLabel2->Visible = false;
        RndNoEdit->Visible = false;
        MajLabel->Visible = false;
        MajorCombo->Visible = false;
        MinLabel->Visible = false;
        MinorCombo->Visible = false;
        RadioGroup1->Visible = false;
        SelLabel->Visible = false;
        SelEdit->Visible = false;
        for (unsigned int i = 0; i < bankhdr.NoItems; i++) selected[i] = 1;
        OKBtn->SetFocus();
    }
    if (SelectOpts->ItemIndex == 1) // select randomly
    {
        MajLabel->Visible = false;
        MajorCombo->Visible = false;
        MinLabel->Visible = false;
        MinorCombo->Visible = false;
        RadioGroup1->Visible = false;
        SelLabel->Visible = false;
        SelEdit->Visible = false;
        RndLabel->Visible = true;
        RndNoEdit->Visible = true;
        RndLabel2->Visible = true;
        RndNoEdit->SetFocus();
    }
    if (SelectOpts->ItemIndex == 2) // select by difficulty range
    {
        RndLabel->Visible = false;
        RndLabel2->Visible = false;
        RndNoEdit->Visible = false;
        MajLabel->Visible = false;
        MajorCombo->Visible = false;
        MinLabel->Visible = false;
        MinorCombo->Visible = false;
        RadioGroup1->Visible = true;
        SelLabel->Visible = false;
        SelEdit->Visible = false;
        response = InputBox("DIFFICULTY","Enter minimum difficulty parameter:","1.0");
        double min = atof(response.c_str());
        response = InputBox("DIFFICULTY","Enter maximum difficulty parameter:","0.0");
        double max = atof(response.c_str());
        // Now, select all items in bank with difficulty in the range
        for (int i = 0; i < NoItems; i++)
        {
            getitem(i+1);
            if (fixeditem.difftype == 0) // classical
            {
                if ((fixeditem.mean >= min) && (fixeditem.mean <= max))
                    selected[itemno] = 1;
            }
            else
            {
                if ((fixeditem.difficulty >= min) && (fixeditem.difficulty <= max))
                    selected[itemno] = 1;
            }
        } // next item
        OKBtn->SetFocus();
    }
    if (SelectOpts->ItemIndex == 3) // select based on categories
    {
        RndLabel->Visible = false;
        RndNoEdit->Visible = false;
        RndLabel2->Visible = false;
        MajLabel->Visible = true;
        MajorCombo->Visible = true;
        MinLabel->Visible = true;
        MinorCombo->Visible = true;
        RadioGroup1->Visible = false;
        SelLabel->Visible = false;
        SelEdit->Visible = false;
        response = InputBox("Select based on M(a)jor Code, M(i)nor Code or (b)oth (i,a or b)?",
            "WHICH CODES","b");

        if ((MajorCombo->Text == "") || (MinorCombo->Text == ""))
        {
            Application->MessageBox("You must first selected codes.","ERROR",MB_OK);
            return;
        }
        for (int i = 0; i < NoItems; i++)
        {
            getitem(i+1);
            if (response == "b")
            {
                if ((fixeditem.majorcode == MajorCombo->ItemIndex) &&
                    (fixeditem.minorcode == MinorCombo->ItemIndex)) selected[itemno] = 1;
            }
            if (response == "a")
            {
                if (fixeditem.majorcode == MajorCombo->ItemIndex) selected[itemno] = 1;
            }
            if (response == "i")
            {
                if (fixeditem.minorcode == MinorCombo->ItemIndex) selected[itemno] = 1;
            }
        }
        OKBtn->SetFocus();
    }
    if (SelectOpts->ItemIndex == 4)// both difficulty and categories
    {
        RndLabel->Visible = false;
        RndLabel2->Visible = false;
        RndNoEdit->Visible = false;
        MajLabel->Visible = true;
        MajorCombo->Visible = true;
        MinLabel->Visible = true;
        MinorCombo->Visible = true;
        RadioGroup1->Visible = true;
        SelLabel->Visible = false;
        SelEdit->Visible = false;
        response = InputBox("Select based on M(a)jor Code, M(i)nor Code or (b)oth (i,a or b)?",
            "WHICH CODES","b");
        if ((MajorCombo->Text == "") || (MinorCombo->Text == ""))
        {
            Application->MessageBox("You must first selected codes.","ERROR",MB_OK);
            return;
        }
        AnsiString response;
        response = InputBox("DIFFICULTY","Enter minimum difficulty parameter:","1.0");
        double min = atof(response.c_str());
        response = InputBox("DIFFICULTY","Enter maximum difficulty parameter:","0.0");
        double max = atof(response.c_str());
        // Now, select items meeting both criteria
        for (int i = 0; i < NoItems; i++)
        {
            getitem(i+1);
            if (fixeditem.difftype == 0) // classical
            {
                if ((fixeditem.mean >= min) && (fixeditem.mean <= max))
                {
                    if ((fixeditem.majorcode == MajorCombo->ItemIndex) &&
                        (fixeditem.minorcode == MinorCombo->ItemIndex))
                        selected[itemno] = 1;
                }
            }
            else
            {
                if ((fixeditem.difficulty >= min) && (fixeditem.difficulty <= max))
                {
                    if ((fixeditem.majorcode == MajorCombo->ItemIndex) &&
                        (fixeditem.minorcode == MinorCombo->ItemIndex))
                        selected[itemno] = 1;
                }
            }
        } // next item
        OKBtn->SetFocus();
    }
    if (SelectOpts->ItemIndex == 5) // individual select items
    {
        RndLabel->Visible = false;
        RndLabel2->Visible = false;
        RndNoEdit->Visible = false;
        MajLabel->Visible = false;
        MajorCombo->Visible = false;
        MinLabel->Visible = false;
        MinorCombo->Visible = false;
        RadioGroup1->Visible = true;
        SelLabel->Visible = true;
        SelEdit->Visible = true;
        getitem(1);
        SelEdit->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::StemScrollChange(TObject *Sender)
{
    int pos = StemScroll->Position;
    int item = atoi(ItemNoEdit->Text.c_str());
    if (pos == item) return;
    if (pos > NoItems) return;
    // load the selected item
    getitem(pos);
    StemMemo->Clear();
    for (int i = 0; i < stemlines; i++)
        StemMemo->Lines->Add(Stem[i]);
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::getitem(int ino)
{
    long int whereat;

    if (fileopen)
    {
        whereat = bankhdr.ItemStart[ino-1];
        fseek(bankfileptr,whereat,0);
        // get fixed values
        descptr = &fixeditem;
        fread(descptr,sizeof(itemdesc),1,bankfileptr);
        ItemNoEdit->Text = fixeditem.ItemNo;
        itemno = fixeditem.ItemNo;
        RadioGroup1->ItemIndex = fixeditem.difftype;
        MajorCodeEdit->Text = MajorCombo->Items->Strings[fixeditem.majorcode];
        MinorCodeEdit->Text = MinorCombo->Items->Strings[fixeditem.minorcode];
        FoilScroll->Max = (short)fixeditem.nofoils;
        NoFoils = fixeditem.nofoils;
        if (NoFoils > 0) ChoiceEdit->Text = 1;
        stemlines = fixeditem.stemlines;
        for (int i = 0; i < fixeditem.nofoils; i++)
            foillines[i] = fixeditem.foillines[i];
        for (int i = 0; i < fixeditem.stemlines; i++)
            strcpy(Stem[i],fixeditem.Stem[i]);
        for (int i = 0; i < fixeditem.nofoils; i++)
            for (int j = 0; j < fixeditem.foillines[i]; j++)
                strcpy(Foil[i][j],fixeditem.Foil[i][j]);
        // load item stem
        StemMemo->Clear();
        for (int i = 0; i < fixeditem.stemlines; i++) // load stem
           StemMemo->Lines->Add(Stem[i]);
        FoilMemo->Clear();
        for (int j = 0; j < fixeditem.foillines[0]; j++) // load first foil
            FoilMemo->Lines->Add(Foil[0][j]);
    }
    else
    {
        Application->MessageBox("Item file is not open.", "FILE ERROR!",MB_OK);
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::openoldbank(TObject *Sender)
{
    char astring[81];
    AnsiString tempfile;
    
    MajorCombo->Clear();
    MinorCombo->Clear();
    OpenDialog1->Filter = "Item Bank (*.bnk)|*.BNK|All files (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
    if ((OpenDialog1->Execute()) == NULL) return;
    tempfile = ExtractFileName(OpenDialog1->FileName);
    strcpy(filename,tempfile.c_str());
    if (FileExists(filename)) // existing bank
    {
        hdrfileptr = fopen(filename,"rb");
        if (hdrfileptr == NULL)
        {
            Application->MessageBox("Could not open old item bank index header.",
                "FILE ERROR!",MB_OK);
            return;
        }
        hdrptr = &bankhdr;
        fread(hdrptr,sizeof(header),1,hdrfileptr);
        NoItems = bankhdr.NoItems;
        StemScroll->Max = bankhdr.NoItems;
        // open and load the major and minor code files
        strcpy(majorfile,bankhdr.majorfile);
        if ((majorptr = fopen(majorfile,"rt")) != NULL)
        {
            while (!feof(majorptr))
            {
                fgets(astring,81,majorptr);
                astring[strlen(astring)-1] = 0;
                if (feof(majorptr)) break;
                MajorCombo->Items->Add(astring);
            }
        }
        strcpy(minorfile,bankhdr.minorfile);
        if ((minorptr = fopen(minorfile,"rt")) != NULL)
        {
            while (!feof(minorptr))
            {
                fgets(astring,31,minorptr);
                astring[strlen(astring)-1] = 0;
                if (feof(minorptr)) break;
                MinorCombo->Items->Add(astring);
            }
        }
        strcpy(bankname,bankhdr.bankname);
        if ((bankfileptr = fopen(bankname,"r+b")) == NULL)
        {
            Application->MessageBox("Can't open items file.","FILE ERROR!",MB_OK);
            fclose(hdrfileptr);
            fclose(majorptr);
            fclose(minorptr);
            return;
        }
        BankEdit->Text = bankname;
        fileopen = true;
        getitem(1); // read the first item information

    }
    else
    {
        Application->MessageBox("The file selected does not exist.","FILE MESSAGE",MB_OK);
        return;
    }
    fclose(hdrfileptr);
    fclose(majorptr);
    fclose(minorptr);
}
//-------------------------------------------------------------------------


void __fastcall TTestSpecFrm::FoilScrollChange(TObject *Sender)
{
    int pos = FoilScroll->Position;
    int ChoiceNo = atoi(ChoiceEdit->Text.c_str());
    if (pos == ChoiceNo) return;
    if (pos > NoFoils) return;
    ChoiceEdit->Text = pos;
    // load the selected foil
    FoilMemo->Clear();
    for (int i = 0; i < foillines[pos-1]; i++)
        FoilMemo->Lines->Add(Foil[pos-1][i]);
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::SelEditKeyPress(TObject *Sender, char &Key)
{
    if ((Key == 'Y') || (Key == 'y')) // use this item
        selected[itemno] = 1;
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::RndNoEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) // number was entered
    {
        int no = atoi(RndNoEdit->Text.c_str());
        randomize();
        for (int i = 0; i < no; i++)
        {
again:      int value = int(rand() % NoItems); // value 0 to no. of items-1
            // check for bounds
            if ((value < 0) || (value >= NoItems)) goto again;
            selected[value] = 1;
            // check for redundancy
            for (int j = 0; j < i; j++) if (selected[value] == 1) goto again;
        }
        OKBtn->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::OpenBtnClick(TObject *Sender)
{
    openoldbank(this);
}
//---------------------------------------------------------------------------

void __fastcall TTestSpecFrm::IDsBtnClick(TObject *Sender)
{
     AnsiString prompt;
     AnsiString response;
     parms.Ntests = atoi(NTestsEdit->Text.c_str());
     for (int i = 0; i < parms.Ntests; i++)
     {
         prompt = "Student ";
         prompt = prompt + (i+1);
         response = InputBox("SUBJECT ID NO.",
             "Enter subject's ID (up to 20 characters):",
             prompt);
         strcpy(parms.IDs[i],response.c_str());
     }
}
//---------------------------------------------------------------------------

