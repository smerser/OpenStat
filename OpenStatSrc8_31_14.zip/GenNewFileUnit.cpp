//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "GenNewFileUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGenNewFileForm *GenNewFileForm;
//---------------------------------------------------------------------------
__fastcall TGenNewFileForm::TGenNewFileForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::ResetBtnClick(TObject *Sender)
{
     FreqInBtn->Visible = true;
     FreqOutBtn->Visible = false;
     ValInBtn->Visible = true;
     ValOutBtn->Visible = false;
     OtherInBtn->Visible = true;
     OtherOutBtn->Visible = false;
     FreqVarEdit->Text = "";
     ValVarEdit->Text = "";
     OtherVarList->Clear();
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::FreqInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (VarList->ItemIndex < 0) return;     
     FreqVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     FreqInBtn->Visible = false;
     FreqOutBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::FreqOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FreqVarEdit->Text);
     FreqVarEdit->Text = "";
     FreqOutBtn->Visible = false;
     FreqInBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::ValInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (VarList->ItemIndex < 0) return;
     ValVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ValInBtn->Visible = false;
     ValOutBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::ValOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ValVarEdit->Text);
     ValVarEdit->Text = "";
     ValOutBtn->Visible = false;
     ValInBtn->Visible = true;    
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::OtherInBtnClick(TObject *Sender)
{
     int i, index;

     if (VarList->ItemIndex < 0) return;
     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              OtherVarList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OtherOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::OtherOutBtnClick(TObject *Sender)
{
     int index;

     index = OtherVarList->ItemIndex;
     VarList->Items->Add(OtherVarList->Items->Strings[index]);
     OtherVarList->Items->Delete(index);
     OtherInBtn->Visible = true;
     if (OtherVarList->Items->Count == 0) OtherOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TGenNewFileForm::OKBtnClick(TObject *Sender)
{
     int NoVars = OtherVarList->Items->Count + 2;
     AnsiString **Data;
     AnsiString *Labels;
     AnsiString CellValue;
     int *selected;
     AnsiString **DictData;
     int col, frequency, count, row;
     double value;

     // allocate memory
     selected = new int[NoVars];
     Labels = new AnsiString[NoVars];
     Data = new AnsiString *[NoCases];
     for (int i = 0; i < NoCases; i++) Data[i] = new AnsiString[NoVars];
     DictData = new AnsiString *[NoVars];
     for (int i = 0; i < NoVars; i++) DictData[i] = new AnsiString[7];

     // Get variables and labels
     for (int i = 1; i <= NoVariables; i++)
     {
         CellValue = MainForm->Grid->Cells[i][0];
         if (CellValue == FreqVarEdit->Text)
         {
            selected[0] = i;
            Labels[0] = CellValue;
            for (int j = 0; j < 7; j++) DictData[0][j] = DictionaryForm->DGrid->Cells[j][i];
         }
         if (CellValue == ValVarEdit->Text)
         {
            selected[1] = i;
            Labels[1] = CellValue;
            for (int j = 0; j < 7; j++) DictData[1][j] = DictionaryForm->DGrid->Cells[j][i];
         }
         for (int j = 0; j < OtherVarList->Items->Count; j++)
         {
             if (CellValue == OtherVarList->Items->Strings[j])
             {
                Labels[j+2] = CellValue;
                selected[j+2] = i;
                for (int k = 0; k < 7; k++) DictData[j+2][k] = DictionaryForm->DGrid->Cells[k][j+2];
             }
         }
     }

     // build data from original file
     for (int i = 1; i <= NoCases; i++)
     {
         for (int j = 0; j < NoVars; j++)
         {
             col = selected[j];
             Data[i-1][j] = MainForm->Grid->Cells[col][i];
         }
     }

     // get number of cases to generate
     count = 0;
     for (int i = 0; i < NoCases; i++)
     {
         frequency = StrToInt(Data[i][0]);
         count += frequency;
     }

     CloseFile();

     // create new file
     for (int i = 1; i < NoVars; i++)
     {
         MainForm->Grid->Cells[i][0] = Labels[i];
         NewVar(i,true);
         for (int j = 0; j < 7; j++) DictionaryForm->DGrid->Cells[j][i] = DictData[i][j];
     }
     // make data
     row = 1;
     MainForm->Grid->RowCount = count + 1;
     for (int i = 0; i < NoCases; i++)
     {
         frequency = StrToInt(Data[i][0]);
         value = StrToFloat(Data[i][1]);
         for (int j = 0; j < frequency; j++)
         {
             MainForm->Grid->Cells[1][row] = value;
             for (int k = 2; k < NoVars; k++)
                 MainForm->Grid->Cells[k][row] = Data[i][k-1];
             row++;
         }
     }
     for (int i = 1; i <= count; i++)
         MainForm->Grid->Cells[0][i] = i;
     FormatCells();
     MainForm->NoCasesEdit->Text = NoCases;
     MainForm->NoVarsEdit->Text = NoVariables;
     
     // release memory
     for (int i = 0; i < NoVars; i++) delete[] DictData[i];
     delete[] DictData;
     for (int i = 0; i < NoCases; i++) delete[] Data[i];
     delete[] Data;
     delete[] Labels;
     delete[] selected;

     NoCases = count;
     NoVariables = NoVars-1;
     
}
//---------------------------------------------------------------------------
