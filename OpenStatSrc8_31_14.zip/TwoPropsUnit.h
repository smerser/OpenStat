//---------------------------------------------------------------------------

#ifndef TwoPropsUnitH
#define TwoPropsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTwoPropsForm : public TForm
{
__published:	// IDE-managed Components
   TRadioGroup *RadioGroup1;
   TRadioGroup *RadioGroup2;
   TPanel *Panel1;
   TLabel *Label1;
   TLabel *Label2;
   TEdit *IndFreq1;
   TEdit *IndFreq2;
   TEdit *IndSize1;
   TEdit *IndSize2;
   TLabel *Label3;
   TLabel *Label4;
   TLabel *Label5;
   TLabel *Label6;
   TLabel *Label7;
   TLabel *Label8;
   TEdit *DepFreq00;
   TEdit *DepFreq01;
   TEdit *DepFreq10;
   TEdit *DepFreq11;
   TPanel *Panel2;
   TLabel *Label9;
   TListBox *VarList;
   TLabel *Label10;
   TLabel *Label11;
   TLabel *Label12;
   TEdit *Var1;
   TEdit *Var2;
   TEdit *Grp;
   TMemo *Memo1;
   TLabel *Label13;
   TEdit *CInterval;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *ContinueBtn;
   TLabel *Label14;
        TEdit *Group1;
        TEdit *Group2;
        TLabel *Label15;
        TLabel *Label16;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall RadioGroup1Click(TObject *Sender);
   void __fastcall RadioGroup2Click(TObject *Sender);
   void __fastcall VarListClick(TObject *Sender);
   void __fastcall ContinueBtnClick(TObject *Sender);
private:	// User declarations
    bool independent;
    bool griddata;

public:		// User declarations
   __fastcall TTwoPropsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTwoPropsForm *TwoPropsForm;
//---------------------------------------------------------------------------
#endif
