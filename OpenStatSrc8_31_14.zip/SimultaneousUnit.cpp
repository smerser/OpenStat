//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "stdio.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "SimultaneousUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSimultaneousForm *SimultaneousForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TSimultaneousForm::TSimultaneousForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSimultaneousForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     MatInChk->Checked = false;
     SaveCorrsChk->Checked = false;
     CrossProdChk->Checked = false;
     CovarChk->Checked = false;
     CorrsChk->Checked = false;
     InverseChk->Checked = false;
     MeansChk->Checked = false;
     VariancesChk->Checked = false;
     StdDevsChk->Checked = false;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TSimultaneousForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------

void __fastcall TSimultaneousForm::IndInBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;     
}
//---------------------------------------------------------------------------

void __fastcall TSimultaneousForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;        
}
//---------------------------------------------------------------------------

void __fastcall TSimultaneousForm::AllBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     for (int i = 0; i < VarList->Items->Count; i++)
         SelList->Items->Add(VarList->Items->Strings[i]);
     VarList->Clear();
     IndInBtn->Visible = false;
     IndOutBtn->Visible = true;     
}
//---------------------------------------------------------------------------

void __fastcall TSimultaneousForm::ComputeBtnClick(TObject *Sender)
{
     int i, j, NoVars, NCases, OriginNoVars;
     bool errorcode, showinverse;
     double R2, df1, df2, determinant, F, FProbF, StdErr, x;
     double *FProbs, *W, *Means, *Variances, *StdDevs, *R2s;
     AnsiString cellstring;
     char outline[121], valstring[121];
     double **corrs, **ProdMat, **CorrMat, **InverseMat;
     int *ColNoSelected;
     AnsiString *RowLabels;
     AnsiString *ColLabels;
     AnsiString filename;
     int result;

     if (NoVariables < 2) NoVariables = 200;

     GetDblMatMem(corrs,NoVariables+1,NoVariables+1);
     GetDblMatMem(CorrMat,NoVariables+1,NoVariables+1);
     GetDblMatMem(InverseMat,NoVariables,NoVariables);
     GetDblMatMem(ProdMat,NoVariables,NoVariables);
     Means = new double[NoVariables];
     Variances = new double[NoVariables];
     StdDevs = new double[NoVariables];
     RowLabels = new AnsiString[NoVariables];
     ColLabels = new AnsiString[NoVariables];
     R2s = new double[NoVariables];
     FProbs = new double[NoVariables];
     W = new double[NoVariables];
     ColNoSelected = new int[NoVariables];

     OriginNoVars = NoVariables; // note - additional variables might be created
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Simultaneous Multiple Regression by Bill Miller");
     errorcode = false;
     if (MatInChk->Checked)
     {
//          OpenDialog1->Filter = "Stat4Free matrix files (*.MAT)|*.MAT|All files (*.*)|*.*";
//          OpenDialog1->FilterIndex = 1;
//          if (OpenDialog1->Execute())
//          {
//               filename = OpenDialog1->FileName;
               LoadMatrix();
//               OpenMatrixFile(filename.c_str());
               NoVars = NoVariables;
               NCases = NoCases;
               for (i = 0; i < NoVars; i++)
               {
                    Means[i] = 0.0;
                    StdDevs[i] = 1.0;
                    Variances[i] = sqr(StdDevs[i]);
                    ColNoSelected[i] = i+1;
                    RowLabels[i] = MainForm->Grid->Cells[i+1][0];
               }
               for (i = 0; i < NoVars; i++)
               {
                   VarList->Items->Add(RowLabels[i]);
                   for (j = 0; j < NoVars; j++)
                       corrs[i][j] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][j+1]));
               }
//          }
     }
     else
     {
          // get independent item columns
          NoVars = SelList->Items->Count;
          if (NoVars < 1)
          {
               ShowMessage("ERROR! No independent variables selected.");
               goto CleanUp;
          }
          for (i = 0; i < NoVars; i++)
          {
               cellstring = SelList->Items->Strings[i];
               for (j = 1; j <= NoVariables; j++)
               {
                    if (cellstring == MainForm->Grid->Cells[j][0])
                    {
                         ColNoSelected[i] = j;
                         //result = VarTypeChk(j,0);
                         //if (result == 1) goto CleanUp;
                         RowLabels[i] = cellstring;
                         ColLabels[i] = cellstring;
                    }
               }
          }
          NoCases = MainForm->Grid->RowCount - 1;
          NCases = NoCases;
     }

     if (InverseChk->Checked) showinverse = true;
     else showinverse = false;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Simultaneous Multiple Regression by Bill Miller");
     if ((CrossProdChk->Checked)&& (!MatInChk->Checked))
     {
           Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected, NCases, 1, false, 0);
           MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Cross-Products Matrix");
     }

     if ((CovarChk->Checked)&&(!MatInChk->Checked))
     {
               Correlations(Means, StdDevs, corrs, NoVars, ColNoSelected,
                  NCases, 2, false, 0);
               MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Variance-Covariance Matrix");
     }
     if (!MatInChk->Checked)
        Correlations(Means, StdDevs, corrs, NoVars,ColNoSelected, NCases,
                       3, false, 0);

     if (CorrsChk->Checked)
             MatPrint(corrs, NoVars, NoVars, ColNoSelected, "Product-Moment Correlations Matrix");

     if (SaveCorrsChk->Checked)
     {
             SaveDialog1->Filter = "Stat4Free matrix files (*.MAT)|*.MAT|All files (*.*)|*.*";
             SaveDialog1->FilterIndex = 1;
             if (SaveDialog1->Execute())
             {
                filename = SaveDialog1->FileName;
                SaveSqrMat(corrs, NoVars, NCases, RowLabels, Means, StdDevs);
             }
             SaveCorrsChk->Checked = false;
     }
     for (int i = 0; i < NoVars; i++) Variances[i] = sqr(StdDevs[i]);
     if (MeansChk->Checked)
     {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(Means,NoVars,ColLabels,"Means");
     }
     if (VariancesChk->Checked)
     {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(Variances,NoVars,ColLabels,"Variances");
     }
     if (StdDevsChk->Checked)
     {
             FrmOutPut->RichOutPut->Lines->Add("");
             VPrint(StdDevs,NoVars,ColLabels,"Standard Deviations");
     }
     if (errorcode)
     {
             FrmOutPut->RichOutPut->Lines->Add("One or more correlations could not be computed due to zero variance of a variable.");
     }
     FrmOutPut->ShowModal();

     if (errorcode)
     {
             ShowMessage("ERROR! A selected variable has no variability-run aborted.");
             goto CleanUp;
     }

     df1 = (double) NoVars - 1.0;
     df2 = (double) (NCases - NoVars);
     // get determinant of the correlation matrix
     determinant = 0.0;
     for (i = 0; i < NoVars; i++)
              for (j = 0; j < NoVars; j++)
                  CorrMat[i][j] = corrs[i][j];
     determinant = Determ(CorrMat,NoVars);
     if (determinant < 0.000001)
     {
               ShowMessage("ERROR! Matrix is singular!");
               goto CleanUp;
     }
     sprintf(outline,"Determinant of correlation matrix = %8.4f",determinant);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     for (int i = 0; i < NoVars; i++)
            for (int j = 0; j < NoVars; j++)
                CorrMat[i][j] = corrs[i][j];
     SVDinverse(CorrMat,NoVars);
     for (int i = 0; i < NoVars; i++)
        for (int j = 0; j < NoVars; j++)
            InverseMat[i][j] = CorrMat[i][j];
     if (showinverse)
     {
        MatPrint(InverseMat,NoVars,NoVars,ColNoSelected,\
            "Inverse of Correlation Matrix Among All Variables");
     }
     sprintf(outline,"\n%10s%8s%10s%10s%12s%5s%5s","Variable","R","R2",\
                            "F","Prob.>F","DF1","DF2");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (int i = 0;i < NoVars; i++)
     {   // R squared values
    	   R2s[i] = 1.0 - (1.0 / InverseMat[i][i]);
        W[i] = (R2s[i] / df1) / ((1.0-R2s[i]) / df2);
        FProbs[i] = ftest(df1,df2,W[i]);
        sprintf(valstring,"%10s",MainForm->Grid->Cells[ColNoSelected[i]][0].c_str());
        sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%5.0f%5.0f",\
        		valstring,sqrt(R2s[i]),R2s[i],W[i],FProbs[i],df1,df2);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int j = 0; j < NoVars; j++)
        {  // betas
        	ProdMat[i][j] = -InverseMat[i][j]/InverseMat[j][j];
        }
     }
     MatPrint(ProdMat,NoVars,NoVars,ColNoSelected,"Betas in Columns");
     FrmOutPut->RichOutPut->Lines->Add("\nStandard Errors of Prediction");
     FrmOutPut->RichOutPut->Lines->Add("Variable     Std.Error");
     for (int i = 0; i < NoVars; i++)
     {
    	   StdErr = double(NCases-1) * SQR(StdDevs[i]) *(1.0 / InverseMat[i][i]);
        StdErr = sqrt(StdErr / double(NCases - NoVars));
        sprintf(valstring,"%10s",MainForm->Grid->Cells[ColNoSelected[i]][0].c_str());
        sprintf(outline,"%10s%10.3f",valstring,StdErr);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     for (int i = 0; i < NoVars; i++)
    	   for (int j = 0; j < NoVars; j++)
        	if (i != j) ProdMat[i][j] *= (StdDevs[j]/StdDevs[i]);
     MatPrint(ProdMat,NoVars,NoVars,ColNoSelected,"Raw Regression Coefficients");
     FrmOutPut->RichOutPut->Lines->Add("Variable   Constant");
     for (int i = 0; i < NoVars; i++)
     {
    	   x = 0.0;
        for (int j = 0; j < NoVars; j++)
        {
        	if (i != j) x += (ProdMat[j][i] * Means[j]);
        }
        x = Means[i] - x;
        sprintf(valstring,"%10s",MainForm->Grid->Cells[ColNoSelected[i]][0].c_str());
        sprintf(outline,"%10s%10.3f",valstring,x);
        FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     // Get partial correlation matrix
     for (int i = 0; i < NoVars; i++)
     {
    	   for (int j = 0; j < NoVars; j++)
        {
        	ProdMat[i][j]=-(1.0 / sqrt(InverseMat[i][i])) * \
            	InverseMat[i][j] * (1.0 / sqrt(InverseMat[j][j]));
        }
     }
     MatPrint(ProdMat,NoVars,NoVars,ColNoSelected,"Partial Correlations");
     FrmOutPut->ShowModal();

CleanUp:
     delete[] ColNoSelected;
     delete[] W;
     delete[] FProbs;
     delete[] R2s;
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;
     ClearDblMatMem(ProdMat,OriginNoVars);
     ClearDblMatMem(InverseMat,OriginNoVars);
     ClearDblMatMem(CorrMat,OriginNoVars+1);
     ClearDblMatMem(corrs,OriginNoVars+1);
}
//---------------------------------------------------------------------------

