//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "FrmFDSpecs.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "Math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "GraphUnit.h"
#include "AnovaTestsUnit.h"
#include "AnovaUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAnovaForm *AnovaForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TAnovaForm::TAnovaForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAnovaForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
        VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     DepVarEdit->Text = "";
     Factor1Edit->Text = "";
     Factor2Edit->Text = "";
     Factor3Edit->Text = "";
     Factor1TypeGrp->ItemIndex = 0;
     Factor2TypeGrp->ItemIndex = 0;
     Factor3TypeGrp->ItemIndex = 0;
     if (ops.format == 0)
     {
        OverAllEdit->Text = "0.05";
        PostHocEdit->Text = "0.05";
     }
     else
     {
        OverAllEdit->Text = "0,05";
        PostHocEdit->Text = "0,05";
     }
     OptionsBox->ItemIndex = 3;
     ScheffeChk->Checked = false;
     TukeyHSDChk->Checked = false;
     TukeyBChk->Checked = false;
     TukeyKramerChk->Checked = false;
     NewmanKeulsChk->Checked = false;
     BonferroniChk->Checked = false;
     OrthogonalChk->Checked = false;
     DepOutBtn->Visible = false;
     Factor1OutBtn->Visible = false;
     Factor2OutBtn->Visible = false;
     Factor3OutBtn->Visible = false;
     DepInBtn->Visible = true;
     Factor1InBtn->Visible = true;
     Factor2InBtn->Visible = true;
     Factor3InBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TAnovaForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);   
}
//---------------------------------------------------------------------------
void __fastcall TAnovaForm::DepInBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              DepVarEdit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor1InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              Factor1Edit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Factor1OutBtn->Visible = true;
     Factor1InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor2InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              Factor2Edit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Factor2OutBtn->Visible = true;
     Factor2InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor3InBtnClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              Factor3Edit->Text = VarList->Items->Strings[i];
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Factor3OutBtn->Visible = true;
     Factor3InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor1OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Factor1Edit->Text);
     Factor1Edit->Text = "";
     Factor1InBtn->Visible = true;
     Factor1OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor2OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Factor2Edit->Text);
     Factor2Edit->Text = "";
     Factor2InBtn->Visible = true;
     Factor2OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Factor3OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Factor3Edit->Text);
     Factor3Edit->Text = "";
     Factor3InBtn->Visible = true;
     Factor3OutBtn->Visible = false;
}
//---------------------------------------------------------------------------


void __fastcall TAnovaForm::getlevels(TObject *Sender)
{
     int i, result, anintvalue;
     double dblvalue;
     AnsiString strvalue;

     minf1 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][1])));
     maxf1 = minf1;
     for (i = 2; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //intvalue = anintvalue;
          if (intvalue > maxf1)  maxf1 = intvalue;
          if (intvalue < minf1)  minf1 = intvalue;
     }
     Nf1cells = maxf1 - minf1 + 1;
     if (nofactors > 1)
     {
          minf2 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][1])));
          maxf2 = minf2;
          for (i = 2; i <= NoCases; i++)
          {
               if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
               intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
               //result = GetValue(i, F2Col, anintvalue, dblvalue, strvalue);
               //if (result != 0) return;
               //intvalue = anintvalue;
               if (intvalue > maxf2)  maxf2 = intvalue;
               if (intvalue < minf2)  minf2 = intvalue;
          }
          Nf2cells = maxf2 - minf2 + 1;
     }
     if (nofactors == 3)
     {
          minf3 = ceil(StrToFloat(Trim(MainForm->Grid->Cells[F3Col][1])));
          maxf3 = minf3;
          for (i = 2; i <= NoCases; i++)
          {
               if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
               intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F3Col][i])));
               //result = GetValue(i, F3Col, anintvalue, dblvalue, strvalue);
               //if (result != 0) return;
               //intvalue = anintvalue;
               if (intvalue > maxf3)  maxf3 = intvalue;
               if (intvalue < minf3)  minf3 = intvalue;
          }
          Nf3cells = maxf3 - minf3 + 1;
     }
     totcells = Nf1cells + Nf2cells + Nf3cells;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Calc1Way(TObject *Sender)
{
     int i;
     int result, anintvalue;
     double dblvalue;
     AnsiString strvalue;

     // get working totals
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          intvalue = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //intvalue = anintvalue;
          X = StrToFloat(Trim(MainForm->Grid->Cells[DepVarCol][i]));
          //result = GetValue(i, DepVarCol, intvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //X = dblvalue;
          intvalue = intvalue - minf1 + 1;
          cellcnts[intvalue-1] = cellcnts[intvalue-1] + 1;
          cellsums[intvalue-1] = cellsums[intvalue-1] + X;
          cellvars[intvalue-1] = cellvars[intvalue-1] + (X * X);
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }
     DFF1 = 0;
     for (i = 0; i < Nf1cells; i++)
     {
        if (cellcnts[i] > 0)
        {
            SSF1 = SSF1 + (sqr(cellsums[i]) / cellcnts[i]);
            DFF1 = DFF1 + 1;
        }
     }
     SSF1 = SSF1 - (sqr(MeanDep) / N);
     SSDep = SSDep - (sqr(MeanDep) / N);
     SSErr = SSDep - SSF1;
     DFTot = N - 1;
     DFF1 = DFF1 - 1;
     DFErr = DFTot - DFF1;
     MSF1 = SSF1 / DFF1;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     Omega = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     F = MSF1 / MSErr;
     ProbF1 = ftest(DFF1, DFErr,F);
     MeanDep = MeanDep / N;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::OneWayTable(TObject *Sender)
{
     int i, grpsize;
     double minvar, maxvar, sumvar, sumfreqlogvar, sumDFrecip;
     double c, bartlett, cochran, hartley, chiprob;
     char outline[121];

     FrmOutPut->RichOutPut->Lines->Add("ONE WAY ANALYSIS OF VARIANCE RESULTS");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Dependent variable is: %s, Independent variable is: %s",
          DepVarEdit->Text.c_str(),Factor1Edit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE    D.F.      SS        MS        F         PROB.>F   OMEGA SQR.");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(outline,"BETWEEN   %4.0f%10.2f%10.2f%10.2f%10.2f%10.2f",
          DFF1,SSF1,MSF1,F,ProbF1,Omega);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"WITHIN    %4.0f%10.2f%10.2f",DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"TOTAL     %4.0f%10.2f",DFTot,SSDep);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("MEANS AND VARIABILITY OF THE DEPENDENT VARIABLE FOR LEVELS OF THE INDEPENDENT VARIABLE");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("GROUP     MEAN      VARIANCE  STD.DEV.  N");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     equal_grp = true;
     minvar = 1e20;
     maxvar = 0.0;
     sumvar = 0.0;
     sumDFrecip = 0.0;
     sumfreqlogvar = 0.0;
     grpsize = ceil(cellcnts[0]);
     MinSize = grpsize; // initialized minimum group size
     MaxSize = grpsize; // initialize maximum group size
     for (i = 0; i < Nf1cells; i++)
     {
          grpsize = ceil(cellcnts[i]);
          if (grpsize < MinSize)
          {
               MinSize = grpsize;
               equal_grp = false;
          }
          if (grpsize > MaxSize)  MaxSize = grpsize;
          if (cellcnts[i] > 1)
          {
               cellvars[i] = cellvars[i] - (sqr(cellsums[i]) / cellcnts[i]);
               cellvars[i] = cellvars[i] / (cellcnts[i] - 1);
               if (cellvars[i] > maxvar)  maxvar = cellvars[i];
               if (cellvars[i] < minvar)  minvar = cellvars[i];
               sumvar = sumvar + cellvars[i];
               sumDFrecip = sumDFrecip + (1.0 / (cellcnts[i] - 1.0));
               sumfreqlogvar = sumfreqlogvar + (cellcnts[i] - 1) * log10(cellvars[i]);
          }
          if (cellcnts[i] > 0)
          {
            sprintf(outline,"%4d %10.2f%10.2f%10.2f%4.0f",
              i+1,cellsums[i] / cellcnts[i], cellvars[i], sqrt(cellvars[i]), cellcnts[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(outline,"TOTAL%10.2f%10.2f%10.2f%4d",MeanDep,MSDep,sqrt(MSDep),N);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");
     c = 1.0 + (1.0 / (3 * DFF1)) * (sumDFrecip - (1.0 / DFErr));
     bartlett = (2.303 / c) * ((DFErr * log10(MSErr)) - sumfreqlogvar);
     chiprob = 1.0 - chisquaredprob(bartlett,ceil(DFF1));
     cochran = maxvar / sumvar;
     hartley = maxvar / minvar;
     FrmOutPut->RichOutPut->Lines->Add("TESTS FOR HOMOGENEITY OF VARIANCE");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(outline,"Hartley Fmax test statistic = %10.2f with deg.s freem: %d and %5.0f.",
          hartley, Nf1cells, MaxSize - 1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Cochran C statistic = %10.2f with deg.s freem: %d and %5.0f.",
          cochran, Nf1cells, MaxSize - 1);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Bartlett Chi-square = %10.2f with %4.0f D.F. Prob. > Chi-Square = %6.3f",
          bartlett, DFF1, chiprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");
     double halftprob = StrToFloat(OverAllEdit->Text);
     if (ProbF1 <= halftprob)
     {
        FrmOutPut->RichOutPut->Lines->Add("FISHER'S (PROTECTED) LEAST SIGNIFICANT DIFFERENCE TEST");
        FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
        halftprob = halftprob / 2.0;
        FrmOutPut->RichOutPut->Lines->Add("GROUP   MEAN  GROUP   MEAN   DIFFERENCE  FISHER LSD  SIGNIFICANT?");
        FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
        for (int i = 0; i <  Nf1cells - 1; i++)
        {
           for (int j = i+1; j < Nf1cells; j++)
           {
               double tinv = inverset(1.0-halftprob,DFErr);
               double LSD = tinv * sqrt(MSErr * (1.0 / cellcnts[i] + 1.0 / cellcnts[j]));
               double mean1 = cellsums[i] / cellcnts[i];
               double mean2 = cellsums[j] / cellcnts[j];
               double diff = fabs(mean1 - mean2);
               sprintf(outline,"%3d  %8.3f %3d  %8.3f  %8.3f  %8.3f",i+1,mean1,j+1,mean2,diff,LSD);
               if (LSD <= diff) strcat(outline,"         YES");
               if (LSD > diff) strcat(outline,"         NO");
               FrmOutPut->RichOutPut->Lines->Add(outline);
           }
        }
        if (Nf1cells > 3) FrmOutPut->RichOutPut->Lines->Add("NOTE! Familywise error rate may be greater than alpha");
        FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     }
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::OneWayPlot(TObject *Sender)
{
     int i;
     double maxmean;
     double *XValue;
     AnsiString setstring;
     int plottype;

     XValue = new double[Nf1cells];
     plottype = OptionsBox->ItemIndex;
     maxmean = 0.0;
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          cellsums[i-1] = cellsums[i-1] / cellcnts[i-1];
          GraphForm->Ypoints[0][i-1] = cellsums[i-1];
          if (cellsums[i-1] > maxmean)  maxmean = cellsums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = Factor1Edit->Text;
     GraphForm->XTitle = "FACTOR A LEVEL";
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     delete[] XValue;
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Calc2Way(TObject *Sender)
{
     int i, j, grpA, grpB;
     int anintvalue;
     int result;
     double dblvalue;
     AnsiString strvalue;
     double Constant, RowsTotCnt, ColsTotCnt, SSCells;

     CompError = false;
     // initialize matrix values
     NoGrpsA = maxf1 - minf1 + 1;
     NoGrpsB = maxf2 - minf2 + 1;
     for (i = 1; i <= NoGrpsA; i++)
     {
          RowSums[i-1] = 0.0;
          RowCount[i-1] = 0.0;
          for (j = 1; j <= NoGrpsB; j++)
          {
               counts[i-1][j-1] = 0.0;
               sums[i-1][j-1] = 0.0;
               vars[i-1][j-1] = 0.0;
          }
     }
     for (i = 1; i <= NoGrpsB; i++)
     {
          ColCount[i-1] = 0.0;
          ColSums[i-1] = 0.0;
     }
     N = 0;
     MeanDep = 0.0;
     SSDep = 0.0;
     SSCells = 0.0;
     RowsTotCnt = 0.0;
     ColsTotCnt = 0.0;
     // get working totals
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          grpA = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpA = anintvalue;
          grpB = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
          //result = GetValue(i, F2Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpB = anintvalue;
          X = StrToFloat(Trim(MainForm->Grid->Cells[DepVarCol][i]));
          //result = GetValue(i, DepVarCol, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //X = dblvalue;
          grpA = grpA - minf1 + 1;
          grpB = grpB - minf2 + 1;
          counts[grpA-1][grpB-1] = counts[grpA-1][grpB-1] + 1;
          sums[grpA-1][grpB-1] = sums[grpA-1][grpB-1] + X;
          vars[grpA-1][grpB-1] = vars[grpA-1][grpB-1] + (X * X);
          RowSums[grpA-1] = RowSums[grpA-1] + X;
          ColSums[grpB-1] = ColSums[grpB-1] + X;
          RowCount[grpA-1] = RowCount[grpA-1] + 1.0;
          ColCount[grpB-1] = ColCount[grpB-1] + 1.0;
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }

     // Calculate results
     for (i = 0; i < NoGrpsA; i++)
     {
          SSF1 = SSF1 + ((RowSums[i] * RowSums[i]) / RowCount[i]);
          RowsTotCnt = RowsTotCnt + RowCount[i];
     }
     for (j = 0; j < NoGrpsB; j++)
     {
          SSF2 = SSF2 + ((ColSums[j] * ColSums[j]) / ColCount[j]);
          ColsTotCnt = ColsTotCnt + ColCount[j];
     }
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
              if (counts[i,j] > 0)
                 SSCells = SSCells + ((sums[i][j] * sums[i][j]) / counts[i][j]);
     }
     if (N > 0)  Constant = (MeanDep * MeanDep) / (double)N;
     else Constant = 0.0;
     SSF1 = SSF1 - Constant;
     SSF2 = SSF2 - Constant;
     SSF1F2 = SSCells - SSF1 - SSF2 - Constant;
     SSErr = SSDep - SSCells;
     SSDep = SSDep - Constant;

     if ((SSF1F2 < 0) || (SSF1 < 0) || (SSF2 < 0))
     {
          ShowMessage("ERROR! A negative SS found. Unbalanced design? Ending analysis.");
          CompError = true;
          return;
     }
     DFTot = N - 1;
     DFF1 = NoGrpsA - 1;
     DFF2 = NoGrpsB - 1;
     DFF1F2 = DFF1 * DFF2;
     DFErr = DFTot - DFF1 - DFF2 - DFF1F2;
     MSF1 = SSF1 / DFF1;
     MSF2 = SSF2 / DFF2;
     MSF1F2 = SSF1F2 / DFF1F2;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     OmegaF1 = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     OmegaF2 = (SSF2 - DFF2 * MSErr) / (SSDep + MSErr);
     OmegaF1F2 = (SSF1F2 - DFF1F2 * MSErr) / (SSDep + MSErr);
     Omega = OmegaF1 + OmegaF2 + OmegaF1F2;
     MeanDep = MeanDep / N;
     // f tests for fixed effects
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSErr);
          FF2 = fabs(MSF2 / MSErr);
          FF1F2 = fabs(MSF1F2 / MSErr);
          ProbF1 = ftest(DFF1,DFErr,FF1);
          ProbF2 = ftest(DFF2,DFErr,FF2);
          ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
     }
     // f tests if both factors are ranm
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1))
     {
          FF1 = fabs(MSF1 / MSF1F2);
          FF2 = fabs(MSF2 / MSF1F2);
          FF1F2 = fabs(MSF1F2 / MSErr);
          ProbF1 = ftest(DFF1,DFF1F2, FF1);
          ProbF2 = ftest(DFF2,DFF1F2,FF2);
          ProbF3 = ftest(DFF1F2,DFErr,FF1F2);
     }
     // f test if factor A is ranm
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSErr);
          FF2 = fabs(MSF2 / MSF1F2);
          FF1F2 = fabs(MSF1F2 / MSErr);
          ProbF1 = ftest(DFF1,DFErr,FF1);
          ProbF2 = ftest(DFF2,DFF1F2,FF2);
          ProbF3 = ftest(DFF1F2,DFErr,FF1F2);
     }
     // f test if factor b is ranm
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1))
     {
          FF1 = fabs(MSF1 / MSF1F2);
          FF2 = fabs(MSF2 / MSErr);
          FF1F2 = fabs(MSF1F2 / MSErr);
          ProbF1 = ftest(DFF1,DFF1F2,FF1);
          ProbF2 = ftest(DFF2,DFErr,FF2);
          ProbF3 = ftest(DFF1F2,DFErr,FF1F2);
     }
     if (ProbF1 > 1.0)  ProbF1 = 1.0;
     if (ProbF2 > 1.0)  ProbF2 = 1.0;
     if (ProbF1F2 > 1.0)  ProbF1F2 = 1.0;

     // Obtain omega squared (proportion of dependent variable explained)
     if (OmegaF1 < 0.0)  OmegaF1 = 0.0;
     if (OmegaF2 < 0.0)  OmegaF2 = 0.0;
     if (OmegaF1F2 < 0.0)  OmegaF1F2 = 0.0;
     //Omega = ( (SSF1 + SSF2 + SSF1F2) - (DFF1 + DFF2 + DFF1F2) * MSErr) / (SSDep + MSErr);
     if (Omega < 0.0)  Omega = 0.0;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::TwoWayTable(TObject *Sender)
{
     int i, j, groupsize;
     double MinVar, MaxVar, sumvars, sumDFrecip, XBar, V, S, RowSS, ColSS;
     double sumfreqlogvar, c, bartlett, cochran, hartley, chiprob;
     char astring[121];

     if (CompError) return;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Two Way Analysis of Variance");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Variable analyzed: %s",DepVarEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Factor A (rows) variable: %s",Factor1Edit->Text.c_str());
     if (Factor1TypeGrp->ItemIndex == 0)  strcat(astring," (Fixed Levels)");
     else strcat(astring," (Random Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor B (columns) variable: %s",Factor2Edit->Text.c_str());
     if (Factor2TypeGrp->ItemIndex == 0)  strcat(astring," (Fixed Levels)");
     else strcat(astring," (Random Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE         D.F.    SS        MS         F      PROB.> F   Omega Squared");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Among Rows     %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f",
          DFF1,SSF1,MSF1,FF1,ProbF1,OmegaF1);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Among Columns  %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f",
          DFF2,SSF2,MSF2,FF2,ProbF2,OmegaF2);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Interaction    %4.0f  %8.3f  %8.3f  %8.3f  %6.3f     %6.3f",
          DFF1F2,SSF1F2,MSF1F2,FF1F2,ProbF1F2,OmegaF1F2);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Within Groups  %4.0f  %8.3f  %8.3f",
          DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Total          %4.0f  %8.3f  %8.3f",
          DFTot,SSDep,MSDep);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Omega squared for combined effects = %8.3f",Omega);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0))
        FrmOutPut->RichOutPut->Lines->Add("Note: Denominator of F ratio is MSErr");
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1))
        FrmOutPut->RichOutPut->Lines->Add("Note: Denominator of F ratio is MSAxB");
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Denominator of F ratio for A is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("and denominator for B and AxB is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Denominator of F ratio for B is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("and denominator for A and AxB is MSErr");
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("GROUP Row Col.  N     MEAN   VARIANCE  STD.DEV.");
     groupsize = ceil(counts[0][0]);
     equal_grp = true;
     MaxVar = 0.0;
     MinVar = 1e20;
     sumvars = 0.0;
     sumfreqlogvar = 0.0;
     sumDFrecip = 0.0;

     // Display cell means, variances, standard deviations
     V = 0.0;
     XBar = 0.0;
     S = 0.0;
     for (i = 0;i < NoGrpsA;i++)
     {
          for (j = 0;j < NoGrpsB;j++)
          {
               if (counts[i][j] > 1)
               {
                    XBar = sums[i][j] / counts[i][j];
                    V = vars[i][j] - ( (sums[i][j] * sums[i][j]) / counts[i][j]);
                    V = V / (counts[i][j] - 1.0);
                    S = sqrt(V);
                    sumvars  = sumvars + V;
                    if (V > MaxVar)  MaxVar = V;
                    if (V < MinVar)  MinVar = V;
                    sumDFrecip = sumDFrecip + (1.0 / (counts[i][j] - 1.0));
                    sumfreqlogvar = sumfreqlogvar + ((counts[i][j] - 1.0) * log(V));
                    if (counts[i][j] != groupsize) equal_grp = false;
               }
               sprintf(astring,"Cell %3d %3d  %3.0f  %8.3f  %8.3f  %8.3f",
                   minf1+i,minf2+j,counts[i][j],XBar,V,S);
               FrmOutPut->RichOutPut->Lines->Add(astring);
          }
     }

     //Display Row means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          XBar = RowSums[i] / RowCount[i];
          OrdMeansA[i] = XBar;
          RowSS = 0.0;
          for (j = 0; j < NoGrpsB; j++) RowSS = RowSS + vars[i][j];
          V = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
          V = V / (RowCount[i] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Row  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
               minf1+i,RowCount[i],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          XBar = ColSums[j] / ColCount[j];
          OrdMeansB[j] = XBar;
          ColSS = 0.0;
          for (i = 0; i < NoGrpsA; i++) ColSS = ColSS + vars[i][j];
          if (ColCount[j] > 0) V = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
          if (ColCount[j] > 1) V = V / (ColCount[j] - 1.0);
          if (V > 0.0) S = sqrt(V);
          sprintf(astring,"Col  %3d      %3.0f  %8.3f  %8.3f  %8.3f",
             minf2+j,ColCount[j],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     sprintf(astring,"TOTAL         %3d  %8.3f  %8.3f  %8.3f",
          N,MeanDep,MSDep,sqrt(MSDep));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
     c = 1.0 + (1.0 / (3.0 * NoGrpsA * NoGrpsB - 1.0)) * (sumDFrecip - (1.0 / DFErr));
     bartlett = (2.303 / c) * ((DFErr * log(MSErr)) - sumfreqlogvar);
     chiprob = 1.0 - chisquaredprob(bartlett,ceil(NoGrpsA * NoGrpsB - 1));
     cochran = MaxVar / sumvars;
     hartley = MaxVar / MinVar;
     FrmOutPut->RichOutPut->Lines->Add("TESTS FOR HOMOGENEITY OF VARIANCE");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(astring,"Hartley Fmax test statistic = %10.2f with deg.s freem: %d and %d.",
          hartley, (NoGrpsA*NoGrpsB),(groupsize-1));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Cochran C statistic = %10.2f with deg.s freem: %d and %d.",
          cochran, (NoGrpsA*NoGrpsB), (groupsize - 1));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Bartlett Chi-square statistic = %10.2f with %4d D.F. Prob. larger value = %6.3f",
          bartlett, (NoGrpsA*NoGrpsB - 1), chiprob);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::TwoWayPlot(TObject *Sender)
{
     int i, j;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     if (CompError)  return;
     XValue = new double[Nf1cells+Nf2cells];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          RowSums[i-1] = RowSums[i-1] / RowCount[i-1];
          GraphForm->Ypoints[0][i-1] = RowSums[i-1];
          if (RowSums[i-1] > maxmean)  maxmean = RowSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = Factor1Edit->Text;
     title =  Factor1Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf2cells);
     for (i = 1; i <= Nf2cells; i++)
     {
          ColSums[i-1] = ColSums[i-1] / ColCount[i-1];
          GraphForm->Ypoints[0][i-1] = ColSums[i-1];
          if (ColSums[i-1] > maxmean)  maxmean = ColSums[i-1];
          XValue[i-1] = minf1 + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = Factor2Edit->Text;
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor A x B Interaction next
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf2cells);
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     for (i = 1; i <= Nf1cells; i++)
     {
          setstring = Factor1Edit->Text + " " + IntToStr(i);
          GraphForm->SetLabels[i] = setstring;
          for (j = 1; j <= Nf2cells;j++)
          {
               XBar = sums[i-1][j-1] / counts[i-1][j-1];
               if (XBar > maxmean)  maxmean = XBar;
               GraphForm->Ypoints[i-1][j-1] = XBar;
          }
     }
     for (j = 1; j <= Nf2cells;j++)
     {
        XValue[j-1] = minf2 + j - 1;
        GraphForm->Xpoints[0][j-1] = XValue[j-1];
     }

     GraphForm->nosets = Nf1cells;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = "Factor A x Factor B";
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     delete[] XValue;
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::Calc3Way(TObject *Sender)
{
     int i, j, k, grpA, grpB, grpC;
     int anintvalue, result;
     double dblvalue;
     AnsiString strvalue;
     double Constant, RowsTotCnt, ColsTotCnt, SlcsTotCnt, SSCells, p, n2;

     CompError = false;
     // initialize matrix values
     NoGrpsA = maxf1 - minf1 + 1;
     NoGrpsB = maxf2 - minf2 + 1;
     NoGrpsC = maxf3 - minf3 + 1;
     for (i = 0; i < NoGrpsA; i++)
     {
          RowSums[i] = 0.0;
          RowCount[i] = 0.0;
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    wsum[i][j][k] = 0.0;
                    ncnt[i][j][k] = 0;
                    wx2[i][j][k] = 0.0;
               }
          }
     }
     for (i = 0; i < NoGrpsB; i++)
     {
          ColCount[i] = 0.0;
          ColSums[i] = 0.0;
     }
     for (i = 0; i < NoGrpsC; i++)
     {
          SlcCount[i] = 0.0;
          SlcSums[i] = 0.0;
     }
     N = 0;
     MeanDep = 0.0;
     SSDep = 0.0;
     RowsTotCnt = 0.0;
     ColsTotCnt = 0.0;
     SlcsTotCnt = 0.0;
     SSF1 = 0.0;
     SSF2 = 0.0;
     SSF3 = 0.0;
     SSF1F2 = 0.0;
     SSF1F3 = 0.0;
     SSF2F3 = 0.0;
     SSF1F2F3 = 0.0;
     SSCells = 0.0;

     // get working totals
     for (i = 1; i <= NoCases;i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          grpA = floor(StrToFloat(Trim(MainForm->Grid->Cells[F1Col][i])));
          grpB = floor(StrToFloat(Trim(MainForm->Grid->Cells[F2Col][i])));
          grpC = floor(StrToFloat(Trim(MainForm->Grid->Cells[F3Col][i])));
          X = StrToFloat(Trim(MainForm->Grid->Cells[DepVarCol][i]));
          //result = GetValue(i, F1Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpA = anintvalue;
          //result = GetValue(i, F2Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpB = anintvalue;
          //result = GetValue(i, F3Col, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //grpC = anintvalue;
          //result = GetValue(i, DepVarCol, anintvalue, dblvalue, strvalue);
          //if (result != 0) return;
          //X = dblvalue;

          grpA = grpA - minf1 + 1;
          grpB = grpB - minf2 + 1;
          grpC = grpC - minf3 + 1;
          ncnt[grpA-1][grpB-1][grpC-1] = ncnt[grpA-1][grpB-1][grpC-1] + 1;
          wsum[grpA-1][grpB-1][grpC-1] = wsum[grpA-1][grpB-1][grpC-1] + X;
          wx2[grpA-1][grpB-1][grpC-1] = wx2[grpA-1][grpB-1][grpC-1] + (X * X);
          RowSums[grpA-1] = RowSums[grpA-1] + X;
          ColSums[grpB-1] = ColSums[grpB-1] + X;
          SlcSums[grpC-1] = SlcSums[grpC-1] + X;
          RowCount[grpA-1] = RowCount[grpA-1] + 1.0;
          ColCount[grpB-1] = ColCount[grpB-1] + 1.0;
          SlcCount[grpC-1] = SlcCount[grpC-1] + 1.0;
          MeanDep = MeanDep + X;
          SSDep = SSDep + (X * X);
          N = N + 1;
     }

     // Calculate results
     Constant = (MeanDep * MeanDep) / N;
     // get ss for rows
     for (i = 0; i < NoGrpsA; i++)
     {
          SSF1 = SSF1 + ((RowSums[i] * RowSums[i]) / RowCount[i]);
          RowsTotCnt = RowsTotCnt + RowCount[i];
     }
     SSF1 = SSF1 - Constant;

     // get ss for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          SSF2 = SSF2 + ((ColSums[j] * ColSums[j]) / ColCount[j]);
          ColsTotCnt = ColsTotCnt + ColCount[j];
     }
     SSF2 = SSF2 - Constant;

     // get ss for slices
     for (k = 0; k < NoGrpsC; k++)
     {
          SSF3 = SSF3 + ((SlcSums[k] * SlcSums[k]) / SlcCount[k]);
          SlcsTotCnt = SlcsTotCnt + SlcCount[k];
     }
     SSF3 = SSF3 - Constant;

     // get ss for row x col interaction
     p = 0.0;
     n2 = 0.0;
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF1F2 = SSF1F2 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF1F2 = SSF1F2 - SSF1 - SSF2 - Constant;

     // get ss for row x slice interaction
     for (i = 0; i < NoGrpsA; i++)
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               for (j = 0; j < NoGrpsB; j++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF1F3 = SSF1F3 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF1F3 = SSF1F3 - SSF1 - SSF3 - Constant;

     // get ss for columns x slices interaction
     for (j = 0; j < NoGrpsB; j++)
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               for (i = 0; i < NoGrpsA; i++)
               {
                    p = p + wsum[i][j][k];
                    n2 = n2 + ncnt[i][j][k];
               }
               SSF2F3 = SSF2F3 + ((p * p) / n2);
               p = 0.0;
               n2 = 0.0;
          }
     }
     SSF2F3 = SSF2F3 - SSF2 - SSF3 - Constant;

     // get ss for cells
     for (i = 0; i < NoGrpsA; i++)
          for (j = 0; j < NoGrpsB; j++)
               for (k = 0; k < NoGrpsC; k++)
                    SSCells = SSCells + ((wsum[i][j][k] * wsum[i][j][k]) / ncnt[i][j][k]);

     SSF1F2F3 = SSCells - SSF1 - SSF2 - SSF3 - SSF1F2 - SSF1F3 - SSF2F3 - Constant;
     SSErr = SSDep - SSCells;
     SSDep = SSDep - Constant;

     if ((SSF1 < 0.0) || (SSF2 < 0.0) || (SSF3 < 0.0) || (SSF1F2 < 0.0) ||
        (SSF1F3 < 0.0) || (SSF2F3 < 0.0) || (SSF1F2F3 < 0.0))
     {
          ShowMessage("ERROR! A negative SS found. Unbalanced Design? Ending analysis.");
          CompError = true;
          return;
     }
     DFTot = N - 1;
     DFF1 = NoGrpsA - 1;
     DFF2 = NoGrpsB - 1;
     DFF3 = NoGrpsC - 1;
     DFF1F2 = DFF1 * DFF2;
     DFF1F3 = DFF1 * DFF3;
     DFF2F3 = DFF2 * DFF3;
     DFF1F2F3 = DFF1 * DFF2 * DFF3;
     DFErr = DFTot - DFF1 - DFF2 - DFF3 - DFF1F2 - DFF1F3 - DFF2F3 - DFF1F2F3;
//     DFCells = N - (NoGrpsA * NoGrpsB * NoGrpsC);
     MSF1 = SSF1 / DFF1;
     MSF2 = SSF2 / DFF2;
     MSF3 = SSF3 / DFF3;
     MSF1F2 = SSF1F2 / DFF1F2;
     MSF1F3 = SSF1F3 / DFF1F3;
     MSF2F3 = SSF2F3 / DFF2F3;
     MSF1F2F3 = SSF1F2F3 / DFF1F2F3;
     MSErr = SSErr / DFErr;
     MSDep = SSDep / DFTot;
     OmegaF1 = (SSF1 - DFF1 * MSErr) / (SSDep + MSErr);
     OmegaF2 = (SSF2 - DFF2 * MSErr) / (SSDep + MSErr);
     OmegaF3 = (SSF3 - DFF3 * MSErr) / (SSDep + MSErr);
     OmegaF1F2 = (SSF1F2 - DFF1F2 * MSErr) / (SSDep + MSErr);
     OmegaF1F3 = (SSF1F3 - DFF1F3 * MSErr) / (SSDep + MSErr);
     OmegaF2F3 = (SSF2F3 - DFF2F3 * MSErr) / (SSDep + MSErr);
     OmegaF1F2F3 = (SSF1F2F3 - DFF1F2F3 * MSErr) / (SSDep + MSErr);
     Omega = OmegaF1 + OmegaF2 + OmegaF3 + OmegaF1F2 + OmegaF1F3 +
              OmegaF2F3 + OmegaF1F2F3;
     MeanDep = MeanDep / N;

     // f tests for fixed effects
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSErr);
          FF2 = fabs(MSF2 / MSErr);
          FF3 = fabs(MSF3 / MSErr);
          FF1F2 = fabs(MSF1F2 / MSErr);
          FF1F3 = fabs(MSF1F3 / MSErr);
          FF2F3 = fabs(MSF2F3 / MSErr);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF1,DFErr,FF1);
          ProbF2 = ftest(DFF2,DFErr,FF2);
          ProbF3 = ftest(DFF3,DFErr,FF3);
          ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFErr,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFErr,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f tests if all factors are random
     for (i = 1; i <= 14; i++)  OKterms[i] = 1; // initialize as OK
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
          if  ((MSF1F2 + MSF1F3 - MSF1F2F3) < 0.0)  OKterms[1] = 0;
          else FF1 = fabs(MSF1 / (MSF1F2 + MSF1F3 - MSF1F2F3));
          if  ((MSF1F2 + MSF2F3 - MSF1F2F3) < 0.0)  OKterms[2] = 0;
          else FF2 = fabs(MSF2 / (MSF1F2 + MSF2F3 - MSF1F2F3));
          if  ((MSF1F3 + MSF2F3 - MSF1F2F3) < 0.0) OKterms[3] = 0;
          else FF3 = fabs(MSF3 / (MSF1F3 + MSF2F3 - MSF1F2F3));
          FF1F2 = fabs(MSF1F2 / MSF1F2F3);
          FF1F3 = fabs(MSF1F3 / MSF1F2F3);
          FF2F3 = fabs(MSF2F3 / MSF1F2F3);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF1,DFF1F2F3,FF1);
          ProbF2 = ftest(DFF2,DFF1F2F3,FF2);
          ProbF3 = ftest(DFF3,DFF1F2F3,FF3);
          ProbF1F2 = ftest(DFF1F2,DFF1F2F3,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFF1F2F3,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFF1F2F3,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f test if factor A is ranm, B and C Fixed
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSErr);
          FF2 = fabs(MSF2 / MSF1F2);
          FF3 = fabs(MSF3 / MSF1F3);
          FF1F2 = fabs(MSF1F2 / MSErr);
          FF1F3 = fabs(MSF1F3 / MSErr);
          FF2F3 = fabs(MSF2F3 / MSF1F2F3);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF1,DFErr,FF1);
          ProbF2 = ftest(DFF2,DFF1F2,FF2);
          ProbF3 = ftest(DFF3,DFF1F3,FF3);
          ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFErr,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFF1F2F3,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f test if factor b is ranm and A and C are Fixed
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSF1F2);
          FF2 = fabs(MSF2 / MSErr);
          FF3 = fabs(MSF3 / MSF2F3);
          FF1F2 = fabs(MSF1F2 / MSErr);
          FF1F3 = fabs(MSF1F3 / MSF1F2F3);
          FF2F3 = fabs(MSF2F3 / MSErr);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF1,DFF1F2,FF1);
          ProbF2 = ftest(DFF2,DFErr,FF2);
          ProbF3 = ftest(DFF3,DFF2F3,FF3);
          ProbF1F2 = ftest(DFF1F2,DFErr,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFF1F2F3,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFErr,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f test if factor c is ranm and A and B are Fixed
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
          FF1 = fabs(MSF1 / MSF1F3);
          FF2 = fabs(MSF2 / MSF2F3);
          FF3 = fabs(MSF3 / MSErr);
          FF1F2 = fabs(MSF1F2 / MSF1F2F3);
          FF1F3 = fabs(MSF1F3 / MSErr);
          FF2F3 = fabs(MSF2F3 / MSErr);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF1,DFF1F3,FF1);
          ProbF2 = ftest(DFF2,DFF2F3,FF2);
          ProbF3 = ftest(DFF3,DFErr,FF3);
          ProbF1F2 = ftest(DFF1F2,DFF1F2F3,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFErr,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFErr,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f tests if A is fixed, B and C are ranm
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
          if ((MSF1F3 + MSF1F2 - MSF1F2F3) < 0.0) OKterms[1] = 0;
          else FF1 = fabs(MSF1 / (MSF1F3 + MSF1F2 - MSF1F2F3));
          FF2 = fabs(MSF2 / MSF2F3);
          FF3 = fabs(MSF3 / MSF2F3);
          FF1F2 = fabs(MSF1F2 / MSF1F2F3);
          FF1F3 = fabs(MSF1F3 / MSF1F2F3);
          FF2F3 = fabs(MSF2F3 / MSErr);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          if ((DFF1F3 + DFF1F2 - DFF1F2F3) <= 0)  OKterms[8] = 0;
          else ProbF1 = ftest(DFF1,(DFF1F3 + DFF1F2 - DFF1F2F3),FF1);
          ProbF2 = ftest(DFF2,DFF2F3,FF2);
          ProbF3 = ftest(DFF3,DFF2F3,FF3);
          ProbF1F2 = ftest(DFF1F2,DFF1F2F3,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFF1F2F3,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFErr,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }
     // f tests if B is fixed, A and C are ranm
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
          FF1 = fabs(MSF2 / MSF1F3);
          if ((MSF2F3 + MSF1F2 - MSF1F2F3) <= 0.0)  OKterms[2] = 0;
          else FF2 = fabs(MSF1 / (MSF2F3 + MSF1F2 - MSF1F2F3));
          FF3 = fabs(MSF3 / MSF1F3);
          FF1F2 = fabs(MSF1F2 / MSF1F2F3);
          FF1F3 = fabs(MSF1F3 / MSErr);
          FF2F3 = fabs(MSF2F3 / MSF1F2F3);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF2,DFF1F3,FF2);
          if ((DFF2F3 + DFF1F2 - DFF1F2F3) <= 0) OKterms[9] = 0;
          else ProbF2 = ftest(DFF1,(DFF2F3 + DFF1F2 - DFF1F2F3),FF1);
          ProbF3 = ftest(DFF3,DFF1F3,FF3);
          ProbF1F2 = ftest(DFF1F2,DFF1F2F3,FF1F2);
          ProbF1F3 = ftest(DFF1F3,DFErr,FF1F3);
          ProbF2F3 = ftest(DFF2F3,DFF1F2F3,FF2F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }

     // f tests if C is fixed A and B are random
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
          FF1 = fabs(MSF1 / MSF1F2);
          FF2 = fabs(MSF2 / MSF1F2);
          if ((MSF2F3 + MSF1F3 - MSF1F2F3) <= 0.0) OKterms[3] = 0;
          else FF3 = fabs(MSF3 / (MSF2F3 + MSF1F3 - MSF1F2F3));
          FF1F2 = fabs(MSF2F3 / MSErr);
          FF1F3 = fabs(MSF1F2 / MSF1F2F3);
          FF2F3 = fabs(MSF1F3 / MSF1F2F3);
          FF1F2F3 = fabs(MSF1F2F3 / MSErr);
          ProbF1 = ftest(DFF3,DFF1F2,FF3);
          ProbF2 = ftest(DFF2,DFF1F2,FF2);
          if ((DFF2F3 + DFF1F3 - DFF1F2F3) <= 0) OKterms[10] = 0;
          else ProbF3 = ftest(DFF1,(DFF2F3 + DFF1F3 - DFF1F2F3),FF1);
          ProbF1F2 = ftest(DFF2F3,DFErr,FF2F3);
          ProbF1F3 = ftest(DFF1F2,DFF1F2F3,FF1F2);
          ProbF2F3 = ftest(DFF1F3,DFF1F2F3,FF1F3);
          ProbF1F2F3 = ftest(DFF1F2F3,DFErr,FF1F2F3);
     }
     if (ProbF1 > 1.0)  ProbF1 = 1.0;
     if (ProbF2 > 1.0)  ProbF2 = 1.0;
     if (ProbF3 > 1.0)  ProbF3 = 1.0;
     if (ProbF1F2 > 1.0)  ProbF1F2 = 1.0;
     if (ProbF1F3 > 1.0)  ProbF1F3 = 1.0;
     if (ProbF2F3 > 1.0)  ProbF2F3 = 1.0;
     if (ProbF1F2F3 > 1.0)  ProbF1F2F3 = 1.0;

     // Obtain omega squared (proportion of dependent variable explained)
     if (OmegaF1 < 0.0)  OmegaF1 = 0.0;
     if (OmegaF2 < 0.0)  OmegaF2 = 0.0;
     if (OmegaF3 < 0.0)  OmegaF3 = 0.0;
     if (OmegaF1F2 < 0.0)  OmegaF1F2 = 0.0;
     if (OmegaF1F3 < 0.0)  OmegaF1F3 = 0.0;
     if (OmegaF2F3 < 0.0)  OmegaF2F3 = 0.0;
     if (OmegaF1F2F3 < 0.0)  OmegaF1F2F3 = 0.0;
     if (Omega < 0.0)  Omega = 0.0;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::ThreeWayTable(TObject *Sender)
{
     int groupsize;
     double MinVar, MaxVar, sumvars, sumDFrecip;
     int i, j, k;
     double XBar, V, S, RowSS, ColSS, SlcSS;
     double sumfreqlogvar, c, bartlett, cochran, hartley, chiprob;
     bool problem;
     char astring[121];

     if (CompError) return;
     FrmOutPut->RichOutPut->Clear();
     problem = false;
     FrmOutPut->RichOutPut->Lines->Add("Three Way Analysis of Variance");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Variable analyzed: %s",DepVarEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Factor A (rows) variable: %s",Factor1Edit->Text.c_str());
     if (Factor1TypeGrp->ItemIndex == 0)  strcat(astring," (Fixed Levels)");
     else strcat(astring," (Random Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor B (columns) variable: %s",Factor2Edit->Text.c_str());
     if (Factor2TypeGrp->ItemIndex == 0)  strcat(astring," (Fixed Levels)");
     else strcat(astring," (Random Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Factor C (slices) variable: %s",Factor3Edit->Text.c_str());
     if (Factor3TypeGrp->ItemIndex == 0)  strcat(astring," (Fixed Levels)");
     else strcat(astring," (Random Levels)");
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE         D.F.      SS          MS           F      PROB.> F   Omega Squared");
     FrmOutPut->RichOutPut->Lines->Add("");
     if ((OKterms[1] == 1) && (OKterms[8] == 1))
     {
          sprintf(astring,"Among Rows     %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
             DFF1,SSF1,MSF1,FF1,ProbF1,OmegaF1);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     else
     {
         sprintf(astring,"Among Rows     %4.0f  %10.3f  %10.3f --- error ---",
             DFF1, SSF1, MSF1 );
         FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     if ((OKterms[2] == 1) && (OKterms[9] == 1))
     {
          sprintf(astring,"Among Columns  %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
             DFF2,SSF2,MSF2,FF2,ProbF2,OmegaF2);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     else
     {
         sprintf(astring,"Among Columns  %4.0f  %10.3f  %10.3f --- error ---",
            DFF2,SSF2,MSF2);
         FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     if ((OKterms[3] == 1) && (OKterms[10] == 1))
     {
          sprintf(astring,"Among Slices   %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
             DFF3,SSF3,MSF3,FF3,ProbF3,OmegaF3);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     else
     {
          sprintf(astring,"Among Slices   %4.0f  %10.3f  %10.3f --- error ---",
             DFF3,SSF3, MSF3);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }
     sprintf(astring,"A x B Inter.   %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
          DFF1F2,SSF1F2,MSF1F2,FF1F2,ProbF1F2,OmegaF1F2);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"A x C Inter.   %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
          DFF1F3,SSF1F3,MSF1F3,FF1F3,ProbF1F3,OmegaF1F3);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"B x C Inter.   %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
          DFF2F3,SSF2F3,MSF2F3,FF2F3,ProbF2F3,OmegaF2F3);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"AxBxC Inter.   %4.0f  %10.3f  %10.3f  %10.3f  %6.3f     %6.3f",
          DFF1F2F3,SSF1F2F3,MSF1F2F3,FF1F2F3,ProbF1F2F3,OmegaF1F2F3);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Within Groups  %4.0f  %10.3f  %10.3f", DFErr,SSErr,MSErr);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Total          %4.0f  %10.3f  %10.3f",DFTot,SSDep,MSDep);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(astring,"Omega squared for combined effects = %8.3f",Omega);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 0))
     FrmOutPut->RichOutPut->Lines->Add("Note: MSErr denominator for all F ratios.");
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
          FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxB + MSAxC - MSAxBxC");
          FrmOutPut->RichOutPut->Lines->Add("Error term for B is MSAxB + MSBxC - MSAxBxC");
          FrmOutPut->RichOutPut->Lines->Add("Error term for C is MSAxC + MSBxC - MSAxBxC");
          FrmOutPut->RichOutPut->Lines->Add("Error term for AxB, AxC and BxC is MSAxBxC");
          FrmOutPut->RichOutPut->Lines->Add("Error term for AxBxC is MSErr.");
     }
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSAxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxC + MSAxB - MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 0) &&
        (Factor3TypeGrp->ItemIndex == 1))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSBxC + MSAxB - MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSAxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     if ((Factor1TypeGrp->ItemIndex == 1) && (Factor2TypeGrp->ItemIndex == 1) &&
        (Factor3TypeGrp->ItemIndex == 0))
     {
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for A is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for B is MSAxB");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for C is MSBxC + MSAxC - MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxB is MSErr");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for BxC is MSAxBxC");
        FrmOutPut->RichOutPut->Lines->Add("Note: Error term for AxBxC is MSErr");
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     for (i = 1; i <= 10; i++)  if (OKterms[i] == 0)  problem = true;
     if (problem)
     {
          FrmOutPut->RichOutPut->Lines->Add("An error occurred due to either an estimate of MS being negative");
          FrmOutPut->RichOutPut->Lines->Add("or the degrees of freem being zero.  This may occur in a design");
          FrmOutPut->RichOutPut->Lines->Add("with ranm factors using the expected values for an exact F-test.");
          FrmOutPut->RichOutPut->Lines->Add("Quasi-F statistics may be employed where this problem exists. See");
          FrmOutPut->RichOutPut->Lines->Add("Winer, B.J., Statistical Principles in Experimental Design, 1962");
          FrmOutPut->RichOutPut->Lines->Add("Section 5.15, pages 199-202 and Glass, G.V. and Stanley, J.C.,");
          FrmOutPut->RichOutPut->Lines->Add("1970, Section 18.10, pages 481-482.");
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("GROUP              N     MEAN   VARIANCE  STD.DEV.");
     groupsize = ncnt[1][1][1];
     equal_grp = true;
     MaxVar = 0.0;
     MinVar = 1e20;
     sumvars = 0.0;
     sumfreqlogvar = 0.0;
     sumDFrecip = 0.0;

     // Display cell means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               for (k = 0; k < NoGrpsC; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    V = wx2[i][j][k] - ( (wsum[i][j][k] * wsum[i][j][k]) / ncnt[i][j][k]);
                    V = V / (ncnt[i][j][k] - 1.0);
                    S = sqrt(V);
                    sumvars  = sumvars + V;
                    if (V > MaxVar)  MaxVar = V;
                    if (V < MinVar)  MinVar = V;
                    sumDFrecip = sumDFrecip + (1.0 / (ncnt[i][j][k] - 1.0));
                    if (V > 0.0)
                       sumfreqlogvar = sumfreqlogvar + ((ncnt[i][j][k] - 1.0) * log(V));
                    if (ncnt[i][j][k] != groupsize)  equal_grp = false;
                    sprintf(astring,"Cell %3d %3d %3d %3d  %8.3f  %8.3f  %8.3f",
                       minf1+i,minf2+j,minf3+k,ncnt[i][j][k],XBar,V,S);
                    FrmOutPut->RichOutPut->Lines->Add(astring);
               }
          }
     }

     //Display Row means, variances, standard deviations
     for (i = 0; i < NoGrpsA; i++)
     {
          XBar = RowSums[i] / RowCount[i];
          OrdMeansA[i] = XBar;
          RowSS = 0.0;
          for (j = 0; j < NoGrpsB; j++)
              for (k = 0; k < NoGrpsC; k++)  RowSS = RowSS + wx2[i][j][k];
          V = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
          V = V / (RowCount[i] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Row   %3d         %3.0f  %8.3f  %8.3f  %8.3f",
               minf1+i,RowCount[i],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for columns
     for (j = 0; j < NoGrpsB; j++)
     {
          XBar = ColSums[j] / ColCount[j];
          OrdMeansB[j] = XBar;
          ColSS = 0.0;
          for (i = 0; i < NoGrpsA; i++)
              for (k = 0; k < NoGrpsC; k++)  ColSS = ColSS + wx2[i][j][k];
          V = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
          V = V / (ColCount[j] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Col   %3d         %3.0f  %8.3f  %8.3f  %8.3f",
             minf2+j,ColCount[j],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     //Display means, variances and standard deviations for slices
     for (k = 0; k < NoGrpsC; k++)
     {
          XBar = SlcSums[k] / SlcCount[k];
          OrdMeansC[k] = XBar;
          SlcSS = 0.0;
          for (i = 0; i < NoGrpsA; i++)
              for (j = 0; j < NoGrpsB; j++)  SlcSS = SlcSS + wx2[i][j][k];
          V = SlcSS - (SlcSums[k] * SlcSums[k] / SlcCount[k]);
          V = V / (SlcCount[k] - 1.0);
          S = sqrt(V);
          sprintf(astring,"Slice %3d         %3.0f  %8.3f  %8.3f  %8.3f",
             minf3+k,SlcCount[k],XBar,V,S);
          FrmOutPut->RichOutPut->Lines->Add(astring);
     }

     sprintf(astring,"TOTAL            %3d  %8.3f  %8.3f  %8.3f",
          N,MeanDep,MSDep,sqrt(MSDep));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");

     c = 1.0 + (1.0 / (3.0 * NoGrpsA * NoGrpsB * NoGrpsC - 1.0)) * (sumDFrecip - (1.0 / DFErr));
     bartlett = (2.303 / c) * ((DFErr * log(MSErr)) - sumfreqlogvar);
     chiprob = chisquaredprob(bartlett,ceil(NoGrpsA * NoGrpsB * NoGrpsC - 1));
     cochran = MaxVar / sumvars;
     if (MinVar > 0.0) hartley = MaxVar / MinVar;
     FrmOutPut->RichOutPut->Lines->Add("TESTS FOR HOMOGENEITY OF VARIANCE");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
     sprintf(astring,"Hartley Fmax test statistic = %10.2f with deg.s freem: %d and %d.",
          hartley, (NoGrpsA*NoGrpsB),(groupsize-1) );
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Cochran C statistic = %10.2f with deg.s freem: %d and %d.",
          cochran, (NoGrpsA*NoGrpsB), (groupsize - 1));
     FrmOutPut->RichOutPut->Lines->Add(astring);
     sprintf(astring,"Bartlett Chi-square statistic = %10.2f with %4d D.F. Prob. larger = %6.3f",
          bartlett, (NoGrpsA*NoGrpsB - 1), 1.0 - chiprob);
     FrmOutPut->RichOutPut->Lines->Add(astring);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::ThreeWayPlot(TObject *Sender)
{
     int i, j, k;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     if (CompError) return;
     XValue = new double[totcells];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf1cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf1cells);
     for (i = 0; i < Nf1cells; i++)
     {
          RowSums[i] = RowSums[i] / RowCount[i];
          GraphForm->Ypoints[0][i] = RowSums[i];
          if (RowSums[i] > maxmean) maxmean = RowSums[i];
          XValue[i] = minf1 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf1cells;
     GraphForm->Heading = Factor1Edit->Text;
     title =  Factor1Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf2cells);
     for (i = 0; i < Nf2cells; i++)
     {
          ColSums[i] = ColSums[i] / ColCount[i];
          GraphForm->Ypoints[0][i] = ColSums[i];
          if (ColSums[i] > maxmean)  maxmean = ColSums[i];
          XValue[i] = minf2 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf2cells;
     GraphForm->Heading = Factor2Edit->Text;
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor C next
     setstring = "FACTOR C";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,1,Nf3cells);
     for (i = 0; i < Nf3cells; i++)
     {
          SlcSums[i] = SlcSums[i] / SlcCount[i];
          GraphForm->Ypoints[0][i] = SlcSums[i];
          if (SlcSums[i] > maxmean)  maxmean = SlcSums[i];
          XValue[i] = minf3 + i;
          GraphForm->Xpoints[0][i] = XValue[i];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = Nf3cells;
     GraphForm->Heading = Factor3Edit->Text;
     title =  Factor2Edit->Text + " Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor A x B Interaction within each slice next
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf2cells);
     GetDblMatMem(GraphForm->Xpoints,1,Nf2cells);
     for (k = 0; k < Nf3cells; k++)
     {
          maxmean = 0.0;
          for (i = 0; i < Nf1cells; i++)
          {
               setstring = Factor1Edit->Text + " " + IntToStr(i+1);
               GraphForm->SetLabels[i+1] = setstring;
               for (j = 0; j < Nf2cells; j++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[i][j] = XBar;
               }
          }
          for (j = 0; j < Nf2cells; j++)
          {
            XValue[j] = minf2 + j ;
            GraphForm->Xpoints[0][j] = XValue[j];
          }

          GraphForm->nosets = Nf1cells;
          GraphForm->nbars = Nf2cells;
          GraphForm->Heading = "Factor A x Factor B Within Slice" + IntToStr(k);
          title =  Factor2Edit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.5;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     }
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf1cells);

     //  Factor A x C Interaction within each Column next
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,Nf1cells,Nf3cells);
     for (j = 0; j < Nf2cells; j++)
     {
          maxmean = 0.0;
          for (i = 0; i < Nf1cells; i++)
          {
               setstring = Factor1Edit->Text + " " + IntToStr(i+1);
               GraphForm->SetLabels[i+1] = setstring;
               for (k = 0; k < Nf3cells; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[i][k] = XBar;
               }
          }
          for (k = 0; k < Nf3cells; k++)
          {
            XValue[k] = minf3 + k;
            GraphForm->Xpoints[0][k] = XValue[k];
          }

          GraphForm->nosets = Nf1cells;
          GraphForm->nbars = Nf3cells;
          GraphForm->Heading = "Factor A x Factor C Within Column " + IntToStr(j+1);
          title =  Factor3Edit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.5;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     }
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf1cells);

     //  Factor B x C Interaction within each row next
     GetDblMatMem(GraphForm->Xpoints,1,Nf3cells);
     GetDblMatMem(GraphForm->Ypoints,Nf2cells,Nf3cells);
     for (i = 0; i < Nf1cells; i++)
     {
          maxmean = 0.0;
          for (j = 0; j < Nf2cells; j++)
          {
               setstring = Factor2Edit->Text + " " + IntToStr(j+1);
               GraphForm->SetLabels[j+1] = setstring;
               for (k = 0; k < Nf3cells; k++)
               {
                    XBar = wsum[i][j][k] / ncnt[i][j][k];
                    if (XBar > maxmean)  maxmean = XBar;
                    GraphForm->Ypoints[j][k] = XBar;
               }
          }
          for (j = 0; j < Nf3cells; j++)
          {
            XValue[j] = minf3 + j;
            GraphForm->Xpoints[0][j] = XValue[j];
          }

          GraphForm->nosets = Nf2cells;
          GraphForm->nbars = Nf3cells;
          GraphForm->Heading = "Factor B x Factor C Within Row " + IntToStr(i+1);
          title =  Factor3Edit->Text + " Codes";
          GraphForm->XTitle = title;
          GraphForm->YTitle = "Mean";
          GraphForm->barwideprop = 0.5;
          GraphForm->AutoScale = false;
          GraphForm->miny = 0.0;
          GraphForm->maxy = maxmean;
          GraphForm->GraphType = plottype;
          GraphForm->BackColor = clYellow;
          GraphForm->WallColor = clBlack;
          GraphForm->FloorColor = clLtGray;
          GraphForm->ShowBackWall = true;
          GraphForm->ShowModal();
     } // next row
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,Nf2cells);
     delete[] XValue;
}
//---------------------------------------------------------------------------


void __fastcall TAnovaForm::OKBtnClick(TObject *Sender)
{
     int result;

     FrmOutPut->RichOutPut->Clear();
     // initialize values
     ColNoSelected = new int[NoVariables];
     DepVarCol = 0;
     F1Col = 0;
     F2Col = 0;
     F3Col = 0;
     SSDep = 0.0;
     SSF1 = 0.0;
     SSF2 = 0.0;
     SSF3 = 0.0;
     SSF1F2 = 0.0;
     SSF1F3 = 0.0;
     SSF2F3 = 0.0;
     SSF1F2F3 = 0.0;
     MeanDep = 0.0;
     MeanF1 = 0.0;
     MeanF2 = 0.0;
     MeanF3 = 0.0;
     Nf1cells = 0;
     Nf2cells = 0;
     Nf3cells = 0;
     N = 0;
     NoSelected = 0;
     minf1 = 0;
     maxf1 = 0;
     minf2 = 0;
     maxf2 = 0;
     minf3 = 0;
     maxf3 = 0;

     //  Get column numbers of dependent variable and factors
     for (int i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == DepVarEdit->Text)
          {
               DepVarCol = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = DepVarCol;
               //result = VarTypeChk(i,0);
               //if (result == 1) return;
          }
          if (cellstring == Factor1Edit->Text)
          {
               F1Col = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F1Col;
               //result = VarTypeChk(i,1);
               //if (result == 1) return;
          }
          if (cellstring == Factor2Edit->Text)
          {
               F2Col = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F2Col;
               //result = VarTypeChk(i,1);
               //if (result == 1) return;
          }
          if (cellstring == Factor3Edit->Text)
          {
               F3Col = i;
               NoSelected = NoSelected + 1;
               ColNoSelected[NoSelected-1] = F3Col;
               //result = VarTypeChk(i,1);
               //if (result == 1) return;
          }
     }
     if (F2Col == 0)  nofactors = 1;
     else nofactors = 2;
     if (F3Col != 0)  nofactors = 3;
     OverallAlpha = StrToFloat(OverAllEdit->Text);
     PostHocAlpha = StrToFloat(PostHocEdit->Text);
     // get min and max of each factor code
     getlevels(this);

     // allocate space
     cellcnts = new double[totcells];  // array of cell counts
     cellvars = new double[totcells];  // arrray of cell sums of squares  variances
     cellsums = new double[totcells];  // array of cell sums  means

     // initialize array values
     for (int i = 1; i <= totcells; i++)
     {
          cellsums[i-1] = 0.0;
          cellvars[i-1] = 0.0;
          cellcnts[i-1] = 0;
     }

     //  analysis
     switch (nofactors)
     {
        case 1 :
        {
          double alpha = StrToFloat(PostHocEdit->Text);
          Calc1Way(this); // single factor anova
          if (CompError)  goto cleanit;
          OneWayTable(this); // output the results
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,MinSize,cellsums,cellcnts,minf1,maxf1,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,MinSize,alpha);
          if (TukeyKramerChk->Checked)
              TUKEY_KRAMER(MSErr,DFErr,MinSize,cellsums,cellcnts,minf1,maxf1,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,MinSize,cellsums,cellcnts,minf1,maxf1,alpha);
          FrmOutPut->ShowModal();
          if (OptionsBox->ItemIndex >= 0)  OneWayPlot(this);
       } break;
       case 2 : // two-way anova
       {
            GetDblMatMem(counts,Nf1cells,Nf2cells); // matrix for 2-way containing cell sizes
            GetDblMatMem(sums,Nf1cells,Nf2cells);  // matrix for 2-way containing cell sums
            GetDblMatMem(vars,Nf1cells,Nf2cells);  // matrix for 2-way containing sums of squares
            RowSums = new double[Nf1cells];  // 2 way row sums
            ColSums = new double[Nf2cells];  // 2 way col sums
            RowCount = new double[Nf1cells]; // 2 way row count
            ColCount = new double[Nf2cells]; // 2 way col count
            OrdMeansA = new double[Nf1cells]; // ordered means for factor 1
            OrdMeansB = new double[Nf2cells]; // ordered means for factor 2

            Calc2Way(this);
            if (CompError)  goto nexttwo;
            TwoWayTable(this);
            TwoWayContrasts(this);
            FrmOutPut->ShowModal();
            if (OptionsBox->ItemIndex >= 0)  TwoWayPlot(this);
nexttwo:    delete[] OrdMeansB;
            delete[] OrdMeansA;
            delete[] ColCount;
            delete[] RowCount;
            delete[] ColSums;
            delete[] RowSums;
            ClearDblMatMem(vars,Nf1cells);
            ClearDblMatMem(sums,Nf1cells);
            ClearDblMatMem(counts,Nf1cells);
       }    break;
       case 3 : // three way anova
       {
            RowSums = new double[Nf1cells];  // 2 way row sums
            ColSums = new double[Nf2cells];  // 2 way col sums
            RowCount = new double[Nf1cells]; // 2 way row count
            ColCount = new double[Nf2cells]; // 2 way col count
            SlcSums = new double[Nf3cells];  // 3 way slice sums
            SlcCount = new double[Nf3cells]; // 3 way slice counts
            OrdMeansA = new double[Nf1cells]; // ordered means for factor 1
            OrdMeansB = new double[Nf2cells]; // ordered means for factor 2
            OrdMeansC = new double[Nf3cells]; // ordered means for factor 3
            GetDblCubeMem(wsum,Nf1cells,Nf2cells,Nf3cells);
            GetDblCubeMem(wx2,Nf1cells,Nf2cells,Nf3cells);
            GetIntCubeMem(ncnt,Nf1cells,Nf2cells,Nf3cells);
            Calc3Way(this);
            if (CompError)  goto nextthree;
            ThreeWayTable(this);
            ThreeWayContrasts(this);
            FrmOutPut->ShowModal();
            if (OptionsBox->ItemIndex >= 0)  ThreeWayPlot(this);
nextthree:
            ClearIntCubeMem(ncnt,Nf1cells,Nf2cells);
            ClearDblCubeMem(wx2,Nf1cells,Nf2cells);
            ClearDblCubeMem(wsum,Nf1cells,Nf2cells);
            delete[] OrdMeansC;
            delete[] OrdMeansB;
            delete[] OrdMeansA;
            delete[] SlcCount;
            delete[] SlcSums;
            delete[] ColCount;
            delete[] ColSums;
            delete[] RowCount;
            delete[] RowSums;
       }
     } // end switch
cleanit:
     delete[] cellcnts;
     delete[] cellvars;
     delete[] cellsums;
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

void __fastcall TAnovaForm::TwoWayContrasts(TObject *Sender)
{
     int i, j;
     double value, alpha;
     char outline[121];
     double *variances;
     double RowSS, ColSS;

     if (CompError) return;
     variances = new double[totcells];
     alpha = StrToFloat(PostHocEdit->Text);
     //  row comparisons
     if ((Nf1cells > 2) && (ProbF1 < OverallAlpha) && (Factor2TypeGrp->ItemIndex == 0))
     {
          for (i = 0; i < NoGrpsA; i++)
          {
               RowSS = 0.0;
               for (j = 0; j < NoGrpsB; j++) RowSS = RowSS + vars[i][j];
               variances[i] = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
               variances[i] = variances[i] / (RowCount[i] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS");
          // get smallest group size
          value = 1e20;
          for (i = 0; i < Nf1cells; i++)  if (RowCount[i] < value) value = RowCount[i];
          if (ScheffeChk->Checked)
              SCHEFFETEST(MSErr,RowSums,RowCount,minf1,maxf1,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(RowSums,RowCount,variances,minf1,maxf1,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
     }

     //  column comparisons
     if ((Nf2cells > 2) && (ProbF2 < OverallAlpha) && (Factor2TypeGrp->ItemIndex == 0))
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               ColSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)  ColSS = ColSS + vars[i][j];
               variances[j] = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
               variances[j] = variances[j] / (ColCount[j] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS");
          value = 1e20;
          for (i = 0; i < Nf2cells; i++)  if (ColCount[i] < value) value = ColCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,ColSums,ColCount,minf2,maxf2,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(ColSums,ColCount,variances,minf2,maxf2,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
     }

     //  simple effects for columns within each row
     if ((ProbF3 < OverallAlpha) && (Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0))
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH ROW");
          for (i = 0; i < Nf1cells; i++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"ROW %d COMPARISONS",i+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums and counts to cellsums and cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    cellsums[j] = sums[i][j];
                    cellcnts[j] = counts[i][j];
                    cellvars[j] = vars[i][j];
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each column
     if ((ProbF3 < OverallAlpha) && (Factor1TypeGrp->ItemIndex == 0) && (Factor2TypeGrp->ItemIndex == 0))
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH COLUMN");
          for (j = 0; j < Nf2cells; j++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"COLUMN %d COMPARISONS", j+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums and counts to cellsums and cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    cellsums[i] = sums[i][j];
                    cellcnts[i] = counts[i][j];
                    cellvars[i] = vars[i][j];
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }
     delete[] variances;
}
//-------------------------------------------------------------------

void __fastcall TAnovaForm::ThreeWayContrasts(TObject *Sender)
{
     int i, j, k;
     double value, alpha;
     char outline[121];
     double *variances;
     double RowSS, ColSS, SlcSS;

     if (CompError) return;
     alpha = StrToFloat(PostHocEdit->Text);
     if ((ScheffeChk->Checked == false) && (TukeyHSDChk->Checked == false) &&
        (TukeyBChk->Checked == false) && (TukeyKramerChk->Checked == false) &&
        (NewmanKeulsChk->Checked == false) && (BonferroniChk->Checked == false) &&
        (OrthogonalChk->Checked == false)) return;
     variances = new double[totcells];

     //  row comparisons
     if ((Nf1cells > 2) && (ProbF1 < OverallAlpha))
     {
          for (i = 0; i < NoGrpsA; i++)
          {
               RowSS = 0.0;
               for (j = 0; j < NoGrpsB; j++)
                   for (k = 0; k < NoGrpsC; k++) RowSS = RowSS + wx2[i][j][k];
               variances[i] = RowSS - (RowSums[i] * RowSums[i] / RowCount[i]);
               variances[i] = variances[i] / (RowCount[i] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS");
          // get smallest group size
          value = 1e20;
          for (i = 0; i < Nf1cells; i++)  if (RowCount[i] < value) value = RowCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,RowSums,RowCount,minf1,maxf1,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(RowSums,RowCount,variances,minf1,maxf1,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,RowSums,RowCount,minf1,maxf1,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,RowSums,RowCount,minf1,maxf1,alpha);
     }

     //  column comparisons
     if ((Nf2cells > 2) && (ProbF2 < OverallAlpha))
     {
          for (j = 0; j < NoGrpsB; j++)
          {
               ColSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)
                   for (k = 0; k < NoGrpsC; k++) ColSS = ColSS + wx2[i][j][k];
               variances[j] = ColSS - (ColSums[j] * ColSums[j] / ColCount[j]);
               variances[j] = variances[j] / (ColCount[j] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS");
          value = 1e20;
          for (i = 0; i < Nf2cells; i++)  if (ColCount[i] < value)  value = ColCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,ColSums,ColCount,minf2,maxf2,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(ColSums,ColCount,variances,minf2,maxf2,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,ColSums,ColCount,minf2,maxf2,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,ColSums,ColCount,minf2,maxf2,alpha);
     }

     //  slice comparisons
     if ((Nf3cells > 2) && (ProbF3 < OverallAlpha))
     {
          for (k = 0; k < NoGrpsC; k++)
          {
               SlcSS = 0.0;
               for (i = 0; i < NoGrpsA; i++)
                   for (j = 0; j < NoGrpsB; j++) SlcSS = SlcSS + wx2[i][j][k];
               variances[k] = SlcSS - (SlcSums[k] * SlcSums[k] / SlcCount[k]);
               variances[k] = variances[k] / (SlcCount[k] - 1.0);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG SLICES");
          value = 1e20;
          for (i = 0; i < Nf3cells;i++)  if (SlcCount[i] < value)  value = SlcCount[i];
          if (ScheffeChk->Checked)
               SCHEFFETEST(MSErr,SlcSums,SlcCount,minf3,maxf3,N,alpha);
          if ((TukeyHSDChk->Checked) && (equal_grp))
              TUKEY(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
          if ((TukeyBChk->Checked) && (equal_grp))
              TUKEYBTEST(MSErr,DFErr,SlcSums,SlcCount,minf3,maxf3,value,alpha);
          if ((TukeyKramerChk->Checked) && (equal_grp))
              TUKEY_KRAMER(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
          if (BonferroniChk->Checked)
             Bonferroni(SlcSums,SlcCount,variances,minf3,maxf3,alpha);
          if (OrthogonalChk->Checked)
              CONTRASTS(MSErr,DFErr,SlcSums,SlcCount,minf3,maxf3,OverallAlpha,alpha);
          if ((NewmanKeulsChk->Checked) && (equal_grp))
              Newman_Keuls(MSErr,DFErr,value,SlcSums,SlcCount,minf3,maxf3,alpha);
     }

     //  simple effects for columns within each row
     if (ProbF1F2 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH ROW");
          for (i = 0; i < Nf1cells; i++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"ROW %d COMPARISONS",i+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    for (k = 0; k < Nf3cells; k++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each column
     if (ProbF1F2 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH COLUMN");
          for (j = 0; j < Nf2cells; j++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"COLUMN %d COMPARISONS",j+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    for (k = 0; k < Nf3cells; k++)
                    {
                         cellsums[i] = wsum[i][j][k];
                         cellcnts[i] = ncnt[i][j][k];
                         cellvars[i] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }

     //  simple effects for columns within each slice
     if (ProbF2F3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG COLUMNS WITHIN EACH SLICE");
          for (k = 0; k < Nf3cells; k++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"SLICE %d COMPARISONS",k+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (j = 0; j < Nf2cells; j++)
               {
                    for (i = 0; i < Nf1cells; i++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (j = 0; j < Nf2cells; j++)  if (cellcnts[j] < value)  value = cellcnts[j];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf2,maxf2,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf2,maxf2,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf2,maxf2,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf2,maxf2,alpha);
          }
     }

     //  simple effects for rows within each slice
     if (ProbF1F3 < OverallAlpha)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          FrmOutPut->RichOutPut->Lines->Add("COMPARISONS AMONG ROWS WITHIN EACH SLICE");
          for (k = 0; k < Nf3cells; k++)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"SLICE %d COMPARISONS",k+1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               // move cell sums && counts to cellsums && cellcnts
               for (i = 0; i < Nf1cells; i++)
               {
                    for (j = 0; j < Nf2cells; j++)
                    {
                         cellsums[j] = wsum[i][j][k];
                         cellcnts[j] = ncnt[i][j][k];
                         cellvars[j] = wx2[i][j][k];
                    }
               }
               value = 1e20;
               for (i = 0; i < Nf1cells; i++)  if (cellcnts[i] < value)  value = cellcnts[i];
               if (ScheffeChk->Checked)
                  SCHEFFETEST(MSErr,cellsums,cellcnts,minf1,maxf1,N,alpha);
               if ((TukeyHSDChk->Checked) && (equal_grp))
                  TUKEY(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if ((TukeyBChk->Checked) && (equal_grp))
                  TUKEYBTEST(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,value,alpha);
               if ((TukeyKramerChk->Checked) && (equal_grp))
                  TUKEY_KRAMER(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
               if (BonferroniChk->Checked)
                  Bonferroni(cellsums,cellcnts,cellvars,minf1,maxf1,alpha);
               if (OrthogonalChk->Checked)
                  CONTRASTS(MSErr,DFErr,cellsums,cellcnts,minf1,maxf1,0.05,alpha);
               if ((NewmanKeulsChk->Checked) && (equal_grp))
                  Newman_Keuls(MSErr,DFErr,value,cellsums,cellcnts,minf1,maxf1,alpha);
          }
     }
     delete[] variances;
}


