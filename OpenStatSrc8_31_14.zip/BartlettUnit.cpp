//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "stdio.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "BartlettUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBartlettTestForm *BartlettTestForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TBartlettTestForm::TBartlettTestForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBartlettTestForm::ResetBtnClick(TObject *Sender)
{
        ChiSqrEdit->Text = "";
        ProbEdit->Text = "";
        DFEdit->Text = "";
        InBtn->Visible = true;
        OutBtn->Visible = false;
        VarList->Clear();
        SelList->Clear();
        for (int i = 1; i <= NoVariables; i++)
           VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TBartlettTestForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);         
}
//---------------------------------------------------------------------------
void __fastcall TBartlettTestForm::InBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              i = 0;
         }
         else i++;
     }
     OutBtn->Visible = true;
     if (VarList->Items->Count < 1) InBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBartlettTestForm::OutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     InBtn->Visible = true;
     if (SelList->Items->Count < 1) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBartlettTestForm::ComputeBtnClick(TObject *Sender)
{
        double **matrix;
        double **temp;
        double **eigenvectors;
        double *eigenvalues;
        double *means;
        double *stddevs;
        int * ColNoSelected;
        int i, j, k, df, p;
        double sumroots, determinant, chisquare, probability;
        double natlogdet, natlogp;
        char aline[121];
        int result, intvalue;
        double dblvalue;
        AnsiString strvalue;

        p = SelList->Items->Count;
        if (p < 3)
        {
                ShowMessage("You must have 3 or more variables for this test.");
                return;
        }
        GetDblMatMem(matrix,p,p);
        GetDblMatMem(temp,p,p);
        GetDblMatMem(eigenvectors,p,p);
        GetDblVecMem(eigenvalues,p);
        GetDblVecMem(means,p);
        GetDblVecMem(stddevs,p);
        GetIntVecMem(ColNoSelected,p);

        for (int j = 0; j < p; j++)
        {
                for (int i = 1; i <= NoVariables; i++)
                {
                        if (SelList->Items->Strings[j] == MainForm->Grid->Cells[i][0])
                        {
                             ColNoSelected[j] = i;
                        }
                }
        }

        FrmOutPut->RichOutPut->Clear();
        Correlations(means,stddevs,matrix,p,ColNoSelected,NoCases,3,false,0);
        MatPrint(matrix, p, p, ColNoSelected, "CORRELATION MATRIX");
        FrmOutPut->RichOutPut->Lines->Add("");
        determinant = Determ(matrix,p);
        natlogdet = log(determinant);
        sprintf(aline,"Determinant = %10.3f, log of determinant = %10.3f",natlogdet);
        FrmOutPut->RichOutPut->Lines->Add(aline);
        FrmOutPut->RichOutPut->Lines->Add("");
        chisquare = -((NoCases-1) - (2 * p - 5.0) / 6.0) * natlogdet;
        df = (p * p - p) / 2;
        probability = chisquaredprob(chisquare,df);
        sprintf(aline,"%8.3f",chisquare);
        ChiSqrEdit->Text = aline;
        sprintf(aline,"%6.4f",1.0-probability);
        ProbEdit->Text = aline;
        sprintf(aline,"%d",df);
        DFEdit->Text = aline;
        sprintf(aline,"Chi-square = %8.3f, D.F. = %d, Probability greater value = %6.4f",
           chisquare,df,1.0 - probability);
        FrmOutPut->RichOutPut->Lines->Add(aline);
        FrmOutPut->ShowModal();
finish:
        delete[] ColNoSelected;
        delete[] stddevs;
        delete[] eigenvalues;
        ClearDblMatMem(eigenvectors,p);
        ClearDblMatMem(temp,p);
        ClearDblMatMem(matrix,p);
}
//---------------------------------------------------------------------------
