//---------------------------------------------------------------------------

#ifndef JTUnitH
#define JTUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TJTForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *TrtIn;
        TBitBtn *TrtOut;
        TLabel *Label3;
        TListBox *TreatVars;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *OKBtn;
        TMemo *Memo1;
        TBitBtn *LabelIn;
        TBitBtn *LabelOut;
        TEdit *DependentEdit;
        TLabel *Label2;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall TrtInClick(TObject *Sender);
        void __fastcall TrtOutClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall LabelInClick(TObject *Sender);
        void __fastcall LabelOutClick(TObject *Sender);
private:	// User declarations
        int LabelPos;
        int *ColPos;
public:		// User declarations
        __fastcall TJTForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TJTForm *JTForm;
//---------------------------------------------------------------------------
#endif
