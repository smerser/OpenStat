//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EscapeUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEscForm *EscForm;
//---------------------------------------------------------------------------
__fastcall TEscForm::TEscForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEscForm::Button1Click(TObject *Sender)
{
     eschit = true;   
}
//---------------------------------------------------------------------------
void __fastcall TEscForm::FormShow(TObject *Sender)
{
     eschit = false;   
}
//---------------------------------------------------------------------------
