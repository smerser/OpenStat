//---------------------------------------------------------------------------
#ifndef canonH
#define canonH
//---------------------------------------------------------------------------
#endif
typedef double ** matrix;
typedef double *vector;
typedef int *intvector;

// prototypes

int canon();

