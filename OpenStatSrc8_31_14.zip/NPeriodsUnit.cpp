//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NPeriodsUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TNPeriodsFrm *NPeriodsFrm;
//---------------------------------------------------------------------------
__fastcall TNPeriodsFrm::TNPeriodsFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNPeriodsFrm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    PaymentEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0";     
}
//---------------------------------------------------------------------------
void __fastcall TNPeriodsFrm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TNPeriodsFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Payment, PresentValue, FutureVal, NPeriods;
     int When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentEdit->Text);
     Payment = StrToFloat(PaymentEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     FutureVal = StrToFloat(FutureEdit->Text);
     NPeriods = NumberOfPeriods(Rate, Payment, PresentValue, FutureVal, Time);
     NPeriodsEdit->Text = FloatToStr(NPeriods);
}
//---------------------------------------------------------------------------

