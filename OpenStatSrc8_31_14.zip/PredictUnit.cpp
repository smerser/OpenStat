//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PredictUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPredictForm *PredictForm;
//---------------------------------------------------------------------------
__fastcall TPredictForm::TPredictForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------

