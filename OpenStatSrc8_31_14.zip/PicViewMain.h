//---------------------------------------------------------------------------

#ifndef PicViewMainH
#define PicViewMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <FileCtrl.hpp>
#include <jpeg.hpp>
#include <Graphics.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TPicViewForm : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TDirectoryListBox *DirectoryListBox1;
    TFileListBox *FileListBox1;
    TLabel *Label1;
    TLabel *Label2;
    TButton *NextBtn;
    TButton *PreviousBtn;
    TButton *PrintBtn;
    TButton *QuitBtn;
    TLabel *Label3;
    TEdit *Edit1;
    TDriveComboBox *DriveComboBox1;
    TLabel *Label4;
    TButton *StretchBtn;
    TButton *RestoreBtn;
    TButton *ThumbBtn;
    TButton *DeleteBtn;
        TButton *RenameBtn;
        TSaveDialog *SaveDialog1;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DirectoryListBox1Click(TObject *Sender);
    void __fastcall FileListBox1Click(TObject *Sender);
    void __fastcall DriveComboBox1Click(TObject *Sender);
    void __fastcall NextBtnClick(TObject *Sender);
    void __fastcall QuitBtnClick(TObject *Sender);
    void __fastcall PreviousBtnClick(TObject *Sender);
    void __fastcall PrintBtnClick(TObject *Sender);
    void __fastcall StretchBtnClick(TObject *Sender);
    void __fastcall RestoreBtnClick(TObject *Sender);
    void __fastcall ThumbBtnClick(TObject *Sender);
    void __fastcall DeleteBtnClick(TObject *Sender);
        void __fastcall RenameBtnClick(TObject *Sender);
private:	// User declarations
    int picindex ;
    bool goodfile;
    AnsiString filename, extension;
    int top, howhi, left, howwide;
public:		// User declarations
    __fastcall TPicViewForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPicViewForm *PicViewForm;
//---------------------------------------------------------------------------
#endif
