//---------------------------------------------------------------------------

#ifndef FileSplitUnitH
#define FileSplitUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSplitFileForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *FirstFileEdit;
        TEdit *SecondFileEdit;
        TRadioGroup *SplitTypeGrp;
        TPanel *Panel1;
        TPanel *Panel2;
        TButton *CancelBtn;
        TButton *ReturnBtn;
        TButton *ComputeBtn;
        TLabel *Label3;
        TLabel *Label4;
        TRadioGroup *VertSelGrp;
        TEdit *SeqNoEdit;
        TLabel *VarLabel;
        TLabel *Label6;
        TEdit *SelVarEdit;
        TLabel *Label7;
        TEdit *SelValueEdit;
        TLabel *Label5;
        TLabel *Label9;
        TLabel *Label10;
        TListBox *VarList;
        TListBox *VarList2;
        TListBox *FileOneList;
        TListBox *FileTwoList;
        TBitBtn *File1InBtn;
        TBitBtn *File1OutBtn;
        TBitBtn *File2InBtn;
        TBitBtn *File2OutBtn;
        TButton *ResetBtn;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall SplitTypeGrpClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall VarListClick(TObject *Sender);
        void __fastcall VertSelGrpClick(TObject *Sender);
        void __fastcall File1InBtnClick(TObject *Sender);
        void __fastcall File1OutBtnClick(TObject *Sender);
        void __fastcall File2InBtnClick(TObject *Sender);
        void __fastcall File2OutBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TSplitFileForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSplitFileForm *SplitFileForm;
//---------------------------------------------------------------------------
#endif
