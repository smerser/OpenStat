//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <Printers.hpp>
#include "ThumbnailsUnit.h"
#include "Clipbrd.hpp"
#include "PicViewMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPicViewForm *PicViewForm;
//---------------------------------------------------------------------------
__fastcall TPicViewForm::TPicViewForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TPicViewForm::FormShow(TObject *Sender)
{
//     Image1->Left = 184;
//     Image1->Top = 32;
//     Image1->Width = 489;
//     Image1->Height = 561;
     Image1->Stretch = true;
     Image1->AutoSize = false;
     top = Image1->Top;
     left = Image1->Left;
     howwide = Image1->Width;
     howhi = Image1->Height;
     Clipboard()->Assign(Image1->Picture);

}
//---------------------------------------------------------------------------

void __fastcall TPicViewForm::DirectoryListBox1Click(TObject *Sender)
{
     FileListBox1->Directory = DirectoryListBox1->Directory;
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::FileListBox1Click(TObject *Sender)
{
     picindex = FileListBox1->ItemIndex - 1;
     NextBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::DriveComboBox1Click(TObject *Sender)
{
  DirectoryListBox1->Drive = DriveComboBox1->Drive;
  FileListBox1->Drive = DriveComboBox1->Drive;
  FileListBox1->Directory = DirectoryListBox1->Directory;
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::NextBtnClick(TObject *Sender)
{
     AnsiString msg;

start:
     picindex = picindex + 1;
     if (picindex > FileListBox1->Items->Count - 1) picindex = 0;
     goodfile = false;
     filename = FileListBox1->Items->Strings[picindex];
     extension = ExtractFileExt(filename);
     if ( (extension == ".jpg") || (extension == ".bmp")
        || (extension == ".JPG") || (extension == ".BMP")
        || (extension == ".wmf") || (extension == ".WMF")
        || (extension == ".ico") || (extension == ".ICO")
        || (extension == ".jpeg") || (extension == ".JPEG") ) goodfile = true;
     else goto start;
//     {
//          msg = "Cannot show a file of type " + extension;
//          ShowMessage(msg);
//     }
     if (goodfile)
     {
          Image1->Picture->LoadFromFile(filename);
          Edit1->Text = filename;
     }
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::QuitBtnClick(TObject *Sender)
{
     return;    
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::PreviousBtnClick(TObject *Sender)
{
     picindex = picindex - 2;
     if (picindex < -1) picindex = -1;
     NextBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::PrintBtnClick(TObject *Sender)
{
    double AspectRatio;
    double OutputWidth, OutputHeight;
    int topindent, leftindent;

    TPrinter *Printr = Printer();
    if (Image1->Picture->Width > Image1->Picture->Height) Printr->Orientation = poLandscape;
    else Printr->Orientation = poPortrait;
    Printr->BeginDoc();
    OutputWidth = Image1->Picture->Width;
    OutputHeight = Image1->Picture->Height;
    AspectRatio = OutputWidth / OutputHeight;
    if ((OutputWidth < Printr->PageWidth) &&
       (OutputHeight < Printr->PageHeight))
    {
       if (OutputWidth < OutputHeight)
       {
          OutputHeight = Printr->PageHeight;
          OutputWidth = OutputHeight * AspectRatio;
       }
    }
    else
    {
        OutputWidth = Printr->PageWidth;
        OutputHeight = OutputWidth / AspectRatio;
    }

    if (OutputWidth > Printr->PageWidth)
    {
        OutputWidth = Printr->PageWidth;
        OutputHeight = OutputWidth / AspectRatio;
    }
    if (OutputHeight > Printr->PageHeight)
    {
        OutputHeight = Printr->PageHeight;
        OutputWidth = OutputHeight * AspectRatio;
    }
    topindent = Printr->PageHeight / 20;
    leftindent = Printr->PageWidth / 20;
    Printr->Canvas->StretchDraw(Rect(leftindent,topindent,
      (OutputWidth-2*leftindent), (OutputHeight-2*leftindent)),
      Image1->Picture->Graphic);
    Printr->EndDoc();
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::StretchBtnClick(TObject *Sender)
{
     Image1->Stretch = true;
     Image1->AutoSize = true;
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::RestoreBtnClick(TObject *Sender)
{
     Image1->Stretch = true;
     Image1->AutoSize = false;
     Image1->Top = top;
     Image1->Left = left;
     Image1->Width = howwide;
     Image1->Height = howhi;
}
//---------------------------------------------------------------------------
void __fastcall TPicViewForm::ThumbBtnClick(TObject *Sender)
{
     ThumbnailsForm->ShowModal();
     if (ThumbnailsForm->picno > 0)
     {
        picindex = ThumbnailsForm->picno - 1;
        NextBtnClick(this);
     }
}
//---------------------------------------------------------------------------

void __fastcall TPicViewForm::DeleteBtnClick(TObject *Sender)
{
     AnsiString msg, response;

     msg = "Delete file " + filename;
     response = InputBox("Delete?",msg,"Y");
     if (response == "Y") DeleteFile(filename);
     FileListBox1->Items->Delete(picindex);
}
//---------------------------------------------------------------------------

void __fastcall TPicViewForm::RenameBtnClick(TObject *Sender)
{
        AnsiString oldname, newname, extension;
        bool result, goodfile;

        oldname = ExtractFileName(Edit1->Text);
        SaveDialog1->FileName = oldname;
        SaveDialog1->DefaultExt = "jpg";
        SaveDialog1->FilterIndex = 1;
        SaveDialog1->Filter = "Graphic File (*.jpg)|*.JPG|JPEG File (*.jpeg)|*.JPEG|BitMap (*.bmp)|*.BMP|Meta File (*.wmf)|*.WMF|Icon File (*.ico)|*.ICO";
        if (SaveDialog1->Execute())
        {
                newname = SaveDialog1->FileName;
                extension = ExtractFileExt(newname);
                if ( (extension == ".jpg") || (extension == ".bmp")
                        || (extension == ".JPG") || (extension == ".BMP")
                        || (extension == ".wmf") || (extension == ".WMF")
                        || (extension == ".ico") || (extension == ".ICO")
                        || (extension == ".jpeg") || (extension == ".JPEG") ) goodfile = true;
                else goodfile = false;
                if (goodfile)
                {
                        result = RenameFile(oldname,newname);
                        if (!result) goodfile = false;
                }
                if (goodfile == false)
                         ShowMessage("File already exists or can't save with that extension.");
        }
}
//---------------------------------------------------------------------------

