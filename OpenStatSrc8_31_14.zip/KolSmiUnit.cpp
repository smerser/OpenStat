//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "dcdflib.h"
#include "stdio.h"
#include <math.h>
#include "Printers.hpp"
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include "functions.h"
#include "FrmFDSpecs.h"
#include "GraphUnit.h"
#include "KolSmiUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

TKSForm *KSForm;
//---------------------------------------------------------------------------
__fastcall TKSForm::TKSForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKSForm::ResetBtnClick(TObject *Sender)
{
     int Yincr, Xincr;

     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     ObservedEdit->Text = "";
     Observed2Edit->Text = "";
     FrequencyEdit->Text = "";
     GroupEdit->Text = "";
     FrequencyEdit->Visible = false;
     FreqIn->Visible = false;
     FreqOut->Visible = false;
     FreqLabel->Visible = false;
     TypeGrp->ItemIndex = 0;
     CompareGrp->ItemIndex = 2;
     ObsInBtn->Visible = true;
     ObsOutBtn->Visible = false;
     PlotChk->Checked = true;
     PrintChk->Checked = true;
     CumDistChk->Checked = true;
     GroupLabel->Visible = false;
     GroupIn->Visible = false;
     GroupOut->Visible = false;
     GroupEdit->Visible = false;
     Obs2InBtn->Visible = false;
     Obs2OutBtn->Visible = false;
     Observed2Edit->Visible = false;
     PlotTypeGrp->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void __fastcall TKSForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::ObsInBtnClick(TObject *Sender)
{
     int index;
     index = VarList->ItemIndex;
     ObservedEdit->Text = VarList->Items->Strings[index];
     ObsInBtn->Visible = false;
     ObsOutBtn->Visible = true;
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::ObsOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(ObservedEdit->Text);
     ObservedEdit->Text = "";
     ObsOutBtn->Visible = false;
     ObsInBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::ComputeBtnClick(TObject *Sender)
{
     double *ObsData;      // observed proportion of values (group 1)
     double *CompData;     // comparison proportion of values (theoretical or group 2)
     double *freq;         // frequency of observed values (group 1)
     double *freqcomp;     // frequency of comparison values (theoretical/group 2)
     double *cumfreq;      // cumulative frequency of observed values (group 1)
     double *cumfreqcomp;  // cumulative frequency of comparison values
     double *pcnt;         // percent of an observed value
     double *comppcnt;     // percent of a comparison value
     double *cumpcnt;      // cumulative percent of observed value percentages
     double *cumpcntcomp;  // cumulative percent of comparison value percentages
     double *pcntilerank;  // percentile ranks of observed values
     double *comppcntilerank; // percentile ranks of comparison values
     double *XValue;       // values for the intervals plotted
     AnsiString FreqLbl, GroupLbl;  // variable labels
     int ObsCol = 0, Obs2Col = 0, FreqCol = 0, CompareTo, NoCats, Ncases, N;
     int GroupCol = 0, combo;
     double x, y, D, Dif, KS;
     AnsiString Caption, Xlabel, Ylabel, CellVal;
     char title[100], outstr[121];
     double s, xn, pr, ompr;
     bool freqinput = false; // true if frequencies are read for the values, counted otherwise
     bool twogroups = false; // true if comparing two group distributions
     bool inerror = false;   // true if there is an error in variable input
     bool cumdist = false;   // true if cumulative distribution plot wanted
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     if (TypeGrp->ItemIndex == 1) freqinput = true;
     if (CumDistChk->Checked) cumdist = true;
     CompareTo = CompareGrp->ItemIndex;
     plottype = PlotTypeGrp->ItemIndex + 6;
//     if ((CompareTo == 0) && (TypeGrp->ItemIndex == 0)) twogroups = true;
     if (CompareTo == 0) twogroups = true;
     if ((TypeGrp->ItemIndex == 0) && (CompareGrp->ItemIndex == 0)) combo = 1;
     if ((TypeGrp->ItemIndex == 0) && (CompareGrp->ItemIndex > 0)) combo = 2;
     if ((TypeGrp->ItemIndex == 1) && (CompareGrp->ItemIndex == 0)) combo = 3;
     if ((TypeGrp->ItemIndex == 1) && (CompareGrp->ItemIndex > 0)) combo = 4;
     if ((TypeGrp->ItemIndex == 2) && (CompareTo == 0)) combo = 5;
     // combo = 1 indicates count of values for observed and comparison groups
     // combo = 2 indicates count of values for observed and a theoretical comparison
     // combo = 3 indicates frequency of values for observed and comparison groups
     // combo = 4 indicates frequency of values for observed and theoretical comparison
     // combo = 5 indicates count of values in two separate columns

     // get variable labels and column numbers
     ObsLabel = ObservedEdit->Text;  // values for the distribution(s)
     if (combo == 5) CompLabel = Observed2Edit->Text;
     if (freqinput) FreqLbl = FrequencyEdit->Text;
     if (twogroups) GroupLbl = GroupEdit->Text;

     for (int i = 0; i < NoVariables; i++)
     {
         if (ObsLabel == MainForm->Grid->Cells[i+1][0]) ObsCol = i+1;
         if (freqinput)
         {
            if (FreqLbl == MainForm->Grid->Cells[i+1][0]) FreqCol = i+1;
         }
         if (twogroups)
         {
            if (GroupLbl == MainForm->Grid->Cells[i+1][0]) GroupCol = i+1;
         }
         if (combo == 5)
         {
            if (CompLabel == MainForm->Grid->Cells[i+1][0]) Obs2Col = i+1;
         }
     }

     // check for input errors
     if (ObsCol == 0) inerror = true;
     if (freqinput == true)
     {
        if (FreqCol == 0) inerror = true;
     }
     if (twogroups)
     {
        if ((GroupCol == 0) && (combo != 5)) inerror = true;
     }
     if (combo == 5)
     {
        if (Obs2Col == 0) inerror = true;
     }
     if (inerror)
     {
        ShowMessage("ERROR! At least one variable has not been selected.");
        return;
     }
/*
     result = VarTypeChk(ObsCol,0);
     if (result == 1) return;
     if (combo == 5)
     {
        result = VarTypeChk(Obs2Col,0);
        if (result == 1) return;
     }

     if (freqinput)
     {
        result = VarTypeChk(FreqCol,1);
        if (result == 1) return;
     }
     if (twogroups)
     {
        result = VarTypeChk(GroupCol,1);
        if (result == 1) return;
     }
*/
     N = NoCases; // get maximum number of cases (values)
     // allocate heap space
     GetDblVecMem(ObsData,N+2);
     GetDblVecMem(CompData,N+2);
     GetDblVecMem(freq,N+2);
     GetDblVecMem(pcnt,N+2);
     GetDblVecMem(comppcnt,N+2);
     GetDblVecMem(cumpcnt,N+2);
     GetDblVecMem(pcntilerank,N+2);
     GetDblVecMem(cumfreq,N+2);
     GetDblVecMem(XValue,N+2);
     GetDblVecMem(freqcomp,N+2);
     GetDblVecMem(cumpcntcomp,N+2);
     GetDblVecMem(cumfreqcomp,N+2);
     GetDblVecMem(comppcntilerank,N+2);

     // Get min and max values for the values variable
     min = 1.0e32;
     max = -1.0e32;
     ObsMean = 0.0;
     ObsStdDev = 0.0;
     Ncases = 0;
     for (int j = 1; j <= NoCases; j++)
     {
        if (! ValidValue(j,ObsCol)) continue;
        if (combo == 5)
        {
           if (! ValidValue(j,Obs2Col)) continue;
        }
        value = StrToFloat(MainForm->Grid->Cells[ObsCol][j]);
        //result = GetValue(j,ObsCol,intvalue,dblvalue,strvalue);
        //if (result == 1) value = 0.0;
        //else value = dblvalue;
        if (value < min) min = value;
        if (value > max) max = value;
        if (!freqinput)
        {
           Ncases++;
           ObsMean += value;
           ObsStdDev += value * value;
        }
        else // get frequency of this value
        {
           int F;
           F = floor(StrToFloat(MainForm->Grid->Cells[FreqCol][j]));
           //result = GetValue(j,FreqCol,intvalue,dblvalue,strvalue);
           //if (result == 1) F = 0;
           //else F = intvalue;
           Ncases += F;
           ObsMean += (value * F);
           ObsStdDev += (value * value * F);
        }
        if (combo == 5)
        {
           value = StrToFloat(MainForm->Grid->Cells[Obs2Col][j]);
           //result = GetValue(j,Obs2Col,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           if (value < min) min = value;
           if (value > max) max = value;
           if (!freqinput)
           {
              Ncases++;
              ObsMean += value;
              ObsStdDev += value * value;
           }
        }
     } // get next case

     ObsStdDev = ObsStdDev - (ObsMean * ObsMean / Ncases);
     ObsStdDev /= (Ncases - 1.0);
     ObsStdDev = sqrt(ObsStdDev);
     ObsMean /= Ncases;
     range = max - min + 1.0;
     incrsize = 1.0;
     // if too many increments, set increment size for 15 increments
     if (range > 200.0) incrsize = range / 15;
     nointervals = range / incrsize;
     nints = ceil(nointervals);
     // get user approval and / or changes
     FDSpecs->TxtVariable->Text = CellVal;
     FDSpecs->TxtMin->Text = FloatToStr(min);
     FDSpecs->TxtMax->Text = FloatToStr(max);
     FDSpecs->TxtRange->Text = FloatToStr(range);
     FDSpecs->TxtIntSize->Text = FloatToStr(incrsize);
     FDSpecs->TxtNoIntervals->Text = IntToStr(nints);
again:  FDSpecs->ShowModal();
     incrsize = StrToFloat(FDSpecs->TxtIntSize->Text);
     nointervals = StrToFloat(FDSpecs->TxtNoIntervals->Text);
     nints = ceil(nointervals);
     if (nints > NoCases)
     {
           ShowMessage("Error!  No. of intervals cannot be greater than no. of cases!");
           goto again;
     }
     // store values of the categories
     for (int j = 0; j < nints+1; j++) XValue[j] = min + (j * incrsize);

     for (int i = 0; i <= nints; i++)
     {
        freq[i] = 0.0;
        freqcomp[i] = 0.0;
        ObsData[i] = 0.0;
        CompData[i] = 0.0;
     }

     // this next section is for input of data under the various combinations
     switch (combo)
     {
        case 1 : GetCombo1Data(GroupCol,ObsCol,freq,freqcomp,ObsData,CompData); break;
        case 2 : GetCombo2Data(ObsCol,CompareTo,freq,freqcomp,XValue,ObsData,CompData); break;
        case 3 : GetCombo3Data(GroupCol,ObsCol,FreqCol,freq,freqcomp,ObsData,CompData); break;
        case 4 : GetCombo4Data(ObsCol,FreqCol,CompareTo,freq,freqcomp,ObsData,CompData,XValue); break;
        case 5 : GetCombo5Data(ObsCol,Obs2Col,freq,freqcomp,ObsData,CompData); break;
     }

     int Ncases1 = 0;
     int Ncases2 = 0;
     // Get number of cases in observed and comparison groups
     for (int i = 0; i <= nints; i++)
     {
        Ncases1 += freq[i];
        Ncases2 += freqcomp[i];
     }

     // get cumulative frequencies and percents to midpoints of frequencies for observed
     cumfreq[0] = freq[0];
     cumfreqcomp[0] = freqcomp[0];
     pcnt[0] = freq[0] / Ncases1;
     comppcnt[0] = freqcomp[0] / Ncases2;
     cumpcnt[0] = pcnt[0];
     cumpcntcomp[0] = comppcnt[0];
     pcntilerank[0] = (freq[0] / 2.0) / Ncases1;
     comppcntilerank[0] = (freqcomp[0] / 2.0) / Ncases2;
     for (int k = 2; k <= nints; k++)
     {
           cumfreq[k-1] = cumfreq[k-2] + freq[k-1];
           pcnt[k-1] = freq[k-1] / Ncases1;
           cumpcnt[k-1] = cumfreq[k-1] / Ncases1;
           pcntilerank[k-1] = (cumfreq[k-2] + freq[k-1] / 2.0) / Ncases1;

           cumfreqcomp[k-1] = cumfreqcomp[k-2] + freqcomp[k-1];
           comppcnt[k-1] = freqcomp[k-1] / Ncases2;
           cumpcntcomp[k-1] = cumfreqcomp[k-1] / Ncases2;
           comppcntilerank[k-1] = (cumfreqcomp[k-2] + freqcomp[k-1] / 2.0) / Ncases2;
     }

     // Print results of observed data (or group 1)
     FrmOutPut->RichOutPut->Lines->Add("Kolmogorov-Smirnov Test");
     FrmOutPut->RichOutPut->Lines->Add("Analysis of variable " + ObsLabel);
     FrmOutPut->RichOutPut->Lines->Add("    FROM  UP TO     FREQ.   PCNT    CUM.FREQ.  CUM.PCNT. %ILE RANK");
     FrmOutPut->RichOutPut->Lines->Add("");
     for (int k = 1; k <= nints; k++)
     {
            sprintf(outstr,"%8.2f%8.2f%8.3f%8.3f  %8.3f  %8.3f  %8.3f",
               min+(k-1) * incrsize, // from
               min + k * incrsize,   // to
               freq[k-1],            // freq
               pcnt[k-1],            // percent
               cumfreq[k-1],         // cumulative freqency
               cumpcnt[k-1],         // cumulative percent to midpoint
               pcntilerank[k-1]);    // percentile rank
            FrmOutPut->RichOutPut->Lines->Add(outstr);
     }
     FrmOutPut->RichOutPut->Lines->Add("");

     // Print results of comparison data (or group 2)
     FrmOutPut->RichOutPut->Lines->Add("Kolmogorov-Smirnov Test");
     FrmOutPut->RichOutPut->Lines->Add("Analysis of Comparison Group");
     FrmOutPut->RichOutPut->Lines->Add("    FROM  UP TO     FREQ.   PCNT    CUM.FREQ.  CUM.PCNT. %ILE RANK");
     FrmOutPut->RichOutPut->Lines->Add("");
     for (int k = 1; k <= nints; k++)
     {
            sprintf(outstr,"%8.2f%8.2f%8.3f%8.3f  %8.3f  %8.3f  %8.3f",
               min+(k-1) * incrsize, // from
               min + k * incrsize,   // to
               freqcomp[k-1],        // freq of comparison group
               comppcnt[k-1],        // percent
               cumfreqcomp[k-1],     // cumulative freqency
               cumpcntcomp[k-1],     // cumulative percent to midpoint
               comppcntilerank[k-1]);// percentile rank
            FrmOutPut->RichOutPut->Lines->Add(outstr);
     }
     FrmOutPut->RichOutPut->Lines->Add("");

     Caption = "Kolmogorov-Smirnov Analysis of " + ObsLabel + " and Comparison" ;
     FrmOutPut->RichOutPut->Lines->Add(Caption);
     sprintf(title,"Observed Mean = %10.3f for %5d cases in %5d categories",
             ObsMean,Ncases,nints);
     FrmOutPut->RichOutPut->Lines->Add(title);
     sprintf(title,"Standard Deviation = %10.3f",ObsStdDev);
     FrmOutPut->RichOutPut->Lines->Add(title);
     FrmOutPut->RichOutPut->Lines->Add("");
/*
     // print observed and comparison probabilties
     FrmOutPut->RichOutPut->Lines->Add("Kolmogorov-Smirnov Distribution Comparison");
     FrmOutPut->RichOutPut->Lines->Add("CATEGORY  OBSERVED       COMPARISON");
     FrmOutPut->RichOutPut->Lines->Add("VALUES    PROBABILITIES  PROBABILITIES");
     for (int i = 0; i < nints; i++)
     {
         sprintf(title,"%5.0f     %10.3f     %10.3f",XValue[i],ObsData[i],CompData[i]);
         FrmOutPut->RichOutPut->Lines->Add(title);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
*/
     cumpcntcomp[0] = CompData[0];
     for (int i = 1; i <= nints; i++) cumpcntcomp[i] = cumpcntcomp[i-1] + CompData[i];
     for (int i = 0; i <= nints; i++) CompData[i] = cumpcntcomp[i];
     CompData[nints] = 1.0;
     cumpcnt[nints] = 1.0;
     for (int i = 0; i <= nints; i++) ObsData[i] = cumpcnt[i];

     // print observed and comparison cumulative probabilties
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Kolmogorov-Smirnov Distribution Comparison");
     FrmOutPut->RichOutPut->Lines->Add("CATEGORY  OBSERVED       COMPARISON     DIFFERENCE");
     FrmOutPut->RichOutPut->Lines->Add("VALUE     CUM. PROB.     CUM. PROB.     CUM. PROB.");
     for (int i = 0; i < nints+1; i++)
     {
         sprintf(title,"%5.0f     %10.3f     %10.3f     %10.3f",
            XValue[i],ObsData[i],CompData[i],(ObsData[i] - CompData[i]));
         FrmOutPut->RichOutPut->Lines->Add(title);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     heading = "Frequency Distribution";
     ytitle = "Frequency";
     if (PlotChk->Checked) PlotIt(freq, freqcomp, XValue);
     heading = "Cumulative Probability Distribution";
     ytitle = "Probability";
     if (cumdist) PlotIt(ObsData,CompData,XValue);
     
     // calculate the K-S statistics
     D = 0.0;
     for (int i = 0; i <= nints; i++)
     {
         Dif = fabs(ObsData[i] - CompData[i]);
         if (Dif > D) D = Dif;
     }
     KS = KSProb(D,Ncases);
     sprintf(title,"Kolmogorov-Smirnov Statistic D = %10.3f with probability > D = %10.3f",
             D,KS);
     FrmOutPut->RichOutPut->Lines->Add(title);
     FrmOutPut->ShowModal();

     delete[] comppcntilerank;
     delete[] cumfreqcomp;
     delete[] cumpcntcomp;
     delete[] comppcnt;
     delete[] freqcomp;
     delete[] XValue;
     delete[] cumfreq;
     delete[] pcntilerank;
     delete[] cumpcnt;
     delete[] pcnt;
     delete[] freq;
     delete[] CompData;
     delete[] ObsData;
}
//---------------------------------------------------------------------------

double TKSForm::KSProb(double D, int N)
{
     double Eps1 = 0.001, Eps2 = 1.0E-8, A2, Fac, Prob, Termbf, Term;

     D = sqrt(N) * D;
     A2 = -2.0 * D * D;
     Fac = 2.0;
     Prob = 0.0;
     Termbf = 0.0;
     for (int j = 1; j <= 100; j++)
     {
          Term = Fac * exp(A2 * j * j);
          Prob += Term;
          if ((fabs(Term) < Eps1 * Termbf) || (fabs(Term) < Eps2 * Prob)) return (Prob);
          Fac = -Fac;
          Termbf = fabs(Term);
     }
     Prob = 1.0; // only if we don't converge above
     return (Prob);
}
//---------------------------------------------------------------------------


void __fastcall TKSForm::FreqInClick(TObject *Sender)
{
     int index;
     index = VarList->ItemIndex;
     FrequencyEdit->Text = VarList->Items->Strings[index];
     FreqIn->Visible = false;
     FreqOut->Visible = true;
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::FreqOutClick(TObject *Sender)
{
     VarList->Items->Add(FrequencyEdit->Text);
     FrequencyEdit->Text = "";
     FreqOut->Visible = false;
     FreqIn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::TypeGrpClick(TObject *Sender)
{
     if ((TypeGrp->ItemIndex == 1) && (CompareGrp->ItemIndex > 0))
     {   // frequency input for observed group but no comparison group
        FrequencyEdit->Visible = true;  // 1
        FreqIn->Visible = true;         // 2
        FreqOut->Visible = false;       // 3
        FreqLabel->Visible = true;      // 4
        GroupLabel->Visible = false;    // 1
        GroupIn->Visible = false;       // 2
        GroupOut->Visible = false;      // 3
        GroupEdit->Visible = false;     // 4
        Values2Label->Visible = false;  // 1
        Observed2Edit->Visible = false; // 2
        Obs2InBtn->Visible = false;     // 3
        Obs2OutBtn->Visible = false;    // 4
     }
     if ((TypeGrp->ItemIndex == 1) && (CompareGrp->ItemIndex == 0))
     {  // frequency input for observed and also a commparison group in same col.
        FrequencyEdit->Visible = true;
        FreqIn->Visible = true;
        FreqOut->Visible = false;
        FreqLabel->Visible = true;
        GroupLabel->Visible = true;
        GroupIn->Visible = true;
        GroupOut->Visible = false;
        GroupEdit->Visible = true;
        Values2Label->Visible = false;
        Observed2Edit->Visible = false;
        Obs2InBtn->Visible = false;
        Obs2OutBtn->Visible = false;
     }
     if ((TypeGrp->ItemIndex == 0) && (CompareGrp->ItemIndex > 0))
     {  // count for observed variable and no observed comparison group
        FrequencyEdit->Visible = false;
        FreqIn->Visible = false;
        FreqOut->Visible = false;
        FreqLabel->Visible = false;
        GroupLabel->Visible = false;
        GroupIn->Visible = false;
        GroupOut->Visible = false;
        GroupEdit->Visible = false;
        Values2Label->Visible = false;
        Observed2Edit->Visible = false;
        Obs2InBtn->Visible = false;
        Obs2OutBtn->Visible = false;
     }
     if ((TypeGrp->ItemIndex == 0) && (CompareGrp->ItemIndex == 0))
     {  // count for both observed and comparison groups
        FrequencyEdit->Visible = false;
        FreqIn->Visible = false;
        FreqOut->Visible = false;
        FreqLabel->Visible = false;
        GroupLabel->Visible = true;
        GroupIn->Visible = true;
        GroupOut->Visible = false;
        GroupEdit->Visible = true;
        Values2Label->Visible = false;
        Observed2Edit->Visible = false;
        Obs2InBtn->Visible = false;
        Obs2OutBtn->Visible = false;
     }
     if ((TypeGrp->ItemIndex == 2) && (CompareGrp->ItemIndex == 0))
     {  // count observed values in two different columns
        FrequencyEdit->Visible = false;
        FreqIn->Visible = false;
        FreqOut->Visible = false;
        FreqLabel->Visible = false;
        GroupLabel->Visible = false;
        GroupIn->Visible = false;
        GroupOut->Visible = false;
        GroupEdit->Visible = false;
        Values2Label->Visible = true;
        Observed2Edit->Visible = true;
        Obs2InBtn->Visible = true;
        Obs2OutBtn->Visible = false;
     }
     if ((TypeGrp->ItemIndex == 2) && (CompareGrp->ItemIndex > 0))
     {  // count observed values in two different columns
        FrequencyEdit->Visible = false;
        FreqIn->Visible = false;
        FreqOut->Visible = false;
        FreqLabel->Visible = false;
        GroupLabel->Visible = false;
        GroupIn->Visible = false;
        GroupOut->Visible = false;
        GroupEdit->Visible = false;
        Values2Label->Visible = false;
        Observed2Edit->Visible = false;
        Obs2InBtn->Visible = false;
        Obs2OutBtn->Visible = false;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GroupInClick(TObject *Sender)
{
     int index;
     index = VarList->ItemIndex;
     GroupEdit->Text = VarList->Items->Strings[index];
     GroupIn->Visible = false;
     GroupOut->Visible = true;
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GroupOutClick(TObject *Sender)
{
     VarList->Items->Add(GroupEdit->Text);
     GroupEdit->Text = "";
     GroupOut->Visible = false;
     GroupIn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::CompareGrpClick(TObject *Sender)
{
        TypeGrpClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GetCombo1Data(int GroupCol, int ObsCol,
          double *ObsFreq, double *CompFreq, double *ObsData, double *CompData)
{
     // combo = 1 indicates count of values for observed and comparison groups
     int grp;
     int Ncases1 = 0;
     int Ncases2 = 0;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,ObsCol)) continue;
           value = StrToFloat(MainForm->Grid->Cells[ObsCol][i]);
           //result = GetValue(i,ObsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           grp = floor(StrToFloat(MainForm->Grid->Cells[GroupCol][i]));
           //result = GetValue(i,GroupCol,intvalue,dblvalue,strvalue);
           //if (result == 1) grp = 0;
           //else grp = intvalue;
           if (grp == 1)
           {
              Ncases1++;
              for (int k = 1; k <= nints; k++)
              {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         ObsFreq[k-1]++;
              }
           }
           if (grp == 2)
           {
              Ncases2++;
              for (int k = 1; k <= nints; k++)
              {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         CompFreq[k-1]++;
              }
           }
     }
     //store proportions in ObsData
     for (int j = 0; j < nints+1; j++)
     {
            ObsData[j] = ObsFreq[j] / Ncases1;
            CompData[j] = CompFreq[j] / Ncases2;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GetCombo2Data(int ObsCol, int CompareTo, double *ObsFreq,
          double *freqcomp, double *XValue, double *ObsData, double *CompData)
{
     // combo = 2 indicates count of values for observed and a theoretical comparison
     int Ncases = 0;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,ObsCol)) continue;
           Ncases++;
           value = StrToFloat(MainForm->Grid->Cells[ObsCol][i]);
           //result = GetValue(i,ObsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           for (int k = 1; k <= nints; k++)
           {
                if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         ObsFreq[k-1]++;
           }
     }
     GetTheoretical(CompareTo, Ncases, CompData, XValue,freqcomp);
     for (int j = 0; j < nints+1; j++)
     {
            ObsData[j] = ObsFreq[j] / Ncases;   // proportion observed
     }
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GetCombo3Data(int GroupCol, int ObsCol, int FreqCol,
          double *ObsFreq, double *CompFreq, double *ObsData, double *CompData)
{
     // combo = 3 indicates frequency of values for observed and comparison groups
     int grp;
     int Ncases1 = 0;
     int Ncases2 = 0;
     double F;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,ObsCol)) continue;
           value = StrToFloat(MainForm->Grid->Cells[ObsCol][i]);
           //result = GetValue(i,ObsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           grp = floor(StrToFloat(MainForm->Grid->Cells[GroupCol][i]));
           //result = GetValue(i,GroupCol,intvalue,dblvalue,strvalue);
           //if (result == 1) grp = 0;
           //else grp = intvalue;
           F = StrToFloat(MainForm->Grid->Cells[FreqCol][i]);
           //result = GetValue(i,FreqCol,intvalue,dblvalue,strvalue);
           //if (result == 1) F = 0.0;
           //else F = (double) intvalue;
           if (grp == 1)
           {
              Ncases1 += F;
              for (int k = 1; k <= nints; k++)
              {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         ObsFreq[k-1]+= F;
              }
           }
           if (grp == 2)
           {
              Ncases2 += F;
              for (int k = 1; k <= nints; k++)
              {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         CompFreq[k-1]+= F;
              }
           }
     }

     //store proportions in ObsData
     for (int j = 0; j < nints+1; j++)
     {
            ObsData[j] = ObsFreq[j] / Ncases1;
            CompData[j] = CompFreq[j] / Ncases2;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GetCombo4Data(int ObsCol, int FreqCol, int CompareTo,
          double *freq, double *freqcomp, double *ObsData, double *CompData,
          double *XValue)
{
     // combo = 4 indicates frequency of values for observed and theoretical comparison
     int Ncases = 0;
     double F;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,ObsCol)) continue;
           value = StrToFloat(MainForm->Grid->Cells[ObsCol][i]);
           //result = GetValue(i,ObsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           F = StrToFloat(MainForm->Grid->Cells[FreqCol][i]);
           //result = GetValue(i,FreqCol,intvalue,dblvalue,strvalue);
           //if (result == 1) F = 0.0;
           //else F = (double) intvalue;
           Ncases += F;
           for (int k = 1; k <= nints; k++)
           {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         freq[k-1]+= F;
           }
     }
     GetTheoretical(CompareTo, Ncases, CompData, XValue, freqcomp);

     //store proportions in ObsData
     for (int j = 0; j < nints+1; j++)
     {
            ObsData[j] = freq[j] / Ncases;
     }
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::GetCombo5Data(int ObsCol, int Obs2Col, double *ObsFreq,
       double *CompFreq, double *ObsData, double *CompData)
{
     int Ncases1 = 0;
     int Ncases2 = 0;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,ObsCol)) continue;
           value = StrToFloat(MainForm->Grid->Cells[ObsCol][i]);
           //result = GetValue(i,ObsCol,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           Ncases1++;
           for (int k = 1; k <= nints; k++)
           {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         ObsFreq[k-1]++;
           }
     }

     for (int i = 1; i <= NoCases; i++)
     {
           if (!ValidValue(i,Obs2Col)) continue;
           value = StrToFloat(MainForm->Grid->Cells[Obs2Col][i]);
           //result = GetValue(i,Obs2Col,intvalue,dblvalue,strvalue);
           //if (result == 1) value = 0.0;
           //else value = dblvalue;
           Ncases2++;
           for (int k = 1; k <= nints; k++)
           {
                 if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
                         CompFreq[k-1]++;
           }
      }
     //store proportions in ObsData
     for (int j = 0; j < nints+1; j++)
     {
            ObsData[j] = ObsFreq[j] / Ncases1;
            CompData[j] = CompFreq[j] / Ncases2;
     }
}
//---------------------------------------------------------------------------


void __fastcall TKSForm::GetTheoretical(int CompareTo, int Ncases, double *CompData,
          double *XValue, double *freqcomp)
{
     // routine to generate theoretical values
     double X, zlow, zhi, zprophi, zproplow, zfreq;
     for (int i = 0; i < nints; i++)
     {
           switch (CompareTo)
           {
              case 1: // rectangular
              {
                 X = (double) Ncases / double (nints);
                 CompData[i] = X;
              } break;
              case 2: // normal
              {
                 X = XValue[i] - (incrsize / 2.0);
                 zlow = (X - ObsMean) / ObsStdDev;
                 X = XValue[i] + (incrsize / 2.0);
                 zhi = (X - ObsMean) / ObsStdDev;
                 // get cum. prop. for this z and translate to frequency
                 zproplow = normalprob(zlow);
                 zprophi = normalprob(zhi);
                 zfreq = Ncases * fabs(zprophi - zproplow);
                 CompData[i] = zfreq;
              } break;
              case 3: // t
              {
                 X = XValue[i] - (incrsize / 2.0);
                 double tlow = (X - ObsMean) / ObsStdDev;
                 X = XValue[i] + (incrsize / 2.0);
                 double thi = (X - ObsMean) / ObsStdDev;
                 // get prop. for this interval translate to frequency
                 double tproplow = tprob(tlow,Ncases);
                 double tprophi = tprob(thi,Ncases);
                 double tfreq = Ncases * fabs(tprophi - tproplow);
                 CompData[i] = tfreq / 2.0;
              } break;
              case 4: // Chi-squared
              {
                 X = XValue[i] - (incrsize / 2.0);
                 double chilow = (X - ObsMean) / ObsStdDev;
                 chilow = chilow * chilow; // squared z score
                 X = XValue[i] + (incrsize / 2.0);
                 double chihi = (X - ObsMean) / ObsStdDev;
                 chihi = chihi * chihi;
                 // get prop. for this interval translate to frequency
                 double chiproplow = tprob(chilow,Ncases);
                 double chiprophi = tprob(chihi,Ncases);
                 double chifreq = Ncases * fabs(chiprophi - chiproplow);
                 CompData[i] = chifreq / 2.0;
              } break;
              case 5: // Poisson
              {
                 X = XValue[i] - (incrsize / 2.0);
                 mean = ObsMean;
                 Which = 1; // obtain P and Q from X and mean
                 cdfpoi(&Which,&P,&Q,&X,&mean,&Status,&Bound);
                 double P1 = P;
                 X = XValue[i] + (incrsize / 2.0);
                 cdfpoi(&Which,&P,&Q,&X,&mean,&Status,&Bound);
                 double P2 = P;
                 CompData[i] = fabs(P2 - P1) * Ncases;
              } break;
           } // end switch
     } // next case i
     // get frequency of comparison data
     for (int j = 0; j < nints + 1; j++) freqcomp[j] = CompData[j];
     // convert frequencies to proportions
     for (int j = 0; j < nints; j++) CompData[j] = freqcomp[j] / Ncases;
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::PlotIt(double *freq, double *freqcomp, double *XValue)
{
     AnsiString xtitle;
     xtitle = "Red = " + ObsLabel + " Blue = " + CompLabel;
     GetDblMatMem(GraphForm->Xpoints,2,nints+1);
     GetDblMatMem(GraphForm->Ypoints,2,nints+1);
     GraphForm->GraphType = plottype; //  2d line is default 6
     GraphForm->nosets = 2;
     GraphForm->nbars = nints;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlue;
     GraphForm->FloorColor = clGray;
     GraphForm->Heading = heading; // "Frequency Distributions";
     GraphForm->XTitle = xtitle;
     GraphForm->YTitle = ytitle; // "Frequency";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = true;
     GraphForm->ShowLeftWall = true;
     GraphForm->ShowRightWall = true;
     GraphForm->ShowBottomWall = true;
     for (int k = 1; k <= nints; k++)
     {
        GraphForm->Ypoints[0][k-1] = freq[k-1];
        GraphForm->Ypoints[1][k-1] = freqcomp[k-1];
        GraphForm->Xpoints[0][k-1] = XValue[k-1];
     }
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Ypoints,2);
     ClearDblMatMem(GraphForm->Xpoints,2);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::Obs2InBtnClick(TObject *Sender)
{
     int index;
     index = VarList->ItemIndex;
     Observed2Edit->Text = VarList->Items->Strings[index];
     Obs2InBtn->Visible = false;
     Obs2OutBtn->Visible = true;
     VarList->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TKSForm::Obs2OutBtnClick(TObject *Sender)
{
     VarList->Items->Add(Observed2Edit->Text);
     Observed2Edit->Text = "";
     Obs2OutBtn->Visible = false;
     Obs2InBtn->Visible = true;
}
//---------------------------------------------------------------------------



