//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include "GraphUnit.h"
#include "stdio.h"
#include "DictionaryUnit.h"
#include "NonPar.h"
#include "ANCOVAUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TANCOVAFORM *ANCOVAFORM;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
__fastcall TANCOVAFORM::TANCOVAFORM(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::ResetBtnClick(TObject *Sender)
{
     int i;

     DepVar->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;
     FixedIn->Visible = true;
     FixedOut->Visible = false;
     CovIn->Visible = true;
     CovOut->Visible = false;
     VarList->Clear();
     CovList->Clear();
     FixedList->Clear();
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     Describe->Checked = false;
     Rmats->Checked = false;
     Inverses->Checked = false;
     PlotMeans->Checked = false;
     RegsChk->Checked = false;
     MeansChk->Checked = false;
     NoBlocks = 0;
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::DepInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     DepVar->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepIn->Visible = false;
     DepOut->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::DepOutClick(TObject *Sender)
{
     VarList->Items->Add(DepVar->Text);
     DepVar->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::FixedInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            FixedList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     FixedOut->Visible = true;

}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::FixedOutClick(TObject *Sender)
{
     int index;

     index = FixedList->ItemIndex;
     if (index < 0)
     {
          FixedOut->Visible = false;
          return;
     }
     VarList->Items->Add(FixedList->Items->Strings[index]);
     FixedList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::CovInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            CovList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     CovOut->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::CovOutClick(TObject *Sender)
{
     int index;

     index = CovList->ItemIndex;
     if (index < 0)
     {
          CovOut->Visible = false;
          return;
     }
     VarList->Items->Add(CovList->Items->Strings[index]);
     CovList->Items->Delete(index);
}
//---------------------------------------------------------------------------
void __fastcall TANCOVAFORM::ComputeBtnClick(TObject *Sender)
{
     char outline[101];
     int result;

     NoFixed = FixedList->Items->Count;
     NoCovs = CovList->Items->Count;
     if ((NoFixed <= 0) || (NoCovs <= 0))
     {
          ShowMessage("ERROR! You must have at least one group variable and one covariate");
          return;
     }
     result = GetParms(this); // get variables and blocks for covariates
     if (result == -1) return;
     CodeGroups(this); // generate effect-coded vectors and blocks for fixed effects
     GenInteractions(this); // generate interaction effects and blocks for fixed effects
     GenCovInteracts(this); // generate interactions and blocks with fixed effects and covariates
/*
     // print blocks as test of coding
     FrmOutPut->RichOutPut->Lines->Add("Block mingrp maxgrp startcol endcol NoVectors");
     for (int i = 0; i < NoBlocks; i++)
     {
         sprintf(outline," %3d  %4d   %4d   %4d     %4d    %4d",i+1,Block[i][0],Block[i][1],Block[i][2],Block[i][3],Block[i][4]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->ShowModal();
*/
     DoRegs(this);
     CleanUp(this);
     ReturnBtn->SetFocus();
}
//---------------------------------------------------------------------------

int __fastcall TANCOVAFORM::GetParms(TObject *Sender)
{
     int i, j, result;

     GetIntVecMem(ColNoSelected,NoVariables);
     GetIntVecMem(FixedCols,NoFixed);
     GetIntVecMem(CovCols,NoCovs);
     GetIntVecMem(mingrp,NoFixed);
     GetIntVecMem(maxgrp,NoFixed);
     GetIntMatMem(Block,100,5);
     BlockLabel = new AnsiString[100];

     NoSelected = 0;
     NoBlocks = 0;
     if (Describe->Checked) descript = true;
     else descript = false;
     if (Inverses->Checked) printinv = true;
     else printinv = false;
     if (PlotMeans->Checked) plot = true;
     else plot = false;
     for (i = 1; i <= NoVariables; i++)
     {
          if (DepVar->Text == MainForm->Grid->Cells[i][0])
          {
               DepColNo = i;
               ColNoSelected[0] = i;
               NoSelected = 1;
               //result = VarTypeChk(i,0);
               //if (result == 1) return(-1);
               break;
          }
     }

     if (NoFixed < 1) goto covs;
     for (i = 0; i < NoFixed; i++)
     {
          for (j = 1; j <= NoVariables; j++)
          {
               if (FixedList->Items->Strings[i] == MainForm->Grid->Cells[j][0])
               {
                    FixedCols[i] = j;
                    ColNoSelected[NoSelected] = j;
                    NoSelected = NoSelected + 1;
                    //result = VarTypeChk(j,1);
                    //if (result == 1) return(-1);
                    break;
               }
          }
     }

covs: if (NoCovs < 1) return(0);
     for (i = 0; i < NoCovs; i++)
     {
          for (j = 1; j <= NoVariables; j++)
          {
               if (CovList->Items->Strings[i] == MainForm->Grid->Cells[j][0])
               {
                    CovCols[i] = j;
                    ColNoSelected[NoSelected] = j;
                    NoSelected = NoSelected + 1;
                    //result = VarTypeChk(j,0);
                    //if (result == 1) return(-1);
                    break;
               }
          }
     }
     // create a "Block" for each covariate
     for (i = 0; i < NoCovs; i++)
     {
          NoBlocks = NoBlocks + 1;
          Block[i][0] = 0;  // group min
          Block[i][1] = 0;  // group max
          Block[i][2] = CovCols[i]; // start column in grid
          Block[i][3] = CovCols[i]; // end column in grid
          Block[i][4] = 1;           // no. of vectors
          BlockLabel[i] = "Cov" + IntToStr(i+1);
     }
     return(0);
}
//-------------------------------------------------------------------

void __fastcall TANCOVAFORM::CodeGroups(TObject *Sender)
{
     int col, i, j, value, startcol, endcol, novectors;
     AnsiString factlabel, cellstring;
     char achar;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     for (i = 0; i < NoFixed; i++) // create a block for code vectors of each fixed variable
     {
          col = FixedCols[i];
          achar = ('A' + i);
          factlabel = achar;
          mingrp[i] = floor(StrToFloat(Trim(MainForm->Grid->Cells[col][1])));
          //result = GetValue(1,col,intvalue,dblvalue,strvalue);
          //if (result == 1) mingrp[i] = 0;
          //else mingrp[i] = intvalue;
          maxgrp[i] = mingrp[i];
          for (j = 1; j <= NoCases; j++)
          {
               if (! ValidRecord(j,ColNoSelected,NoSelected))  continue;
               cellstring = Trim(MainForm->Grid->Cells[col][j]);
               value = floor(StrToFloat(cellstring));
               //result = GetValue(j,col,intvalue,dblvalue,strvalue);
               //if (result == 1) value = 0;
               //else value = intvalue;
               if (value < mingrp[i]) mingrp[i] = value;
               if (value > maxgrp[i]) maxgrp[i] = value;
          }
          // create fixed effect coding for levels - 1 of the fixed effect var.
          EffectCode(col,mingrp[i],maxgrp[i],factlabel,startcol,
                    endcol,novectors,this);
          NoBlocks = NoBlocks + 1;
          Block[NoBlocks-1][0] = mingrp[i];
          Block[NoBlocks-1][1] = maxgrp[i];
          Block[NoBlocks-1][2] = startcol;
          Block[NoBlocks-1][3] = endcol;
          Block[NoBlocks-1][4] = novectors;
          BlockLabel[NoBlocks-1] = factlabel;
     } // next factor block
}
//-------------------------------------------------------------------

void __fastcall TANCOVAFORM::GenInteractions(TObject *Sender)
{
     int i, j, k, l, m, n, o, highest, col, vect1col, vect2col, vect3col, value;
     AnsiString labelstr;
     int startcol, endcol, novectors,oldnovars;
     AnsiString cell1, cell2, cell3, cell4;
     int TwoWays[10][2] = {{1,2},{1,3},{2,3},{1,4},{2,4},{3,4},{1,5},{2,5},{3,5},{4,5}};
     int ThreeWays[10][3] = {{1,2,3},{1,2,4},{1,3,4},{2,3,4},{1,2,5},{1,3,5},
                             {1,4,5},{2,3,5},{2,4,5},{3,4,5}};
     int FourWays[5][4] = {{1,2,3,4},{1,2,3,5},{1,2,4,5},{1,3,4,5},{2,3,4,5}};
     double TwoWayCombos, ThreeWayCombos, FourWayCombos;

//     highest = LevelsGroup->ItemIndex + 2;
//     if (highest < 2) return;
     if (NoFixed < 2) return;
     novectors = 0;

     // Do two-way interactions.  Note- a block is created for each fixed effect
     // combination, e.g. effects 1 with 2, 1 with 3, 2 with 3, etc.
     TwoWayCombos = ceil(combos(2.0,(double)NoFixed));
//     col = NoVariables;
     oldnovars = NoVariables;

     for (i = 0; i < TwoWayCombos; i++) // pointer to 2-way blocks
     {
         int Block1 = TwoWays[i][0] + NoCovs - 1; // block # for first fixed effect
         int Block2 = TwoWays[i][1] + NoCovs - 1; // block # for second fixed effect
         int Start1 = Block[Block1][2];
         int End1 = Block[Block1][3];
         int Start2 = Block[Block2][2];
         int End2 = Block[Block2][3];
         oldnovars = NoVariables;
         startcol = Block[NoBlocks-1][3] + 1;
         col = NoVariables;
         for (j = Start1; j <= End1; j++) // vector in first fixed factor
         {
             for (k = Start2; k <= End2; k++) // vector in second fixed factor
             {
                 col++;
                 novectors++;
                 NewVar(col,false);
                 labelstr = MainForm->Grid->Cells[j][0] + "x";
                 labelstr = labelstr + MainForm->Grid->Cells[k][0];
                 MainForm->Grid->Cells[col][0] = labelstr;
                 DictionaryForm->DGrid->Cells[1][col] = labelstr;
                 for (m = 1; m <= NoCases; m++)
                 {
                     if (! ValidRecord(m,ColNoSelected,NoSelected)) continue;
                     cell1 = Trim(MainForm->Grid->Cells[j][m]);
                     cell2 = Trim(MainForm->Grid->Cells[k][m]);
                     value = floor(StrToFloat(cell1)) * floor(StrToFloat(cell2));
                     MainForm->Grid->Cells[col][m] = IntToStr(value);
                 } // next case m
             } // next vector k in second factor
             endcol = col; // last grid column containing two-way interaction vectors
             NoBlocks = NoBlocks + 1;
             Block[NoBlocks-1][0] = 0; // zeroes for interactions
             Block[NoBlocks-1][1] = 0; // zeroes for interactions
             Block[NoBlocks-1][2] = startcol; // grid start col for 2-way interactions
             Block[NoBlocks-1][3] = endcol; // grid end col for 2-way interactions
             Block[NoBlocks-1][4] = novectors; // no. of vectors for 2-way interaction
             BlockLabel[NoBlocks-1] = BlockLabel[Block1] + "x" + BlockLabel[Block2];
             NoVariables = oldnovars + novectors;
             MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
             novectors = 0;
         } // end of interaction of fixed effect vectors j and fixed effect vectors k
     } // end of two-way combinations

     // do 3-way interactions using group vectors and two way interaction vectors
     if (NoFixed < 3) return;
     ThreeWayCombos = combos(3.0,(double)NoFixed);
     for (i = 0; i < ThreeWayCombos; i++) // pointer to 2-way blocks
     {
         startcol = Block[NoBlocks-1][3] + 1;
         col = NoVariables;
         int Block1 = ThreeWays[i][0] + NoCovs - 1; // block # for first fixed effect
         int Block2 = ThreeWays[i][1] + NoCovs - 1; // block # for second fixed effect
         int Block3 = ThreeWays[i][2] + NoCovs - 1; // block # for third fixed effect
         int Start1 = Block[Block1][2];
         int End1 = Block[Block1][3];
         int Start2 = Block[Block2][2];
         int End2 = Block[Block2][3];
         int Start3 = Block[Block3][2];
         int End3 = Block[Block3][3];
         oldnovars = NoVariables;
         novectors = 0;
         for (j = Start1; j <= End1; j++) // vector in first fixed factor
         {
             for (k = Start2; k <= End2; k++) // vector in second fixed factor
             {
                 for (l = Start3; l <= End3; l++) // vector in third fixed factor
                 {
                     col++;
                     novectors++;
                     NewVar(col,false);
                     labelstr = MainForm->Grid->Cells[j][0] + "x";
                     labelstr = labelstr + MainForm->Grid->Cells[k][0];
                     labelstr = labelstr + "x" + MainForm->Grid->Cells[l][0];
                     MainForm->Grid->Cells[col][0] = labelstr;
                     DictionaryForm->DGrid->Cells[1][col] = labelstr;
                     for (m = 1; m <= NoCases; m++)
                     {
                         if (! ValidRecord(m,ColNoSelected,NoSelected)) continue;
                         cell1 = Trim(MainForm->Grid->Cells[j][m]);
                         cell2 = Trim(MainForm->Grid->Cells[k][m]);
                         cell3 = Trim(MainForm->Grid->Cells[l][m]);
                         value = floor(StrToFloat(cell1)) *
                                 floor(StrToFloat(cell2)) *
                                 floor(StrToFloat(cell3));
                         MainForm->Grid->Cells[col][m] = IntToStr(value);
                     } // next case m
                 } // next third variable
             } // next second variable
         } // end of interaction of fixed effects vectors for j, k and l
         endcol = col; // last grid column containing three-way interaction vectors
         NoBlocks = NoBlocks + 1;
         Block[NoBlocks-1][0] = 0; // zeroes for interactions
         Block[NoBlocks-1][1] = 0; // zeroes for interactions
         Block[NoBlocks-1][2] = startcol; // grid start col for 3-way interactions
         Block[NoBlocks-1][3] = endcol; // grid end col for 3-way interactions
         Block[NoBlocks-1][4] = novectors; // no. of vectors for 3-way interaction
         BlockLabel[NoBlocks-1] = BlockLabel[Block1] + "x" + BlockLabel[Block2]
                                            + "x" + BlockLabel[Block3];
         NoVariables = oldnovars + novectors;
         MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
//         novectors = 0;
     } // end of three-way combinations

     // do 4-way interactions using group and 3-way interaction vectors
     if (NoFixed < 4) return;
     FourWayCombos = combos(4.0,(double)NoFixed);
     for (i = 0; i < FourWayCombos; i++) // pointer to 4-way blocks
     {
         startcol = Block[NoBlocks-1][3] + 1;
         col = NoVariables;
         int Block1 = FourWays[i][0] + NoCovs - 1; // block # for first fixed effect
         int Block2 = FourWays[i][1] + NoCovs - 1; // block # for second fixed effect
         int Block3 = FourWays[i][2] + NoCovs - 1; // block # for third fixed effect
         int Block4 = FourWays[i][3] + NoCovs - 1; // block # for fourth fixed effect
         int Start1 = Block[Block1][2];
         int End1 = Block[Block1][3];
         int Start2 = Block[Block2][2];
         int End2 = Block[Block2][3];
         int Start3 = Block[Block3][2];
         int End3 = Block[Block3][3];
         int Start4 = Block[Block4][2];
         int End4 = Block[Block4][3];
         oldnovars = NoVariables;
         novectors = 0;
         for (j = Start1; j <= End1; j++) // vector in first fixed factor
         {
             for (k = Start2; k <= End2; k++) // vector in second fixed factor
             {
                 for (l = Start3; l <= End3; l++) // vector in third fixed factor
                 {
                     for (m = Start4; m <= End4; m++) // vecotr in fourth fixed factor
                     {
                         col++;
                         novectors++;
                         NewVar(col,false);
                         labelstr = MainForm->Grid->Cells[j][0] + "x";
                         labelstr = labelstr + MainForm->Grid->Cells[k][0];
                         labelstr = labelstr + "x" + MainForm->Grid->Cells[l][0];
                         MainForm->Grid->Cells[col][0] = labelstr;
                         DictionaryForm->DGrid->Cells[1][col] = labelstr;
                         for (n = 1; n <= NoCases; n++)
                         {
                             if (! ValidRecord(n,ColNoSelected,NoSelected)) continue;
                             cell1 = Trim(MainForm->Grid->Cells[j][n]);
                             cell2 = Trim(MainForm->Grid->Cells[k][n]);
                             cell3 = Trim(MainForm->Grid->Cells[l][n]);
                             cell4 = Trim(MainForm->Grid->Cells[m][n]);
                             value = floor(StrToFloat(cell1)) *
                                 floor(StrToFloat(cell2)) *
                                 floor(StrToFloat(cell3)) *
                                 floor(StrToFloat(cell4));
                             MainForm->Grid->Cells[col][n] = IntToStr(value);
                         } // next case n
                     } // next fourth vector m
                 } // next third vector
             } // next second vector
         } // end of interaction of fixed effects vectors for j, k and l and m
         endcol = col; // last grid column containing four-way interaction vectors
         NoBlocks = NoBlocks + 1;
         Block[NoBlocks-1][0] = 0; // zeroes for interactions
         Block[NoBlocks-1][1] = 0; // zeroes for interactions
         Block[NoBlocks-1][2] = startcol; // grid start col for 4-way interactions
         Block[NoBlocks-1][3] = endcol; // grid end col for 4-way interactions
         Block[NoBlocks-1][4] = novectors; // no. of vectors for 2-way interaction
         BlockLabel[NoBlocks-1] = BlockLabel[Block1] + "x" + BlockLabel[Block2]
                                            + "x" + BlockLabel[Block3] + "x"
                                            + BlockLabel[Block4];
         NoVariables = oldnovars + novectors;
         MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
     } // end of four-way combinations

}
//-------------------------------------------------------------------

void __fastcall TANCOVAFORM::DoRegs(TObject *Sender)
{
     AnsiString outline;
     int i, j;

     // get count of variables used
     count = 0;
     for (i = 0; i < NoBlocks; i++)
         for (j = 0; j <= Block[i][4]; j++) count = count + 1;
     GetDblVecMem(BetaWeights,count+1);
     GetDblVecMem(BWeights,count+2);
     GetDblVecMem(Means,count+1);
     GetDblVecMem(Variances,count+1);
     GetDblVecMem(StdDevs,count+1);
     RowLabels = new AnsiString[count+1];
     ColLabels = new AnsiString[count+1];
     GetIntVecMem(IndepIndex,count+1);
     GetIntVecMem(ColNoSelected,count+1);

     if (Rmats->Checked) PrintIt = true;
     else PrintIt = false;
     if (RegsChk->Checked) ShowRegs = true;
     else ShowRegs = false;
     Testout = false;
     probout = 0.99;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("ANALYSIS OF COVARIANCE USING MULTIPLE REGRESSION");
     FrmOutPut->RichOutPut->Lines->Add("");
     outline = "File Analyzed: " + MainForm->FileNameEdit->Text;
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     EntryOpt1(this); // factors, interactions and covariats concurrently
     FrmOutPut->ShowModal();
}
//-------------------------------------------------------------------

void __fastcall TANCOVAFORM::CleanUp(TObject *Sender)
{
     ClearIntVecMem(ColNoSelected);
     ClearIntVecMem(IndepIndex);
     delete[] ColLabels;
     delete[] RowLabels;
     ClearDblVecMem(StdDevs);
     ClearDblVecMem(Variances);
     ClearDblVecMem(Means);
     ClearDblVecMem(BWeights);
     ClearDblVecMem(BetaWeights);
     ClearIntVecMem(maxgrp);
     ClearIntVecMem(mingrp);
     ClearIntVecMem(CovCols);
     ClearIntVecMem(FixedCols);
}
//-------------------------------------------------------------------
void __fastcall TANCOVAFORM::EntryOpt1(TObject *Sender)
{
     int i, j, k, col, count;
     AnsiString Title;
     char outline[101];
     double FullR2, F, Prob, df1, df2, SSGroups, MSGroups, SSError, MSError;
     double SSTotal, SSExplained, SSGrpTot;
     double *tProbs;
     bool printcorrs = false;

     // factors, interactions and covariates concurrently (full model)
     // get grid column numbers of all vectors and dependent variable
     if (RegsChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Model for Testing Assumption of Zero Interactions with Covariates");
        FrmOutPut->RichOutPut->Lines->Add("");
     }
     count = 0;
     for (i = 1; i <= NoBlocks; i++) // no. of vector blocks
     {
          for (j = 1; j <= Block[i-1][4]; j++) // no of vectors in block
          {
               col = Block[i-1][2] + j - 1; // count from begining col.
               count = count + 1;
               ColNoSelected[count-1] = col;
               IndepIndex[count-1] = count;
               RowLabels[count-1] = MainForm->Grid->Cells[col][0];
          }
     }
     count = count + 1;
     noind = count - 1;
     ColNoSelected[count-1] = DepColNo;
     IndepIndex[count-1] = count;
     RowLabels[count-1] = MainForm->Grid->Cells[DepColNo][0];

     // Get correlation matrix (note dependent is last variable)
     GetDblMatMem(CorMat,count+1,count+1);
     GetDblMatMem(IndMat,count+1,count+1);
     GetDblVecMem(tProbs,count);
     GetDblVecMem(BStdErrs,noind+1);
     GetDblVecMem(BTtests,noind+1);
     int NSUBS = NoCases;
     if (NSUBS <= count)
     {
        ShowMessage("No. of cases less than or equal to No. of variables - quiting.");
        goto endit;
     }
     if (Rmats->Checked) printcorrs = true;
     // Get regression
     PrintIt = true;
     printinv = false;
     if (Inverses->Checked == true) printinv = true;
     mreg(noind, ColNoSelected, DepColNo, RowLabels, Means, Variances,StdDevs,
               BWeights, BetaWeights, BStdErrs, BTtests,tProbs,R2, F, StdErrEst,
               NCases, errorcode, descript, printcorrs, printinv, ShowRegs, false);
     FullR2 = R2;
//     SSTotal = Variances[count-1] * (NCases - 1);
     df2 = NCases - noind - 1;
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     // Now do analysis without the interactions (Ancova model)
     if (RegsChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Model for Analysis of Covariance");
        FrmOutPut->RichOutPut->Lines->Add("");
     }
     count = 0;
     for (i = 1; i < NoBlocks; i++) // no. of vector blocks
     {
          for (j = 1; j <= Block[i-1][4]; j++) // no of vectors in block
          {
               col = Block[i-1][2] + j - 1; // count from begining col.
               count = count + 1;
               ColNoSelected[count-1] = col;
               IndepIndex[count-1] = count;
               RowLabels[count-1] = MainForm->Grid->Cells[col][0];
          }
     }
     count = count + 1;
     noind = count - 1;
     ColNoSelected[count-1] = DepColNo;
     IndepIndex[count-1] = count;
     RowLabels[count-1] = MainForm->Grid->Cells[DepColNo][0];

     // Get correlation matrix (note dependent is last variable)
     Correlations(Means, StdDevs, CorMat, count,ColNoSelected, NSUBS, 3, false, 0);
     // save in IndMat
     for (i = 0; i < count; i++)
         for (j = 0; j < count; j++)
             IndMat[i][j] = CorMat[i][j];
     if (Rmats->Checked) PrintIt = true;
     else PrintIt = false;
     // Get regression
     PrintIt = true;
     printinv = false;
     if (Inverses->Checked == true)  printinv = true;
     mreg(noind, ColNoSelected, DepColNo, RowLabels, Means, Variances,StdDevs,
               BWeights, BetaWeights, BStdErrs, BTtests,tProbs,R2, F, StdErrEst,
               NCases, errorcode, descript, printcorrs, printinv, ShowRegs, false);

     // test differences between previous and current models (= beta test)
     constant = BWeights[noind];
     df1 =NoTestVecs;
     F = ((FullR2 - R2) / df1) / ((1.0 - FullR2) / df2);
     Prob = ftest(df1,df2,F);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Test for Homogeneity of Group Regression Coefficients");
     sprintf(outline,"Change in R2 = %6.4f. F = %10.3f  Prob.> F = %6.4f with d.f. %8.0f and %8.0f",
           (FullR2 - R2),F,Prob, df1, df2);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FullR2 = R2;
     SSTotal = Variances[count-1] * (NCases - 1);
//     SSGroups = FullR2 * SSTotal;
     SSError = (1.0 - FullR2) * SSTotal;
//     df1 = noind;
     df2 = NCases - noind - 1;
//     MSGroups = SSGroups / df1;
     MSError = SSError / df2;
     // Obtain adjusted means
     AdjustMeans(this);
     // make comparisons among groups
     MultCompare(this);

     // Now do regression, eliminating each block to test effects of that term
     PrintIt = false;
     FrmOutPut->RichOutPut->Lines->Add("Test for Each Source of Variance Obtained by Eliminating");
     FrmOutPut->RichOutPut->Lines->Add("from the Regression Model for ANCOVA the Vectors Associated");
     FrmOutPut->RichOutPut->Lines->Add("with Each Fixed Effect.");
     FrmOutPut->RichOutPut->Lines->Add("");
     SSGrpTot = 0.0;
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("    SOURCE      Deg.F.      SS          MS          F           Prob>F");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     for (i = 1; i < NoBlocks; i++) // covariates, fixed effects, interactions
     {
          count = 0;
          for (j = 1; j < NoBlocks; j++)
          {
               if (j == i) continue; // exclude the factor to be tested
               for (k = 1; k <= Block[j-1][4]; k++) // no of vectors in block
               {
                    col = Block[j-1][2] + k - 1; // count from begining col.
                    count = count + 1;
                    ColNoSelected[count-1] = col;
                    IndepIndex[count-1] = count;
                    RowLabels[count-1] = MainForm->Grid->Cells[col][0];
               }
          } // get next block of vectors for factors to be included
          count = count + 1;
          noind = count - 1;
          ColNoSelected[count-1] = DepColNo;
          IndepIndex[count-1] = count;
          RowLabels[count-1] = MainForm->Grid->Cells[DepColNo][0];
          Correlations(Means, StdDevs, CorMat, count,ColNoSelected, NSUBS, 3, false, 0);
          // Get regression
          printinv = false;
          mreg(noind, ColNoSelected, DepColNo, RowLabels, Means, Variances,StdDevs,
               BWeights, BetaWeights, BStdErrs, BTtests,tProbs,R2, F, StdErrEst,
               NCases, errorcode, false, false, false, false, false);
          df1 = Block[i-1][4];
          SSGroups = (FullR2 - R2) * SSTotal;
          SSGrpTot = SSGrpTot + SSGroups;
          MSGroups = SSGroups / df1;
          F = MSGroups / MSError;
          Prob = ftest(df1,df2,F);
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"%10s  %10.0f  %10.2f  %10.2f  %10.3f  %10.4f",
                            BlockLabel[i-1],df1,SSGroups,MSGroups,F,Prob);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     } // get next Block to eliminate
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     sprintf(outline,"%10s  %10.0f  %10.2f  %10.2f","ERROR",df2,SSError,MSError);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     sprintf(outline,"%10s  %10d  %10.2f","TOTAL",NCases-1,SSTotal);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");

     // examine effect of covariates alone
     count = 0;
     for (i = 1; i <= NoCovs; i++) // covariance block
     {
         col = Block[i-1][2]; // begining col.
         count = count + 1;
         ColNoSelected[count-1] = col;
         IndepIndex[count-1] = count;
         RowLabels[count-1] = MainForm->Grid->Cells[col][0];
     }
     count = count + 1;
     noind = count - 1;
     ColNoSelected[count-1] = DepColNo;
     IndepIndex[count-1] = count;
     RowLabels[count-1] = MainForm->Grid->Cells[DepColNo][0];
     // Get regression
     printinv = false;
     mreg(noind, ColNoSelected, DepColNo, RowLabels, Means, Variances,StdDevs,
               BWeights, BetaWeights, BStdErrs, BTtests,tProbs,R2, F, StdErrEst,
               NCases, errorcode, false, false, false, false, false);
     df1 = NoCovs;
     SSGroups = R2 * SSTotal;
     MSGroups = SSGroups / df1;
     SSError = (1.0 - R2) * SSTotal;
     df2 = (NCases - NoCovs - 1);
     MSError = SSError / df2;
     F = MSGroups / MSError;
     Prob = ftest(df1,df2,F);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("ANALYSIS FOR COVARIATES ONLY");

     sprintf(outline,"%10s  %10.0f  %10.2f  %10.2f  %10.3f  %10.4f",
                            "Covariates",df1,SSGroups,MSGroups,F,Prob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");

endit:
     ClearDblVecMem(BTtests);
     ClearDblVecMem(BStdErrs);
     ClearDblVecMem(tProbs);
     ClearDblMatMem(IndMat,count+1);
     ClearDblMatMem(CorMat,count+1);
}
//-------------------------------------------------------------------
void __fastcall TANCOVAFORM::GenCovInteracts(TObject *Sender)
{
   int i, j, k, l, m, vect1col, vect2col, col;
   double value;
   AnsiString labelstr, cell1, cell2;
   int startcol, endcol, novectors, oldnovars;

   col = NoVariables;
   oldnovars = NoVariables;
   novectors = 0;
   NoTestVecs = 0;
   startcol = Block[NoBlocks-1][3] + 1; // create vectors starting here in grid
   int lastblock = NoBlocks;
   int firstblock = NoCovs+1; // start of fixed effect vectors
   for (i = 1; i <= NoCovs; i++) // product vectors for each covariate
   {
        vect1col = Block[i-1][2]; // column of covariate i
        for (j = firstblock; j <= lastblock; j++) // start with block after covariate blocks
        {
               for (l = 1; l <= Block[j-1][4]; l++) // no. vectors in factor block
               {
                   vect2col = Block[j-1][2] + l - 1; // vector col. of B
                   col = col + 1;
                   novectors = novectors + 1;
                   NoTestVecs = NoTestVecs + 1;
                   NewVar(col,false);
                   labelstr = MainForm->Grid->Cells[vect1col][0] + "x";
                   labelstr = labelstr + MainForm->Grid->Cells[vect2col][0];
                   MainForm->Grid->Cells[col][0] = labelstr;
                   DictionaryForm->DGrid->Cells[1][col] = labelstr;
                   for (m = 1; m <= NoCases; m++)
                   {
                       if (! ValidRecord(m,ColNoSelected,NoSelected)) continue;
                       cell1 = Trim(MainForm->Grid->Cells[vect1col][m]);
                       cell2 = Trim(MainForm->Grid->Cells[vect2col][m]);
                       value = StrToFloat(cell1) * StrToFloat(cell2);
                       MainForm->Grid->Cells[col][m] = FloatToStr(value);
                   } // next case m
               } // next l vector
        } // next fixed effects factor j and interactions
   } // next covariate i
   endcol = col; // last grid column containing interaction vectors
   NoBlocks = NoBlocks + 1;
   Block[NoBlocks-1][0] = 0; // zeroes for interactions
   Block[NoBlocks-1][1] = 0; // zeroes for interactions
   Block[NoBlocks-1][2] = startcol; // grid start col for 2-way interactions
   Block[NoBlocks-1][3] = endcol; // grid end col for 2-way interactions
   Block[NoBlocks-1][4] = novectors; // no. of vectors for 2-way interaction
   BlockLabel[NoBlocks-1] = BlockLabel[i-1] + "xFixed";
   NoVariables = oldnovars + novectors;
   MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
}
//-------------------------------------------------------------------
void __fastcall TANCOVAFORM::AdjustMeans(TObject *Sender)
{
     double sum;
     double **GrpCovMeans;
     double *AdjMeans;
     double *Intercepts;
     int i, j, k, col, grp, nogrps;
     double value;
     AnsiString *Labels;
     AnsiString varlabel;
     char outline[101];
     int *noingrp;
     double *XValue;
     double maxmean;
     AnsiString cell1;

     GetDblMatMem(GrpCovMeans,noind,noind);
     GetDblVecMem(AdjMeans,noind);
     GetDblVecMem(Intercepts,noind);
     Labels = new AnsiString[noind];
     GetIntVecMem(noingrp,noind);
     GetDblVecMem(XValue,noind);

     // get means for groups and covariates
     for (j = 1; j <= NoFixed; j++) // for each fixed variable
     {
          varlabel = MainForm->Grid->Cells[FixedCols[j-1]][0];;
          nogrps = maxgrp[j-1] - mingrp[j-1] + 1;
          maxmean = 0.0;
          for (i = 1; i <= nogrps; i++)
          {
               XValue[i-1] = i;
               noingrp[i-1] = 0;
               for (k = 1; k <= NoCovs; k++) GrpCovMeans[i-1][k-1] = 0.0;
          }
          for (i = 1; i <= nogrps; i++) AdjMeans[i-1] = 0.0;
          for (i = 1; i <= NoCases; i++)
          {
               cell1 = Trim(MainForm->Grid->Cells[FixedCols[j-1]][i]);
               if (cell1 == "") continue;
               grp = ceil(StrToFloat(cell1));
               grp = grp - mingrp[j-1] + 1;
               noingrp[grp-1] = noingrp[grp-1] + 1;
               for (k = 1; k <= NoCovs; k++)
               {
                    col = CovCols[k-1];
                    cell1 = Trim(MainForm->Grid->Cells[col][i]);
                    if (cell1 == "") continue;
                    value = StrToFloat(cell1);
                    GrpCovMeans[grp-1][k-1] = GrpCovMeans[grp-1][k-1] + value;
               }
               cell1 = Trim(MainForm->Grid->Cells[DepColNo][i]);
               if (cell1 == "") continue;
               value = StrToFloat(cell1);
               AdjMeans[grp-1] = AdjMeans[grp-1] + value;
          } // next case i

          GetDblMatMem(GraphForm->Ypoints,1,nogrps);
          GetDblMatMem(GraphForm->Xpoints,1,nogrps);
          for (k = 1; k <= nogrps; k++)
          {
               Labels[k-1] = "Group " + IntToStr(k);
               AdjMeans[k-1] = AdjMeans[k-1] / noingrp[k-1];
               GraphForm->Ypoints[0][k-1] = AdjMeans[k-1];
               GraphForm->Xpoints[0][k-1] = k;
               if (AdjMeans[k-1] > maxmean) maxmean = AdjMeans[k-1];
               for (i = 1; i <= NoCovs; i++)
               {
                    GrpCovMeans[k-1][i-1] = GrpCovMeans[k-1][i-1] / noingrp[k-1];
               }
          }
          // print unadjusted means
          FrmOutPut->RichOutPut->Lines->Add("");
          strcpy(outline,"Unadjusted Group Means for Group Variables ");
          strcat(outline,MainForm->Grid->Cells[FixedCols[j-1]][0].c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
          VPrint(AdjMeans,nogrps,Labels,"Means");
          FrmOutPut->RichOutPut->Lines->Add("");

          // plot group means if requested
          if (plot)
          {
               GraphForm->nosets = 1;
               GraphForm->nbars = nogrps;
               GraphForm->Heading = "Unadjusted Means for " + varlabel;
               GraphForm->XTitle = "GROUP";
               GraphForm->YTitle = "Mean";
               GraphForm->barwideprop = 0.5;
               GraphForm->AutoScale = false;
               GraphForm->miny = 0.0;
               GraphForm->maxy = maxmean;
               GraphForm->GraphType = 3; // 3d Vertical Bar Chart
               GraphForm->ShowBackWall = true;
               GraphForm->BackColor = clWhite;
               GraphForm->WallColor = clGray;
               GraphForm->FloorColor = clGray;
               GraphForm->ShowModal();
          }
          // get intercepts for group equations for this fixed effect variable
          sum = 0.0;
          for (k = 1; k < nogrps; k++) // no. vectors is 1 less than no. groups
          {
               Intercepts[k-1] = constant + BWeights[NoCovs+k-1];
               sum = sum + BWeights[NoCovs+k-1];
          }
          Intercepts[nogrps-1] = constant - sum;

          // get adjusted means
          for (k = 1; k <= nogrps; k++)
          {
               sum = 0.0;
               for (i = 1; i <= NoCovs; i++)
                    sum = sum + BWeights[i-1] * (GrpCovMeans[k-1][i-1]-Means[i-1]);
               AdjMeans[k-1] = AdjMeans[k-1] - sum;
               GraphForm->Ypoints[0][k-1] = AdjMeans[k-1];
               Labels[k-1] = "Group " + IntToStr(k);
          }
          // plot group means if requested
          if (plot)
          {
               GraphForm->nosets = 1;
               GraphForm->nbars = nogrps;
               GraphForm->Heading = "Adjusted Means for " + varlabel;
               GraphForm->XTitle = "GROUP";
               GraphForm->YTitle = "Mean";
               GraphForm->barwideprop = 0.5;
               GraphForm->AutoScale = false;
               GraphForm->miny = 0.0;
               GraphForm->maxy = maxmean;
               GraphForm->GraphType = 3; // 3d Vertical Bar Chart
               GraphForm->ShowBackWall = true;
               GraphForm->BackColor = clWhite;
               GraphForm->WallColor = clGray;
               GraphForm->FloorColor = clGray;
               GraphForm->ShowModal();
          }
          // print results for intercepts
          FrmOutPut->RichOutPut->Lines->Add("");
          strcpy(outline,"Intercepts for Each Group Regression Equation for Variable: ");
          strcat(outline,MainForm->Grid->Cells[FixedCols[j-1]][0].c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
          VPrint(Intercepts,nogrps,Labels,"Intercepts");
          FrmOutPut->RichOutPut->Lines->Add("");
          // print adjusted means
          FrmOutPut->RichOutPut->Lines->Add("");
          strcpy(outline,"Adjusted Group Means for Group Variables ");
          strcat(outline,MainForm->Grid->Cells[FixedCols[j-1]][0].c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
          VPrint(AdjMeans,nogrps,Labels,"Means");
          FrmOutPut->RichOutPut->Lines->Add("");
     }
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
     ClearDblVecMem(XValue);
     ClearIntVecMem(noingrp);
     delete[] Labels;
     ClearDblVecMem(Intercepts);
     ClearDblVecMem(AdjMeans);
     ClearDblMatMem(GrpCovMeans,noind);
}
//-------------------------------------------------------------------
void __fastcall TANCOVAFORM::MultCompare(TObject *Sender)
{
     int i, j, size;
     double **covmat;
     char outline[101];
     AnsiString title;
     AnsiString *Labels;
     double sum;
     double df1, df2, F, Prob;

     if (!MeansChk->Checked) return;
     GetDblMatMem(covmat,noind,noind);
     Labels = new AnsiString[noind];
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Multiple Comparisons Among Group Means");
     FrmOutPut->RichOutPut->Lines->Add("");
     SVDinverse(IndMat,noind);
     size = noind - NoCovs;
     title = "Inverse of Independents Matrix";
     for (i = 1; i <= noind; i++) Labels[i-1] = "Group " + IntToStr(i);
     for (i = 1; i <= noind-NoCovs; i++)
          for (j = 1; j <= noind-NoCovs; j++)
               covmat[i-1][j-1] = sqrt(StdErrEst) * IndMat[NoCovs+i-1][NoCovs+j-1] /
               (Variances[NoCovs+j-1] * (NoCases-1));
     for (i = 1; i <= size+1; i++) Labels[i-1] = "Group " + IntToStr(i);
     // augment matrix
     for (i = 1; i <= size; i++)
     {
          sum = 0.0;
          for (j = 1; j <= size; j++)
          {
               sum = sum + covmat[i-1][j-1];
          }
          covmat[i-1][size] = -sum;
          covmat[size][i-1] = -sum;
     }
     sum = 0.0;
     for (i = 1; i <= size; i++) sum = sum + covmat[i-1][size];
     covmat[size][size] = -sum;
     if (Inverses->Checked)
     {
          title = "Augmented Covariance Among Group Vectors";
          for (i = 1; i <= size; i++) Labels[i-1] = "Group " + IntToStr(i);
          ArrayPrint(covmat,size+1,size+1,"COVARIANCES",Labels,Labels,title.c_str());
     }

     // Now, contrast the b coefficients
     // Get last B weight from effect coding as - sum of other B weights
     BWeights[noind] = 0.0;
     for (i = 0; i < noind; i++) BWeights[noind] = BWeights[noind] - BWeights[i];
     for (i = 1; i <= size; i++)
     {
          for (j = i + 1; j <= size + 1; j++)
          {
               df1 = 1.0;
               df2 = NoCases - noind - 1;
               F = pow((BWeights[NoCovs+i-1] - BWeights[NoCovs+j-1]),2);
               if ((covmat[i-1][i-1] + covmat[j-1][j-1] - (covmat[i-1][j-1] + covmat[j-1][i-1]) <= 0.0))
               {
                  ShowMessage("Error in F testing.");
                  F = 0.01;
               }
               else F = F / (covmat[i-1][i-1] + covmat[j-1][j-1] - (covmat[i-1][j-1] + covmat[j-1][i-1]));
               Prob = ftest(df1,df2,F);
               sprintf(outline,"Comparison of Group %3d with Group %3d",
                          i,j);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"F = %10.3f, probability = %5.3f with degrees of freedom %5.0f and %5.0f",
                          F, Prob, df1, df2);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     delete[] Labels;
     ClearDblMatMem(covmat,noind);
}
//-------------------------------------------------------------------

void __fastcall TANCOVAFORM::EffectCode(int GridCol, int min, int max,
                    AnsiString FactLetter,
                    int &startcol, int &endcol,int &novectors,TObject *Sender)
{
     int levels, i, j, grp, col, cval, oldnovars;
     double **coef;
     AnsiString labelstr;

     // Routine for creating coded vectors representing group membership
     // for purposes of multiple regression effects of group membership
     levels = max - min + 1;
     GetDblMatMem(coef,levels,levels);
     novectors = levels - 1;
     startcol = NoVariables + 1;
     endcol = startcol + novectors - 1;
     col = NoVariables;
     oldnovars = NoVariables;
     // setup grid for additional columns
     for (i = 1; i < levels; i++)
     {
          labelstr = FactLetter + IntToStr(i);
          col = col++;
//          Initialize(col);
          NewVar(col,false);
          DictionaryForm->DGrid->Cells[1][col] = labelstr;
          MainForm->Grid->Cells[col][0] = labelstr;
     }

     // get coefficients for effect coding
     for (i = 1; i <= levels; i++) // group code
     {
          for (j = 1; j < levels; j++) // vector code
          {
               if (i == j) coef[i-1][j-1] = 1.0;
               if (i == levels) coef[i-1][j-1] = -1.0;
               if ((i != j) && (i != levels)) coef[i-1][j-1] = 0.0;
          }
     }

     // code the cases using coefficients above
     col = oldnovars;
     for (i = 1; i < levels; i++)
     {
          col = col + 1;
          for (j = 1; j <= NoCases; j++)
          {
               grp = ceil(StrToFloat(Trim(MainForm->Grid->Cells[GridCol][j])))
                      - min + 1; // subject group code
               cval = coef[grp-1][i-1]; // vector code
               MainForm->Grid->Cells[col][j] = IntToStr(cval);
          }
     }
     NoVariables = oldnovars + novectors;
     MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
     ClearDblMatMem(coef,levels);
}
//---------------------------------------------------------------------

void __fastcall TANCOVAFORM::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

