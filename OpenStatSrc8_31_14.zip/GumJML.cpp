//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "GumJML.h"
#include "MainUnit.h"
extern struct Options ops;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGUMForm *GUMForm;
//---------------------------------------------------------------------------
__fastcall TGUMForm::TGUMForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGUMForm::BtnOKClick(TObject *Sender)
{
    GUMForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TGUMForm::BtnCancelClick(TObject *Sender)
{
    GUMForm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TGUMForm::BtnResetClick(TObject *Sender)
{
     if (ops.format == 0)
     {
        DeltaEndEdit->Text = "0.001";
        ItemCOEdit->Text = "0.01";
        ItemAlphaEdit->Text = "0.05";
        PersonCOEdit->Text = "0.01";
        PersonAlphaEdit->Text = "0.05";
        LocalCOEdit->Text = "0.01";
        TauEndEdit->Text = "0.001";
        DeltaEndEdit->Text = "0.001";
        ThetaEndEdit->Text = "0.001";
        AvgAllEdit->Text = "0.003";
     }
     else
     {
        DeltaEndEdit->Text = "0,001";
        ItemCOEdit->Text = "0,01";
        ItemAlphaEdit->Text = "0,05";
        PersonCOEdit->Text = "0,01";
        PersonAlphaEdit->Text = "0,05";
        LocalCOEdit->Text = "0,01";
        TauEndEdit->Text = "0,001";
        DeltaEndEdit->Text = "0,001";
        ThetaEndEdit->Text = "0,001";
        AvgAllEdit->Text = "0,003";
     }
}
//---------------------------------------------------------------------------

void __fastcall TGUMForm::FormShow(TObject *Sender)
{
     BtnResetClick(this);    
}
//---------------------------------------------------------------------------

