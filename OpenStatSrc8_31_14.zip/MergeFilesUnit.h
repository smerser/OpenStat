//---------------------------------------------------------------------------

#ifndef MergeFilesUnitH
#define MergeFilesUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "stdio.h"
//---------------------------------------------------------------------------
class TMergeFilesForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TRadioGroup *SplitTypeGrp;
        TLabel *Label1;
        TEdit *FirstFileEdit;
        TLabel *Label2;
        TEdit *SecondFileEdit;
        TLabel *Label3;
        TLabel *Label4;
        TPanel *Panel1;
        TLabel *VarLabel;
        TListBox *VarList;
        TPanel *Panel2;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TListBox *VarList2;
        TLabel *Label5;
        TButton *BrowseBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall SplitTypeGrpClick(TObject *Sender);
        void __fastcall BrowseBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        AnsiString **DictTwo;
        int nrows, ncols;
        AnsiString FileName;
        FILE *FileTwo;
        char cellstr[51];

public:		// User declarations
        __fastcall TMergeFilesForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMergeFilesForm *MergeFilesForm;
//---------------------------------------------------------------------------
#endif
