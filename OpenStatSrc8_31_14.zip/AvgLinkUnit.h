//---------------------------------------------------------------------------

#ifndef AvgLinkUnitH
#define AvgLinkUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAvgLinkForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TRadioGroup *RadioGroup1;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ReturnBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
    void TreePlot(int **Clusters, int *Lst, int NoPoints);
    void PreTree(int NN, int CRIT, int *LST, int **KLUS);
public:		// User declarations
    __fastcall TAvgLinkForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAvgLinkForm *AvgLinkForm;
//---------------------------------------------------------------------------
#endif
