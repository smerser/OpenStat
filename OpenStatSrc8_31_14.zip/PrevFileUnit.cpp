//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "DataFuncs.h"
#include "PrevFileUnit.h"
extern struct Options ops;
extern int importopt;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPrevFileForm *PrevFileForm;

//---------------------------------------------------------------------------
__fastcall TPrevFileForm::TPrevFileForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPrevFileForm::FormShow(TObject *Sender)
{
     Grid->ColWidths[0] = 700;
     Grid->Cells[0][0] = "FILE NAME:";
     Grid->Cells[1][0] = "LAST USED:";
     Grid->Cells[2][0] = "TIME USED:";
//     Grid->Cells[3][0] = "FILE TYPE:";
     for (int i = 1; i < 11; i++)
     {
         if (ops.PrevFiles[i-1].FileName != "")  {
            Grid->Cells[0][i] = ops.PrevFiles[i-1].FileName;
            Grid->Cells[1][i],ops.PrevFiles[i-1].Date;
            Grid->Cells[2][i],ops.PrevFiles[i-1].Time;
         }
     }
}
//---------------------------------------------------------------------------
void __fastcall TPrevFileForm::ReturnClick(TObject *Sender)
{
     PrevFileForm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TPrevFileForm::GridClick(TObject *Sender)
{
     int row;
     AnsiString fextension;
     AnsiString PrevFileName;
     char aFileName[151];

     row = Grid->Row;
     strcpy(aFileName,Grid->Cells[0][row].c_str());
     PrevFileName = UpperCase(aFileName);
     fextension = ExtractFileExt(PrevFileName);
     MainForm->OpenDialog1->FileName = aFileName;
     if ((fextension == ".TEX") || (fextension == ".S4U") || (fextension == ".tex") || (fextension == ".s4U"))
     {
        OpenOSFile();
        return;
     }
     if ((fextension == ".TAB") || (fextension == ".tab"))
     {
        importopt = 1;
        ImportTabFile();
        return;
     }
     if ((fextension == ".CSV") || (fextension == ".csv"))
     {
        importopt = 2;
        ImportTabFile();
        return;
     }
     if ((fextension == ".SPC") || (fextension == ".spc"))
     {
        importopt = 3;
        ImportTabFile();
        return;
     }
     if ((fextension == ".REC") || (fextension == ".rec"))
     {
        MainForm->EpidataClick(this);
     }
     if ((fextension == ".OS4") || (fextension == ".BIN") || (fextension == ".os4") || (fextension == ".bin"))
     {
        OpenOS4();
     }
     if ((fextension == ".MAT") || (fextension == ".mat"))
     {
        LoadMatrix();
     }
}
//---------------------------------------------------------------------------
