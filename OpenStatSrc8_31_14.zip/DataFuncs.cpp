#include "DataFuncs.h"
#include "OptionsUnit.h"
#include "MainUnit.h"
#include "stdio.h"
#include "PrevFileUnit.h"
#include "OutPut.h"
#include "FrmSelCases.h"
#include "FrmSelIf.h"
#include "FrmSelRange.h"
#include "FrmSelRndm.h"
#include "IfParser.h"
#include "SplashUnit.h"
#include "Clipbrd.hpp"
#include "DictionaryUnit.h"
#include "dir.h"
#include "math.h"
#include "system.hpp"
#include "DirectoryUnit.h"
#include "DateFunc.h";

extern int importopt;
extern int row, col;
extern long filestart, fileend, filepos;
extern AnsiString linebuf[1000];
extern AnsiString cellstring;
extern bool openfile;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
extern NoVariables, NoCases;
extern char prtfmt[121];

struct VarDef
{
       int Sequence;
       char ShortLabel[11];
       char LongLabel[41];
       int VarType; // 0 = floating, 1 = integer, 2 = string, 3 = date, 4 = money
       int Width;
       int Decimals;
       int Justify; // 0 = Right, 1 = center, 2 = left
       int ColWide;
       int NoLabels;
       char ValLabels[100][11];  // label of up to 10 characters
       char LabelValue[100][21]; // value of up to 20 characters
};
struct VarDef *vdef[1000];
struct VarDef *TempDef;

FILE *CSVFile;
AnsiString FileName;
AnsiString DictVar[7];

//-------------------------------------------------------------------

void ImportTabFile(void)
{
   int nrows, ncols, howlong, nvars;
   AnsiString astring;
   char chr;
   char cellstr[51];
   char tabchar = '\t';
   char commachar = ',';
   char spacechar = ' ';
   char csvchar;
   char newline = '\n';
   char crreturn = '\r';
   bool labels;

   MainForm->OpenDialog1->InitialDir = GetCurrentDir();
   switch (importopt) // determine which type of import
   {
   	  case 1: csvchar = tabchar;
         MainForm->OpenDialog1->Filter = "TAB files (*.tab)|*.TAB|All files (*.*)|*.*";
         MainForm->OpenDialog1->FilterIndex = 1;
         MainForm->OpenDialog1->DefaultExt = "TAB";
         break;
      case 2: csvchar = commachar;
           MainForm->OpenDialog1->Filter = "Comma files (*.csv)|*.CSV|All files (*.*)|*.*";
           MainForm->OpenDialog1->FilterIndex = 1;
           MainForm->OpenDialog1->DefaultExt = "CSV";
           break;
      case 3: csvchar = spacechar;
           MainForm->OpenDialog1->Filter = "Space files (*.spc)|*.SPC|All files (*.*)|*.*";
           MainForm->OpenDialog1->FilterIndex = 1;
           MainForm->OpenDialog1->DefaultExt = "SPC";
           break;
   }

   if (MainForm->OpenDialog1->Execute())
   {
      astring = InputBox("VARIABLES","Are variable labels included?","Y");
      if (astring == "Y") labels = true;
      else labels = false;
//      nrows = 0;
//      ncols = 0;
      FileName = MainForm->OpenDialog1->FileName;
      MainForm->FileNameEdit->Text = FileName;
      CSVFile = fopen(FileName.c_str(),"rt");

      // read data file
      if (labels) nrows = 0;
      else nrows = 1;
      ncols = 1;
      strcpy(cellstr,"");
      howlong = 0;
      do
      {
         chr = getc(CSVFile);
         if ((chr != csvchar) && (chr != newline) && (chr != crreturn))
         {
            cellstr[howlong] = chr;
            howlong++;
         }
         if (chr == csvchar)
         {
            cellstr[howlong] = '\0';
            MainForm->Grid->Cells[ncols][nrows] = cellstr;
            if (MainForm->Grid->ColCount < ncols+1)
            	  MainForm->Grid->ColCount = ncols+1;
            ncols++;
            strcpy(cellstr,"");
            howlong = 0;
         }
         if (chr == newline)
         {
            cellstr[howlong] = '\0';
            MainForm->Grid->Cells[ncols][nrows] = cellstr;
            if (MainForm->Grid->ColCount < ncols+1)
            	  MainForm->Grid->ColCount = ncols+1;
            ncols = 1;
            if (nrows > 0) MainForm->Grid->Cells[0][nrows] = "CASE" + IntToStr(nrows);
            else MainForm->Grid->Cells[0][0] = "UNIT";
            MainForm->Grid->RowCount = nrows+1;
            if (MainForm->Grid->RowCount < nrows+1) MainForm->Grid->RowCount = nrows + 1;
            nrows++;
            strcpy(cellstr,"");
            howlong = 0;
         }
      } while (! feof(CSVFile));
      openfile = true;
      nvars = MainForm->Grid->ColCount - 1;
      MainForm->NoVarsEdit->Text = nvars;
      MainForm->NoCasesEdit->Text = IntToStr(nrows-1);
      NoCases = nrows-1;
      // create default dictionary entries
      for (int i = 1; i <= nvars; i++) NewVar(i,labels);
   } // end if open executed
   astring = ExtractFileDir(MainForm->OpenDialog1->FileName);
   OptionsForm->DataPathEdit->Text = astring;
   SetCurrentDir(OptionsForm->DataPathEdit->Text);
   UpdateOps(MainForm->SaveDialog1->FileName.c_str());
   MainForm->Grid->FixedRows = 1; // insure fixed variable row
}
//---------------------------------------------------------------------------

void OpenOSFile(void)
{
   int nrows, ncols;
   AnsiString astring;
   char cellstr[51];
//   char tabchar = '\t';
//   char newline = '\n';
   MainForm->OpenDialog1->InitialDir = GetCurrentDir();
   MainForm->OpenDialog1->DefaultExt = "TEX";
   MainForm->OpenDialog1->Filter = "OpenStat File (*.tex)|*.TEX|Text files (*.s4u)|*.S4U|All files (*.*)|*.*";
   MainForm->OpenDialog1->FilterIndex = 1;
   if (MainForm->OpenDialog1->Execute())
   {
      FileName = MainForm->OpenDialog1->FileName;
      MainForm->FileNameEdit->Text = FileName;
      CSVFile = fopen(FileName.c_str(),"rt");
      fgetpos(CSVFile,&filestart);
      fscanf(CSVFile,"%d",&nrows);
      fscanf(CSVFile,"%d",&ncols);
      MainForm->Grid->RowCount = nrows+1;
      MainForm->Grid->ColCount = ncols+1;
      DictionaryForm->DGrid->RowCount = ncols+1;
      // read dictionary definitions
      for (int i = 1; i <= ncols; i++)  // dictionary rows
      {
         for (int j = 0; j < 7; j++) // dictionary columns
         {
      	    fscanf(CSVFile,"%s",cellstr);
            int howlong = strlen(cellstr);
            cellstr[howlong] = '\0';
            DictionaryForm->DGrid->Cells[j][i] = cellstr;
         }
      }
      // read data file
      for (int i = 0; i <= nrows; i++)
      {
      	for (int j = 0; j <= ncols; j++)
         {
         	fscanf(CSVFile,"%s",cellstr);
            int howlong = strlen(cellstr);
            cellstr[howlong] = '\0';
            MainForm->Grid->Cells[j][i] = cellstr;
         }
      }
      for (int i = 1; i <= nrows; i++)
        MainForm->Grid->Cells[0][i] = "CASE " + IntToStr(i);
      openfile = true;
      MainForm->NoVarsEdit->Text = IntToStr(ncols);
      MainForm->NoCasesEdit->Text = IntToStr(nrows);
      NoVariables = ncols;
      NoCases = nrows;
      astring = ExtractFileDir(MainForm->OpenDialog1->FileName);
      OptionsForm->DataPathEdit->Text = astring;
      SetCurrentDir(OptionsForm->DataPathEdit->Text);
   }
   UpdateOps(FileName.c_str());
}
//---------------------------------------------------------------------------

void SaveOSFile(void)
{
   int nrows, ncols, pos;
   bool found = false;
   AnsiString astring;
   char tabchar = '\t';
   char newline = '\n';
   TReplaceFlags Flags;

   MainForm->SaveDialog1->InitialDir = GetCurrentDir();
   MainForm->SaveDialog1->DefaultExt = "TEX";
   MainForm->SaveDialog1->Filter = "OpenStat (*.tex)|*.TEX|All files (*.*)|*.*";
   MainForm->SaveDialog1->FilterIndex = 1;
   MainForm->SaveDialog1->FileName = MainForm->FileNameEdit->Text;
   if (MainForm->SaveDialog1->Execute())
   {
      FileName = MainForm->SaveDialog1->FileName;
      FileName = ChangeFileExt(FileName,".TEX");
      MainForm->FileNameEdit->Text = FileName;
      CSVFile = fopen(FileName.c_str(),"wt");
      nrows = MainForm->Grid->RowCount - 1;
      ncols = MainForm->Grid->ColCount - 1;
      fprintf(CSVFile,"%d%c",nrows,tabchar);
      fprintf(CSVFile,"%d%c",ncols,newline);

      // replace any blanks in dictionary cells with an underscore
      for (int i = 1; i <= ncols; i++) // dictionary rows
      {
      	for (int j = 0; j < 7; j++) // dictionary columns
         {
repeat:    	astring = Trim(DictionaryForm->DGrid->Cells[j][i]);
            pos = AnsiPos(" ",astring);
            if (pos != 0)
            {
               astring = StringReplace(astring," ","_",Flags);
               DictionaryForm->DGrid->Cells[j][i] = astring;
               found = true;
               goto repeat;
            }
         }
      }
      if (found) DictionaryForm->ShowModal();

      // print dictionary
      for (int i = 1; i <= ncols; i++) // dictionary rows
      {
      	for (int j = 0; j < 7; j++) // dictionary columns
         {
         	astring = Trim(DictionaryForm->DGrid->Cells[j][i]);
            fprintf(CSVFile,"%s%c",astring.c_str(),tabchar);
         }
         fprintf(CSVFile,"%c",newline);
      }

      // print grid
     	for (int i = 0; i <= nrows; i++)
     	{
         for (int j = 0; j <= ncols; j++)
         {
             astring = Trim(MainForm->Grid->Cells[j][i]);
             pos = AnsiPos(" ",astring);
             if (pos != 0)
             {
               astring = StringReplace(astring," ","_",Flags);
             }
             if (astring == "") astring = ops.missval;
             fprintf(CSVFile,"%s%c",astring.c_str(),tabchar);
         }
         fprintf(CSVFile,"%c",newline);
     	}
     	fclose(CSVFile);
      openfile = false;
      UpdateOps(FileName.c_str());
//      MainForm->FileNameEdit->Text = "";
   }
}
//---------------------------------------------------------------------------

void CloseFile(void)
{
   if (openfile) fclose(CSVFile);
   openfile = false;
   for (int i = 0; i < MainForm->Grid->RowCount; i++)
   for (int j = 0; j < MainForm->Grid->ColCount; j++)
   MainForm->Grid->Cells[j][i] = "";
   MainForm->Grid->RowCount = 2;
   MainForm->Grid->ColCount = 2;
   MainForm->Grid->Cells[0][1] = "CASE 1";
   MainForm->Grid->Cells[0][0] = "UNITS";
   for (int i = 1; i < DictionaryForm->DGrid->RowCount; i++)
   	for (int j = 0; j < 8; j++) DictionaryForm->DGrid->Cells[j][i] = "";
   DictionaryForm->DGrid->RowCount = 2;
   MainForm->NoCasesEdit->Text = IntToStr(0);
   MainForm->NoVarsEdit->Text = IntToStr(0);
   MainForm->FileNameEdit->Text = "";
   NewVar(1,false);
}
//---------------------------------------------------------------------------

void CopyIt(void)
{
   int rowstart, rowend, colstart, colend, size, position;
   char *buffer;
   char cellvalue[51];

   Clipboard()->Clear();
   rowstart = MainForm->Grid->Selection.Top;
   rowend = MainForm->Grid->Selection.Bottom;
   colstart = MainForm->Grid->Selection.Left;
   colend = MainForm->Grid->Selection.Right;
   size = 0;
   position = 0;
   for (int i = rowstart; i <= rowend; i++)
   	for (int j = colstart; j <= colend; j++)
      	size = size + StrLen(MainForm->Grid->Cells[j][i].c_str()) + 3;
   buffer = new char[size+3];
   for (int i = rowstart; i <= rowend; i++)
   {
   	for (int j = colstart; j <= colend; j++)
      {
          strcpy(cellvalue,MainForm->Grid->Cells[j][i].c_str());
          for (unsigned int k = 0; k < strlen(cellvalue); k++)
          {
      	       buffer[position] = cellvalue[k];
               position++;
          }
          buffer[position] = '\t';
          position++;
      }
      buffer[position] = '\r';
      position++;
      buffer[position] = '\n';
      position++;
   }
   buffer[position] = '\0';
   Clipboard()->SetTextBuf(buffer);
   delete[] buffer;
}
//---------------------------------------------------------------------------

void PasteIt(void)
{
     AnsiString astring, cellstr;
     int row, col, howlong, startcol;
     int gridrows;
//     int gridcols;
     char header[21];
     char *buffer;

     row = MainForm->Grid->Row;
     col = MainForm->Grid->Col;
     gridrows = row;
//     gridcols = col;
     startcol = col;

    // get clipboard info
    if (Clipboard()->HasFormat(CF_TEXT)) astring = Clipboard()->AsText;
    else
    {
       Application->MessageBox("The clipboard does not contain text.", NULL, MB_OK);
       return;
    }
    howlong = strlen(astring.c_str());
    buffer = new char[howlong+1];
    strcpy(buffer,astring.c_str());
    cellstr = "";
    for (int i = 0; i < howlong; i++)
    {
         if ((buffer[i] != '\t') && (buffer[i] != '\r') && (buffer[i] != '\n'))
              cellstr = cellstr + buffer[i];
         if ((buffer[i] == '\t') || (buffer[i] == '\r')) // end of a cell value in a row
         {    // going across the row
              MainForm->Grid->Cells[col][gridrows] = cellstr;
              if (col + 1 > NoVariables)
              {
                NewVar(col,false);
                NoVariables = col;
                MainForm->Grid->ColCount = NoVariables;
                MainForm->Grid->Cells[col][0] = DictionaryForm->DGrid->Cells[1][col];
              }
              col++;
              cellstr = "";
         }
         if (buffer[i] == '\r') // a new row was found for the next cell value
         {
             if (col + 1 > NoVariables)
              {
                NewVar(col,false);
                NoVariables = col;
                MainForm->Grid->ColCount = NoVariables;
                MainForm->Grid->Cells[col][0] = DictionaryForm->DGrid->Cells[1][col];
              }
                if (i+2 < howlong)
                {
                        row++;
                        MainForm->Grid->Cells[0][row] = "CASE " + IntToStr(row);
                        if (row > gridrows) gridrows = row;
                        col = startcol;
                        cellstr = "";
                }
         }
         if (buffer[i+1] == '\n') i++;
    }
    if (MainForm->Grid->RowCount <= gridrows)
    {
          MainForm->Grid->RowCount = gridrows+1;
          MainForm->NoCasesEdit->Text = MainForm->Grid->RowCount-1;
          sprintf(header,"CASE %d",gridrows+1);
          MainForm->Grid->Cells[0][gridrows+1] = header;
          NoCases = gridrows;
          MainForm->NoCasesEdit->Text = IntToStr(NoCases);
    }

    delete[] buffer;
}
//---------------------------------------------------------------------------

void DeleteIt(void)
{
     // procedure to delete a block of cells in the main grid (and put on
     // the clipboard
   int rowstart, rowend, colstart, colend, size, position;
   char *buffer;
   char cellvalue[51];

   Clipboard()->Clear();
   rowstart = MainForm->Grid->Selection.Top;
   rowend = MainForm->Grid->Selection.Bottom;
   colstart = MainForm->Grid->Selection.Left;
   colend = MainForm->Grid->Selection.Right;
   size = 0;
   position = 0;
   for (int i = rowstart; i <= rowend; i++)
   	for (int j = colstart; j <= colend; j++)
      	     size = size + StrLen(MainForm->Grid->Cells[j][i].c_str()) + 3;
   buffer = new char[size+3];
   for (int i = rowstart; i <= rowend; i++)
   {
      for (int j = colstart; j <= colend; j++)
      {
          strcpy(cellvalue,MainForm->Grid->Cells[j][i].c_str());
          for (unsigned int k = 0; k < strlen(cellvalue); k++)
          {
      	       buffer[position] = cellvalue[k];
               position++;
          }
          buffer[position] = '\t';
          position++;
          MainForm->Grid->Cells[j][i] = "";
      }
      buffer[position] = '\r';
      position++;
      buffer[position] = '\n';
      position++;
   }
   buffer[position] = '\0';
   Clipboard()->SetTextBuf(buffer);
   delete[] buffer;

   if ( (colstart == 1) && (colend == NoVariables) && (rowend == NoCases) )
   {    // bottom of grid across all variables was selected
        MainForm->Grid->RowCount = rowstart;
        NoCases = rowstart;
        MainForm->NoCasesEdit->Text = rowstart;
   }
   if ( (colend == NoVariables) && (rowstart == 1) && (rowend == NoCases) )
   {
        MainForm->Grid->ColCount = colstart;
        NoVariables = colstart;
        MainForm->NoVarsEdit->Text = colstart;
   }
}
//---------------------------------------------------------------------------

void NewVar(int col, bool labels)
{
   if (labels)
   {
      DictionaryForm->DGrid->Cells[1][col] = MainForm->Grid->Cells[col][0];
      DictionaryForm->DGrid->Cells[2][col] = MainForm->Grid->Cells[col][0];
   }
   else
   {
      DictionaryForm->DGrid->Cells[1][col] = "VAR" + IntToStr(col);
      MainForm->Grid->Cells[col][0] = "VAR" + IntToStr(col);
      DictionaryForm->DGrid->Cells[2][col] = "Variable" + IntToStr(col);
   }
   DictionaryForm->DGrid->Cells[0][col] = IntToStr(col);
   DictionaryForm->DGrid->Cells[3][col] = ops.format;
   DictionaryForm->DGrid->Cells[4][col] = ops.gridfldwidth;
   DictionaryForm->DGrid->Cells[5][col] = ops.gridnodecimals;
   DictionaryForm->DGrid->Cells[6][col] = ops.missval;
   if (col+1 > DictionaryForm->DGrid->RowCount)
       DictionaryForm->DGrid->RowCount = col + 1;
   NoVariables = DictionaryForm->DGrid->RowCount-1;
   if (NoVariables + 1 > MainForm->Grid->ColCount)
       MainForm->Grid->ColCount = NoVariables + 1;
   MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
}
//---------------------------------------------------------------------------

void InsertNewCol(int col)
{
	// Insert a new column in the grid and in the dictionary

   MainForm->Grid->ColCount++;
   NoVariables = MainForm->Grid->ColCount - 1;
   MainForm->NoVarsEdit->Text = NoVariables;
   DictionaryForm->DGrid->RowCount = DictionaryForm->DGrid->RowCount + 1;
   for (int i = NoVariables; i > col; i--)
   {
         for (int j = 0; j < MainForm->Grid->RowCount; j++)
             MainForm->Grid->Cells[i][j] = MainForm->Grid->Cells[i-1][j];
			for (int j = 0; j < 7; j++)
             DictionaryForm->DGrid->Cells[j][i] = DictionaryForm->DGrid->Cells[j][i-1];
   }
   for (int i = 0; i < MainForm->Grid->RowCount; i++) MainForm->Grid->Cells[col][i] = "";
   NewVar(col,false);
   MainForm->Grid->Col = col;
   DictionaryForm->ShowModal();
}
//---------------------------------------------------------------------------

bool ValidRecord(int row, int *ColSelected, int noselected)
{
	// check to see if this is a valid record
   AnsiString CellValue;
   bool good = true;
   int var, result;

//   CellValue = MainForm->Grid->Cells[col][row];

   if (FilterOn)
   {
       if (Trim(MainForm->Grid->Cells[FilterCol][row]) == "NO")
       {
          good = false;
          return (good);
       }
   }
   for (int i = 1; i <= noselected; i++)
   {
        var = ColSelected[i-1];
        result = ValidValue(row,var);
        if (result == 0)
        {
                good = false;
                return (good);
        }
   }

   return (good);
}
//---------------------------------------------------------------------------

void SaveOptions(void)
{
     // save results in an options file
     FILE *stream;
     struct LastUsed somefiles[10];
     AnsiString CurrDir;

//     CurrDir = GetCurrentDir();
     CurrDir = OptionsForm->HomePathEdit->Text;
//     ShowMessage("Options will be saved in: " + CurrDir);
     SetCurrentDir(CurrDir);
     stream = fopen("OPTIONS.FIL","w");
     ops.format = OptionsForm->NumbersGrp->ItemIndex;
     ops.gridfldwidth = StrToInt(OptionsForm->FldWidthEdit->Text);
     ops.gridnodecimals = StrToInt(OptionsForm->DecimalsEdit->Text);
     strcpy(ops.missval, OptionsForm->MissValEdit->Text.c_str());
//     ops.printformat = OptionsForm->NumberPrintGrp->ItemIndex;
//     ops.printwidth = StrToInt(OptionsForm->PrntWideEdit->Text);
//     ops.printdecimals = StrToInt(OptionsForm->PrintNoDecEdit->Text);
//     strcpy(ops.printmissvals, OptionsForm->PrintMissValEdit->Text.c_str());
//     ops.printspaces = StrToInt(OptionsForm->PrintSpacesEdit->Text);
     CurrDir = OptionsForm->DataPathEdit->Text;
//     CurrDir = GetCurrentDir();
//     SetCurrentDir(CurrDir);
     OptionsForm->DirectoryList->Directory = CurrDir;
//     OptionsForm->DataPathEdit->Text = CurrDir;
     DirectoryForm->DirectoryList->Directory = CurrDir;
//     DirectoryForm->PathEdit->Text = CurrDir;
//     SetCurrentDir(OptionsForm->PathEdit->Text);
     strcpy(ops.DataPath,CurrDir.c_str());
     for (int i = 0; i < 10; i++)  {
            strcpy(ops.PrevFiles[i].FileName,PrevFileForm->Grid->Cells[0][i+1].c_str());
            strcpy(ops.PrevFiles[i].Date,PrevFileForm->Grid->Cells[1][i+1].c_str());
            strcpy(ops.PrevFiles[i].Time,PrevFileForm->Grid->Cells[2][i+1].c_str());
     }

     fwrite(&ops,sizeof(ops)+1,1,stream);
     fclose(stream);
     SetCurrentDir(CurrDir);
//     GetOptions();
}
//------------------------------------------------------------------------

void GetOptions(void)
{
     FILE *stream;
     char astring[151];
     int fldwide, decplaces, spaces;
     AnsiString CurrDir;

     CurrDir = GetCurrentDir();
//     ShowMessage("Options will be obtained from: " + CurrDir);
     SetCurrentDir(CurrDir);
     if ((stream = fopen("OPTIONS.FIL", "r")) == NULL)
     {
        SplashForm->ShowModal();
//        OptionsForm->ShowModal();
        return;
     }
     else
     {
        // select data directory
        fread(&ops,sizeof(ops)+1,1,stream);
        OptionsForm->NumbersGrp->ItemIndex = ops.format;
        if (OptionsForm->NumbersGrp->ItemIndex == 1) DecimalSeparator = ',';
        else DecimalSeparator = '.';
        OptionsForm->FldWidthEdit->Text = IntToStr(ops.gridfldwidth);
        OptionsForm->DecimalsEdit->Text = IntToStr(ops.gridnodecimals);
        OptionsForm->MissValEdit->Text = ops.missval;
//        OptionsForm->NumberPrintGrp->ItemIndex = ops.printformat;
//        OptionsForm->PrntWideEdit->Text = IntToStr(ops.printwidth);
//        OptionsForm->PrintNoDecEdit->Text = IntToStr(ops.printdecimals);
//        OptionsForm->PrintMissValEdit->Text = ops.printmissvals;
//        OptionsForm->PrintSpacesEdit->Text = IntToStr(ops.printspaces);
        OptionsForm->HomePathEdit->Text = ops.HomePath;
        OptionsForm->DataPathEdit->Text = ops.DataPath;
        CurrDir = OptionsForm->DataPathEdit->Text;
        SetCurrentDir(OptionsForm->DataPathEdit->Text);
        OptionsForm->DirectoryList->Directory = CurrDir;
//        OptionsForm->PathEdit->Text = CurrDir;
        DirectoryForm->DirectoryList->Directory = CurrDir;
        DirectoryForm->PathEdit->Text = CurrDir;
        for (int i = 0; i < 10; i++)
        {
            PrevFileForm->Grid->Cells[0][i+1] = ops.PrevFiles[i].FileName;
            PrevFileForm->Grid->Cells[1][i+1] = ops.PrevFiles[i].Date;
            PrevFileForm->Grid->Cells[2][i+1] = ops.PrevFiles[i].Time;
        }
     }
     fclose(stream);

     // create the output format for printing individual values
     // may be used in new versions for output formatting
     strcpy(prtfmt,""); // clear previous format
     decplaces = ops.gridnodecimals; //ops.printdecimals;
     fldwide = ops.gridfldwidth; // ops.printwidth;
     spaces = 2; // ops.printspaces;
     strcpy(prtfmt,"%");
     sprintf(astring,"%d",fldwide);
     strcat(prtfmt,astring);
     if (ops.format == 0) strcat(prtfmt,"."); // American decimal point "."
     else strcat(prtfmt,","); // European style decimal point ","
     sprintf(astring,"%d",decplaces);
     strcat(prtfmt,astring);
     strcat(prtfmt,"f");
//     if (ops.printformat == 0) strcat(prtfmt,"f");
//     else strcat(prtfmt,"E");
     for (int i = 0; i <= spaces; i++) strcat(prtfmt," ");
}
//------------------------------------------------------------------------

int isnumber(char value[])
{
// checks to see if the string contains all numbers
   int number = 1;

   for (unsigned int i = 0; i < strlen(value); i++)
   {
     if (isalpha(value[i]))
     {
        if ((value[i] == ',') && (ops.format == 1)) number = 1; // European
        else number = 0;
     }
   }
   return (number);
}
//---------------------------------------------------------------------------

int ValidValue(int row, int var)
{
   int vartype, good;
   AnsiString cellstr;
   int intmiss, intvalue;
   double dblmiss, dblvalue;

   if (var > DictionaryForm->DGrid->RowCount-1)
   {
      AnsiString astring;
      astring = "No definition found for variable " + IntToStr(var);
      ShowMessage(astring);
      return(0);
   }

   good = 1;
   vartype = StrToInt(DictionaryForm->DGrid->Cells[3][var]);
   switch (vartype)  {
      case 0 : {  // floating point
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            good = 0;
            break;
         }
         if (isnumber(cellstr.c_str())) good = 1;
         dblvalue = StrToFloat(cellstr);
         dblmiss = StrToFloat(DictionaryForm->DGrid->Cells[6][var]);    //atof(ops.missval);
         if (dblvalue == dblmiss) good = 0;
      } break;
      case 1 : { // integer
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            good = 0;
            break;
         }
         if (isnumber(cellstr.c_str())) good = 1;
         intvalue = StrToInt(cellstr);
         intmiss = StrToInt(DictionaryForm->DGrid->Cells[6][var]);      //atoi(ops.missval);
         if (intvalue == intmiss) good = 0;
      } break;
      case 2 : { // string - no action needed
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            good = 0;
            break;
         }
         if (strcmp(cellstr.c_str(),ops.missval) != 0) good = 0;
         else good = 1;
      } break;
      case 3 :  { // date - convert to integer
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            good = 0;
            break;
         }
        good = 1;
      } break;
      case 4 : {  // money - remove dollar sign
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            good = 0;
            break;
         }
         good = 1;
      } break;
   }

   return (good);
}
//---------------------------------------------------------------------------

void PrintCases(void)
{
    char outline[121];
    int startcol = 0;
    int endcol;
    bool done = false;
    double X;
    AnsiString cellstring;
    char valstr[21];

//    NoCases = MainForm->Grid->RowCount-1;
    FrmOutPut->RichOutPut->Clear();
    sprintf(outline,"\n\nCASES FOR FILE %s",FileName);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    while (!done)
    {
 		endcol = startcol + 6;
        if (endcol > MainForm->Grid->ColCount) endcol = MainForm->Grid->ColCount;
        for (int i = 0; i <= NoCases; i++)
        {
           strcpy(outline,"");
           for (int j = startcol; j <= endcol; j++)
           {
              sprintf(valstr,"  %10s",MainForm->Grid->Cells[j][i].c_str());
              strcat(outline,valstr);
           }
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        if (endcol == MainForm->Grid->ColCount) done = true;
        else
        {
            startcol = endcol + 1;
            FrmOutPut->RichOutPut->Lines->Add("");
        }
    }
    FrmOutPut->ShowModal();
}
//------------------------------------------------------------------

void DeleteaCol(int col)
{
    char TempStr[21] = "";

    // First, be sure every cell has a string (even blank)
    for (int j = 0; j < MainForm->Grid->RowCount; j++)
        if (MainForm->Grid->Cells[col][j] == "") MainForm->Grid->Cells[col][j] = " ";

	 // copy values from the Dictionary
    for (int i = 0; i < 7; i++) DictVar[i] = DictionaryForm->DGrid->Cells[i][col];

    char *buf = MainForm->Grid->Cols[col]->GetText();
    Clipboard()->SetTextBuf(buf);
    if (MainForm->Grid->ColCount > 2)
    {
    	for (int i = col+1; i < MainForm->Grid->ColCount; i++)
        {
            for (int j = 0; j < 7; j++)
            	DictionaryForm->DGrid->Cells[j][i-1] = DictionaryForm->DGrid->Cells[j][i];
        		for (int j = 0; j < MainForm->Grid->RowCount; j++)
            	MainForm->Grid->Cells[i-1][j] = MainForm->Grid->Cells[i][j];
        }
 	    for (int j = 0; j < MainForm->Grid->RowCount; j++)
                 MainForm->Grid->Cells[MainForm->Grid->ColCount-1][j] = "";
        MainForm->Grid->ColCount--; // reduce grid no. of columns
        DictionaryForm->DGrid->RowCount--;
        NoVariables = MainForm->Grid->ColCount - 1;
        itoa(NoVariables,TempStr,10);
        MainForm->NoVarsEdit->Text = TempStr;
    }
}
//--------------------------------------------------------------------------

void InsertaRow(int row)
{
     char TempStr[21];
     char NoStr[11];

     MainForm->Grid->RowCount++;
     for (int i = MainForm->Grid->RowCount-1; i > row; i--)
     {
        for (int j = 0; j < MainForm->Grid->ColCount; j++)
        {
        	MainForm->Grid->Cells[j][i] = MainForm->Grid->Cells[j][i-1];
        }
     }
     for (int i = 1; i < MainForm->Grid->RowCount; i++)
     {
        strcpy(TempStr,"CASE:");
        itoa(i,NoStr,10);
        strcat(TempStr,NoStr);
        MainForm->Grid->Cells[0][i] = TempStr;
     }
     for (int j = 1; j < MainForm->Grid->ColCount; j++)
          MainForm->Grid->Cells[j][row] = "";
     NoCases = MainForm->Grid->RowCount - 1;
     MainForm->NoCasesEdit->Text = NoCases;
}

//---------------------------------------------------------------------------


void CutaRow(int row)
{
    // First, be sure every cell has a string (even blank)
    for (int j = 0; j < MainForm->Grid->ColCount; j++)
        if (MainForm->Grid->Cells[j][row] == "") MainForm->Grid->Cells[j][row] = " ";

    char *buf = MainForm->Grid->Rows[row]->GetText();
    Clipboard()->SetTextBuf(buf);
    for (int i = row; i < MainForm->Grid->RowCount-1; i++)
    {
        for (int j = 0; j < MainForm->Grid->ColCount; j++)
            MainForm->Grid->Cells[j][i] = MainForm->Grid->Cells[j][i+1];
    }
    MainForm->Grid->RowCount--;
    NoCases = MainForm->Grid->RowCount - 1;
    MainForm->NoCasesEdit->Text = NoCases;
}
//---------------------------------------------------------------------------

void CopyaRow(int row)
{
    // First, be sure every cell has a string (even blank)
    for (int j = 0; j < MainForm->Grid->ColCount; j++)
        if (MainForm->Grid->Cells[j][row] == "") MainForm->Grid->Cells[j][row] = " ";
    char *buf = MainForm->Grid->Rows[row]->GetText();
    Clipboard()->SetTextBuf(buf);
}
//---------------------------------------------------------------------------

void PasteaRow(int row)
{
    char buf[100001];

    Clipboard()->GetTextBuf(buf,100000);
    MainForm->Grid->Rows[row]->SetText(buf);
    if (MainForm->Grid->RowCount > NoCases)
    {
        NoCases++;
        MainForm->NoCasesEdit->Text = NoCases;
    }
}
//---------------------------------------------------------------------------

void CopyaCol(int col)
{
	 // copy values from the Dictionary
    for (int i = 0; i < 7; i++) DictVar[i] = DictionaryForm->DGrid->Cells[i][col];

    // First, be sure every cell has a string (even blank)
    for (int j = 0; j < MainForm->Grid->RowCount; j++)
        if (MainForm->Grid->Cells[col][j] == "") MainForm->Grid->Cells[col][j] = " ";
    char *buf = MainForm->Grid->Cols[col]->GetText();
    Clipboard()->SetTextBuf(buf);
}
//---------------------------------------------------------------------------

void PasteaCol(int col)
{
    char buf[100001];
    AnsiString astring;

    Clipboard()->GetTextBuf(buf,100000);
    MainForm->Grid->Cols[col]->SetText(buf);
	 // copy values to the Dictionary
    for (int i = 0; i < 7; i++) DictionaryForm->DGrid->Cells[i][col] = DictVar[i] ;
    MainForm->Grid->Cells[col][0] = DictVar[1];

    if (col > NoVariables)
    {
        MainForm->NoVarsEdit->Text = col;
        NoVariables = col;
    }
}
//---------------------------------------------------------------------------

void UpdateOps(char FileName[])
{
//  Move first 9 options down and add FileName to top of list
    AnsiString astring;
    char today[21];
    char time[21];

    if (strlen(FileName) < 1) return;
    for (int i = 8; i >= 0; i--)  {
        strcpy(ops.PrevFiles[i+1].FileName,ops.PrevFiles[i].FileName);
        strcpy(ops.PrevFiles[i+1].Date,ops.PrevFiles[i].Date);
        strcpy(ops.PrevFiles[i+1].Time,ops.PrevFiles[i].Time);
    }
    strcpy(ops.PrevFiles[0].FileName,FileName);
    astring = DateToStr(Date());
    strcpy(today,astring.c_str());
    astring = TimeToStr(Time());
    strcpy(time,astring.c_str());
    strcpy(ops.PrevFiles[0].Date,today);
    strcpy(ops.PrevFiles[0].Time,time);

    //  update the PrevFileForm grid
    UpdatePrev();
    // save the options file
//    SaveOptions();
}
//---------------------------------------------------------------------------

void UpdatePrev(void)
{
     // read the 10 ops structure members for previously read files into the
     // grid for the previous files
     for (int i = 0; i < 10; i++)  {
         PrevFileForm->Grid->Cells[0][i+1] = ops.PrevFiles[i].FileName;
         PrevFileForm->Grid->Cells[1][i+1] = ops.PrevFiles[i].Date;
         PrevFileForm->Grid->Cells[2][i+1] = ops.PrevFiles[i].Time;
     }
}
//---------------------------------------------------------------------------

void SaveCSVFile(void)
{
     FILE *CSVFile;
     int nrows, ncols;
     AnsiString astring;
     char tabchar = '\t';
     char commachar = ',';
     char spacechar = ' ';
     char csvchar;
     char newline = '\n';

     MainForm->SaveDialog1->InitialDir = GetCurrentDir();
     switch (importopt) // determine which type of import
     {
        case 1:
              MainForm->SaveDialog1->Filter = "Tab files (*.tab)|*.TAB|All files (*.*)|*.*";
              MainForm->SaveDialog1->FilterIndex = 1;
              MainForm->SaveDialog1->DefaultExt = "TAB";
              csvchar = tabchar;
              break;
        case 2: csvchar = commachar;
              MainForm->SaveDialog1->Filter = "Comma files (*.csv)|*.CSV|All files (*.*)|*.*";
              MainForm->SaveDialog1->FilterIndex = 1;
              MainForm->SaveDialog1->DefaultExt = "CSV";
              break;
        case 3: csvchar = spacechar;
              MainForm->SaveDialog1->Filter = "Space files (*.spc)|*.SPC|All files (*.*)|*.*";
              MainForm->SaveDialog1->FilterIndex = 1;
              MainForm->SaveDialog1->DefaultExt = "SPC";
              break;
     }

     if (MainForm->SaveDialog1->Execute())
     {
        FileName = MainForm->SaveDialog1->FileName;
        switch (importopt)
        {
           case 1: ChangeFileExt(FileName,".TAB");
                   break;
           case 2: ChangeFileExt(FileName,".CSV");
                   break;
           case 3: ChangeFileExt(FileName,".SPC");
                   break;
        }
        CSVFile = fopen(FileName.c_str(),"wt");
//        CSVFile = fopen(MainForm->SaveDialog1->FileName.c_str(),"wt");
        nrows = MainForm->Grid->RowCount - 1;
        ncols = MainForm->Grid->ColCount - 1;
        for (int i = 0; i <= nrows; i++)
        {
            for (int j = 1; j < ncols; j++)
            {
                astring = Trim(MainForm->Grid->Cells[j][i]);
                fprintf(CSVFile,"%s%c",astring.c_str(),csvchar);
            }
            astring = Trim(MainForm->Grid->Cells[ncols][i]);
            fprintf(CSVFile,"%s",astring.c_str());
            fprintf(CSVFile,"%c",newline);
        }
        MainForm->FileNameEdit->Text = FileName;
        fclose(CSVFile);
        openfile = false;
        UpdateOps(FileName.c_str());
//        UpdateOps(MainForm->SaveDialog1->FileName.c_str());
     }
}
//------------------------------------------------------------------------

void SelectCases(void)
{
   AnsiString cellstring;
   bool FilterVar = false;
   bool FilterDel = false;
   bool IfFilter = false;
   bool RandomFilter = false;
   bool RangeFilter = false;
   bool AllCases = true;
   char outline[73] = "";
   long int filtcol;

   SelCases->ListBox1->Clear();
   SelIf->LstVars->Clear();
   for (int i = 1; i <= NoVariables; i++) // load variables in list
   {
      cellstring = MainForm->Grid->Cells[i][0];
      SelCases->ListBox1->Items->Add(cellstring);
      SelIf->LstVars->Items->Add(cellstring);
   }

   SelCases->ShowModal();
   if (SelCases->ModalResult == mrCancel) return;

   if (SelCases->BtnSelAll->Checked) // no selection
   {
       FilterOn = false;
       MainForm->StatusEdit->Text = "Filter OFF";
       NoCases = MainForm->Grid->RowCount - 1;
       return;
   }

   if (SelCases->BtnFilter->Checked) // use filter variable
   {
      cellstring = SelCases->TxtFilterVar->Text;
      FilterVar = true;
      AllCases = false;
      if (SelCases->BtnUnselDel->Checked)
      {
         FilterDel = true;
         FilterOn = true;
      }
      else  FilterDel = false;
   }

   if (SelCases->BtnIfCondition->Checked)
   {
        IfFilter = true;
        FilterOn = true;
        AllCases = false;
        if (SelCases->BtnUnselDel->Checked) FilterDel = true;
        else FilterDel = false;
   }
   if (SelCases->BtnRandom->Checked)
   {
      RandomFilter = true;
      FilterOn = true;
      AllCases = false;
      // selection by percentage or number of first N cases?
      if (SelCases->BtnUnselDel->Checked) FilterDel = true;
      else FilterDel = false;
   }
   if (SelCases->BtnCaseRange->Checked)
   {
      // get values of first and last case
      RangeFilter = true;
      FilterOn = true;
      AllCases = false;
      if (SelCases->BtnUnselDel->Checked) FilterDel = true;
      else FilterDel = false;
   }
   if (SelCases->BtnFilter->Checked)
   {
       FilterOn = true;
       FilterVar = true;
   }
   if (!FilterOn && AllCases) // no current filtering and none to be done
    	return;
   else  // filter is on to use
   {
        if (RangeFilter || RandomFilter || IfFilter)
        {
            // create a filter variable and select cases
            if (NoVariables+1 == MainForm->Grid->ColCount) // Need another column?
            {
               MainForm->Grid->ColCount++;
               NoVariables++;
               sprintf(outline,"%d",NoVariables);
               MainForm->NoVarsEdit->Text = outline;
            }
            filtcol = MainForm->Grid->ColCount-1;
            FilterCol = filtcol;
            NewVar(filtcol,false);
        }
    	  // select cases using the method selected
        if (RangeFilter)
        {
            int FirstCase = StrToInt(SelRange->TxtFirstCase->Text);
            int LastCase = StrToInt(SelRange->TxtLastCase->Text);
            strcpy(outline,"RangeFilter");
            MainForm->Grid->Cells[filtcol][0] = outline;
            DictionaryForm->DGrid->Cells[1][filtcol] = outline;
            DictionaryForm->DGrid->Cells[2][filtcol] = outline;
            for (int i = 1; i < MainForm->Grid->RowCount; i++)
            {
            	if ((i >= FirstCase) && (i <= LastCase)) // match found
                {
                	  MainForm->Grid->Cells[filtcol][i] = "YES";
                }
                else MainForm->Grid->Cells[filtcol][i] = "NO";
            }
        }

        if (RandomFilter)
        {
            strcpy(outline,"RandomFilter");
            MainForm->Grid->Cells[filtcol][0] = outline;
            DictionaryForm->DGrid->Cells[1][filtcol] = outline;
            DictionaryForm->DGrid->Cells[2][filtcol] = outline;
            randomize();
            if (SelRndm->BtnApprox->Checked) // % of cases
            {
            	double pcntrndm = atof(SelRndm->TxtPcntCases->Text.c_str());
                int norndm = (pcntrndm / 100.0) * double(NoCases);
                for (int i = 0; i < norndm; i++)
                {
                	int caserow = random(NoCases) + 1;
                    if (MainForm->Grid->Cells[filtcol][caserow] != "YES")
                        MainForm->Grid->Cells[filtcol][caserow] = "YES";
                    else i--;
                }
            }
            else // exact no from first N cases
            {
            	int norndm = atoi(SelRndm->TxtCases->Text.c_str());
                int cases = atoi(SelRndm->TxtFromFirst->Text.c_str());
                for (int i = 0; i < norndm; i++)
                {
                	int caserow = random(cases) + 1;
                    if (MainForm->Grid->Cells[filtcol][caserow] != "YES")
                        MainForm->Grid->Cells[filtcol][caserow] = "YES";
                    else i--;
                }
            }
            // put NO in all without a YES
            for (int i = 1; i <= NoCases; i++)
            {
            	if (MainForm->Grid->Cells[filtcol][i] != "YES")
                	MainForm->Grid->Cells[filtcol][i] = "NO";
            }
        } // end if random filter

        if (FilterVar) // use existing filter variable
        {
            AnsiString filtvar = SelCases->TxtFilterVar->Text;
            // find column of the filter variable
            filtcol = 0;
            for (int i = 1; i <= NoVariables; i++)
            {
               	cellstring = MainForm->Grid->Cells[i][0];
                if (cellstring == filtvar)
                {
                   	filtcol = i;
                    break;
                }
            }
            FilterCol = filtcol;
            if (filtcol == 0)
            {
               FilterOn = false; //invalid filter column
            }
            return;
        } // end if filter variable

        if (IfFilter)
        {
            char Expression[600]; //If expression text string from SelIf control
            char **ExpList; // List of sub-expressions parsed from above
            char **LeftValue; // String left of Op code for each sub-expr.
            char **RightValue; // String right of Op code for each sub-ex.
            char **JoinOps; // Logic operation code joining sub-expressions
            char **Ops; // Operation code between left and right values
            int NoExpr; // No. of sub-expressions parsed from Expression
            bool TValue[20]; // Boolean result from evaluating sub-express.
            bool result, Truth;
            char **VarLabels; // Labels of variables
            try
            {
                VarLabels = new char *[NoVariables];
                for (int i = 0; i < NoVariables; i++) VarLabels[i] = new char[21];
                ExpList = new char*[20];
                for (int i = 0; i < 20; i++) ExpList[i] = new char[31];
                LeftValue = new char*[20];
                for (int i = 0; i < 20; i++) LeftValue[i] = new char[31];
                RightValue = new char*[20];
                for (int i = 0; i < 20; i++) RightValue[i] = new char[31];
                JoinOps = new char*[20];
                for (int i = 0; i < 20; i++) JoinOps[i] = new char[5];
                Ops = new char*[20];
                for (int i = 0; i < 20; i++) Ops[i] = new char[5];
            }
		      catch (...) // This block entered only if xalloc is thrown.
			   {
    			   ShowMessage("Could not allocate memory.");
	            return;
			   }

            for (int i = 0; i < NoVariables; i++)
            {
               AnsiString tempstr = Trim(MainForm->Grid->Cells[i+1][0]);
            	strcpy(VarLabels[i],tempstr.c_str());
            }
            strcpy(outline,"IfFilter");
            MainForm->Grid->Cells[filtcol][0] = outline;
            DictionaryForm->DGrid->Cells[1][filtcol] = outline;
            DictionaryForm->DGrid->Cells[2][filtcol] = outline;
            strcpy(Expression,SelIf->TxtIfExpr->Text.c_str());

            parse(Expression, ExpList,NoExpr, Ops, LeftValue, RightValue,JoinOps);

            // Now, for each sub-expression, check left and right values for
            // matching variable(s) or numeric values and apply the operation
            // to each record in the grid.
            for (int i = 1; i <= NoCases; i++)
            {
             	for (int j = 0; j <= NoExpr; j++)
               {
                	TValue[j] = TruthValue(i,j,LeftValue[j],RightValue[j],\
                 	Ops, VarLabels, NoVariables);
               }
               // Now, evaluate the truth table using joining operations
               if (NoExpr > 0)
               {
                   Truth = true;
                   for (int j = 0; j < NoExpr; j++)
                   {
                 	   result = false;
                     if (strcmp(JoinOps[j],".A") == 0)  { // AND
                        if (TValue[j] && TValue[j+1]) result = true;
                     }
                     if (strcmp(JoinOps[j],".O") == 0) { // OR
                        if (TValue[j] || TValue[j+1]) result = true;
                     }
                     if (strcmp(JoinOps[j],".N") == 0) { // NOT
                        if (!TValue[j]) result = true;
                     }
                     if (result == false) Truth = false;
                   }
               }
               else Truth = TValue[0];
               if (Truth) MainForm->Grid->Cells[filtcol][i] = "YES";
               else MainForm->Grid->Cells[filtcol][i] = "NO";
            } // end i case
			for (int i = 0; i < NoVariables; i++) delete[] VarLabels[i];
            delete[] VarLabels;
	        for (int i = 0; i < 20; i++) delete[] Ops[i];
            delete[] Ops;
        	for (int i = 0; i < 20; i++) delete[] JoinOps[i];
	        delete[] JoinOps;
            for (int i = 0; i < 20; i++) delete[] RightValue[i];
        	delete[] RightValue;
	        for (int i = 0; i < 20; i++) delete[] LeftValue[i];
            delete[] LeftValue;
        	for (int i = 0; i < 20; i++) delete[] ExpList[i];
	        delete[] ExpList;
        } // end if if-expression filter

        if (FilterVar) // use existing filter variable
        {
            AnsiString filtvar = SelCases->TxtFilterVar->Text;
            // find column of the filter variable
            filtcol = 0;
            for (int i = 1; i <= NoVariables; i++)
            {
               	cellstring = MainForm->Grid->Cells[i][0];
                if (cellstring == filtvar)
                {
                   	filtcol = i;
                    break;
                }
            }
            FilterCol = filtcol;
            if (filtcol == 0)
            {
               FilterOn = false; //invalid filter column
            }
        } // end if filter variable

        // Should we delete the "NO" rows?
        if (FilterDel)
        {
            int delrow = 1;
            while (delrow < MainForm->Grid->RowCount)
            {
             	if (MainForm->Grid->Cells[filtcol][delrow] == "NO") // delete it!
                	CutaRow(delrow);
               else delrow++;
            }
        }
   } // end else

   if (FilterOn) MainForm->StatusEdit->Text = "Filter ON";
   else MainForm->StatusEdit->Text = "Filter OFF";
}
//---------------------------------------------------------------------------

void ChangeSeparator(void)
{
     char cellstr[51];
     AnsiString cellvalue;

     for (int i = 1; i <= NoVariables; i++)
     {
         for (int j = 1; j <= NoCases; j++)
         {
             strcpy(cellstr, MainForm->Grid->Cells[i][j].c_str());
             for (unsigned int k = 0; k < strlen(cellstr); k++)
             {
                 if ((ops.format == 1) && (cellstr[k] == '.')) cellstr[k] =',';
                 if ((ops.format == 0) && (cellstr[k] == ',')) cellstr[k] = '.';
             }
             cellvalue = cellstr;
             MainForm->Grid->Cells[i][j] = cellvalue;
         }
     }
}
//---------------------------------------------------------------------

void RowColSwap(void)
{
     int Rows, Cols;
     char tempcell[21];
     AnsiString **tempgrid;
     AnsiString astring;

     Rows = NoCases + 1;
     Cols = NoVariables + 1;

     // allocate grid memory
     tempgrid = new AnsiString *[Cols];
     for (int i = 0; i < Cols; i++) tempgrid[i] = new AnsiString[Rows];

     // store grid
     for (int i = 0; i < Cols; i++)
         for (int j = 0; j < Rows; j++) tempgrid[i][j] = MainForm->Grid->Cells[i][j];
     for (int i = 0; i < Cols; i++)
         for (int j = 0; j < Rows; j++) MainForm->Grid->Cells[j][i] = tempgrid[i][j];

     // Delete old dictionary definitions
     for (int i = 1; i <= Cols; i++) // dictionary grid rows
     {
         for (int j = 0; j < 7; j++) DictionaryForm->DGrid->Cells[j][i] = "";
     }
     DictionaryForm->DGrid->RowCount = 1;

     // update variable definitions
     for (int col = 1; col < Rows; col++)
     {
        NewVar(col,true);
        MainForm->Grid->ColCount = col + 1;
        NoVariables = col;
        MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
     }

     // set no. of variables and cases in grid
     NoVariables = Rows-1;
     NoCases = Cols - 1;
     MainForm->NoVarsEdit->Text = NoVariables;
     MainForm->NoCasesEdit->Text = NoCases;
     MainForm->Grid->RowCount = NoCases + 1;
     MainForm->Grid->ColCount = NoVariables + 1;

     // cleanup
     for (int i = 0; i < Cols; i++) delete[] tempgrid[i];
     delete[] tempgrid;
}
//---------------------------------------------------------------------

void GridSort(void)
{
     int col = MainForm->Grid->Col;
     AnsiString Temp;
     AnsiString response;

     response = InputBox("DIRECTION:","Ascending(A) or Descending(D):","A");
     if (response == "D") goto L100;
     if (DictionaryForm->DGrid->Cells[3][col] < 2)
     {
        for (int i = 1; i < MainForm->Grid->RowCount-1; i++) // accross rows
        {
            for (int j = i+1; j < MainForm->Grid->RowCount; j++)
            {
                if (StrToFloat(Trim(MainForm->Grid->Cells[col][i])) > StrToFloat(Trim(MainForm->Grid->Cells[col][j]))) // swap
                {
                   for (int k = 0; k < MainForm->Grid->ColCount; k++)
                   {
                       Temp = MainForm->Grid->Cells[k][i];
                       MainForm->Grid->Cells[k][i] = MainForm->Grid->Cells[k][j];
                       MainForm->Grid->Cells[k][j] = Temp;
                   }
                }
            }
        }
     }
     else
     {
        for (int i = 1; i < MainForm->Grid->RowCount-1; i++) // accross rows
        {
            for (int j = i+1; j < MainForm->Grid->RowCount; j++)
            {
                if (Trim(MainForm->Grid->Cells[col][i]) > Trim(MainForm->Grid->Cells[col][j])) // swap
                {
                   for (int k = 0; k < MainForm->Grid->ColCount; k++)
                   {
                       Temp = MainForm->Grid->Cells[k][i];
                       MainForm->Grid->Cells[k][i] = MainForm->Grid->Cells[k][j];
                       MainForm->Grid->Cells[k][j] = Temp;
                   }
                }
            }
        }
     }
     return;
L100:

     if (DictionaryForm->DGrid->Cells[3][col] < 2)
     {
        for (int i = 1; i < MainForm->Grid->RowCount-1; i++) // accross rows
        {
            for (int j = i+1; j < MainForm->Grid->RowCount; j++)
            {
                if (StrToFloat(Trim(MainForm->Grid->Cells[col][i])) < StrToFloat(Trim(MainForm->Grid->Cells[col][j]))) // swap
                {
                   for (int k = 0; k < MainForm->Grid->ColCount; k++)
                   {
                       Temp = MainForm->Grid->Cells[k][i];
                       MainForm->Grid->Cells[k][i] = MainForm->Grid->Cells[k][j];
                       MainForm->Grid->Cells[k][j] = Temp;
                   }
                }
            }
        }
     }
     else
     {
        for (int i = 1; i < MainForm->Grid->RowCount-1; i++) // accross rows
        {
            for (int j = i+1; j < MainForm->Grid->RowCount; j++)
            {
                if (Trim(MainForm->Grid->Cells[col][i]) < Trim(MainForm->Grid->Cells[col][j])) // swap
                {
                   for (int k = 0; k < MainForm->Grid->ColCount; k++)
                   {
                       Temp = MainForm->Grid->Cells[k][i];
                       MainForm->Grid->Cells[k][i] = MainForm->Grid->Cells[k][j];
                       MainForm->Grid->Cells[k][j] = Temp;
                   }
                }
            }
        }
     }
}
//---------------------------------------------------------------------------

void PrintDict(void)
{
     int startcell, endcell;
     bool done;
     AnsiString outline;
     char cellstr[81];

     DictionaryForm->DGrid->Cells[0][0] = "No.";
     DictionaryForm->DGrid->Cells[0][1] = IntToStr(1);
     DictionaryForm->DGrid->Cells[1][0] = "Short Name";
     DictionaryForm->DGrid->Cells[2][0] = "Long Name";
     DictionaryForm->DGrid->Cells[3][0] = "Type";
     DictionaryForm->DGrid->Cells[4][0] = "Integers";
     DictionaryForm->DGrid->Cells[5][0] = "Decimals";
     DictionaryForm->DGrid->Cells[6][0] = "Missing";
     for (int i = 0; i < DictionaryForm->DGrid->RowCount; i++)
     {
         sprintf(cellstr,"%4s %10s %30s %4s %8s %8s %7s",
            DictionaryForm->DGrid->Cells[0][i].c_str(),
            DictionaryForm->DGrid->Cells[1][i].c_str(),
            DictionaryForm->DGrid->Cells[2][i].c_str(),
            DictionaryForm->DGrid->Cells[3][i].c_str(),
            DictionaryForm->DGrid->Cells[4][i].c_str(),
            DictionaryForm->DGrid->Cells[5][i].c_str(),
            DictionaryForm->DGrid->Cells[6][i].c_str());
         outline = cellstr;
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void FormatCells(void)
{
     int nrows, ncols;

     nrows = MainForm->Grid->RowCount-1;
     ncols = MainForm->Grid->ColCount-1;
     for (int i = 1; i <= ncols; i++)  {
        for (int j = 1; j <= nrows; j++)  {
        FmtCell(j,i);
        } // next row
     } // next column
}
//------------------------------------------------------------------------

void FmtCell(int row, int col)
{
     AnsiString cellstr;
     int i, j, valtype, align, cellwide, decplaces, fldwide;
     char fmt[41];
     char astring[41];
     double X;

     i = col;
     j = row;
     cellstr = Trim(MainForm->Grid->Cells[i][j]);
     if (cellstr == "") return;
     if (cellstr == ops.missval) return;
     if (DictionaryForm->DGrid->RowCount > col)  {
        valtype = StrToInt(DictionaryForm->DGrid->Cells[3][col]);
//        cellwide = StrToInt(DictionaryForm->DGrid->Cells[4][col]);
        decplaces = StrToInt(DictionaryForm->DGrid->Cells[5][col]);
        fldwide = StrToInt(DictionaryForm->DGrid->Cells[4][col]);
     } // end if not a null variable definition
     else return;

     switch (valtype)  { // save with specified format
        case 0 :  { // floating point
           X = cellstr.ToDouble();
           strcpy(fmt,"%");
           sprintf(astring,"%d",fldwide);
           strcat(fmt,astring);
           strcat(fmt,".");
           sprintf(astring,"%d",decplaces);
           strcat(fmt,astring);
           strcat(fmt,"f");
           sprintf(astring,fmt,X);
           MainForm->Grid->Cells[i][j] = astring;
           ChangeSeparator();
        }  break;
        case 1 : { // integer
           int Y = ceil(cellstr.ToDouble());
           strcpy(fmt,"%");
           sprintf(astring,"%d",fldwide);
           strcat(fmt,astring);
           strcat(fmt,"d");
           sprintf(astring,fmt,Y);
           MainForm->Grid->Cells[i][j] = astring;
//           ChangeSeparator();
        } break;
        case 2 : { // string
           strcpy(fmt,"%");
           sprintf(astring,"%d",fldwide);
           strcat(fmt,astring);
           strcat(fmt,"s");
           sprintf(astring,fmt,cellstr.c_str());
           MainForm->Grid->Cells[i][j] = astring;
        }  break;
        case 3 : { // Date
           sprintf(astring,"%s",MainForm->Grid->Cells[i][j].c_str());
           MainForm->Grid->Cells[i][j] = astring;
        }  break;
        case 4 : { // Money
           double X = StrToFloat(cellstr);
           strcpy(fmt,"$ %");
           sprintf(astring,"%d",fldwide);
           strcat(fmt,astring);
           if (ops.format == 0) strcat(fmt,"."); // American decimal point "."
           else strcat(fmt,","); // European style decimal point ","
           sprintf(astring,"%d",decplaces);
           strcat(fmt,astring);
           strcat(fmt,"f");
           sprintf(astring,fmt,X);
           MainForm->Grid->Cells[i][j] = astring;
        }  break;
     } // end switch
}
//------------------------------------------------------------------------

void OpenOS4(void)
{
     FILE *file1;
     int nrows, ncols;
     AnsiString astring;
     char FileName[121];

     MainForm->OpenDialog1->InitialDir = GetCurrentDir();
     MainForm->OpenDialog1->DefaultExt = "BIN";
     MainForm->OpenDialog1->Filter = "OpenStat4 files (*.bin)|*.BIN|All files (*.*)|*.*";
     MainForm->OpenDialog1->FilterIndex = 1;
     if (MainForm->OpenDialog1->Execute())
     {
   	    strcpy(FileName,MainForm->OpenDialog1->FileName.c_str());
        MainForm->FileNameEdit->Text = FileName;
     }
     else return;
     file1 = fopen(FileName,"rb");
     char cellstr[31];
     char FileLabel[81];

     fread(&nrows,sizeof(nrows),1,file1);
     fread(&ncols,sizeof(ncols),1,file1);
     MainForm->Grid->RowCount = nrows+1;
     MainForm->Grid->ColCount = ncols+1;
     for (int i = 1; i <= ncols; i++) {
         vdef[i] = new struct VarDef;
         fread(vdef[i],sizeof(VarDef),1,file1);
         MainForm->Grid->Cells[i][0] = vdef[i]->ShortLabel;
         NewVar(i,true);
     }
     for (int i = 1; i <= nrows; i++)  {
         astring = "CASE " + IntToStr(i);
         MainForm->Grid->Cells[0][i] = astring;
         for (int j = 1; j <= ncols; j++)  {
             fread(&cellstr,sizeof(cellstr),1,file1);
             MainForm->Grid->Cells[j][i] = cellstr;
        }
    }
    fclose(file1);
    FilterOn = false;
    NoVariables = ncols;
    NoCases = nrows;
    MainForm->NoVarsEdit->Text = IntToStr(ncols);
    MainForm->NoCasesEdit->Text = IntToStr(nrows);
    for (int i = 1; i <= NoVariables; i++) vdef[i] = NULL;
    UpdateOps(MainForm->SaveDialog1->FileName.c_str());
}
//---------------------------------------------------------------------------

void SaveOS4(void)
{
    FILE *file1;
    int nrows, ncols;
    char cellstr[31];
    char FileName[121];

    MainForm->SaveDialog1->InitialDir = GetCurrentDir();
    MainForm->SaveDialog1->DefaultExt = "BIN";
    MainForm->SaveDialog1->Filter = "OpenStat4 files (*.bin)|*.BIN|All files (*.*)|*.*";
    MainForm->SaveDialog1->FilterIndex = 1;
    MainForm->SaveDialog1->FileName = MainForm->FileNameEdit->Text;
    if (MainForm->SaveDialog1->Execute())
    {
       strcpy(FileName,MainForm->SaveDialog1->FileName.c_str());
       MainForm->FileNameEdit->Text = FileName;
    }
    else return;

    // update column widths in the variable definitions
    for (int i = 1; i <= NoVariables; i++)
    {
        vdef[i] = new struct VarDef;
        strcpy(vdef[i]->ShortLabel,MainForm->Grid->Cells[i][0].c_str());
        strcpy(vdef[i]->LongLabel,DictionaryForm->DGrid->Cells[2][i].c_str());
        vdef[i]->VarType = StrToInt(DictionaryForm->DGrid->Cells[3][i].c_str());
        vdef[i]->Width = StrToInt(DictionaryForm->DGrid->Cells[4][i].c_str());
        vdef[i]->Decimals = StrToInt(DictionaryForm->DGrid->Cells[5][i].c_str());
        vdef[i]->ColWide = MainForm->Grid->ColWidths[i];
        vdef[i]->Justify = 0;
        vdef[i]->NoLabels = 0;
    }
    file1 = fopen(FileName,"wb");
    nrows = MainForm->Grid->RowCount-1;
    ncols = MainForm->Grid->ColCount-1;
    fwrite(&nrows,sizeof(nrows),1,file1);
    fwrite(&ncols,sizeof(ncols),1,file1);
    for (int i = 1; i <= ncols; i++)
    {
        strcpy(cellstr,vdef[i]->ShortLabel);  // for testing purposes
        fwrite(vdef[i],sizeof(VarDef),1,file1);
    }
    for (int i = 1; i <= nrows; i++)
    {
        for (int j = 1; j <= ncols; j++)
        {
            strcpy(cellstr,MainForm->Grid->Cells[j][i].c_str());
            fwrite(&cellstr,sizeof(cellstr),1,file1);
        }
    }
    fclose(file1);
    for (int i = 1; i <= NoVariables; i++) vdef[i] = NULL;
    UpdateOps(MainForm->SaveDialog1->FileName.c_str());
}
//---------------------------------------------------------------------------

void OpenEpiDataFile(char FileName[])
{
     FILE *InFile;
     int counter, Nflds, ncase, Nvars = 0;
     int width, totalcolumns, ncards;
     char instring[10001];
     char valuestr[301];
     char achar;
     char label[1000][201];
     int fldwidth[1000];
     int fldstart[1000];
     int fldend[1000];
     int fldtype[1000];
     int varstart[1000];
     int varend[1000];
     char outstring[300];
     int lastend = 0;

     // read header record
     InFile = fopen(FileName,"rb");
     counter = 0;
     do  {
         achar = fgetc(InFile);
         valuestr[counter++] = achar;
     }  while (achar != ' ');
     valuestr[counter] = '\0';
     Nflds = atoi(valuestr);  // may not be the number of variables!
     // get remainder of line
     do  {
         achar = fgetc(InFile);
     }  while ( achar != '\n');

     // read the field definition lines
     totalcolumns = 0;  // total no. of columns of data
     for (int i = 0; i < Nflds; i++)
     {
         fgets(instring,200,InFile); // get header record

         // get label
         counter = 0;
         for (int j = 1; j <= 10; j++)
         {
            valuestr[counter] = instring[j];
            counter++;
         }
         valuestr[counter] = '\0';
         strcpy(label[i],valuestr);

         // type of field
         counter = 0;
         for (int j = 32; j <= 35; j++)
         {
            valuestr[counter] = instring[j];
            counter++;
         }
         valuestr[counter] = '\0';
         fldtype[i] = atoi(valuestr);

         // length of the field
         counter = 0;
         for (int j = 36; j <= 39; j++)
         {
            valuestr[counter] = instring[j];
            counter++;
         }
         valuestr[counter] = '\0';
         fldwidth[i] = atoi(valuestr);
         totalcolumns += fldwidth[i];
         if (fldwidth[i] > 0)
         {
            if (i == 0)
            {
               fldstart[i] = 1;
               lastend = fldstart[i] + fldwidth[i] - 1;
            }
            if (i > 0) fldstart[i] = lastend + 1;
            fldend[i] = fldstart[i] + fldwidth[i] - 1;
            lastend = fldend[i];
         }
         else
         {
             fldstart[i] = 0;
             fldend[i] = 0;
         }
     }

     // build variables - leave out label, soundex and encrypted fields
     FrmOutPut->RichOutPut->Lines->Add("Field Definitions");
     FrmOutPut->RichOutPut->Lines->Add("NO.  LABEL      TYPE LENGTH START  END");
     for (int i = 0; i < Nflds; i++)
     {
         if ((fldwidth[i] > 0) && (fldtype[i] != 17) && (fldtype[i] != 18)) // not a label field
         {
           varstart[Nvars] = fldstart[i];
           varend[Nvars] = fldend[i];
           Nvars++;
           vdef[Nvars] = new VarDef;
           MainForm->Grid->Cells[Nvars][0] = label[i];
           NewVar(Nvars,true);
           vdef[Nvars]->Width = fldwidth[i];
           strcpy(vdef[Nvars]->ShortLabel,label[i]);
           strcpy(vdef[Nvars]->LongLabel,label[i]);
           for (int j = 0; j < 100; j++)
           {
               vdef[Nvars]->ValLabels[j][0] = '\0';
               vdef[Nvars]->LabelValue[j][0] = '\0';
           }
           if (fldtype[i] == 0) vdef[Nvars]->VarType = 1; // integer
           if (fldtype[i] == 1) vdef[Nvars]->VarType = 2; // alphanumeric
           if (fldtype[i] == 2) vdef[Nvars]->VarType = 3; // date
           if (fldtype[i] == 3) vdef[Nvars]->VarType = 2; // upper case alpha
           if (fldtype[i] == 5) vdef[Nvars]->VarType = 2; // boolean Y or N
           if (fldtype[i] == 6) vdef[Nvars]->VarType = 0; // double
           if (fldtype[i] == 10) vdef[Nvars]->VarType = 2; // today day field
           if (fldtype[i] == 11) vdef[Nvars]->VarType = 2; // euro date
           if (fldtype[i] == 12)vdef[Nvars]->VarType = 1; // auto id field
           if (fldtype[i] >= 100) vdef[Nvars]->VarType = 0; // double
           if ((fldtype[i] == 4) || (fldtype[i] == 7) || (fldtype[i] == 8) || (fldtype[i] == 9)
                || (fldtype[i] == 13) || (fldtype[i] == 14) || (fldtype[i] == 15))
                vdef[Nvars]->VarType = 2;
           if ((fldtype[i] > 15) && (fldtype[i] < 21)) vdef[Nvars]->VarType = 2;
           DictionaryForm->DGrid->Cells[3][Nvars] = IntToStr(vdef[Nvars]->VarType);
           DictionaryForm->DGrid->Cells[4][Nvars] = IntToStr(fldwidth[i]);
           if (vdef[Nvars]->VarType != 0) DictionaryForm->DGrid->Cells[5][Nvars] = IntToStr(0);
           DictionaryForm->DGrid->Cells[6][Nvars] = ops.missval;
         }
         sprintf(outstring,"%4d %10s %3d  %4d  %5d %5d",
              i+1,label[i],fldtype[i],fldwidth[i],fldstart[i],fldend[i]);
         FrmOutPut->RichOutPut->Lines->Add(outstring);
     }
     // now read the data from 78 column cards (1 or more) and place in the grid
     MainForm->Grid->ColCount = Nvars + 1;
     int result = totalcolumns / 78;
     ncards = result;
     ncase = 1;
     if (result * 78 < totalcolumns) ncards++; // no. of 78 column records per case

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("RECORDS");
     sprintf(outstring,"No. Variables = %d with Total columns = %d",Nvars,totalcolumns);
     FrmOutPut->RichOutPut->Lines->Add(outstring);

     while (! feof(InFile))
     {
        counter = 0;
        strcpy(instring,"");
        do // read all columns of one record
        {
            achar = fgetc(InFile);
            if (feof(InFile)) goto finish;
            if ((achar != '\n') && (achar != '!') && (achar != '\r') && (achar != '?'))
            {
                instring[counter] = achar;
                counter++;
            }
        } while (counter < totalcolumns);
        instring[counter] = '\0';

        // pull out the variable values
        for (int i = 0; i < Nvars; i++)
        {
            counter = 0;
            for (int j = varstart[i]; j <= varend[i]; j++)
            {
                valuestr[counter] = instring[j-1];
                counter++;
            }
            valuestr[counter] = '\0';
            MainForm->Grid->Cells[i+1][ncase] = valuestr;
        }
        if (feof(InFile)) goto finish;
        ncase++;
        MainForm->Grid->RowCount++;
        MainForm->Grid->Cells[0][ncase] = "CASE " + IntToStr(ncase);
     }
finish:
     FrmOutPut->ShowModal();
     // check for an empty row - delete if there
     int emptycells = 0;
     for (int i = 1; i <= Nvars; i++)
            if (MainForm->Grid->Cells[i][ncase] == "") emptycells++;
     if (emptycells == Nvars)
     {
           MainForm->Grid->Cells[0][ncase] = "";
           ncase--;
           MainForm->Grid->RowCount--;
     }

     MainForm->NoVarsEdit->Text = Nvars;
     MainForm->NoCasesEdit->Text = ncase;
     fclose(InFile);
     MainForm->FileNameEdit->Text = FileName;
     FormatCells();
     UpdateOps(MainForm->SaveDialog1->FileName.c_str());
}
//---------------------------------------------------------------------

void LoadMatrix(void)
{
   // routine to read a matrix stored as a square matrix
   // saved no. of cases, means and standard deviations are ignored
      double value;
      int Nvars, Ncols, NCases;
      char FileName[181];
      FILE *outfile;
      char cellstring[21];
      AnsiString labelstr;
      
      MainForm->OpenDialog1->Filter = "Square matrix files (*.mat)|*.MAT|All files (*.*)|*.*";
      MainForm->OpenDialog1->FilterIndex = 1;
      MainForm->OpenDialog1->DefaultExt = "MAT";
      if (MainForm->OpenDialog1->Execute())
      {
        strcpy(FileName,MainForm->OpenDialog1->FileName.c_str());
        MainForm->FileNameEdit->Text = FileName;
        outfile = fopen(FileName,"rb");
        fread(&Nvars,sizeof(Nvars),1,outfile);
        MainForm->Grid->ColCount = Nvars+1;
        MainForm->Grid->RowCount = Nvars+1;
        for (int i = 1; i <= Nvars; i++)
        {
          NewVar(i,false);
        }
        MainForm->NoVarsEdit->Text = NoVariables;
        MainForm->NoCasesEdit->Text = NoVariables;
        fread(&NCases,sizeof(NCases),1,outfile);
        NoCases = NCases;
        // read grid values
        for (int i = 0; i < Nvars; i++)
        {
            for (int j = 0; j < Nvars; j++)
            {
                fread(&value,sizeof(value),1,outfile);
                MainForm->Grid->Cells[j+1][i+1] = value;
            }
        }
        // read means
        for (int i = 0; i < Nvars; i++) fread(&value,sizeof(value),1,outfile);

        // read standard deviations
        for (int i = 0; i < Nvars; i++) fread(&value,sizeof(value),1,outfile);

        // read row labels
        for (int i = 0; i < Nvars; i++)
        {
            strcpy(cellstring,"");
            fread(&cellstring,sizeof(cellstring),1,outfile);
            DictionaryForm->DGrid->Cells[1][i+1] = cellstring;
            MainForm->Grid->Cells[i+1][0] = cellstring;
        }
        // read column labels
        for (int j = 0; j < Nvars; j++)
        {
            strcpy(cellstring,"");
            fread(&cellstring,sizeof(cellstring),1,outfile);
            MainForm->Grid->Cells[0][j+1] = cellstring;
        }
        fclose(outfile);
      }
      UpdateOps(MainForm->SaveDialog1->FileName.c_str());
}

//---------------------------------------------------------------------

bool LabelOK(AnsiString label)
{
        // check for redundancy in the label for a new variable
        bool OK = true;
        AnsiString cellvalue;

        for (int i = 1; i <= NoVariables; i++)
        {
                cellvalue = MainForm->Grid->Cells[i][0];
                if (cellvalue == label)
                {
                        ShowMessage("Another variable label already exists that is the same.");
                        OK = false;
                        return (OK);
                }
        }
        return (OK);
}

//---------------------------------------------------------------------
bool StringsToInt(int strcol, int newcol, bool prompt)
{ // Procedure to convert group strings into group integers with the option
  // to save the integers in the grid
        AnsiString *StrGrps, *OneString;
        int NoStrings, col;
        AnsiString String1, String2, TempString, response;
        int i, j, k;
        bool dup;
        bool savenewcol = true;

        // Get memory for arrays
        StrGrps = new AnsiString [NoCases];
        OneString = new AnsiString [NoCases];

        // check to see if strcol is a string variable
        TempString = DictionaryForm->DGrid->Cells[3][strcol];
        if (TempString != "2")
        {
                ShowMessage("ERROR! Column selected is not defined as a string variable");
                goto endit;
        }

        // read the strings into the StrGrps array
        for (i = 1; i <= NoCases; i++) StrGrps[i-1] = Trim(MainForm->Grid->Cells[strcol][i]);

        // sort the StrGrps array
        for (i = 0; i < NoCases - 1; i++)
        {
                for (j = i + 1; j < NoCases; j++)
                {
                        if (StrGrps[i] > StrGrps[j]) // swap
                        {
                                TempString = StrGrps[i];
                                StrGrps[i] = StrGrps[j];
                                StrGrps[j] = TempString;
                        }
                }
        }

        // copy unique strings into the OneString array
        TempString = StrGrps[0];
        OneString[0] = TempString;
        NoStrings = 0;
        for (i = 1; i < NoCases; i++)
        {
                if (StrGrps[i] != TempString) // a new string found
                {
                        for (k = 0; k < NoCases; k++) // check for existing
                        {
                                if (TempString == OneString[k]) dup = true;
                                else dup = false;
                        }
                        if (dup == false)
                        {
                                NoStrings++;
                                OneString[NoStrings] = StrGrps[i];
                                TempString = StrGrps[i];
                        }
                }
        }

        // make a new variable in the grid for the group integers
        col = NoVariables + 1;
        DictionaryForm->DGrid->Cells[1][col] = "GroupCode";
        MainForm->Grid->Cells[col][0] = "GroupCode";
        DictionaryForm->DGrid->Cells[2][col] = "Variable" + IntToStr(col);
        DictionaryForm->DGrid->Cells[0][col] = IntToStr(col);
        DictionaryForm->DGrid->Cells[3][col] = "1";
        DictionaryForm->DGrid->Cells[4][col] = "8";
        DictionaryForm->DGrid->Cells[5][col] = "0";
        DictionaryForm->DGrid->Cells[6][col] = ops.missval;
        if (col+1 > DictionaryForm->DGrid->RowCount)
               DictionaryForm->DGrid->RowCount = col + 1;
        NoVariables = DictionaryForm->DGrid->RowCount-1;
        if (NoVariables + 1 > MainForm->Grid->ColCount)
               MainForm->Grid->ColCount = NoVariables + 1;
        MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
        newcol = col;
        
        // oompare case strings with OneString values and use index + 1
        // for the group code in the data grid
        for (i = 1; i <= NoCases; i++)
        {
                TempString = MainForm->Grid->Cells[strcol][i];
                for (j = 0; j < NoCases; j++)
                {
                        if (TempString == OneString[j])
                                MainForm->Grid->Cells[col][i] = IntToStr(j+1);
                }
        }

        // see if user wants to save the generated group codes
        if (prompt == true)
        {
                response = InputBox("Save Code in Grid?","Y or N","N");
                if ((response == "n") || (response == "N")) savenewcol = false;
        }

        // clean up memory
endit:  delete[] OneString;
        delete[] StrGrps;

        // return results
        return (savenewcol);
}
//----------------------------------------------------------------------

int GetValue(int row, int var, int &intvalue, double &dblvalue, AnsiString &strvalue)
{
   int vartype, good;
   AnsiString cellstr;
   int intmiss;
   double dblmiss;
   AnsiString astring;
   char teststr[20];

   if (var > DictionaryForm->DGrid->RowCount-1)
   {
      astring = "No definition found for variable " + IntToStr(var) + ". Define the variable.";
      ShowMessage(astring);
      return(1);
   }

   vartype = StrToInt(DictionaryForm->DGrid->Cells[3][var]);
   switch (vartype)  {
      case 0 : {  // floating point
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            astring = "WARNING! No value in row " + IntToStr(row) + " and col." + IntToStr(var) +
                      ".  Substituting 0.0 for the value.";
            ShowMessage(astring);
            MainForm->Grid->Cells[var][row] = "0.0";
            dblvalue = 0.0;
            good = 0;
            return(good);
         }
         if (isnumber(cellstr.c_str())) good = 0;
         else
         {
             astring = "WARNING! Value at row " + IntToStr(row) + " and col." + IntToStr(var) +
                       "is not a floating point value.";
             ShowMessage(astring);
             good = 1;
             return (good);
         }
         dblvalue = StrToFloat(cellstr);
         dblmiss = StrToFloat(DictionaryForm->DGrid->Cells[6][var]);    //atof(ops.missval);
         if (dblvalue == dblmiss) good = 0;
      } break;
      case 1 : { // integer
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            astring = "WARNING! No value in row " + IntToStr(row) + " and col." + IntToStr(col) +
                      ".  Substituting 0 for the value.";
            ShowMessage(astring);
            intvalue = 0;
            MainForm->Grid->Cells[var][row] = IntToStr(intvalue);
            good = 0;
            return(good);
         }
         if (isnumber(cellstr.c_str())) good = 0;
         else
         {
             astring = "WARNING! Value at row " + IntToStr(row) + " and col." + IntToStr(var) +
                       "is not an integer value.";
             ShowMessage(astring);
             good = 1;
             return(good);
         }
         strcpy(teststr,cellstr.c_str());
         for (int i = 0; i < strlen(teststr); i++)
         {
                if ((teststr[i] == '.') || (teststr[i] == ','))
                {
                   astring = "WARNING!  Value at row " + IntToStr(row) + " and col." + IntToStr(var) +
                      " is not an integer value.";
                   ShowMessage(astring);
                   good = 1;
                   return(good);
                }
         }
         intvalue = StrToInt(cellstr);
         intmiss = StrToInt(DictionaryForm->DGrid->Cells[6][var]);      //atoi(ops.missval);
         if (intvalue == intmiss) good = 0;
      } break;
      case 2 :
      { // string
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            astring = "WARNING! No value in row " + IntToStr(row) + " and col." + IntToStr(col) +
                      ".  Substituting the missing value for the value.";
            ShowMessage(astring);
            MainForm->Grid->Cells[var][row] = ops.missval;
            good = 0;
            break;
         }
         if (strcmp(cellstr.c_str(),ops.missval) == 0) good = 0;
         else good = 1;
      } break;
      case 3 :  { // date - convert to integer
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            astring = "WARNING! No value in row " + IntToStr(row) + " and col." + IntToStr(col) +
                      ".  Substituting 0 for the value.";
            ShowMessage(astring);
            strvalue = 0;
            good = 0;
            break;
         }
         int chrpos, from, to;
         long date;
         AnsiString yrs, mos, days;
         int yr, mo, day;
         chrpos = cellstr.Pos("/");
         yrs = cellstr.SubString(1,chrpos-1);
         yr = StrToInt(yrs);
         from = chrpos+1;
         to = cellstr.Length();
         cellstr = cellstr.SubString(from,to);
         chrpos = cellstr.Pos("/");
         mos = cellstr.SubString(1,chrpos-1);
         mo = StrToInt(mos);
         from = chrpos+1;
         to = cellstr.Length();
         cellstr = cellstr.SubString(from,to);
         day = StrToInt(cellstr);
         date = ymd_to_date(yr, mo, day);
         MainForm->Grid->Cells[var][row] = IntToStr(date);
      } break;
      case 4 : {  // money - remove dollar sign
         cellstr = Trim(MainForm->Grid->Cells[var][row]);
         if (cellstr == "")
         {
            astring = "WARNING! No value in row " + IntToStr(row) + " and col." + IntToStr(col) +
                      ".  Substituting $0.00 for the value.";
            ShowMessage(astring);
            strvalue = "$0.00";
            MainForm->Grid->Cells[var][row] = strvalue;
            good = 0;
            break;
         }
         // delete $ from string and return a floating value
         int to = cellstr.Length();
         cellstr = cellstr.SubString(2,to);
         MainForm->Grid->Cells[var][row] = cellstr;
         good = 0;
      } break;
   }
   return (good);
}
//---------------------------------------------------------------------------

int VarTypeChk(int var, int wanted)
{
        int found, result;
        AnsiString remark;

        found = StrToInt(DictionaryForm->DGrid->Cells[3][var]);
        if (wanted != found)
        {
                result = 1;
                //remark = "Re-define the variable type in column " + IntToStr(var) + " to type " + IntToStr(wanted);
                remark = "WARNING!  For column " + IntToStr(var) + " type expected = " + IntToStr(wanted) +
                   " but found " + IntToStr(found) + ". Redefine the variable and reformat grid!";
                ShowMessage(remark);
                return (result);
        }
        else result = 0;
        return (result);
}
//--------------------------------------------------------------------------


