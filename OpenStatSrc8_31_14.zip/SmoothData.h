//---------------------------------------------------------------------------

#ifndef SmoothDataH
#define SmoothDataH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSmoothForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TListBox *VarList;
        TLabel *Label1;
        TBitBtn *InBtn;
        TBitBtn *OutBtn;
        TEdit *VariableEdit;
        TLabel *Label2;
        TEdit *RepeatEdit;
        TLabel *Label3;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall InBtnClick(TObject *Sender);
        void __fastcall OutBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        int VarCol;
        int OutCol;
public:		// User declarations
        __fastcall TSmoothForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSmoothForm *SmoothForm;
//---------------------------------------------------------------------------
#endif
