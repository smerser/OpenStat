//---------------------------------------------------------------------------
#ifndef FileSelUnitH
#define FileSelUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <FileCtrl.hpp>
//---------------------------------------------------------------------------
class TFileSelFrm : public TForm
{
__published:	// IDE-managed Components
    TDriveComboBox *DriveBox;
    TFileListBox *FileListBox;
    TDirectoryListBox *DirBox;
    TFilterComboBox *FilterBox;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *FileNameEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall FilterBoxChange(TObject *Sender);
    void __fastcall DriveBoxChange(TObject *Sender);
    void __fastcall FileListBoxClick(TObject *Sender);
    void __fastcall DirBoxChange(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFileSelFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFileSelFrm *FileSelFrm;
//---------------------------------------------------------------------------
#endif
