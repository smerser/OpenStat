//---------------------------------------------------------------------------

#ifndef MWUFormUnitH
#define MWUFormUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TMWUForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TListBox *ListBox1;
        TEdit *GroupEdit;
        TLabel *Label3;
        TEdit *DependEdit;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall CancelBtnClick(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall ListBox1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMWUForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMWUForm *MWUForm;
//---------------------------------------------------------------------------
#endif
