//---------------------------------------------------------------------------

#ifndef MatrixUnitH
#define MatrixUnitH
//---------------------------------------------------------------------------
#endif

void ArrayPrint(double **Matrix, int Nrows, int Ncols, char *ColHeader,\
     AnsiString *RowLabels, AnsiString *ColLabels, char *Title);
void IntArrayPrint(int **Matrix, int Nrows, int Ncols, char *ColHeader,\
     AnsiString *RowLabels, AnsiString *ColLabels, char *Title);
void VPrint(double *vector, int Ncols, AnsiString*Labels, char *Title);
void IntVPrint(int *vector, int Ncols, AnsiString*Labels, char *Title);
void matsub(double **ResultMat, double **FirstMat, double **SecdMat, int rows, int cols);
void OPRINC(double *S, int M, int IA, double *EVAL, double **EVEC,
            double **COMP, double *VAR, double *CL, double *CU, int IER);
void EHOUSS(double *A, int N, double *D, double *E, double *E2);
double DSIGN(double X, double Y);
void EQRT2S(double *D, double *E, int N, double **Z, int IZ, int IER);
void EHOBKS(double *A, int N, int M1, int M2, double **Z, int IZ);
void UERTST(int IER, char *NAME);
void tred2(double **a, int n, double *d, double *e);
void tqli(double *d, double *e, int n, double **z);
void xtqli(double **a, int NP, double *d, double *f, double *e);
double pythag(double a, double b);
double SQR(double a);
int Correlations(double *means, double *stddevs, double **corr, int NoSelected,
    int *ColNoSelected, int & NSUBS, int mattype, bool Augment, int prtopts);
void eigsrt(double d[], double **v, int n);
void vectorprint(double *vector, int *selected, int Ncols, char *Title);
void MatPrint(double **Matrix, int Nrows, int Ncols, int *selected, char *Title);
double Determ(double **a, int rows);
void ludcmp(double **a, int n, int *indx, double &d);
void mreg(int NoIndep, int *IndepCols, int DepCol, AnsiString *RowLabels,
               double *Means, double *Variances,double *StdDevs,
               double *BWeights, double *BetaWeights, double *BStdErrs,
               double *Bttests,double *tProbs, double &R2, double &F, double &stderrest,
               int &NCases, bool &errorcode, bool PrintDesc, bool PrintCorrs,
               bool PrintInverse, bool PrintCoefs, bool SaveCorrs);
void MATAxB(double ** a, double **b, double **c, int brows, int bcols, int crows,
            int ccols, bool &errorcode);
bool MATTRN(double ** a, double **b, int brows, int bcols);
int matinv(double **a, int N, double **ainverse, double **v, double *W);
int SVDinverse(double ** a, int N);
void nonsymroots(double **a, int nv, int &nf, double c,double **v,double *e, double *x,\
                      double &t, double &ev);
double Partial(double **Rmat, int Candidate, int Size, int N,
               double &Prob, double &F, double &df1, double &df2);
void SaveSqrMat(double **Matrix, int Nvars, int NCases, AnsiString *RowLabels,
                double *Means, double *StdDevs);
void OpenSqrMat(char *FileName, double **Matrix, int Nvars, int NCases, AnsiString *RowLabels,
					 double *Means, double *StdDevs);
void Predict(int *ColNoSelected, int *IndepIndex, int NoVars, double **IndepInverse,
             double *Means, double *StdDevs,double *BetaWeights, double *BWeights,
             double constant, double StdErrEst, int NoIndepVars);
void MReg2(int NCases, int NoVars, int &NoIndepVars, int *IndepIndex,
           double **corrs, double **IndepCorrs, AnsiString *RowLabels,
           double &R2, double *BetaWeights, double *Means, double *Variances,
           int &errorcode, double &StdErrEst, double &constant,
           double probout, bool Printit, bool TestOut, bool PrintInv);
void MatOffset(double **MatA, double **MatB, int matsize);
void MatOnset(double **MatA, double **MatB, int matsize);
int SEVS(int nv, int nf, double C,double **r, double **v, double *e, double *p, int nd);
void SymMatRoots(double **A, int M, double *E, double **V);
void Roots(double **RMat, int NITEMS, double *EIGENVAL, double **EIGENVEC);
void OpenMatrixFile(char FileName[]);
void SaveMatrixFile(char FileName[]);
void svd(double **A, int M, int N, double **U, double **S, double **V);
void InvertMat(double ** matrix, int n);
void CoFactor(double **a,int n,double **b);             

