//---------------------------------------------------------------------------

#ifndef CorrespondenceUnitH
#define CorrespondenceUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TCorrespondenceForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *RowIn;
        TBitBtn *RowOut;
        TBitBtn *ColIn;
        TBitBtn *ColOut;
        TLabel *Label2;
        TEdit *RowEdit;
        TLabel *Label3;
        TGroupBox *GroupBox1;
        TCheckBox *ObsChk;
        TCheckBox *ExpChk;
        TCheckBox *ChiChk;
        TCheckBox *YatesChk;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TListBox *ColList;
        TMemo *Memo1;
        TCheckBox *EigenChk;
        TCheckBox *RowCorres;
        TCheckBox *ColCorrChk;
        TCheckBox *BothCorrChk;
        TCheckBox *PlotChk;
        TCheckBox *PropsChk;
        TCheckBox *ShowQChk;
        TCheckBox *QCheckChk;
        TCheckBox *ShowABChk;
        TCheckBox *CheckPChk;
        void __fastcall RowInClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall RowOutClick(TObject *Sender);
        void __fastcall ColInClick(TObject *Sender);
        void __fastcall ColOutClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        void __fastcall TCorrespondenceForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N,AnsiString *PtLabels,
                                      AnsiString titlestr,
                                      AnsiString Xlabel,
                                      AnsiString Ylabel);
public:		// User declarations
        __fastcall TCorrespondenceForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCorrespondenceForm *CorrespondenceForm;
//---------------------------------------------------------------------------
#endif
