//---------------------------------------------------------------------------

#ifndef ExpSmoothUnitH
#define ExpSmoothUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TExpSmoothFrm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *AlphaEdit;
    TScrollBar *AlphaScroll;
    TLabel *Label2;
    TLabel *Label3;
    TButton *CancelBtn;
    TButton *OKBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall AlphaScrollChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TExpSmoothFrm(TComponent* Owner);
    double alpha;
};
//---------------------------------------------------------------------------
extern PACKAGE TExpSmoothFrm *ExpSmoothFrm;
//---------------------------------------------------------------------------
#endif
