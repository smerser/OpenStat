//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "RunsTestUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "math.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRunsTestForm *RunsTestForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
//---------------------------------------------------------------------------
__fastcall TRunsTestForm::TRunsTestForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRunsTestForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     TestVarEdit->Text = "";
     MeanEdit->Text = "";
     StdDevEdit->Text = "";
     NUpEdit->Text = "";
     NDownEdit->Text = "";
     StatEdit->Text = "";
     ProbEdit->Text = "";
     ConclusionEdit->Text = "";
     NRunsEdit->Text = "";
     OutBtn->Visible = false;
     InBtn->Visible = true;
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TRunsTestForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TRunsTestForm::ComputeBtnClick(TObject *Sender)
{
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;
     
     col = 0;
     N = 0;
     N1 = 0;
     N2 = 0;
     Nless = 0;
     Nmore = 0;
     R = 1;
     Mean = 0.0;
     for (i = 0; i < NoVariables; i++)
		if (MainForm->Grid->Cells[i+1][0] == TestVarEdit->Text) col = i+1;
     if (col == 0)
     {
        ShowMessage("Could not locate variable to analyze.");
        return;
     }
     //result = VarTypeChk(col,0);
     //if (result == 1) return;

	values = new double[NoCases]; // set up the data array
	for (i = 0; i < NoCases; i++)
	{
		if (! ValidValue(i+1,col)) continue;
		values[i] = StrToFloat(MainForm->Grid->Cells[col][i+1]);
                //result = GetValue(i+1,col,intvalue,dblvalue,strvalue);
                //if (result == 1) values[i] = 0.0;
                //else values[i] = dblvalue;
		N++;
	}

	//calculate mean
	// Run through all the input, add those that have valid values
	 for(i = 0; i < N; i++)  Mean += values[i];
	 //check for insufficient data
	if(N<=10)
	{
		ShowMessage("Insufficient data. You must have at least 11 values.");
		return;
	}
	else
	{   // Do the math
		Mean = Mean /  float(N);
		// run through each value and compare it with mean
    		for(i = 0; i < N; i++)
		{     //check and discard the ties with the mean
                if(Mean != values[i])
			 {   // check if it is greater than mean then adds one
			 	if (values[i]  >  Mean)
				{
					N1++;
				    	a = i;
				   	while (a > 0)
					{
						a--;
					 	if( values[a] !=  Mean)  break;
			    		}
				    	if (values[a] < Mean)
                         {
                            R++;
                            Nless++;
                         }
				}
                    // check to see if it is less than mean
                    else if (values[i] < Mean)
				{
                         N2++;
					a = i;
					while (a > 0)
					{
                        		a--;
		 				if(values[a] != Mean)  break;
                         }
				    	if (values[a] > Mean)
                         {
                            R++;
                            Nmore++;
                         }
                    }   //closing else-if statement
			}  // end of if values[i] not equal the mean
          }  // end of i loop
	}     // end of else do math

	//compute the expected mean and variance of R
     ExpMean = 1.0 +((float) (2*N1*N2) / float(N1+N2)); //Mean "Mu"
     SD1 = 2*N1*N2*(2*N1*N2-N1-N2);
     SD2 = pow( (N1 + N2), 2);
     SD3 = N1 + N2 - 1;
     SD4 = SD1 / (SD2 * SD3); //Standard deviation "Sigma"
     SD = sqrt(SD4);
	//calculating P value
     z1 = ((float)R - ExpMean) / SD;
	z2 = fabs(z1);
	z = z2;
     t = (z > 0) ? z : (-z);
     p1 = pow((1+t*(0.049867347 + t*(0.0211410061  + t*(0.0032776263 + t*(0.0000380036 +
     t*(0.0000488906  + t*(0.000005383))))))), -16);
     p = 1.0 - p1 / 2.0;
     t = 1.0 - ((z > 0.0) ? p : 1.0 - p);         //this is P-value

	// Show results
     sprintf(outstr,"%8.3f",Mean);
     MeanEdit->Text = outstr;
     sprintf(outstr,"%8.3f",SD);
     StdDevEdit->Text = outstr;
     NUpEdit->Text = IntToStr(N1);
     NDownEdit->Text = IntToStr(N2);
     NRunsEdit->Text = IntToStr(R);
     sprintf(outstr,"%8.3f",z);
     StatEdit->Text = outstr;
	if (t < 0.0001) astring = "Almost Zero";
	else
     {
         sprintf(outstr,"%6.4f",t);
         ProbEdit->Text = outstr;
     }
	//determine the conclusion
        	if (t < 0.01)
	{
                	astring =  "Very strong evidence against randomness (trend or seasonality)";
		ConclusionEdit->Text = astring;
        	}
        	else if ((t < 0.05) && (t >= 0.01)  )
	{
                	astring = "Moderate evidence against randomness";
		ConclusionEdit->Text = astring;
        	}
        	else if ((t < 0.10) && (t >= 0.05) )
	{
                	astring = "Suggestive evidence against randomness";
		ConclusionEdit->Text = astring;
        	}
        	else if (t >= 0.10)
	{
                	astring = "Little or no real evidences against randomness";
		ConclusionEdit->Text = astring;
        	}
	else 
	{
		astring = "Strong evidence against randomness (trend or seasonality exists)";
		ConclusionEdit->Text = astring;
	}
     delete[] values;
	return;
}
//---------------------------------------------------------------------------

void __fastcall TRunsTestForm::InBtnClick(TObject *Sender)
{
   int i;

   i = VarList->ItemIndex;
   if (i < 0) return;
   TestVarEdit->Text = VarList->Items->Strings[i];
   VarList->Items->Delete(i);
   InBtn->Visible = false;
   OutBtn->Visible = true;     
}
//---------------------------------------------------------------------------

void __fastcall TRunsTestForm::OutBtnClick(TObject *Sender)
{
     if (TestVarEdit->Text == "") return;
     VarList->Items->Add(TestVarEdit->Text);
     TestVarEdit->Text = "";
     OutBtn->Visible = false;
     InBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TRunsTestForm::PrintBtnClick(TObject *Sender)
{

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("RANDOMNESS RUNS TESTS FOR "+ TestVarEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Mean = " + MeanEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Standard Deviation = " + StdDevEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Number Values > Mean = " + NUpEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Number Values < Mean = " + NDownEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
//     FrmOutPut->RichOutPut->Lines->Add("Number of Runs > Mean = " + IntToStr(Nmore));
//     FrmOutPut->RichOutPut->Lines->Add("");
//     FrmOutPut->RichOutPut->Lines->Add("Number of Runs < Mean = " + IntToStr(Nless));
//     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Number of Runs = " + NRunsEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Test Statistic = " + StatEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Probability = " + ProbEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Conclusion: " + ConclusionEdit->Text);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

