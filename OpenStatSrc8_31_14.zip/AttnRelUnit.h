//---------------------------------------------------------------------------

#ifndef AttnRelUnitH
#define AttnRelUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmCorrectedR : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TEdit *FirstrEdit;
    TLabel *Label3;
    TEdit *FirstVarEdit;
    TLabel *Label4;
    TEdit *SecdVarEdit;
    TButton *ComputeBtn;
    TLabel *Label5;
    TEdit *EstREdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ReturnBtn;
    TLabel *Label6;
    void __fastcall FirstrEditKeyPress(TObject *Sender, char &Key);
    void __fastcall FirstVarEditKeyPress(TObject *Sender, char &Key);
    void __fastcall SecdVarEditKeyPress(TObject *Sender, char &Key);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmCorrectedR(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmCorrectedR *FrmCorrectedR;
//---------------------------------------------------------------------------
#endif
