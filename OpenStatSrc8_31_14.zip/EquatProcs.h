void SubParms(char oldstring[], int NParms, char Parms[], double Parmvalues[]);
void SubVars(char oldstring[], int NVars, char Vars[8][3], double Xvalues[]);
void BlanksOut(char OpsString[]);
double eval(char OpsString[], int NParms, int NVars,
                     double ParmValues[], double Xvalues[]);
void GetParens(char OpsString[],int &leftparen, int &rightparen);
int GetFunction(char OpsString[],int leftparen, int &length);
void PutValues(char OpsString[], int NVars, int NParms, double ParmValues[],
               double Xvalues[]);
void CopyFuncValue(char OpsString[], int leftparen, int rightparen,int funcno,
                   double value, int length);
bool FindDivTimes(char OpsString[], int &position, char &Operation);
bool FindPlusMinus(char OpsString[], int &position, char &Operation);
void DoOperation(char OpsString[], int position, char Operation);
void StringSub(char OpsString[], char tempstr[],int frompos, int topos);
double asinh(double x);
double acosh(double x);
double atanh(double x);
double acoth(double x);
void MultDiv(char OpsString[], int &position, char &Operation);
void PlusMinus(char OpsString[], int &position, char &Operation);

