//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PaymentUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPaymentFrm *PaymentFrm;
//---------------------------------------------------------------------------
__fastcall TPaymentFrm::TPaymentFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPaymentFrm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    PaymentEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0";         
}
//---------------------------------------------------------------------------
void __fastcall TPaymentFrm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);       
}
//---------------------------------------------------------------------------
void __fastcall TPaymentFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Pay, PresentValue, FutureVal;
     int NPeriods, When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentEdit->Text);
     NPeriods = StrToInt(NPeriodsEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     FutureVal = StrToFloat(FutureEdit->Text);
     Pay = Payment(Rate, NPeriods, PresentValue, FutureVal, Time);
     PaymentEdit->Text = FloatToStr(Pay);
}
//---------------------------------------------------------------------------
