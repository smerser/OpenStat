//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "stdlib.h"
#include "stdio.h"
#include "math.h"
#include "functions.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "MatrixUnit.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "LifeTableUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLifeTableForm *LifeTableForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TLifeTableForm::TLifeTableForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::FormShow(TObject *Sender)
{
        ObsStartEdit->Clear();
        NoAliveEdit->Clear();
        NoDiedEdit->Clear();
        CensoredEdit->Clear();
        LstVariables->Clear();
        ObsInBtn->Visible = true;
        ObsOutBtn->Visible = false;
        EndInBtn->Visible = true;
        EndOutBtn->Visible = false;
        NoAliveInBtn->Visible = true;
        NoAliveOutBtn->Visible = false;
        NoDiedInBtn->Visible = true;
        NoDiedOutBtn->Visible = false;
        CensoredInBtn->Visible = true;
        CensoredOutBtn->Visible = false;
        LifeTableGrid->Cells[1][0] = "Obs.Start";
        LifeTableGrid->Cells[2][0] = "Obs.End";
        LifeTableGrid->Cells[3][0] = "Alive";
        LifeTableGrid->Cells[4][0] = "Died";
        LifeTableGrid->Cells[5][0] = "Censored";
        LifeTableGrid->Cells[6][0] = "At Risk";
        LifeTableGrid->Cells[7][0] = "Prob.Die";
        LifeTableGrid->Cells[8][0] = "Prob.Alive";
        LifeTableGrid->Cells[9][0] = "Cum.P.Alive";
        LifeTableGrid->Cells[10][0] = "S.E. Alive";
        LifeTableGrid->Cells[11][0] = "Low 95%";
        LifeTableGrid->Cells[12][0] = "Hi 95%";
        LifeTableGrid->ColCount = 13;
        LifeTableGrid->RowCount = NoCases+1;
        for (int i = 0; i <= 12; i++)
        {
                for (int j = 1; j <= NoCases; j++) LifeTableGrid->Cells[i][j] = "";
        }
        for (int i = 1; i <= NoVariables; i++)
                LstVariables->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::ResetBtnClick(TObject *Sender)
{
        ObsStartEdit->Text = "";
        ObsEndEdit->Text = "";
        NoAliveEdit->Text = "";
        NoDiedEdit->Text = "";
        CensoredEdit->Text = "";
        ObsInBtn->Visible = true;
        ObsOutBtn->Visible = false;
        EndInBtn->Visible = true;
        EndOutBtn->Visible = false;
        NoAliveInBtn->Visible = true;
        NoAliveOutBtn->Visible = false;
        NoDiedInBtn->Visible = true;
        NoDiedOutBtn->Visible = false;
        CensoredInBtn->Visible = true;
        CensoredOutBtn->Visible = false;
        LstVariables->Clear();
        for (int i = 1; i <= 12; i++)
        {
                for (int j = 1; j <= NoCases; j++) LifeTableGrid->Cells[i][j] = "";
        }
        for (int i = 1; i <= NoVariables; i++)
                LstVariables->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::ComputeBtnClick(TObject *Sender)
{
        int value, i, j;
        int *varcols;
        double AtRisk, ProbDie, ProbLive, CumProbLive, StdErr, Up95, Low95;
        double N, P, Q, mu, CI, z;
        char outline[20];

        CI = StrToFloat(ConfidenceEdit->Text);
        z = inversez(CI);
        varcols = new int(5);
        for (i = 1; i <= 5; i++)
        {
                if (MainForm->Grid->Cells[i][0] == ObsStartEdit->Text) varcols[0] = i;
                if (MainForm->Grid->Cells[i][0] == ObsEndEdit->Text) varcols[1] = i;
                if (MainForm->Grid->Cells[i][0] == NoAliveEdit->Text) varcols[2] = i;
                if (MainForm->Grid->Cells[i][0] == NoDiedEdit->Text) varcols[3] = i;
                if (MainForm->Grid->Cells[i][0] == CensoredEdit->Text) varcols[4] = i;
        }
        for (i = 1; i <= NoCases; i++)
        {
                LifeTableGrid->Cells[0][i] = "CASE " + IntToStr(i);
                LifeTableGrid->Cells[1][i] = Trim(MainForm->Grid->Cells[varcols[0]][i]);
                LifeTableGrid->Cells[2][i] = Trim(MainForm->Grid->Cells[varcols[1]][i]);
                LifeTableGrid->Cells[3][i] = Trim(MainForm->Grid->Cells[varcols[2]][i]);
                LifeTableGrid->Cells[4][i] = Trim(MainForm->Grid->Cells[varcols[3]][i]);
                LifeTableGrid->Cells[5][i] = Trim(MainForm->Grid->Cells[varcols[4]][i]);
        }
        for (i = 1; i <=NoCases; i++)
        {
                AtRisk = StrToFloat(LifeTableGrid->Cells[3][i]);
                AtRisk = AtRisk - (StrToFloat(LifeTableGrid->Cells[5][i]) / 2.0);
                sprintf(outline,"%8.4f",AtRisk);
                LifeTableGrid->Cells[6][i] = outline;
                ProbDie = StrToFloat(LifeTableGrid->Cells[4][i]) / AtRisk;
                sprintf(outline,"%8.4f",ProbDie);
                LifeTableGrid->Cells[7][i] = outline;
                sprintf(outline,"%8.4f",1.0-ProbDie);
                LifeTableGrid->Cells[8][i] = outline;
        }
        N = StrToFloat(LifeTableGrid->Cells[3][1]);
        LifeTableGrid->Cells[9][1] = LifeTableGrid->Cells[8][1];
        P = StrToFloat(LifeTableGrid->Cells[9][1]);
        Q = 1.0 - P;
        StdErr = sqrt(N * P * Q);
        sprintf(outline,"%8.4f",StdErr);
        LifeTableGrid->Cells[10][1] = outline;
        mu = N * P;
        sprintf(outline,"%8.4f",StdErr);
        LifeTableGrid->Cells[10][1] = outline;
        Up95 = mu + (z * StdErr);
        Low95 = mu - (z * StdErr);
        sprintf(outline,"%8.4f",Low95);
        LifeTableGrid->Cells[11][1] = outline;
        sprintf(outline,"%8.3f",Up95);
        LifeTableGrid->Cells[12][1] = outline;

        for (i = 2; i <= NoCases; i++)
        {
                CumProbLive = StrToFloat(LifeTableGrid->Cells[9][i-1]) *
                   StrToFloat(LifeTableGrid->Cells[8][i]);
                sprintf(outline,"%8.4f",CumProbLive);
                LifeTableGrid->Cells[9][i] = outline;
                P = CumProbLive;
                Q = 1.0 - P;
                StdErr = sqrt(N * P * Q);
                mu = N * P;
                sprintf(outline,"%8.4f",StdErr);
                LifeTableGrid->Cells[10][i] = outline;
                Up95 = mu + (z * StdErr);
                Low95 = mu - (z * StdErr);
                sprintf(outline,"%8.4f",Low95);
                LifeTableGrid->Cells[11][i] = outline;
                sprintf(outline,"%8.3f",Up95);
                LifeTableGrid->Cells[12][i] = outline;
        }
        delete[] varcols;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::ObsInBtnClick(TObject *Sender)
{
     int i, index;

     index = LstVariables->Items->Count;
     i = 0;
     while (i < index)
     {
           if (LstVariables->Selected[i]) {
              ObsStartEdit->Text = LstVariables->Items->Strings[i];
              LstVariables->Items->Delete(i);
              index--;
           }
           else i++;
     }
     ObsOutBtn->Visible = true;
     ObsInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::ObsOutBtnClick(TObject *Sender)
{
     LstVariables->Items->Add(ObsStartEdit->Text);
     ObsStartEdit->Text = "";
     ObsInBtn->Visible = true;
     ObsOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::NoAliveInBtnClick(TObject *Sender)
{
     int i, index;

     index = LstVariables->Items->Count;
     i = 0;
     while (i < index)
     {
           if (LstVariables->Selected[i]) {
              NoAliveEdit->Text = LstVariables->Items->Strings[i];
              LstVariables->Items->Delete(i);
              index--;
           }
           else i++;
     }
     NoAliveOutBtn->Visible = true;
     NoAliveInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::NoAliveOutBtnClick(TObject *Sender)
{
     LstVariables->Items->Add(NoAliveEdit->Text);
     NoAliveEdit->Text = "";
     NoAliveInBtn->Visible = true;
     NoAliveOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::NoDiedInBtnClick(TObject *Sender)
{
     int i, index;

     index = LstVariables->Items->Count;
     i = 0;
     while (i < index)
     {
           if (LstVariables->Selected[i]) {
              NoDiedEdit->Text = LstVariables->Items->Strings[i];
              LstVariables->Items->Delete(i);
              index--;
           }
           else i++;
     }
     NoDiedOutBtn->Visible = true;
     NoDiedInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::NoDiedOutBtnClick(TObject *Sender)
{
     LstVariables->Items->Add(NoDiedEdit->Text);
     NoDiedEdit->Text = "";
     NoDiedInBtn->Visible = true;
     NoDiedOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::CensoredInBtnClick(TObject *Sender)
{
     int i, index;

     index = LstVariables->Items->Count;
     i = 0;
     while (i < index)
     {
           if (LstVariables->Selected[i]) {
              CensoredEdit->Text = LstVariables->Items->Strings[i];
              LstVariables->Items->Delete(i);
              index--;
           }
           else i++;
     }
     CensoredOutBtn->Visible = true;
     CensoredInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLifeTableForm::CensoredOutBtnClick(TObject *Sender)
{
     LstVariables->Items->Add(CensoredEdit->Text);
     CensoredEdit->Text = "";
     CensoredInBtn->Visible = true;
     CensoredOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TLifeTableForm::EndInBtnClick(TObject *Sender)
{
     int i, index;

     index = LstVariables->Items->Count;
     i = 0;
     while (i < index)
     {
           if (LstVariables->Selected[i]) {
              ObsEndEdit->Text = LstVariables->Items->Strings[i];
              LstVariables->Items->Delete(i);
              index--;
           }
           else i++;
     }
     EndOutBtn->Visible = true;
     EndInBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TLifeTableForm::EndOutBtnClick(TObject *Sender)
{
     LstVariables->Items->Add(ObsEndEdit->Text);
     ObsEndEdit->Text = "";
     EndInBtn->Visible = true;
     EndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------


