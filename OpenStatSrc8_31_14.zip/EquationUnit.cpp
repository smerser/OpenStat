//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "EquationUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEquationForm *EquationForm;
//---------------------------------------------------------------------------
__fastcall TEquationForm::TEquationForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::ResetBtnClick(TObject *Sender)
{
     NewVarEdit->Text = "";
     OpEdit->Text = "";
     FuncEdit->Text = "";
     VarEdit->Text = "";
     OpsCombo->Text = "Operations";
     FunctionCombo->Text = "Functions";
     VarCombo->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarCombo->Items->Add(MainForm->Grid->Cells[i][0]);
     VarCombo->Text = "Variables";
     operations = new AnsiString[NoVariables];
     functions = new AnsiString[NoVariables];
     variables = new AnsiString[NoVariables];
     NoEntries = 0;
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::NextBtnClick(TObject *Sender)
{
     operations[NoEntries] = OpEdit->Text;
     if ((NoEntries > 0) && (operations[NoEntries] == "") )
     {
        ShowMessage("ERROR-No operation selected - enter again!");
        return;
     }
     functions[NoEntries] = FuncEdit->Text;
     variables[NoEntries] = VarEdit->Text;
     if (variables[NoEntries] == "")
     {
        ShowMessage("ERROR-No variable entered - enter again!");
        return;
     }
     NoEntries++;
     OpEdit->Text = "";
     FuncEdit->Text = "";
     VarEdit->Text = "";
     OpsCombo->Text = "Operations";
     FunctionCombo->Text = "Functions";
     VarCombo->Text = "Variables";
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::FinishedBtnClick(TObject *Sender)
{
     operations[NoEntries] = OpEdit->Text;
     if ((NoEntries > 0) && (operations[NoEntries] == "") )
     {
        ShowMessage("ERROR-No operation selected - enter again!");
        return;
     }
     functions[NoEntries] = FuncEdit->Text;
     variables[NoEntries] = VarEdit->Text;
     if (variables[NoEntries] == "")
     {
        ShowMessage("ERROR-No variable entered - enter again!");
        return;
     }
     NoEntries++;
     OpsCombo->Text = "Operations";
     FunctionCombo->Text = "Functions";
     VarCombo->Text = "Variables";
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::ComputeBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     double newvalue, xvalue;
     int opsitem, funcsitem, col, newcol;
     char outline[121];

     // get position of selected variables from the main grid
     selected = new int[NoEntries];
     for (int i = 1; i <= NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i][0];
         for (int j = 0; j < NoEntries; j++)
             if (cellstring == variables[j]) selected[j] = i;
     }

     // create a new variable in the main grid
     col = NoVariables + 1;
     newcol = col;
     MainForm->Grid->Cells[col][0] = NewVarEdit->Text;
     NewVar(col,true);

     // for each subject obtain selected variable values and add to newvalue
     for (int i = 1; i <= NoCases; i++) // subject loop
     {
         newvalue = 0.0;
         for (int j = 0; j < NoEntries; j++) // list loop
         {
             col = selected[j];
             xvalue = StrToFloat(MainForm->Grid->Cells[col][i]);
             if (functions[j] != "") // do the function
             {
                 for (int k = 0; k < 12; k++) // get function number
                 {
                     if (functions[j] == FunctionCombo->Items->Strings[k]) funcsitem = k;
                 }
                 switch (funcsitem)
                 {
                     case 0: xvalue *= xvalue; break;
                     case 1: xvalue = sqrt(xvalue); break;
                     case 2: xvalue = sin(xvalue); break;
                     case 3: xvalue = cos(xvalue); break;
                     case 4: xvalue = tan(xvalue); break;
                     case 5: xvalue = asin(xvalue); break;
                     case 6: xvalue = acos(xvalue); break;
                     case 7: xvalue = atan(xvalue); break;
                     case 8: xvalue = log10(xvalue); break;
                     case 9: xvalue = log(xvalue); break;
                     case 10: xvalue = exp(xvalue); break;
                     case 11: xvalue = 1.0 / xvalue; break;
                 }
             } // end if function
             if (operations[j] == "") newvalue += xvalue;
             else // find operation
             {
                  for (int k = 0; k < 4; k++)
                  {
                      if (operations[j] == OpsCombo->Items->Strings[k]) opsitem = k;
                  }
                  switch (opsitem)
                  {
                      case 0: newvalue += xvalue; break;
                      case 1: newvalue -= xvalue; break;
                      case 2: newvalue *= xvalue; break;
                      case 3: newvalue /= xvalue; break;
                  }
             } // end else
         } // end jth variable
         MainForm->Grid->Cells[newcol][i] = newvalue;
         FmtCell(i,newcol);
     } // next subject

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Equation Used for the New Variable");
     FrmOutPut->RichOutPut->Lines->Add("");
     strcpy(outline,NewVarEdit->Text.c_str());
     strcat(outline," = ");
     for (int j = 0; j < NoEntries; j++)
     {
         strcat(outline,functions[j].c_str());
         strcat(outline," ");
         strcat(outline,variables[j].c_str());
         strcat(outline," ");
         if (j < NoEntries-1)
         {
            strcat(outline,operations[j+1].c_str());
            strcat(outline," ");
         }
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TEquationForm::CancelBtnClick(TObject *Sender)
{
     delete[] variables;
     delete[] functions;
     delete[] operations;
}
//---------------------------------------------------------------------------

void __fastcall TEquationForm::ReturnBtnClick(TObject *Sender)
{
     delete[] variables;
     delete[] functions;
     delete[] operations;
}
//---------------------------------------------------------------------------


void __fastcall TEquationForm::OpsComboClick(TObject *Sender)
{
     int index = OpsCombo->ItemIndex;
     OpEdit->Text = OpsCombo->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TEquationForm::FunctionComboClick(TObject *Sender)
{
     int index = FunctionCombo->ItemIndex;
     FuncEdit->Text = FunctionCombo->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TEquationForm::VarComboClick(TObject *Sender)
{
     int index = VarCombo->ItemIndex;
     VarEdit->Text = VarCombo->Items->Strings[index];
}
//---------------------------------------------------------------------------

