//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "GLMGrid.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGLMGridFrm *GLMGridFrm;

//---------------------------------------------------------------------------
__fastcall TGLMGridFrm::TGLMGridFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGLMGridFrm::ReturnBtnClick(TObject *Sender)
{
    GLMGridFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TGLMGridFrm::SaveBtnClick(TObject *Sender)
{
     FILE *file1;
     int nrows, ncols, col;
     char cellstr[31];
     char FileName[121];
     struct VarDef *vdef[1000];
     AnsiString astring;

     nrows = Grid->RowCount-1;
     ncols = Grid->ColCount-1;
     SaveDialog1->DefaultExt = "OS4";
     SaveDialog1->Filter = "Stats4Free *.OS4|*.OS4|TAB *.tab|*.TAB|Comma *.CSV|*.CSV|Space *.SSV|*.SSV|All *.*|*.*";
     SaveDialog1->FilterIndex = 1;
     if (SaveDialog1->Execute())
     {
         // create definitions
         for (int col = 1; col <= ncols; col++)
         {
             vdef[col] = new VarDef;
             astring = Grid->Cells[col][0];
             strcpy(vdef[col]->ShortLabel,astring.c_str());
             astring = "VARIABLE" + IntToStr(col);
             strcpy(vdef[col]->LongLabel, astring.c_str());
             vdef[col]->VarType = 0;
             vdef[col]->Justify = 2; // left justify
             vdef[col]->Width = 8;
             vdef[col]->Decimals = 2;
             vdef[col]->NoLabels = 0;
             vdef[col]->Sequence = col;
             vdef[col]->ColWide = MainForm->Grid->ColWidths[col];
             for (int i = 0; i < 100; i++)
             {
                 strcpy(vdef[col]->ValLabels[i],"");
                 strcpy(vdef[col]->LabelValue[i],"");
             }
         }
         strcpy(FileName,SaveDialog1->FileName.c_str());
         if ((file1 = fopen(FileName,"wb")) != NULL)
         {
            // update column widths in the variable definitions
            for (int i = 1; i <= ncols; i++)
            vdef[i]->ColWide = MainForm->Grid->ColWidths[i];
            file1 = fopen(FileName,"wb");
            fwrite(&nrows,sizeof(nrows),1,file1);
            fwrite(&ncols,sizeof(ncols),1,file1);
            for (int i = 1; i <= ncols; i++) fwrite(vdef[i],sizeof(VarDef),1,file1);
            for (int i = 1; i <= nrows; i++)
            {
                for (int j = 1; j <= ncols; j++)
                {
                    strcpy(cellstr,Grid->Cells[j][i].c_str());
                    fwrite(&cellstr,sizeof(cellstr),1,file1);
                }
            }
         }
    }
    fclose(file1);
    for (int i = 1; i <=ncols; i++)
    {
        delete vdef[i];
        vdef[i] = NULL;
    }
}
//---------------------------------------------------------------------------
