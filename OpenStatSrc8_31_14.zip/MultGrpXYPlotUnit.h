//---------------------------------------------------------------------------

#ifndef MultGrpXYPlotUnitH
#define MultGrpXYPlotUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TMultGrpXYPlot : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TLabel *Label1;
        TListBox *Varlist;
        TBitBtn *XInBtn;
        TLabel *Label2;
        TBitBtn *XOutBtn;
        TEdit *XEdit;
        TBitBtn *YInBtn;
        TBitBtn *YOutBtn;
        TLabel *Label4;
        TEdit *PlotTitleEdit;
        TButton *ResetBtn;
        TGroupBox *GroupBox1;
        TCheckBox *DescChk;
        TCheckBox *LinesBox;
        TButton *CancelBtn;
        TButton *OKBtn;
        TLabel *Label3;
        TEdit *YEdit;
        TBitBtn *GrpInBtn;
        TBitBtn *GrpOutBtn;
        TLabel *Label5;
        TEdit *GroupEdit;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall XInBtnClick(TObject *Sender);
        void __fastcall XOutBtnClick(TObject *Sender);
        void __fastcall YInBtnClick(TObject *Sender);
        void __fastcall YOutBtnClick(TObject *Sender);
        void __fastcall GrpInBtnClick(TObject *Sender);
        void __fastcall GrpOutBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall plotxy(double **XValues, double **YValues,
                double MaxX, double MinX, double MaxY, double MinY, int N,
                int NoY, int MinGrp);

private:	// User declarations
public:		// User declarations
        __fastcall TMultGrpXYPlot(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMultGrpXYPlot *MultGrpXYPlot;
//---------------------------------------------------------------------------
#endif
