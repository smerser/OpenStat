//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "functions.h"
#include "MainUnit.h"
#include "Math.hpp"
#include <stdlib.h>
#include "OutPut.h"
#include <string.h>
#include <stdio.h>

//-----------------------------------------------------------------------
extern int NoVariables;
extern int NoCases;

double ftest(double DF1, double DF2, double f)
{
    double prob;

    if (f < 0.0001) return 1.0;
    prob = betai(0.5 * DF2, 0.5 * DF1, DF2 / (DF2 + DF1 * f));
    if (prob > 1.0) prob = 2.0 - prob;
    return prob;
}

//----------------------------------------------------------------------------------------------

double betai(double A, double b, double X)
{
    double bt;

    if (X < 0.0 || X > 1.0)
    {
        Application->MessageBox("Bad x in incomplete beta function - terminating","PROBLEM!",MB_OK);
        return 0.0;
    }
    if (X == 0.0 || X == 1.0) bt = 0.0;
    else bt = exp(gammln(A + b) - gammln(A) - gammln(b) + A * log(X) + b * log(1.0 - X));
    if (X < (A + 1.0) / (A + b + 2.0) ) return (bt * betacf(A, b, X) / A);
    else return (1.0 - bt * betacf(b, A, 1.0 - X) / b);
}

//---------------------------------------------------------------------------------------------

double betacf(double A, double b, double X)
{
    int itmax, M;
    double eps, am, bm, qab, qap, qam, d, bz, em, ap, bp, app, bpp,aold, az, tem;

    itmax = 1000;
    eps = 0.0000003;

    am = 1.0;
    bm = 1.0;
    az = 1.0;
    qab = A + b;
    qap = A + 1.0;
    qam = A - 1.0;
    bz = 1.0 - qab * X / qap;
    for (M = 1; M <= itmax; M++)
    {
        em = M;
        tem = em + em;
        d = em * (b - M) * X / ((qam + tem) * (A + tem));
        ap = az + d * am;
        bp = bz + d * bm;
        d = -(A + em) * (qab + em) * X / ((A + tem) * (qap + tem));
        app = ap + d * az;
        bpp = bp + d * bz;
        aold = az;
        am = ap / bpp;
        bm = bp / bpp;
        az = app / bpp;
        bz = 1.0;
        if (fabs(az - aold) < eps * fabs(az)) return az;
    }
    Application->MessageBox ("a or b too big or itmax too small in betacf","PROBLEM!",MB_OK);
    return az;
}

//------------------------------------------------------------------------------------------

double gammln(double xx)
{
    double cof[6], X, tmp, ser;
    int j;

    cof[0] = 76.18009173;
    cof[1] = -86.50532033;
    cof[2] = 24.01409822;
    cof[3] = -1.231739516;
    cof[4] = 0.00120858003;
    cof[5] = -0.00000536382;

    X = xx - 1.0;
    tmp = X + 5.5;
    tmp = tmp - ((X + 0.5) * log(tmp));
    ser = 1.0;
    for (j = 0; j <= 5; j++)
    {
        X = X + 1.0;
        ser = ser + cof[j] / X;
    }
    return ( -tmp + log(2.50662827465 * ser) );
}

//------------------------------------------------------------------------------------------

double chisquaredprob(double X, int k)
{
	// the distribution function of the chi-squared distribution based on k d.f.
	double factor; // factor which multiplies sum of series
	double g;      // lngamma(k1+1)
	double k1;     // adjusted degrees of freedom
	double sum;    // temporary storage for partial sums
	double term;   // term of series
	double x1;     // adjusted argument of funtion
    double chi2prob; // chi-squared probability

     if ((X < 0.01) || (X > 1000.0))
     {
          if (X < 0.01) chi2prob = 0.0001;
          else chi2prob = 0.999;
          return chi2prob;
     }
     else
     {
    	x1 = 0.5 * X;
    	k1 = 0.5 * k;
    	g = gammln(k1 + 1);
    	factor = exp(k1 * log(x1) - g - x1);
    	sum = 0;
    	if (factor > 0)
    	{
        	term = 1.0;
          	sum = 1.0;
          	while ( (term / sum) > 0.000001)
          	{
               k1++;
               term *= (x1 / k1);
               sum += term;
          	} // end of while loop
    	} // end of if-then loop
    	chi2prob = sum * factor;
    } //end if .. else
    return chi2prob;
} // end of ChiSquaredProb

//----------------------------------------------------------------------------

double ord(double z)
{
	double pi = 3.14159;
    return(1.0 / sqrt(2.0 * pi)) * (1.0 / exp(z * z / 2.0));
} // End ord function

//----------------------------------------------------------------------------

double f(double z)
{
	// the density function of the standard normal distribution (height of curve)
    double A = 0.39894228;  // 1 / sqrt(2*pi)
    return (A * exp(-0.5 * z * z));
}  // End Function


//---------------------------------------------------------------------------

double simpsonintegral(double A, double b)
{
	// integrates the function f from lower a to upper limit b choosing an
	// interval length so that the error is less than a given amount -
	// the default value is 1.0e-06
	const double Errorconst = 0.00001;
	double H;        // current length of interval
	long i;          // counter
	double integral;    // current approximation to integral
	double lastint;  // previous approximation
	long N;          // no. of intervals
	double sum1;
	double sum2;
	double sum4;     // sums of function values

     N = 2;
     H = 0.5 * (b - A);
     sum1 = H * (f(A) + f(b));
     sum2 = 0.0;
     sum4 = f(0.5 * (A + b));
     integral = H * (sum1 + 4.0 * sum4);
     do
     {
           lastint = integral;
           N = N + N;
           H = 0.5 * H;
           sum2 = sum2 + sum4;
           sum4 = 0.0;
           i = 1;
           do
           {
                 sum4 = sum4 + f(A + i * H);
                 i = i + 2;
           } while (i <= N);
           integral = H * (sum1 + 2.0 * sum2 + 4.0 * sum4);
     } while (fabs(integral - lastint) >= Errorconst);
     return (integral / 3.0);
}  // end of SimpsonIntegral

//---------------------------------------------------------------------------

double normalprob(double z)
{
	// the distribution function of the standard normal distribution derived
	// by integration using simpson's rule .
    return (0.5 + simpsonintegral(0.0, z));
} //End of normalprob

//---------------------------------------------------------------------------

double zcumsimp(double z)
{
	double cp;
	bool negative;

     negative = false;
     if (z <= 0) negative = true;
     z = fabs(z);
     cp = normalprob(z);
     if (negative) cp = 1.0 - cp;
     return cp;
} // End zcumsimp Function

//---------------------------------------------------------------------------

double zprob(double p, bool &errorstate)
{
	// value of probability between approx. 0 and .5 entered in p and the
    // z value is returned  z
	double z, xp, lim, p0, p1, p2, p3, p4, q0, q1, q2, q3, q4, Y;

     errorstate = true;
     lim = 1E-19;
     p0 = -0.322232431088;
     p1 = -1.0;
     p2 = -0.342242088547;
     p3 = -0.0204231210245;
     p4 = -4.53642210148E-05;
     q0 = 0.099348462606;
     q1 = 0.588581570495;
     q2 = 0.531103462366;
     q3 = 0.10353775285;
     q4 = 0.0038560700634;
     xp = 0.0;
     if (p > 0.5) p = 1 - p;
     if (p < lim) z = xp;
     else
     {
          errorstate = false;
          if (p == 0.5) z = xp;
          else
          {
               Y = sqrt(log(1.0 / (p * p)));
               xp = Y + ((((Y * p4 + p3) * Y + p2) * Y + p1) * Y + p0) / \
                    ((((Y * q4 + q3) * Y + q2) * Y + q1) * Y + q0);
               if (p < 0.5) xp = -xp;
               z = xp;
          }
     }
     return z;
}  // End function zprob

// ----------------------------------------------------------------------------

double inversez(double prob)
{
	// obtains the inverse of z, that is, the z for a probability associated
    // with a normally distributed z score.
        double z, p;
        bool flag;

        p = prob;
        if (prob > 0.5) p = 1.0 - prob;
        z = zprob(p,flag);
        if (prob > 0.5) z = fabs(z);
        return z;
} //End of inversez Function

//---------------------------------------------------------------------------


double lngamma(double w)

/* Calculates the logarithm of the gamma function.  w must be such that */
/*   2*w is an integer > 0.                                             */

{

double a = 0.57236494; /* log(sqrt(pi)) */
double answer;
double sum; /* a temporary store for summation of values */

	sum = 0;
	w = w - 1;
	while (w > 0.0)
	{
		sum = sum + log(w);
		w = w - 1;
	} /* of summation loop */
	if (w < 0.0) answer = sum + a;
	   else answer = sum;
	   return(answer);
}

/* -------------------incomplete beta ratio ----------------------------- */

double betaratio(double x, double a, double b, double lnbeta)

/* calculates the incomplete beta function ratio with parameters a    */
/* and b.  LnBeta is the logarithm of the complete beta function with */
/* parameters a and b.                                                */

{

double error = 1.0E-7;

double c; /* c = a + b */
double    factor1,factor2,factor3; /* factors multiplying terms in series */
int      i, j;                    /* counters */
double    sum;                     /* current sum of series */
double    temp;                    /* temporary store for exchanges */
double    term;                    /* term of series */
bool      xlow; /* boolean status of x which determines the end from which the */
			/* series is evaluated */
//double    ylow;                    /* adjusted argument */
double    y;

	if ((x==0) || (x==1))  sum = x;
	else
	{
		c = a + b;
		if (a < (c * x))
		{
			xlow = true;
			y = x;
			x = 1 - x;
			temp = a;
			a = b;
			b = temp;
		}
		else
		{
			xlow = false;
			y = 1 - x;
		}
		term = 1;
		j = 0;
		sum = 1;
		i = fabs(b + c * y) + 1;
		factor1 = x / y;
		do
		{
			 j = j + 1;
			 i = i - 1;
			 if (i >= 0)
			 {
				 factor2 = b - j;
				 if (i == 0) factor2 = x;
			 }
			 if (fabs(a + j) < 1.0e-6)  exit(0);
			 term = term * factor2 * factor1 / (a + j);
			 sum = sum + term;
		} while ((fabs(term) > sum) || (fabs(term) > (error * sum)));
		factor3 = exp(a * log(x) + (b - 1) * log(y) - lnbeta);
		sum = sum * factor3 / a;
		if (xlow) sum = 1 - sum;
	}
	return(sum);
}

// -----------inverse of the incomplete beta function ratio -------------
double inversebetaratio(double ratio, double a, double b, double lnbeta)
{

/* Calculates the inverse of the incomplete beta function ratio with */
/* parameters a and b.  LnBeta is the logarithm of the complete beta */
/* function with parameters a and b.  Uses function betaratio.       */

double error = 1.0E-7;

bool      largeratio;                    /* boolean flag */
double    temp1, temp2, temp3, temp4;    /* temporary variables */
double    x, x1;                  /* successive estimates of inverse ratio */
double    y;                        /* adjustment during newton iteration */

	if ((ratio == 0) || (ratio == 1)) x = ratio;
	else
	{
		largeratio = false;
		if (ratio > 0.5)
		{
			largeratio = true;
			ratio = 1 - ratio;
			temp1 = a;
			b = a;
			a = temp1;
		}
		/* calcuates initial estimate for x */
		temp1 = sqrt(-log(ratio * ratio));
		temp2 = 1.0 + temp1 * (0.99229 + 0.04481 * temp1);
		temp2 = temp1 - (2.30753 + 0.27061 * temp1) / temp2;
		if ((a > 1) && (b > 1))
		{
			temp1 = (temp2 * temp2 - 3.0) / 6.0;
			temp3 = 1.0 / (a + a -1.0);
			temp4 = 1.0 / (b + b - 1.0);
			x1 = 2.0 /(temp3 + temp4);
			x = temp1 + 5.0 / 6.0 - 2.0 / (3.0 * x1);
			x = temp2 * sqrt(x1 + temp1) / x1 - x * (temp4 - temp3);
			x = a / (a + b * exp(x + x));
		}
		else
		{
			temp1 = b + b;
			temp3 = 1.0 / (9.0 * b);
			temp3 = 1.0 - temp3 + temp2 * sqrt(temp3);
			temp3 = temp1 * temp3 * temp3 * temp3;
			if (temp3 > 0)
			{
				temp3 = (4.0 * a + temp1 - 2.0) / temp3;
				if (temp3 > 1) x = 1.0 - 2.0 / (1 + temp3);
				else x = exp((log(ratio * a) + lnbeta) / a);
			}
			else x = 1.0 - exp((log((1 - ratio) * b) + lnbeta) / b);
		}

		/* Newton iteration */
		do
		{
             y = betaratio(x,a,b,lnbeta);
			 y = (y - ratio) * exp((1-a)*log(x)+(1-b)*log(1-x)+lnbeta);
             temp4 = y;
             x1 = x - y;
			 while ((x1 <= 0) || (x1 >= 1))
			 {
				 temp4 = temp4 / 2;
				 x1 = x - temp4;
			 }
             x = x1;
		} while (fabs(y) >= error);
		if (largeratio) x = 1 - x;
	}
	return(x);
}

//------------------------------------------------------------------------
/* --------------------Inverse F distribution function ------------------- */

double fpercentpoint(double p, int k1, int k2)

/* Calculates the inverse F distribution function based on k1 and k2 */
/* degrees of freedom.  Uses function lngamma, betaratio and the     */
/* inversebetaratio routines.                                        */

{

double    h1, h2;             /* half degrees of freedom k1, k2 */
double    lnbeta;   /* log of complete beta function with params h1 and h2 */
double    ratio;              /* beta ratio */
double    x;                  /* inverse beta ratio */

     h1 = 0.5 * k2;
     h2 = 0.5 * k1;
     ratio = 1 - p;
     lnbeta = lngamma(h1) + lngamma(h2) - lngamma(h1 + h2);
     x = inversebetaratio(ratio,h1,h2,lnbeta);
	return( k2 * (1 - x) / (k1 * x));
}

//---------------------------------------------------------------------------
/* ------------------------- alnorm ---------------------------------- */

double alnorm(double x, bool upper)

{

/* algorithm AS 66 from Applied Statistics, 1973, Vol. 22, No.3, pg.424-427 */

double   ltone, utzero, zero, half, one, con, z, y;
bool     up;
double   altemp;

     ltone = 7.0;
     utzero = 18.66;
     zero = 0.0;
     half = 0.5;
     one = 1.0;
     con = 1.28;
     up = upper;
     z = x;
	if (z < zero)
	{
		up = (! up);
		z = -z;
	}
	if ((z <= ltone) || (up) && (z <= utzero))
	{
		y = half * z * z;
		if (z > con)
		{
               altemp = 0.398942280385 * exp(-y) /
               (z - 3.8052e-8 + 1.00000615302 /
               (z + 3.98064794e-4 + 1.98615381364 /
               (z - 0.151679116635 + 5.29330324926 /
               (z + 4.8385912808 - 15.1508972451 /
               (z + 0.742380924027 + 30.789933034 /
               (z + 3.99019417011))))));
		}
          else altemp = half - z * (0.398942280444 - 0.399903438504 * y /
               (y + 5.75885480458 - 29.8213557808 /
               (y + 2.62433121679 + 48.6959930692 /
               (y + 5.92885724438))));
	}
     else altemp = zero;
	if (! up) altemp = one - altemp;
	return(altemp);
}

/* ----------------- Probability of student range ---------------------- */

double prtrng(double q, double v, double r)

/* algorith as 190 appl. Statistics, 1983, Vol.32, No.2
  evaluates the probability from 0 to q for a studentized range having
  v degrees of freedom and r samples. */

{

double   pcutj, pcutk, step, vmax, zero, fifth, half, one, two;
double   cv1, cv2, cvmax;
double    vw[31], qw[31];
double   cv[5];
int      jmin, jmax, kmin, kmax, ifault;
double   g, gmid, r1, c, h, v2, gstep, gk, pk, pk1, pk2, w0, pz;
double   x, hj, ehj, pj;
int      j, jj, jump, k;
double   sumprob;

   sumprob = 0.0;
   pcutj = 0.00003; pcutk = 0.0001; step = 0.45; vmax = 120.0;
   zero = 0.0; fifth = 0.2; half = 0.5; one = 1.0; two = 2.0;
   cv1 = 0.193064705; cv2 = 0.293525326; cvmax = 0.39894228;
   cv[1] = 0.318309886; cv[2] = -0.268132716e-2;
   cv[3] = 0.347222222e-2; cv[4] = 0.833333333e-1;
   jmin = 3; jmax = 13; kmin = 7; kmax = 15;
   /* check initial values */
   ifault = 0;
   if ((v < one) || (r < two)) ifault = 1;
   if ((q >= zero) && (ifault == 0))
   {  /* main body of function */
	 g = step * pow(r,-fifth);
	 gmid = half * log(r);
      r1 = r - one;
	 c = log(r * g * cvmax);
	 if (c <= vmax)
	 {
	    h = step * pow(v,-half);
         v2 = v * half;
	    if (v == one) c = cv1;
	    if (v == two) c = cv2;
	    if (! ((v == one) || (v == two))) c = sqrt(v2) * cv[1] /
            (one + ((cv[2] / v2 + cv[3]) / v2 + cv[4]) / v2);
	    c = log(c * r * g * h);
	 }
   /* compute integral.
	Given a row k, the procedure starts at the midpoint and works outward
	(index j) in calculating the probability at nodes symetric about the
	midpoint.  The rows (index k) are also processed outwards symmetrically
	about the midpoint.  The center row is unpaired. */
	gstep = g;
	qw[1] = -one;
	qw[jmax + 1] = -one;
	pk1 = one;
	pk2 = one;
	for (k = 1; k < kmax+1; ++k)
	{
       gstep = gstep - g;
pt21:  gstep = -gstep;
       gk = gmid + gstep;
       pk = zero;
	  if ((pk2 > pcutk) || (k <= kmin))
	  {
             w0 = c - gk * gk * half;
             pz = alnorm(gk,true);
             x = alnorm(gk - q,true) - pz;
		   if ((x > zero)) pk = exp(w0 + r1 * log(x));
		   if (v <= vmax)
		   {
                jump = -jmax;
		pt22: jump = jump + jmax;
			 for (j = 1;j < jmax+1; ++j)
			 {
				jj = j + jump;
				if (qw[jj] <= zero)
				{
					 hj = h * j;
					 if (j < jmax) qw[jj + 1] = -one;
					 ehj = exp(hj);
					 qw[jj] = q * ehj;
					 vw[jj] = v * (hj + half - ehj * ehj * half);
				}
				pj = zero;
				x = alnorm(gk - qw[jj],true) - pz;
				if (x > zero) pj = exp(w0 + vw[jj] + r1 * log(x));
				pk = pk + pj;
				if (pj <= pcutj)
				{
					  if((jj > jmin) || (k > kmin)) goto pt25;
				}
			 } /* for j = 1 to jmax */
	pt25:  h = -h;
			if (h < zero) goto pt22;
			} /* if v less than or equal vmax */
	  }  /* if pk2 > pcutk or k <= kmin */
	  sumprob = sumprob + pk;
	  if ((k <= kmin) || (pk > pcutk) || (pk1 > pcutk))
	  {
           pk2 = pk1;
           pk1 = pk;
		 if (gstep > zero) goto pt21;
	  }
	}   /* for k = 1 to kmax */
   }; /* main body of function */
   if (ifault == 0) return(sumprob);
   else return(-1.0);
}


/* -------------Studentized range statistic distribution function ------- */

double STUDENT(double q, double v, double r)
{

/* Yields the probability of a sample value of Q or larger from a population
  with r means and degrees of freedom for the mean square error of v. */

     double  probq;
         if (v > 120.0) v = 120.0;
	 probq = prtrng(q,v,r);
	 if (probq < 0)
     {
       Application->MessageBox("fault in calculating prob. of Student Range Q","ERROR!",MB_OK);
       probq = 0.0;
     }
     probq = 1.0 - probq;
	 return(probq);
}

//-------------------------------------------------------------------------

double inversechi(double p, int k)
{
       double a1, w, z;

       z = inversez(p);
       a1 = 2.0 / ( 9.0 * k);
       w = 1.0 - a1 + z * sqrt(a1);
       return (k * w * w * w);
}

//--------------------------------------------------------------------------

double chi2func(double chisqr, double df)
{
     // Returns the height of the density curve for the chi-squared statistic
     double ratio1, ratio2, ratio3, h;

     ratio1 = df / 2.0;
     ratio2 = (df - 2.0) / 2.0;
     ratio3 = chisqr / 2.0;
     h = (1.0 / (pow(2.0,ratio1) * exp(lngamma(ratio1)))) * pow(chisqr,ratio2) * ( 1.0 / exp(ratio3));
     return (h);
}

//--------------------------------------------------------------------------

double Ffunc(double F, int df1, int df2)
{
       // Returns the height of the density curve for the F statistic
       double ratio1;
       double ratio2;
       double ratio3;
       double ratio4;
       double h;
       double part1, part2, part3, part4, part5, part6, part7, part8, part9;

       ratio1 = (double(df1 + df2)) / 2.0;
       ratio2 = (double(df1) - 2.0) / 2.0;
       ratio3 = double(df1) / 2.0;
       ratio4 = double(df2) / 2.0;
       part1 = exp(lngamma(ratio1));
       part2 = pow(df1,ratio3);
       part3 = pow(df2,ratio4);
       part4 = exp(lngamma(ratio3));
       part5 = exp(lngamma(ratio4));
       part6 = pow(F,ratio2);
       part7 = pow((F*df1+df2),ratio1);
       part8 = (part1 * part2 * part3) / (part4 * part5);
       if (part7 == 0.0) part9 = 0.0;
       else part9 = part6 / part7;
       h = part8 * part9;
/*
     ratio1 := (df1 + df2) / 2.0;
     ratio2 := (df1 - 2.0) / 2.0;
     ratio3 := df1 / 2.0;
     ratio4 := df2 / 2.0;
     ffunc := ((gamma(ratio1) * realraise(df1,ratio3) *
              realraise(df2,ratio4)) /
              (gamma(ratio3) * gamma(ratio4))) *
              (realraise(f,ratio2) / realraise((f*df1+df2),ratio1));
*/
       return h;
}
//----------------------------------------------------------------------

void scatplot(double *X, double *Y, int NoCases, char *titlestr,
     char *x_axis, char *y_axis, double x_min, double x_max, double y_min,
     double y_max)
{
     int i, j, xslot, height, row;
     double MaxY, incrementx, incrementy, rangex, rangey, swap;
     bool overlap;
     char plotstring[62][61];
     char ValueString[11];
     char outline[81];

     height = 20;
     rangex = x_max - x_min;
     incrementx = rangex / 9.0;
     rangey = y_max - y_min;
     incrementy = rangey / height;
     // sort in ascending order
     for (i = 0; i < NoCases - 1; i++)
     {
          for (j = i + 1; j < NoCases; j++)
          {
               if (Y[i] < Y[j])
               {
                    swap = Y[i];
                    Y[i] = Y[j];
                    Y[j] = swap;
                    swap = X[i];
                    X[i] = X[j];
                    X[j] = swap;
               }
          }
     }
     sprintf(outline,"             SCATTERPLOT - %s",titlestr);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     MaxY = y_max;
     for (i = 0; i <  60; i++)
          for (j = 0; j < height + 1; j++) plotstring[j][i] = ' ';
     // Set up the plot strings with the data
     row = -1;
     while (MaxY > y_min)
     {
          row++;
          plotstring[row][30] = '|';
          if (row == (height / 2))
          {
               for (i = 0; i < 60; i++) plotstring[row][i] = '-';
          }
          for (i = 0; i < NoCases; i++)
          {
               if ((MaxY >= Y[i]) && (Y[i] > (MaxY - incrementy)))
               {
                    xslot = int(((X[i] - x_min) / rangex) * 60.0);
                    if (xslot < 0) xslot = 0;
                    if (xslot > 59) xslot = 59;
                    overlap = false;
                    //itoa(i,ValueString,10);
                    //howlong = strlen(ValueString);
                    //for (L = xslot; L < (xslot + howlong - 1); L++)
                    //{
                      if (plotstring[row][xslot] != ' ') overlap = true;
                    //}
                    if (overlap == true) plotstring[row][xslot] = '*';
                    else
                    {
                      //for (L = 0; L < howlong; L++)
                      //    plotstring[row][xslot+L] = ValueString[L];
                      plotstring[row][xslot] = '.';
                    }
               }
          }
          MaxY = MaxY - incrementy;
     } // end of while statement
     // print the plot
     sprintf(outline,"%70s",y_axis);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 0; i < row; i++)
     {
          strcpy(outline,"");
          //if (y_axis[i]== ' ') outline[i] = '|';
          for (j = 0; j < 60; j++) outline[j] = plotstring[i][j];
          outline[60] = '\0';
          strcat(outline,"|-");
          sprintf(ValueString,"%6.2f",y_max - i * incrementy + incrementy);
          strcat(outline,ValueString);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"_______________________________________________________________");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     strcpy(outline,"");
     for (i = 0; i < 10; i++)
        strcat(outline,"   |  ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"%s",x_axis);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     strcpy(outline,"");
     for (i = 0; i < 10; i++)
     {
         sprintf(ValueString,"%6.2f",x_min + (i * incrementx));
         strcat(outline,ValueString);
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->ShowModal();
} //End of scatplot procedure
//----------------------------------------------------------------------------

double tprob(double t, double DF)
{
    // Returns the probability corresponding to a two-tailed t test.
    double F = t * t;
    double prob = ftest(1.0,DF,F);
    return prob;
}
//----------------------------------------------------------------------------

double inverset(double Probt, double DF)
{
    // Returns the t value corresponding to a two-tailed t test probability.
    double z = inversez(Probt);
    double W = z * ((8.0 * DF + 3.0) / (1.0 + 8.0 * DF));
    double tValue = sqrt(DF * (exp(W * W / DF) - 1.0));
    if (Probt < 0.5) tValue = -tValue;
    return tValue;
}
//----------------------------------------------------------------------------

double Percentile(int nscrgrps, double pcnt, double *freq,
                  double *cumfreq, double *Scores)
{
   int i, interval;
   double pcntile, Llimit, Ulimit, cumlower, intvlfreq;

   interval = 0;
   for (i = 0; i <=nscrgrps-1; i++)
   {
       if (cumfreq[i] >= pcnt)
       {
           interval = i;
           break;
       }
   }
   if (interval > 0)
   {
       Llimit = Scores[interval];
       Ulimit = Scores[interval+1];
       cumlower = cumfreq[interval-1];
       intvlfreq = freq[interval];
   }
   else
   {   // Percentile in first interval
       Llimit = Scores[0];
       Ulimit = Scores[1];
       cumlower = 0.0;
       intvlfreq = freq[0];
   }
   if (intvlfreq > 0) pcntile = Llimit + ((pcnt - cumlower) / intvlfreq) * (Ulimit- Llimit);
   else pcntile = Llimit;
   return (pcntile);
}
//----------------------------------------------------------------------------

void swilk (bool &init, double *x, int n, int n1, int n2, double *a,
            double &w, double &pw, int &ifault)
{

//        ALGORITHM AS R94 APPL. STATIST. (1995) VOL.44, NO.4
//        Calculates the Shapiro-Wilk W test and its significance level

// ARGUMENTS:
//   INIT     Set to .FALSE. on the first call so that weights A(N2) can be
//            calculated.   Set to .TRUE. on exit unless IFAULT = 1 or 3.
//   X(N1)    Sample values in ascending order.
//   N        The total sample size (including any right-censored values).
//   N1       The number of uncensored cases (N1 <= N).
//   N2       Integer part of N/2.
//   A(N2)    The calculated weights.
//   W        The Shapiro-Wilks W-statistic.
//   PW       The P-value for W.
//   IFAULT   Error indicator:
//            = 0 for no error
//            = 1 if N1 < 3
//            = 2 if N > 5000 (a non-fatal error)
//            = 3 if N2 < N/2
//            = 4 if N1 > N or (N1 < N and N < 20).
//            = 5 if the proportion censored (N - N1)/N > 0.8.
//            = 6 if the data have zero range.
//            = 7 if the X's are not sorted in increasing order

// Fortran 90 version by Alan.Miller @ vic.cmis.csiro.au
// Latest revision - 4 December 1998

	double summ2, ssumm2, fac, rsn, an, an25, a1, a2, delta, range;
	double sa, sx, ssx, ssa, sax, asa, xsx, ssassx, w1, y, xx, xi;
	double gamma, m, s, ld, bf, z90f, z95f, z99f, zfm, zsd, zbar;
	int ncens, nn2, i, i1, j;
   bool upper;
   double c1[6] = {0.0, 0.221157, -0.147981, -2.07119, 4.434685, -2.706056};
	double c2[6] = {0.0, 0.042981, -0.293762, -1.752461, 5.682633, -3.582633};
	double c3[4] = {0.5440, -0.39978, 0.025054, -0.6714E-3 };
	double c4[4] = {1.3822, -0.77857, 0.062767, -0.0020322};
	double c5[4] = {-1.5861, -0.31082, -0.083751, 0.0038915};
	double c6[3] = {-0.4803, -0.082676, 0.0030302};
   double c7[2] = {0.164, 0.533};
	double c8[2] = {0.1736, 0.315};
	double c9[2] = {0.256, -0.00635};
	double g[2] = {-2.273, 0.459};
	double z90, z95, z99, zm, zss, bf1, xx90, xx95,	zero, one, two, three;
	double sqrth, qtr, th, small,	pi6, stqr;

	upper = true;
	z90 = 1.2816;
	z95 = 1.6449;
	z99 = 2.3263;
	zm = 1.7509;
	zss = 0.56268;
	bf1 = 0.8378;
	xx90 = 0.556;
	xx95 = 0.622;
	zero = 0.0;
	one = 1.0;
	two = 2.0;
	three = 3.0;
	sqrth = 0.70711;
	qtr = 0.25;
	th = 0.375;
	small = 1E-19;
	pi6 = 1.909859;
	stqr = 1.047198;
	pw  =  one;
	if (w >= zero) w = one;
	an = n;
	ifault = 3;
	nn2 = n / 2;
	if (n2 < nn2) return;
	ifault = 1;
	if (n < 3) return;

//        If INIT is false, calculates coefficients for the test

	if (! init)
   {
		if (n == 3) a[1] = sqrth;
  		else
      {
			   an25 = an + qtr;
    			summ2 = zero;
    			for (i = 1; i <= n2; i++)
			   {
      			ppnd7((i - th)/an25, a[i], ifault);
      			summ2 = summ2 + (a[i] * a[i]);
    			}
    			summ2 = summ2 * two;
    			ssumm2 = sqrt(summ2);
    			rsn = one / sqrt(an);
    			a1 = poly(c1, 6, rsn) - a[1] / ssumm2;

            //        Normalize coefficients

    			if (n > 5)
			   {
				   i1 = 3;
      			a2 = -a[2]/ssumm2 + poly(c2,6,rsn);
      			fac = sqrt((summ2 - two * a[1] * a[1]  - two * a[2] * a[2])/
                                   (one - two * pow(a1,2) - two * pow(a2,2)));
      			a[1] = a1;
      			a[2] = a2;
            }
    			else
            {
      			i1 = 2;
      			fac = sqrt((summ2 - two * a[1] * a[1])/ (one - two * a1 * a1));
	      		a[1] = a1;
    			}
    			for (i = i1; i <= nn2; i++) a[i] = -a[i]/fac;
  		}
  		init = true;
	}
	if (n1 < 3) return;

	ncens = n - n1;
	ifault = 4;
	if ((ncens < 0) || ((ncens > 0) && (n < 20))) return;
	ifault = 5;
	delta = ncens/an;
	if (delta > 0.8) return;

//        If W input as negative, calculate significance level of -W

	if (w < zero)
	{
		w1 = one + w;
		ifault = 0;
		goto My70;
	}

//        Check for zero range

	ifault = 6;
	range = x[n1] - x[1];
	if (range < small)  return; //RETURN

//        Check for correct sort order on range - scaled X

	ifault = 7;
	xx = x[1] / range;
	sx = xx;
	sa = -a[1];
	j = n - 1;
	for (i = 2; i <= n1; i++)
	{
  		xi = x[i]/range;
		if (xx-xi > small)
		{
			ShowMessage("x[i]s out of order"); // WRITE(*, *) 'x(i)s out of order'
         return;// RETURN
  		}
		sx = sx + xi;
  		if (i != j)  sa = sa + sign(1, i - j) * a[min(i, j)];
		xx = xi;
  		j = j - 1;
	}
	ifault = 0;
	if (n > 5000)  ifault = 2;

//        Calculate W statistic as squared correlation
//        between data and coefficients

	sa = sa/n1;
	sx = sx/n1;
	ssa = zero;
	ssx = zero;
	sax = zero;
	j = n;
	for (i = 1; i <= n1; i++)
   {
  		if (i != j)  asa = sign(1, i - j) * a[min(i, j)] - sa;
  		else asa = -sa;
  		xsx = x[i]/range - sx;
  		ssa = ssa + asa * asa;
  		ssx = ssx + xsx * xsx;
  		sax = sax + asa * xsx;
  		j = j - 1;
	}

   //        W1 equals (1-W) claculated to avoid excessive rounding error
   //        for W very near 1 (a potential problem in very large samples)

	ssassx = sqrt(ssa * ssx);
	w1 = (ssassx - sax) * (ssassx + sax)/(ssa * ssx);
My70:
 	w = one - w1;

   //        Calculate significance level for W (exact for N=3)

	if (n == 3)
	{
  		pw = pi6 * (ArcSin(sqrt(w)) - stqr);
  		return; //RETURN
	}
	y = log(w1);
	xx = log(an);
   //	m = zero;
   //	s = one;
	if (n <= 11)
	{
  		gamma = poly(g, 2, an);
  		if (y >= gamma)
		{
    			pw = small;
    			exit; //RETURN
  		}
  		y = -log(gamma - y);
  		m = poly(c3, 4, an);
  		s = exp(poly(c4, 4, an));
	}
	else
   {
  		m = poly(c5, 4, xx);
  		s = exp(poly(c6, 3, xx));
	}
	if (ncens > 0)
	{
      //        Censoring by proportion NCENS/N.  Calculate mean and sd
      //        of normal equivalent deviate of W.
      ld = -log(delta);
  		bf = one + xx * bf1;
  		z90f = z90 + bf * pow(poly(c7, 2, pow(xx90,xx)),ld);
  		z95f = z95 + bf * pow(poly(c8, 2, pow(xx95,xx)),ld);
  		z99f = z99 + bf * pow(poly(c9, 2, xx),ld);

      //        Regress Z90F,...,Z99F on normal deviates Z90,...,Z99 to get
      //        pseudo-mean and pseudo-sd of z as the slope and intercept

  		zfm = (z90f + z95f + z99f)/three;
  		zsd = (z90*(z90f-zfm)+z95*(z95f-zfm)+z99*(z99f-zfm))/zss;
  		zbar = zfm - zsd * zm;
  		m = m + zbar * s;
  		s = s * zsd;
	}
	pw = alnorm((y - m)/s, upper);
}

//-----------------------------------------------------------------------------------

void ppnd7 (double p, double &normal_dev, int &ifault)
{

// ALGORITHM AS241  APPL. STATIST. (1988) VOL. 37, NO. 3, 477- 484.
// Produces the normal deviate Z corresponding to a given lower tail area of P;
// Z is accurate to about 1 part in 10**7.

// This ELF90-compatible version by Alan Miller - 20 August 1996
// N.B. The original algorithm is as a function; this is a subroutine


	double zero, one, half, split1, split2, const1, const2, q, r;
   double a0, a1, a2, a3, b1, b2, b3;
	double c0, c1, c2, c3, d1, d2;
	double e0, e1, e2, e3, f1, f2;

	zero = 0.0;
	one = 1.0;
	half = 0.5;
	split1 = 0.425;
	split2 = 5.0;
	const1 = 0.180625;
	const2 = 1.6;
	a0 = 3.3871327179E+00;
	a1 = 5.0434271938E+01;
   a2 = 1.5929113202E+02;
	a3 = 5.9109374720E+01;
   b1 = 1.7895169469E+01;
	b2 = 7.8757757664E+01;
	b3 = 6.7187563600E+01;
	c0 = 1.4234372777E+00;
	c1 = 2.7568153900E+00;
	c2 = 1.3067284816E+00;
	c3 = 1.7023821103E-01;
	d1 = 7.3700164250E-01;
	d2 = 1.2021132975E-01;
	e0 = 6.6579051150E+00;
	e1 = 3.0812263860E+00;
	e2 = 4.2868294337E-01;
	e3 = 1.7337203997E-02;
	f1 = 2.4197894225E-01;
	f2 = 1.2258202635E-02;
	ifault = 0;
	q = p - half;
	if (fabs(q) <= split1)
	{
		r = const1 - q * q;
		normal_dev = q * (((a3 * r + a2) * r + a1) * r + a0) / (((b3 * r + b2) * r + b1) * r + one);
		return; // RETURN
	}
	else
   {
		if (q < zero)  r = p;
      else r = one - p;
  		if (r <= zero)
		{
    			ifault = 1;
    			normal_dev = zero;
    			return; //RETURN
  		}
  		r = sqrt(-log(r));
  		if (r <= split2)
		{
    			r = r - const2;
    			normal_dev = (((c3 * r + c2) * r + c1) * r + c0) / ((d2 * r + d1) * r + one);
      }
		else
      {
    			r = r - split2;
    			normal_dev = (((e3 * r + e2) * r + e1) * r + e0) / ((f2 * r + f1) * r + one);
  		}
  		if (q < zero) normal_dev = - normal_dev;
		return;
	}
} // end procedure ppnd7
//---------------------------------------------------------------------

double poly(double *c, int nord, double x)
{

//        Algorithm AS 181.2   Appl. Statist.  (1982) Vol. 31, No. 2
//        Calculates the algebraic polynomial of order nored-1 with
//        array of coefficients c.  Zero order coefficient is c(1)
	double fn_val, p;
	int i, j, n2;
   double c2[6];
   double result;

   // copy into array for access starting at 1 instead of zero
   for (i = 1; i <= nord; i++) c2[i] = c[i-1];

	fn_val = c2[1];
	if (nord == 1)
    {
         result = fn_val;
         return(result); // RETURN
    }
	p = x * c2[nord];
	if (nord == 2)  goto My20;
	n2 = nord - 2;
	j = n2 + 1;
	for (i = 1; i <= n2; i++)
	{
		p = (p + c2[j])*x;
  		j = j - 1;
	}
My20:
   fn_val = fn_val + p;
	result = fn_val;
   return(result);
} // FUNCTION poly
//-----------------------------------------------------------------------

double sign(double a, double b)
{
      if (b >= 0.0) return (fabs(a));
      else return(-fabs(a));
}
//-------------------------------------------------------------------

int isign(int a, int b)
{
     if (b >= 0) return(abs(a));
     else return(-abs(a));
}
//-------------------------------------------------------------------

double probz(double z)
{
   // the distribution function of the standard normal distribution derived
   // by integration using simpson's rule .
     return( 0.5 + simpsonintegral(0.0,z));
}
//-----------------------------------------------------------------------


double zdensity(double z)
{
   // the density function of the standard normal distribution
   double a = 0.39894228; // 1 / sqrt(2*pi)
   return(a * exp(-0.5 * z*z ));
}
//----------------------------------------------------------------------

double sqr(double value)
{
     return(value * value);
}
//----------------------------------------------------------------------

AnsiString copy(AnsiString source, int first, int last)
{
// emulates the Delphi copy function for copying a substring from one
// ansistring to another.
   if (first < 1) first = 1;
   if (last < first) last = first;
   AnsiString resultstr;
   resultstr = source.SubString(first,last);
   return(resultstr);
}
//---------------------------------------------------------------------------

double WholeValue(double value)
{
        // split a value into the whole and fractional parts
        double whole = floor(value);
        return whole;
}
//---------------------------------------------------------------------------
double FractionValue(double value)
{
        // split a value into the whole and fractional parts
        double fraction = value - floor(value);
        return fraction;
}
//---------------------------------------------------------------------------

double Quartiles(int Type, double pcntile, int N, double *values)
{
        double whole, fraction, result, np;
        int subscript;
        switch (Type)
        {
                case 1 :  np = pcntile * N; break;
                case 2 :  np = pcntile * (N + 1); break;
                case 3 :  np = pcntile * N; break;
                case 4 :  np = pcntile * N; break;
                case 5 :  np = pcntile * (N - 1); break;
                case 6 :  np = pcntile * N + 0.5; break;
                case 7 :  np = pcntile * (N + 1); break;
                case 8 :  np = pcntile * (N + 1); break;
        }
        whole = WholeValue(np);
        fraction = FractionValue(np);
        subscript = whole;
        switch (Type)
        {
           case 1 : result = ((1.0 - fraction) * values[subscript]) + (fraction * values[subscript + 1]);
               break;
           case 2 : result = ((1.0 - fraction) * values[subscript]) + fraction * values[subscript + 1];
               break;
           case 3 : if (fraction == 0.0) result = values[subscript];
               else result = values[subscript + 1];
               break;
           case 4 : if (fraction == 0.0) result = 0.5 * (values[subscript] + values[subscript + 1]);
               else result = values[subscript + 1];
               break;
           case 5 : if (fraction == 0.0) result = values[subscript + 1];
               else result = values[subscript + 1] + fraction * (values[subscript + 2] -
                    values[subscript + 1]);
               break;
           case 6 : result = values[subscript];
               break;
           case 7 : if (fraction == 0.0) result = values[subscript];
               else result = fraction * values[subscript] +
                  ((1.0 - fraction) * values[subscript + 1]);
               break;
           case 8 : if (fraction == 0.0) result = values[subscript];
               if (fraction == 0.5)
                   result = 0.5 * (values[subscript] + values[subscript + 1]);
               if (fraction < 0.5) result = values[subscript];
               if (fraction > 0.5) result = values[subscript + 1];
               break;
        }
        return result;
}

//---------------------------------------------------------------------------


