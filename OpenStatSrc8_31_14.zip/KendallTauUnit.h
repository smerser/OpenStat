//---------------------------------------------------------------------------

#ifndef KendallTauUnitH
#define KendallTauUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TKendallTauForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TEdit *XEdit;
     TEdit *YEdit;
     TEdit *ZEdit;
     TBitBtn *XInBtn;
     TBitBtn *XOutBtn;
     TBitBtn *YInBtn;
     TBitBtn *YOutBtn;
     TBitBtn *ZInBtn;
     TBitBtn *ZOutBtn;
     TGroupBox *GroupBox1;
     TCheckBox *ShowRanksChk;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall XInBtnClick(TObject *Sender);
     void __fastcall XOutBtnClick(TObject *Sender);
     void __fastcall YInBtnClick(TObject *Sender);
     void __fastcall YOutBtnClick(TObject *Sender);
     void __fastcall ZInBtnClick(TObject *Sender);
     void __fastcall ZOutBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TKendallTauForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKendallTauForm *KendallTauForm;
//---------------------------------------------------------------------------
#endif
