//---------------------------------------------------------------------------

#ifndef EvalGenrUnitH
#define EvalGenrUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmEvalGen : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *ProjNameEdit;
    TLabel *Label2;
    TEdit *Author1Edit;
    TEdit *Author2Edit;
    TEdit *Author3Edit;
    TLabel *Label3;
    TMemo *CompanyMemo;
    TLabel *Label4;
    TEdit *DateEdit;
    TGroupBox *GroupBox1;
    TRadioButton *DiagnosticBtn;
    TRadioButton *FormativeBtn;
    TRadioButton *SummativeBtn;
    TGroupBox *GroupBox2;
    TRadioButton *CIPPBtn;
    TRadioButton *ScrivenBtn;
    TRadioButton *ExceptionBtn;
    TRadioButton *CauseBtn;
    TRadioButton *AnecdotalBtn;
    TRadioButton *ChaosBtn;
    TRadioButton *OtherBtn;
    TGroupBox *GroupBox3;
    TCheckBox *PersonnelChk;
    TCheckBox *MaterialsChk;
    TCheckBox *ProcessChk;
    TCheckBox *ProductsChk;
    TCheckBox *FacilitiesChk;
    TCheckBox *SafetyChk;
    TCheckBox *EnvironmentChk;
    TCheckBox *SystemsChk;
    TCheckBox *OtherChk;
    TGroupBox *GroupBox4;
    TCheckBox *PersonnelReqChk;
    TCheckBox *FacilitiesReqChk;
    TCheckBox *EquipReqChk;
    TCheckBox *TimeReqChk;
    TCheckBox *SoftwareReqChk;
    TCheckBox *AccessReqChk;
    TCheckBox *OtherReqChk;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *GenerateBtn;
    TButton *ReturnBtn;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall GenerateBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmEvalGen(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmEvalGen *FrmEvalGen;
//---------------------------------------------------------------------------
#endif
