//---------------------------------------------------------------------------

#ifndef RIDITUnitH
#define RIDITUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TRIDITForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TLabel *Label1;
        TListBox *VarList;
        TLabel *Label2;
        TBitBtn *RowIn;
        TBitBtn *RowOut;
        TEdit *RowEdit;
        TLabel *Label3;
        TBitBtn *ColIn;
        TBitBtn *ColOut;
        TListBox *ColList;
        TGroupBox *GroupBox1;
        TCheckBox *ObsChk;
        TCheckBox *ExpChk;
        TCheckBox *PropChk;
        TCheckBox *ChiChk;
        TCheckBox *YatesChk;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TEdit *RefEdit;
        TLabel *Label4;
        TRadioGroup *RefGrp;
        TLabel *Label5;
        TEdit *AlphaEdit;
        TCheckBox *BonChk;
        TCheckBox *DetailsChk;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall RowInClick(TObject *Sender);
        void __fastcall RowOutClick(TObject *Sender);
        void __fastcall ColInClick(TObject *Sender);
        void __fastcall ColOutClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall ColListClick(TObject *Sender);
        void __fastcall RefGrpClick(TObject *Sender);
private:	// User declarations
void TRIDITForm::Analyze(int RefCol, int *ColNoSelected, AnsiString *RowLabels,
                         AnsiString *ColLabels, int NoToAnalyze, int **Freq,
                         double **Props, int NoRows);
                         
public:		// User declarations
        __fastcall TRIDITForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRIDITForm *RIDITForm;
//---------------------------------------------------------------------------
#endif
