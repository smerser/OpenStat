#include "MainUnit.h"

//-------------------------------------------------------------------

void OpenOSFile(void)
{
	// Opens an OpenStat text file

}

//-------------------------------------------------------------------

void SaveOSFile(void)
{
	// Saves an OpenStat text fle

}

//-------------------------------------------------------------------

