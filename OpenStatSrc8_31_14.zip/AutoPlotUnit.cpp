//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Printers.hpp"
#include <stdio.h>
#include "AutoPlotUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAutoPlotFrm *AutoPlotFrm;
//---------------------------------------------------------------------------
__fastcall TAutoPlotFrm::TAutoPlotFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAutoPlotFrm::ReturnBtnClick(TObject *Sender)
{
    AutoPlotFrm->Hide();    
}
//---------------------------------------------------------------------------


void TAutoPlotFrm::AutoPrint(void)
{
       TPrinter *Prntr = Printer();
//       Prntr->Orientation = poPortrait;
       Prntr->Orientation = poLandscape;
       TRect r = Rect(20,20,Prntr->PageWidth-20,Prntr->PageHeight / 2 + 20);
       Prntr->BeginDoc();
       Prntr->Canvas->StretchDraw(r, Image1->Picture->Bitmap);
       Prntr->EndDoc();
}

//----------------------------------------------------------------------------
void __fastcall TAutoPlotFrm::PrintBtnClick(TObject *Sender)
{
    AutoPrint();
}
//---------------------------------------------------------------------------

void TAutoPlotFrm::AutoPlot(void)
{
    int topmarg, botmarg, leftmarg, rightmarg, height, width, verthi, horizlong;
    int X, Y, middle, yincrement, xincrement, labelheight;
    AnsiString labelstring;
    char label[11];
    double corstep, yprop, scaley;

    height = AutoPlotFrm->Image1->Height;
    width = AutoPlotFrm->Image1->Width;
    middle = height / 2;
    topmarg = height / 10;
    verthi = height - (2 * topmarg);
    botmarg = topmarg + verthi -10;
    leftmarg = width / 10;
    horizlong = width - 2 * leftmarg;
    rightmarg = leftmarg + horizlong;
    yincrement = verthi / 20;
    xincrement = horizlong / npoints;

    Image1->Canvas->Pen->Color = clBlack;
    Image1->Canvas->Brush->Color = clWhite;
    Image1->Canvas->Rectangle(0,0,width,height);

    // print title at top, centered
    labelstring = "Autocorrelations analysis for :";
    labelstring = labelstring + DepVarEdit;
    X = (leftmarg + horizlong / 2) - (Image1->Canvas->TextWidth(labelstring) / 2);
    Y = 1;
    Image1->Canvas->TextOut(X,Y,labelstring);

    // draw middle (zero correlation) axis
    Y = middle;
    Image1->Canvas->MoveTo(leftmarg,Y);
    X = rightmarg;
    Image1->Canvas->LineTo(X,Y);

    // draw right axis
    X = leftmarg;
    Y = botmarg;
    Image1->Canvas->MoveTo(X,Y);
    Y = topmarg;
    Image1->Canvas->LineTo(X,Y);

    // correlation scale to left of vertical axis
    corstep = 1.0;
    for (int i = 0; i < 21; i++)
    {
        Y = topmarg + (i * yincrement);
        sprintf(label,"%4.2f -",corstep);
        labelstring = label;
        X = leftmarg - Image1->Canvas->TextWidth(labelstring);
        Image1->Canvas->TextOut(X,Y,labelstring);
        corstep = corstep - 0.1;
    }

    // Make legend axis on bottom
    X = leftmarg;
    Y = botmarg;
    Image1->Canvas->MoveTo(X,Y);
    X = rightmarg;
    Image1->Canvas->LineTo(X,Y);
    for (int i = 0; i < npoints+1; i++)
    {
        X = leftmarg + (xincrement * i);
        labelstring = "|";
        Image1->Canvas->TextOut(X,Y,labelstring);
        labelstring = (i);
        Y = Y + 5;
        if (i % 2) Image1->Canvas->TextOut(X,Y,labelstring);
        Y = botmarg;
    }
    labelstring = "LAG VALUE";
    X = (leftmarg + horizlong / 2) - (Image1->Canvas->TextWidth(labelstring) / 2);
    Y = botmarg + Image1->Canvas->TextHeight(labelstring);
    Image1->Canvas->TextOut(X,Y,labelstring);

    // Plot lines from correlation to correlation
    Image1->Canvas->Pen->Color = clRed;
    for (int i = 0; i < npoints; i++)
    {
        yprop = (1.0 - correlations[i]) / 2.0;
        scaley = yprop * verthi;
        X = leftmarg + (xincrement * i);
        Y = topmarg + scaley;
        if (i == 0) Image1->Canvas->MoveTo(X,Y);
        else Image1->Canvas->LineTo(X,Y);
        Image1->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
    }

    // Plot partial correlations
    if (PlotPartCors)
    {
       Image1->Canvas->Pen->Color = clBlue;
       for (int i = 0; i < npoints; i++)
       {
         yprop = (1.0 - partcors[i]) / 2.0;
         scaley = yprop * verthi;
         X = leftmarg + (xincrement * i);
         Y = topmarg + scaley;
         if (i == 0) Image1->Canvas->MoveTo(X,Y);
         else Image1->Canvas->LineTo(X,Y);
         Image1->Canvas->Ellipse(X-3,Y-3,X+3,Y+3);
       }
    }

    // Plot lines for upper and lower 95% confidence levels
    if (PlotLimits)
    {
       Image1->Canvas->Pen->Color = clGreen;
       yprop = (1.0 - uplimit) / 2.0;
       scaley = yprop * verthi;
       Y = topmarg + scaley;
       Image1->Canvas->MoveTo(leftmarg,Y);
       X = rightmarg;
       Image1->Canvas->LineTo(X,Y);
       yprop = (1.0 - lowlimit) / 2.0;
       scaley = yprop * verthi;
       Y = topmarg + scaley;
       Image1->Canvas->MoveTo(leftmarg,Y);
       X = rightmarg;
       Image1->Canvas->LineTo(X,Y);
    }

    // Show legend at right
    X = rightmarg;
    labelstring = "Correlations";
    labelheight = Image1->Canvas->TextHeight(labelstring);
    Y = 5 * labelheight;
    Image1->Canvas->Font->Color = clRed;
    Image1->Canvas->TextOut(X,Y,labelstring);
    labelstring = "Partials";
    Y = 6 * labelheight;
    Image1->Canvas->Font->Color = clBlue;
    Image1->Canvas->TextOut(X,Y,labelstring);
    Y = 7 * labelheight;
    labelstring = "95% C.I.";
    Image1->Canvas->Font->Color = clGreen;
    Image1->Canvas->TextOut(X,Y,labelstring);
}
//----------------------------------------------------------------------------

void __fastcall TAutoPlotFrm::FormShow(TObject *Sender)
{
    AutoPlot();
}
//---------------------------------------------------------------------------

void __fastcall TAutoPlotFrm::FormPaint(TObject *Sender)
{
//    AutoPlot();    
}
//---------------------------------------------------------------------------

void __fastcall TAutoPlotFrm::FormResize(TObject *Sender)
{
    AutoPlot();    
}
//---------------------------------------------------------------------------

