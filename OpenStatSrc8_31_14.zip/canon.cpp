//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "canon.h"
#include "canvars.h"
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "output.h"
#include "functions.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include <vcl\Dialogs.hpp>
#include <stdio.h>
#include <math.h>
#include <exception>
//---------------------------------------------------------------------------
#pragma package(smart_init)
extern long int NoCases;
extern long int NoVariables;
extern bool FilterOn;
extern long int FilterCol;
extern int FileType;
int canon()
{
     extern bool Allocated;

     AnsiString cellstring, gridstring;
     bool errorcode = false;
     char outline[121];
     int result, intvalue;
     int count = 0, a_size=0, b_size=0, k=0, no_factors=0, novars=0;
     int prtopts, IER, i, j;
     double dblvalue;
     double s, m, n, df1, df2, q, w, pcnt_extracted=0.0, trace=0.0;
     double minroot=0.0, critical_prob=0.0, Lambda = 1.0, Pillia = 0.0;
     double chisqr = 0.0, HLTrace = 0.0, chiprob = 0.0, ftestprob;
     double Roys, f, Hroot;
     AnsiString strvalue;

    FrmCanonical->LstVars->Clear();
    FrmCanonical->LstLeftVars->Clear();
    FrmCanonical->LstRightVars->Clear();
    for (i = 1; i <= NoVariables; i++) //load variables in list
    {
        AnsiString cellstring = MainForm->Grid->Cells[i][0];
        FrmCanonical->LstVars->Items->Add(cellstring);
    }
    FrmCanonical->ShowModal();
    if (FrmCanonical->ModalResult== mrCancel) return 0;

    // Get size of the Left and Right matrices (predictors and dependents)
    a_size = 0;
    b_size = 0;
    a_size = FrmCanonical->LstLeftVars->Items->Count; // independent var.s
    b_size = FrmCanonical->LstRightVars->Items->Count; // dependent var.s
    if ((a_size == 0) || (b_size == 0))
    {
        ShowMessage("ERROR!  Variables must be selected for both sides.");
        return (0);
    }
    if (a_size < b_size)
    {
       Application->MessageBox("No. of dependent variables should be less than or equal to independent variables.","REVERSED?",MB_OK);
       return 0;
    }
    novars = a_size + b_size;

     matrix raa = NULL;
     GetDblMatMem(raa,a_size,a_size);
     matrix rbb = NULL;
     GetDblMatMem(rbb,b_size,b_size);
     matrix rab = NULL;
     GetDblMatMem(rab,a_size,b_size);
     matrix rba=NULL;
     GetDblMatMem(rba,b_size,a_size);
     matrix bigmat=NULL;
     GetDblMatMem(bigmat,novars,novars);
     matrix first_prod=NULL;
     GetDblMatMem(first_prod,novars,novars);
     matrix second_prod=NULL;
     GetDblMatMem(second_prod,novars,novars);
     matrix char_equation=NULL;
     GetDblMatMem(char_equation,novars,novars);
     matrix raainv=NULL;
     GetDblMatMem(raainv,a_size,a_size);
     matrix rbbinv=NULL;
     GetDblMatMem(rbbinv,b_size,b_size);
     matrix eigenvectors=NULL;
     GetDblMatMem(eigenvectors,novars,novars);
     matrix norm_a=NULL;
     GetDblMatMem(norm_a,novars,novars);
     matrix norm_b=NULL;
     GetDblMatMem(norm_b,novars,novars);
     matrix raw_a=NULL;
     GetDblMatMem(raw_a,novars,novars);
     matrix raw_b=NULL;
     GetDblMatMem(raw_b,novars,novars);
     matrix a_cors=NULL;
     GetDblMatMem(a_cors,a_size,a_size);
     matrix b_cors=NULL;
     GetDblMatMem(b_cors,b_size,b_size);
     matrix eigentrans=NULL;
     GetDblMatMem(eigentrans,novars,novars);
     matrix theta=NULL;
     GetDblMatMem(theta,novars,novars);
     matrix tempmat=NULL;
     GetDblMatMem(tempmat,novars+1,novars+1);
     matrix tempinv=NULL;
     GetDblMatMem(tempinv,novars+1,novars+1);

     vector mean=NULL;
     mean = new double[novars];
     vector variance=NULL;
     variance = new double[novars];
     vector stddev=NULL;
     stddev = new double[novars];
     vector roots=NULL;
     roots = new double[novars];
     vector root_chi=NULL;
     root_chi = new double[novars];
     vector chi_prob=NULL;
     chi_prob = new double[novars];
     vector pv_a=NULL;
     pv_a = new double[a_size];
     vector pv_b=NULL;
     pv_b = new double[b_size];
     vector rd_a=NULL;
     rd_a = new double[a_size];
     vector rd_b=NULL;
     rd_b = new double[b_size];
     vector pcnt_trace=NULL;
     pcnt_trace = new double[novars];

     intvector root_df=NULL;
     root_df = new int[novars];
     intvector a_vars=NULL;
     a_vars = new int[a_size];
     intvector b_vars=NULL;
     b_vars = new int[b_size];
     intvector selected=NULL;
     selected = new int[novars];

     AnsiString * RowLabels=NULL;
     try {
         RowLabels = new AnsiString [novars];
         }
     catch (...){
        Application->MessageBox("Out of Memory","ERROR!",MB_OK);
        exit (-1);
        }
     AnsiString * ColLabels=NULL;
     try {
         ColLabels = new AnsiString [novars];
     }
     catch (...) {
         Application->MessageBox("Out of Memory","ERROR!",MB_OK);
         exit (-1);
     }

     AnsiString *CanLabels = NULL;
     try {
         CanLabels = new AnsiString[NoVariables];
     }
     catch (...) {
         Application->MessageBox("Out of Memory","ERROR!",MB_OK);
         exit (-1);
     }

     AnsiString SNo;

     //------------ WORK STARTS HERE! -------------------------------------

     // Build labels for canonical functions 1 to novars
     for (i = 0; i < b_size; i++)
         CanLabels[i] = "Var. " + AnsiString(i+1);

     // identify variables selected for left and right variables
     for (i = 0; i < a_size; i++) // identify left variables
     {
         cellstring = FrmCanonical->LstLeftVars->Items->Strings[i];
         for (j = 1; j <= NoVariables; j++)
         {
             gridstring = MainForm->Grid->Cells[j][0];
             if (cellstring == gridstring){
                 a_vars[i] = j;
                 RowLabels[i]= MainForm->Grid->Cells[j][0];
             }
         }
     }
     for (i = 0; i < b_size; i++) // identify left variables
     {
         cellstring = FrmCanonical->LstRightVars->Items->Strings[i];
         for (j = 1; j <= NoVariables; j++)
         {
             gridstring = MainForm->Grid->Cells[j][0];
             if (cellstring == gridstring){
                 b_vars[i] = j;
                 ColLabels[i] = MainForm->Grid->Cells[j][0];
             }
         }
     }

     // build list of all variables selected
     for (i = 0; i < a_size; i++) selected[i] = a_vars[i];
     for (i = 0; i < b_size; i++) selected[i+a_size] = b_vars[i];
/*
     // check for correct variable types
     for (i = 0; i < a_size + b_size; i++)
     {
        result = VarTypeChk(selected[i],0);
        if (result == 1) goto cleanup;
     }
*/
     if ((FrmCanonical->BtnDescriptives->Checked)&&
         (FrmCanonical->BtnCorrs->Checked)) prtopts = 1;
     if ((FrmCanonical->BtnDescriptives->Checked)&&
         (!FrmCanonical->BtnCorrs->Checked)) prtopts = 3;
     if ((!FrmCanonical->BtnDescriptives->Checked)&&
         (FrmCanonical->BtnCorrs->Checked)) prtopts = 2;


     FrmOutPut->RichOutPut->Lines->Add("CANONICAL CORRELATION ANALYSIS");
     FrmOutPut->RichOutPut->Lines->Add("");
     count = NoCases;
     if (FileType != 7)
     {
        // Get means, standard deviations, etc. for total matrix
        IER = Correlations(mean, stddev, bigmat, novars, selected, count, 3,
                        false, prtopts);
        if (IER != 0)
        {
            Application->MessageBox("Zero variance found for a variable-terminating","ERROR!",MB_OK);
            goto cleanup;
        }
        if (FrmCanonical->SaveRChkBox->Checked)
        {
            SaveSqrMat(bigmat, novars, NoCases, RowLabels, mean, stddev);
//            SaveRmat(bigmat,novars,NoCases,selected);
        }
     }
     else // correlation matrix was read
     {
        for (i = 0; i < novars; i++)
        {
            mean[i] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][novars+1]));
            stddev[i] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][novars+2]));
            for (j = 0; j < novars; j++)
                bigmat[i][j] = StrToFloat(MainForm->Grid->Cells[i+1][j+1]);
        }
     }
     for (i = 0; i < novars; i++) variance[i] = stddev[i] * stddev[i];

     //partition matrix into quadrants
     for (i = 0; i < a_size; i++)
     {
         for (j = 0; j < a_size; j++) raa[i][j] = bigmat[i][j];
     }

     for (i = a_size; i < novars; i++)
     {
         for (j = a_size; j < novars; j++)
              rbb[i-a_size][j-a_size] = bigmat[i][j];
     }

     for (i = 0; i < a_size; i++)
     {
         for (j = a_size; j < novars; j++)
             rab[i][j-a_size] = bigmat[i][j];
     }
     for (i = a_size; i < novars; i++)
     {
         for (j = 0; j < a_size; j++)
             rba[i-a_size][j] = bigmat[i][j];
     }

     if (FrmCanonical->BtnCorrs->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        MatPrint(raa,a_size,a_size,a_vars,"Left (Independent) Correlation Matrix");
        FrmOutPut->RichOutPut->Lines->Add("");
        MatPrint(rbb,b_size,b_size,b_vars,"Right (Dependent) Correlation Matix");
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(rab,a_size,b_size,"Smaller Size",RowLabels,ColLabels,"Left-Right Correlation Matrix");
//        FrmOutPut->ShowModal();
     }

     // get inverses of left and right hand matrices raa and rbb
     MatOffset(raa,tempmat,a_size);
     matinv(tempmat,a_size,tempinv,eigenvectors,roots);
     MatOnset(raainv,tempinv,a_size);
     if (FrmCanonical->BtnInverses->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        MatPrint(raainv,a_size,a_size,a_vars,"Inverse of Left (a) Variables Matrix");
//        FrmOutPut->ShowModal();
     }
     MatOffset(rbb,tempmat,b_size);
     matinv(tempmat,b_size,tempinv,eigenvectors,roots);
     MatOnset(rbbinv,tempinv,b_size);
     if (FrmCanonical->BtnInverses->Checked)
     {
          FrmOutPut->RichOutPut->Lines->Add("");
          MatPrint(rbbinv,b_size,b_size,b_vars,"Inverse of Right (b) Variables Matrix");
//          FrmOutPut->ShowModal();
     }

     // get products of raainv x rab and the rbbinv x rba matrix
     MATAxB(first_prod,rbbinv,rba,b_size,b_size,b_size,a_size,errorcode);
     MATAxB(second_prod,raainv,rab,a_size,a_size,a_size,b_size,errorcode);
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(first_prod,b_size,a_size," ",ColLabels,RowLabels,"b(Right) Inverse x Rba Matrices");
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(second_prod,a_size,b_size," ",RowLabels,ColLabels,"a (Left) Inverse x Rab Matrices");
//     FrmOutPut->ShowModal();

     //get characteristic equations matrix (product of last two product matrices
     //The product should yeild rows and cols representing the smaller of the two sets
     for (i = 0; i < b_size; i++)
         for (j = 0; j < b_size; j++)
             char_equation[i][j] = 0.0;
     MATAxB(char_equation,first_prod,second_prod,b_size,a_size, a_size,b_size,errorcode);
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(char_equation,b_size,b_size,"Canonical Function",CanLabels,CanLabels,"Characteristic Equations Matrix");
//     FrmOutPut->ShowModal();

     //  now get roots and vectors of the characteristic equation using
     // NonSymRoots routine
     minroot = 0.0;
     for (i = 0; i < b_size; i++)
     {
         roots[i] = 0.0;
         pcnt_trace[i] = 0.0;
         for (j = 0; j < b_size; j++) eigenvectors[i][j] = 0.0;
     }
     trace = 0.0;
     no_factors = b_size;
     nonsymroots(char_equation, b_size, no_factors, minroot, eigenvectors, roots,\
                pcnt_trace, trace, pcnt_extracted);
     sprintf(outline,"Trace of the matrix = %10.4f",trace);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Percent of trace extracted: %10.4f",pcnt_extracted);
     FrmOutPut->RichOutPut->Lines->Add(outline);

     // Normalize smaller set weights and coumpute larger set weights
     MATTRN(eigentrans,eigenvectors,b_size,b_size);
     MATAxB(tempmat,eigentrans,rbb,b_size,b_size,b_size,b_size,errorcode);
     MATAxB(theta,tempmat,eigenvectors,b_size,b_size,b_size,b_size,errorcode);
     for (j = 0; j < b_size; j++)
     {
            q = 1.0 / sqrt(theta[j][j]);
            for (i = 0; i < b_size; i++)
            {
                norm_b[i][j] = eigenvectors[i][j] * q;
                raw_b[i][j] = norm_b[i][j] / stddev[a_size+i];
            }
     }
     MATAxB(norm_a,second_prod,norm_b,a_size,b_size,b_size,b_size,errorcode);
     for (j = 0; j < b_size; j++)
     {
            for (i = 0; i < a_size; i++)
            {
                norm_a[i][j] *= (1.0 / sqrt(roots[j]));
                raw_a[i][j] = norm_a[i][j] / stddev[i];
            }
     }

     // Compute the correlations between variables and canonical variables
     MATAxB(a_cors,raa,norm_a,a_size,a_size,a_size,b_size,errorcode);
     for (j = 0; j < b_size; j++)
     {
         q = 0.0;
         for (i = 0; i < a_size; i++) q = q + norm_a[i][j] * a_cors[i][j];
         q = 1.0 / sqrt(q);
         for (i = 0; i < a_size; i++) a_cors[i][j] *= q;
     }
     MATAxB(b_cors,rbb,norm_b,b_size,b_size,b_size,b_size,errorcode);
     for (j = 0; j < b_size; j++)
     {
         q = 0.0;
         for (i = 0; i < b_size; i++) q += norm_b[i][j] * b_cors[i][j];
         q = 1.0 / sqrt(q);
         for (i = 0; i < b_size; i++) b_cors[i][j] *= q;
     }

     // Compute the Proportions of Variance (PVs) and Redundancy Coefficients
     for (j = 0; j < b_size; j++)
     {
         pv_a[j] = 0.0;
         for (i = 0; i < a_size; i++) pv_a[j] += (a_cors[i][j]*a_cors[i][j]);
         pv_a[j] /= a_size;
         rd_a[j] = pv_a[j] * roots[j];
     }
     for (j = 0; j < b_size; j++)
     {
         pv_b[j] = 0.0;
         for (i = 0; i < b_size; i++) pv_b[j] += (b_cors[i][j]*b_cors[i][j]);
         pv_b[j] /= b_size;
         rd_b[j] = pv_b[j] * roots[j];
     }

     // Compute tests of the roots
     q = a_size + b_size + 1;
     q = -(double(count) - 1.0 - (q / 2.0));
     k = 0;
     for (i = 0; i < b_size; i++)
     {
         w = 1.0;
         for (j = i; j < b_size; j++) w *= (1.0 - roots[j]);
         root_chi[i] = q * log(w);
         root_df[i] = (a_size - i) * (b_size - i);
         chi_prob[i] = 1.0-chisquaredprob(root_chi[i],root_df[i]);
         if (chi_prob[i] < critical_prob) k = k + 1;
     }
     Roys = roots[0] / (1.0 - roots[0]);
     Lambda = 1.0;
     for (i = 0; i < b_size; i++)
     {
         Hroot = roots[i] / (1.0 - roots[i]);
         Lambda *= (1.0 / (1.0 + Hroot));
         Pillia += (Hroot / (1.0 + Hroot));
         HLTrace += Hroot;
     }

     // Print remaining results
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"   Canonical R   Root  % Trace   Chi-Sqr    D.F.    Prob.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 0; i < b_size; i++)
     {
         sprintf(outline,"%2d %10.6f %8.3f %7.3f %8.3f      %2d %8.3f",\
          i+1, sqrt(roots[i]), roots[i], pcnt_trace[i], root_chi[i], root_df[i], chi_prob[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     chisqr = -log(Lambda) * (double(count) - 1.0 - 0.5*(double(a_size + b_size) - 1.0));
     chiprob = 1.0 - chisquaredprob(chisqr,a_size*b_size);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Overall Tests of Significance:");
     FrmOutPut->RichOutPut->Lines->Add("         Statistic      Approx. Stat.   Value   D.F.  Prob.>Value");
     sprintf(outline,"Wilkes Lambda           Chi-Squared %10.4f  %3d   %6.4f", chisqr,a_size*b_size,chiprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     s = double(b_size);
     m = 0.5 * double(a_size - b_size - 1);
     n = 0.5 * double(count - b_size-a_size - 2);
     f = (HLTrace * 2.0 * (s * n + 1)) / (s * s * (2.0 * m + s + 1.0));
     df1 = s * (2.0 * m + s + 1.0);
     df2 = 2.0 * ( s * n  + 1.0);
     ftestprob = ftest(df1,df2,f);
     sprintf(outline,"Hotelling-Lawley Trace  F-Test      %10.4f %2d %2d  %6.4f", f, int(df1),int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     df2 = s * (2.0 * n + s + 1.0);
     f = (Pillia / (s - Pillia)) * ( (2.0 * n + s +1.0) / (2.0 * m + s + 1.0) );
     ftestprob = ftest(df1,df2,f);
     sprintf(outline,"Pillai Trace            F-Test      %10.4f %2d %2d  %6.4f", f, int(df1),int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     Roys *= double(count - 1 - a_size + b_size)/double(a_size);
     df1 = double(a_size);
     df2 = double(count - 1 - a_size + b_size);
     ftestprob = ftest(df1,df2,Roys);
     sprintf(outline,"Roy's Largest Root      F-Test      %10.4f %2d %2d  %6.4f", Roys, int(df1), int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
//     FrmOutPut->ShowModal();

     if (FrmCanonical->BtnRootsVectors->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(eigenvectors,b_size,b_size,"Eigenvectors",CanLabels,CanLabels,"Eigenvectors in Columns");
//        FrmOutPut->ShowModal();
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(norm_a,a_size,b_size,"Weights",RowLabels,CanLabels,"Standardized Left Side (Independent )Weights");
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(norm_b,b_size,b_size,"Weights",ColLabels,CanLabels,"Standardized Right Side (Dependent) Weights");
//     FrmOutPut->ShowModal();

     if (FrmCanonical->BtnRawCoeffs->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(raw_a,a_size,b_size,"Weights",RowLabels,CanLabels,"Raw Left Side Weights");
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(raw_b,b_size,b_size,"Weights",ColLabels,CanLabels,"Raw Right Side Weights");
//        FrmOutPut->ShowModal();
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(a_cors,a_size,b_size,"Canonical Variables",RowLabels,CanLabels,"Left Side (Independent) Correlations with Function");
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(b_cors,b_size,b_size,"Canonical Variables",ColLabels,CanLabels,"Right Side (Dependent) Correlations with Function");
//     FrmOutPut->ShowModal();

     if (FrmCanonical->BtnRedundency->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Redundancy Analysis for Left Side Variables");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Function    Variance Prop.    Redundancy");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (i = 0; i < b_size; i++)
        {
             sprintf(outline,"%10d %10.5f     %10.5f",i+1,pv_a[i],rd_a[i]);
             FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Redundancy Analysis for Right Side Variables");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Function    Variance Prop.    Redundancy");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (i = 0; i < b_size; i++)
        {
            sprintf(outline,"%10d %10.5f     %10.5f",i+1,pv_b[i],rd_b[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
     }

     //------------- Now, clean up memory mess ----------------------------
cleanup:
     delete[] CanLabels;
     delete[] ColLabels;
     delete[] RowLabels;

     delete[] selected;
     delete[] b_vars;
     delete[] a_vars;
     delete[] root_df;

     delete[] pcnt_trace;
     delete[] rd_b;
     delete[] rd_a;
     delete[] pv_b;
     delete[] pv_a;
     delete[] chi_prob;
     delete[] root_chi;
     delete[] roots;
     delete[] stddev;
     delete[] variance;
     delete[] mean;

     ClearDblMatMem(tempinv,novars+1);
     ClearDblMatMem(tempmat,novars+1);
     ClearDblMatMem(theta,novars);
     ClearDblMatMem(eigentrans,novars);
     ClearDblMatMem(b_cors,b_size);
     ClearDblMatMem(a_cors,a_size);
     ClearDblMatMem(raw_b,novars);
     ClearDblMatMem(raw_a,novars);
     ClearDblMatMem(norm_b,novars);
     ClearDblMatMem(norm_a,novars);
     ClearDblMatMem(eigenvectors,novars);
     ClearDblMatMem(rbbinv,b_size);
     ClearDblMatMem(raainv,a_size);
     ClearDblMatMem(char_equation,novars);
     ClearDblMatMem(second_prod,novars);
     ClearDblMatMem(first_prod,novars);
     ClearDblMatMem(bigmat,novars);
     ClearDblMatMem(rba,b_size);
     ClearDblMatMem(rab,a_size);
     ClearDblMatMem(rbb,b_size);
     ClearDblMatMem(raa,a_size);
     return 1;
}

//-------------------------------------------------------------------


