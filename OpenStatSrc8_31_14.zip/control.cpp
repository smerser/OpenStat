/******************************************************************************/
/*                                                                            */
/*  CONTROL - Routines related to processing user's control commands          */
/*                                                                            */
/* Copyright (c) 1993 by Academic Press, Inc.                                 */
/*                                                                            */
/* All rights reserved.  Permission is hereby granted, until further notice,  */
/* to make copies of this diskette, which are not for resale, provided these  */
/* copies are made from this master diskette only, and provided that the      */
/* following copyright notice appears on the diskette label:                  */
/* (c) 1993 by Academic Press, Inc.                                           */
/*                                                                            */
/* Except as previously stated, no part of the computer program embodied in   */
/* this diskette may be reproduced or transmitted in any form or by any means,*/
/* electronic or mechanical, including input into storage in any information  */
/* system for resale, without permission in writing from the publisher.       */
/*                                                                            */
/* Produced in the United States of America.                                  */
/*                                                                            */
/* ISBN 0-12-479041-0                                                         */
/*                                                                            */
/******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include "funcdefs.h"    // Function prototypes
#include "NeuralMainUnit.h"
#include "OutPut.h"

#define IM 714025L      // These constants are from Press et. al.
#define IA 1366L        // "Numerical Recipes in C"
#define IC 150889L      // Do not tamper with them unless you are an expert
#define TABLE_LENGTH 97 // Length of shuffle table

static long seed = 797 ;           // Keep the current seed here
static long randout ;              // Random output
static long table[TABLE_LENGTH] ;  // Keep shuffle table here
static int table_initialized = 0 ; // Has it been initialized?
static double f_factor, f_f[LTAB_LENGTH], f_d[LTAB_LENGTH] ;

/*
--------------------------------------------------------------------------------

   Prototypes for local routines

--------------------------------------------------------------------------------
*/

static void remove_comments ( char *str ) ;
static void remove_leading_blanks ( char **str ) ;
static void remove_trailing_blanks ( char *str ) ;

/*
--------------------------------------------------------------------------------

   split_control_line - This splits the control line into the command part
      and the parameter part.  It replaces the colon (which terminates the
      command) with a 0, and returns a pointer to the rest of the line.
      It also returns a pointer to the command part of the line, which will
      not be the input line if it started with blanks.  The command part is
      converted to upper case.
      Note that no actual copies are made.  The returned string pointers
      simply point to parts of the input line, which is modified as needed.
      If the input line did not contain a colon, but had characters not
      attributable to comments, n_command is returned 0 and rest returns
      the line.

--------------------------------------------------------------------------------
*/

void split_control_line (
   char *line ,     // Control line input here
   char **command , // Returned pointer to command part
   int *n_command , // Length of command part
   char **rest ,    // Returned pointer to parameter part
   int *n_rest      // Length of parameter part
   )
{
   int i, n ;

   remove_leading_blanks ( &line ) ;
   remove_comments ( line ) ;

   n = strlen ( line ) ;
   for (i=0 ; i<n ; i++) {
      if (line[i] == ':') {                 // Colon terminates command part
         line[i] = 0 ;                      // so terminate this substring
         remove_trailing_blanks ( line ) ;  // Blanks may preceed colon
         *command = line ;                  // Return pointer to command part
         *n_command = strlen ( *command ) ; // and its length
         *command = StrUpper( *command ) ;          // Return it upper case
         *rest = line + i + 1 ;             // This is the parameter part
         remove_leading_blanks ( rest ) ;   // which may have leading blanks
         *rest = StrUpper( *rest ) ;             // Return it upper case
         *n_rest = strlen ( *rest ) ;       // Return its length
         return ;                           // Normal return here
         }
      }

   *n_command = 0 ;  // Error if we get here
   *rest = *command = line ;
   *n_rest = strlen ( line ) ;
}

/*
--------------------------------------------------------------------------------

      get_control_line - Read a control line from a file or stdin

--------------------------------------------------------------------------------
*/

void get_control_line (
   char *control_line ,       // Control line returned here
   int *control_file_number , // Stack pointer for control files (-1 = none)
   FILE *control_files[]      // Stack of file pointers to control files
   )
{
   int n ;

   *control_line = 0 ;   // Always clear any old command in it

   while (*control_file_number >= 0) {  // First priority is control files

      if (fgets ( control_line , CONTROL_LINE_LENGTH ,
                  control_files[*control_file_number] ) == NULL ) { // EOF?
         fclose ( control_files[*control_file_number] ) ; // If so, close it
         --*control_file_number ;                      // and pop it from stack
         continue ;
         }

      n = strlen ( control_line ) ;    // fgets returns the newline at end
      if (control_line[n-1] == '\n')   // so we must remove it
         control_line[--n] = 0 ;       // Using an 'if' is good style

      if (n)                           // It may be that it was a null line
         return ;
      }

   FrmOutPut->RichOutPut->Lines->Add( "No Control File (QUIT:) " ) ;  // No control files
   control_line = "QUIT:" ;             // so read from stdin
}

/*
--------------------------------------------------------------------------------

   stack_control_file - Process a CONTROL command by opening, stacking the file 

--------------------------------------------------------------------------------
*/

void stack_control_file (
   char *filename ,           // Full path name of new control file
   int *control_file_number , // Input of current stack position, output inc'd
   FILE *control_files[]      // Stack of file pointers to control files
   )
{
   FILE *fp ;

   if (*control_file_number >= MAX_CONTROL_FILES-1) {
      printf ( "\nERROR... Too many nested control files.  Max is %d.",
               MAX_CONTROL_FILES ) ;
      return ;
      }

   fp = fopen ( filename , "rt" ) ;

   if (fp == NULL) {
      printf ( "\nERROR... Cannot open %s.", filename ) ;
      return ;
      }

   control_files[++*control_file_number] = fp ;
}

/*
--------------------------------------------------------------------------------

   Local utility routines

--------------------------------------------------------------------------------
*/

static void remove_leading_blanks ( char **str )
{
   while (**str == ' ')
      ++*str ;
}

static void remove_trailing_blanks ( char *str )
{
   int n = strlen ( str ) ;
   while (n--) {
      if (str[n] == ' ')
         str[n] = 0 ;
      else
         break ;
      }
}

static void remove_comments ( char *str )
{
   int i, n ;
   n = strlen ( str ) ;
   for (i=0 ; i<n ; i++) {
      if (str[i] == ';') {
         str[i] = 0 ;
         while (i--) {
            if (str[i] == ' ')
               str[i] = 0 ;
            else
               return ;
            }
         }
      }
}


/*
   This routine is a major eater of time, so it should be made
   as efficient as possible.  Fanatics will code it in assembler.

   The summation loop in this version is opened into groups of
   four.  This saves much overhead in loop counting.  Even more
   important, it avoids breaking the pipeline in RISC and other 
   processors which count on pipelines for speed. 

   Note that we use *(vec1+1) et cetera here.  This is for the 
   benefit of 386 family processors which can include a constant
   address offset in instructions.  Other processors may benefit
   from incrementing each time: *vec1++ et cetera. 
*/
     
double dotprod (
   int n ,         // Length of vectors
   double *vec1 ,  // One of the vectors to be dotted
   double *vec2 )  // The other vector
{
   int k, m ;
   double sum ;

   sum = 0.0 ;  // Will cumulate dot product here
   k = n / 4 ;  // Divide vector into this many groups of 4
   m = n % 4 ;  // This is the remainder of that division

   while (k--) {    // Do each group of 4
      sum += *vec1 * *vec2 ;
      sum += *(vec1+1) * *(vec2+1) ;
      sum += *(vec1+2) * *(vec2+2) ;
      sum += *(vec1+3) * *(vec2+3) ;
      vec1 += 4 ;
      vec2 += 4 ;
      }

   while (m--)      // Do the remainder
      sum += *vec1++ * *vec2++ ;

   return sum ;
}


void error_message ( char *msg )
{
     FrmOutPut->RichOutPut->Lines->Add(msg);
//   printf ( "\nERROR: %s", msg ) ;
}

void warning_message ( char *msg )
{
     FrmOutPut->RichOutPut->Lines->Add(msg);
//   printf ( "\nWARNING: %s", msg ) ;
}

void normal_message ( char *msg )
{
     FrmOutPut->RichOutPut->Lines->Add(msg);
//   printf ( "\n%s", msg ) ;
}

void progress_message ( char *msg )
{
     FrmOutPut->RichOutPut->Lines->Add(msg);
//   printf ( "%s", msg ) ;
}

void memory_message ( char *msg )
{
     FrmOutPut->RichOutPut->Lines->Add(msg);
//   printf ( "\nInsufficient memory %s", msg ) ;
}

void str_to_upr ( char *str )
{
   char *ptr = str-1;
   while (*++ptr)
      *ptr = toupper ( *ptr ) ;
}

double veclen ( int n , double *v )
{
   double sum = 0.0 ;
   while (n--)
      sum += v[n] * v[n] ;
   return sum ;
}


void shake ( int nvars , double *center , double *x , double temp )
{
   double r ;
/*  SHAKE - Randomly perturb a point
   Recall that the variance of a uniform deviate on 0-1 is 1/12.
   Adding four such random variables multiplies the variance by 4,
   while dividing by 2 divides the variance by 4.
*/

   temp *= 3.464101615 / (2. * longrandmax () ) ; // SQRT(12)=3.464...

   while (nvars--) {
      r = (double) longrand() + (double) longrand() -
          (double) longrand() - (double) longrand() ;
      *x++ = *center++ + temp * r ;
      }
}

double ParseDouble ( char **str )
{
   double num ;

   while (! (isdigit ( **str )  ||  (**str == '-')  ||  (**str == '.'))) {
      if (**str)
         ++(*str) ;
      else
         return 0. ;
      }

   num = atof ( *str ) ;

   while ((isdigit ( **str )  ||  (**str == '-')  ||  (**str == '.')))
      ++(*str) ;

   return num ;
}


/*  Set the random seed */
void slongrand ( long iseed )
{
   seed = iseed ;          // We keep the static seed here
   table_initialized = 0 ; // Must also rebuild table with it!
}

/*  Return the maximum random number */
long longrandmax ()
{
   return IM - 1L ;
}

/*  This is the actual random number generator */
long longrand ()     // Return the next random number
{
   int i ;

   if (! table_initialized) {  // Initialize shuffle table before use
      table_initialized = 1 ;  // Flag to avoid more inits
      for (i=0 ; i<TABLE_LENGTH ; i++) { // Fill entire table
         seed = (IA * seed + IC) % IM ;  // Make a random number
         table[i] = seed ;               // Put it in the table
         }
      seed = (IA * seed + IC) % IM ;     // One more random number
      randout = seed ;                   // for upcoming first use
      }

   i = (int) ((double) TABLE_LENGTH * (double) randout / (double) IM) ;
   randout = table[i] ;            // This output comes from table
   seed = (IA * seed + IC) % IM ;  // Make new random number
   table[i] = seed ;               // to replace used entry
   return randout ;                // then return old entry
}

double unifrand ()
{
   return (double) longrand () / (double) IM ;
}

/*  ACT_FUNC - Compute the activation function                                */
/*  This also contains the routine actderiv which computes the derivative.    */
/*
   This uses a piecewise linear approximation.  The routine
   'act_func_init' must be called before the 'act_func' function
   in order to initialize the interpolation table.
*/

void act_func_init ()
{
   int i ;

   f_factor = (double) (LTAB_LENGTH - 1) / (double) LTAB_MAX ;
   for (i=0 ; i<LTAB_LENGTH ; i++) {
      f_f[i] = 1.0 / (1.0 + exp ( - ((double) i) / f_factor )) ;
      if (i)
         f_d[i-1] = f_f[i] - f_f[i-1] ;
      }
}

double act_func ( double x )
{
   int i ;
   double xd ;

   if (x >= 0.0) {                   // One symmetric half
      xd = x * f_factor ;            // Find location in table
      i = (int) xd ;                 // Subscript in table
      if (i >= (LTAB_LENGTH - 1))    // If outside table
         return f_f[LTAB_LENGTH-1] ; // hold at highest entry
      return f_f[i] + f_d[i] * (xd - i) ; // Else interpolate
      }

   else {                            // Other symmetric half
      xd = -x * f_factor ;
      i = (int) xd ;
      if (i >= (LTAB_LENGTH - 1))
         return 1.0 - f_f[LTAB_LENGTH-1] ;
      return 1.0 - (f_f[i] + f_d[i] * (xd - i)) ;
      }
}

/*
   ACTDERIV - Compute the derivative of the activation function.
   Note that it is written as a function of the output activation,
   f(net), rather than net itself.
   This is all that is needed for the logistic activation function.
   If the user tries other functions, appropriate reparameterization
   must be done.  To make this dependent on the net would
   necessitate storing the nets, which is otherwise unnecessary.
*/

double actderiv ( double f )
{
   return f * (1.0 - f) ;   // Logistic derivative
}

/*
   INVERSE_ACT - Compute the inverse of the activation function.
*/

double inverse_act ( double f )
{
   return -log ( 1.0 / f - 1.0 ) ; // Inverse logistic function
}

/*  ACTIVITY - Evaluate the activity of a single LayerNet neuron              */
double activity ( double *input , double *coefs , int n )
{
   double sum ;

   sum = dotprod ( n , input , coefs ) ;
   sum += coefs[n] ;      // Bias term

   return act_func ( sum ) ;
}

