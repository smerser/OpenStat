//---------------------------------------------------------------------------

#ifndef AlscaleUnitH
#define AlscaleUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAlscaleForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *Return;
     TLabel *Label1;
     TEdit *FileNameEdit;
     TGroupBox *DimensionsGrp;
     TLabel *Label2;
     TLabel *Label3;
     TLabel *Label4;
     TEdit *NRowsEdit;
     TEdit *NColsEdit;
     TEdit *NMatricesEdit;
     TRadioGroup *MeasLevelGrp;
     TRadioGroup *DataFormGrp;
     TRadioGroup *MeasProcGrp;
     TRadioGroup *MeasCondGrp;
     TGroupBox *DegPolyGrp;
     TLabel *Label5;
     TEdit *DegPolyEdit;
     TGroupBox *MaxOrdGrp;
     TLabel *Label6;
     TEdit *MaxCatsEdit;
     TGroupBox *GroupBox1;
     TLabel *Label7;
     TEdit *CutoffEdit;
     TRadioGroup *AnalysisGrp;
     TGroupBox *SolutionGrp;
     TLabel *Label8;
     TLabel *Label9;
     TLabel *Label10;
     TLabel *Label11;
     TLabel *Label12;
     TLabel *Label13;
     TLabel *Label14;
     TEdit *MaxSolEdit;
     TEdit *MinSolEdit;
     TEdit *WghtConstrainedEdit;
     TEdit *MaxItersEdit;
     TEdit *ConvergeEdit;
     TEdit *MinStressEdit;
     TEdit *NoDirectsEdit;
     TGroupBox *OptionsGrp;
     TCheckBox *PlotChk;
     TCheckBox *Plot2Chk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
      bool EXIST;
      bool **XCEED;
      int PRSIZE, MAXSIZ, IONUMS, IN1, NPLT, LOUT, NDP, NDQ, NDR, NDPP, INDATA;
      char BLANK, CCC[101];
      int NROW, NCOL, NS, NDTYP, NSIM, NPS, NWC, NDEG, NDMX, DEBUG, ICNSTR, NOULB;
      double CUT, STMIN, STMIND, BIG, EPSID, EPSI, AX, BIGDif, SMLSUM, SUM, Dif;
      int MAXITD, NWE, NDIM, NDMN, NNC, MAXIT, NDIR, MAXSIZE, NDMAX;
      int JX, JWA, JWD, JXX, JDS, JCFR, LCFR, JCFL, JW, JWS, JZZ, JU11, JU12, JU22;
      int JUB1, JUB2, JXN, JTR, JFK, JCV, LCV, JCW, JPHSUB, JPHSTI, JNDSR;
      int JNAD, JIX, JIY, JIZ, JFTLN, JDIST, JPIJP, JXK, NWORDS, NA, IMI, MISALL;
      int NB, ND, NP, NDXP, NT, NAB, NX, I1, NN, NDT, L, N, FMR, IFLXER;
      int NC2, NTEMP1, NTEMP2, LXER, NPARM, INITX, INITXC, INITW, INITWS, I2, I3;
      int NSC, NDXS, NBS, NC, NDX, NBNBNS, MAXDIM, IFLPDS, NCST, NPT, IM1, NCOLP1;
      int IA, IB, IC, ID, J1, IER;
      double *AREA;
      double **DS, **XX, ***WA, *X, **A, **XTX, **XTXK, **CK, **WK, *WC, *WD;
      double ALPH1, TRAN, SUMSQ, STRSS, STRSS2;
      int *IX, **NAD, *IZ, *IY;

      void __fastcall STEP4(double *X, double *WC, double **DISP,
                double **CFL, double **W, double *TR, double **WS,
                double **DIST, double **DUMMY, double **PIJP, double **XK,
                double *ROW, int IJKL);

      void __fastcall DISTP(double **W, double **CFL, double *X,
         double *WC, double *WD, int *IX, int *IY, int *IZ, double *XX,
         int **NDSR, double **WS, int **NAD);
      void __fastcall PRS(int *IR, int *IBK, double *D, int N,
               double *W, int *IZ, int L);
      void __fastcall SES(int *IR, int *IBK, double *D,int N, int *IZ, int L);
      void __fastcall TRS(double *DISP, double *DIST, int *IVEC, int NELE);
      void __fastcall LENGTH(double *DIST, double *DISP, int N);
      void __fastcall DRIVER(double *AREA, bool EOJ);
      void __fastcall STEP1(int *IX, double *X, double ***WA, double **XX,
                      double **DS, int **NAD, int IER);
      void __fastcall CATSES(double *WA, double *WC, int *IDY, int N,
                double *CIV, int NCAT);
      void __fastcall POLYF(double *DISP, double *DIST, int N,
                double *OBS, double **R, double *ALPH, int NDEG, int NCST, int NAB);
      void __fastcall BLOC2(double *A,int *LL, int IZ, int N);
      void __fastcall COEF(double **U11, double **U12, double **U22,
                 double *UB1, double *UB2, int NDIM, double **CFL, int M,
                 double *XN, int NB, int NDX);
      void __fastcall INNER(double **CFL, double **W, double *X,
                double **WB, double **U11, double **U12, double **U22,
                double *UB1, double *UB2, double *XN, int NB, int NDIM,
                int NS, int NDX, int NBS,double **WS);

      void __fastcall MSTRS(int N, double *DISP, double *DIST, double STRSS1, double RESID);
      void __fastcall ARNGE(double **W, double **X, double **WS, int NB,
                 int NS, int NDIM, double *TR);
      void __fastcall NORMW(double **W, int N, int ND,double PHI,double *PHIROW, int ICONFL);
      void __fastcall NORMX(double **X, double **W, int NB, int NS, int ND, int NWE);
      void __fastcall CJEIG(double **A, double **U,double **V,int N,
                int ND,double **B, double **W, double *ALAM, int NFT, int NB);
      void __fastcall SHEL9(double *A, int *C, int NITEM);
      void __fastcall LINT(double *DISP, double *DIST, int N, double *OBS);
      void __fastcall OUTS(double *X, int NB, int NS, int NC, double **XX);
      void __fastcall OUTA(double *X, int NB, int NFL);
      void __fastcall SCUBE(double P, double Q, double R, double CUBE);
      void __fastcall PDWGHT(double **A, double **X, double **D,
           double **O, int N, int R, double **PIJP, int P,int Q, bool IFL, double DELTA);
      void __fastcall PDINWT(double **X, double **O, double **XK,
               double **A, double **B, int N, int R, int T, double *ROW,
               double **XTX, double **XTXK, bool IFL);
      void __fastcall PDSCAL(double **A, double **X, double **O,
            double **D,int N, int R, int T, bool IFL, int IOUT, int ITMAX, double CRIT,
            double **PIJP, double SUMSQ, bool **XCEED, bool IFULL);
      void __fastcall EIGK(double **A, double *VALUE, int N, int NA);
      void __fastcall PDDIST(double **X, double **A, int N, int R, int T, double **D);
      void __fastcall PDDISP(double **O, int N, bool ISIM, bool IFL, double SUMSQ);
      void __fastcall MINV(double **A1, int N, int NA);
      void __fastcall PDSTRS(double **O, double **D, int N,
                             bool IFL, double STRESS, double RSQ);
      void __fastcall PDYUNG(double **CK, double **WK, double **XK,
                             double **X, int N, int R, int T, double *ROOTS);
      void __fastcall PDMAIN(double **X, double **O, int N, int R,
          int T,int ISUB, int ISYM,int IPLOT, int IOUT,double **D,
          double **UK, double **PIJP, double **XK, double *ROW);
      void __fastcall PDOUTY(double **CK, double **WK, double **XK,
                             int N, int R, int T, int ISUB, int IOUT);
      void __fastcall PDOUTT(double **WK,double **UK, int N, int R,int ISUB, int IOUT);
      void __fastcall PDPLOT(double **XK, int N, int T, int IOUT, int NMAX);
      void __fastcall PDTUCK(double **WK, double **X, double **UK, int N,int R);
      double F(double X, double P, double Q, double R);
      double SIGN(double A, double B);
      double AMIN1(double A, double B, double C);
      double AMAX1(double A, double B, double C);
      void __fastcall INSWM(double **DS,double **CFL, double **CFR,
          double **WS, double **XX, double *TR, double *CV, double *CW,
          double **FK, double **ZZ, double ***C, int NADCT, int NB,
          int NDIM, int ND, int NDX, int NDXP, int NS);
      void __fastcall INIT(double **W, double **CFL, double **CFR,
            int NB, int NS, int ND, double **XX, double ***WA, double *TR,
            double **FK, double ***C, double **XEQ, double **AM, double **WS,
            int NDX, int NDXP);
      
public:		// User declarations
     __fastcall TAlscaleForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAlscaleForm *AlscaleForm;
//---------------------------------------------------------------------------
#endif
