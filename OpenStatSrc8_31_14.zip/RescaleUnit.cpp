//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "OutPut.h"
#include "RescaleUnit.h"
#include <stdio.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRescaleForm *RescaleForm;
//---------------------------------------------------------------------------
__fastcall TRescaleForm::TRescaleForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRescaleForm::FileOpenBtnClick(TObject *Sender)
{
     OpenDialog1->DefaultExt = "txt";
     OpenDialog1->Filter = "Text files (*.txt)|*.TXT|All files (*.*)|*.*";
     OpenDialog1->FilterIndex = 1;
     if (OpenDialog1->Execute()) OutFileEdit->Text = OpenDialog1->FileName;
}
//---------------------------------------------------------------------------
void __fastcall TRescaleForm::ComputeBtnClick(TObject *Sender)
{
     double amin, vmin, r, V, A;
     AnsiString filename;
     FILE * txtfile;
     char astring[20];
     char valuestr[20];
     char printline[81];
     AnsiString msg;
     int i = 1;
     
     FrmOutPut->RichOutPut->Clear();
     amin = StrToFloat(RescaleForm->AminEdit->Text);
     vmin = StrToFloat(RescaleForm->VminEdit->Text);
     r = StrToFloat(RescaleForm->rEdit->Text);
     filename = RescaleForm->OutFileEdit->Text;
     txtfile = fopen(filename.c_str(),"r");
     while (!feof(txtfile))
     {
           fgets(astring,21,txtfile); // and remove trailing end-of-line
           for (int i=0; i < strlen(astring)-1; i++) valuestr[i] = astring[i];
           A = atof(valuestr);
           V = A / r + (vmin - amin / r);
           sprintf(printline,"%5d   A = %10.5f,  V = %10.5f",i,A,V);
           msg = printline;
           FrmOutPut->RichOutPut->Lines->Add(msg);
           i += 1;
     }
     fclose(txtfile);
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------
