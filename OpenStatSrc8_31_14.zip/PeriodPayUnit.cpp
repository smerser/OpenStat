//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PeriodPayUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPeriodPayForm *PeriodPayForm;
//---------------------------------------------------------------------------
__fastcall TPeriodPayForm::TPeriodPayForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPeriodPayForm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    PaymentEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0";         
    PeriodEdit->Text = "";     
}
//---------------------------------------------------------------------------
void __fastcall TPeriodPayForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TPeriodPayForm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Pay, PresentValue, FutureVal;
     int NPeriods, Period, When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentEdit->Text);
     NPeriods = StrToInt(NPeriodsEdit->Text);
     Period = StrToInt(PeriodEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     FutureVal = StrToFloat(FutureEdit->Text);
     Pay = PeriodPayment(Rate, Period, NPeriods, PresentValue, FutureVal, Time);
     PaymentEdit->Text = FloatToStr(Pay);
}
//---------------------------------------------------------------------------
