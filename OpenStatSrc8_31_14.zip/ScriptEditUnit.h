//---------------------------------------------------------------------------

#ifndef ScriptEditUnitH
#define ScriptEditUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <FileCtrl.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFrmScriptEditor : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TEdit *ScriptFileEdit;
     TListBox *ScriptList;
     TLabel *Label2;
     TRadioGroup *EditOptions;
     TDirectoryListBox *DirectoryListBox1;
     TFileListBox *FileListBox1;
     TLabel *Label3;
     TLabel *Label4;
     TButton *SaveBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TSaveDialog *SaveDialog1;
     TOpenDialog *OpenDialog1;
     TLabel *EditLabel;
     TEdit *LineEdit;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall SaveBtnClick(TObject *Sender);
     void __fastcall EditOptionsClick(TObject *Sender);
     void __fastcall ScriptListClick(TObject *Sender);
     void __fastcall LineEditKeyPress(TObject *Sender, char &Key);
     void __fastcall DirectoryListBox1Change(TObject *Sender);
     void __fastcall FileListBox1Click(TObject *Sender);
private:	// User declarations
    int EditOption;
    int index;

public:		// User declarations
     __fastcall TFrmScriptEditor(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmScriptEditor *FrmScriptEditor;
//---------------------------------------------------------------------------
#endif
