//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "InterestPayUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TInterestPayForm *InterestPayForm;
//---------------------------------------------------------------------------
__fastcall TInterestPayForm::TInterestPayForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TInterestPayForm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    PeriodEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0";
    InterestEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TInterestPayForm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TInterestPayForm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Payment, PresentValue, FutureVal, Interest;
     int Period, NPeriods, When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentEdit->Text);
     FutureVal = StrToFloat(FutureEdit->Text);
     Period = StrToInt(PeriodEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     NPeriods = StrToInt(NPeriodsEdit->Text);
     Interest = InterestPayment(Rate, Period, NPeriods, PresentValue, FutureVal, Time);
     InterestEdit->Text = FloatToStr(Interest);
}
//---------------------------------------------------------------------------
