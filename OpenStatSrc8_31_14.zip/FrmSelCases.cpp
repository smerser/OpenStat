//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FrmSelCases.h"
#include "FrmSelIf.h"
#include "FrmSelRndm.h"
#include "FrmSelRange.h"
#include "MainUnit.h"

extern int NoVariables;
extern bool FilterOn;
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TSelCases *SelCases;
//---------------------------------------------------------------------------
__fastcall TSelCases::TSelCases(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnOKClick(TObject *Sender)
{
	SelCases->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnCancelClick(TObject *Sender)
{
	SelCases->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::IfButtonClick(TObject *Sender)
{
	SelIf->ShowModal();	
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::SampleButtonClick(TObject *Sender)
{
	SelRndm->ShowModal();	
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::RangeButtonClick(TObject *Sender)
{
	SelRange->ShowModal();	
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnIfConditionClick(TObject *Sender)
{
	if (BtnIfCondition->Checked)
    {
    	IfButton->Enabled = true;
        SampleButton->Enabled = false;
        RangeButton->Enabled = false;
        BtnUnselDel->Enabled = true;
        BtnUnselFilt->Enabled = true;
    }
    else IfButton->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnRandomClick(TObject *Sender)
{
	if (BtnRandom->Checked)
    {
    	SampleButton->Enabled = true;
        IfButton->Enabled = false;
        RangeButton->Enabled = false;
        BtnUnselDel->Enabled = true;
        BtnUnselFilt->Enabled = true;
    }
    else SampleButton->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnCaseRangeClick(TObject *Sender)
{
	if (BtnCaseRange->Checked)
    {
    	RangeButton->Enabled = true;
        SampleButton->Enabled = false;
        IfButton->Enabled = false;
        BtnUnselDel->Enabled = true;
        BtnUnselFilt->Enabled = true;
    }
    else RangeButton->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnFilterClick(TObject *Sender)
{
    	RangeButton->Enabled = false;
        SampleButton->Enabled = false;
        IfButton->Enabled = false;
        BtnUnselDel->Enabled = true;
        BtnUnselFilt->Enabled = true;
        FilterOn = true;
        MainForm->StatusEdit->Text = "Filter On";
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnSelAllClick(TObject *Sender)
{
    	RangeButton->Enabled = false;
        SampleButton->Enabled = false;
        IfButton->Enabled = false;
        BtnUnselDel->Enabled = false;
        BtnUnselFilt->Enabled = false;
        TxtFilterVar->Text = "";
        MainForm->StatusEdit->Text = "Filter Off";
        FilterOn = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnFilterVarClick(TObject *Sender)
{
	int index = ListBox1->ItemIndex;
	TxtFilterVar->Text = ListBox1->Items->Strings[index];
        FilterOn = true;
        MainForm->StatusEdit->Text = "Filter On";
        if (TxtFilterVar->Text.Length() > 0)
           MainForm->StatusEdit->Text = MainForm->StatusEdit->Text +
           ": " + TxtFilterVar->Text;
}
//---------------------------------------------------------------------------
void __fastcall TSelCases::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OS4HELP.HLP";
  Application->HelpJump("selectif");
}
//---------------------------------------------------------------------------


void __fastcall TSelCases::BtnResetClick(TObject *Sender)
{
        BtnSelAllClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TSelCases::FormShow(TObject *Sender)
{
        BtnSelAllClick(this);
}
//---------------------------------------------------------------------------

