//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "GLMGrid.h"
#include "GLM.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGLMFrm1 *GLMFrm1;
extern int NoVariables;
extern int NoCases;
extern int FilterCol;
extern bool FilterOn;

//---------------------------------------------------------------------------
__fastcall TGLMFrm1::TGLMFrm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGLMFrm1::CancelBtnClick(TObject *Sender)
{
     GLMFrm1->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::FormShow(TObject *Sender)
{
     AnsiString cellstring;

     ListBox1->Clear();
     ListBox2->Clear();
     ListBox3->Clear();
     ListBox4->Clear();
     ListBox5->Clear();
     DepAbrevList->Clear();
     FixedAbrevList->Clear();
     RndAbrevList->Clear();
     CovAbrevList->Clear();
     InterAbrevList->Clear();
     DepOutBtn->Enabled = false;
     FixedOutBtn->Enabled = false;
     RndmOutBtn->Enabled = false;
     CovOutBtn->Enabled = false;
     DescChkBox->Checked = false;
     CorrChkBox->Checked = false;
     zPlotChkBox->Checked = false;
     RawResidChkBox->Checked = false;
     TypeGroup->ItemIndex = 0;
     NoContDep = 0;
     NoCatDep = 0;
     ModelEdit->Text = "";
//     TypeIIIChkBox->Checked = true;
//     TypeIChkBox->Checked = false;
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
     InterStart = false;
     IntVarCnt = 0;
     CovVectCols = NULL;
     DepCols = NULL;
     IntVectCnt = NULL;
     try
     {
         IntVarCol = new int*[20]; //max of 20 interactions up to 5 way
         for (int i = 0; i < 20; i++) IntVarCol[i] = new int[5];
         IntFixNo = new int *[20];
         for (int i = 0; i < 20; i++) IntFixNo[i] = new int[5];
         IntTermType = new int*[20];
         for (int i =0; i < 20; i++) IntTermType[i] = new int[5]; // type of term
         IntTermCnt = new int[20]; // no of terms in each interaction item
         IntRndNo = new int *[20];
         for (int i = 0; i < 20; i++) IntRndNo[i] = new int[5];
         FixVectCols = new int *[10];
         for (int i = 0; i < 10; i++) FixVectCols[i] = new int[10];
         IntVectCnt = new int[10];
         IntCovNo = new int *[20];
         for (int i = 0; i < 20; i++) IntCovNo[i] = new int[5];
     }
     catch (...)
     {
           Application->MessageBox("Out of memory.","ERROR",MB_OK);
           return;
     }

}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::DepInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            cellstring = "Y";
            int no = DepAbrevList->Items->Count;
            cellstring = cellstring + (no+1);
            if (TypeGroup->ItemIndex == 0)
            {
                DepAbrevList->Items->Add(cellstring);
                NoContDep++;
            }
            else
            {
                CatDepAbbrevList->Items->Add(cellstring); // categorical dependent variable
                NoCatDep++;
            }
            count++;
         }
     }
     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }

     DepOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::FixedInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;
     char chrA = 'A';

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox3->Items->Add(cellstring);
            cellstring = "F";
            int no = FixedAbrevList->Items->Count;
            cellstring = cellstring + char(chrA+no);
            FixedAbrevList->Items->Add(cellstring);
            count++;
         }
     }
     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }

     FixedOutBtn->Enabled = true;

}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::RndmInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;
     char chrA = 'A';

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox4->Items->Add(cellstring);
            cellstring = "R";
            int no = RndAbrevList->Items->Count;
            cellstring = cellstring + char(chrA+no);
//            cellstring = cellstring + (no+1);
            RndAbrevList->Items->Add(cellstring);
            count++;
         }
     }
     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }

     RndmOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::CovInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox5->Items->Add(cellstring);
            cellstring = "C";
            int no = CovAbrevList->Items->Count;
            cellstring = cellstring + (no+1);
            CovAbrevList->Items->Add(cellstring);
            count++;
         }
     }
     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }

     CovOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::DepOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     if (ListBox2->ItemIndex == -1) return;
     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);
     // find abbreviation and remove
     cellstring = "Y";
     cellstring = cellstring + (index+1);
     bool found = false;
     for (int i = 0; i < DepAbrevList->Items->Count; i++)
     {
         if (cellstring == DepAbrevList->Items->Strings[i]) // match found?
         {
             DepAbrevList->Items->Delete(i);
             NoContDep--;
             found = true;
         }
     }
     if (!found) // check for presence in categorical dependents
     {
         for (int i = 0; i < CatDepAbbrevList->Items->Count; i++)
         {
             if (cellstring == CatDepAbbrevList->Items->Strings[i])
             {
                 CatDepAbbrevList->Items->Delete(i);
                 NoCatDep--;
             }
         }
     }
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::FixedOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     if (ListBox3->ItemIndex == -1) return;
     index = ListBox3->ItemIndex;
     cellstring = ListBox3->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox3->Items->Delete(index);

}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::RndmOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     if (ListBox4->ItemIndex == -1) return;
     index = ListBox4->ItemIndex;
     cellstring = ListBox4->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox4->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::CovOutBtnClick(TObject *Sender)
{
     AnsiString cellstring;
     int index;

     if (ListBox5->ItemIndex == -1) return;
     index = ListBox5->ItemIndex;
     cellstring = ListBox5->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox5->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::ResetBtnClick(TObject *Sender)
{
    // clean up the heap
    if (NoCatDep > 0)
    {
        for (int i = 0; i < NoCatDep; i++) delete[] DepVectCols[i];
        delete[] DepVectCols;
        delete[] CatDepCols;
        delete[] CatDepLevels;
    }
    if (NoCov > 0)
    {
        delete[] CovVectCols;
        delete[] CovCols;
    }
    if (NoRnd > 0)
    {
       delete[] RndLevels;
       delete[] RndCols;
       for (int i = 0; i < NoRnd; i++) delete[] RndVectCols[i];
       delete[] RndVectCols;
    }
    if (NoFixed > 0)
    {
       delete[] FixedLevels;
       delete[] FixedCols;
    }
    delete[] DepCols;
    for (int i = 0; i < 20; i++) delete[] IntCovNo[i];
    delete[] IntCovNo;
    delete[] IntVectCnt;
    for (int i = 0; i < 10; i++) delete[] FixVectCols[i];
    delete[] FixVectCols;
    for (int i = 0; i < 20; i++) delete[] IntRndNo[i];
    delete[] IntRndNo;
    delete[] IntTermCnt;
    for (int i = 0; i < 20; i++) delete[] IntTermType[i];
    delete[] IntTermType;
    for (int i = 0; i < 20; i++) delete[] IntFixNo[i];
    delete[] IntFixNo;
    for (int i = 0; i < 20; i++) delete[] IntVarCol[i];
    delete[] IntVarCol;
    FormShow(this);
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::OKBtnClick(TObject *Sender)
{
    int TypeCode = 1;
    int i, j, col, Min, Max, value, gridcols, gridrows;
    int FactorType;
    AnsiString cellstring;
    bool mancova;

    // To complete a GLM analysis, levels of fixed and random variables
    // are coded using orthogonal, effect or dummy coding.  A new grid is
    // created to hold the original dependent variable values, codings for
    // fixed and random variable levels, interaction vectors of these codings,
    // and finally, the covariates.  This new array is then analyzed using
    // either multiple regression (if only one dependent variable) or using
    // canonical correlation procedures (if multiple dependent variables exist.)

    mancova = false;
    NoDep = ListBox2->Items->Count;
    NoFixed = ListBox3->Items->Count;
    NoRnd = ListBox4->Items->Count;
    NoCov = ListBox5->Items->Count;
    try  {
        DepCols = new int[NoDep];
        if (NoFixed > 0)
        {
            FixedCols = new int[NoFixed];
            FixedLevels = new int[NoFixed];
        }
        if (NoRnd > 0)
        {
            RndVectCols = new int*[NoRnd];
            for (int i = 0; i < NoRnd; i++) RndVectCols[i] = new int[10];
            RndCols = new int[NoRnd];
            RndLevels = new int[NoRnd];
        }
        if (NoCov > 0)
        {
            CovCols = new int[NoCov];
            CovVectCols = new int[NoCov];
        }
        if (NoCatDep > 0)
        {
            CatDepLevels = new int[NoCatDep];
            CatDepCols = new int[NoCatDep];
            DepVectCols = new int *[NoCatDep];
            for (int i = 0; i < NoCatDep; i++) DepVectCols[i] = new int[10];
        }
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory.","ERROR",MB_OK);
        exit (-1);
    }

    // Get column no.s of variables
    int catcnt = 0;
    int contcnt = 0;
    for (i = 0; i < NoDep; i++) // get grid column of all dependent variables
    {
        cellstring = ListBox2->Items->Strings[i];
        bool categorical = false;
        // determine whether a continuous or categorical dependent variable
        if (NoCatDep > 0)
        {
            for (int k = 0; k < NoCatDep; k++)
            {
                AnsiString abbrev = "Y";
                abbrev = abbrev + (i+1);
                if (abbrev == CatDepAbbrevList->Items->Strings[k])
                    categorical = true;
            }
        }
        for (j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
            {
                if (!categorical)
                {
                    DepCols[contcnt] = j+1;
                    contcnt++;
                }
                else
                {
                    CatDepCols[catcnt] = j+1;
                    catcnt++;
                }
            }
        }
    }
    if (NoFixed > 0)
    {
        for (i = 0; i < NoFixed; i++)
        {
            cellstring = ListBox3->Items->Strings[i];
            for (j = 0; j < NoVariables; j++)
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                    FixedCols[i] = j+1;
        }
    }
    if (NoRnd > 0)
    {
        for (i = 0; i < NoRnd; i++)
        {
            cellstring = ListBox4->Items->Strings[i];
            for (j = 0; j < NoVariables; j++)
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                    RndCols[i] = j+1;
        }
    }
    if (NoCov > 0)
    {
        for (i = 0; i < NoCov; i++)
        {
            cellstring = ListBox5->Items->Strings[i];
            for (j = 0; j < NoVariables; j++)
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                    CovCols[i] = j+1;
        }
    }

    // Get minimum and maximum levels of fixed and random variables
    if (NoFixed > 0)
    {
        for (i = 0; i < NoFixed; i++)
        {
            col = FixedCols[i];
            Min = 1000;
            Max = 0;
            for (j = 0; j < NoCases; j++)
            {
                if (!ValidRecord(FixedCols,NoFixed,j+1)) continue;
                value = atoi(MainForm->Grid->Cells[col][j+1].c_str());
                if (value < Min) Min = value;
                if (value > Max) Max = value;
            }
            FixedLevels[i] = Max - Min + 1;
        }
    }
    if (NoRnd > 0)
    {
        for (i = 0; i < NoRnd; i++)
        {
            col = RndCols[i];
            Min = 1000;
            Max = 0;
            for (j = 0; j < NoCases; j++)
            {
                if (!ValidRecord(RndCols,NoRnd,j+1)) continue;
                value = atoi(MainForm->Grid->Cells[col][j+1].c_str());
                if (value < Min) Min = value;
                if (value > Max) Max = value;
            }
            RndLevels[i] = Max - Min + 1;
        }
    }
    if (NoCatDep > 0) // categorical dependent variables
    {
        for (i = 0; i < NoCatDep; i++)
        {
            col = CatDepCols[i];
            Min = 1000;
            Max = 0;
            for (j = 0; j < NoCases; j++)
            {
                if (!ValidRecord(CatDepCols,NoCatDep,j+1)) continue;
                value = atoi(MainForm->Grid->Cells[col][j+1].c_str());
                if (value < Min) Min = value;
                if (value > Max) Max = value;
            }
            CatDepLevels[i] = Max - Min + 1;
        }
    }

    // First, get the type of coding the user wishes to generate
    if (RadioGroup1->ItemIndex == 0) TypeCode = 1; // orthogonal
    if (RadioGroup1->ItemIndex == 1) TypeCode = 2; // effect
    if (RadioGroup1->ItemIndex == 2) TypeCode = 3; // dummy

    // Next, set up the new grid with correct no. of rows and columns
    // and copy the dependent variables to the grid
    gridrows = NoCases + 1;
    gridcols = NoDep + NoCov + 1;
    if (NoCatDep > 0)
       for (i = 0; i < NoCatDep; i++) gridcols += (CatDepLevels[i]-1);
    if (NoFixed > 0)
       for (i = 0; i < NoFixed; i++) gridcols += (FixedLevels[i]-1);
    if (NoRnd > 0)
       for (i = 0; i < NoRnd; i++) gridcols += (RndLevels[i]-1);

    GLMGridFrm->Grid->RowCount = gridrows;
    GLMGridFrm->Grid->ColCount = gridcols;

    for (i = 0; i < NoCases; i++) // copy case labels
        GLMGridFrm->Grid->Cells[0][i+1] = MainForm->Grid->Cells[0][i+1];

    for (i = 0; i < NoContDep; i++) // copy dependent variables
    {
        col = DepCols[i];
        for (j = 0; j < NoCases; j++)
            GLMGridFrm->Grid->Cells[i+1][j+1] = MainForm->Grid->Cells[col][j+1];
        GLMGridFrm->Grid->Cells[i+1][0] = GLMFrm1->DepAbrevList->Items->Strings[i];
    }
    startcol = NoContDep + 1;

    // Now, generate main factor coding for fixed variables
    // These will be saved in the newly created GLMGridFrm
    // grid following the copied dependent variables

    // get coding for any categorical dependent variables and add to the grid
    if (NoCatDep > 0)
    {
        FactorType = 0;
        MainCoding(NoCatDep, NoCases, TypeCode, CatDepLevels,
                   FixedCols, startcol, FactorType,FixVectCols,
                   RndVectCols,DepVectCols);
        // Update the startcol
        for (j = 0; j < NoCatDep; j++) startcol += (CatDepLevels[j]-1);
    }

    // Add the covariates to the grid
    if (NoCov > 0)
    {
       for (i = 0; i < NoCov; i++)
       {
           col = CovCols[i];
           GLMGridFrm->Grid->Cells[startcol][0] = CovAbrevList->Items->Strings[i];
           //   MainForm->Grid->Cells[col][0];
           CovVectCols[i] = startcol;
           for (j = 0; j < NoCases; j++)
               GLMGridFrm->Grid->Cells[startcol][j+1] = MainForm->Grid->Cells[col][j+1];
           startcol++;
       }
    }

    if (NoFixed > 0) // get coding for each fixed variable
    {
        FactorType = 1;
        MainCoding(NoFixed, NoCases, TypeCode, FixedLevels,
                   FixedCols, startcol, FactorType,FixVectCols,
                   RndVectCols,DepVectCols);
        // Update the startcol
        for (j = 0; j < NoFixed; j++) startcol += (FixedLevels[j]-1);
    }

    if (NoRnd > 0) // get coding for each random variable
    {
        FactorType = 2;
        MainCoding(NoRnd,NoCases,TypeCode,RndLevels,RndCols,
                   startcol,FactorType,FixVectCols,RndVectCols,DepVectCols);
        for (j = 0; j < NoRnd; j++) startcol += (RndLevels[j]-1);
    }

    // Now get two-way interactions among factors
    InterCoding(this);

    GLMGridFrm->ShowModal();

    // check for whether or not manova or mancova is correct methodology
    if ((NoCov > 0) && ((NoFixed > 0) || (NoRnd > 0)) && (NoContDep > 1))
    {
        mancova = true;
        Application->MessageBox("Multivariate Analysis of Covariance","MESSAGE",MB_OK);
    }

    // Now do regression or canonical analysis
    if ((NoDep > 1)||(NoCatDep >= 1)||(mancova)) // canonical correlation
    {
       CanReg(NoContDep,NoCatDep,NoFixed,NoRnd,NoCov,IntVarCnt,DepCols,CatDepCols,
           FixedCols,RndCols,CovCols,CatDepLevels,FixedLevels,RndLevels,
           IntVectCnt, TypeCode, mancova);
    }
    else // do multiple regression analysis
    {
       MReg(NoDep,NoFixed,NoRnd,NoCov,IntVarCnt,DepCols,FixedCols,RndCols,
           CovCols,FixedLevels,RndLevels,IntVectCnt,TypeCode);
    }

    // clean up the heap
    if (NoCatDep > 0)
    {
        for (int i = 0; i < NoCatDep; i++) delete[] DepVectCols[i];
        delete[] DepVectCols;
        delete[] CatDepCols;
        delete[] CatDepLevels;
    }
    if (NoCov > 0)
    {
        delete[] CovVectCols;
        delete[] CovCols;
    }
    if (NoRnd > 0)
    {
       delete[] RndLevels;
       delete[] RndCols;
       for (i = 0; i < NoRnd; i++) delete[] RndVectCols[i];
       delete[] RndVectCols;
    }
    if (NoFixed > 0)
    {
       delete[] FixedLevels;
       delete[] FixedCols;
    }
    delete[] DepCols;
    for (i = 0; i < 20; i++) delete[] IntCovNo[i];
    delete[] IntCovNo;
    delete[] IntVectCnt;
    for (i = 0; i < 10; i++) delete[] FixVectCols[i];
    delete[] FixVectCols;
    for (i = 0; i < 20; i++) delete[] IntRndNo[i];
    delete[] IntRndNo;
    delete[] IntTermCnt;
    for (i = 0; i < 20; i++) delete[] IntTermType[i];
    delete[] IntTermType;
    for (i = 0; i < 20; i++) delete[] IntFixNo[i];
    delete[] IntFixNo;
    for (i = 0; i < 20; i++) delete[] IntVarCol[i];
    delete[] IntVarCol;

    GLMFrm1->Hide();
}
//---------------------------------------------------------------------------

void MainCoding(int NFactors, int NoCases, int TypeCode, int *Levels,
                 int *MainCols, int startcol, int FactorType,
                 int **FixVectCols, int **RndVectCols, int **DepVectCols)
{
    AnsiString cellstring;
    int i, j, col, newcol, X, value;
    char chrA = 'A';

    for (int factor = 0; factor < NFactors; factor++)
    {
        int **Codes;;
        try  {
             Codes = new int *[Levels[factor]];
             for (i = 0; i < Levels[factor]; i++) Codes[i] = new int[Levels[factor]-1];
        }
        catch (...)
        {
              Application->MessageBox("Out of Memory.","ERROR",MB_OK);
              return;
        }
        VectorCodes(Levels[factor],TypeCode, Codes);
        col = MainCols[factor];
        for (j = 0; j < Levels[factor]-1; j++)
        {
            if (FactorType == 0) cellstring = "Y";
            if (FactorType == 1) cellstring = "F";
            if (FactorType == 2) cellstring = "R";
            cellstring = cellstring + char(chrA+factor);
            cellstring = cellstring + (j+1);
            newcol = startcol + j;
            if (FactorType == 0) DepVectCols[factor][j] = newcol;
            if (FactorType == 1) FixVectCols[factor][j] = newcol;
            if (FactorType == 2) RndVectCols[factor][j] = newcol;
            GLMGridFrm->Grid->Cells[newcol][0] = cellstring;
        }
        for (i = 0; i < NoCases; i++)
        {
            X = atoi(MainForm->Grid->Cells[col][i+1].c_str());
            for (j = 0; j < Levels[factor]-1; j++)
            {
                value = Codes[X-1][j];
                newcol = startcol + j;
                GLMGridFrm->Grid->Cells[newcol][i+1] = value;
            }
        }
        for (i = 0; i < Levels[factor]; i++) delete[] Codes[i];
        delete[] Codes;
        startcol += (Levels[factor]-1);
    }
}
//---------------------------------------------------------------------------

void VectorCodes(int NoLevels, int Type, int **Codes)
{
     for (int Level = 1; Level <= NoLevels; Level++)
     {
         for (int vector = 1; vector < NoLevels; vector++)
         {
             switch (Type)
             {
                 case 1:  // Orthogonal coding
                 {
                      if (Level <= vector) Codes[Level-1][vector-1] = 1;
                      if (Level-1 == vector) Codes[Level-1][vector-1] = -vector;
                      if (Level > vector +1) Codes[Level-1][vector-1] = 0;
                      break;
                 }
                 case 2: // Effect coding (with comparison to first level)
                 {
                      if (Level == vector) Codes[Level-1][vector-1] = 1;
                      if (Level == NoLevels) Codes[Level-1][vector-1] = -1;
                      if ((Level != vector) && (Level != NoLevels))
                          Codes[Level-1][vector-1] = 0;
                      break;
                 }
                 case 3: // Dummy coding
                 {
                      if (Level == vector) Codes[Level-1][vector-1] = 1;
                      else Codes[Level-1][vector-1] = 0;
                      break;
                 }
             } // end switch
         } // next vector
     } // next Level
}
//---------------------------------------------------------------------------

void MReg(int NoDep,int NoFixed,int NoRnd,int NoCov, int IntVarCnt, int *DepCols,
          int *FixedCols,int *RndCols,int *CovCols,int *FixedLevels,
          int *RndLevels,int *IntVectCnt, int TypeCode)
{
    int matsize, i, j, k, ptr, OldNoIndep = 0;
    int *ColsIn, *FixStart, *FixEnd, *RndStart, *RndEnd, *GridIn, *IndepIn;
    int *IntStart, *IntEnd;
    int CovStart, NoIn, prtopt;
    double **rmat, **inversemat, **WorkMat, **v, *DepVector, *Betas;
    double *BWeights, *Means, *Variances, *StdDevs, *tvalues, *W;
    double *probs;
    double OldR2 = 0;
    bool descriptives = false, correlations = false, covin = false;
    TStringList *Plist = new TStringList();

    if (GLMFrm1->DescChkBox->Checked) descriptives = true;
    if (GLMFrm1->CorrChkBox->Checked) correlations = true;
    matsize = GLMGridFrm->Grid->ColCount;
    try
    {
       rmat = new double *[matsize];
       for (i = 0; i < matsize; i++) rmat[i] = new double[matsize];
       inversemat = new double *[matsize];
       for (i = 0; i < matsize; i++) inversemat[i] = new double[matsize];
       WorkMat = new double *[matsize];
       for (i = 0; i < matsize; i++) WorkMat[i] = new double[matsize];
       v = new double *[matsize];
       for (i = 0; i < matsize; i++) v[i] = new double[matsize];
       DepVector = new double[matsize];
       Betas = new double[matsize];
       BWeights = new double[matsize];
       Means = new double[matsize];
       Variances = new double[matsize];
       StdDevs = new double[matsize];
       tvalues = new double[matsize];
       probs = new double[matsize];
       W = new double[matsize];
       ColsIn = new int[matsize];
       GridIn = new int[matsize];
       IndepIn = new int[matsize];
       if (NoFixed > 0)
       {
           FixStart = new int[NoFixed];
           FixEnd = new int[NoFixed];
       }
       if (NoRnd > 0)
       {
           RndStart = new int[NoRnd];
           RndEnd = new int[NoRnd];
       }
       if (IntVarCnt > 0)
       {
           IntStart = new int[IntVarCnt];
           IntEnd = new int[IntVarCnt];
       }
    }
    catch (...)
    {
          Application->MessageBox("Out of Memory.","ERROR",MB_OK);
          return;
    }

    // Determine where the data are in the GLMGridFrm
    GridIn[0] = 1; // dependent variable is first column of GLMGridFrm
    ptr = 2; // mainform grid column for next vector

    if (NoCov > 0)
    {
        CovStart = ptr;
        for (i = 0; i < NoCov; i++) ptr++;
    }

    if (NoFixed > 0) // fixed level vectors would be next
    {
       for (i = 0; i < NoFixed; i++)
       {
           FixStart[i] = ptr; //grid column start of factor i
           for (j = 0; j < FixedLevels[i]-1; j++)
           {
               GridIn[ptr-1] = ptr; // starts after covariates
               ptr++;
           }
           FixEnd[i] = ptr-1;
       }
    }

    if (NoRnd > 0) // random levels vectors would be next
    {
        for (i = 0; i < NoRnd; i++)
        {
            RndStart[i] = ptr;
            for (j = 0; j < RndLevels[i]-1; j++)
            {
                GridIn[ptr-1] = ptr;
                ptr++;
            }
            RndEnd[i] = ptr-1;
        }
    }

    if (IntVarCnt > 0) // interaction vectors would be next
    {
        for (i = 0; i < IntVarCnt; i++)
        {
            IntStart[i] = ptr;
            for (j = 0; j < IntVectCnt[i]; j++)
            {
                GridIn[ptr-1] = ptr;
                ptr++;
            }
            IntEnd[i] = ptr-1;
        }
    }

    // What are the users options?
    if (descriptives && correlations) prtopt = 1; // print all
    if (descriptives && !correlations) prtopt = 3; // descriptives
    if (!descriptives && correlations) prtopt = 2; // corr's only

    // Build columns in the r matrix for the first step
    GridIn[0] = 1; // dependent variable (only one) in column 1
    NoIn = 1;

    if ((NoCov > 0)&&(GLMFrm1->RadioGroup3->ItemIndex == 0)) // are covariates entered first?
    {
        for (i = 0; i < NoCov; i++)
        {
            GridIn[NoIn] = CovStart + i;
            NoIn++;
        }
        // show results
        GetCorrs(Means, StdDevs, rmat, NoIn, GridIn, NoCases, prtopt, 3);
        for (i = 0; i < NoIn; i++) Variances[i] = StdDevs[i] * StdDevs[i];
        //build work matrix of independent variables offset by 1 for inverse
        for (i = 0; i < NoIn-1; i++) DepVector[i] = rmat[0][i+1];
        for (i=0; i < NoIn-1; i++)
            for (j = 0; j < NoIn-1; j++) WorkMat[i+1][j+1] = rmat[i+1][j+1];
        // Get inverse
        matinv(WorkMat, NoIn-1, inversemat, v, W);
        // move to offset 0
        for (i=0; i < NoIn-1; i++) // rows
        {
            IndepIn[i] = GridIn[i+1];
            for (j = 0; j < NoIn-1; j++)inversemat[i][j] = inversemat[i+1][j+1];
        }
        if ((prtopt == 1) || (prtopt == 2))
        {
            MPrint(inversemat, NoIn-1, NoIn-1, IndepIn, "Inverse Matrix");
            FrmOutPut->ShowModal();
        }
        OldR2 = ShowStep(NoIn-1, inversemat, DepVector, Betas,
            IndepIn, Means, Variances, StdDevs, NoCases, OldR2, OldNoIndep );
        OldNoIndep = NoIn-1;
    }

    if (NoFixed > 0) // add fixed effect variables one at a time
    {
        if ((NoCov > 0)&&(GLMFrm1->RadioGroup3->ItemIndex == 1)&& (covin == false))
        {
            covin = true;
            for (i = 0; i < NoCov; i++)
            {
                GridIn[NoIn] = CovStart + i;
                NoIn++;
            }
        }
        for (i = 0; i < NoFixed; i++)
        {
            for (j = 0; j < FixedLevels[i] - 1; j++)
            {
                GridIn[NoIn] = FixStart[i]+j;
                NoIn++;
            }
            // do analysis
            GetCorrs(Means, StdDevs, rmat, NoIn, GridIn, NoCases, prtopt, 3);
            for (j = 0; j < NoIn; j++) Variances[j] = StdDevs[j] * StdDevs[j];
            //build work matrix of independent variables offset by 1 for inverse
            for (j = 0; j < NoIn-1; j++) DepVector[j] = rmat[0][j+1];
            for (j=0; j < NoIn-1; j++)
                for (k = 0; k < NoIn-1; k++)
                    WorkMat[j+1][k+1] = rmat[j+1][k+1];
            // Get inverse
            matinv(WorkMat, NoIn-1, inversemat, v, W);
            // move to offset 0
             for (j=0; j < NoIn-1; j++) // rows
             {
                 IndepIn[j] = GridIn[j+1];
                 for (k = 0; k < NoIn-1; k++)
                     inversemat[j][k] = inversemat[j+1][k+1];
             }
             if ((prtopt == 1) || (prtopt == 2))
             {
                MPrint(inversemat, NoIn-1, NoIn-1, IndepIn, "Inverse Matrix");
                FrmOutPut->ShowModal();
             }
             OldR2 = ShowStep(NoIn-1, inversemat, DepVector, Betas,
                 IndepIn, Means, Variances, StdDevs, NoCases, OldR2, OldNoIndep );
             OldNoIndep = NoIn-1;
        }
    }

    // next random variable
    if (NoRnd > 0) // add random effect variables one at a time
    {
        if ((NoCov > 0)&&(GLMFrm1->RadioGroup3->ItemIndex == 1) && (covin == false))
        {
            covin = true;
            for (i = 0; i < NoCov; i++)
            {
                GridIn[NoIn] = CovStart + i;
                NoIn++;
            }
        }
        for (i = 0; i < NoRnd; i++)
        {
            for (j = 0; j < RndLevels[i] - 1; j++)
            {
                GridIn[NoIn] = RndStart[i]+j;
                NoIn++;
            }
            // do analysis
            GetCorrs(Means, StdDevs, rmat, NoIn, GridIn, NoCases, prtopt, 3);
            for (j = 0; j < NoIn; j++) Variances[j] = StdDevs[j] * StdDevs[j];
            //build work matrix of independent variables offset by 1 for inverse
            for (j = 0; j < NoIn-1; j++) DepVector[j] = rmat[0][j+1];
            for (j=0; j < NoIn-1; j++)
                for (k = 0; k < NoIn-1; k++)
                    WorkMat[j+1][k+1] = rmat[j+1][k+1];
            // Get inverse
            matinv(WorkMat, NoIn-1, inversemat, v, W);
            // move to offset 0
             for (j=0; j < NoIn-1; j++) // rows
             {
                 IndepIn[j] = GridIn[j+1];
                 for (k = 0; k < NoIn-1; k++)
                     inversemat[j][k] = inversemat[j+1][k+1];
             }
             if ((prtopt == 1) || (prtopt == 2))
             {
                MPrint(inversemat, NoIn-1, NoIn-1, IndepIn, "Inverse Matrix");
                FrmOutPut->ShowModal();
             }
             OldR2 = ShowStep(NoIn-1, inversemat, DepVector, Betas,
                 IndepIn, Means, Variances, StdDevs, NoCases, OldR2, OldNoIndep );
             OldNoIndep = NoIn-1;
        }
    }

    // now do interactions
    if (IntVarCnt > 0)
    {
        for (i = 0; i < IntVarCnt; i++)
        {
            for (j = 0; j < IntVectCnt[i]; j++)
            {
                GridIn[NoIn] = IntStart[i]+j;
                NoIn++;
            }
            // do analysis
            GetCorrs(Means, StdDevs, rmat, NoIn, GridIn, NoCases, prtopt, 3);
            for (j = 0; j < NoIn; j++) Variances[j] = StdDevs[j] * StdDevs[j];
            //build work matrix of independent variables offset by 1 for inverse
            for (j = 0; j < NoIn-1; j++) DepVector[j] = rmat[0][j+1];
            for (j=0; j < NoIn-1; j++)
                for (k = 0; k < NoIn-1; k++)
                    WorkMat[j+1][k+1] = rmat[j+1][k+1];
            // Get inverse
            matinv(WorkMat, NoIn-1, inversemat, v, W);
            // move to offset 0
             for (j=0; j < NoIn-1; j++) // rows
             {
                 IndepIn[j] = GridIn[j+1];
                 for (k = 0; k < NoIn-1; k++)
                     inversemat[j][k] = inversemat[j+1][k+1];
             }
             if ((prtopt == 1) || (prtopt == 2))
             {
                MPrint(inversemat, NoIn-1, NoIn-1, IndepIn, "Inverse Matrix");
                FrmOutPut->ShowModal();
             }
             OldR2 = ShowStep(NoIn-1, inversemat, DepVector, Betas,
                 IndepIn, Means, Variances, StdDevs, NoCases, OldR2, OldNoIndep );
             OldNoIndep = NoIn-1;
        }
    }

    // Still need to do covariates?
    if ((NoCov > 0) &&(GLMFrm1->RadioGroup3->ItemIndex == 2)) // covariates after effects
    {
        for (i = 0; i < NoCov; i++)
        {
            GridIn[NoIn] = CovStart + i;
            NoIn++;
        }
        // show results
        GetCorrs(Means, StdDevs, rmat, NoIn, GridIn, NoCases, prtopt, 3);
        for (i = 0; i < NoIn; i++) Variances[i] = StdDevs[i] * StdDevs[i];
        //build work matrix of independent variables offset by 1 for inverse
        for (i = 0; i < NoIn-1; i++) DepVector[i] = rmat[0][i+1];
        for (i=0; i < NoIn-1; i++)
            for (j = 0; j < NoIn-1; j++) WorkMat[i+1][j+1] = rmat[i+1][j+1];
        // Get inverse
        matinv(WorkMat, NoIn-1, inversemat, v, W);
        // move to offset 0
        for (i=0; i < NoIn-1; i++) // rows
        {
            IndepIn[i] = GridIn[i+1];
            for (j = 0; j < NoIn-1; j++)inversemat[i][j] = inversemat[i+1][j+1];
        }
        if ((prtopt == 1) || (prtopt == 2))
        {
            MPrint(inversemat, NoIn-1, NoIn-1, IndepIn, "Inverse Matrix");
            FrmOutPut->ShowModal();
        }
        OldR2 = ShowStep(NoIn-1, inversemat, DepVector, Betas,
            IndepIn, Means, Variances, StdDevs, NoCases, OldR2, OldNoIndep );
        OldNoIndep = NoIn-1;
    }

    //clean up heap
    if (IntVarCnt > 0)
    {
        delete[] IntEnd;
        delete[] IntStart;
    }
    if (NoRnd > 0)
    {
        delete[] RndEnd;
        delete[] RndStart;
    }
    if (NoFixed > 0)
    {
        delete[] FixEnd;
        delete[] FixStart;
    }
    delete[] IndepIn;
    delete[] GridIn;
    delete[] ColsIn;
    delete[] W;
    delete[] probs;
    delete[] tvalues;
    delete[] StdDevs;
    delete[] Variances;
    delete[] Means;
    delete[] BWeights;
    delete[] Betas;
    delete[] DepVector;
    for (i = 0; i < matsize; i++) delete[] v[i];
    delete[] v;
    for (i = 0; i < matsize; i++) delete[] WorkMat[i];
    delete[] WorkMat;
    for (i = 0; i < matsize; i++) delete[] inversemat[i];
    delete[] inversemat;
    for (i = 0; i < matsize; i++) delete[] rmat[i];
    delete[] rmat;
    delete Plist;

}
//---------------------------------------------------------------------------

void CanReg(int NoContDep, int NoCatDep, int NoFixed, int NoRnd, int NoCov,int NoInt,
          int *DepCols, int *CatDepCols, int *FixedCols, int *RndCols,
          int *CovCols, int * CatDepLevels, int *FixedLevels,
          int *RndLevels, int *IntVectCnt, int TypeCode,bool mancova)
{
    int matsize, i, j, k, prtopts;
    bool descriptives, correlations, errorcode;
    double **rmat, **inversemat, **WorkMat, **ryy, **rxx, **ryx;
    double **ryyinv, **rxxinv, **rxy, **eigenvectors, **RxxINVxRxy;
    double **RyyINVxRyx, **char_equation, **eigentrans, **theta;
    double **raw_y, **norm_y, **raw_x, **norm_x, **y_cors, **x_cors;
    double *Means, *Variances, *StdDevs;
    double *tvalues, *probs, *roots, *pcnt_trace;
    double *pv_y, *pv_x, *rd_y, *rd_x, *root_chi, *chi_prob;
    double q;
    int *ColNoSelected, *root_df;
    int depcnt, indcnt;
    AnsiString ColLabels[20];
    AnsiString RowLabels[20];
    AnsiString CanLabels[20];
    char outline[121];

    if (GLMFrm1->DescChkBox->Checked) descriptives = true;
    if (GLMFrm1->CorrChkBox->Checked) correlations = true;
    if (descriptives && correlations) prtopts = 1; // print all
    if (descriptives && !correlations) prtopts = 3; // descriptives
    if (!descriptives && correlations) prtopts = 2; // corr's only
    matsize = NoContDep + NoCov+1;
    depcnt = NoContDep;
    indcnt = NoCov;

    if (NoCatDep > 0)
    {
        for (i = 0; i < NoCatDep; i++)
        {
            matsize += (CatDepLevels[i]-1);
            depcnt += (CatDepLevels[i]-1);
        }
    }
    if (NoFixed > 0)
    {
        for (i = 0; i < NoFixed; i++)
        {
            matsize += (FixedLevels[i]-1);
            indcnt += (FixedLevels[i]-1);
        }
    }
    if (NoRnd > 0)
    {
        for (i = 0; i < NoRnd; i++)
        {
            matsize += (RndLevels[i]-1);
            indcnt += (RndLevels[i]-1);
        }
    }
    if (NoInt > 0)
    {
        for (i = 0; i < NoInt; i++)
        {
            matsize += IntVectCnt[i];
            indcnt += IntVectCnt[i];
        }
    }

    // get heap space for work arrays
    try
    {
       ryy = new double *[depcnt];
       for (i = 0; i < depcnt; i++) ryy[i] = new double [depcnt];
       rxx = new double *[indcnt];
       for (i = 0; i < indcnt; i++) rxx[i] = new double [indcnt];
       ryx = new double *[depcnt];
       for (i = 0; i < depcnt; i++) ryx[i] = new double [indcnt];
       rxy = new double *[indcnt];
       for (i = 0; i < indcnt; i++) rxy[i] = new double [depcnt];
       ryyinv = new double *[depcnt];
       for (i = 0; i < depcnt; i++) ryyinv[i] = new double [depcnt];
       rxxinv = new double *[indcnt];
       for (i = 0; i < indcnt; i++) rxxinv[i] = new double [indcnt];
       rmat = new double *[matsize];
       for (i = 0; i < matsize; i++) rmat[i] = new double[matsize];
       inversemat = new double *[matsize];
       for (i = 0; i < matsize; i++) inversemat[i] = new double[matsize];
       WorkMat = new double *[matsize];
       for (i = 0; i < matsize; i++) WorkMat[i] = new double[matsize];
       eigenvectors = new double *[matsize];
       for (i = 0; i < matsize; i++) eigenvectors[i] = new double[matsize];
       RxxINVxRxy = new double *[matsize];
       for (i = 0; i < matsize; i++) RxxINVxRxy[i] = new double[matsize];
       RyyINVxRyx = new double *[matsize];
       for (i = 0; i < matsize; i++) RyyINVxRyx[i] = new double[matsize];
       char_equation = new double *[matsize];
       for (i = 0; i < matsize; i++) char_equation[i] = new double[matsize];
       eigentrans = new double *[matsize];
       for (i = 0; i < matsize; i++) eigentrans[i] = new double[matsize];
       theta = new double *[matsize];
       for (i = 0; i < matsize; i++) theta[i] = new double[matsize];
       raw_y = new double *[matsize];
       for (i = 0; i < matsize; i++) raw_y[i] = new double[matsize];
       norm_y = new double *[matsize];
       for (i = 0; i < matsize; i++) norm_y[i] = new double[matsize];
       raw_x = new double *[matsize];
       for (i = 0; i < matsize; i++) raw_x[i] = new double[matsize];
       norm_x = new double *[matsize];
       for (i = 0; i < matsize; i++) norm_x[i] = new double[matsize];
       y_cors = new double *[matsize];
       for (i = 0; i < matsize; i++) y_cors[i] = new double[matsize];
       x_cors = new double *[matsize];
       for (i = 0; i < matsize; i++) x_cors[i] = new double[matsize];
       pcnt_trace = new double[matsize];
       roots = new double [matsize];
       Means = new double[matsize];
       Variances = new double[matsize];
       StdDevs = new double[matsize];
       tvalues = new double[matsize];
       probs = new double[matsize];
       ColNoSelected = new int[matsize];
       pv_y = new double [matsize];
       rd_y = new double [matsize];
       pv_x = new double [matsize];
       rd_x = new double [matsize];
       root_chi = new double[matsize];
       root_df = new int[matsize];
       chi_prob = new double[matsize];
    }
    catch (...)
    {
        Application->MessageBox("MEMORY ERROR!","Out of memory in GLM",MB_OK);
    }

    // get full correlation matrix
    for (i = 0; i < matsize-1; i++) ColNoSelected[i] = i+1;
    GetCorrs(Means,StdDevs,rmat,matsize-1,ColNoSelected,NoCases,prtopts,3);

    // partition correlation matrix into quadrants
    for (i = 0; i < depcnt; i++)
    {  // ryy is the correlation among dependent variables
        for (j = 0; j < depcnt; j++) ryy[i][j] = rmat[i][j];
        ColNoSelected[i] = i+1;
    }
    if (correlations)
        MPrint(ryy,depcnt,depcnt,ColNoSelected,"Dependent Variable Correlation Matrix");

    if (!mancova)
    {
        for (i = 0; i < indcnt; i++)
        {  // rxx is the correlation among independent variables
            for (j = 0; j < indcnt; j++) rxx[i][j] = rmat[i+depcnt][j+depcnt];
            ColNoSelected[i] = i+1+depcnt;
        }
        if (correlations)
        {
            MPrint(rxx,indcnt,indcnt,ColNoSelected,"Independent Variable Correlation Matrix");
            FrmOutPut->RichOutPut->Lines->Add("");
        }
    }
    else // copy only the covariates at this step for mancova
    {
        for (i = 0; i < NoCov; i++)
        {   // rxx is the correlation among covariates
            for (j = 0; j < NoCov; j++) rxx[i][j] = rmat[i+depcnt][j+depcnt];
            ColNoSelected[i] = i+1+depcnt;
        }
        if (correlations)
        {
            MPrint(rxx,NoCov,NoCov,ColNoSelected,"Covariate Correlation Matrix");
            FrmOutPut->RichOutPut->Lines->Add("");
        }
    }

    for (i = 0; i < depcnt; i++)
    {
       RowLabels[i] = GLMGridFrm->Grid->Cells[i+1][0]; // dependent variables
       if (!mancova)
       {
           for (j = 0; j < indcnt; j++)
           {
               ryx[i][j] = rmat[i][j+depcnt];
               rxy[j][i] = ryx[i][j];
               ColLabels[j] = GLMGridFrm->Grid->Cells[j+1+depcnt][0]; // indep. vars.
           }
       }
       else // dependent-covariate intercorrelations
       {
           for (j = 0; j < NoCov; j++)
           {
               ryx[i][j] = rmat[i][j+depcnt];
               rxy[j][i] = ryx[i][j];
               ColLabels[j] = GLMGridFrm->Grid->Cells[j+1+depcnt][0]; // cov. vars.
           }
       }
    }

    if (!mancova)
    {
        if (correlations)
        {
            ArrayPrint(ryx,depcnt,indcnt,"Dependent",RowLabels,ColLabels,"Dep.-Indep. Correlation Matrix");
            FrmOutPut->ShowModal();
        }
    }
    else
    {
        if (correlations)
        {
            ArrayPrint(ryx,depcnt,NoCov,"Dependent",RowLabels,ColLabels,"Dep.-Covariate Correlation Matrix");
            FrmOutPut->ShowModal();
        }
    }
//    int oldindcnt = indcnt;
    if (mancova) indcnt = NoCov;
    //  invert left and right matrices
     for (i = 0; i < depcnt; i++)
         for (j = 0; j < depcnt; j++) WorkMat[i+1][j+1] = ryy[i][j];
     matinv(WorkMat,depcnt,inversemat,eigenvectors,roots);
     for (i = 0; i < depcnt; i++)
         for (j = 0; j < depcnt; j++) ryyinv[i][j] = inversemat[i+1][j+1];
     for (i = 0; i < depcnt; i++) ColNoSelected[i] = i+1;
    if (correlations)
        MPrint(ryyinv,depcnt,depcnt,ColNoSelected,"Dependent Var. Correlation Matrix Inverse");
     for (i = 0; i < indcnt; i++)
         for (j = 0; j < indcnt; j++) WorkMat[i+1][j+1] = rxx[i][j];
     matinv(WorkMat,indcnt,inversemat,eigenvectors,roots);
     for (i = 0; i < indcnt; i++)
         for (j = 0; j < indcnt; j++) rxxinv[i][j] = inversemat[i+1][j+1];
     for (i = 0; i < indcnt; i++) ColNoSelected[i] = i+1+depcnt;
    if (correlations)
        MPrint(rxxinv,indcnt,indcnt,ColNoSelected,"Independent Correlation Matrix Inverse");
    FrmOutPut->ShowModal();

     // get products of ryyinv x ryx and the rxxinv x rxy matrix
     // RxxINVxRxy is product of independent variable inverse r mat times rxy
     // and is of size indcnt by depcnt
     // RyyINVxRyx is product of dependent inverse r mat times ryx
     // and is of size depcnt by indcnt
     MATAxB(RyyINVxRyx,ryyinv,ryx,depcnt,depcnt,depcnt,indcnt,errorcode);
     MATAxB(RxxINVxRxy,rxxinv,rxy,indcnt,indcnt,indcnt,depcnt,errorcode);
     if (correlations)
     {
         ArrayPrint(RyyINVxRyx,depcnt,indcnt,"Dep.Inv. x yx corr.s",RowLabels,ColLabels,"ryy-1 x ryx Matrices");
         FrmOutPut->RichOutPut->Lines->Add("");
         ArrayPrint(RxxINVxRxy,indcnt,depcnt,"Indep.Inv. x xy corr.s",ColLabels,RowLabels,"rxx-1 x rxy Matrices");
         FrmOutPut->ShowModal();
     }

     //get characteristic equations matrix (product of last two product matrices
     //The product should yeild rows and cols representing the smaller of the two sets
     int size;
     if (indcnt <= depcnt) size = indcnt;
     else size = depcnt;
     // Build labels for canonical functions
     for (i = 0; i < size; i++) CanLabels[i] = "Var. " + AnsiString(i+1);
     // clear array
     for (i = 0; i < size; i++)
         for (j = 0; j < size; j++) char_equation[i][j] = 0.0;
     MATAxB(char_equation,RyyINVxRyx,RxxINVxRxy,depcnt,indcnt,indcnt,depcnt,errorcode);
     if (correlations)
     {
             ArrayPrint(char_equation,depcnt,depcnt,"Canonical Functions",CanLabels,CanLabels,"Characteristic Equations Matrix");
             FrmOutPut->ShowModal();
     }

     //  now get roots and vectors of the characteristic equation using
     // NonSymRoots routine
     double minroot = 0.0;
     double trace;
     double pcnt_extracted = 0.0;

     for (i = 0; i < size; i++)
     {
         roots[i] = 0.0;
         pcnt_trace[i] = 0.0;
         for (j = 0; j < size; j++) eigenvectors[i][j] = 0.0;
     }
     trace = 0.0;
     int no_factors = size;
     nonsymroots(char_equation, depcnt, no_factors, minroot, eigenvectors, roots,\
                pcnt_trace, trace, pcnt_extracted);
     sprintf(outline,"Trace of the matrix = %10.4f",trace);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Percent of trace extracted: %10.4f",pcnt_extracted);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     ArrayPrint(eigenvectors,size,size,"Eigenvectors",CanLabels,CanLabels,"Eigenvectors in Columns");
     FrmOutPut->ShowModal();

     MATTRN(eigentrans,eigenvectors,depcnt,depcnt);
     MATAxB(WorkMat,eigentrans,ryy,depcnt,depcnt,depcnt,depcnt,errorcode);
     MATAxB(theta,WorkMat,eigenvectors,depcnt,depcnt,depcnt,depcnt,errorcode);
     for (j = 0; j < depcnt; j++) // solve for Y weights
     {
         q = 1.0 / sqrt(theta[j][j]);
         for (i = 0; i < depcnt; i++)
         {
             norm_y[i][j] = eigenvectors[i][j] * q; // normalized independent
             raw_y[i][j] = norm_y[i][j] / StdDevs[i];
         }
     }
     // now solve for normalized independent variable coeeficients
     MATAxB(norm_x,RxxINVxRxy,norm_y,indcnt,depcnt,depcnt,depcnt,errorcode);
     for (j = 0; j < depcnt; j++)
     {
         for (i = 0; i < indcnt; i++)
         {
             norm_x[i][j] *= (1.0 / sqrt(roots[j]));
             raw_x[i][j] = norm_x[i][j] / StdDevs[depcnt+i];
         }
     }
     ArrayPrint(norm_y,depcnt,size,"Weights",RowLabels,CanLabels,"Standardized Dependent Variable Weights");
     ArrayPrint(norm_x,indcnt,size,"Weights",ColLabels,CanLabels,"Standardized Independent Variable Weights");
     FrmOutPut->ShowModal();
     ArrayPrint(raw_y,depcnt,size,"Weights",RowLabels,CanLabels,"Raw Dependent Variable Weights");
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(raw_x,indcnt,size,"Weights",ColLabels,CanLabels,"Raw Independent Variable Weights");
     FrmOutPut->ShowModal();

     // Compute the correlations between variables and canonical variables
     // first, the correlations of dependent variables with dependent
     // canonical variables (structure coefficients)
     MATAxB(y_cors,ryy,norm_y,depcnt,depcnt,depcnt,indcnt,errorcode); //depcnt x indcnt
     for (j = 0; j < indcnt; j++)
     {
         q = 0.0;
         for (i = 0; i < depcnt; i++) q = q + norm_y[i][j] * y_cors[i][j];
         if (q > 0)
         {
             q = 1.0 / sqrt(q);
             for (i = 0; i < depcnt; i++) y_cors[i][j] *= q;
         }
         else
         {
             for (i = 0; i < depcnt; i++) y_cors[i][j] = 0.0;
         }
     }
     // Now the structure coefficients for the independent variables
     MATAxB(x_cors,rxx,norm_x,indcnt,indcnt,indcnt,depcnt,errorcode);
     for (j = 0; j < depcnt; j++)
     {
         q = 0.0;
         for (i = 0; i < indcnt; i++) q += norm_x[i][j] * x_cors[i][j];
         if (q > 0)
         {
             q = 1.0 / sqrt(q);
             for (i = 0; i < indcnt; i++) x_cors[i][j] *= q;
         }
         else
         {
             for (i = 0; i < indcnt; i++) x_cors[i][j] = 0.0;
         }
     }
     ArrayPrint(y_cors,depcnt,size,"Canonical Variables",RowLabels,CanLabels,"Dependent Variable Correlations with Function");
     FrmOutPut->RichOutPut->Lines->Add("");
     ArrayPrint(x_cors,indcnt,size,"Canonical Variables",ColLabels,CanLabels,"Independent Variable Correlations with Function");
     FrmOutPut->ShowModal();

     // Compute the Proportions of Variance (PVs) and Redundancy Coefficients
     // Redundancy for dependent variables
     for (j = 0; j < indcnt; j++)
     {
         pv_y[j] = 0.0;
         for (i = 0; i < depcnt; i++) pv_y[j] += (y_cors[i][j]*y_cors[i][j]);
         pv_y[j] /= depcnt;
         rd_y[j] = pv_y[j] * roots[j];
     }
     // Redundancy for independent variables
     for (j = 0; j < depcnt; j++)
     {
         pv_x[j] = 0.0;
         for (i = 0; i < indcnt; i++) pv_x[j] += (x_cors[i][j]*x_cors[i][j]);
         pv_x[j] /= indcnt;
         rd_x[j] = pv_x[j] * roots[j];
     }
     sprintf(outline,"Redundancy Analysis for Dependent Variables");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("  Raw Variance Explained");
     sprintf(outline,"            Proportion       Redundancy");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 0; i < depcnt; i++)
     {
         sprintf(outline,"%10s %10.5f     %10.5f",RowLabels[i].c_str(),pv_y[i],rd_y[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Redundancy Analysis for Independent Variables");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("  Raw Variance Explained");
     sprintf(outline,"            Proportion       Redundancy");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 0; i < indcnt; i++)
     {
         sprintf(outline,"%10s %10.5f     %10.5f",ColLabels[i].c_str(),pv_x[i],rd_x[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->ShowModal();

     // Compute tests of the roots
     double w;
     q = depcnt + indcnt + 1;
     q = -(double(NoCases) - 1.0 - (q / 2.0));
     k = 0;
     for (i = 0; i < size; i++)
     {
         w = 1.0;
         for (j = i; j < size; j++) w *= (1.0 - roots[j]);
         root_chi[i] = q * log(w);
         root_df[i] = (depcnt - i) * (indcnt - i);
         chi_prob[i] = 1.0-chisquaredprob(root_chi[i],root_df[i]);
//         if (chi_prob[i] < 0.05) k = k + 1;
     }
     double Roys;
     double Hroot;
     double Lambda = 0.0;
     double Pillia = 0.0;
     double HLTrace = 0.0;
     Roys = roots[0] / (1.0 - roots[0]);
     Lambda = 1.0;
     for (i = 0; i < size; i++)
     {
         Hroot = roots[i] / (1.0 - roots[i]);
         Lambda *= (1.0 / (1.0 + Hroot));
         Pillia += (Hroot / (1.0 + Hroot));
         HLTrace += Hroot;
     }

     // Print remaining results
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"   Canonical R   Root  % Trace   Chi-Sqr    D.F.    Prob.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 0; i < size; i++)
     {
         sprintf(outline,"%2d %10.6f %8.3f %7.3f %8.3f      %2d %8.3f",\
          i+1, sqrt(roots[i]), roots[i], pcnt_trace[i], root_chi[i], root_df[i], chi_prob[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     double chisqr;
     chisqr = -log(Lambda) * (double(NoCases) - 1.0 - 0.5*(double(depcnt + indcnt) - 1.0));
     double chiprob;
     chiprob = 1.0 - chisquaredprob(chisqr,depcnt*indcnt);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Overall Tests of Significance:");
     FrmOutPut->RichOutPut->Lines->Add("         Statistic      Approx. Stat.   Value   D.F.  Prob.>Value");
     sprintf(outline,"Wilkes Lambda           Chi-Squared %10.4f  %3d   %6.4f", chisqr,depcnt*indcnt,chiprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     double s = double(size);
     double m, n, f, df1, df2;
     if (indcnt < depcnt) m = 0.5 * double(depcnt - indcnt - 1);
     else m = 0.5 * double(indcnt - depcnt - 1);
     n = 0.5 * double(NoCases - indcnt - depcnt - 2);
     f = (HLTrace * 2.0 * (s * n + 1)) / (s * s * (2.0 * m + s + 1.0));
     df1 = s * (2.0 * m + s + 1.0);
     df2 = 2.0 * ( s * n  + 1.0);
     double ftestprob = ftest(df1,df2,f);
     sprintf(outline,"Hotelling-Lawley Trace  F-Test      %10.4f %2d %2d  %6.4f", f, int(df1),int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     df2 = s * (2.0 * n + s + 1.0);
     f = (Pillia / (s - Pillia)) * ( (2.0 * n + s +1.0) / (2.0 * m + s + 1.0) );
     ftestprob = ftest(df1,df2,f);
     sprintf(outline,"Pillia Trace            F-Test      %10.4f %2d %2d  %6.4f", f, int(df1),int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if (indcnt > depcnt)
     {
         Roys *= double(NoCases - 1 - depcnt + indcnt)/double(depcnt);
         df1 = double(depcnt);
         df2 = double(NoCases - 1 - depcnt + indcnt);
     }
     else
     {
         Roys *= double(NoCases - 1 - indcnt + depcnt) / double(indcnt);
         df1 = double(depcnt);
         df2 = double(NoCases - 1 - indcnt + depcnt);
     }
     ftestprob = ftest(df1,df2,Roys);
     sprintf(outline,"Roy's Largest Root      F-Test      %10.4f %2d %2d  %6.4f", Roys, int(df1), int(df2), ftestprob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();
    // Now, if mancova is needed, obtain canonical scores for the Y variables
    // and do a manova for the groups
    if (mancova)
    {
        GLMGridFrm->Grid->ColCount = GLMGridFrm->Grid->ColCount + (size*2);
        double X;
        double z;
        for (j = 0; j < size; j++)
        {
            sprintf(outline,"DepCanZ%d",j+1);
            GLMGridFrm->Grid->Cells[matsize+j][0] = outline;
            sprintf(outline,"CovCanZ%d",j+1);
            GLMGridFrm->Grid->Cells[matsize+size+j][0] = outline;
        }
        // Add the canonical scores to the GLM grid.
        for (i = 0; i < NoCases; i++)
        {
            for (j = 0; j < size; j++) // dependent canonical variable
            {
                z = 0.0; // for summing weighted z scores
                for (k = 0; k < depcnt; k++) // each dependent variable
                {
                    X = atof(GLMGridFrm->Grid->Cells[k+1][i+1].c_str());
                    X = (X - Means[k]) / StdDevs[k];
                    X *= norm_y[k][j];
                    z += X;
                }
                sprintf(outline,"%6.3f",z);
                GLMGridFrm->Grid->Cells[matsize+j][i+1] = outline;
            }
            // Now do covariate canonical variates
            for (j = 0; j < size; j++) // independent canonical functions
            {
                z = 0.0;
                for (k = 0; k < indcnt; k++)
                {
                    X = atof(GLMGridFrm->Grid->Cells[depcnt+k+1][i+1].c_str());
                    X = (X - Means[k+depcnt]) / StdDevs[k+depcnt];
                    X *= norm_x[k][j];
                    z += X;
                }
                sprintf(outline,"%6.3f",z);
                GLMGridFrm->Grid->Cells[matsize+size+j][i+1] = outline;
            }
        }
        GLMGridFrm->ShowModal();
    }

    if (mancova)
    {
        // Now do canonical analyis of groups vectors using the DepCanz scores
    }

    // cleanup the heap
    delete[] chi_prob;
    delete[] root_df;
    delete[] root_chi;
    delete[] rd_x;
    delete[] pv_x;
    delete[] rd_y;
    delete[] pv_y;
    delete[] ColNoSelected;
    delete[] probs;
    delete[] tvalues;
    delete[] StdDevs;
    delete[] Variances;
    delete[] Means;
    delete[] roots;
    delete[] pcnt_trace;
    for (i = 0; i < matsize; i++) delete[] x_cors[i];
    delete[] x_cors;
    for (i = 0; i < matsize; i++) delete[] y_cors[i];
    delete[] y_cors;
    for (i = 0; i < matsize; i++) delete[] norm_x[i];
    delete[] norm_x;
    for (i = 0; i < matsize; i++) delete[] raw_x[i];
    delete[] raw_x;
    for (i = 0; i < matsize; i++) delete[] norm_y[i];
    delete[] norm_y;
    for (i = 0; i < matsize; i++) delete[] raw_y[i];
    delete[] raw_y;
    for (i = 0; i < matsize; i++) delete[] theta[i];
    delete[] theta;
    for (i = 0; i < matsize; i++) delete[] eigentrans[i];
    delete[] eigentrans;
    for (i = 0; i < matsize; i++) delete[] char_equation[i];
    delete[] char_equation;
    for (i = 0; i < matsize; i++) delete[] RyyINVxRyx[i];
    delete[] RyyINVxRyx;
    for (i = 0; i < matsize; i++) delete[] RxxINVxRxy[i];
    delete[] RxxINVxRxy;
    for (i = 0; i < matsize; i++) delete[] eigenvectors[i];
    delete[] eigenvectors;
    for (i = 0; i < matsize; i++) delete[] WorkMat[i];
    delete[] WorkMat;
    for (i = 0; i < matsize; i++) delete[] inversemat[i];
    delete[] inversemat;
    for (i = 0; i < matsize; i++) delete[] rmat[i];
    delete[] rmat;
    for (i = 0; i < depcnt; i++) delete[] ryyinv[i];
    delete[] ryyinv;
    for (i = 0; i < indcnt; i++) delete[] rxxinv[i];
    delete[] rxxinv;
    for (i = 0; i < indcnt; i++) delete[] rxy[i];
    delete[] rxy;
    for (i = 0; i < depcnt; i++) delete[] ryx[i];
    delete[] ryx;
    for (i = 0; i < indcnt; i++) delete[] rxx[i];
    delete[] rxx;
    for (i = 0; i < depcnt; i++) delete[] ryy[i];
    delete[] ryy;
}
//---------------------------------------------------------------------------

int GetCorrs(double *means, double *stddevs, double **corr,
             int NoSelected, int *ColNoSelected, int NSUBS, int prtopts,
             int mattype)
{
    // Computes the correlation matrix
    // and the means and standard deviations of the NoSelected variables read
    // from the grid where the NoSelected variables are selected from grid
    // columns stored in ColNoSelected.  Results are returned in the vector
    // corr.
    // If mattype = 1, raw cross-products are returned.
    // If mattype = 2, covariances are returned.
    // If mattype = 3, correlations returned.
    // If prtopts = 0, no printing desired.
    // If prtopts = 1, means, standard deviations and matrix are printed.
    // If prtopts = 2, only the matrix is printed.
    // If prtopts = 3, only means and standard deviations are printed.

    int IER = 0, colx, coly, count = 0;
    double X, Y;
    char outline[121];

    // Initialize arrays
    for (int i = 0; i < NoSelected; i++)
    {
        means[i] = 0.0;
        stddevs[i] = 0.0;
        for (int j = 0; j < NoSelected; j++) corr[i][j] = 0.0;
    }

    for (int i = 0; i < NSUBS; i++)
    {
        if (FilterOn)
           if (GLMGridFrm->Grid->Cells[FilterCol][i+1] == "NO") continue;
        count++;
        for (int j = 0; j < NoSelected; j++)
        {
            colx = ColNoSelected[j];
            X = atof(GLMGridFrm->Grid->Cells[colx][i+1].c_str());
            means[j] += X;
            for (int k = 0; k < NoSelected; k++)
            {
                coly = ColNoSelected[k];
                Y = atof(GLMGridFrm->Grid->Cells[coly][i+1].c_str());
                corr[j][k] += (X * Y);
            }
        }
    }

    if (mattype == 1) // raw cross-products wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            MPrint(corr, NoSelected, NoSelected, ColNoSelected,
                     "Raw Cross-Products Matrix");
        for (int i = 0; i < NoSelected; i++) // get std. dev.s
        {
            stddevs[i] = corr[i][i] - (means[i] * means[i] / double(count));
            stddevs[i] /= double(count-1);
            if (stddevs[i] > 0.0) stddevs[i] = sqrt(stddevs[i]);
            else stddevs[i] = 0.0;
        }
        for (int i = 0; i < NoSelected; i++) // get means
            means[i] /= double(count);
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            vprint(means, ColNoSelected, NoSelected,"Means");
            vprint(stddevs, ColNoSelected, NoSelected,"Standard Deviations");
        }
        return (IER);
    }

    // get variance-covariance matrix (deviation cross-products)
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            corr[i][j] -= means[i] * means[j] / double(count);
            corr[i][j] /= double(count - 1);
        }
    }

    // Since diagonal values are variances, grab them
    for (int i = 0; i < NoSelected; i++)
    {
        stddevs[i] = corr[i][i]; // variances on diagonal
        if (stddevs[i] <= 0.0) IER = 1;
    }

    // Divide sums to get means and square root of variances for std. dev.'s
    for (int i = 0; i < NoSelected; i++)
    {
        means[i] /= double(count);
        if (stddevs[i] > 0.0) stddevs[i] = sqrt(stddevs[i]);
        else stddevs[i] = 0.0;
    }

    if (mattype == 2) // covariance matrix wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            MatPrint(corr, NoSelected, NoSelected, ColNoSelected,
                     "Deviation Cross-Products Matrix");
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            vprint(means, ColNoSelected, NoSelected,"Means");
            vprint(stddevs, ColNoSelected, NoSelected,"Standard Deviations");
        }
        return (IER);
    }

    // Get correlations
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
        {
            if ((stddevs[i] > 0.0) && (stddevs[j] > 0.0))
                corr[i][j] /= (stddevs[i] * stddevs[j]);
            else
            {
                corr[i][j] = 0.0;
                IER = 1;
            }
        }
    if (mattype == 3) // correlations wanted
    {
        if((prtopts == 1) || (prtopts == 2)) // print the matrix
            MPrint(corr, NoSelected, NoSelected, ColNoSelected,
                     "Correlation Matrix");
        if ((prtopts == 1)||(prtopts == 3)) // print means and standard deviations
        {
            vprint(means, ColNoSelected, NoSelected,"Means");
            vprint(stddevs, ColNoSelected, NoSelected,"Standard Deviations");
        }
    }
    sprintf(outline,"Results based on a total of %d observations.",count);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();
    return (IER);
}
//--------------------------------------------------------------------------

void MPrint(double **Matrix, int Nrows, int Ncols, int *selected, char *Title)
{
	char outline[121];
   char valstring[121];
   int startvar;
   int endvar;
   bool done;

   sprintf(outline,"\n\n");
   FrmOutPut->RichOutPut->Lines->Add(outline);
   sprintf(outline,"%s\n",Title);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   startvar = 0;
   endvar = Ncols-1;
   done = false;
   do
   {
        if (endvar - startvar + 1 > 6) endvar = startvar + 5;
        if (endvar == Ncols -1) done = true;
        strcpy(outline,"");
        strcat(outline,"Variables ");
        // Build column labels
        for (int i = startvar; i <= endvar; i++)
        {
            sprintf(valstring,"%10s ",GLMGridFrm->Grid->Cells[selected[i]][0].c_str());
            strcat(outline,valstring);
        }
        strcat(outline,"\n");
        FrmOutPut->RichOutPut->Lines->Add(outline);

        // Print matrix rows for columns startvar to endvar
        for (int i = 0; i < Nrows; i++)
        {
            strcpy(outline,"");
            sprintf(valstring,"%10s ",GLMGridFrm->Grid->Cells[selected[i]][0].c_str());
            strcat(outline,valstring);
            for (int j = startvar; j <= endvar; j++)
            {
                sprintf(valstring,"%10.3f ",Matrix[i][j]);
                strcat(outline,valstring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        startvar = endvar + 1;
        endvar = Ncols-1;
   } while (!done);

}
//-------------------------------------------------------------------------

void vprint(double *vector, int *selected, int Ncols, char *Title)
{
	char outline[121];
    char valstring[121];
    int startvar;
    int endvar;
    bool done;

    sprintf(outline,"%s\n",Title);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    startvar = 0;
    endvar = Ncols-1;
    done = false;
    do
    {
        if (endvar - startvar + 1 > 6) endvar = startvar + 5;
        if (endvar == Ncols -1) done = true;
        strcpy(outline,"");
        strcat(outline,"Variables ");
        // Build column labels
        for (int i = startvar; i <= endvar; i++)
        {
            sprintf(valstring,"%10s ",GLMGridFrm->Grid->Cells[selected[i]][0].c_str());
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);

        // Print vector for columns startvar to endvar
        strcpy(outline,"");
        sprintf(valstring,"          ");
        strcat(outline,valstring);
        for (int j = startvar; j <= endvar; j++)
        {
            sprintf(valstring,"%10.3f ",vector[j]);
            strcat(outline,valstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        startvar = endvar + 1;
        endvar = Ncols-1;
    }	while (!done);
}
//-------------------------------------------------------------------------

double ShowStep(int NoIndep, double **InverseMat, double *rxy, double *W,
     int *indx, double *Means, double *Variances, double *StdDevs,
     int count, double OldR2, int OldNoIndep )
{
    double R2, SSt, SSres, MSres, VarEst, StdErrEst, SSModel, F, ProbF;
    double df1, df2, constant, SSx, StdErrB, B, beta, SS;
    int i, j;
    char outline[121];
    char valstring[121];

        // Multiply inverse times Rxy vector and store in betas vector
		R2 = 0.0;
        for (i = 0; i < NoIndep; i++) // rows
        {
        	W[i] = 0.0;
        	for (j = 0; j < NoIndep; j++) // columns
            {
                W[i] += (InverseMat[i][j] * rxy[j]);
            }
            R2 = R2 + W[i] * rxy[i];
        }
        // Compute B's, constant, std. errors, t's and probabilities of t's.
        df1 = NoIndep;
        df2 = count - NoIndep - 1;
        SSt = double(count-1) * Variances[0];
        SSres = SSt * (1.0 - R2);
        MSres = SSres / df2;
        VarEst = SSres / df2;
        StdErrEst = sqrt(VarEst);
        SSModel = SSt - SSres;
        if (R2 >= 1.0) F = 1000;
        else F = (R2 / df1) / ((1.0-R2)/ df2);
        ProbF = ftest(df1,df2,F);
        sprintf(outline,"                      Analysis of Variance");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Source     DF        SS        MS        F         Prob>F");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Model     %3d       %9.3f %9.3f %9.4f %9.4f",NoIndep,SSModel,\
             SSModel / df1, F, ProbF);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Error     %3.0f       %9.3f %9.3f",df2,SSres,VarEst);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Total     %3d       %9.3f",count-1,SSt);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
//        sprintf(outline,"\n%10s%8s%10s%10s%12s%5s%5s","Variable","R","R2",\
//        		"F","Prob.>F","DF1","DF2");
//        FrmOutPut->RichOutPut->Lines->Add(outline);
//        sprintf(valstring,"%10s",GLMGridFrm->Grid->Cells[indx[0]][0].c_str());
//        sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%5.0f%5.0f\n",\
//                       		valstring,sqrt(R2),R2,F,ProbF,df1,df2);
//        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Std. Error of Estimate = %10.3f\n",StdErrEst);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add\
            ("Variable       Beta      B         Std.Error t         Prob.>t");
        df1 = 1.0;
        df2 = count - NoIndep - 1;
        constant=0.0;
//        double StdErrCnst = sqrt(Variances[NoIndep] / NoCases);
        for (int i = 0; i < NoIndep; i++)
        {
        	beta = W[i];
            B = beta * StdDevs[0] / StdDevs[i+1];
            constant += B * Means[i+1];
            SSx = double(count-1) * Variances[i+1];
            StdErrB = sqrt(VarEst / (SSx * (1.0 / InverseMat[i][i])));
            if (StdErrB > 0) F = B / StdErrB;
            else F = 1000;
            ProbF = ftest(df1,df2,F*F);
            sprintf(valstring,"%10s",GLMGridFrm->Grid->Cells[indx[i]][0].c_str());
            sprintf(outline,"%10s%10.3f%10.3f%10.3f%10.3f%10.3f",\
                            	valstring, beta ,B, StdErrB, F, ProbF);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        constant = Means[0] - constant;
        //sprintf(outline,"Constant  %20.3f%10.3f",constant,StdErrCnst);
        sprintf(outline,"Constant  %20.3f",constant);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        //Show SS for each predictor
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Increments in Total Sum of Squares Due to Each Variable");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Source        DF  TypeIII SS   F      Prob>F");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 0; i < NoIndep; i++)
        {
            SS = (W[i]*W[i]) / (InverseMat[i][i]) * SSt;
            if (MSres > 0) F = SS / MSres;
            else F = 1000.0;
            ProbF = ftest(1,df2,F);
            sprintf(valstring,"%10s",GLMGridFrm->Grid->Cells[indx[i]][0].c_str());
            sprintf(outline,"%10s     %1d %9.4f %9.4f %7.4f",valstring,1,SS,F,ProbF);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
	    // Show change in R2 over old R2 and its significance. Place R2 into OldR2
        if ((R2 > OldR2) && (NoIndep > OldNoIndep))
        {
        	df1 = NoIndep - OldNoIndep;
        	if (R2 < 1.0) F = ((R2 - OldR2)/ df1 ) / ((1.0 - R2) / df2);
            else F = 1000.0;
            ProbF = ftest(df1,df2,F);
            sprintf(outline,"\nIncrease in R2   F         Prob.>F   DF1       DF2");
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"%10.3f%10.3f%13.3f%5.0f%10.0f",(R2-OldR2),F,ProbF,\
                     df1, df2);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            OldNoIndep = NoIndep;
            OldR2 = R2;
        }
        FrmOutPut->ShowModal();
        return (R2);
}
//--------------------------------------------------------------------------


void __fastcall TGLMFrm1::ShowModBtnClick(TObject *Sender)
{
     AnsiString Label;

     if (ListBox2->Items->Count == 0) // dependent variables selected?
     {
        Application->MessageBox("First select the variables for the analysis.","ERROR",MB_OK);
        return;
     }
     if (ListBox2->Items->Count > 1) // multiple dependent variables
     {
//         ModelEdit->Text = "g( ";
         if (NoContDep > 0)
         {
             for (int i = 0; i < NoContDep; i++)
             {
                 ModelEdit->Text = ModelEdit->Text + DepAbrevList->Items->Strings[i];
                 if (i+1 < NoContDep)
                     ModelEdit->Text = ModelEdit->Text + " + ";
             }
         }
         if (NoCatDep > 0)
         {
             if (NoContDep > 0) ModelEdit->Text = ModelEdit->Text + " + ";
             for (int i = 0; i < NoCatDep; i++)
             {
                 ModelEdit->Text = ModelEdit->Text + CatDepAbbrevList->Items->Strings[i];
                 if (i+1 < NoCatDep)
                     ModelEdit->Text = ModelEdit->Text + " + ";
             }
         }
         ModelEdit->Text = ModelEdit->Text + " = ";
     }
     else ModelEdit->Text = "Y = ";

     if (FixedAbrevList->Items->Count > 0) // fixed effects entered
     {
         for (int i = 0; i < FixedAbrevList->Items->Count; i++)
         {
             ModelEdit->Text = ModelEdit->Text + FixedAbrevList->Items->Strings[i];
             ModelEdit->Text = ModelEdit->Text + " + ";
         }
     }

     if (RndAbrevList->Items->Count > 0) // Random effects entered
     {
         for (int i = 0; i < RndAbrevList->Items->Count; i++)
         {
             ModelEdit->Text = ModelEdit->Text + RndAbrevList->Items->Strings[i];
             ModelEdit->Text = ModelEdit->Text + " + ";
         }
     }

     if (CovAbrevList->Items->Count > 0) // covariates entered
     {
         for (int i = 0; i < CovAbrevList->Items->Count; i++)
         {
             ModelEdit->Text = ModelEdit->Text + CovAbrevList->Items->Strings[i];
             ModelEdit->Text = ModelEdit->Text + " + ";
         }
     }

     if (InterAbrevList->Items->Count > 0) // interaction effects entered
     {
         for (int i = 0; i < InterAbrevList->Items->Count; i++)
         {
             ModelEdit->Text = ModelEdit->Text + InterAbrevList->Items->Strings[i];
             ModelEdit->Text = ModelEdit->Text + " + ";
         }
     }

     ModelEdit->Text = ModelEdit->Text + "e";
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::StrtInterBtnClick(TObject *Sender)
{
     InterStart = true;
     InterTerm = "";
     NoTerms = 0;
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::FixedAbrevListClick(TObject *Sender)
{
    if (InterStart == false)
    {
       Application->MessageBox("To enter an interaction term, click Start Interaction",
           "ERROR",MB_OK);
       return;
    }
    int index = FixedAbrevList->ItemIndex;
    if (index >= 0)
    {
        InterTerm = InterTerm + FixedAbrevList->Items->Strings[index];
        IntFixNo[IntVarCnt][NoTerms] = index;
        InterTerm = InterTerm + "*";
        IntTermType[IntVarCnt][NoTerms] = 1; // fixed type term
        NoTerms++;
    }
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::RndAbrevListClick(TObject *Sender)
{
    if (InterStart == false)
    {
       Application->MessageBox("To enter an interaction term, click Start Interaction",
           "ERROR",MB_OK);
       return;
    }
    int index = RndAbrevList->ItemIndex;
    if (index >= 0)
    {
        InterTerm = InterTerm + RndAbrevList->Items->Strings[index];
        IntRndNo[IntVarCnt][NoTerms] = index;
        InterTerm = InterTerm + "*";
        IntTermType[IntVarCnt][NoTerms] = 2; // random type term
        NoTerms++;

    }
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::CovAbrevListClick(TObject *Sender)
{
    if (InterStart == false)
    {
       Application->MessageBox("To enter an interaction term, click Start Interaction",
           "ERROR",MB_OK);
       return;
    }
    int index = CovAbrevList->ItemIndex;
    if (index >= 0)
    {
        InterTerm = InterTerm + CovAbrevList->Items->Strings[index];
        InterTerm = InterTerm + "*";
        IntCovNo[IntVarCnt][NoTerms] = index;
        IntTermType[IntVarCnt][NoTerms] = 3; // covariate type term
        NoTerms++;
    }
}
//---------------------------------------------------------------------------


void __fastcall TGLMFrm1::EndInterBtnClick(TObject *Sender)
{
     // eliminate * at end of string
     int howlong = InterTerm.Length()-1;
     InterTerm = InterTerm.SubString(1,howlong);
     InterAbrevList->Items->Add(InterTerm);
     InterTerm = "";
     InterStart = false;
     IntTermCnt[IntVarCnt] = NoTerms;
     IntVarCnt++;
}
//---------------------------------------------------------------------------

void __fastcall TGLMFrm1::InterCoding(TObject *Sender)
{
    // This routine generates vector products from the fixed, random or covariate
    // vectors already generated in the GLMGridFrm.  Up to five terms
    // may be involved for up to 20 interactions.  The no. of interaction
    // items is stored in IntVarCnt.  For terms of an interaction from
    // fixed factors, the column of the first level vector is stored in
    // FixVectCols[i][0].  For random factors the column of the first
    // vector is stored in RndVectCols[i][0]. The 'i' in the last two
    // expressions refers to the ith factor.  The second column holds the
    // number of the vector for levels 1,...,No. of levels - 1;
    // For covariates, the starting position is the 2nd column in the grid.
    int i, j, k, L, M, N; // subscript variables
    int VectCol1, VectCol2, Levels1, Levels2,col1, col2;
    int NoIntVars;
    double X, Y;
    AnsiString cellstring1, cellstring2, string1, string2, Label;

    for (i = 0; i < IntVarCnt; i++) // interaction item
    {
        NoIntVars = 0;
        for (j = 0; j < IntTermCnt[i]-1; j++) // term j of the interaction
        {
            for (k = j+1; k < IntTermCnt[i]; k++) // term k of the interaction
            {
                if (IntTermType[i][j] == 1) // fixed type
                {
                    L = IntFixNo[i][j]; //fixed var. no.
                    VectCol1 = FixVectCols[L][0]; // col. of first fixed factor vector
                    Levels1 = FixedLevels[L];
                    cellstring1 = FixedAbrevList->Items->Strings[L];
                }
                if (IntTermType[i][j] == 2) // random type
                {
                    L = IntRndNo[i][j]; // random var. no.
                    VectCol1 = RndVectCols[L][0]; // col. of first Rnd. vector
                    Levels1 = RndLevels[L];
                    cellstring1 = RndAbrevList->Items->Strings[L];
                }
                if (IntTermType[i][j] == 3) // covariate
                {
                    L = IntCovNo[i][j]; // covariate var. no.
                    VectCol1 = CovVectCols[L]; // col. no. of covariate in glmgrid
                    Levels1 = 2;
                    cellstring1 = CovAbrevList->Items->Strings[L];
                }
                if (IntTermType[i][k] == 1) // fixed type
                {
                    L = IntFixNo[i][k]; //fixed var. no.
                    VectCol2 = FixVectCols[L][0]; // col. of first fixed factor vector
                    Levels2 = FixedLevels[L];
                    cellstring2 = FixedAbrevList->Items->Strings[L];
                }
                if (IntTermType[i][k] == 2) // random type
                {
                    L = IntRndNo[i][k]; // random var. no.
                    VectCol2 = RndVectCols[L][0]; // col. of first Rnd. vector
                    Levels2 = RndLevels[L];
                    cellstring2 = RndAbrevList->Items->Strings[L];
                }
                if (IntTermType[i][k] == 3) // covariate
                {
                    L = IntCovNo[i][k]; // covariate var. no.
                    VectCol2 = CovVectCols[L]; // col. no. of covariate in glmgrid
                    Levels2 = 2;
                    cellstring2 = CovAbrevList->Items->Strings[L];
                }
//                Application->MessageBox("OK","Got this far.",MB_OK);
                // Now generate product vectors.  Add a column to the grid
                // for each and store the column numbers used (startcol).
                for (L = 0; L < Levels1-1; L++)
                {
                    string1 = cellstring1 + (L+1);
                    for (M = 0; M < Levels2-1; M++)
                    {
                        string2 = cellstring2 + (M+1);
                        GLMGridFrm->Grid->ColCount++;
                        Label = string1 + "*";
                        Label = Label + string2;
                        GLMGridFrm->Grid->Cells[startcol][0] = Label;
                        IntVarCol[i][NoIntVars] = startcol;
                        for (N = 0; N < NoCases; N++)
                        {
                            col1 = VectCol1 + L;
                            col2 = VectCol2 + M;
                            X = atof(GLMGridFrm->Grid->Cells[col1][N+1].c_str());
                            Y = atof(GLMGridFrm->Grid->Cells[col2][N+1].c_str());
                            GLMGridFrm->Grid->Cells[startcol][N+1] = (X * Y);
                        } // next case
                        startcol++;
                        NoIntVars++;
                    } // next M level
                } // next L level
            } // next k term
        } // next j term
        IntVectCnt[i] = NoIntVars;
    } // next interaction variable
//    Application->MessageBox("OK","Got this far.",MB_OK);
} // end of procedure
//---------------------------------------------------------------------------


