//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "FUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFform *Fform;
//---------------------------------------------------------------------------
__fastcall TFform::TFform(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFform::FormShow(TObject *Sender)
{
        DF1Edit->Text = "";
        DF2Edit->Text = "";
        CumEdit->Text = "";
        PropGreater->Text = "";
        QEdit->Text = "";        
}
//---------------------------------------------------------------------------
void __fastcall TFform::ComputeBtnClick(TObject *Sender)
{
        double cumprob;
        double probgreater;
        double DF1, DF2, Q;

        Q = StrToFloat(QEdit->Text);
        DF1 = StrToFloat(DF1Edit->Text);
        DF2 = StrToFloat(DF2Edit->Text);
        cumprob = ftest(DF1,DF2,Q);
        probgreater = 1.0 - cumprob;
        CumEdit->Text = FloatToStr(probgreater);
        PropGreater->Text = FloatToStr(cumprob);

}
//---------------------------------------------------------------------------
