//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "MemMgrUnit.h"
#include "BestRegUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBestRegForm *BestRegForm;
extern int NoCases;
extern int NoVariables;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TBestRegForm::TBestRegForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     SelList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     MatInChk->Checked = false;
     SaveCorrsChk->Checked = false;
     PredictChk->Checked = false;
     CrossProdChk->Checked = false;
     CovarChk->Checked = false;
     CorrsChk->Checked = false;
     InverseChk->Checked = false;
     MeansChk->Checked = false;
     VariancesChk->Checked = false;
     StdDevsChk->Checked = false;
     DepEdit->Text = "";
     if (ops.format == 0)
     {
        InProbEdit->Text = "0.05";
        OutProbEdit->Text = "0.10";
     }
     else // European
     {
        InProbEdit->Text = "0,05";
        OutProbEdit->Text = "0,10";
     }
     DepOutBtn->Visible = false;
     DepInBtn->Visible = true;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::DepOutBtnClick(TObject *Sender)
{
     if (DepEdit->Text == "") return;
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::IndOutBtnClick(TObject *Sender)
{
     int index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (SelList->Items->Count < 1) IndOutBtn->Visible = false;     
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::AllBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     for (int i = 0; i < VarList->Items->Count; i++)
         SelList->Items->Add(VarList->Items->Strings[i]);
     VarList->Clear();
     IndInBtn->Visible = false;
     IndOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TBestRegForm::OKBtnClick(TObject *Sender)
{
     int i, j, OriginNoVars;
     AnsiString title, cellstring, filename;
     double R2, StdErrEst, constant;
     int *IndepIndex;
     bool showinverse;
     int result;

     if (MatInChk->Checked == true)  NoVariables = 200;
     GetDblMatMem(cross_prod,NoVariables+1,NoVariables+1);
     GetDblMatMem(ind_mat,NoVariables+1,NoVariables+1);
     sumx = new double[NoVariables];
     mean = new double[NoVariables];
     stddev = new double[NoVariables];
     variance = new double[NoVariables];
     xycross = new double[NoVariables];
     raw_b = new double[NoVariables];
     RowLabels = new AnsiString[NoVariables];
     ColLabels = new AnsiString[NoVariables];
     IndepIndex = new int[NoVariables];
     ColNoSelected = new int[NoVariables];
     Selected = new int[NoVariables];
     Max_Set = new int[NoVariables];
     pred_labels = new AnsiString[NoVariables];

     OriginNoVars = NoVariables; // note - additional variables might be created
     stop_prob = StrToFloat(InProbEdit->Text); // probability to include a variable
     prout = 1.0;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Best Combination Multiple Regression by Bill Miller");
     errorcode = 0;
     last_R2 = 0.0;
     last_set = 0 ;
     more_to_do = true;

     if (MatInChk->Checked)
     {
               LoadMatrix();
               NoVars = NoVariables;
               NCases = NoCases;
               for (i = 0; i < NoVars; i++)
               {
                    mean[i] = 0.0;
                    stddev[i] = 1.0;
                    variance[i] = sqr(stddev[i]);
                    ColNoSelected[i] = i+1;
                    RowLabels[i] = MainForm->Grid->Cells[i+1][0];
                    ColLabels[i] = RowLabels[i];
               }
               for (i = 0; i < NoVars; i++)
               {
                   VarList->Items->Add(RowLabels[i]);
                   for (j = 0; j < NoVars; j++)
                       cross_prod[i][j] = StrToFloat(Trim(MainForm->Grid->Cells[i+1][j+1]));
               }
               // convert correlations to deviation cross-products
               for (i = 0; i < NoVars; i++)
                   for (j = 0; j < NoVars; j++)
                       cross_prod[i][j] *= (stddev[i] * stddev[j] * (NoCases-1));
                       MatPrint(cross_prod, NoVars, NoVars, ColNoSelected, "Deviation Cross-Products Matrix");
               FrmOutPut->ShowModal();
               FrmOutPut->RichOutPut->Clear();
//          }
     }
     else
     {
          // get independent item columns
          NoVars = SelList->Items->Count;
          if (NoVars < 1)
          {
               ShowMessage("ERROR! No independent variables selected.");
               goto CleanUp;
          }
          for (i = 0; i < NoVars; i++)
          {
               cellstring = SelList->Items->Strings[i];
               for (j = 1; j <= NoVariables; j++)
               {
                    if (cellstring == MainForm->Grid->Cells[j][0])
                    {
                         ColNoSelected[i] = j;
                         RowLabels[i] = cellstring;
                         ColLabels[i] = cellstring;
                    }
               }
          }
          // get dependendent variable column
          if (DepEdit->Text == "")
          {
               ShowMessage("ERROR! No Dependent variable selected.");
               goto CleanUp;
          }
          NoVars = NoVars + 1;
          for (j = 1; j <= NoVariables; j++)
          {
               if (DepEdit->Text == MainForm->Grid->Cells[j][0])
               {
                    ColNoSelected[NoVars-1] = j;
                    RowLabels[NoVars-1] = DepEdit->Text;
                    ColLabels[NoVars-1] = DepEdit->Text;
               }
          }
          NoCases = MainForm->Grid->RowCount - 1;
          NCases = NoCases;

          if ((CrossProdChk->Checked)&& (!MatInChk->Checked))
          {
               Correlations(mean, stddev, cross_prod, NoVars, ColNoSelected,
                  NCases, 1, false, 0);
               MatPrint(cross_prod, NoVars, NoVars, ColNoSelected, "Cross-Products Matrix");
          }

          if ((CovarChk->Checked)&&(!MatInChk->Checked))
          {
               Correlations(mean, stddev, cross_prod, NoVars, ColNoSelected,
                  NCases, 2, false, 0);
               MatPrint(cross_prod, NoVars, NoVars, ColNoSelected, "Variance-Covariance Matrix");
          }
          if (!MatInChk->Checked)
             Correlations(mean, stddev, cross_prod, NoVars,ColNoSelected, NCases,
                       3, false, 0);
     } // end else

     if ((CorrsChk->Checked)&& (!MatInChk->Checked))
        MatPrint(cross_prod, NoVars, NoVars, ColNoSelected, "Product-Moment Correlations Matrix");

     if ((SaveCorrsChk->Checked)&& (!MatInChk->Checked))
     {
          SaveDialog1->Filter = "Stat4Free matrix files (*.MAT)|*.MAT|All files (*.*)|*.*";
          SaveDialog1->FilterIndex = 1;
          if (SaveDialog1->Execute())
          {
               filename = SaveDialog1->FileName;
               SaveSqrMat(cross_prod, NoVars, NCases, RowLabels, mean, stddev);
          }
     }

     for (int i = 0; i < NoVars; i++) variance[i] = sqr(stddev[i]);
     if (MeansChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(mean,NoVars,ColLabels,"Means");
     }

     if (VariancesChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(variance,NoVars,ColLabels,"Variances");
     }

     if (StdDevsChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        VPrint(stddev,NoVars,ColLabels,"Standard Deviations");
     }

     if (errorcode)
     {
          FrmOutPut->RichOutPut->Lines->Add("One or more correlations could not be computed due to zero variance of a variable.");
     }
     FrmOutPut->ShowModal();

     if (errorcode)
     {
          ShowMessage("ERROR! A selected variable has no variability-run aborted.");
          goto CleanUp;
     }

     FrmOutPut->RichOutPut->Clear();

     if (InverseChk->Checked) showinverse = true;
     else showinverse = false;

     y_ptr = NoVars;
//     INIT(this);

     if (!MatInChk->Checked)
     {
        // get deviation cross-products matrix from the cross-products matrix
        Correlations(mean, stddev, cross_prod, NoVars, ColNoSelected, NCases, 1, false, 0);
        // above is cross-products matrix - next we get deviation CP matrix
        for (int i = 0; i < NoVars; i++) variance[i] = sqr(stddev[i]);
        for (i = 0; i < NoVars; i++)
            for (j = 0; j < NoVars; j++)
                cross_prod[i][j] = cross_prod[i][j] - (mean[i] * mean[j] * NCases);
        MatPrint(cross_prod, NoVars, NoVars, ColNoSelected, "Deviation Cross-Products Matrix");
     }

     // use deviation cross-products for analysis

     v = NoVars;
     no_predictors = v - 1;
     ss_total = cross_prod[y_ptr-1][y_ptr-1];
     biggest_R2 = 0.0;

     // Find best single predictor
     sets = 1;
     for (j = 1; j <= no_predictors; j++)
     {
         Selected[0] = j;
         REGRESS(this);
     }
     BEST_SET_STATS(this);

     // Find best combinations of 2 to no_predictors - 1
     sets = 2;
     while (sets < no_predictors)
     {
         end_of_set = false;
         start_set(this);
            while (! end_of_set)
            {
                REGRESS(this);
                bump_one(this);
            }
        REGRESS(this);
        BEST_SET_STATS(this);
        sets = sets + 1;
     }
     sets = sets - 1; // no. of predictors

     // Find regression with all of the predictors
     if (more_to_do)
     {
         sets = no_predictors;
         for (i = 1; i <= sets; i++)  Selected[i-1] = i;
         REGRESS(this);
         BEST_SET_STATS(this);
     }
     else
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Last variable added failed entry test. Job ended.");
     }

     if (!MatInChk->Checked)
        Correlations(mean, stddev, cross_prod, NoVars,ColNoSelected, NCases, 3, false, 0);

     // add [predicted scores, residual scores, etc. to grid if options elected
     if (PredictChk->Checked)
     {
         for (i = 1; i <= sets; i++)
         {
            ii = Selected[i-1];
            IndepIndex[i-1] = ii; //ColNoSelected[ii];
         }
         prout = 1.0;

         MReg2(NCases,NoVars, sets, IndepIndex, cross_prod, ind_mat,
               RowLabels, R2, raw_b, mean, variance,
               errorcode, StdErrEst, constant,prout, true, false,showinverse);

         Predict(ColNoSelected, IndepIndex,NoVars, ind_mat, mean, stddev, raw_b,
             raw_b, constant, StdErrEst, sets);
//         Predict(ColNoSelected, NoVars, ind_mat, mean, stddev,
//                 raw_b, StdErrEst, IndepIndex, sets);
     }

     FrmOutPut->ShowModal();

CleanUp:
     delete[] pred_labels;
     delete[] Max_Set;
     delete[] Selected;
     delete[] ColNoSelected;
     delete[] IndepIndex;
     delete[] ColLabels;
     delete[] RowLabels;
     delete[] raw_b;
     delete[] xycross;
     delete[] variance;
     delete[] stddev;
     delete[] mean;
     delete[] sumx;
     ClearDblMatMem(ind_mat,OriginNoVars+1);
     ClearDblMatMem(cross_prod,OriginNoVars+1);
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::INIT(TObject *Sender)
{
     int i,j;

     count = 0.0;
     for (i = 1; i <= NoVariables; i++)
     {
          sumx[i-1] = 0.0;
          mean[i-1] = 0.0;
          variance[i-1] = 0.0;
          stddev[i-1] = 0.0;
          for (j = 1; j <= v; j++)  cross_prod[i-1][j-1] = 0.0;
     }
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::REGRESS(TObject *Sender)
{
     int i, j;
     char outline[121];

     b_zero = 0.0 ;
     ss_reg = 0.0 ;
     for (i = 1; i <= sets; i++) raw_b[i-1] = 0.0 ;

     // Set up matrices of deviation cross_products to use

     for (i = 1; i <= sets; i++)
     {
         ii = Selected[i-1];
         xycross[i-1] = cross_prod[y_ptr-1][ii-1];
         for (j = 1; j <= sets; j++)
         {
              jj = Selected[j-1];
              ind_mat[i-1][j-1] = cross_prod[ii-1][jj-1];
         }
     }
     SVDinverse(ind_mat,sets);

     for (i = 1; i <= sets; i++)
     {
          ii = Selected[i-1];
          for (j = 1; j <= sets; j++)
              raw_b[i-1] = raw_b[i-1] + (ind_mat[i-1][j-1] * xycross[j-1]) ;
          b_zero = b_zero + raw_b[i-1] * mean[ii-1];
     }
     b_zero = mean[y_ptr-1] - b_zero;

     // Get sum of squares for regression and multiple R
     for (i = 1; i <= sets; i++) ss_reg = ss_reg + raw_b[i-1] * xycross[i-1];
     mult_R2 = ss_reg / ss_total;

     // Now, check to see if this R2 is largest.  If so, save set

     if (mult_R2 > biggest_R2)
     {
          biggest_R2 = mult_R2;
          for (i = 1; i <= sets; i++) Max_Set[i-1] = Selected[i-1];
     }

     // print out this combination for testing purposes }
     if (ShowComboChk->Checked)
     {
          sprintf(outline," Set %2d includes variables:",sets);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          for (i = 1; i <= sets; i++)
          {
               sprintf(outline,"variable %d (%s)",Selected[i-1],ColLabels[Selected[i-1]-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Squared  R = %6.4f",mult_R2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("");
     }
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::BEST_SET_STATS(TObject *Sender)
{
     int i, j;
     char outline[121];
     char astring[121];

     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Variables entered in step %2d",sets);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     for (i = 1; i <= sets; i++)
     {
          ii = Max_Set[i-1];
          Selected[i-1] = Max_Set[i-1];
          sprintf(outline,"%2d %s",Max_Set[i-1],ColLabels[ii-1].c_str());
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     REGRESS(this);
     sprintf(outline,"Squared Multiple Correlation = %5.4f",mult_R2);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Dependent variable = %s",ColLabels[y_ptr-1]);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("ANOVA for Regression Effects : ");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE      df           SS           MS            F             Prob");
     df_reg = sets;
     df_res = ceil(NCases) - sets - 1;
     df_tot = ceil(NCases) - 1;
     ms_reg = ss_reg / df_reg;
     ss_res = ( 1.0 - mult_R2) * ss_total ;
     ms_res = ss_res / df_res ;
     f_test = ms_reg / ms_res ;
     prob_f = ftest(df_reg,df_res,f_test);

     // Get variance of b coefficients
     sprintf(outline,"Regression %3d %14.4f %14.4f %14.4f %14.4f",
         df_reg,ss_reg,ms_reg,f_test,prob_f);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Residual   %3d %14.4f %14.4f",df_res,ss_res,ms_res);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Total      %3d %14.4f",df_tot,ss_total);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Variables in the equation");
     FrmOutPut->RichOutPut->Lines->Add("VARIABLE            b        s.e. b    Beta    t    prob. t");
     for (i = 1; i <= sets; i++)
         for (j = 1; j <= sets; j++)
             ind_mat[i-1][j-1] = ind_mat[i-1][j-1] * ms_res ;
     for (i = 1; i <= sets; i++)
     {
         ii = Selected[i-1];
         pred_labels[i-1] = ColLabels[ii-1];
         sprintf(outline,"%16s %10.5f ",ColLabels[ii-1].c_str(),raw_b[i-1]);
         seb = sqrt(ind_mat[i-1][i-1]);
         t = raw_b[i-1] / seb ;
         f_test = t * t ;
         prob_f = ftest(1,df_res,f_test);
         beta = raw_b[i-1] * stddev[ii-1] / stddev[y_ptr-1] ;
         sprintf(astring,"%8.4f %8.4f %6.3f %6.4f",seb,beta,t,prob_f);
         strcat(outline,astring);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"(Intercept)      %10.5f",b_zero);
     FrmOutPut->RichOutPut->Lines->Add(outline);

     //    MAT_PRINT(sets,ind_mat,pred_labels,"Variance-covariance matrix of b s");

     //  Now see if the gain was significant over last step
     df1 = sets - last_set ;
     if (df1 > 0)
     {
          f_test = ((mult_R2 - last_R2 ) / df1 ) / ( (1.0 - mult_R2) / df_res) ;
          prob_f =  ftest(df1,df_res,f_test);
          if (prob_f < stop_prob)  more_to_do = false ;
          R2_diff = mult_R2 - last_R2 ;
          FrmOutPut->RichOutPut->Lines->Add("");
          sprintf(outline,"Increase in squared R for this step = %8.6f",R2_diff);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"F = %8.4f with D.F. %d and %d with Probability = %6.4f",
             f_test,df1,df_res,prob_f);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------");
          FrmOutPut->RichOutPut->Lines->Add("");
          last_set = sets;
          last_R2 = mult_R2;
     }
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::bump_one(TObject *Sender)
{
     if (Selected[first_pt-1] < no_predictors)
          Selected[first_pt-1] = Selected[first_pt-1] + 1;
     else
     {
          all_done = false;
          while (! all_done)
          {
               first_pt = first_pt -1;
               if (first_pt < 1)  all_done = true;
               else
               {
                    Selected[first_pt-1] = Selected[first_pt-1] + 1;
                    if (Selected[first_pt-1] < Selected[first_pt])
                    {
                         re_set(this);
                         first_pt = pointer;
                         all_done = true;
                    }
                    else Selected[first_pt-1] = Selected[first_pt-1] - 1;
               }
          }
     }
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::start_set(TObject *Sender)
{
     int i;

     end_of_set = false;
     for (i = 1; i <= sets;i++) Selected[i-1] = i;
     first_pt = sets;
     pointer = sets;
}
//-------------------------------------------------------------------

void __fastcall TBestRegForm::re_set(TObject *Sender)
{
     int i;

     testval = no_predictors - sets + 1 ;
     if ((first_pt == 1) && (Selected[first_pt-1] == testval)) end_of_set = true;
     else for (i = first_pt + 1; i <= sets; i++) Selected[i-1] = Selected[i-2] + 1;
}
//-------------------------------------------------------------------


void __fastcall TBestRegForm::MatInChkClick(TObject *Sender)
{
     if (MatInChk->Checked)
     {
        SaveCorrsChk->Enabled = false;
        PredictChk->Enabled = false;
        SaveCorrsChk->Enabled = false;
        CrossProdChk->Enabled = false;
        CovarChk->Enabled = false;
        CorrsChk->Enabled = false;
        InverseChk->Enabled = false;
     }
     else
     {
        SaveCorrsChk->Enabled = true;
        PredictChk->Enabled = true;
        SaveCorrsChk->Enabled = true;
        CrossProdChk->Enabled = true;
        CovarChk->Enabled = true;
        CorrsChk->Enabled = true;
        InverseChk->Enabled = true;
     }

}
//---------------------------------------------------------------------------

