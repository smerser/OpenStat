//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "OutPut.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFrmOutPut *FrmOutPut;
//---------------------------------------------------------------------------
__fastcall TFrmOutPut::TFrmOutPut(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::ReturnBtnClick(TObject *Sender)
{
     RichOutPut->Clear();
     FrmOutPut->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::PrintBtnClick(TObject *Sender)
{
     if (PrintDialog1->Execute()) RichOutPut->Print("OUTPUT");
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::PrintButtonClick(TObject *Sender)
{
     if (PrintDialog1->Execute()) RichOutPut->Print("OUTPUT");
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::ReturnSpdBtnClick(TObject *Sender)
{
     RichOutPut->Clear();
     FrmOutPut->ModalResult = mrOk;
     FrmOutPut->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::FontSelSpdBtnClick(TObject *Sender)
{
  FontDialog1->Options << fdApplyButton;
  FontDialog1->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::FontDialog1Apply(TObject *Sender, HWND Wnd)
{
    if (ActiveControl->ClassNameIs("TRichEdit"))
        ((TRichEdit *)ActiveControl)->SelAttributes->Assign(FontDialog1->Font);
    else MessageBeep(0);

}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::OpenButtonClick(TObject *Sender)
{
    OpenDialog1->Filter = "OpenStat rich text files (*.rtf)|*.RTF|All files (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
	if (OpenDialog1->Execute())
    {
        RichOutPut->Lines->LoadFromFile(OpenDialog1->FileName);
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::SaveButtonClick(TObject *Sender)
{
    SaveDialog1->Filter = "OpenStat rich text files (*.rtf)|*.RTF|All files (*.*)|*.*";
    SaveDialog1->FilterIndex = 1;
	if (SaveDialog1->Execute())
    {
        RichOutPut->Lines->SaveToFile(SaveDialog1->FileName);
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::CutButtonClick(TObject *Sender)
{

    RichOutPut->CutToClipboard();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::PasteButtonClick(TObject *Sender)
{
    RichOutPut->PasteFromClipboard();
}
//---------------------------------------------------------------------------

void __fastcall TFrmOutPut::CopyButtonClick(TObject *Sender)
{
    RichOutPut->CopyToClipboard();    
}
//---------------------------------------------------------------------------



