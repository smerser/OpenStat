//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "FrmFDSpecs.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "Math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
#include "GraphUnit.h"
#include "NestedABUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TNestedABForm *NestedABForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;

//---------------------------------------------------------------------------
__fastcall TNestedABForm::TNestedABForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNestedABForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     AInBtn->Visible = true;
     AOutBtn->Visible = false;
     BInBtn->Visible = true;
     BOutBtn->Visible = false;
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
     FactorAEdit->Text = "";
     FactorBEdit->Text = "";
     DepEdit->Text = "";
     OptionsBox->ItemIndex = 3;
}
//---------------------------------------------------------------------------
void __fastcall TNestedABForm::ComputeBtnClick(TObject *Sender)
{
     GetVars(this);
     GetMemory(this);
     GetSums(this);
     ShowMeans(this);
     GetResults(this);
     ShowResults(this);
     FrmOutPut->ShowModal();
     TwoWayPlot(this);
     ReleaseMemory(this);
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::GetVars(TObject *Sender)
{
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     DepVar = DepEdit->Text;
     FactorA = FactorAEdit->Text;
     FactorB = FactorBEdit->Text;
     ACol = 0;
     BCol = 0;
     YCol = 0;
     for (int i = 1; i <= NoVariables; i++)
     {
         if (FactorA == MainForm->Grid->Cells[i][0]) ACol = i;
         if (FactorB == MainForm->Grid->Cells[i][0]) BCol = i;
         if (DepVar == MainForm->Grid->Cells[i][0]) YCol = i;
     }
     if ((ACol == 0) || (BCol == 0) || (YCol == 0))
     {
        ShowMessage("Error in specifying variables to analyze.");
        return;
     }
/*
     // check variable types
     result = VarTypeChk(ACol,1);
     if (result == 1) return;
     result = VarTypeChk(BCol,1);
     if (result == 1) return;
     result = VarTypeChk(YCol,0);
     if (result == 1) return;
*/
     // Get number of A levels
     MinA = 1000;
     MaxA = -1000;
     for (int i = 1; i <= NoCases; i++)
     {
         AValue = floor(StrToFloat(MainForm->Grid->Cells[ACol][i]));
         //result = GetValue(i,ACol,intvalue,dblvalue,strvalue);
         //if (result == 1) AValue = 0;
         //else AValue = intvalue;
         if (AValue < MinA) MinA = AValue;
         if (AValue > MaxA) MaxA = AValue;
     }
     NoALevels = MaxA - MinA + 1;

     // Get number of B Levels
     MinB = 1000;
     MaxB = -1000;
     for (int i = 1; i <= NoCases; i++)
     {
         BValue = floor(StrToFloat(MainForm->Grid->Cells[BCol][i]));
         //result = GetValue(i,BCol,intvalue,dblvalue,strvalue);
         //if (result == 1) BValue = 0;
         //else BValue = intvalue;
         if (BValue < MinB) MinB = BValue;
         if (BValue > MaxB) MaxB = BValue;
     }
     NoBLevels = MaxB - MinB + 1;
}
// --------------------------------------------------------------------

void __fastcall TNestedABForm::GetMemory(TObject *Sender)
{
     GetDblMatMem(SS,NoBLevels,NoALevels);
     GetDblMatMem(SumSqr,NoBLevels,NoALevels);
     GetIntMatMem(CellCount,NoBLevels,NoALevels);
     GetDblMatMem(CellMeans,NoBLevels,NoALevels);
     GetDblMatMem(CellSDs,NoBLevels,NoALevels);
     GetDblVecMem(ASS,NoALevels);
     GetDblVecMem(BSS,NoBLevels);
     GetDblVecMem(ASumSqr,NoALevels);
     GetDblVecMem(BSumSqr,NoBLevels);
     GetDblVecMem(AMeans,NoALevels);
     GetDblVecMem(BMeans,NoBLevels);
     GetIntVecMem(ACount,NoALevels);
     GetIntVecMem(BCount,NoBLevels);
     GetDblVecMem(ASDs,NoALevels);
}
//---------------------------------------------------------------------

void __fastcall TNestedABForm::GetSums(TObject *Sender)
{
     int Aindex, Bindex;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     // Clear memory
     SSTot = 0.0;
     SumSqrTot = 0.0;
     TotN = 0;

     for (int i = 0; i < NoBLevels; i++)
     {
         for (int j = 0; j < NoALevels; j++)
         {
             SS[i][j] = 0.0;
             SumSqr[i][j] = 0.0;
             CellCount[i][j] = 0;
         }
     }

     for (int i = 0; i < NoALevels; i++)
     {
         ACount[i] = 0;
         AMeans[i] = 0.0;
         ASS[i] = 0.0;
         ASumSqr[i] = 0.0;
     }

     for (int j = 0; j < NoBLevels; j++)
     {
         BCount[j] = 0;
         BMeans[j] = 0.0;
         BSS[j] = 0.0;
         BSumSqr[j] = 0.0;
     }

     // Accumulate sums and sums of squared values
     for (int i = 1; i <= NoCases; i++)
     {
         Aindex = floor(StrToFloat(MainForm->Grid->Cells[ACol][i]));
         Bindex = floor(StrToFloat(MainForm->Grid->Cells[BCol][i]));
         YValue = StrToFloat(MainForm->Grid->Cells[YCol][i]);
         //result = GetValue(i,YCol,intvalue,dblvalue,strvalue);
         //if (result == 1) YValue = 0.0;
         //else YValue = dblvalue;
         Aindex = Aindex - MinA;
         Bindex = Bindex - MinB;
         SS[Bindex][Aindex] += (YValue * YValue);
         SumSqr[Bindex][Aindex] += YValue;
         CellCount[Bindex][Aindex] += 1;
         ACount[Aindex] += 1;
         BCount[Bindex] += 1;
         ASS[Aindex] += (YValue * YValue);
         BSS[Bindex] += (YValue * YValue);
         ASumSqr[Aindex] += YValue;
         BSumSqr[Bindex] += YValue;
         SSTot += (YValue * YValue);
         SumSqrTot += YValue;
         TotN += 1;
     }

     // get cell means and marginal means, SDs plus square of sums
     for (int i = 0; i < NoBLevels; i++)
     {
         for (int j = 0; j < NoALevels; j++)
         {
             if (CellCount[i][j] > 0)
             {
                CellMeans[i][j] = SumSqr[i][j] / CellCount[i][j];
                SumSqr[i][j] *= SumSqr[i][j];
                CellSDs[i][j] = SS[i][j] - (SumSqr[i][j] / CellCount[i][j]);
                CellSDs[i][j] = CellSDs[i][j] / (CellCount[i][j] - 1);
                CellSDs[i][j] = sqrt(CellSDs[i][j]);
             }
         }
     }
     for (int i = 0; i < NoBLevels; i++)
     {
         BMeans[i] = BSumSqr[i] / BCount[i];
         BSumSqr[i] *= BSumSqr[i];
     }
     for (int i = 0; i < NoALevels; i++)
     {
         AMeans[i] = ASumSqr[i] / ACount[i];
         ASumSqr[i] *= ASumSqr[i];
         ASDs[i] = ASS[i] - (ASumSqr[i] / ACount[i]);
         ASDs[i] = ASDs[i] / (ACount[i] - 1);
         ASDs[i] = sqrt(ASDs[i]);
     }
     TotMean = SumSqrTot / TotN;
     SumSqrTot *= SumSqrTot;
}
// --------------------------------------------------------------------


void __fastcall TNestedABForm::AInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     FactorAEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     AInBtn->Visible = false;
     AOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::BInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     FactorBEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     BInBtn->Visible = false;
     BOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::DepInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepInBtn->Visible = false;
     DepOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::AOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FactorAEdit->Text);
     FactorAEdit->Text = "";
     AInBtn->Visible = true;
     AOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::BOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(FactorBEdit->Text);
     FactorBEdit->Text = "";
     BInBtn->Visible = true;
     BOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::ShowMeans(TObject *Sender)
{
     char outvalue[121];

     // put means to the output page
     FrmOutPut->RichOutPut->Lines->Add("NESTED ANOVA by Bill Miller");
     FrmOutPut->RichOutPut->Lines->Add("File Analyzed: " + MainForm->FileNameEdit->Text);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("CELL MEANS");
     FrmOutPut->RichOutPut->Lines->Add("A LEVEL     B LEVEL          MEAN        STD.DEV.");
     for (int i = 0; i < NoALevels; i++)
     {
         for (int j = 0; j < NoBLevels; j++)
         {
             if (CellCount[j][i] > 0)
             {
                sprintf(outvalue,"%5d       %5d       %10.3f    %10.3f",
                        i+MinA,j+MinB,CellMeans[j][i],CellSDs[j][i]);
                FrmOutPut->RichOutPut->Lines->Add(outvalue);
             }
         }
         FrmOutPut->RichOutPut->Lines->Add("");
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("A MARGIN MEANS");
     FrmOutPut->RichOutPut->Lines->Add("A LEVEL       MEAN    STD.DEV.");
     for (int i = 0; i < NoALevels; i++)
     {
         sprintf(outvalue,"%5d    %10.3f    %10.3f",i+MinA,AMeans[i],ASDs[i]);
         FrmOutPut->RichOutPut->Lines->Add(outvalue);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
/*     FrmOutPut->RichOutPut->Lines->Add("B MARGIN MEANS");
     FrmOutPut->RichOutPut->Lines->Add("B LEVEL       MEAN");
     for (int i = 0; i < NoBLevels; i++)
     {
         sprintf(outvalue,"%5d    %10.3f",i+MinB,BMeans[i]);
         FrmOutPut->RichOutPut->Lines->Add(outvalue);
     }
*/
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outvalue,"GRAND MEAN = %10.3f",TotMean);
     FrmOutPut->RichOutPut->Lines->Add(outvalue);
     FrmOutPut->RichOutPut->Lines->Add("");
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::GetResults(TObject *Sender)
{
     double constant, temp;
     int NoBLevelsInA, BLevCount;

     // Calculate ANOVA Table results
     celln = 0;
     for (int i = 0; i < NoALevels; i++)
         for (int j = 0; j < NoBLevels; j++)
             if (CellCount[j][i] > celln) celln = CellCount[j][i];
     // assumes all cells have same n size
     // get no of levels in A
     BLevCount = 0;
     for (int i = 0; i < NoALevels; i++)
     {
         NoBLevelsInA = 0;
         for (int j = 0; j < NoBLevels; j++)
             if (CellCount[j][i] > 0) NoBLevelsInA++;
         if (NoBLevelsInA > BLevCount) BLevCount = NoBLevelsInA;
     }
     dfA = NoALevels - 1;
     dfBwA = NoALevels * (BLevCount - 1);
     dfwcell = NoALevels * BLevCount * (celln - 1);
     dftotal = TotN - 1;

     constant = SumSqrTot / TotN;
     SSTot = SSTot - constant;
     MSTot = SSTot / dftotal;

     SSA = 0.0;
     for (int i = 0; i < NoALevels; i++) SSA = SSA + (ASumSqr[i] / ACount[i]);
     temp = SSA;
     SSA =  SSA - constant;
     MSA = SSA / dfA;

     SSB = 0.0;
     for (int i = 0; i < NoALevels; i++)
         for (int j = 0; j < NoBLevels; j++)
             if (CellCount[j][i] > 0) SSB = SSB + (SumSqr[j][i] / CellCount[j][i]);
     SSB = SSB - temp;
     MSB = SSB / dfBwA;

     SSW = SSTot - SSA - SSB;
     MSW = SSW / dfwcell;
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::ShowResults(TObject *Sender)
{
     char outvalue[121];
     double F, PF;

     // print ANOVA table
     FrmOutPut->RichOutPut->Lines->Add("ANOVA TABLE");
     FrmOutPut->RichOutPut->Lines->Add("SOURCE     D.F.      SS        MS        F         PROB.");
     if (RandomBChk->Checked)
     {
        F = MSA / MSB;
        PF = ftest(dfA,dfBwA,F);
     }
     else
     {
         F = MSA / MSW;
         PF = ftest(dfA,dfwcell,F);
     }
     sprintf(outvalue,"A         %4d  %10.3f%10.3f%10.3f%10.3f",dfA,SSA,MSA,F,PF);
     FrmOutPut->RichOutPut->Lines->Add(outvalue);
     F = MSB / MSW;
     PF = ftest(dfBwA,dfwcell,F);
     sprintf(outvalue,"B(A)      %4d  %10.3f%10.3f%10.3f%10.3f",dfBwA,SSB,MSB,F,PF);
     FrmOutPut->RichOutPut->Lines->Add(outvalue);
     sprintf(outvalue,"w.cells   %4d  %10.3f%10.3f",dfwcell,SSW,MSW);
     FrmOutPut->RichOutPut->Lines->Add(outvalue);
     sprintf(outvalue,"Total     %4d  %10.3f",dftotal,SSTot);
     FrmOutPut->RichOutPut->Lines->Add(outvalue);
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::ReleaseMemory(TObject *Sender)
{
     // release allocated memory allocated as:
/*
     GetDblMatMem(SS,NoBLevels,NoALevels);
     GetDblMatMem(SumSqr,NoBLevels,NoALevels);
     GetIntMatMem(CellCount,NoBLevels,NoALevels);
     GetDblMatMem(CellMeans,NoBLevels,NoALevels);
     GetDblVecMem(ASS,NoALevels);
     GetDblVecMem(BSS,NoBLevels);
     GetDblVecMem(ASumSqr,NoALevels);
     GetDblVecMem(BSumSqr,NoBLevels);
     GetDblVecMem(AMeans,NoALevels);
     GetDblVecMem(BMeans,NoBLevels);
     GetIntVecMem(ACount,NoALevels);
     GetIntVecMem(BCount,NoBLevels);
*/
     delete[] ASDs;
     delete[] BCount;
     delete[] ACount;
     delete[] BMeans;
     delete[] AMeans;
     delete[] BSumSqr;
     delete[] ASumSqr;
     delete[] BSS;
     delete[] ASS;
     ClearDblMatMem(CellSDs,NoBLevels);
     ClearDblMatMem(CellMeans,NoBLevels);
     ClearIntMatMem(CellCount,NoBLevels);
     ClearDblMatMem(SumSqr,NoBLevels);
     ClearDblMatMem(SS,NoBLevels);
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TNestedABForm::TwoWayPlot(TObject *Sender)
{
     int i, j;
     double maxmean, XBar;
     double *XValue;
     AnsiString title;
     int plottype;
     AnsiString setstring;

     XValue = new double[NoALevels+NoBLevels];
     plottype = OptionsBox->ItemIndex;

     //  Factor A first
     setstring = "FACTOR A";
     GraphForm->SetLabels[1] = setstring;
     maxmean = -1000.0;
     GetDblMatMem(GraphForm->Xpoints,1,NoALevels);
     GetDblMatMem(GraphForm->Ypoints,1,NoALevels);
     for (i = 1; i <= NoALevels; i++)
     {
          GraphForm->Ypoints[0][i-1] = AMeans[i-1];
          if (AMeans[i-1] > maxmean)  maxmean = AMeans[i-1];
          XValue[i-1] = MinA + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = NoALevels;
     GraphForm->Heading = FactorA;
     title =  FactorA + " Group Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);

     //  Factor B next
     setstring = "FACTOR B";
     GraphForm->SetLabels[1] = setstring;
     maxmean = 0.0;
     GetDblMatMem(GraphForm->Xpoints,1,NoBLevels);
     GetDblMatMem(GraphForm->Ypoints,1,NoBLevels);
     for (i = 1; i <= NoBLevels; i++)
     {
          GraphForm->Ypoints[0][i-1] = BMeans[i-1];
          if (BMeans[i-1] > maxmean)  maxmean = BMeans[i-1];
          XValue[i-1] = MinB + i - 1;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = NoBLevels;
     GraphForm->Heading = FactorB;
     title =  FactorB + " Group Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = 0.0;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
     delete[] XValue;
}
