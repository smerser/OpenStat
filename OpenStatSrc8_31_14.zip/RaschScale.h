//---------------------------------------------------------------------------
#ifndef RaschScaleH
#define RaschScaleH
#include "vcl/graphics.hpp"
#include "math.h"
#include "OutPut.h"
//#include "Graphics.h"
//---------------------------------------------------------------------------
#endif
void ANALYZE(int *itemfail, int *grpfail, int **f, int &T, int *grppass,\
            int *itempass, int r, int C1, double &min, double &max, \
            double *p2);
void EXPAND(double v1, double v2, double &xexpand, double &yexpand);
void FinishIt(int r, int *i5, double *rptbis, double *rbis, double *slope, \
			  double *mean, int *itemfail, double *P );
void FREQUENCIES(int C1, int r, int **f, int *rowtot, int *i5, int *s5,\
                 int T, int *S );
void GETLOGS(double *L, double *L1, double *L2, double *g, double *G2,\
             double *f2, int *rowtot, int k, int *s5, int *S, int T, int r,\
             int C1, double &v1, double &v2 );
void GETSCORES(int noselected, int *selected, int NoCases, int **f,\
               double *mean, double *xsqr, double *sumxy, int *S, int *X,\
               double &sumx, double &sumx2, int &N);
void MAXABILITY(double *expdcnt, double *d2, double *e2, double **p1,\
                double *p2, double *P, int C1, int r, double **D,\
                int *s5, int noloops);
double MAXITEM(double *R1, double *d1, double **p1, double **D, double *e1,\
             double *p2, double *P, int *S, int *rowtot, int T, int r, int C1);
void MAXOUT(int r, int C1, int *i5, int *s5, double *P, double *p2);
void PROX(double *P, double *p2, int k, int r, int C1, double *L1, \
          double yexpand, double xexpand, double *g, int T, int *rowtot, \
          int *i5, int *s5);
void REDUCE(int k, int &r, int &T, int &C1, int *i5, int *rowtot, int *s5,\
            int **f, int *S);
void  SLOPES(double *rptbis, double *rbis, double *slope, int N, double sumx,\
             double sumx2, double *sumxy, int r, double *xsqr, double *mean);
void TESTFIT(int r, int C1, int **f, int *S, double *P, double *p2, int T );
void plot(double **xyarray, int arraysize, char *Title, int Vdivisions,\
          int Hdivisions);
void PLOTINFO(int k, int r, double **info, double **A, double *slope, \
              double *P);
void rasch(int NoVariables, int NoCases, int noselected, int *selected);
void PlotItems(int r, int *i5, double *P);
void PlotScrs(int C1, int *s5, double *p2);
void PlotTest(double **TestInfo, int arraysize, AnsiString Title,
              int Vdivisions, int Hdivisions);



