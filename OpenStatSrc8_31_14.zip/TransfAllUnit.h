//---------------------------------------------------------------------------

#ifndef TransfAllUnitH
#define TransfAllUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTransfAllForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *ListBox1;
        TBitBtn *Var1In;
        TBitBtn *Var1Out;
        TLabel *Label2;
        TEdit *Var1Edit;
        TLabel *Label5;
        TListBox *TrnsfrmLst;
        TEdit *ConstantEdit;
        TBitBtn *Var2In;
        TBitBtn *Var2Out;
        TLabel *Label3;
        TEdit *Var2Edit;
        TButton *CancelBtn;
        TButton *OKBtn;
        TEdit *SelectEdit;
        TLabel *Label4;
        TMemo *Memo1;
        TLabel *Label6;
        void __fastcall CancelBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Var1InClick(TObject *Sender);
        void __fastcall Var1OutClick(TObject *Sender);
        void __fastcall Var2InClick(TObject *Sender);
        void __fastcall Var2OutClick(TObject *Sender);
        void __fastcall TrnsfrmLstClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
    int TIndex;
public:		// User declarations
        __fastcall TTransfAllForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTransfAllForm *TransfAllForm;
//---------------------------------------------------------------------------
#endif
    double * Rank(int v1col);
    double * PRank(int v1col);
