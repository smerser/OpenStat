//---------------------------------------------------------------------------

#ifndef BartlettUnitH
#define BartlettUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBartlettTestForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *VarList;
        TListBox *SelList;
        TLabel *Label1;
        TLabel *Label2;
        TBitBtn *InBtn;
        TBitBtn *OutBtn;
        TButton *CancelBtn;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TLabel *Label3;
        TEdit *ChiSqrEdit;
        TLabel *Label4;
        TEdit *ProbEdit;
        TLabel *Label5;
        TEdit *DFEdit;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall InBtnClick(TObject *Sender);
        void __fastcall OutBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TBartlettTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBartlettTestForm *BartlettTestForm;
//---------------------------------------------------------------------------
#endif
