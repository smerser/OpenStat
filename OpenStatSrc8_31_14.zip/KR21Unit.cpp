//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "KR21Unit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKR21Form *KR21Form;
//---------------------------------------------------------------------------
__fastcall TKR21Form::TKR21Form(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKR21Form::ResetBtnClick(TObject *Sender)
{
     MaxScoreEdit->Text = "";
     MeanEdit->Text = "";
     StdDevEdit->Text = "";
     RelEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TKR21Form::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TKR21Form::ComputeBtnClick(TObject *Sender)
{
     double items, mean, stddev, rel;

     items = StrToFloat(MaxScoreEdit->Text);
     mean = StrToFloat(MeanEdit->Text);
     stddev = StrToFloat(StdDevEdit->Text);
     rel = (items / (items - 1.0)) * (1.0 - (mean * (items - mean))/
          (items * (stddev * stddev)));
     RelEdit->Text = FloatToStr(rel);
}
//---------------------------------------------------------------------------
