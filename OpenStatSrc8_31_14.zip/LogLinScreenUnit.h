//---------------------------------------------------------------------------

#ifndef LogLinScreenUnitH
#define LogLinScreenUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TLogLinScreenForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TBitBtn *InBtn;
     TBitBtn *OutBtn;
     TBitBtn *AllBtn;
     TLabel *Label2;
     TListBox *SelList;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TMemo *Memo1;
     TGroupBox *GroupBox1;
     TCheckBox *MargTotalsChk;
     TCheckBox *PrintEstChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall InBtnClick(TObject *Sender);
     void __fastcall OutBtnClick(TObject *Sender);
     void __fastcall AllBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
//  CrossClassFrm: TCrossClassFrm;
  int *Minimums;
  int *Maximums;
  bool *Response;
  bool *Interact;
  int NoDims;
  void __fastcall Marginals(int NoDims, int ArraySize, int **ndexes,
                              double *Data, int **Margins);
  void __fastcall Screen(int &NVAR, int &MP, int &MM, int &NTAB,
                         double *TABLE, int *DIM, double *GSQ, int *DGFR,
                         double **PART, double **MARG, int **DFS,
                         int **IP, int **IM, int *ISET, int *JSET,
                         int **CONFIG, double *FIT, int *SIZE, int *COORD,
                         double *X, double *Y, int &IFAULT);

  void __fastcall CONF(int &N, int &M, int &MP, int &MM, int *ISET,
                       int *JSET, int **IP, int **IM, int &NP);

  void __fastcall COMBO(int *ISET, int N, int M, bool &LAST);

  void __fastcall EVAL(int **IAR, int NC, int NV, int IBEG, int NVAR, int MAX,
                       int **CONFIG, int *DIM, int &DF);

  void __fastcall RESET(double *FIT, int NTAB, double AVG);

  void __fastcall LIKE(double &GSQ,  double *FIT, double *TABLE, int NTAB);

  void __fastcall LOGFIT(int NVAR, int NTAB, int NCON, int *DIM,
                         int **CONFIG, double *TABLE, double *FIT, int *SIZE,
                         int *COORD, double *X, double *Y);

  void __fastcall MaxCombos(int NoDims, int &MM, int &MP);

  int __fastcall ArrayPosition(int NoDims, double *Data, int *Subscripts,
                               int *DimSize);

public:		// User declarations
     __fastcall TLogLinScreenForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLogLinScreenForm *LogLinScreenForm;
//---------------------------------------------------------------------------
#endif
