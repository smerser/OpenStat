//---------------------------------------------------------------------------
#ifndef FrmSelCasesH
#define FrmSelCasesH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Buttons.hpp>
//---------------------------------------------------------------------------
class TSelCases : public TForm
{
__published:	// IDE-managed Components
	TListBox *ListBox1;
	TGroupBox *GroupBox1;
	TRadioButton *BtnSelAll;
	TRadioButton *BtnIfCondition;
	TButton *IfButton;
	TRadioButton *BtnRandom;
	TButton *SampleButton;
	TRadioButton *BtnCaseRange;
	TButton *RangeButton;
	TRadioButton *BtnFilter;
	TBitBtn *BtnFilterVar;
	TEdit *TxtFilterVar;
	TGroupBox *GroupBox2;
	TRadioButton *BtnUnselFilt;
	TRadioButton *BtnUnselDel;
	TLabel *Label1;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnReset;
	TButton *BtnHelp;
	void __fastcall BtnOKClick(TObject *Sender);
	void __fastcall BtnCancelClick(TObject *Sender);
	void __fastcall IfButtonClick(TObject *Sender);
	void __fastcall SampleButtonClick(TObject *Sender);
	void __fastcall RangeButtonClick(TObject *Sender);
	void __fastcall BtnIfConditionClick(TObject *Sender);
	void __fastcall BtnRandomClick(TObject *Sender);
	void __fastcall BtnCaseRangeClick(TObject *Sender);
	void __fastcall BtnFilterClick(TObject *Sender);
	void __fastcall BtnSelAllClick(TObject *Sender);
	void __fastcall BtnFilterVarClick(TObject *Sender);
    
    
    void __fastcall BtnHelpClick(TObject *Sender);
        void __fastcall BtnResetClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TSelCases(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TSelCases *SelCases;
//---------------------------------------------------------------------------
#endif
