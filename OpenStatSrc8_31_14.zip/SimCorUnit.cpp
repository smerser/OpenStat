//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <math.h>
#include <Math.hpp>
#include "OutPut.h"
#include "SimCorUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSimCorFrm *SimCorFrm;
//---------------------------------------------------------------------------
__fastcall TSimCorFrm::TSimCorFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::XmeanEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) YmeanEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::YmeanEditKeyPress(TObject *Sender, char &Key)
{
   if (Key == 13) SDXEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::SDXEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) SDYEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::SDYEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) CorrEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::CorrEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) NoObsEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::NoObsEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) DoneBtn->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::DoneBtnClick(TObject *Sender)
{
    char outline[81];

    N = atoi(NoObsEdit->Text.c_str());
    meanx = atof(XmeanEdit->Text.c_str());
    meany = atof(YmeanEdit->Text.c_str());
    sdx = atof(SDXEdit->Text.c_str());
    sdy = atof(SDYEdit->Text.c_str());
    corr = atof(CorrEdit->Text.c_str());
    try  {
        x = new double[N];
        y = new double[N];
        freqx = new int[51];
        freqy = new int[51];
    }
    catch(...)
    {
        ShowMessage("Memory error in corr. simulation.");
        return;
    }

    // generate x and y data observations
    double corsqr = corr * corr;
    double yvariance = sdy * sdy;
    double predvar = corsqr * yvariance;
    double errvariance = yvariance - predvar;
    double stderror = sqrt(errvariance);
    double b = corr * (sdy / sdx);
    double constant = meany - (b * meanx);

    newmeanx = 0.0;
    newmeany = 0.0;
    newsdx = 0.0;
    newsdy = 0.0;
    newcorr = 0.0;
    for (int i = 0; i < N; i++)
    {
        x[i] = RandG(meanx,sdx);
        double randomerror = RandG(0.0,stderror);
        y[i] = (b * x[i]) + constant + randomerror;
        newmeanx += x[i];
        newmeany += y[i];
        newsdx += (x[i] * x[i]);
        newsdy += (y[i] * y[i]);
        newcorr += (x[i] * y[i]);
    }
    newsdx -= ((newmeanx * newmeanx) / double(N));
    newsdx /= double(N - 1);
    newsdx = sqrt(newsdx);
    newsdy -= ((newmeany * newmeany) / double(N));
    newsdy /= double(N - 1);
    newsdy = sqrt(newsdy);
    newcorr -= ((newmeanx * newmeany) / double(N));
    newcorr /= double(N - 1);
    newcorr /= (newsdx * newsdy);
    newmeanx /= double(N);
    newmeany /= double(N);
    newb = newcorr * (newsdy / newsdx);
    newconstant = newmeany - (newb * newmeanx);
    FrmOutPut->RichOutPut->Lines->Clear();
    strcpy(outline,"POPULATION PARAMETERS FOR THE SIMULATION");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Mean X = %8.3f, Std. Dev. X = %8.3f",meanx, sdx);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Mean Y = %8.3f, Std. Dev. Y = %8.3f",meany, sdy);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Product-Moment Correlation = %8.3f",corr);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Regression line slope = %8.3f, constant = %8.3f",
        b, constant);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"SAMPLE STATISTICS FOR %d OBSERVATIONS FROM THE POPULATION",N);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Mean X = %8.3f, Std. Dev. X = %8.3f",newmeanx, newsdx);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Mean Y = %8.3f, Std. Dev. Y = %8.3f",newmeany, newsdy);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Product-Moment Correlation = %8.3f",newcorr);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Regression line slope = %8.3f, constant = %8.3f",
        newb, newconstant);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();
    plot();
    ReturnBtn->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TSimCorFrm::CancelBtnClick(TObject *Sender)
{
    SimCorFrm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TSimCorFrm::plot(void)
{
    // get min and max of x and y points
    double minx, maxx, miny, maxy, xincrement, yincrement;
    char label[51];
    int xpos, ypos, xpos1, ypos1, xpos2, ypos2;

    minx = maxx = x[0];
    miny = maxy = y[0];
    for (int i = 1; i < N; i++)
    {
        if (minx > x[i]) minx = x[i];
        if (maxx < x[i]) maxx = x[i];
        if (miny > y[i]) miny = y[i];
        if (maxy < y[i]) maxy = y[i];
    }
    xincrement = (maxx - minx) / 10;
    yincrement = (maxy - miny) / 10;

    int winwidth = SimCorFrm->Width;
    int winheight = SimCorFrm->Height - Panel1->Height;
    int xoffset = winwidth / 3;
    int yoffset = winheight / 3;
    int xaxislong = winwidth - xoffset- winwidth/10;
    int yaxislong = winheight - yoffset - winheight/10;
    Canvas->Pen->Color = clBlack;
    Canvas->MoveTo(xoffset,yaxislong);
    Canvas->LineTo(winwidth,yaxislong);
    Canvas->MoveTo(xoffset,yaxislong);
    Canvas->LineTo(xoffset,0);
    int xspacing = xaxislong / 10;
    int yspacing = yaxislong / 10;
    // do xaxis
    for (int i = 0; i < 11; i++)
    {
        Canvas->MoveTo(xoffset + (i * xspacing),yaxislong);
        Canvas->LineTo(xoffset + (i * xspacing),yaxislong + 10);
        sprintf(label,"%8.3f",minx + (i * xincrement));
        int labelwidth = Canvas->TextWidth(label);
        int xpos = xoffset + (i * xspacing)-labelwidth / 2;
        int ypos = yaxislong + 12;
        Canvas->TextOut(xpos,ypos,label);
    }
    // do yaxis
    for (int i = 0; i < 11; i++)
    {
        Canvas->MoveTo(xoffset, yaxislong - (i * yspacing));
        Canvas->LineTo(xoffset-10,yaxislong - (i * yspacing));
        sprintf(label,"%8.3f",miny + (i * yincrement));
        int labelwidth = Canvas->TextWidth(label);
        int xpos = xoffset-10-labelwidth;
        int ypos = yaxislong - (i * yspacing);
        Canvas->TextOut(xpos,ypos,label);
    }
    // plot points
    Canvas->Pen->Color = clRed;
    for (int i = 0; i < N; i++)
    {
       xpos = xoffset + ((x[i]-minx)/(maxx-minx) * xaxislong);
       ypos = yaxislong - ((y[i]-miny)/(maxy-miny) * yaxislong);
       Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
    }
    // draw regression line
    Canvas->Pen->Color = clBlack;
    double predy1 = newb * minx + newconstant;
    double predy2 = newb * maxx + newconstant;
    xpos1 = xoffset;
    xpos2 = xoffset + xaxislong;
    ypos1 = yaxislong - ((predy1-miny)/(maxy-miny) * yaxislong);
    ypos2 = yaxislong - ((predy2-miny)/(maxy-miny) * yaxislong);
    Canvas->MoveTo(xpos1,ypos1);
    Canvas->LineTo(xpos2,ypos2);

    // do x frequency distribution
    xincrement = (maxx-minx) / 50.0;
    xspacing = xaxislong / 50;
    for (int j = 0; j < 51; j++) freqx[j] = 0.0;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < 51; j++)
        {
            double lowerx = minx + (j * xincrement);
            double upperx = minx + ((j+1) * xincrement);
            if ((x[i] >= lowerx) && (x[i] < upperx)) freqx[j]++;
        }
    }
    // plot the x frequencies
    int minfreq = N;
    int maxfreq = 0;
    for (int j = 0; j < 51; j++)
    {
        if (freqx[j] > maxfreq) maxfreq = freqx[j];
        if (freqx[j] < minfreq) minfreq = freqx[j];
    }
    int flength = winheight - (yaxislong + 25) - Panel1->Height;
    for (int j = 0; j < 51; j++)
    {
        xpos = xoffset + (j * xspacing);
        ypos1 = yaxislong + 25 +
            (double(freqx[j]-minfreq)/double(maxfreq-minfreq)* double(flength));
        ypos2 = yaxislong + 25;
        Canvas->MoveTo(xpos,ypos1);
        Canvas->LineTo(xpos,ypos2);
    }
    Canvas->MoveTo(xoffset,yaxislong+25);
    Canvas->LineTo(winwidth,yaxislong+25);
    xpos = 20;
    ypos = yaxislong+30;
    Canvas->TextOut(xpos,ypos,"X DISTRIBUTION");
    int theight = Canvas->TextHeight("X");
    ypos += theight;
    sprintf(label,"correlation = %6.3f",newcorr);
    Canvas->TextOut(xpos,ypos,label);
    ypos += theight;
    sprintf(label,"Mean X = %8.3f, Mean Y = %8.3f",newmeanx, newmeany);
    Canvas->TextOut(xpos,ypos,label);
    sprintf(label,"SD X = %8.3f, SD Y = %8.3f",newsdx, newsdy);
    ypos += theight;
    Canvas->TextOut(xpos,ypos,label);

    // do y frequency distribution
    yincrement = (maxy-miny) / 50.0;
    yspacing = yaxislong / 50;
    for (int j = 0; j < 51; j++) freqy[j] = 0.0;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < 51; j++)
        {
            double lowery = miny + (j * yincrement);
            double uppery = miny + ((j+1) * yincrement);
            if ((y[i] >= lowery) && (y[i] < uppery)) freqy[j]++;
        }
    }
    // plot the y frequencies
    minfreq = N;
    maxfreq = 0;
    for (int j = 0; j < 51; j++)
    {
        if (freqy[j] > maxfreq) maxfreq = freqy[j];
        if (freqy[j] < minfreq) minfreq = freqy[j];
    }
    flength = winwidth - (xaxislong + 150);
    for (int j = 0; j < 51; j++)
    {
        ypos = yaxislong - (j * yspacing);
        double frange = maxfreq - minfreq;
        double prop = (double(freqy[j]) - double(minfreq)) / frange;
        xpos1 = xoffset - 50 - (prop * flength);
        xpos2 = xoffset - 50;
        Canvas->MoveTo(xpos1,ypos);
        Canvas->LineTo(xpos2,ypos);
    }
    Canvas->MoveTo(xoffset - 50,yaxislong);
    Canvas->LineTo(xoffset - 50,0);
    Canvas->TextOut(0,0,"Y DISTRIBUTION");
}
//---------------------------------------------------------------------------


void __fastcall TSimCorFrm::ReturnBtnClick(TObject *Sender)
{
    // clean up the heap
    delete[] freqy;
    delete[] freqx;
    delete[] y;
    delete[] x;

    SimCorFrm->Hide();    
}
//---------------------------------------------------------------------------

