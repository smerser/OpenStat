//---------------------------------------------------------------------------

#ifndef BGHUnitH
#define BGHUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TBGHForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *DepInBtn;
        TBitBtn *DepOutBtn;
        TBitBtn *Factor1InBtn;
        TBitBtn *Factor1OutBtn;
        TBitBtn *Factor2InBtn;
        TBitBtn *Factor2OutBtn;
        TLabel *Label2;
        TEdit *DepVarEdit;
        TLabel *Label3;
        TEdit *Factor1Edit;
        TRadioGroup *OptionsBox;
        TLabel *Label6;
        TEdit *OverAllEdit;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        TMemo *Memo1;
        TLabel *Label4;
        TEdit *Factor2Edit;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall DepInBtnClick(TObject *Sender);
        void __fastcall Factor1InBtnClick(TObject *Sender);
        void __fastcall Factor2InBtnClick(TObject *Sender);
        void __fastcall DepOutBtnClick(TObject *Sender);
        void __fastcall Factor1OutBtnClick(TObject *Sender);
        void __fastcall Factor2OutBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
   AnsiString outline;
   AnsiString cellstring;
   double SSDep, SSErr, SSF1, SSF2, SSF1F2;
   double MSDep, MSErr, MSF1, MSF2, MSF1F2;
   double DFTot, DFErr, DFF1, DFF2, DFF1F2;
   double Omega, OmegaF1, OmegaF2, OmegaF1F2, F, MinSize, MaxSize;
   double FF1, FF2, FF1F2, ProbF1, ProbF2, ProbF1F2;
   double MeanDep, MeanF1, MeanF2, MeanF3, X;
   double *cellcnts;    // array of cell counts
   double *cellvars;    // arrray of cell sums of squares then variances
   double *cellsums;    // array of cell sums then means
   double **counts;     // matrix for 2-way containing cell sizes
   double **sums;       // matrix for 2-way containing cell sums
   double **vars;       // matrix for 2-way containing sums of squares
   double *RowSums;     // 2 way row sums
   double *ColSums;     // 2 way col sums
   double *RowCount;    // 2 way row count
   double *ColCount;    // 2 way col count
   double *OrdMeansA, *OrdMeansB; // reordered means for f1, f2, f3
   double OverallAlpha, PostHocAlpha; // alphas for tests
   double ***wsum, ***wx2; // : DblDyneCube
   int NoSelected, intvalue, N;
   int *ColNoSelected;
   int DepVarCol, F1Col, F2Col, Nf1cells, Nf2cells;
   int minf1, maxf1, minf2, maxf2, minf3, nofactors, totcells;
   int NoGrpsA, NoGrpsB, NoGrpsC;
   int ***ncnt; // : IntDyneCube;
   int OKterms[15];
   bool CompError;
   bool equal_grp;   // check for equal groups for post-hoc tests

   void __fastcall getlevels(TObject *Sender);
   void __fastcall Calc2Way(TObject *Sender);
   void __fastcall TwoWayTable(TObject *Sender);
   void __fastcall TwoWayPlot(TObject *Sender);

public:		// User declarations
        __fastcall TBGHForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBGHForm *BGHForm;
//---------------------------------------------------------------------------
#endif
