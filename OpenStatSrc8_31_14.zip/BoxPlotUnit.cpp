//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "PlotUnit.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "MainUnit.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "BoxPlotUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBoxPlotForm *BoxPlotForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TBoxPlotForm::TBoxPlotForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBoxPlotForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     GroupEdit->Text = "";
     MeasEdit->Text = "";
     CheckBox1->Checked = false;
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TBoxPlotForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TBoxPlotForm::ComputeBtnClick(TObject *Sender)
{

     int i, j, k, GrpVar, MeasVar, mingrp, maxgrp, G, NoGrps, cnt, nscrgrps;
     double X, tenpcnt, ninepcnt, qrtile1, qrtile2, qrtile3, temp;
     double minscr, maxscr, intvlsize, lastX, Q1, Q2, Q3;
     AnsiString cellstring;
     char outline[121];
     double *means, *lowqrtl, *hiqrtl, *tenpcntile, *ninetypcntile, *median;
     double *freq, *Scores, *cumfreq, *prank, *scrgrp;
//     double *values;
     int *grpsize, *ColNoSelected;
     bool done, results;
     int NoSelected, tempcol;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;
     
     ColNoSelected = new int[NoVariables];
     freq = new double[2 * NoCases + 1];
     Scores = new double[2 * NoCases + 1];
     cumfreq = new double[2 * NoCases + 1];
     prank = new double[2 * NoCases + 1];
//     values = new double[2 * NoCases + 1];

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Box Plot of Groups");
     FrmOutPut->RichOutPut->Lines->Add("");

     GrpVar = 0;
     MeasVar = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GroupEdit->Text) GrpVar = i;
          if (cellstring == MeasEdit->Text) MeasVar = i;
     }
     if ((GrpVar == 0) || (MeasVar == 0))
     {
        ShowMessage("ERROR!  First select variables for the group and measure.");
        goto cleanup;
     }
     NoSelected = 2;
     ColNoSelected[0] = GrpVar;
     ColNoSelected[1] = MeasVar;

     // check to see if strcol is a string variable
     cellstring = DictionaryForm->DGrid->Cells[3][GrpVar];
     if (cellstring == "2") // recode into an integer code
     {
        results = StringsToInt(GrpVar, tempcol, true);
        GrpVar = NoVariables;
        ColNoSelected[0] = GrpVar;
     }

     // get minimum and maximum group values
     mingrp = 10000;
     maxgrp = -10000;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
          G = StrToInt(MainForm->Grid->Cells[GrpVar][i]);
          if (G < mingrp) mingrp = G;
          if (G > maxgrp) maxgrp = G;
     }
     NoGrps = maxgrp - mingrp + 1;
     if (NoGrps > 30)
     {
          ShowMessage("ERROR! Too many groups for meaningful plot.");
          goto cleanup;
     }

     grpsize = new int[NoGrps + 1];
     means = new double[NoGrps + 1];
     lowqrtl = new double[NoGrps + 1];
     hiqrtl = new double[NoGrps + 1];
     tenpcntile = new double[NoGrps + 1];
     ninetypcntile = new double[NoGrps + 1];
     median = new double[NoGrps + 1];
     scrgrp = new double[NoGrps + 1];
     // initialize
     for (j = 1; j <= NoGrps; j++)
     {
          means[j-1] = 0.0;
          grpsize[j-1] = 0;
     }

     // get minimum and maximum scores and score interval
     intvlsize = 10000.0;
     lastX = 0.0;
     X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][1]));
     minscr = X;
     maxscr = X;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected, NoSelected)) continue;
          X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
          if (X > maxscr) maxscr = X;
          if (X < minscr) minscr = X;
          if (i > 1) // get interval size as minimum difference between 2 scores
          {
               if ((X != lastX) && (fabs(X - lastX) < intvlsize)) intvlsize = fabs(X - lastX);
               lastX = X;
          }
          else lastX = X;
     }

     //  check for excess no. of intervals and reset if needed
     nscrgrps = ceil((maxscr - minscr) / intvlsize);
     if (nscrgrps > (2 * NoCases)) intvlsize = (maxscr - minscr) / float(NoCases);

     // setup score groups
     done = false;
     Scores[0] = minscr - (intvlsize / 2.0);
     nscrgrps = 0;
     lastX = maxscr + intvlsize + (intvlsize / 2.0);

     while (! done)
     {
          nscrgrps = nscrgrps + 1;
          Scores[nscrgrps] = minscr + (nscrgrps * intvlsize) - (intvlsize / 2.0);
          if (Scores[nscrgrps] > lastX) done = true;
     }
     Scores[nscrgrps+1] = Scores[nscrgrps] + intvlsize;
     if (Scores[0] < minscr) minscr = Scores[0];
     if (Scores[nscrgrps] > maxscr) maxscr = Scores[nscrgrps];

     // do analysis for each group
     for (j = 1; j <= NoGrps; j++) // group
     {
          // get score groups for this group j
          for (i = 0; i <= nscrgrps; i++)
          {
               cumfreq[i] = 0.0;
               freq[i] = 0.0;
          }
          cnt = 0;
          for (i = 1; i <= NoCases; i++)
          {   // get scores for this group j
              if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
                G = StrToInt(Trim(MainForm->Grid->Cells[GrpVar][i]));
//                if (result != 0) continue;
                G = G - mingrp + 1;
                if (G == j) // subject in this group
                {
                     cnt = cnt + 1;
                     X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
//                     values[cnt] = X;
                     means[j-1] = means[j-1] + X;
                     // find score interval and add to the frequency
                     for (k = 0; k <= nscrgrps; k++)
                     {
                         if ((X >= Scores[k]) && (X < Scores[k+1]))
                        freq[k] = freq[k] + 1;
                     }
                }
          }
          grpsize[j-1] = cnt;
          if (grpsize[j-1] > 0) means[j-1] = means[j-1] / float(grpsize[j-1]);

             // accumulate frequencies
          cumfreq[0] = freq[0];
          for (i = 1; i <= nscrgrps-1; i++) cumfreq[i] = cumfreq[i-1] + freq[i];
          cumfreq[nscrgrps] = cumfreq[nscrgrps-1];

          // get percentile ranks
          if (grpsize[j-1] > 0)
                prank[0] = ((cumfreq[0] / 2.0) / float(grpsize[j-1])) * 100.0;
          for (i = 1; i <= nscrgrps-1; i++)
          {
               if (grpsize[j-1] > 0)
                 prank[i] = ((cumfreq[i-1] + (freq[i] / 2.0)) / float(grpsize[j-1])) * 100.0;
          }
           // get centiles required.

          qrtile1 = 0.25 * grpsize[j-1];
          lowqrtl[j-1] = Percentile(nscrgrps,qrtile1,freq,cumfreq,Scores);
          qrtile2 = 0.50 * grpsize[j-1];
          median[j-1] = Percentile(nscrgrps,qrtile2,freq,cumfreq,Scores);
          qrtile3 = 0.75 * grpsize[j-1];
          hiqrtl[j-1] = Percentile(nscrgrps,qrtile3,freq,cumfreq,Scores);
          tenpcnt = 0.10 * grpsize[j-1];
          tenpcntile[j-1] = Percentile(nscrgrps,tenpcnt,freq,cumfreq,Scores);
          ninepcnt = 0.90 * grpsize[j-1];
          ninetypcntile[j-1] = Percentile(nscrgrps,ninepcnt,freq,cumfreq,Scores);
          if (CheckBox1->Checked)
          {
               FrmOutPut->RichOutPut->Lines->Add("");
               sprintf(outline,"Results for group %d, mean = %8.3f",j, means[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               FrmOutPut->RichOutPut->Lines->Add("Centile       Value");
               sprintf(outline,"Ten          %6.3f",tenpcntile[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Twenty five  %6.3f",lowqrtl[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Median       %6.3f",median[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Seventy five %6.3f",hiqrtl[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               sprintf(outline,"Ninety       %6.3f",ninetypcntile[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
               FrmOutPut->RichOutPut->Lines->Add("Score Range    Frequency Cum.Freq. Percentile Rank");
               FrmOutPut->RichOutPut->Lines->Add("______________ _________ _________ _______________");
               for (i = 0; i <= nscrgrps-1; i++)
               {
                    sprintf(outline,"%6.2f - %6.2f %6.2f    %6.2f     %6.2f",
                       Scores[i],Scores[i+1],freq[i],cumfreq[i],prank[i]);
                    FrmOutPut->RichOutPut->Lines->Add(outline);
               }
          }
     } // get values for next group
     if (CheckBox1->Checked) FrmOutPut->ShowModal();

     // plot the boxes
     BoxPlot(NoGrps,maxscr,minscr,lowqrtl,hiqrtl,tenpcntile,ninetypcntile,means,median);

     //cleanup the heap
cleanup:
     delete[] scrgrp;
//     delete[] values;
     delete[] prank;
     delete[] cumfreq;
     delete[] Scores;
     delete[] freq;
     delete[] median;
     delete[] ninetypcntile;
     delete[] tenpcntile;
     delete[] hiqrtl;
     delete[] lowqrtl;
     delete[] means;
     delete[] grpsize;
     delete[] ColNoSelected;
     if (results == false) DeleteaCol(NoVariables);
}
//---------------------------------------------------------------------------

void __fastcall TBoxPlotForm::BoxPlot(int nbars,
                                      double max,
                                      double min,
                                      double *lowqrtl,
                                      double *hiqrtl,
                                      double *tenpcnt,
                                      double *ninetypcnt,
                                      double *means,
                                      double *median)
{
     int i, HTickSpace, imagewide, imagehi, vtop, vbottom, offset;
     int vhi, hleft, hright, hwide, barwidth, Xpos, Ypos, strhi;
     TPoint coords[5];
     int thi, deep, X, Y, colcycle, boxhi, barhi;
     int X1, X2, X3, X4, X5, X6, X7, X8, X9, X10; // X coordinates for box and lines
     int Y1, Y2, Y3, Y4, Y5, Y6, Y7, Y8, Y9, Y10; // Y coordinates for box and lines
     AnsiString Title;
     char outline[121];
     double valincr, Yvalue;

     Title = "BOXPLOT FOR : " + MainForm->FileNameEdit->Text;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 60;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     // Show title
     PlotForm->Caption = Title;
     Y = 10;
     Title = "RED: mean, BLACK: median, BOX: 25th to 75th percentile, WISKERS: 10th and 90th percentile";
     X = imagewide / 2 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     PlotForm->Image1->Canvas->TextOut(X,Y,Title);

     HTickSpace = hwide / (nbars+1);
     barwidth = HTickSpace / 2;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(10,vtop,imagewide-10,imagehi-10);

     // Draw vertical axis
     valincr = (max - min) / 20.0;
     for (i = 1; i <= 21; i++)
     {
          sprintf(outline,"%8.2f",max - ((i-1)*valincr));
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          Xpos = 20;
          Yvalue = max - (valincr * (i-1));
          Ypos = ceil(vhi * ( (max - Yvalue) / (max - min)));
          Ypos = Ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(Xpos,Ypos,Title);
     }
     PlotForm->Image1->Canvas->MoveTo(hleft,vtop);
     PlotForm->Image1->Canvas->LineTo(hleft,vbottom+20);

     // draw horizontal axis
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom + 20);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom + 20);
     for (i = 1; i <= nbars; i++)
     {
          Ypos = vbottom + 10;
          Xpos = ceil((hwide / (nbars+1))* i + hleft);
          PlotForm->Image1->Canvas->MoveTo(Xpos,Ypos);
          Ypos = Ypos + 10;
          PlotForm->Image1->Canvas->LineTo(Xpos,Ypos);
          sprintf(outline,"%d",i);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          Xpos = Xpos - offset;
          Ypos = Ypos + strhi;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(Xpos,Ypos,Title);
          Xpos = 20;
          PlotForm->Image1->Canvas->TextOut(Xpos,Ypos,"GROUPS:");
     }

     for (i = 1; i <= nbars; i++)
     {
        colcycle = i % 4; // select a color for box
        if (colcycle == 0) PlotForm->Image1->Canvas->Brush->Color = clBlue;
        if (colcycle == 1) PlotForm->Image1->Canvas->Brush->Color = clGreen;
        if (colcycle == 2) PlotForm->Image1->Canvas->Brush->Color = clFuchsia;
        if (colcycle == 3) PlotForm->Image1->Canvas->Brush->Color = clLime;

        // plot the box front face
        X9 = ceil(hleft + ((i) * HTickSpace) - (barwidth / 2));
        X10 = X9 + barwidth;
        X1 = X9;
        X2 = X10;
        Ypos= ceil((((max - hiqrtl[i-1]) / (max - min)) * vhi) + vtop);
        Y1 = Ypos;
        Ypos = ceil((((max - lowqrtl[i-1]) / (max - min)) * vhi) + vtop);
        Y2 = Ypos;
        PlotForm->Image1->Canvas->Rectangle(X1,Y1,X2,Y2);

        // draw upper 90th percentile line and end
        X3 = ceil(X1 + barwidth / 2);
        PlotForm->Image1->Canvas->MoveTo(X3,Y1);
        Ypos = ceil((((max - ninetypcnt[i-1]) / (max - min)) * vhi) + vtop);
        Y3 = Ypos;
        PlotForm->Image1->Canvas->LineTo(X3,Y3);
        PlotForm->Image1->Canvas->MoveTo(X1,Y3);
        PlotForm->Image1->Canvas->LineTo(X2,Y3);

        // draw lower 10th percentile line and end
        PlotForm->Image1->Canvas->MoveTo(X3,Y2);
        Ypos = ceil((((max - tenpcnt[i-1]) / (max - min)) * vhi) + vtop);
        Y4 = Ypos;
        PlotForm->Image1->Canvas->LineTo(X3,Y4);
        PlotForm->Image1->Canvas->MoveTo(X1,Y4);
        PlotForm->Image1->Canvas->LineTo(X2,Y4);

        //plot the means line
        PlotForm->Image1->Canvas->Pen->Color = clRed;
        PlotForm->Image1->Canvas->Pen->Style = psDot;
        Ypos = ceil((((max - means[i-1]) / (max - min)) * vhi) + vtop);
        Y9 = Ypos;
        PlotForm->Image1->Canvas->MoveTo(X9,Y9);
        PlotForm->Image1->Canvas->LineTo(X10,Y9);
        PlotForm->Image1->Canvas->Pen->Color = clBlack;
        PlotForm->Image1->Canvas->Pen->Style = psSolid;

        //plot the median line
        PlotForm->Image1->Canvas->Pen->Color = clBlack;
        Ypos = ceil((((max - median[i-1]) / (max - min)) * vhi) + vtop);
        Y9 = Ypos;
        PlotForm->Image1->Canvas->MoveTo(X9,Y9);
        PlotForm->Image1->Canvas->LineTo(X10,Y9);
        PlotForm->Image1->Canvas->Pen->Color = clBlack;
    }
    PlotForm->ShowModal();
}
//--------------------------------------------------------------------------

void __fastcall TBoxPlotForm::VarlistClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;

     if (GroupEdit->Text == "") GroupEdit->Text = Varlist->Items->Strings[index];
     else MeasEdit->Text = Varlist->Items->Strings[index];   
}
//---------------------------------------------------------------------------
