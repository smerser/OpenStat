//---------------------------------------------------------------------------

#ifndef LoanItMainH
#define LoanItMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TLoanItForm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TPanel *Panel2;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *PrincEdit;
    TEdit *APREdit;
    TEdit *YrsEdit;
    TEdit *PerYrEdit;
    TScrollBar *PrincScroll;
    TScrollBar *APRScroll;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TScrollBar *NoYrsScroll;
    TLabel *Label8;
    TScrollBar *NPerYrScroll;
    TButton *AmortizeBtn;
    TButton *ExitBtn;
    TButton *ResetBtn;
    TLabel *Label9;
    TEdit *PaymentEdit;
    TMemo *Memo1;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall PrincScrollChange(TObject *Sender);
    void __fastcall APRScrollChange(TObject *Sender);
    void __fastcall NoYrsScrollChange(TObject *Sender);
    void __fastcall NPerYrScrollChange(TObject *Sender);
    void __fastcall PrincEditKeyPress(TObject *Sender, char &Key);
    void __fastcall APREditKeyPress(TObject *Sender, char &Key);
    void __fastcall YrsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall PerYrEditKeyPress(TObject *Sender, char &Key);
    void __fastcall AmortizeBtnClick(TObject *Sender);
private:	// User declarations
     double Principle, Interest, Years, NoPerYr, Payment;
     double numerator, term2;
    void __fastcall CalcPayment(TObject *Sender);
public:		// User declarations
    __fastcall TLoanItForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLoanItForm *LoanItForm;
//---------------------------------------------------------------------------
#endif
