//---------------------------------------------------------------------------

#ifndef BoxPlotUnitH
#define BoxPlotUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TBoxPlotForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TListBox *Varlist;
   TMemo *Memo1;
   TLabel *Label2;
   TEdit *GroupEdit;
   TLabel *Label3;
   TEdit *MeasEdit;
   TGroupBox *GroupBox1;
   TCheckBox *CheckBox1;
   TButton *ReturnBtn;
   TButton *ComputeBtn;
   TButton *CancelBtn;
   TButton *ResetBtn;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall ComputeBtnClick(TObject *Sender);
   void __fastcall BoxPlot(int nbars, double max, double min, double *lowqrtl,
                           double *hiqrtl, double *tenpcnt, double *ninetypcnt,
                           double *means,  double *median);
   void __fastcall VarlistClick(TObject *Sender);

private:	// User declarations
public:		// User declarations
   __fastcall TBoxPlotForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBoxPlotForm *BoxPlotForm;
//---------------------------------------------------------------------------
#endif
