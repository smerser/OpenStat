//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "DataFuncs.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "RaschScale.h"
#include "RaschUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRaschForm *RaschForm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
__fastcall TRaschForm::TRaschForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::ResetBtnClick(TObject *Sender)
{
     ProxChk->Checked = false;
     PlotItemDifChk->Checked = false;
     PlotLogAbilityChk->Checked = false;
     PlotItemInfoChk->Checked = false;
     PlotTestInfoChk->Checked = false;
     SelList->Clear();
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++) VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     VarInBtn->Visible = true;
     VarOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::VarInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = VarList->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (VarList->Selected[i])
         {
            cellstring = VarList->Items->Strings[i];
            SelList->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < VarList->Items->Count; i++)
           {
               if (VarList->Selected[i])
               {
                  VarList->Items->Delete(i);
                  count--;
               }
           }
     }
     VarOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::VarOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = SelList->ItemIndex;
     cellstring = SelList->Items->Strings[index];
     VarList->Items->Add(cellstring);
     SelList->Items->Delete(index);
     VarInBtn->Visible = true;
     if (SelList->Items->Count < 0) VarOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::BtnAllClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = VarList->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = VarList->Items->Strings[index];
          SelList->Items->Add(cellstring);
     }
     VarList->Clear();
     VarOutBtn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TRaschForm::OKBtnClick(TObject *Sender)
{
     int noselected;
     int *selected;
     AnsiString cellstring;
     int result;

     noselected = SelList->Items->Count;
     if (noselected == 0)
     {
        ShowMessage("ERROR!  Select items to analyze.");
        return;
     }
     selected = new int[noselected];
     for (int i = 0; i < noselected; i++)
     {
         cellstring = SelList->Items->Strings[i];
         for (int j = 1; j <= NoVariables; j++)
         {
            if (cellstring == MainForm->Grid->Cells[j][0])
            {
                selected[i] = j;
                //result = VarTypeChk(j,1);
                //if (result == 1)
                //{
                //        delete[] selected;
                //        return;
                //}
            }
         }
     }
     rasch(NoVariables, NoCases, noselected, selected);
     delete[] selected;
}
//---------------------------------------------------------------------------


