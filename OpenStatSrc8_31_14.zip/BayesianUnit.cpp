//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BayesianUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBayesianFrm *BayesianFrm;
//---------------------------------------------------------------------------
__fastcall TBayesianFrm::TBayesianFrm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TBayesianFrm::Exit1Click(TObject *Sender)
{
        Close();        
}
//---------------------------------------------------------------------------

