//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "stdio.h"
#include "OutPut.h"
#include "NonPar.h"
#include "MainUnit.h"
#include "functions.h"
#include "HyperGeomUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THyperGeoForm *HyperGeoForm;
//---------------------------------------------------------------------------
__fastcall THyperGeoForm::THyperGeoForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall THyperGeoForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall THyperGeoForm::ResetBtnClick(TObject *Sender)
{
        SampSizeEdit->Clear();
        PopSizeEdit->Clear();
        SampObsEdit->Clear();
        PopObsEdit->Clear();
        ProbXEdit->Clear();
        ProbGEEdit->Clear();
        ProbLessEdit->Clear();
        ProbGTEdit->Clear();
        ProbLTEdit->Clear();
        Label5->Visible = false;
        Label6->Visible = false;
        Label7->Visible = false;
        Label8->Visible = false;
        Label9->Visible = false;
        ProbXEdit->Visible = false;
        ProbGEEdit->Visible = false;
        ProbLessEdit->Visible = false;
        ProbGTEdit->Visible = false;
        ProbLTEdit->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall THyperGeoForm::ComputeBtnClick(TObject *Sender)
{
        int SampObs, PopObs, SampSize, PopSize, N;
        double ProbX, Prob, SumProb = 0.0;
        int A, B, C, D, APlusC, BPlusD, APlusB, CPlusD;
        bool done = false;
        double ProbGE, ProbGT, ProbLT, ProbLE;

        Label5->Visible = true;
        Label6->Visible = true;
        Label7->Visible = true;
        Label8->Visible = true;
        Label9->Visible = true;
        ProbXEdit->Visible = true;
        ProbGEEdit->Visible = true;
        ProbLessEdit->Visible = true;
        ProbGTEdit->Visible = true;
        ProbLTEdit->Visible = true;
        SampObs = StrToInt(SampObsEdit->Text);
        PopObs = StrToInt(PopObsEdit->Text);
        SampSize = StrToInt(SampSizeEdit->Text);
        PopSize = StrToInt(PopSizeEdit->Text);

        A = SampObs;
        B = SampSize-A;
        C = PopObs;
        D = PopSize-C;
        APlusC = A + C;
        BPlusD = B + D;
        CPlusD = C + D;
        APlusB = A + B;
        N = A + B + C + D;

        //Ready output
        FrmOutPut->RichOutPut->Clear();
        SumProb = 0.0;
        FrmOutPut->RichOutPut->Lines->Add("Hypergeometric Probability Test");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Accumulating Values of the Hypergeometric Distribution");
        FrmOutPut->RichOutPut->Lines->Add("");

        //Get first probability
        ProbX = combos(A, C) * combos(B, D) / combos(APlusB, CPlusD);
        ProbXEdit->Text = FloatToStr(ProbX);
        SumProb = SumProb + ProbX;
        FisherTable(A, B, C, D, ProbX, SumProb);

        //Get more extreme probabilities
        while (! done)
        {
                if (A == APlusB) done = true;
                else {
                        A = A + 1;
                        B = B - 1;
                        if ( (A < 0) || (B < 0) || (C < 0) || (D < 0)) done = true;
                }
                if (! done)
                {
                        Prob = combos(A, C) * combos(B, D) / combos(APlusB, CPlusD);
                        SumProb = SumProb + Prob;
                        FisherTable(A, B, C, D, Prob, SumProb);
                }
        } // end while not done
        FrmOutPut->ShowModal();
        ProbGE = SumProb;
        ProbGT = SumProb - ProbX;
        ProbLT = 1.0 - ProbGE;
        ProbLE = ProbLT + ProbX;
        ProbGEEdit->Text = FloatToStr(ProbGE);
        ProbLessEdit->Text = FloatToStr(ProbLE);
        ProbGTEdit->Text = FloatToStr(ProbGT);
        ProbLTEdit->Text = FloatToStr(ProbLT);
}
//---------------------------------------------------------------------------

        void __fastcall THyperGeoForm::FisherTable(int A, int B, int C, int D,
                                        double p, double SumP)
{
    char outline[101];

    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Table for Hypergeometric Probabilities");
    FrmOutPut->RichOutPut->Lines->Add("                 Column");
    FrmOutPut->RichOutPut->Lines->Add("Row             1          2");
    sprintf(outline," 1     %10d %10d",A, B);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline," 2     %10d %10d",C, D);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Probability = %6.4f",p);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Cumulative Probability = %6.4f",SumP);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
}
