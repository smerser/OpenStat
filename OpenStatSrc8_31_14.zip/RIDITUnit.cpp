//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "RIDITUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRIDITForm *RIDITForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TRIDITForm::TRIDITForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Clear();
     ColList->Clear();
     RowEdit->Text = "";
     RefEdit->Text = "";
     if (ops.format == 0)AlphaEdit->Text = "0.05";
     else AlphaEdit->Text = "0,05";
     BonChk->Checked = true;
     RowIn->Visible = true;
     RowOut->Visible = false;
     ColIn->Visible = true;
     ColOut->Visible = false;
     Label4->Visible = false;
     RefEdit->Visible = false;
     RefGrp->ItemIndex = -1;
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);        
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);        
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::RowInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     RowEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RowIn->Visible = false;
     RowOut->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::RowOutClick(TObject *Sender)
{
     VarList->Items->Add(RowEdit->Text);
     RowEdit->Text = "";
     RowIn->Visible = true;
     RowOut->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::ColInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            ColList->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     ColOut->Visible = true;        
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::ColOutClick(TObject *Sender)
{
     int index;

     index = ColList->ItemIndex;
     if (index < 0)
     {
          ColOut->Visible = false;
          return;
     }
     VarList->Items->Add(ColList->Items->Strings[index]);
     ColList->Items->Delete(index);        
}
//---------------------------------------------------------------------------
void __fastcall TRIDITForm::ColListClick(TObject *Sender)
{
        int index = ColList->ItemIndex;

        RefEdit->Text = ColList->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TRIDITForm::ComputeBtnClick(TObject *Sender)
{
     bool AllRefs = true;
     int i, j, RowNo, ColNo, DepNo;
     int Row, Col, NoSelected, Ncases, Nrows, Ncols, FObs, df;
     AnsiString *RowLabels, *ColLabels;
     int *ColNoSelected;
     AnsiString cellstring;
     char outline[101];
     int **Freq;
     double **Prop, **Expected, **CellChi;
     double PObs, ChiSquare, ProbChi;
     bool yates;
     AnsiString title;
     AnsiString filename;
     double Adjchisqr, Adjprobchi, G;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     if (RefGrp->ItemIndex == 1) AllRefs = false;
     GetIntVecMem(ColNoSelected,NoVariables+1);
     yates = false;
     RowNo = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == RowEdit->Text) RowNo = i;
     }
     //result = VarTypeChk(RowNo,2);
     //if (result == 1)
     //{
     //   delete[] ColNoSelected;
     //   return;
     //}
     Nrows = NoCases;
     Ncols = ColList->Items->Count;
     RowLabels = new AnsiString[Nrows+1];
     ColLabels = new AnsiString[Ncols+1];

     if (RowNo == 0)
     {
        ShowMessage("ERROR! A variable for the row labels was not entered.");
        delete[] ColNoSelected;
        return;
     }
     ColNoSelected[0] = RowNo;

     // Get Column labels
     for (i = 0; i < Ncols; i++)
     {
        ColLabels[i] = ColList->Items->Strings[i];
        for (j = 1; j <= NoVariables; j++)
        {
                cellstring = MainForm->Grid->Cells[j][0];
                if (cellstring == ColLabels[i])
                {
                        ColNoSelected[i+1] = j;
                        //result = VarTypeChk(j,1);
                        //if (result == 1)
                        //{
                        //        delete[] ColLabels;
                        //        delete[] RowLabels;
                        //        delete[] ColNoSelected;
                        //        return;
                        //}
                }
        }
     }

     // Get row labels
     for (i = 1; i <= NoCases; i++)
     {
        RowLabels[i-1] = MainForm->Grid->Cells[RowNo][i];
     }

     // allocate and initialize
     GetIntMatMem(Freq,Nrows+1,Ncols+1);
     GetDblMatMem(Prop,Nrows+1,Ncols+1);
     GetDblMatMem(Expected,Nrows,Ncols);
     GetDblMatMem(CellChi,Nrows,Ncols);
     for (i = 1; i <= Nrows + 1; i++)
         for (j = 1; j <= Ncols + 1; j++) Freq[i-1][j-1] = 0;
    RowLabels[Nrows] = "Total";
    ColLabels[Ncols] = "Total";

     // get cell data
     Ncases = 0;
     for (i = 1; i <= NoCases; i++)
     {
        Row = i;
        for (j = 1; j <= Ncols; j++)
        {
                   Col = ColNoSelected[j];
                   Freq[i-1][j-1] = floor(StrToFloat(MainForm->Grid->Cells[Col][Row]));
                   result = GetValue(Row,Col,intvalue,dblvalue,strvalue);
                   //if (result == 1) Freq[i-1][j-1] = 0;
                   //else Freq[i-1][j-1] = intvalue;
                   Ncases = Ncases + Freq[i-1][j-1];
        }
     }
     Freq[Nrows][Ncols] = Ncases;

     // Now, calculate expected values
     // Get row totals first
     for (i = 1; i <= Nrows; i++)
     {
          for (j = 1; j <= Ncols; j++)
          {
               Freq[i-1][Ncols] = Freq[i-1][Ncols] + Freq[i-1][j-1];
          }
     }
     // Get col totals next
     for (j = 1; j <= Ncols; j++)
     {
         for (i = 1; i <= Nrows; i++)
         {
             Freq[Nrows][j-1] = Freq[Nrows][j-1] + Freq[i-1][j-1];
         }
     }

     // Then get expected values and cell chi-squares
     ChiSquare = 0.0;
     Adjchisqr = 0.0;
     if ((YatesChk->Checked) && (Nrows == 2) && (Ncols == 2)) yates = true;
     if ((Nrows > 1) && (Ncols > 1))
     {
        for (i = 1; i <= Nrows; i++)
        {
          for (j = 1; j <= Ncols; j++)
          {
               Expected[i-1][j-1] = (double) Freq[Nrows][j-1] * (double) Freq[i-1][Ncols] / (double)Ncases;
               if (Expected[i-1][j-1] > 0.0)
                  CellChi[i-1][j-1] = sqr((double)Freq[i-1][j-1] - Expected[i-1][j-1])
                                    / Expected[i-1][j-1];
               else
               {
                    ShowMessage("ERROR! Zero expected value found.");
                    CellChi[i-1][j-1] = 0.0;
               }
               ChiSquare = ChiSquare + CellChi[i-1][j-1];
          }
        }
        df = (Nrows - 1) * (Ncols - 1);
        if (yates == true)  // 2 x 2 corrected chi-square
        {
          Adjchisqr = fabs((Freq[0][0] * Freq[1][1]) - (Freq[0][1] * Freq[1][0]));
          Adjchisqr = sqr(Adjchisqr - Ncases / 2.0) * Ncases; // numerator
          Adjchisqr = Adjchisqr / (Freq[0][2] * Freq[1][2] * Freq[2][0] * Freq[2][1]);
          Adjprobchi = 1.0 - chisquaredprob(Adjchisqr,df);
        }
     }
     if (Nrows == 1) // equal probability
     {
        for (j = 0; j < Ncols; j++)
        {
                Expected[0][j] = (double) Ncases / (double) Ncols;
                if (Expected[0][j] > 0)
                   CellChi[0][j] = sqr((double)Freq[0][j] - Expected[0][j]) / Expected[0][j];
                ChiSquare += CellChi[0][j];
        }
        df = Ncols - 1;
     }

     if (Ncols == 1) // equal probability
     {
        for (i = 0; i < Nrows; i++)
        {
                Expected[i][0] = (double) Ncases / (double) Nrows;
                if (Expected[i][0] > 0)
                   CellChi[i][0] = sqr((double)Freq[i][0] - Expected[i][0]) / Expected[i][0];
                ChiSquare += CellChi[i][0];
        }
        df = Nrows - 1;
     }

     ProbChi = 1.0 - chisquaredprob(ChiSquare,df); // prob. larger chi

    //Print results to output form
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Chi-square Analysis Results");
    sprintf(outline,"No. of Cases = %d",Ncases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    // print tables requested by use
    if (ObsChk->Checked)
    {
       IntArrayPrint(Freq, Nrows+1, Ncols+1,"Frequencies",
                     RowLabels, ColLabels,"OBSERVED FREQUENCIES");
    }

    if (ExpChk->Checked)
    {
         strcpy(outline,"EXPECTED FREQUENCIES");
         ArrayPrint(Expected, Nrows, Ncols, "Expected Values", RowLabels, ColLabels,
                    outline);
    }

    if (PropChk->Checked) strcpy(outline,"ROW PROPORTIONS");
    for (i = 1; i <= Nrows + 1; i++)
    {
              for (j = 1; j <= Ncols; j++)
              {
                   if (Freq[i-1][Ncols] > 0.0)
                        Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[i-1][Ncols];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[i-1][Ncols] > 0.0)  Prop[i-1][Ncols] = 1.0;
              else Prop[i-1][Ncols] = 0.0;
    }
    if (PropChk->Checked) ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
    if (PropChk->Checked) strcpy(outline,"COLUMN PROPORTIONS");
    for (j = 1; j <= Ncols + 1; j++)
    {
              for (i = 1; i <= Nrows; i++)
              {
                   if (Freq[Nrows][j-1] > 0.0)
                       Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[Nrows][j-1];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[Nrows][j-1] > 0.0)  Prop[Nrows][j-1] = 1.0;
              else Prop[Nrows][j-1] = 0.0;
    }
    if (PropChk->Checked) ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);

    if (ChiChk->Checked)
    {
         strcpy(outline,"CHI-SQUARED VALUE FOR CELLS");
         ArrayPrint(CellChi, Nrows, Ncols, "Chi-square Values", RowLabels, ColLabels,
                    outline);
    }

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Chi-square = %8.3f with D.F. = %d. Prob. > value = %8.3f",
                    ChiSquare,df,ProbChi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    if (yates == true)
    {
         sprintf(outline,"Chi-square using Yates correction = %8.3f and Prob > value = %8.3f",
                 Adjchisqr,Adjprobchi);
         FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    double liklihood = 0.0;
    for (int i = 0; i < Nrows; i++)
        for (int j = 0; j < Ncols; j++)
             if (Freq[i][j] > 0.0) liklihood += (double)Freq[i][j] * (log(Expected[i][j] / (double)Freq[i][j]));
    liklihood = -2.0 * liklihood;
    double probliklihood = 1.0 - chisquaredprob(liklihood,df);
    sprintf(outline,"Liklihood Ratio = %8.3f with prob. > value = %6.4f",
            liklihood,probliklihood);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    if ((Nrows > 1) && (Ncols > 1))
    {
        double phi = sqrt(ChiSquare / (double) Ncases);
        sprintf(outline,"phi correlation = %6.4f",phi);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double pearsonr = 0.0;
        double SumX = 0.0;
        double SumY = 0.0;
        double VarX = 0.0;
        double VarY = 0.0;
        for (int i = 0; i < Nrows; i++) SumX += ( (double)(i+1) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) SumY += ( (double)(j+1) * (double) Freq[Nrows][j] );
        for (int i = 0; i < Nrows; i++) VarX += ( (double)((i+1)*(i+1)) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) VarY += ( (double)((j+1)*(j+1)) * (double) Freq[Nrows][j] );
        VarX = VarX - ((SumX * SumX) / (double) Ncases);
        VarY = VarY - ((SumY * SumY) / (double) Ncases);
        for (int i = 0; i < Nrows; i++)
                for (int j = 0; j < Ncols; j++)
                        pearsonr += (double) ((i+1)*(j+1) * Freq[i][j]);
        pearsonr = pearsonr - (SumX * SumY / (double) Ncases);
        pearsonr = pearsonr / sqrt(VarX * VarY);
        sprintf(outline,"Pearson Correlation r = %6.4f",pearsonr);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double MantelHaenszel = (double) (Ncases-1) * (pearsonr * pearsonr);
        double MHprob = 1.0 - chisquaredprob(MantelHaenszel,1);
        sprintf(outline,"Mantel-Haenszel Test of Linear Association = %8.3f with probability > value = %6.4f",
            MantelHaenszel, MHprob);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CoefCont = sqrt(ChiSquare / (ChiSquare + (double) Ncases));
        sprintf(outline,"The coefficient of contingency = %8.3f",CoefCont);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CramerV;
        if (Nrows < Ncols) CramerV = sqrt(ChiSquare / (Ncases * ((double) (Nrows-1))));
        else CramerV = sqrt(ChiSquare / (Ncases * ((double) (Ncols-1))));
        sprintf(outline,"Cramer's V = %8.3f",CramerV);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // Now do RIDIT analysis
    int RefColNo;
    int NoToAnalyze = ColList->Items->Count;

    if (AllRefs) // do an analysis for each variable as a reference variable
    {
        NoToAnalyze = ColList->Items->Count;
        for (i = 0; i < NoToAnalyze; i++)
        {
                RefColNo = ColNoSelected[i+1] - 2;
                Analyze(RefColNo, ColNoSelected, RowLabels,ColLabels,
                         NoToAnalyze,Freq,Prop, Nrows);
        }
    }
    else  // only one selected reference variable
    {
        NoToAnalyze = ColList->Items->Count;
        // get column of reference variable
        for (i = 1; i <= NoVariables; i++)
        {
                if (RefEdit->Text == MainForm->Grid->Cells[i][0]) RefColNo = i;

        }
        for (j = 0; j < NoToAnalyze; j++)
        {
               if (ColNoSelected[j+1] == RefColNo) RefColNo = j;
        }
        Analyze(RefColNo, ColNoSelected, RowLabels,ColLabels,
                NoToAnalyze,Freq, Prop, Nrows);
    }

    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(CellChi,Nrows);
    ClearDblMatMem(Expected,Nrows);
    ClearDblMatMem(Prop,Nrows+1);
    ClearIntMatMem(Freq,Nrows+1);
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

void TRIDITForm::Analyze(int RefCol, int *ColNoSelected, AnsiString *RowLabels,
                         AnsiString *ColLabels, int NoToAnalyze, int **Freq,
                         double **Props, int NoRows)
{
        // procedure to complete a RIDIT analysis
        double **probdists;
        double **refprob;
        double *sizes;
        double *meanridits;
        double *Cratios;
        double OverMeanRidit;
        double chisquare;
        double probchi;
        double alpha;
        double *StdErr;
        double Bonferroni;
        int chidf;
        int K;
        int i, j;
        char outline[101];
        AnsiString outstring;
        bool details = false;

        GetDblMatMem(probdists,NoRows,NoToAnalyze);
        GetDblMatMem(refprob,NoRows,4);
        GetDblVecMem(sizes,NoToAnalyze);
        GetDblVecMem(meanridits,NoToAnalyze);
        GetDblVecMem(Cratios,NoToAnalyze);
        GetDblVecMem(StdErr,NoToAnalyze);

        alpha = StrToFloat(AlphaEdit->Text);
        if (DetailsChk->Checked) details = true;

        sprintf(outline,"ANALYSIS FOR STANDARD %s",ColLabels[RefCol]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        // print frequencies
         strcpy(outline,"Frequencies Observed");
         IntArrayPrint(Freq, NoRows, NoToAnalyze, "Frequencies", RowLabels, ColLabels,
                    outline);

        // print column proportions
         strcpy(outline,"Column Proportions Observed");
         ArrayPrint(Props, NoRows, NoToAnalyze, "Proportions", RowLabels, ColLabels,
                    outline);

        // Get sizes in each column
        for (i = 0; i < NoToAnalyze; i++)
        {
                sizes[i] = (double)Freq[NoRows][i];
        }
        // Get the reference variable probabilities for all variables
        for (j = 0; j < NoToAnalyze; j++)
        {
                for (i = 0; i < NoRows; i++)
                {
                        refprob[i][0] = Props[i][j];
                        refprob[i][1] = Props[i][j] / 2.0;
                }
                refprob[0][2] = 0.0;
                for (i = 1; i < NoRows; i++) refprob[i][2] = refprob[i-1][2] + refprob[i-1][0];
                for (i = 0; i < NoRows; i++) refprob[i][3] = refprob[i][1] + refprob[i][2];
                if (details) // print calculations table
                {
                        outstring = "Ridit calculations for " + ColLabels[j];
                        strcpy(outline,outstring.c_str());
                        ArrayPrint(refprob, NoRows, 4, "CALCULATIONS", RowLabels, ColLabels,
                           outline);
                }
                // store results in probdists
                for (i = 0; i < NoRows; i++) probdists[i][j] = refprob[i][3];
        }
        outstring = "Ridits for all variables";
        strcpy(outline,outstring.c_str());
        ArrayPrint(probdists, NoRows, NoToAnalyze, "RIDITS", RowLabels, ColLabels,
                    outline);

        // obtain mean ridits for the all variables using the reference variable
        for (i = 0; i < NoToAnalyze; i++)
        {
                meanridits[i] = 0.0;
                for (j = 0; j < NoRows; j++)
                {
                        meanridits[i] += (probdists[j][RefCol] * Freq[j][i]);
                }
                meanridits[i] /= sizes[i];
        }
        // print the means using the reference variable
        VPrint(meanridits,NoToAnalyze,ColLabels,"Mean RIDITS Using the Reference Values");
        // obtain the weighted grand mean ridit
        OverMeanRidit = 0.0;
        for (i = 0; i < NoToAnalyze; i++)
        {
                if (i != RefCol) OverMeanRidit += sizes[i] * meanridits[i];
        }
        OverMeanRidit /= (Freq[NoRows][NoToAnalyze] - sizes[RefCol]);
        sprintf(outline,"Overall mean for RIDITS in non-reference groups = %8.4f",OverMeanRidit);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        // obtain chisquare
        chisquare = 0.0;
        double term1,term2,term3,term4;
        term4 = (OverMeanRidit - 0.5) * (OverMeanRidit - 0.5);
        term3 = 0.0;
        for (i = 0; i < NoToAnalyze; i++)
        {
                if (i != RefCol) term3 += (sizes[i] * sizes[i]);
        }
        term3 = 12.0 * term3;
        term2 = (double) Freq[NoRows][NoToAnalyze];
        term1 = 0.0;
        for (i = 0; i < NoToAnalyze; i++)
        {
                if (i != RefCol)
                   term1 += (sizes[i] * ((meanridits[i] - 0.5) * (meanridits[i] - 0.5)));
        }
        term1 *= 12.0;
        chisquare = term1 - ((term3 / term2) * term4);
        probchi = 1.0 - chisquaredprob(chisquare,NoToAnalyze-1);
        sprintf(outline,"Chisquared = %8.3f with probability < %8.4f",chisquare,probchi);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        // do pairwise comparisons
        Cratios[RefCol] = 0.0;
        for (i = 0; i < NoToAnalyze; i++)
        {
                if (i != RefCol)
                {
                        StdErr[i] = sqrt(sizes[RefCol] + sizes[i]) /
                             (2.0 * sqrt(3.0 * sizes[RefCol] * sizes[i]));
                        Cratios[i] = ( meanridits[i] - 0.5) / StdErr[i];
                }
        }
        VPrint(Cratios,NoToAnalyze,ColLabels,"z critical ratios");
        alpha = alpha / 2.0;
        if (BonChk->Checked) alpha = alpha / (double)(NoToAnalyze - 1);
        Bonferroni = inversez(1.0 - alpha);
        sprintf(outline,"significance level used for comparisons = %8.3f",Bonferroni);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (i = 0; i < NoToAnalyze; i++)
        {
                if (i != RefCol)
                {
                        if (fabs(Cratios[i]) > Bonferroni)
                        {
                                sprintf(outline,"%s vs %s significant",ColLabels[i],ColLabels[RefCol]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                        else
                        {
                                sprintf(outline,"%s vs %s not significant",ColLabels[i],ColLabels[RefCol]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                }
        }
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();

        // cleanup
        delete[] StdErr;
        delete[] Cratios;
        delete[] meanridits;
        delete[] sizes;
        ClearDblMatMem(refprob,NoRows);
        ClearDblMatMem(probdists,NoRows);
}
//---------------------------------------------------------------------------

void __fastcall TRIDITForm::RefGrpClick(TObject *Sender)
{
        if (RefGrp->ItemIndex == 0) // do all variables as reference variable
        {
                Label4->Visible = false;
                RefEdit->Visible = false;
        }
        else
        {
                Label4->Visible = true;
                RefEdit->Visible = true;
        }
}
//---------------------------------------------------------------------------

