//---------------------------------------------------------------------------

#ifndef EquationUnitH
#define EquationUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TEquationForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *NewVarEdit;
    TComboBox *OpsCombo;
    TLabel *Label2;
    TComboBox *FunctionCombo;
    TComboBox *VarCombo;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TButton *NextBtn;
    TButton *FinishedBtn;
    TEdit *OpEdit;
    TEdit *FuncEdit;
    TEdit *VarEdit;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall NextBtnClick(TObject *Sender);
    void __fastcall FinishedBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall OpsComboClick(TObject *Sender);
    void __fastcall FunctionComboClick(TObject *Sender);
    void __fastcall VarComboClick(TObject *Sender);
private:	// User declarations
    AnsiString *operations, *functions, *variables;
    int *selected;
    int NoEntries;
    
public:		// User declarations
    __fastcall TEquationForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TEquationForm *EquationForm;
//---------------------------------------------------------------------------
#endif
