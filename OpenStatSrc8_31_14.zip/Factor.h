//---------------------------------------------------------------------------
#ifndef FactorH
#define FactorH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFactorFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TListBox *ListBox2;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TRadioGroup *RadioGroup1;
    TRadioButton *PrCompBtn;
    TRadioButton *PartImageBtn;
    TRadioButton *GuttmanBtn;
    TRadioButton *HarrisBtn;
    TRadioButton *CanonicalBtn;
    TRadioButton *AlphaBtn;
    TRadioGroup *RadioGroup2;
    TGroupBox *GroupBox1;
    TCheckBox *CorrChkBox;
    TCheckBox *DescChkBox;
    TCheckBox *UnVectChkBox;
    TCheckBox *PcntTrChkBox;
    TCheckBox *ScreeChkBox;
    TCheckBox *CommunChkBox;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OkBtn;
    TCheckBox *PlotFactChkBox;
    TLabel *Label3;
    TEdit *MinRootEdit;
    TButton *EnterAllBtn;
    TCheckBox *FactScrsChkBox;
    TCheckBox *SaveRChkBox;
    TCheckBox *SaveFChkBox;
    TLabel *Label4;
    TEdit *MaxIterEdit;
    TRadioButton *PAFBtn;
    TLabel *Label5;
    TEdit *MaxFactorsEdit;
    TCheckBox *SortChkBox;
	TRadioGroup *InputOptGrp;
	TLabel *Label6;
	TEdit *NoObsEdit;
	TOpenDialog *OpenDialog1;
	TSaveDialog *SaveDialog1;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall OkBtnClick(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall EnterAllBtnClick(TObject *Sender);
	void __fastcall InputOptGrpClick(TObject *Sender);
private:	// User declarations
	 int InputType;
    void __fastcall FACTORS(double *eigenvalues, double *d2, double **A, int N,int factorchoice);
    void __fastcall factREORDER(double *d, int *d2, double **A,AnsiString *var_label, int N);
    void __fastcall VARIMAX(double **v, int n1, int n2, AnsiString * RowLabels,
             AnsiString *ColLabels, int *order);
    void __fastcall SORT_LOADINGS(double **v, int n1, int n2, int *High_Factor,
             double *A, double *b, AnsiString *var_label, int *order);
    void __fastcall PROCRUST(double **b, int nv, int nb, AnsiString *RowLabels,
              AnsiString *ColLabels);
    void __fastcall LSFactScores(double **F, int NoVars, int NoFacts, int NCases,
                  int *ColNoSelected);
    void __fastcall QUARTIMAX(double **v, int n1, int n2, AnsiString * RowLabels,
              AnsiString *ColLabels, int *order);
    void __fastcall LoadFactors(double **matrix,int &rows,int &cols,
                   AnsiString *RowLabels, AnsiString *ColLabels);
    void __fastcall TFactorFrm::SaveFactors(double **Loadings, int k, int j,
                 AnsiString *RowLabels, AnsiString *ColLabels);
    void __fastcall KMO(int k, double **matrix);
    void __fastcall PROMAX(double **v, int n1, int n2, AnsiString * RowLabels,
              AnsiString *ColLabels, int *order);


public:		// User declarations
    __fastcall TFactorFrm(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TFactorFrm *FactorFrm;
//---------------------------------------------------------------------------
#endif

