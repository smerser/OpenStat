//---------------------------------------------------------------------------

#ifndef WLSUnitH
#define WLSUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TWLSForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TEdit *DepVarEdit;
    TLabel *Label3;
    TListBox *IndVarList;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ReturnBtn;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TBitBtn *IndInBtn;
    TBitBtn *IndOutBtn;
    TBitBtn *WghtInBtn;
    TBitBtn *WghtOutBtn;
    TGroupBox *GroupBox2;
    TCheckBox *OLSChk;
    TCheckBox *PlotChk;
    TCheckBox *RegResChk;
    TCheckBox *WeightChk;
    TButton *PrelimBtn;
    TCheckBox *UseWeightsChk;
    TCheckBox *OriginChk;
    TLabel *Label5;
    TEdit *WghtVarEdit;
    TCheckBox *UserWghtsChk;
    TMemo *Memo1;
    TCheckBox *Origin2Chk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall IndInBtnClick(TObject *Sender);
    void __fastcall IndOutBtnClick(TObject *Sender);
    void __fastcall WghtInBtnClick(TObject *Sender);
    void __fastcall WghtOutBtnClick(TObject *Sender);
    void __fastcall PrelimBtnClick(TObject *Sender);
private:	// User declarations
   void __fastcall PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars);
   void __fastcall TWLSForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double *UpConf,
                                      double *LowConf,
                                      double ConfBand,
                                      double Xmean,
                                      double Ymean,
                                      double R,
                                      double Slope,
                                      double Intercept,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N,
                                      AnsiString XLabel,
                                      AnsiString YLabel);

public:		// User declarations
    __fastcall TWLSForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWLSForm *WLSForm;
//---------------------------------------------------------------------------
#endif
