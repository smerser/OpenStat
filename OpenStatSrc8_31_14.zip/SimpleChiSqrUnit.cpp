//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "SimpleChiSqrUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSimpleChiSqr *SimpleChiSqr;
//---------------------------------------------------------------------------
__fastcall TSimpleChiSqr::TSimpleChiSqr(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSimpleChiSqr::NcatsEditExit(TObject *Sender)
{
        NoCats = StrToInt(NcatsEdit->Text);
        ObservedGrid->RowCount = NoCats+1;
        ExpectedGrid->RowCount = NoCats+1;
        ChiSqrGrid->RowCount = NoCats+1;
}
//---------------------------------------------------------------------------
void __fastcall TSimpleChiSqr::ResetBtnClick(TObject *Sender)
{
        NoCats = 1;
        ObservedGrid->RowCount = NoCats+1;
        ExpectedGrid->RowCount = NoCats+1;
        ChiSqrGrid->RowCount = NoCats+1;
        NcatsEdit->Text = "";
        ObservedGrid->Cells[0][0] = "Observed";
        ExpectedGrid->Cells[0][0] = "Expected";
        ChiSqrGrid->Cells[0][0] = "ChiSquare";
}
//---------------------------------------------------------------------------
void __fastcall TSimpleChiSqr::ComputeBtnClick(TObject *Sender)
{
        double TotalChiSqr;
        double chisqr, Obs, Exp, ChiProb, NObs, NExp;
        int i;
        char outline[101];

        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("Simple Chi-square Analysis Results");
        FrmOutPut->RichOutPut->Lines->Add("Category  ChiSquare");

        TotalChiSqr = 0.0;
        NObs = 0.0;
        NExp = 0.0;
        for (i = 1; i <= NoCats; i++)
        {
                Obs = StrToFloat(ObservedGrid->Cells[0][i]);
                NObs += Obs;
                Exp = StrToFloat(ExpectedGrid->Cells[0][i]);
                NExp += Exp;
                chisqr = sqr(Obs - Exp) / Exp;
                sprintf(outline,"%8.3f",chisqr);
                ChiSqrGrid->Cells[0][i] = outline; // FloatToStr(chisqr);
                TotalChiSqr += chisqr;
                sprintf(outline,"    %2d   %8.4f",i,chisqr);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        TotChiSqrEdit->Text = FloatToStr(TotalChiSqr);
        ChiProb = 1.0 - chisquaredprob(TotalChiSqr,NoCats); // prob. larger chi
        ProbEdit->Text = FloatToStr(ChiProb);
        //Print results to output form
        sprintf(outline,"Number Observed = %8.3f",NObs);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Total Number Expected = %8.3f",NExp);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"ChiSquare = %8.3f with Probability of a larger value = %8.3f",
             TotalChiSqr,ChiProb);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
}
//---------------------------------------------------------------------------
