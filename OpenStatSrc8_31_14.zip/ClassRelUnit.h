//---------------------------------------------------------------------------

#ifndef ClassRelUnitH
#define ClassRelUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TClassRelForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TMemo *Memo1;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TLabel *Label2;
    TEdit *ClassVarEdit;
    TLabel *Label3;
    TEdit *NoCatsEdit;
    TStringGrid *ClassGrid;
    TButton *CancelBtn;
    TButton *ResetBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TLabel *Label4;
    TEdit *NoItemsEdit;
    TLabel *Label6;
    TEdit *NoTestedEdit;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TMemo *Memo2;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall NoCatsEditExit(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall NoCatsEditKeyPress(TObject *Sender, char &Key);
    void __fastcall NoItemsEditKeyPress(TObject *Sender, char &Key);
private:	// User declarations
    double *F, *CF, *XA, *XB;
    int N, M, K, col, *L;
    double XBAR, SD, X;
    char outline[101];

    void __fastcall KAPPA(int N, double &A, double &B, int K,
                int *L, int M, double &XP, double &SDP, double &XK,
                double &SDK);

    void __fastcall NEHY(int N, double &A, double &B, double *F, double *CF);

    void __fastcall BF(int N, int &LL, int &LU, double &A, double &B,
              double &BFZ, double &DBFA, double &DBFB, double &DSA,
              double &DSB, double &SUMBF);

    void __fastcall ZERLAB(int N, double &A, double &B, double *XA,
                double *XB, double *F);

    void __fastcall VARAB(int N, double &A, double &B, double &VA, double &VB,
                      double &VAB, int M, double *F, double *DA, double *DB);

    void __fastcall DERLAB(int N, double A, double B, double *DA, double *DB);

public:		// User declarations
    __fastcall TClassRelForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TClassRelForm *ClassRelForm;
//---------------------------------------------------------------------------
#endif
