//---------------------------------------------------------------------------

#ifndef DifferenceUnitH
#define DifferenceUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TDifferenceFrm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *LagEdit;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *OrderEdit;
    TLabel *Label4;
    TButton *CancelBtn;
    TButton *OKBtn;
private:	// User declarations
public:		// User declarations
    __fastcall TDifferenceFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDifferenceFrm *DifferenceFrm;
//---------------------------------------------------------------------------
#endif
