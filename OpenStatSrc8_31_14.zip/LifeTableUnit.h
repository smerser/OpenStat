//---------------------------------------------------------------------------

#ifndef LifeTableUnitH
#define LifeTableUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TLifeTableForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TListBox *LstVariables;
        TBitBtn *ObsInBtn;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *ObsStartEdit;
        TBitBtn *ObsOutBtn;
        TLabel *Label3;
        TEdit *NoAliveEdit;
        TBitBtn *NoAliveInBtn;
        TBitBtn *NoAliveOutBtn;
        TLabel *Label4;
        TEdit *NoDiedEdit;
        TBitBtn *NoDiedInBtn;
        TBitBtn *NoDiedOutBtn;
        TLabel *Label5;
        TEdit *CensoredEdit;
        TBitBtn *CensoredInBtn;
        TBitBtn *CensoredOutBtn;
        TStringGrid *LifeTableGrid;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *Return;
        TLabel *Label6;
        TEdit *ObsEndEdit;
        TBitBtn *EndInBtn;
        TBitBtn *EndOutBtn;
        TLabel *Label7;
        TEdit *ConfidenceEdit;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall ObsInBtnClick(TObject *Sender);
        void __fastcall ObsOutBtnClick(TObject *Sender);
        void __fastcall NoAliveInBtnClick(TObject *Sender);
        void __fastcall NoAliveOutBtnClick(TObject *Sender);
        void __fastcall NoDiedInBtnClick(TObject *Sender);
        void __fastcall NoDiedOutBtnClick(TObject *Sender);
        void __fastcall CensoredInBtnClick(TObject *Sender);
        void __fastcall CensoredOutBtnClick(TObject *Sender);
        void __fastcall EndInBtnClick(TObject *Sender);
        void __fastcall EndOutBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TLifeTableForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLifeTableForm *LifeTableForm;
//---------------------------------------------------------------------------
#endif
