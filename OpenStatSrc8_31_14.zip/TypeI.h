//---------------------------------------------------------------------------
#ifndef TypeIH
#define TypeIH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTypeIFrm : public TForm
{
__published:	// IDE-managed Components
    TListBox *ListBox1;
    TListBox *ListBox2;
    TLabel *Label1;
    TLabel *Label2;
    TGroupBox *GroupBox1;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *GroupVar;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ResetBtn;
    TGroupBox *GroupBox2;
    TCheckBox *CheckBox1;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TButton *SelectBtn;
    TCheckBox *CheckBox2;
        TCheckBox *PostHocChk;
        TLabel *Label5;
        TEdit *AlphaEdit;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall ListBox2Click(TObject *Sender);
    void __fastcall SelectBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
    void __fastcall PlotMeans(double **C, int range, int k, TObject *Sender);
    void __fastcall PostHocTests(int NoSelected, double MSerr,
                int dferr, int count, double *ColMeans, double alpha, TObject *Sender);
public:		// User declarations
    __fastcall TTypeIFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTypeIFrm *TypeIFrm;
//---------------------------------------------------------------------------
#endif
