//---------------------------------------------------------------------------

#ifndef MinMaxUnitH
#define MinMaxUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TMinMaxForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TBitBtn *IndInBtn;
    TBitBtn *IndOutBtn;
    TLabel *Label2;
    TEdit *DepEdit;
    TLabel *Label3;
    TListBox *SelList;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TGroupBox *GroupBox1;
    TCheckBox *MeansChk;
    TCheckBox *VariancesChk;
    TCheckBox *StdDevsChk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall IndInBtnClick(TObject *Sender);
    void __fastcall IndOutBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TMinMaxForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMinMaxForm *MinMaxForm;
//---------------------------------------------------------------------------
#endif
