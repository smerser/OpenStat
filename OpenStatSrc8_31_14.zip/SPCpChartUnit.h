//---------------------------------------------------------------------------

#ifndef SPCpChartUnitH
#define SPCpChartUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSPCpChartForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TRadioGroup *SigmaGroup;
     TLabel *Label3;
     TEdit *MeasEdit;
     TEdit *SigmaEdit;
     TButton *ResetBtn;
     TButton *ComputeBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TGroupBox *GroupBox1;
     TEdit *PEdit;
     TGroupBox *GroupBox2;
     TEdit *NEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean, double Target,
                             TObject *Sender);

private:	// User declarations
public:		// User declarations
     __fastcall TSPCpChartForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSPCpChartForm *SPCpChartForm;
//---------------------------------------------------------------------------
#endif
