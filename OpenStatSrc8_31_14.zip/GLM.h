//---------------------------------------------------------------------------
#ifndef GLMH
#define GLMH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TGLMFrm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TListBox *ListBox2;
    TLabel *Label3;
    TListBox *ListBox3;
    TLabel *Label4;
    TListBox *ListBox4;
    TLabel *Label5;
    TListBox *ListBox5;
    TRadioGroup *RadioGroup1;
    TRadioGroup *RadioGroup3;
    TGroupBox *GroupBox1;
    TCheckBox *DescChkBox;
    TCheckBox *CorrChkBox;
    TCheckBox *zPlotChkBox;
    TCheckBox *RawResidChkBox;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TBitBtn *FixedInBtn;
    TBitBtn *FixedOutBtn;
    TBitBtn *RndmInBtn;
    TBitBtn *RndmOutBtn;
    TBitBtn *CovInBtn;
    TBitBtn *CovOutBtn;
    TLabel *Label6;
    TListBox *DepAbrevList;
    TListBox *FixedAbrevList;
    TListBox *RndAbrevList;
    TListBox *CovAbrevList;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TListBox *InterAbrevList;
    TLabel *Label10;
    TLabel *Label11;
    TEdit *ModelEdit;
    TLabel *Label12;
    TButton *StrtInterBtn;
    TButton *EndInterBtn;
    TButton *ShowModBtn;
    TLabel *Label13;
    TLabel *Label14;
    TLabel *Label15;
    TListBox *CatDepAbbrevList;
    TRadioGroup *TypeGroup;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall FixedInBtnClick(TObject *Sender);
    void __fastcall RndmInBtnClick(TObject *Sender);
    void __fastcall CovInBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall FixedOutBtnClick(TObject *Sender);
    void __fastcall RndmOutBtnClick(TObject *Sender);
    void __fastcall CovOutBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall ShowModBtnClick(TObject *Sender);
    void __fastcall StrtInterBtnClick(TObject *Sender);
    void __fastcall FixedAbrevListClick(TObject *Sender);
    void __fastcall RndAbrevListClick(TObject *Sender);
    void __fastcall CovAbrevListClick(TObject *Sender);
    void __fastcall EndInterBtnClick(TObject *Sender);
    void __fastcall InterCoding(TObject *Sender);
private:	// User declarations
    bool InterStart;
    AnsiString InterTerm;
    int *FixedCols;
    int *DepCols;
    int *CovCols;
    int *RndCols;
    int **FixVectCols;
    int **RndVectCols;
    int **DepVectCols;
    int *CovVectCols;
    int **IntVarCol;
    int *IntTermCnt;
    int **IntTermType;
    int **IntFixNo;
    int **IntRndNo;
    int **IntCovNo;
    int *FixedLevels;
    int *RndLevels;
    int *IntVectCnt;
    int *CatDepCols;
    int *CatDepLevels;
    int NoTerms;
    int IntVarCnt;
    int startcol;
    int NoDep;
    int NoContDep;
    int NoCatDep;
    int NoFixed;
    int NoRnd;
    int NoCov;
public:		// User declarations
    __fastcall TGLMFrm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGLMFrm1 *GLMFrm1;
//---------------------------------------------------------------------------
#endif
void VectorCodes(int NoLevels, int Type, int **Codes);
void MainCoding(int NFactors, int NoCases, int TypeCode, int *Levels,
                 int *MainCols, int startcol,int FactorType,
                 int **FixVectCols, int **RndVectCols, int **DepVectCols);
void MReg(int NoContDep,int NoFixed,int NoRnd,int NoCov,int NoInt, int *DepCols,
          int *FixedCols,int *RndCols,int *CovCols,int *FixedLevels,
          int *RndLevels, int *IntVectCnt, int TypeCode);
void CanReg(int NoDep, int NoCatDep, int NoFixed, int NoRnd, int NoCov,int NoInt,
          int *DepCols, int *CatDepCols, int *FixedCols, int *RndCols,
          int *CovCols, int * CatDepLevels, int *FixedLevels,
          int *RndLevels, int *IntVectCnt, int TypeCode, bool mancova);
int GetCorrs(double *Means, double *StdDevs, double **rmat,
             int NoIn, int *GridIn, int NoCases, int prtopt,
             int mattype);
void MPrint(double **Matrix, int Nrows, int Ncols, int *selected, char *Title);
void vprint(double *vector, int *selected, int Ncols, char *Title);
double ShowStep(int NoIndep, double **InverseMat, double *rxy, double *W,
     int *indx, double *Means, double *Variances, double *StdDevs,
     int count, double OldR2, int OldNoIndep);


