//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "NonLinUnit.h"
#include "EquatProcs.h"
#include "string.h"
#include "math.hpp"
#include "math.h"
#include <stdio.h>
#include "OutPut.h"
#include "MainUnit.h"
#include "DictionaryUnit.h"
#include "MemMgrUnit.h"
#include "DataFuncs.h"
#include "PlotUnit.h"
#include "GraphUnit.h"
#include "functions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEquatParseForm *EquatParseForm;
//extern struct VarDef *vdef[1000];
//extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
//extern char FileName[81];

//---------------------------------------------------------------------------
__fastcall TEquatParseForm::TEquatParseForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TEquatParseForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
     VarList->Items->Add(MainForm->Grid->Cells[i][0]);
        Grid->Cells[0][0] = "VAR.(x?)";
        Grid->Cells[1][0] = "PARMS";
        Grid->Cells[2][0] = "ESTIMATE";
        Grid->Cells[3][0] = "STD.ERR.";
        Grid->Cells[4][0] = "t PROB.";
        for (int i = 0; i < 5; i++) // column
           for (int j = 1; j < 9; j++) // row
              Grid->Cells[i][j] = "";
        Grid->Cells[1][1] = "a = ";
        Grid->Cells[1][2] = "b = ";
        Grid->Cells[1][3] = "c = ";
        Grid->Cells[1][4] = "d = ";
        Grid->Cells[1][5] = "e = ";
        Grid->Cells[1][6] = "f = ";
        Grid->Cells[1][7] = "g = ";
        Grid->Cells[1][8] = "h = ";
        FileNameEdit->Text = "";
        EquationEdit->Text = "";
        AnalyzedEdit->Text = "";
        DepEdit->Text = "";
        ResultEdit->Text = "";
        FuncBox->Text = "Available Functions";
        OpsBox->Text = "Operations";
        DepInBtn->Visible = true;
        DepOutBtn->Visible = false;
        InBtn->Visible = true;
        OutBtn->Visible = false;
        NoItsEdit->Text = "";
        ComboBox1->ItemIndex = -1;
        ComboBox1->Text = "Models";
        ParmBox->ItemIndex = -1;
        ParmBox->Text = "Parameters";
        VarsBox->ItemIndex = -1;
        VarsBox->Text = "Variables";
        NParms = 0;
        NVars = 0;
        PlotXYBox->Checked = false;
        PlotYYBox->Checked = false;
        SaveBox->Checked = false;
        ShowItsChk->Checked = false;
        IterResultsChk->Checked = false;
        SaveResidBox->Checked = false;
        AbsDevBox->Checked = false;
        ConfIntEdit->Text = "95";
        FileNameEdit->Text = MainForm->FileNameEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TEquatParseForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::ComputeBtnClick(TObject *Sender)
{
   done = false;
   int Iterations = 0;
   oldrms = 0.0;
   ccSW = 1.0;
   ccAv = 0.0;
   ccSD = 1.0;
   for (int i = 0; i < 8; i++)
   {
        Par[i] = 0.0;
        SEP[i] = 1.0;
        xArr[i] = 0.0;
        for (int j = 0; j < 8; j++) Cov[i][j] = 0.0;
        for (int j = 0; j < 9; j++) Arr[i][j] = 0.0;
   }
   for (int i = 0; i < 9; i++) Der[i] = 0.0;

   // Get dependent and independent variable columns
   for (int i = 1; i <= NoVariables; i++)
   {
      if (DictionaryForm->DGrid->Cells[1][i] == DepEdit->Text) ycol = i;
      for (int j = 1; j <= NVars; j++)
      {
        if (DictionaryForm->DGrid->Cells[1][i] == Grid->Cells[0][j]) xcols[j-1] = i;
      }
   }
   strcpy(parsestr,EquationEdit->Text.c_str());

   // Get parameter values
   NParms = 0;
   for (int i = 1; i <= 8; i++)
   {
   	if (Grid->Cells[2][i] == "") continue;
      ParmValues[NParms] = StrToFloat(Grid->Cells[2][i]);
      NParms++;
   }

   // read file and store data in Data array
   ReadCases(this);

   // plot x's versus observed y if user selected
   if (PlotXYBox->Checked) Plotit();

   // Calculate the fit
   while (!done)
   {
      Iterate(this);
      if (ShowItsChk->Checked)
      {
      	AnsiString answer = InputBox("MORE?","Yes = y, No = n","y");
      	if (answer != "y") done = true;
      }
		Iterations++;
      if (fabs(oldrms - RMS) < 0.00001)
      {
      	done = true;
         Iterate(this); // do one more
      }
      else oldrms = RMS;
      if (Iterations > 1000) done = true;
   }
   NoItsEdit->Text = Iterations;
   if (PlotYYBox->Checked) plotxy(this);
   if (SaveBox->Checked) SavePred();
   if (SaveResidBox->Checked) SaveResid();

   // cleanup the heap
   for (int i = 0; i < nrows; i++) delete Data[i];
   delete Data;
   FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::FuncBoxClick(TObject *Sender)
{
	char funcstr[51];
   char selstr[51];
   int index = FuncBox->ItemIndex;
   strcpy(selstr,FuncBox->Items->Strings[index].c_str());
   int j = 0;
   for (unsigned int i = 0; i < strlen(selstr); i++)
   {
   	if (selstr[i] == ';') break;
      else
      {
      	funcstr[j] = selstr[i];
         j++;
      }
   }
   funcstr[j] = 0; // null terminator of string
   EquationEdit->Text = EquationEdit->Text + funcstr;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::OpsBoxClick(TObject *Sender)
{
	char funcstr[51];
   char selstr[51];
   int index = OpsBox->ItemIndex;
   strcpy(selstr,OpsBox->Items->Strings[index].c_str());
   int j = 0;
   for (unsigned int i = 0; i < strlen(selstr); i++)
   {
   	if (selstr[i] == ';') break;
      else
      {
      	funcstr[j] = selstr[i];
         j++;
      }
   }
   funcstr[j] = 0; // null terminator of string
   EquationEdit->Text = EquationEdit->Text + funcstr;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::InBtnClick(TObject *Sender)
{
     if (VarList->Items->Count <= 0) return;
     int index = VarList->ItemIndex;
     NVars++;
     Grid->Cells[0][NVars] = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     if (VarList->Items->Count <= 0) InBtn->Visible = false;
     if (Grid->Cells[1][9] != "") InBtn->Visible = false;
     OutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::OutBtnClick(TObject *Sender)
{
	int index = Grid->Row;
   VarList->Items->Add(Grid->Cells[0][index]);
   Grid->Cells[0][index] = "";
   NVars--;
   InBtn->Visible = true;
   if (index == 0) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::DepInBtnClick(TObject *Sender)
{
	if (VarList->Items->Count <= 0) return;
	int index = VarList->ItemIndex;
   DepEdit->Text = VarList->Items->Strings[index];
   VarList->Items->Delete(index);
   DepInBtn->Visible = false;
   DepOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::DepOutBtnClick(TObject *Sender)
{
	VarList->Items->Add(DepEdit->Text);
   DepEdit->Text = "";
   DepInBtn->Visible = true;
   DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::ComboBox1Click(TObject *Sender)
{
	char modstring[101];
   char cleanmodel[101];
   AnsiString Model;
   int count = 0;
   int index = ComboBox1->ItemIndex;
   strcpy(modstring,ComboBox1->Items->Strings[index].c_str());
   strcpy(cleanmodel,"");
   for (unsigned int i = 0; i < strlen(modstring); i++)
   {
   	if (modstring[i] != ';')
      {
      	cleanmodel[count] = modstring[i];
         count++;
      }
      else break;
   }
   cleanmodel[count] = 0; // terminate string
   Model = cleanmodel;
   EquationEdit->Text = Model;
   AnalyzedEdit->Text = Model;
   funcno = index + 1;
   if (funcno == 15) EquationEdit->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::ReadCases(TObject *Sender)
{
     // allocate storage for data
     Data = new double*[NoCases];
     for (int i = 0; i < NoCases; i++) Data[i] = new double[NoVariables];

     // read data
     for (int i = 1; i <= NoCases; i++) // file case
     {
         for (int j = 1; j <= NoVariables; j++) // case variables
         {
            Data[i-1][j-1] = StrToFloat(MainForm->Grid->Cells[j][i]);
         }
     }
}
//---------------------------------------------------------------------

void __fastcall TEquatParseForm::Iterate(TObject *Sender)
{
   AnsiString o;
   char value[101];
   char modstring[101];
   char OpsString[101];
	int i, j, k;
	int nPar;
	int nVar;
	int nPts = 0;

	double cccSW = 0.0;
	double cccAv = 0.0;
	double cccSD = 0.0;

	nPts = NoCases;
	nPar = NParms;
	nVar = NVars;
	int dgfr = nPts - nPar;

	// get percentile from user
	double Pctile = StrToFloat(ConfIntEdit->Text) /100.0;

	// Get t value for 95% confidence level
//	double St95 = AStudT( 1.0 - Pctile , dgfr );
    double St95 = inverset(Pctile, dgfr);
   // get the percentage to fall below the curve from user (if elected)
   //	double a = StrToFloat(NonLinFrm->Grid->Cells[2][1]);

	// get parameters from the grid
	a = ParmValues[0];
	Par[0] = a;
	b = ParmValues[1];
	Par[1] = b;
	c = ParmValues[2];
	Par[2] = c;
	d = ParmValues[3];
	Par[3] = d;
	e = ParmValues[4];
	Par[4] = e;
	f = ParmValues[5];
	Par[5] = f;
	g = ParmValues[6];
	Par[6] = g;
	h = ParmValues[7];
	Par[7] = h;

   if ((done) || (IterResultsChk->Checked))
   {
      FrmOutPut->RichOutPut->Lines->Add("");
   	o = EquationEdit->Text;
		FrmOutPut->RichOutPut->Lines->Add(o);
   	o = "     x" + IntToStr(i+1) + "   ";
		o = o + "     y         yc       y-yc       SEest       YcLo       YcHi  ";
   	FrmOutPut->RichOutPut->Lines->Add(o);
   }

	double SSq = 0.0;
   for (i = 0; i < nPar; i++)
   	for (j = 0; j < nPar+1; j++) Arr[i][j] = 0;

	// get x data for each case and variance estimate of the x values
	for (i = 1; i <= nPts; i++) // case i
   {
		for (j = 0; j < nVar; j++) // variable j
		{
			xArr[j] = Data[i-1][xcols[j]-1];
   		if ((fabs(oldrms - RMS) < 0.0001) || (IterResultsChk->Checked))
   		{
         	sprintf(value,"%11.5f",xArr[j]);
         	o = value;
         }
		}
      double x = xArr[0]; // for use when only x is used in the formula
      x1 = x;
		x2 = xArr[1];
		x3 = xArr[2];
		x4 = xArr[3];
		x5 = xArr[4];
		x6 = xArr[5];
		x7 = xArr[6];
		x8 = xArr[7];

		// get computed y value
      strcpy(OpsString,EquationEdit->Text.c_str());
      strcpy(modstring,OpsString);
      double yc;
   	  switch (funcno)
      {
			case 1: yc = a + b * x1; break;
			case 2: yc = a * x1; break;
			case 3: yc = a  + b * x1 + c * x1 * x1 ; break;
			case 4: yc = a + x1* (b + x1 * (c + x1* (d + x1 * (e + x1 * (f + x1 * (g + x1 * h)))))) ;
                 break;
			case 5: yc = a + b * x1 + c * x2 + d * x3 + e * x4 + f * x5 + g * x6 + h * x7 ;
         		  break;
			case 6: yc = a * exp(-b * x1) ; break;
			case 7: yc = (a - c) * exp(-b * x1) + c ; break;
			case 8: yc = a * exp(-b * x1) + c * exp(-d * x1) + e * exp(-f * x1) + g * exp(-h * x1) ;
                 break;
			case 9: yc = a + b * exp(-c * x1) + d * exp(-e * x1) + f * exp(-g * x1) ;
                 break;
			case 10: yc = a / (pow(2,(x1 / b ))) ; break;
			case 11: yc = (a - c) / (pow(2,(x1 / b))) + c ; break;
			case 12: yc = exp(a - (b / x1)) ; break;
			case 13: yc = exp(a - (b / (x1 + c))) ; break;
			case 14: yc = a + b * sin(x1) ; break;
			case 15: strcpy(OpsString,modstring); // restore parsestr
                  yc = eval(OpsString,NParms,NVars,Par,xArr);
                  break;
      } // end switch

	  // get observed y value for this case
	  double y = Data[i-1][ycol-1];

	  // get standard error from the form
      double w;
      double vSEy = 0.0;
      if (StdErrYEdit->Text != "") vSEy = StrToFloat(StdErrYEdit->Text);
		if(vSEy == 0.0) w = 0.001;
      else w = vSEy;

	  double yo = y;

		if(AbsDevBox->Checked)
		{
			if(y < yc) w = w * max( sqrt(Pctile * fabs(y-yc)) , 0.001 * y );
			else w = w * max( sqrt((1.0 - Pctile) * fabs(y-yc)) , 0.001 * y );
		}

		cccSW = cccSW + 1 / ( w * w );
		cccAv = cccAv + yc / ( w * w );
		cccSD = cccSD + ( y - ccAv ) * ( y - ccAv ) / ( w * w );

		for (j = 0; j < nPar; j++)
		{
			double Save = Par[j];
            double Del;
			if(Save == 0.0) Del = 0.0001;
			else Del = Save / 1000.0;
			Par[j] = Save + Del;
			a=Par[0];
			b=Par[1];
			c=Par[2];
			d=Par[3];
			e=Par[4];
			f=Par[5];
			g=Par[6];
			h=Par[7];

         // get derivative for parameter j by evaluating the function with the
			// change in parameter j
         double ytemp;
   		 switch (funcno)
      	 {
				case 1: ytemp = a + b * x1; break;
				case 2: ytemp = a * x1; break;
				case 3: ytemp = a  + b * x1 + c * x1 * x1 ; break;
				case 4: ytemp = a + x1* (b + x1 * (c + x1* (d + x1 * (e + x1 * (f + x1 * (g + x1 * h)))))) ;
                 break;
				case 5: ytemp = a + b * x1 + c * x2 + d * x3 + e * x4 + f * x5 + g * x6 + h * x7 ;
         		  break;
				case 6: ytemp = a * exp(-b * x1) ; break;
				case 7: ytemp = (a - c) * exp(-b * x1) + c ; break;
				case 8: ytemp = a * exp(-b * x1) + c * exp(-d * x1) + e * exp(-f * x1) + g * exp(-h * x1) ;
                 break;
				case 9: ytemp = a + b * exp(-c * x1) + d * exp(-e * x1) + f * exp(-g * x1) ;
                 break;
				case 10: ytemp = a / (pow(2,(x1 / b ))) ; break;
				case 11: ytemp = (a - c) / (pow(2,(x1 / b))) + c ; break;
				case 12: ytemp = exp(a - (b / x1)) ; break;
				case 13: ytemp = exp(a - (b / (x1 + c))) ; break;
				case 14: ytemp = a + b * sin(x1) ; break;
				case 15: strcpy(OpsString,modstring); // restore parsestr
                  ytemp = eval(OpsString,NParms,NVars,Par,xArr);
                  break;
      	} // end switch

			Der[j] = ( ytemp - yc ) / ( Del * w );
			Par[j] = Save; // restore parameter
			a=Par[0];
			b=Par[1];
			c=Par[2];
			d=Par[3];
			e=Par[4];
			f=Par[5];
			g=Par[6];
			h=Par[7];
		} // next parameter j

		Der[nPar] = (y - yc) / w;
		SSq = SSq + Der[nPar]*Der[nPar];

		// store products of parameter derivatives in Arr[]
		for (j = 0; j < nPar; j++)
		{
			for (k = 0; k <= nPar; k++)
			{
				Arr[j][k] = Arr[j][k] + Der[j] * Der[k];
			}
		}

		// get standard errors and covariances
		double SEest = 0;
		for (j = 0; j < nPar; j++)
		{
			SEest = SEest + Cov[j][j] * Der[j] * Der[j];
			for (k = j+1; k < nPar; k++)
			{
				SEest = SEest + 2.0 * Cov[j][k] * Der[j] * Der[k];
			}
		}
		SEest = w * sqrt(SEest);
		double yco = yc;
		double ycl = yc - St95 * SEest;
		double ych = yc + St95 * SEest;

   	if ((done) || (IterResultsChk->Checked))
   	{
      	sprintf(value,"%10.5f",yo);
      	o = o + value;
      	sprintf(value,"%10.5f",yco);
      	o = o + value;
      	sprintf(value,"%10.5f ",(yo-yco));
      	o = o + value;
      	sprintf(value,"%10.5f ",SEest);
      	o = o + value;
      	sprintf(value,"%10.5f ",ycl);
      	o = o + value;
      	sprintf(value,"%10.5f ",ych);
      	o = o + value;
			FrmOutPut->RichOutPut->Lines->Add(o);
      }
	} // next case

	ccSW = cccSW;
	ccAv = cccAv / ccSW;
	ccSD = cccSD / ccSW;
	double GenR2 = (ccSD-(SSq/ccSW))/ccSD;
	double GenR = sqrt(GenR2);
   if ((done) || (IterResultsChk->Checked))
   {
      FrmOutPut->RichOutPut->Lines->Add("");
   	sprintf(value,"Corr. Coeff. = %10.5f  R2 = %10.5f",GenR,GenR2);
   	o = value;
   	FrmOutPut->RichOutPut->Lines->Add(o);
   }

	RMS = sqrt(SSq / Max(1,dgfr));
   if ((done) || (IterResultsChk->Checked))
   {
   	sprintf(value,"RMS Error = %10.5f, d.f. = %d  SSq = %10.5f",RMS,dgfr,SSq);
   	FrmOutPut->RichOutPut->Lines->Add(value);
   }

   EquatParseForm->ResultEdit->Text = FloatToStr(RMS);

	for (i = 0; i < nPar; i++)
	{
		double s = Arr[i][i];
      if (s < 0.0001) s = 1.0;
		Arr[i][i] = 1.0;
		for (k = 0; k <= nPar; k++) Arr[i][k] = Arr[i][k] / s;
		for (j = 0; j < nPar; j++)
		{
			if (i != j)
			{
				s = Arr[j][i];
				Arr[j][i] = 0.0;
				for (k = 0; k <= nPar; k++)
				{
					Arr[j][k] = Arr[j][k] - s * Arr[i][k];
				}
			}
		}
	}

   double FRelax = 0.5;
   if ((done) || (IterResultsChk->Checked))
   {
      FrmOutPut->RichOutPut->Lines->Add("");
   	o = "Parameter Estimates ...";
   	FrmOutPut->RichOutPut->Lines->Add(o);
   }
   for (i = 0; i < nPar; i++)
   {
   	Par[i] = Par[i] + FRelax * Arr[i][nPar];
      SEP[i] = RMS * sqrt(Arr[i][i]);
   	if ((done) || (IterResultsChk->Checked))
   	{
//      	sprintf(value,"p%d= %10.5f  +/-  %10.5f  p= %10.5f",i+1,Par[i],SEP[i],
//              StudT(Par[i]/SEP[i],dgfr));
      	sprintf(value,"p%d= %10.5f  +/-  %10.5f  p= %10.5f",i+1,Par[i],SEP[i],
              tprob(Par[i]/SEP[i],dgfr));

      	FrmOutPut->RichOutPut->Lines->Add(value);
      }
   }

   if ((done) || (IterResultsChk->Checked))
   {
      FrmOutPut->RichOutPut->Lines->Add("");
		o = "Covariance Matrix Terms and Error-Correlations...";
   	FrmOutPut->RichOutPut->Lines->Add(o);
   }
	for (j = 0; j < nPar; j++)
	{
		for (k = j; k < nPar; k++)
		{
			Cov[j][k] = Arr[j][k] * RMS * RMS;
			double v = Arr[j][k] / sqrt(Arr[j][j] * Arr[k][k]);
   		if ((done) || (IterResultsChk->Checked))
   		{
				o = "B(" + IntToStr(j+1) + "," + IntToStr(k+1) + ")=" ;
				if(j != k)
            {
               o = "B(" + IntToStr(j+1) + "," + IntToStr(k+1) + ")=" ;
         		o = o + "B(" + IntToStr(k+1) + "," + IntToStr(j+1) + ")=" ;
            }
            else
            	o = "B(" + IntToStr(j+1) + "," + IntToStr(k+1) + ")=       " ;
				o = o + "   ";
            sprintf(value,"%10.5f",Cov[j][k]);
				o = o + value;
				o = o + "; r=";
            sprintf(value,"%10.5f",v);
            o = o + value;
         	FrmOutPut->RichOutPut->Lines->Add(o);
         }
		}
	}

	// output the parameters, their standard errors and the root mean square error
   sprintf(value,"%10.5f",Par[0]);
   EquatParseForm->Grid->Cells[2][1] = value;
   ParmValues[0] = Par[0];
   sprintf(value,"%10.5f",SEP[0]);
   EquatParseForm->Grid->Cells[3][1] = value;
//   sprintf(value,"%10.5f",StudT(Par[0]/SEP[0],dgfr));
   sprintf(value,"%10.5f",tprob(Par[0]/SEP[0],dgfr));
   EquatParseForm->Grid->Cells[4][1] = value;

   sprintf(value,"%10.5f",Par[1]);
	EquatParseForm->Grid->Cells[2][2] = value;
   ParmValues[1] = Par[1];
   sprintf(value,"%10.5f",SEP[1]);
   EquatParseForm->Grid->Cells[3][2] = value;
//   sprintf(value,"%10.5f",StudT(Par[1]/SEP[1],dgfr));
   sprintf(value,"%10.5f",tprob(Par[1]/SEP[1],dgfr));
   EquatParseForm->Grid->Cells[4][2] = value;

   sprintf(value,"%10.5f",Par[2]);
	EquatParseForm->Grid->Cells[2][3] = value;
   ParmValues[2] = Par[2];
   sprintf(value,"%10.5f",SEP[2]);
   EquatParseForm->Grid->Cells[3][3] = value;
//   sprintf(value,"%10.5f",StudT(Par[2]/SEP[2],dgfr));
   sprintf(value,"%10.5f",tprob(Par[2]/SEP[2],dgfr));
   EquatParseForm->Grid->Cells[4][3] = value;

   sprintf(value,"%10.5f",Par[3]);
	EquatParseForm->Grid->Cells[2][4] = value;
   ParmValues[3] = Par[3];
   sprintf(value,"%10.5f",SEP[3]);
   EquatParseForm->Grid->Cells[3][4] = value;
//   sprintf(value,"%10.5f",StudT(Par[3]/SEP[3],dgfr));
   sprintf(value,"%10.5f",tprob(Par[3]/SEP[3],dgfr));
   EquatParseForm->Grid->Cells[4][4] = value;

   sprintf(value,"%10.5f",Par[4]);
	EquatParseForm->Grid->Cells[2][5] = value;
   ParmValues[4] = Par[4];
   sprintf(value,"%10.5f",SEP[4]);
   EquatParseForm->Grid->Cells[3][5] = value;
//   sprintf(value,"%10.5f",StudT(Par[4]/SEP[4],dgfr));
   sprintf(value,"%10.5f",tprob(Par[4]/SEP[4],dgfr));
   EquatParseForm->Grid->Cells[4][5] = value;

   sprintf(value,"%10.5f",Par[5]);
	EquatParseForm->Grid->Cells[2][6] = value;
   ParmValues[5] = Par[5];
   sprintf(value,"%10.5f",SEP[5]);
   EquatParseForm->Grid->Cells[3][6] = value;
//   sprintf(value,"%10.5f",StudT(Par[5]/SEP[5],dgfr));
   sprintf(value,"%10.5f",tprob(Par[5]/SEP[5],dgfr));
   EquatParseForm->Grid->Cells[4][6] = value;

   sprintf(value,"%10.5f",Par[6]);
	EquatParseForm->Grid->Cells[2][7] = value;
   ParmValues[6] = Par[6];
   sprintf(value,"%10.5f",SEP[6]);
   EquatParseForm->Grid->Cells[3][7] = value;
//   sprintf(value,"%10.5f",StudT(Par[6]/SEP[6],dgfr));
   sprintf(value,"%10.5f",tprob(Par[6]/SEP[6],dgfr));
   EquatParseForm->Grid->Cells[4][7] = value;

   sprintf(value,"%10.5f",Par[7]);
	EquatParseForm->Grid->Cells[2][8] = value;
   ParmValues[7] = Par[7];
   sprintf(value,"%10.5f",SEP[7]);
   EquatParseForm->Grid->Cells[3][8] = value;
//   sprintf(value,"%10.5f",StudT(Par[7]/SEP[7],dgfr));
   sprintf(value,"%10.5f",tprob(Par[7]/SEP[7],dgfr));
   EquatParseForm->Grid->Cells[4][8] = value;
}

//-------------------------------------------------------------------------------------

double __fastcall TEquatParseForm::AStudT(double p, int n)
{
	double v = 0.5;
	double dv = 0.5;
	double t = 0.0;
    	while(dv > 1e-6)
	{
		t = 1.0 / v - 1;
		dv = dv / 2.0;
		if (StudT(t,n) > p) v = v - dv;
 		else v = v + dv;
	}
    	return (t);
}
//-------------------------------------------------------------------------------------
/*
double __fastcall TEquatParseForm::StudT(double t, int n)
{
    t = fabs(t);
    double w = t / sqrt(n);
    double th = atan(w);
    if (n == 1) return (1.0 - th / M_PI/2.0);
    double sth = sin(th);
    double cth = cos(th);
    if((n%2)==1) return (1.0 -(th + sth * cth * StatCom(cth * cth, 2, n-3, -1)) / M_PI/2.0);
    else return (1.0 - sth * StatCom(cth * cth, 1, n - 3, -1));
}
//-------------------------------------------------------------------------------------

double __fastcall TEquatParseForm::StatCom(double q, int i, int j, int b)
{
    double zz = 1.0;
    double z = zz;
    int k = i;
    while (k <= j)
    {
        zz = zz * q * k / (k - b);
        z = z + zz;
        k = k + 2;
    }
    return (z);
}
//-------------------------------------------------------------------------------------
*/
void __fastcall TEquatParseForm::EquationEditExit(TObject *Sender)
{
	AnalyzedEdit->Text = EquationEdit->Text;
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::ParmBoxClick(TObject *Sender)
{
	int index = ParmBox->ItemIndex;
   EquationEdit->Text = EquationEdit->Text + ParmBox->Items->Strings[index] + " ";
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::VarsBoxClick(TObject *Sender)
{
	int index = VarsBox->ItemIndex;
   EquationEdit->Text = EquationEdit->Text + VarsBox->Items->Strings[index] + " ";
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::Plotit(void)
{
          double **Xpoints, **Ypoints;
          double temp;
          int xcol;

          GetDblMatMem(Xpoints,1,NoCases);
          GetDblMatMem(Ypoints,1,NoCases);

          for (int j = 1; j <= NVars; j++) // do a graph for each x variable
          {
             xcol = xcols[j-1];
             for (int i = 1; i <= NoCases; i++)
          	 {
              	 Xpoints[0][i-1] = StrToFloat(MainForm->Grid->Cells[xcol][i]);
                Ypoints[0][i-1] = StrToFloat(MainForm->Grid->Cells[ycol][i]);
          	 } // next case i
             // sort on x's
             for (int i = 0; i < NoCases-1; i++)
             {
             		for (int k = i+1; k < NoCases; k++)
                  {
                  	if (Xpoints[0][i] > Xpoints[0][k]) // swap
                     {
          					temp = Xpoints[0][i];
                        Xpoints[0][i] = Xpoints[0][k];
                        Xpoints[0][k] = temp;
                        temp = Ypoints[0][i];
                        Ypoints[0][i] = Ypoints[0][k];
                        Ypoints[0][k] = temp;
                     }
                  }
             } // end of sort
          	 GraphForm->Heading = "X VERSUS OBSERVED Y";
          	 GraphForm->nosets = 1;
          	 GraphForm->nbars = NoCases;
          	 GraphForm->XTitle = MainForm->Grid->Cells[xcol][0];
          	 GraphForm->YTitle = MainForm->Grid->Cells[ycol][0];
          	 GraphForm->Ypoints = Ypoints;
          	 GraphForm->Xpoints = Xpoints;
          	 GraphForm->GraphType = 8;  // 2d plot
          	 GraphForm->barwideprop = 1.0;
          	 GraphForm->AutoScale = true;
          	 GraphForm->ShowLeftWall = true;
          	 GraphForm->ShowRightWall = true;
          	 GraphForm->ShowBottomWall = true;
          	 GraphForm->ShowBackWall = true;
          	 GraphForm->BackColor = clWhite;
          	 GraphForm->WallColor = clBlue;
          	 GraphForm->FloorColor = clTeal;
          	 GraphForm->ShowModal();
          } // mext variable j
cleanup:
          ClearDblMatMem(Ypoints,1);
          ClearDblMatMem(Xpoints,1);
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::SavePred(void)
{
	char astr[12];
   int index;
   int col = NoVariables + 1;
	double y;
   char modstring[101];
   char OpsString[101];

     strcpy(OpsString,EquationEdit->Text.c_str());
     strcpy(modstring,OpsString);

     NewVar(col,false);
     MainForm->Grid->Cells[col][0] = "Pred_Y";
     DictionaryForm->DGrid->Cells[1][col] = "Pred_Y";
//     strcpy(vdef[col]->ShortLabel,"Pred_Y");
     ReadParms();
     for (int i = 1; i <= NoCases; i++)
     {
         index = ComboBox1->ItemIndex + 1;
         ReadXs(i-1);
         switch (index) // get y of the chosen function
         {
			case 1: y = a + b * x1; break;
			case 2: y = a * x1; break;
			case 3: y = a  + b * x1 + c * x1 * x1 ; break;
			case 4: y = a + x1* (b + x1 * (c + x1* (d + x1 * (e + x1 * (f + x1 * (g + x1 * h)))))) ;
                 break;
			case 5: y = a + b * x1 + c * x2 + d * x3 + e * x4 + f * x5 + g * x6 + h * x7 ;
         		  break;
			case 6: y = a * exp(-b * x1) ; break;
			case 7: y = (a - c) * exp(-b * x1) + c ; break;
			case 8: y = a * exp(-b * x1) + c * exp(-d * x1) + e * exp(-f * x1) + g * exp(-h * x1) ;
                 break;
			case 9: y = a + b * exp(-c * x1) + d * exp(-e * x1) + f * exp(-g * x1) ;
                 break;
			case 10: y = a / (pow(2,(x1 / b ))) ; break;
			case 11: y = (a - c) / (pow(2,(x1 / b))) + c ; break;
			case 12: y = exp(a - (b / x1)) ; break;
			case 13: y = exp(a - (b / (x1 + c))) ; break;
			case 14: y = a + b * sin(x1) ; break;
			case 15: strcpy(OpsString,modstring); // restore parsestr
                  y = eval(OpsString,NParms,NVars,Par,Xvalues);
                  break;
         }
         sprintf(astr,"%10.6f",y);
         MainForm->Grid->Cells[col][i] = astr;
     } // next i
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::SaveResid(void)
{
     char astr[12];
     char OpsString[101];
     char modstring[101];
     double observedy, resid, y;
     int col = NoVariables + 1;
     int index;

     strcpy(OpsString,EquationEdit->Text.c_str());
     strcpy(modstring,OpsString);
     NewVar(col,false);
     MainForm->Grid->Cells[col][0] = "Residual";
     DictionaryForm->DGrid->Cells[1][col] = "Residual";
//     strcpy(vdef[col]->ShortLabel,"Residual");
     ReadParms();
     for (int i = 1; i <= NoCases; i++)
     {
         index = ComboBox1->ItemIndex + 1;
         ReadXs(i-1);
         switch (index) // get y of the chosen function
         {
			case 1: y = a + b * x1; break;
			case 2: y = a * x1; break;
			case 3: y = a  + b * x1 + c * x1 * x1 ; break;
			case 4: y = a + x1* (b + x1 * (c + x1* (d + x1 * (e + x1 * (f + x1 * (g + x1 * h)))))) ;
                 break;
			case 5: y = a + b * x1 + c * x2 + d * x3 + e * x4 + f * x5 + g * x6 + h * x7 ;
         		  break;
			case 6: y = a * exp(-b * x1) ; break;
			case 7: y = (a - c) * exp(-b * x1) + c ; break;
			case 8: y = a * exp(-b * x1) + c * exp(-d * x1) + e * exp(-f * x1) + g * exp(-h * x1) ;
                 break;
			case 9: y = a + b * exp(-c * x1) + d * exp(-e * x1) + f * exp(-g * x1) ;
                 break;
			case 10: y = a / (pow(2,(x1 / b ))) ; break;
			case 11: y = (a - c) / (pow(2,(x1 / b))) + c ; break;
			case 12: y = exp(a - (b / x1)) ; break;
			case 13: y = exp(a - (b / (x1 + c))) ; break;
			case 14: y = a + b * sin(x1) ; break;
			case 15: strcpy(OpsString,modstring); // restore parsestr
                  y = eval(OpsString,NParms,NVars,Par,Xvalues);
                  break;
         }
         observedy = atof(MainForm->Grid->Cells[ycol][i].c_str());
         resid = y - observedy;
         sprintf(astr,"%10.6f",resid);
         MainForm->Grid->Cells[col][i] = astr;
     } // next i
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::plotxy(TObject *Sender)
{
	double *Xpoints, *Ypoints, *UpConf, *LowConf;
   double ConfBand, Xmean, Ymean, R, Slope, Intercept, Xmax, Xmin;
   double  Xvariance, Yvariance, Xstddev, Ystddev;
   double Ymax, Ymin, X, Y, temp, SSx, SEPred,y ;
   double predicted, sedata;
   double t, DF;
   int i, j,xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
   int vhi, hwide, offset, strhi, imagehi, index;
   double maxval, minval, valincr, Yvalue, Xvalue;
   AnsiString Title;
   char outline[121];
   char OpsString[101];
   char modstring[101];

   strcpy(OpsString,EquationEdit->Text.c_str());
   strcpy(modstring,OpsString);
   GetDblVecMem(Xpoints,NoCases+1); //SetLength(Xpoints,NoCases + 1);
   GetDblVecMem(Ypoints,NoCases+1); //SetLength(Ypoints,NoCases + 1);
   GetDblVecMem(UpConf,NoCases+1);  //SetLength(UpConf,NoCases + 1);
   GetDblVecMem(LowConf,NoCases+1); //SetLength(lowConf,NoCases + 1);
   ReadParms();
   index = ComboBox1->ItemIndex + 1;
   Xmax = -1.0e20;
   Xmin = 1.0e20;
   Ymax = -1.0e20;
   Ymin = 1.0e20;
   Xmean = 0.0;
   Ymean = 0.0;
   Xvariance = 0.0;
   Yvariance = 0.0;
   R = 0.0;

   for (int i = 1; i <= NoCases; i++)
	{
   	ReadXs(i-1);
      switch (index) // get y of the chosen function
      {
			case 1: y = a + b * x1; break;
			case 2: y = a * x1; break;
			case 3: y = a  + b * x1 + c * x1 * x1 ; break;
			case 4: y = a + x1* (b + x1 * (c + x1* (d + x1 * (e + x1 * (f + x1 * (g + x1 * h)))))) ;
                 break;
			case 5: y = a + b * x1 + c * x2 + d * x3 + e * x4 + f * x5 + g * x6 + h * x7 ;
         		  break;
			case 6: y = a * exp(-b * x1) ; break;
			case 7: y = (a - c) * exp(-b * x1) + c ; break;
			case 8: y = a * exp(-b * x1) + c * exp(-d * x1) + e * exp(-f * x1) + g * exp(-h * x1) ;
                 break;
			case 9: y = a + b * exp(-c * x1) + d * exp(-e * x1) + f * exp(-g * x1) ;
                 break;
			case 10: y = a / (pow(2,(x1 / b ))) ; break;
			case 11: y = (a - c) / (pow(2,(x1 / b))) + c ; break;
			case 12: y = exp(a - (b / x1)) ; break;
			case 13: y = exp(a - (b / (x1 + c))) ; break;
			case 14: y = a + b * sin(x1) ; break;
			case 15: strcpy(OpsString,modstring); // restore parsestr
                  y = eval(OpsString,NParms,NVars,Par,Xvalues);
                  break;
      }
      Xpoints[i] = StrToFloat(MainForm->Grid->Cells[ycol][i]);
      X = Xpoints[i];
      Ypoints[i] = y;
      Y = Ypoints[i];
      if (X > Xmax) Xmax = X;
      if (X < Xmin) Xmin = X;
      if (Y > Ymax) Ymax = Y;
      if (Y < Ymin) Ymin = Y;
      Xmean = Xmean + X;
      Ymean = Ymean + Y;
      Xvariance = Xvariance + (X * X);
      Yvariance = Yvariance + (Y * Y);
      R = R + (X * Y);
   } // next case i

   // sort on X
   for (i = 1; i <= NoCases - 1; i++)
   {
          for (j = i + 1; j <= NoCases; j++)
          {
               if (Xpoints[i] > Xpoints[j]) //swap
               {
                    temp = Xpoints[i];
                    Xpoints[i] = Xpoints[j];
                    Xpoints[j] = temp;
                    temp = Ypoints[i];
                    Ypoints[i] = Ypoints[j];
                    Ypoints[j] = temp;
               }
          }
   }

   // calculate statistics
   Xvariance = Xvariance - (Xmean * Xmean / NoCases);
   SSx = Xvariance;
   Xvariance = Xvariance / (NoCases - 1);
   Xstddev = sqrt(Xvariance);

   Yvariance = Yvariance - (Ymean * Ymean / NoCases);
   Yvariance = Yvariance / (NoCases - 1);
   Ystddev = sqrt(Yvariance);

   R = R - (Xmean * Ymean / NoCases);
   R = R / (NoCases - 1);
   if ((Xstddev > 0.0) && (Ystddev > 0.0)) R = R / (Xstddev * Ystddev);
   else R = 0.0;
   SEPred = sqrt(1.0 - (R * R)) * Ystddev;
   SEPred = SEPred * sqrt((NoCases - 1) / (NoCases - 2));
   Xmean = Xmean / NoCases;
   Ymean = Ymean / NoCases;
   Slope = R * Ystddev / Xstddev;
   Intercept = Ymean - Slope * Xmean;

   FrmOutPut->RichOutPut->Lines->Add("X versus Y Plot");
   FrmOutPut->RichOutPut->Lines->Add("");
   sprintf(outline,"X = %s, Y = %s from file: %s","Y",
      "Y'",MainForm->FileNameEdit->Text.c_str());
   FrmOutPut->RichOutPut->Lines->Add(outline);
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("Variable     Mean   Variance  Std.Dev.");
   sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f","Y",Xmean,Xvariance,Xstddev);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f","Y'",Ymean,Yvariance,Ystddev);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   sprintf(outline,"Correlation = %6.4f, Slope = %8.2f, Intercept = %8.2f",
              R, Slope, Intercept);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   sprintf(outline,"Standard Error of Estimate = %8.2f",SEPred);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   sprintf(outline,"Number of good cases = %d",NoCases);
   FrmOutPut->RichOutPut->Lines->Add(outline);

   // get confidence band
//   ConfBand = 95.0 / 100.0;
   DF = NoCases - 2;
//   t = AStudT(ConfBand,DF);
   double Pctile = StrToFloat(ConfIntEdit->Text) /100.0;
   t = inverset(Pctile,DF);
   for (i = 1; i <= NoCases; i++)
   {
       X = Xpoints[i];
       predicted = Slope * X + Intercept;
       sedata = SEPred * sqrt(1.0 + (1.0 / NoCases) + ((X - Xmean) * (X - Xmean) / SSx));
       UpConf[i] = predicted + (t * sedata);
       LowConf[i] = predicted - (t * sedata);
       if (UpConf[i] > Ymax) Ymax = UpConf[i];
       if (LowConf[i] < Ymin)Ymin = LowConf[i];
   }

   Title = "Y versus Predicted Y PLOT Using File: " + MainForm->FileNameEdit->Text;
   PlotForm->Caption = Title;
   imagewide = PlotForm->Image1->Width;
   imagehi = PlotForm->Image1->Height;
   PlotForm->Image1->Canvas->Pen->Color = clBlack;
   PlotForm->Image1->Canvas->Brush->Color = clWhite;
   PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
   PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
   vtop = 20;
   vbottom = ceil(imagehi) - 80;
   vhi = vbottom - vtop;
   hleft = 100;
   hright = imagewide - 80;
   hwide = hright - hleft;
   PlotForm->Image1->Canvas->Pen->Color = clBlack;
   PlotForm->Image1->Canvas->Brush->Color = clWhite;

   // Draw chart border
   PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

   // draw Means
   ypos = ceil(vhi * ( (Ymax - Ymean) / (Ymax - Ymin)));
   ypos = ypos + vtop;
   xpos = hleft;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   xpos = hright;
   PlotForm->Image1->Canvas->Pen->Color = clGreen;
   PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   Title = "MEAN Y'";
   strhi = PlotForm->Image1->Canvas->TextHeight(Title);
   ypos = ypos - strhi / 2;
   PlotForm->Image1->Canvas->Brush->Color = clWhite;
   PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

   xpos = ceil(hwide * ( (Xmean - Xmin) / (Xmax - Xmin)));
   xpos = xpos + hleft;
   ypos = vtop;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   ypos = vbottom;
   PlotForm->Image1->Canvas->Pen->Color = clGreen;
   PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   Title = "MEAN Y";
   strhi = PlotForm->Image1->Canvas->TextWidth(Title);
   xpos = xpos - strhi / 2;
   ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
   PlotForm->Image1->Canvas->Brush->Color = clWhite;
   PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

   // draw slope line
   PlotForm->Image1->Canvas->Pen->Color = clBlack;
   Yvalue = (Xpoints[1] * Slope) + Intercept; // predicted score
   ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
   ypos = ypos + vtop;
   xpos = ceil(hwide * ( (Xpoints[1]- Xmin) / (Xmax - Xmin)));
   xpos = xpos + hleft;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   Yvalue = (Xpoints[NoCases] * Slope) + Intercept; // predicted score
   ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
   ypos = ypos + vtop;
   xpos = ceil(hwide * ( (Xpoints[NoCases] - Xmin) / (Xmax - Xmin)));
   xpos = xpos + hleft;
   PlotForm->Image1->Canvas->LineTo(xpos,ypos);

   // draw horizontal axis
   PlotForm->Image1->Canvas->Pen->Color = clBlack;
   PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
   PlotForm->Image1->Canvas->LineTo(hright,vbottom);
   valincr = (Xmax - Xmin) / 10.0;
   for (i = 1; i <= 11; i++)
   {
      ypos = vbottom;
      Xvalue = Xmin + valincr * (i - 1);
      xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
      xpos = xpos + hleft;
      PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
      ypos = ypos + 10;
      PlotForm->Image1->Canvas->LineTo(xpos,ypos);
      sprintf(outline,"%6.2f",Xvalue);
      Title = outline;
      offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
      xpos = xpos - offset;
      PlotForm->Image1->Canvas->Pen->Color = clBlack;
      PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
   }
   xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth("Y'") / 2);
   ypos = vbottom + 20;
   PlotForm->Image1->Canvas->TextOut(xpos,ypos,"Y");
   sprintf(outline,"R(Y,Y') = %5.3f, Slope = %6.2f, Intercept = %6.2f",
           R,Slope,Intercept);
   Title = outline;
   xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
   ypos = ypos + 15;
   PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

   // Draw vertical axis
   Title = "Pred. Y"; //YEdit->Text;
   xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
   ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
   PlotForm->Image1->Canvas->TextOut(xpos,ypos,"Y'");
   xpos = hleft;
   ypos = vtop;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   ypos = vbottom;
   PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   valincr = (Ymax - Ymin) / 10.0;
   for (i = 1; i <= 11; i++)
   {
      double value = Ymax - ((i-1) * valincr);
      sprintf(outline,"%8.2f",value);
      Title = outline;
      strhi = PlotForm->Image1->Canvas->TextHeight(Title);
      xpos = 10;
      Yvalue = Ymax - (valincr * (i-1));
      ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
      ypos = ypos + vtop - strhi / 2;
      PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
      xpos = hleft;
      ypos = ypos + strhi / 2;
      PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
      xpos = hleft - 10;
      PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   }

   // draw points for x and y pairs
   for (i = 1; i <= NoCases; i++)
   {
      ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
      ypos = ypos + vtop;
      xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
      xpos = xpos + hleft;
      PlotForm->Image1->Canvas->Brush->Color = clNavy;
      PlotForm->Image1->Canvas->Brush->Style = bsSolid;
      PlotForm->Image1->Canvas->Pen->Color = clNavy;
      PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
   }

   // plot confidence limits
   PlotForm->Image1->Canvas->Pen->Color = clRed;
   ypos = ceil(vhi * ((Ymax - UpConf[1]) / (Ymax - Ymin)));
   ypos = ypos + vtop;
   xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
   xpos = xpos + hleft;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   for (i = 2; i <= NoCases; i++)
   {
      ypos = ceil(vhi * ((Ymax - UpConf[i]) / (Ymax - Ymin)));
      ypos = ypos + vtop;
      xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
      xpos = xpos + hleft;
      PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   }
   ypos = ceil(vhi * ((Ymax - LowConf[1]) / (Ymax - Ymin)));
   ypos = ypos + vtop;
   xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
   xpos = xpos + hleft;
   PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
   for (i = 2; i <= NoCases; i++)
   {
      ypos = ceil(vhi * ((Ymax - LowConf[i]) / (Ymax - Ymin)));
      ypos = ypos + vtop;
      xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
      xpos = xpos + hleft;
      PlotForm->Image1->Canvas->LineTo(xpos,ypos);
   }
   PlotForm->ShowModal();

   delete[] LowConf;
   delete[] UpConf;
   delete[] Ypoints;
   delete[] Xpoints;
}
//-------------------------------------------------------------------

void __fastcall TEquatParseForm::ReadParms(void)
{
//     for (int i = 1; i <= NParms; i++)
//         Par[i-1] = StrToFloat(Grid->Cells[3][i]);
     switch (NParms)
     {
         case 1 : a = Par[0]; break;
         case 2 : a = Par[0];
                  b = Par[1]; break;
         case 3 : a = Par[0];
                  b = Par[1];
                  c = Par[2]; break;
         case 4 : a = Par[0];
                  b = Par[1];
                  c = Par[2];
                  d = Par[3]; break;
         case 5 : a = Par[0];
                  b = Par[1];
                  c = Par[2];
                  d = Par[3];
                  e = Par[4]; break;
         case 6 : a = Par[0];
                  b = Par[1];
                  c = Par[2];
                  d = Par[3];
                  e = Par[4];
                  f = Par[5]; break;
         case 7 : a = Par[0];
                  b = Par[1];
                  c = Par[2];
                  d = Par[3];
                  e = Par[4];
                  f = Par[5];
                  g = Par[6]; break;
         case 8 : a = Par[0];
                  b = Par[1];
                  c = Par[2];
                  d = Par[3];
                  e = Par[4];
                  f = Par[5];
                  g = Par[6];
                  h = Par[7]; break;
     }
}
//---------------------------------------------------------------------------

void __fastcall TEquatParseForm::ReadXs(int i)
{
	char outline[101];
    char valstr[21];
     strcpy(outline,"x: ");
     for (int j = 0; j < NVars; j++)
     {
//         int col = xcols[j];
         Xvalues[j] = Data[i][j];
//         sprintf(valstr,"x%d=%6.3f ",j,xArr[j]);
//         strcat(outline,valstr);
     }
//     FrmOutPut->RichOutPut->Lines->Add(outline);
     x1 = Xvalues[0];
     x2 = Xvalues[1];
     x3 = Xvalues[2];
     x4 = Xvalues[3];
     x5 = Xvalues[4];
     x6 = Xvalues[5];
     x7 = Xvalues[6];
     x8 = Xvalues[7];
}
//---------------------------------------------------------------------------


