//---------------------------------------------------------------------------

#ifndef PlotXYUnitH
#define PlotXYUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TXvsYPlotForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TListBox *Varlist;
   TBitBtn *XInBtn;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *OKBtn;
   TGroupBox *GroupBox1;
   TCheckBox *RegLineChk;
   TCheckBox *ConfBandChk;
   TEdit *ConfIntvlEdit;
   TLabel *Label3;
   TCheckBox *DescChk;
   TEdit *XEdit;
   TLabel *Label2;
   TBitBtn *YInBtn;
   TLabel *Label4;
   TEdit *YEdit;
   TCheckBox *MeansChk;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall YInBtnClick(TObject *Sender);
   void __fastcall XInBtnClick(TObject *Sender);
   void __fastcall OKBtnClick(TObject *Sender);

private:	// User declarations
   void __fastcall plotxy(double *Xpoints,
                          double *Ypoints,
                          double *UpConf,
                          double *LowConf,
                          double ConfBand,
                          double Xmean,
                          double Ymean,
                          double R,
                          double Slope,
                          double Intercept,
                          double Xmax,
                          double Xmin,
                          double Ymax,
                          double Ymin,
                          int N);

public:		// User declarations

   __fastcall TXvsYPlotForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TXvsYPlotForm *XvsYPlotForm;
//---------------------------------------------------------------------------
#endif
