//---------------------------------------------------------------------------

#ifndef CATROCH
#define CATROCH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TCatROCFrm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *ScaleInBtn;
        TBitBtn *ScaleOutBtn;
        TLabel *Label2;
        TEdit *CatVarEdit;
        TBitBtn *NormInBtn;
        TBitBtn *NormOutBtn;
        TBitBtn *PosInBtn;
        TBitBtn *PosOutBtn;
        TLabel *NormLabel;
        TLabel *Label3;
        TEdit *NormVarEdit;
        TEdit *PosVarEdit;
        TMemo *Memo1;
        TButton *CancelBtn;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall ScaleInBtnClick(TObject *Sender);
        void __fastcall NormInBtnClick(TObject *Sender);
        void __fastcall PosInBtnClick(TObject *Sender);

private:	// User declarations
        void check(int &iclass, int ncats, double *fpf, double *tpf,
                              int icon, int *iary);
        void degen(int &iclass, int *iary, double *fpf, double *tpf);
        void inifit(int ncats, int negcount, int poscount,
                      double *fpf, double *tpf);
        void MOSLOP(int &LL, double **XP);
        void OUTRSL(int &LL, double **XP);
        void CHISQR(void);
        void PDEV(void);
        void TERMS(void);
        void PlotPts(double *Xpoints,double *Ypoints, double *Ylow, double *Yup);

        double *PXBA;
        double *DXBA;
        double *DIFFN;
        double *DIFFSN;
        double **XX;
        double *fpf;
        double *tpf;
        double **XP;
        double *PARX;
        double *X;
        double *XS;
        double *PX;
        double *DX;
        double **XXDUM;
        double *ADJX;
        double AAA;
        double BBB;
        double A;
        double B;
        double FUNLIK;
        int KSN;
        int EMN;
        int EMS;
        int *cat;
        int *CATN;
        int *CATS;
        int *catcount;
        int KAT;
        int *iary;

public:		// User declarations
        __fastcall TCatROCFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCatROCFrm *CatROCFrm;
//---------------------------------------------------------------------------
#endif
