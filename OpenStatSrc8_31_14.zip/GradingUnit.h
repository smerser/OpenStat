//---------------------------------------------------------------------------
#ifndef GradingUnitH
#define GradingUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TGradingFrm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *RadioGroup1;
    TRadioGroup *RadioGroup2;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TLabel *Label11;
    TLabel *Label12;
    TLabel *Label13;
    TLabel *Label14;
    TEdit *Edit1;
    TEdit *Edit2;
    TEdit *Edit3;
    TEdit *Edit4;
    TEdit *Edit5;
    TEdit *Edit6;
    TEdit *Edit7;
    TEdit *Edit8;
    TEdit *Edit9;
    TEdit *Edit10;
    TEdit *Edit11;
    TEdit *Edit12;
    TEdit *Edit13;
    TEdit *Edit14;
    TEdit *Edit15;
    TEdit *Edit16;
    TEdit *Edit17;
    TEdit *Edit18;
    TEdit *Edit20;
    TEdit *Edit21;
    TEdit *Edit22;
    TEdit *Edit23;
    TEdit *Edit24;
    TButton *CancelBtn;
    TButton *OKBtn;
    TEdit *Edit19;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TGradingFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGradingFrm *GradingFrm;
//---------------------------------------------------------------------------
#endif
