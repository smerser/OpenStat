//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SuccIntvl.h"
#include "VarSelect.h"
#include "MainUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
extern long int NoVariables;
extern long int NoCases;
extern bool FilterOn;
extern long int FilterCol;

void SuccInt(void)
{
    int NoSelected = 0;
    int MaxCat = 0;
    int *ColNoSelected;
    int *RowTots;
    int *CatCount;
    int **FreqMat;
    double **PropMat;
    double **Zmatrix;
    double **CumMat;
    double **WidthMat;
    double **TheorZMat;
    double **ThCumPMat;
    double *DiscDisp;
    double *Mean;
    double *StdDev;
    double *CumWidth;
    double *ScaleValue;
    double L1 = 0.01;
    double L2 = 0.99;
    AnsiString *RowLabels;
    AnsiString *ColLabels;
    char outline[72];
    char astring[21];
    int result;

    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    FrmVarSel->ChkBox->Visible = false;
    for (int i = 0; i < NoVariables; i++)
        FrmVarSel->LstBoxVars->Items->Add(MainForm->Grid->Cells[i+1][0]);
    FrmVarSel->Caption = "Successive Interval Scaling";
    if(FrmVarSel->ShowModal() == mrCancel) return;
    NoSelected = FrmVarSel->LstBoxSelected->Items->Count;
    if (NoSelected == 0)
    {
        ShowMessage("ERROR!  No items were selected.");
        return;
    }
    //Allocate heap storage for a vector of items selected
    try  {
        ColNoSelected = new int[NoSelected];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Get items selected
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            if (FrmVarSel->LstBoxSelected->Items->Strings[i] ==
                MainForm->Grid->Cells[j+1][0])
            {
                ColNoSelected[i] = j+1;
                //result = VarTypeChk(j+1,1);
                //if (result == 1)
                //{
                //        delete[] ColNoSelected;
                //        return;
                //}
            }
        }
    }

    //Find largest category value in data
    for (int i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (int j = 0; j < NoSelected; j++)
        {
            int col = ColNoSelected[j];
            int X = floor(StrToFloat(MainForm->Grid->Cells[col][i+1]));
            if (X > MaxCat) MaxCat = X;
        }
    }

    //Allocate space for frequency, proportion, z, reproduced matrixes, etc.
    try  {
        FreqMat = new int*[NoSelected];
        for (int i = 0; i < NoSelected; i++) FreqMat[i] = new int[MaxCat];
        PropMat = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) PropMat[i] = new double[MaxCat];
        Zmatrix = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) Zmatrix[i] = new double[MaxCat];
        CumMat = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) CumMat[i] = new double[MaxCat];
        WidthMat = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) WidthMat[i] = new double[MaxCat];
        TheorZMat = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) TheorZMat[i] = new double[MaxCat];
        ThCumPMat = new double*[NoSelected];
        for (int i = 0; i < NoSelected; i++) ThCumPMat[i] = new double[MaxCat];
        RowTots = new int[NoSelected];
        DiscDisp = new double[NoSelected];
        CatCount = new int[MaxCat];
        Mean = new double[MaxCat];
        StdDev = new double[MaxCat];
        CumWidth = new double[MaxCat];
        ScaleValue = new double[NoSelected];
        RowLabels = new AnsiString[NoSelected];
        ColLabels = new AnsiString[MaxCat];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Initialize arrays
    for (int i = 0; i < NoSelected; i++)
    {
        RowTots[i] = 0;
        DiscDisp[i] = 0.0;
        ScaleValue[i] = 0.0;
        for (int j = 0; j < MaxCat; j++)
        {
            FreqMat[i][j] = 0;
            PropMat[i][j] = 0.0;
            CumMat[i][j] = 0.0;
            Zmatrix[i][j] = 0.0;
            WidthMat[i][j] = 0.0;
            TheorZMat[i][j] = 0.0;
            ThCumPMat[i][j] = 0.0;
        }
    }
    for (int j = 0; j < MaxCat; j++)
    {
        CumWidth[j] = 0.0;
        StdDev[j] = 0.0;
        Mean[j] = 0.0;
        CatCount[j] = 0;
    }

    TCursor Save_Cursor = Screen->Cursor; // save current cursor
    Screen->Cursor = crHourGlass;    // Show hourglass cursor

    //Build frequency matrix
    for (int i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (int j = 0; j < NoSelected; j++)
        {
            int col = ColNoSelected[j];
            int X = floor(StrToFloat(MainForm->Grid->Cells[col][i+1]));
            if ((X > 0) && (X <= MaxCat)) FreqMat[j][X-1]++;
        }
    }

    // Get row totals of the frequency matrix
    for (int i = 0; i < NoSelected; i++)
    {
        RowTots[i] = 0;
        for (int j = 0; j < MaxCat; j++)
        {
            RowTots[i]+= FreqMat[i][j];
        }
    }

    // Convert frequencies to proportions of the row totals
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < MaxCat; j++)
            PropMat[i][j] = double(FreqMat[i][j]) / double(RowTots[i]);

    // Accumulate the proportions accross the categories
    for (int i = 0; i < NoSelected; i++)
    {
        CumMat[i][0] = PropMat[i][0];
        for (int j = 1; j < MaxCat; j++)
        {
            CumMat[i][j] = CumMat[i][j-1] + PropMat[i][j];
            if (j == MaxCat-1) CumMat[i][j] = 1.0;
        }
    }

    // Convert cumulative proportions to z scores
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < MaxCat; j++)
        {
            if (CumMat[i][j] < L1) Zmatrix[i][j] = 99.0; //flag  -infinity
            if (CumMat[i][j] > L2) Zmatrix[i][j] = 99.0; //flag +infinity
            if ((CumMat[i][j] >= L1) && (CumMat[i][j] <= L2))
                 Zmatrix[i][j] = inversez(CumMat[i][j]);
        }
    }

    // Obtain discriminal dispersions of the items
    double t3 = 0.0;
    for (int i = 0; i < NoSelected; i++)
    {
        double d1 = 0.0;
        double d2 = 0.0;
        double C1 = 0.0;
        for (int j = 0; j < MaxCat-1; j++)
        {
            if (Zmatrix[i][j] != 99.0)
            {
                d1 += Zmatrix[i][j];
                d2 += (Zmatrix[i][j] * Zmatrix[i][j]);
                C1 += 1.0;
            }
        }
        if (C1 > 1)
        {
            DiscDisp[i] = d2 - ((d1 * d1) / C1);
            DiscDisp[i] /= (C1-1.0);
            DiscDisp[i] = sqrt(DiscDisp[i]);
        }
        else DiscDisp[i] = 99.0;
        if ((DiscDisp[i] > 0) && (DiscDisp[i] != 99.0)) t3 += (1.0 / DiscDisp[i]);
    }
    //Constant t3 =No. items / recipricols of std.dev.s of item z scores
    t3 = double(NoSelected) / t3;
    for (int i = 0; i < NoSelected; i++)
    {
        if ((DiscDisp[i] > 0.0) && (t3 > 0))
             DiscDisp[i] = (1.0 / DiscDisp[i]) * t3;
        else DiscDisp[i] = 99.0;
    }

    // Now, calculate interval widths
    for (int j = 1; j < MaxCat-1; j++)
    {
        for (int i = 0; i < NoSelected; i++)
        {
            if ((Zmatrix[i][j] != 99.0) && (Zmatrix[i][j-1] != 99.0))
               WidthMat[i][j-1] = Zmatrix[i][j] - Zmatrix[i][j-1];
            else WidthMat[i][j-1] = 99.0;
        }
    }

    //Calculate Means and Standard Deviations of category Widths
    for (int j = 0; j < MaxCat-2; j++)
    {
        for (int i = 0; i < NoSelected; i++)
        {
            if (WidthMat[i][j] != 99.0)
            {
                CatCount[j]++;
                Mean[j] += WidthMat[i][j];
                StdDev[j] += (WidthMat[i][j] * WidthMat[i][j]);
            }
        }
        if (CatCount[j] > 1)
        {
            Mean[j] /= double(CatCount[j]);
            StdDev[j] = (StdDev[j] / CatCount[j]) - (Mean[j] * Mean[j]);
            StdDev[j] *= (double(CatCount[j]) / double(CatCount[j] - 1));
        }
    }

    // Calculate cumulative widths
    CumWidth[0] = Mean[0];
    for (int j = 1; j < MaxCat-2; j++)
        CumWidth[j] = CumWidth[j-1] + Mean[j];

    // Calculate scale item scale values
    for (int i = 0; i < NoSelected; i++)
    {
        bool found = false;
        int count = 0;
        int subscript;
        do
        {
            if (CumMat[i][count] >= 0.5)
            {
                found = true;
                subscript = count;
            }
            if (count == (MaxCat-1))
            {
                found = true;
                subscript = count;
            }
            count++;
        } while (!found);
        if (subscript > 0)
        {
            ScaleValue[i] = Mean[subscript-1] * ((0.5 - CumMat[i][subscript-1]) /
                PropMat[i][subscript]);
            if (subscript > 1) ScaleValue[i] += CumWidth[subscript-2];
        }
        else
        {  //extreme value - get average of z scores in first cat. and / 2
            double sum=0.0;
            for (int k = 0; k < NoSelected; k++) sum += Zmatrix[i][0];
            sum /= fabs((double(NoSelected * 2)));
            ScaleValue[i] = sum * ((0.5 - (CumMat[i][0]/2.0)) / (CumMat[i][0]/2.0));
        }
    }

    //Calculate Theoretical z scores from the scale values
    double discrep = 0.0;
    int count = 0;
    double z;
    double prop;
    for (int i = 0; i < NoSelected; i++)
    {
        z = -ScaleValue[i];
        TheorZMat[i][0] = z;
        prop = normalprob(z);
        ThCumPMat[i][0] = prop;
        for (int j = 1; j < MaxCat-1; j++)
        {
            z = CumWidth[j-1] - ScaleValue[i];
            if (z < -3) z = -3.0;
            if (z > 3) z = 3.0;
            prop = normalprob(z);
            TheorZMat[i][j] = z;
            ThCumPMat[i][j] = prop;
            discrep += fabs(CumMat[i][j] - prop);
            count++;
        }
        ThCumPMat[i][MaxCat-1] = 1.0;
    }
    discrep /= double(count); // average discrepency between theoretical and observed

    // Report results
    for (int i = 0; i < NoSelected; i++)
        RowLabels[i] = MainForm->Grid->Cells[ColNoSelected[i]][0];
    for (int i = 0; i < MaxCat; i++)
    {
        sprintf(outline," %2d-%2d ",i,i+1);
        ColLabels[i] = outline;
    }
    FrmOutPut->RichOutPut->Lines->Add("          SUCCESSIVE INTERVAL SCALING RESULTS");
    FrmOutPut->RichOutPut->Lines->Add("");
    strcpy(outline,"            ");
    for (int i = 0; i < MaxCat; i++) strcat(outline,ColLabels[i].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(outline,"%10s",RowLabels[i].c_str());
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"Frequency  ");
        for (int j = 0; j < MaxCat; j++)
        {
            sprintf(astring,"%7d",FreqMat[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"Proportion ");
        for (int j = 0; j < MaxCat; j++)
        {
            sprintf(astring,"%7.3f",PropMat[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"Cum. Prop. ");
        for (int j = 0; j < MaxCat; j++)
        {
            sprintf(astring,"%7.3f",CumMat[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"Normal z   ");
        for (int j = 0; j < MaxCat; j++)
        {
            if (Zmatrix[i][j] != 99.0)
            {
                sprintf(astring,"%7.3f",Zmatrix[i][j]);
                strcat(outline,astring);
            }
            else strcat(outline,"   -   ");
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("                  INTERVAL WIDTHS");
    strcpy(outline,"          ");
    for (int i = 0; i < MaxCat-2; i++)
    {
        sprintf(astring," %2d-%2d ",i+2,i+1);
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    strcpy(outline,"");
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(astring,"%10s",RowLabels[i].c_str());
        strcat(outline,astring);
        for (int j = 0; j < MaxCat-2; j++)
        {
            if (WidthMat[i][j] != 99.0)
            {
                sprintf(astring,"%7.3f",WidthMat[i][j]);
                strcat(outline,astring);
            }
            else strcat(outline,"   -   ");
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"");
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    strcpy(outline,"Mean Width");
    for (int i = 0; i < MaxCat-2; i++)
    {
        sprintf(astring,"%7.2f",Mean[i]);
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    strcpy(outline,"No. Items ");
    for (int i = 0; i < MaxCat-2; i++)
    {
        sprintf(astring,"%7d",CatCount[i]);
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    strcpy(outline,"Std. Dev.s");
    for (int i = 0; i < MaxCat-2; i++)
    {
        sprintf(astring,"%7.2f",StdDev[i]);
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    strcpy(outline,"Cum. Means");
    for (int i = 0; i < MaxCat-2; i++)
    {
        sprintf(astring,"%7.2f",CumWidth[i]);
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("ESTIMATES OF SCALE VALUES AND THEIR DISPERSIONS");
    FrmOutPut->RichOutPut->Lines->Add("Item       No. Ratings Scale Value  Discriminal Dispersion");
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(outline,"%10s     %3d        %6.3f      %6.3f",
           RowLabels[i].c_str(),RowTots[i],ScaleValue[i],DiscDisp[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");

    FrmOutPut->RichOutPut->Lines->Add("Z scores Estimated from Scale values");
    strcpy(outline,"           ");
    for (int i = 0; i < MaxCat; i++) strcat(outline,ColLabels[i].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(outline,"%10s",RowLabels[i].c_str());
        for (int j = 0; j < MaxCat-1; j++)
        {
            sprintf(astring,"%7.3f",TheorZMat[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");

    FrmOutPut->RichOutPut->Lines->Add("Cumulative Theoretical Proportions");
    strcpy(outline,"           ");
    for (int i = 0; i < MaxCat; i++) strcat(outline,ColLabels[i].c_str());
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(outline,"%10s",RowLabels[i].c_str());
        for (int j = 0; j < MaxCat; j++)
        {
            sprintf(astring,"%7.3f",ThCumPMat[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");

    strcpy(outline,"Average Discrepency Between Theoretical and Observed Frequencies");
    sprintf(astring,"%6.3f",discrep);
    strcat(outline,astring);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    Screen->Cursor = Save_Cursor;
    FrmOutPut->ShowModal();

    // Clean up the heap
    delete[] ColLabels;
    delete[] RowLabels;
    delete[] ScaleValue;
    delete[] CumWidth;
    delete[] CatCount;
    delete[] Mean;
    delete[] StdDev;
    delete[] DiscDisp;
    delete[] RowTots;
    for (int i = 0; i < NoSelected; i++) delete[] ThCumPMat[i];
    delete[] ThCumPMat;
    for (int i = 0; i < NoSelected; i++) delete[] TheorZMat[i];
    delete[] TheorZMat;
    for (int i = 0; i < NoSelected; i++) delete[] WidthMat[i];
    delete[] WidthMat;
    for (int i = 0; i < NoSelected; i++) delete[] CumMat[i];
    delete[] CumMat;
    for (int i = 0; i < NoSelected; i++) delete[] Zmatrix[i];
    delete[] Zmatrix;
    for (int i = 0; i < NoSelected; i++) delete[] PropMat[i];
    delete[] PropMat;
    for (int i = 0; i < NoSelected; i++) delete[] FreqMat[i];
    delete[] FreqMat;
    delete[] ColNoSelected;
    FrmVarSel->ChkBox->Visible = true;
}
