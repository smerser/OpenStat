//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "TypeI.h"
#include "OutPut.h"
#include "GraphUnit.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "DictionaryUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "AnovaTestsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTypeIFrm *TypeIFrm;
extern bool FilterOn;
extern int FilterCol;
extern int NoVariables;
extern int NoCases;
//---------------------------------------------------------------------------
__fastcall TTypeIFrm::TTypeIFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTypeIFrm::FormShow(TObject *Sender)
{
    GroupVar->Text = "";
    ListBox1->Clear();
    ListBox2->Clear();
    for (int i = 0; i < NoVariables; i++)
        ListBox1->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::InBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::OutBtnClick(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    index = ListBox2->ItemIndex;
    cellstring = ListBox2->Items->Strings[index];
    ListBox1->Items->Add(cellstring);
    ListBox2->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::ListBox2Click(TObject *Sender)
{
	int index;
    AnsiString cellstring;

    if (GroupVar->Text != "") return;
    index = ListBox2->ItemIndex;
    cellstring = ListBox2->Items->Strings[index];
    GroupVar->Text = cellstring;
    ListBox2->Items->Delete(index);
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::SelectBtnClick(TObject *Sender)
{
    AnsiString cellstring;

    while (ListBox1->Items->Count > 0)
    {
        cellstring = ListBox1->Items->Strings[0];
        ListBox2->Items->Add(cellstring);
        ListBox1->Items->Delete(0);
    }
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::ResetBtnClick(TObject *Sender)
{
    FormShow(this);
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::CancelBtnClick(TObject *Sender)
{
    TypeIFrm->Hide();
    return;
}
//---------------------------------------------------------------------------


void __fastcall TTypeIFrm::OKBtnClick(TObject *Sender)
{
    int a1, a2, agrp, i, j, k, v1, totaln = 0, NoSelected, range, group;
    double p, X, f1, f2, f3, probf1, probf2, probf3, fd1, fd2, TotMean = 0.0,
           TotStdDev = 0.0;
    double **C, *squaredsumx, *sumxsquared, *coltot, *sumsum, **StdDev;
    int degfree[8];
    int *ColNoSelected;
    double ss[8];
    double ms[8];
    double coeff[6];
    int *N;
    char value[11];
    char outline[81];
    AnsiString cellstring;
    int tempcol;
    bool results;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;
    double alpha;

    if (GroupVar->Text == "")
    {
        Application->MessageBox("Select a variable for between groups treatment groups",
                                "ERROR!",MB_OK);
        return;
    }
    alpha = StrToFloat(AlphaEdit->Text);
     NoSelected = ListBox2->Items->Count + 1;
     if (NoSelected < 2)
     {
        ShowMessage("ERROR!  Select 2 or more variables from those available.");
        return;
     }
     try  {
        ColNoSelected = new int[NoSelected];
     }
     catch (...)
     {
        Application->MessageBox("Out of memory in axs anova.","MEMORY ERROR",MB_OK);
     }

    // Get between subjects group variable
    for (int j = 0; j < NoVariables; j++)
        if (GroupVar->Text == MainForm->Grid->Cells[j+1][0])
                ColNoSelected[0] = j+1;
     v1 = ColNoSelected[0]; //A treatment (group) variable
     // check to see if strcol is a string variable
     cellstring = DictionaryForm->DGrid->Cells[3][v1];
     if (cellstring == "2") // recode into an integer code
     {
        results = StringsToInt(v1, tempcol, true);
        if (results == false) DeleteaCol(v1);
        v1 = NoVariables;
        ColNoSelected[0] = v1;
     }
     //result = VarTypeChk(v1,1);
     //if (result == 1)
     //{
     //   delete[] ColNoSelected;
     //   return;
     //}

     //get minimum and maximum group codes for Treatment A
     a1 = 1000; //atoi(MainForm->Grid->Cells[v1][1].c_str());
     a2 = 0; //a1;
     for (i = 1; i < NoCases; i++)
     {
        if (!ValidRecord(i,ColNoSelected,1)) continue;
        group = floor(StrToFloat(MainForm->Grid->Cells[v1][i]));
        result = GetValue(i,v1,intvalue,dblvalue,strvalue);
        //if (result == 1) group = 0;
        //else group = intvalue;
        if (group < a1) a1 = group;
        if (group > a2) a2 = group;
     }
    range = a2 - a1 + 1;
    k = NoSelected - 1; //Number of B (within subject) treatment levels

    try  {
        C = new double *[range];
        for (i = 0; i < range; i++) C[i] = new double [k];
        N = new int[range];
        squaredsumx = new double[range];
        coltot = new double [k];
        sumxsquared = new double[range];
        sumsum = new double[range];
        StdDev = new double *[range+1];
        for (i = 0; i < range+1; i++) StdDev[i] = new double [k+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of memory in axs anova.","MEMORY ERROR",MB_OK);
    }

    // initialize arrays
    for (i = 0; i < range; i++)
    {
        N[i] = 0.0;
        squaredsumx[i] = 0.0;
        sumxsquared[i] = 0.0;
        sumsum[i] = 0.0;
        for (j = 0; j < k; j++) C[i][j] = 0.0;
    }
    for (j = 0; j < k; j++) coltot[j] = 0.0;
    for (i = 0; i < range+1; i++)
        for (j = 0; j < k+1; j++)
            StdDev[i][j] = 0.0;
    for (i = 0; i < 6; i++) coeff[i] = 0.0;
    for (i = 0; i < 8; i++) degfree[i] = 0.0;

    // Get items selected for repeated measures (B treatments)
    for (int i = 0; i < ListBox2->Items->Count; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            if (ListBox2->Items->Strings[i] == MainForm->Grid->Cells[j+1][0])
            {
                ColNoSelected[i+1] = j+1;
                //result = VarTypeChk(j+1,0);
                //if (result == 1) goto cleanup;
            }
        }
    }

    //Read data values and get sums and sums of squared values
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        agrp = floor(StrToFloat(MainForm->Grid->Cells[v1][i+1]));
        agrp = agrp - a1; // offset to zero
        p = 0.0;
        //Now read the B treatment scores
        for (j = 0; j < k; j++)
        {
            int col = ColNoSelected[j+1];
            if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
            X = StrToFloat(MainForm->Grid->Cells[col][i+1]);
            //result = GetValue(i+1,col,intvalue,dblvalue,strvalue);
            //if (result == 1) X = 0.0;
            //else X = dblvalue;
            C[agrp][j] = C[agrp][j] + X;
            StdDev[agrp][j] += (X * X);
            coeff[0] += X;
            p = p + X;
            sumxsquared[agrp] += (X * X);
            TotMean += X;
            TotStdDev += (X * X);
        }
        N[agrp] = N[agrp] + 1;
        squaredsumx[agrp] += (p * p);
        sumsum[agrp] += p;
    } // next case

    // Obtain sums of squares for std. dev.s of B treatments
    for (i = 0; i < k; i++) // column (B treatments)
        for (j = 0; j < range; j++) // group of A treatments
            StdDev[range][i] += StdDev[j][i];

    // Obtain sums of squares for std. dev.s of A treatments
    for (i = 0; i < range; i++)
        for (j = 0; j < k; j++)
            StdDev[i][k] += StdDev[i][j];

    // Obtain cell standard deviations
    for (i = 0; i < range; i++) // rows
    {
        for (j = 0; j < k; j++) // columns
        {
            StdDev[i][j] -= ((C[i][j] * C[i][j]) / double(N[i]));
            StdDev[i][j] /= (double(N[i]-1));
            StdDev[i][j] = sqrt(StdDev[i][j]);
        }
    }

    // Obtain A treatment group standard deviations
    for (i = 0; i < range; i++)
    {
        StdDev[i][k] -= ((sumsum[i] * sumsum[i]) / double(k * N[i]));
        StdDev[i][k] /= double(k * N[i] - 1);
        StdDev[i][k] = sqrt(StdDev[i][k]);
    }

    // Obtain coefficients for the sums of squares
    for (i = 0; i < range; i++)
    {
        coeff[1] += sumxsquared[i];
        coeff[2] += ((sumsum[i] * (sumsum[i]) / (double(N[i] * k))));
        coeff[5] += squaredsumx[i];
        totaln += N[i];
    }
    coeff[0] = (coeff[0] * coeff[0]) / double(totaln * k);
    double den = k;
    coeff[5] /= den;
    for (j = 0; j < k; j++)
    {
        coltot[j] = 0.0;
        for (i = 0; i < range; i++)
        {
            coltot[j] +=C[i][j];
            coeff[4] += ((C[i][j] * C[i][j]) / (double(N[i])));
        }
        coeff[3] += (coltot[j] * coltot[j]);
    }
    den = totaln;
    coeff[3] /= den;

    // Obtain B treatment group standard deviations
    for (j = 0; j < k; j++)
    {
        StdDev[range][j] -= (double(coltot[j] * coltot[j]) / double(totaln));
        StdDev[range][j] /= (double(totaln-1));
        StdDev[range][j] = sqrt(StdDev[range][j]);
    }

    // Calculate degrees of freedom for the mean squares
    degfree[0] = totaln - 1; // Between subjects degrees freedom
    degfree[1] = a2 - a1; // between groups degrees of freedom
    degfree[2] = totaln - (a2 - a1 + 1);// subjects within groups deg. frd.
    degfree[3] = totaln * (k - 1); // within subjects degrees of freedom
    degfree[4] = k - 1; // B treatments degrees of freedom
    degfree[5] = degfree[1] * degfree[4]; // A x B interaction degrees of frd.
    degfree[6] = degfree[2] * degfree[4]; // B x Subjects within groups d.f.
    degfree[7] = k * totaln - 1; // total degrees of freedom

    // Calculate the sums of squares
    ss[0] = coeff[5] - coeff[0];
    ss[1] = coeff[2] - coeff[0];
    ss[2] = coeff[5] - coeff[2];
    ss[3] = coeff[1] - coeff[5];
    ss[4] = coeff[3] - coeff[0];
    ss[5] = coeff[4] - coeff[2] - coeff[3] + coeff[0];
    ss[6] = coeff[1] - coeff[4] - coeff[5] + coeff[2];
    ss[7] = coeff[1] - coeff[0];

    // Calculate the mean squares
    for (i = 0; i < 8; i++)
    {
        den = degfree[i];
        ms[i] = ss[i] / den;
    }

    // Calculate the f-tests for effects A, B and interaction
    if (ms[2] > 0.0) f1 = ms[1] / ms[2];
    else f1 = 1000.0;
    if (ms[6] > 0.0)
    {
        f2 = ms[4] / ms[6];
        f3 = ms[5] / ms[6];
    }
    else
    {
        f2 = 1000.0;
        f3 = 1000.0;
    }

    //Now, report results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("ANOVA With One Between Subjects and One Within Subjects Treatments");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("------------------------------------------------------------------");
    FrmOutPut->RichOutPut->Lines->Add("Source             df      SS         MS         F         Prob.");
    FrmOutPut->RichOutPut->Lines->Add("------------------------------------------------------------------");
    fd1 = degfree[1];
    fd2 = degfree[2];
    probf1 = ftest(fd1, fd2, f1);
    fd1 = degfree[4];
    fd2 = degfree[6];
    probf2 = ftest(fd1, fd2, f2);
    fd1 = degfree[5];
    fd2 = degfree[6];
    probf3 = ftest(fd1, fd2, f3);
    sprintf(outline,"Between         %5d %10.3f",degfree[0],ss[0]);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   Groups (A)   %5d %10.3f %10.3f %10.3f      %6.4f",
            degfree[1], ss[1], ms[1], f1, probf1);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   Subjects w.g.%5d %10.3f %10.3f",degfree[2],ss[2],ms[2]);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Within Subjects %5d %10.3f",degfree[3], ss[3]);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   B Treatments %5d %10.3f %10.3f %10.3f      %6.4f",
            degfree[4], ss[4], ms[4], f2, probf2);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   A X B inter. %5d %10.3f %10.3f %10.3f      %6.4f",
            degfree[5], ss[5], ms[5], f3, probf3);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"   B X S w.g.   %5d %10.3f %10.3f",degfree[6], ss[6], ms[6]);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"TOTAL           %5d %10.3f",degfree[7], ss[7]);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("------------------------------------------------------------------");

    //Calculate and print means
    FrmOutPut->RichOutPut->Lines->Add("Means");
    sprintf(outline,"TRT.   ");
    for (i = 1; i <= k; i++)
    {
        sprintf(value,"B%3d   ",i);
        strcat(outline,value);
    }
    strcat(outline,"TOTAL");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add(" A ");
    for (i = 0; i < range; i++)
    {
        for (j = 0; j < k; j++)
            C[i][j] /= double(N[i]); //mean of each B treatment within A treatment
        sumsum[i] /= double(N[i] * k); //means in A treatment accross B treatments
    }
    for (j = 0; j < k; j++) coltot[j] /= double(totaln);
    TotStdDev -= ((TotMean * TotMean) / double(k * totaln));
    TotStdDev /= (double(k * totaln - 1));
    TotStdDev = sqrt(TotStdDev);
    TotMean /= double(k * totaln);
    for (i = 0; i < range; i++)
    {
        sprintf(outline,"%3d  ",i+a1);
        for (j = 0; j < k; j++)
        {
            sprintf(value,"%7.3f",C[i][j]);
            strcat(outline,value);
        }
        sprintf(value,"%7.3f",sumsum[i]);
        strcat(outline,value);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    sprintf(outline,"TOTAL");
    for (j = 0; j < k; j++)
    {
        sprintf(value,"%7.3f",coltot[j]);
        strcat(outline,value);
    }
    sprintf(value,"%7.3f",TotMean);
    strcat(outline,value);
    FrmOutPut->RichOutPut->Lines->Add(outline);

    // Print standard deviations
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Standard Deviations");
    sprintf(outline,"TRT.   ");
    for (i = 1; i <= k; i++)
    {
        sprintf(value,"B%3d   ",i);
        strcat(outline,value);
    }
    strcat(outline,"TOTAL");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add(" A ");
    for (i = 0; i < range; i++)
    {
        sprintf(outline,"%3d  ",i+a1);
        for (j = 0; j < k; j++)
        {
            sprintf(value,"%7.3f",StdDev[i][j]);
            strcat(outline,value);
        }
        sprintf(value,"%7.3f",StdDev[i][k]);
        strcat(outline,value);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    sprintf(outline,"TOTAL");
    for (j = 0; j < k; j++)
    {
        sprintf(value,"%7.3f",StdDev[range][j]);
        strcat(outline,value);
    }
    sprintf(value,"%7.3f",TotStdDev);
    strcat(outline,value);
    FrmOutPut->RichOutPut->Lines->Add(outline);

//    FrmOutPut->ShowModal();
    if (CheckBox1->Checked == true) PlotMeans(C,range,k,this);
    if (PostHocChk->Checked == true)
    {
        // do tests for between groups (A treatments)
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Post-hoc Comparisons for Groups");
        PostHocTests(range, ms[1], degfree[1], range, sumsum, alpha, this);
        FrmOutPut->RichOutPut->Lines->Add("");
        // do tests for repeated measures (B treatments)
        FrmOutPut->RichOutPut->Lines->Add("Post-hoc Comparisons for Repeated Measures");
        PostHocTests(k, ms[4], degfree[4], NoCases, coltot, alpha, this);
    }
    FrmOutPut->ShowModal();
    // cleanup the heap
cleanup:
    for (i = 0; i < range+1; i++) delete[] StdDev[i];
    delete[] StdDev;
    delete[] sumsum;
    delete[] sumxsquared;
    delete[] coltot;
    delete[] squaredsumx;
    delete[] N;
    for (i = 0; i < range; i++) delete[] C[i];
    delete[] C;
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::PlotMeans(double **C, int range, int k,
    TObject *Sender)
{
    // Allocate space for point sets of means
    GetDblMatMem(GraphForm->Xpoints,1,k);
    GetDblMatMem(GraphForm->Ypoints,range,k);
    float MaxMean = 0.0;
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < range; j++)
        {
            if (C[j][i] > MaxMean) MaxMean = C[j][i];
            GraphForm->Ypoints[j][i] = C[j][i];
        }
        GraphForm->Xpoints[0][i] = (double) (i+1);
    }
    GraphForm->nosets = range;
    GraphForm->nbars = k;
    GraphForm->Heading = "MEANS OF WITHIN TREATMENTS FOR EACH BETWEEN GROUPS TREATMENT";
    GraphForm->XTitle = "WITHIN (B) TREATMENT GROUP";
    GraphForm->YTitle = "MEAN";
    GraphForm->barwideprop = 0.5;
    GraphForm->AutoScale = false;
    GraphForm->miny = 0.0;
    GraphForm->maxy = MaxMean;
    GraphForm->GraphType = 3; // 3d vertical bars
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clBlack;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowBackWall = true;
    GraphForm->ShowModal();
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,range);
}
//---------------------------------------------------------------------------

void __fastcall TTypeIFrm::PostHocTests(int NoSelected, double MSerr,
                int dferr, int count, double *ColMeans, double alpha, TObject *Sender)
{
       double *group_total, *group_count;
       group_total = new double[NoSelected];
       group_count = new double[NoSelected];
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEY(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEY_KRAMER(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       TUKEYBTEST(MSerr,dferr,group_total,group_count,1,NoSelected,count,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       SCHEFFETEST(MSerr,group_total,group_count,1,NoSelected,count*NoSelected,alpha);
       for (int i = 0; i < NoSelected; i++)
       {
           group_count[i] = (double)count;
           group_total[i] = (double)count * ColMeans[i];
       }
       Newman_Keuls(MSerr,dferr,count,group_total,group_count,1,NoSelected,alpha);
       delete[] group_count;
       delete[] group_total;
}

//---------------------------------------------------------------------------
