//---------------------------------------------------------------------------

#ifndef DiscrimUnitH
#define DiscrimUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TNeuralDiscrimForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label1;
   TLabel *Label2;
   TLabel *Label3;
   TEdit *NGrpsEdit;
   TEdit *NVarsEdit;
   TEdit *ConfFileEdit;
   TLabel *Label4;
   TLabel *Label5;
   TEdit *NoLay1Edit;
   TEdit *NoLay2Edit;
   TLabel *Label6;
   TEdit *WghtNameEdit;
   TButton *CancelBtn;
   TButton *OKBtn;
private:	// User declarations
public:		// User declarations
   __fastcall TNeuralDiscrimForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TNeuralDiscrimForm *NeuralDiscrimForm;
//---------------------------------------------------------------------------
#endif
