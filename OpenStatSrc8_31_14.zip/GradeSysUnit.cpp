//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include <math.h>
#include "OutPut.h"
#include "MemMgrUnit.h"
#include "TestInfoUnit.h"
#include "GradingUnit.h"
#include "GradeSysUnit.h"
#include "GraphUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGradeSysFrm *GradeSysFrm;
//---------------------------------------------------------------------------
__fastcall TGradeSysFrm::TGradeSysFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGradeSysFrm::ExitBtnClick(TObject *Sender)
{
    GradeSysFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TGradeSysFrm::CancelBtnClick(TObject *Sender)
{
    GradeSysFrm->Hide();     
}
//---------------------------------------------------------------------------
void __fastcall TGradeSysFrm::FormShow(TObject *Sender)
{
    FileOpened = false;
    AbsenceMethod = 0;
    GradeScheme = 0;
    TestNoEdit->Text = "";
    TestNameEdit->Text = "";
    BookNameEdit->Text = "";
    for (int i = 0; i < 20; i++) tests[i] = NULL;
    Grid->RowCount = 2;
    Grid->ColCount = 6; // 10;
    Grid->Cells[0][0] = "NO.";
    Grid->Cells[1][0] = "LAST NAME";
    Grid->Cells[2][0] = "FIRST NAME";
    Grid->Cells[3][0] = "MID. INIT";
    Grid->Cells[4][0] = "IDENT. NO.";
    Grid->Cells[5][0] = "E-MAIL ADDR.";
    Grid->Cells[0][1] = 1;
}
//---------------------------------------------------------------------------
void __fastcall TGradeSysFrm::AddStudBtnClick(TObject *Sender)
{
    Grid->RowCount++;
    int row = Grid->RowCount-1;
    Grid->Cells[0][row] = row;
    gbook.NoStudents = Grid->RowCount-1;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::InitTest(int TestN)
{
    char tempstr[21];

    Grid->ColCount += 4;
    int col = Grid->ColCount - 4;
    sprintf(tempstr,"%d Raw",TestN);
    Grid->Cells[col][0] = tempstr;
    sprintf(tempstr,"%d z",TestN);
    Grid->Cells[col+1][0] = tempstr;
    sprintf(tempstr,"%d Rank",TestN);
    Grid->Cells[col+2][0] = tempstr;
    sprintf(tempstr,"%d Grade",TestN);
    Grid->Cells[col+3][0] = tempstr;
    tests[TestN-1] = new Test;
    Grid->Row = 1;
    Grid->Col = 5 + (4 * TestN) - 3;
    TestDescChkBox->Checked = true;
    DoBookBtnClick(this);
}
//---------------------------------------------------------------------------


void __fastcall TGradeSysFrm::GridKeyPress(TObject *Sender, char &Key)
{
    int test;

    if (Key == 13)
    {
        if (Grid->Col < Grid->ColCount-1) Grid->Col++;
    }
    else // get current test number
    {
        if (Grid->Col < 6) test = 0;
        else test = ((Grid->Col - 6) / 4)+1;
        TestNoEdit->Text = test;
        char tempstr[21];
        sprintf(tempstr,"Test %d",test);
        TestNameEdit->Text = tempstr;
        TestNo = test;
    }
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::AddTestBtnClick(TObject *Sender)
{
    int notests = ((Grid->ColCount - 5) / 4);
    InitTest(notests+1);
    Grid->Row = 1;
    Grid->Col = Grid->ColCount - 5;
    gbook.NoTests = notests+1;
}
//---------------------------------------------------------------------------


void __fastcall TGradeSysFrm::GridClick(TObject *Sender)
{
    int test;

    if (Grid->Col < 6) test = 0;
    else test = ((Grid->Col - 6) / 4)+1;
    TestNoEdit->Text = test;
    char tempstr[21];
    sprintf(tempstr,"Test %d",test);
    TestNameEdit->Text = tempstr;
    TestNo = test;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::DelStudBtnClick(TObject *Sender)
{
    int row = Grid->Row;

    if (row == 0) return;
    if (row == Grid->RowCount-1)
    {
        for (int i = 0; i < Grid->ColCount; i++) Grid->Cells[i][row] = "";
        Grid->RowCount--;
        return;
    }
	if (Grid->RowCount > 2)
    {
    	for (int i = row+1; i < Grid->RowCount; i++)
        {
        	for (int j = 0; j < Grid->ColCount; j++)
            	Grid->Cells[j][i-1] = Grid->Cells[j][i];
        }
    }
	for (int j = 0; j < Grid->ColCount; j++)
      	Grid->Cells[j][Grid->RowCount-1] = "";
    Grid->RowCount--;
    for (int i = row; i < Grid->RowCount; i++) Grid->Cells[0][i] = i;
    gbook.NoStudents = Grid->RowCount-1;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::DelTestBtnClick(TObject *Sender)
{
    int testno = atoi(TestNoEdit->Text.c_str());
    int col = 6 + (testno * 4) - 4;

    for (int k = 0; k < 4; k++)
    {
    	for (int i = col+1; i < Grid->ColCount; i++)
        {
        	for (int j = 0; j < Grid->RowCount; j++)
            {
            	Grid->Cells[i-1][j] = Grid->Cells[i][j];
            }
        }
    }
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < Grid->RowCount; j++)
             Grid->Cells[Grid->ColCount-1][j] = "";
        Grid->ColCount--; // reduce grid no. of columns
    }
    delete[] tests[testno-1];
    tests[testno-1] = NULL;
    int notests = ((Grid->ColCount - 5) / 4);
    gbook.NoTests = notests;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::SortBtnClick(TObject *Sender)
{
     int sortcol = Grid->Col;
     int norows = Grid->RowCount;
     AnsiString cellstr1;
     AnsiString cellstr2;
     AnsiString tempstr;

     for (int i = 1; i < norows - 1; i++)
     {
         for (int j = i+1; j < norows; j++)
         {
             cellstr1 = Grid->Cells[sortcol][i];
             cellstr2 = Grid->Cells[sortcol][j];
             if (cellstr1 > cellstr2) // swap rows
             {
                 for (int k = 1; k < Grid->ColCount; k++)
                 {
                     tempstr = Grid->Cells[k][i];
                     Grid->Cells[k][i] = Grid->Cells[k][j];
                     Grid->Cells[k][j] = tempstr;
                 }
             }
         }
     }
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::OpenFileBtnClick(TObject *Sender)
{
    int notests;
    int nocases;
    char CellString[21];

    OpenDialog1->DefaultExt = "GBK";
    OpenDialog1->Filter = "GradeBook(*.GBK)|*.GBK|ALL (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
    if ((OpenDialog1->Execute()) == NULL) return;
    strcpy(FileName,OpenDialog1->FileName.c_str());
    if ((fileptr = fopen(FileName,"rb")) != NULL)
    {
        BookNameEdit->Text = FileName;
        fread(&gbook,sizeof(gbook),1,fileptr);
        notests = gbook.NoTests;
        if (notests > 0)
        {
            for (int i = 0; i < notests; i++)
            {
                tests[i] = new Test;
                fread(tests[i],sizeof(Test),1,fileptr);
            }
        }
        nocases = gbook.NoStudents;
        Grid->ColCount = 6 + (4 * notests);
        Grid->RowCount = nocases + 1;
        for (int i = 0; i < Grid->RowCount; i++)
        {
            for (int j = 0; j < Grid->ColCount; j++)
            {
                fread(&CellString,sizeof(CellString),1,fileptr);
                Grid->Cells[j][i] = CellString;
            }
        }
    }
    else return;
    BookNameEdit->Text = gbook.Name;
    fclose(fileptr);
    FileOpened = true;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::SaveFileBtnClick(TObject *Sender)
{
    char CellString[21];
    int notests = ((Grid->ColCount - 5) / 4);
    for (int i = 0; i < notests; i++)
    {
        if (tests[i] == NULL)
        {
            Application->MessageBox("One of the tests has not yet been defined!",
                "ERROR!",MB_OK);
            return;
        }
    }
    gbook.NoStudents = Grid->RowCount-1;
    gbook.NoTests = notests;
    if (AbsenceMethod == 0) gbook.AbsenceMethod = 1; // default
    if (GradeScheme == 0) gbook.GradeScheme = 1; // default
    if (strlen(gbook.Name) == 0) strcpy(gbook.Name,"GRADEBOOK1"); //default
    if (strlen(FileName) > 0) SaveDialog1->FileName = FileName;
    SaveDialog1->DefaultExt = "GBK";
    SaveDialog1->Filter = "GradeBook(*.GBK)|*.GBK|ALL (*.*)|*.*";
    SaveDialog1->FilterIndex = 1;
    if ((SaveDialog1->Execute()) == NULL) return;
    strcpy(FileName,SaveDialog1->FileName.c_str());
    fileptr = fopen(FileName,"wb");
    fwrite(&gbook,sizeof(GradeBook),1,fileptr);
    if (notests > 0)
    {
        for (int i = 0; i < notests; i++)
            fwrite(tests[i],sizeof(Test),1,fileptr);
    }
    for (int i = 0; i < Grid->RowCount; i++)
    {
        for (int j = 0; j < Grid->ColCount; j++)
        {
            strcpy(CellString,Grid->Cells[j][i].c_str());
            fwrite(&CellString,sizeof(CellString),1,fileptr);
        }
    }
    fclose(fileptr);
    for (int i = 0; i < notests; i++) tests[i] = NULL;
    for (int i = 0; i < Grid->ColCount; i++)
        for (int j = 0; j < Grid->RowCount; j++) Grid->Cells[i][j] = "";
    Grid->ColCount = 2;
    Grid->RowCount = 2;
    FormShow(this);
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::DoBookBtnClick(TObject *Sender)
{
    AnsiString response;
    char outline[81];

    if (BookTitleChkBox->Checked)
    {
        response = InputBox("NAME","Enter the gradebook name: ","GRADEBOOK1");
        strcpy(gbook.Name,response.c_str());
        BookNameEdit->Text = response;
        BookTitleChkBox->Checked = false;
    }
    if (GrdMethChkBox->Checked)
    {
        GradingFrm->ShowModal();
        if (GradingFrm->ModalResult == mrCancel)return;
        AbsenceMethod = GradingFrm->RadioGroup1->ItemIndex + 1;
        gbook.AbsenceMethod = AbsenceMethod;
        GradeScheme = GradingFrm->RadioGroup2->ItemIndex + 1;
        gbook.GradeScheme = GradeScheme;
        gbook.Dist[0][0] = atof(GradingFrm->Edit1->Text.c_str());
        gbook.Dist[1][0] = atof(GradingFrm->Edit3->Text.c_str());
        gbook.Dist[2][0] = atof(GradingFrm->Edit5->Text.c_str());
        gbook.Dist[3][0] = atof(GradingFrm->Edit7->Text.c_str());
        gbook.Dist[4][0] = atof(GradingFrm->Edit9->Text.c_str());
        gbook.Dist[5][0] = atof(GradingFrm->Edit11->Text.c_str());
        gbook.Dist[6][0] = atof(GradingFrm->Edit13->Text.c_str());
        gbook.Dist[7][0] = atof(GradingFrm->Edit15->Text.c_str());
        gbook.Dist[8][0] = atof(GradingFrm->Edit17->Text.c_str());
        gbook.Dist[9][0] = atof(GradingFrm->Edit19->Text.c_str());
        gbook.Dist[10][0] = atof(GradingFrm->Edit21->Text.c_str());
        gbook.Dist[11][0] = atof(GradingFrm->Edit23->Text.c_str());
        gbook.Dist[0][1] = atof(GradingFrm->Edit2->Text.c_str());
        gbook.Dist[1][1] = atof(GradingFrm->Edit4->Text.c_str());
        gbook.Dist[2][1] = atof(GradingFrm->Edit6->Text.c_str());
        gbook.Dist[3][1] = atof(GradingFrm->Edit8->Text.c_str());
        gbook.Dist[4][1] = atof(GradingFrm->Edit10->Text.c_str());
        gbook.Dist[5][1] = atof(GradingFrm->Edit12->Text.c_str());
        gbook.Dist[6][1] = atof(GradingFrm->Edit14->Text.c_str());
        gbook.Dist[7][1] = atof(GradingFrm->Edit16->Text.c_str());
        gbook.Dist[8][1] = atof(GradingFrm->Edit18->Text.c_str());
        gbook.Dist[9][1] = atof(GradingFrm->Edit20->Text.c_str());
        gbook.Dist[10][1] = atof(GradingFrm->Edit22->Text.c_str());
        gbook.Dist[11][1] = atof(GradingFrm->Edit24->Text.c_str());
        GrdMethChkBox->Checked = false;
    }
    if (TestDescChkBox->Checked)
    {
        int testno = atoi(TestNoEdit->Text.c_str());
        if (testno == 0)
        {
            Application->MessageBox("First click on a column of the test.",
                "ERROR",MB_OK);
            return;
        }
        TestInfoFrm->NoEdit->Text = testno;
        TestInfoFrm->ShowModal();
        tests[testno-1]->TestNo = testno;
        tests[testno-1]->NoItems = atoi(TestInfoFrm->NoItemsEdit->Text.c_str());
        tests[testno-1]->Weight = atof(TestInfoFrm->WeightEdit->Text.c_str());
        tests[testno-1]->Reliability = atof(TestInfoFrm->TestRelEdit->Text.c_str());
        strcpy(tests[testno-1]->Description,TestInfoFrm->TitleEdit->Text.c_str());
        tests[testno-1]->Mean = 0.0;
        tests[testno-1]->StdDev = 0.0;
        TestDescChkBox->Checked = false;
    }
    if (PrntGridChkBox->Checked)
    {
        PrintCases();
        PrntGridChkBox->Checked = false;
    }
    if (TestSumChkBox->Checked)
    {
        int testno = atoi(TestNoEdit->Text.c_str());
        if (testno == 0)
        {
            Application->MessageBox("First click on a column of the test.",
                "ERROR",MB_OK);
            return;
        }
        FrmOutPut->RichOutPut->Clear();
        sprintf(outline,"SUMMARY FOR TEST NUMBER %d",testno);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"TEST NAME = %s",tests[testno-1]->Description);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"NO. ITEMS = %d",tests[testno-1]->NoItems);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"RELIABILITY = %6.3f",tests[testno-1]->Reliability);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"WEIGHT = %6.3f",tests[testno-1]->Weight);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"MEAN = %6.3f",tests[testno-1]->Mean);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"STANDARD DEVIATION = %6.3f",tests[testno-1]->StdDev);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
        TestSumChkBox->Checked = false;
    }
    if (GrdBkSumChkBox->Checked)
    {
        FrmOutPut->RichOutPut->Clear();
        sprintf(outline,"NAME = %s",gbook.Name);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"NO. OF STUDENTS = %d",gbook.NoStudents);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"NO. OF TESTS = %d",gbook.NoTests);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"If a student misses a test you ");
        if (gbook.AbsenceMethod == 0) gbook.AbsenceMethod = 1;
        switch (gbook.AbsenceMethod)
        {
            case 1:
                strcat(outline,"assign a raw score of zero to the test.");
                break;
            case 2:
                strcat(outline,"assign the average of the student's other tests.");
                break;
            case 3:
                strcat(outline,"predict the score from other student's scores.");
                break;
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (gbook.GradeScheme == 0) gbook.GradeScheme = 1; // default
        strcpy(outline,"You base final grades on ");
        switch (gbook.GradeScheme)
        {
            case 1:
                strcat(outline,"the total of unweighted raw scores.");
                break;
            case 2:
                strcat(outline,"the total of weighted raw scores.");
                break;
            case 3:
                strcat(outline,"the total of unweighted z scores.");
                break;
            case 4:
                strcat(outline,"the total of weighted z scores.");
                break;
            case 5:
                strcat(outline,"the total of unweighted rank scores.");
                break;
            case 6:
                strcat(outline,"the total of weighted rank scores.");
                break;
            case 7:
                strcat(outline,"the percent of items correctly passed.");
                break;
            case 8:
                strcat(outline,"the average letter grade earned (A = 11, F = 0");
                break;
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        char LETGRADE[12][3] = {"A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"};
        FrmOutPut->RichOutPut->Lines->Add("GRADING DISTRIBUTION PARAMETERS");
        FrmOutPut->RichOutPut->Lines->Add("GRADE   FROM   UP TO");
        for (int j = 0; j < 12; j++)
        {
            sprintf(outline,"  %2s  %6.2f %6.2f",
                LETGRADE[j], gbook.Dist[j][0], gbook.Dist[j][1]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
        GrdBkSumChkBox->Checked = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::DoTestBtnClick(TObject *Sender)
{
    double *orderedX;
    double *Rank;
    int *index;
    char outline[81];

    int testno = atoi(TestNoEdit->Text.c_str());
    if (testno == 0)
    {
        Application->MessageBox("First click on a column of the test.",
                "ERROR",MB_OK);
        return;
    }
    // calculate mean and std. dev. of non-missing scores.
    int rawcol = 6 + (testno * 4) - 4;
    double mean = 0.0;
    double sd = 0.0;
    int N = 0;
    double X;
    // Check for missing values and, if required, replace with zeros,
    // average of existing scores or predicted from other's scores
    for (int i = 1; i < Grid->RowCount; i++)
    {
        if (Grid->Cells[rawcol][i] == "") // found blank!
        {
            if(gbook.AbsenceMethod == 1) // replace with zero
                Grid->Cells[rawcol][i] = 0.0;
            if (gbook.AbsenceMethod == 2) // average of other scores of the student
            {
                int notests = Grid->ColCount - 5 / 4;
                if (notests > 1) // is there anything to average?
                {
                    double tsum = 0.0;
                    double count = 0.0;
                    for (int j = 1; j <= notests; j++)
                    {
                        int atest = 6 + (j * 4) - 4;
                        if (atest != rawcol) // can't use same test!
                        {
                            if (Grid->Cells[atest][i] != "")
                            {
                                tsum += atof(Grid->Cells[atest][i].c_str());
                                count += 1.0;
                            }
                        }
                        if (count > 0)
                        {
                            tsum /= count;
                            Grid->Cells[rawcol][i] = tsum;
                        } // end calculation of mean of other test scores
                    } // end loop for j test
                } // end if more than one test available to use
            } // end if abscence method = 2
            if (gbook.AbsenceMethod == 3) // predicted from other scores
            {
                Application->MessageBox("Mult.Reg not yet available - using mean of other's scores",
                    "NOTICE!",MB_OK);
                double sumx = 0.0;
                double count = 0.0;
                for (int k = 1; k < Grid->RowCount; k++)
                {
                    if (Grid->Cells[rawcol][k] != "")
                    {
                        sumx += atof(Grid->Cells[rawcol][k].c_str());
                        count += 1.0;
                    }
                    if (count > 0.0)
                    {
                        sumx /= count;
                        Grid->Cells[rawcol][i] = sumx;
                    }
                }
            } // end if abscence method = 3 (predicted)
        } // end if a blank score found
    } // end student i loop
    for (int i = 1; i < Grid->RowCount; i++)
    {
        if (Grid->Cells[rawcol][i] != "")
        {
           X = atof(Grid->Cells[rawcol][i].c_str());
           mean += X;
           sd += (X * X);
           N++;
        }
    }
    sd = sd - (mean * mean / double(N));
    sd /= (double(N) - 1.0);
    sd = sqrt(sd);
    mean /= double(N);
    sprintf(outline,"Results for test %d: Mean = %6.3f, S.D. = %6.3f, N = %d",
         testno,mean,sd, N);
    Application->MessageBox(outline,"MESSAGE",MB_OK);
    tests[testno-1]->Mean = mean;
    tests[testno-1]->StdDev = sd;
    if (zChkBox->Checked)
    {
        for (int i = 1; i < Grid->RowCount; i++)
        {
            if (Grid->Cells[rawcol][i] != "")
            {
                X = atof(Grid->Cells[rawcol][i].c_str());
                double z = (X - mean) / sd;
                sprintf(outline,"%6.3f",z);
                Grid->Cells[rawcol+1][i] = outline;
            }
        }
        zChkBox->Checked = false;
    }
    if (RankChkBox->Checked)
    {
        //Place scores in a vector, sort the vector and convert to ranks
        orderedX = new double[N];
        index = new int[N];
        Rank = new double[N];
        // get scores and sort
        int j = 0;
        for (int i = 1; i < Grid->RowCount; i++)
        {
            if (Grid->Cells[rawcol][i] != "")
            {
                orderedX[j] = atof(Grid->Cells[rawcol][i].c_str());
                index[j] = i;
                j++;
            }
        }
        for (int i = 0; i < N - 1; i++)
        {
            for (int j = i+1; j < N; j++)
            {
                if (orderedX[i] > orderedX[j]) // swap
                {
                    double temp = orderedX[i];
                    orderedX[i] = orderedX[j];
                    orderedX[j] = temp;
                    temp = Rank[i];
                    Rank[i] = Rank[j];
                    Rank[j] = temp;
                    int tempi = index[i];
                    index[i] = index[j];
                    index[j] = tempi;
                }
            }
        }
        for (int i = 0; i < N; i++) Rank[i] = i+1;

        // find ties and replace with average rank
        double temp = orderedX[0];
        int ties = 0;
        for (int i = 1; i < N; i++)
        {
            if (orderedX[i] == temp) ties++;
            if ((orderedX[i] != temp) && (ties == 0)) temp = orderedX[i];
            if ((orderedX[i] != temp) && (ties > 0))// average ranks
            {
                double ranksum = 0.0;
                for (int j = 0; j < ties+1; j++) ranksum += Rank[i-1-j];
                ranksum /= double(ties+1);
                for (int j = 0; j < ties+1; j++) Rank[i-1-j] = ranksum;
                ties = 0;
                temp = orderedX[i];
            }
        }
        // check for last score being a tie
        if (ties > 0)
        {
                int i = N-1;
                double ranksum = 0.0;
                for (int j = 0; j < ties; j++) ranksum += Rank[i-1-j];
                ranksum /= double(ties);
                for (int j = 0; j < ties; j++) Rank[i-1-j] = ranksum;
        }
        // Now store ranks in grid position pointed to by the index
        for (int i = 0; i < N; i++)
            Grid->Cells[rawcol+2][index[i]] = Rank[i];
        delete[] Rank;
        delete[] index;
        delete[] orderedX;
        RankChkBox->Checked = false;
    }
    if (LtrGrdChkBox->Checked)
    {
        if ((gbook.Dist[0][0] == 0.0) && (gbook.Dist[0][1] == 0.0))
        {
            Application->MessageBox("You have not assigned values for a grade distribution!",
                "ERROR!",MB_OK);
            return;
        }
        int col;
        int gtype = gbook.GradeScheme;
        char LETGRADE[12][3] = {"A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F"};
        for (int i = 1; i < Grid->RowCount; i++)
        {
            double X;
            switch (gtype)
            {
                case 1: // raw score - unweigted
                    col = rawcol;
                    break;
                case 2: // raw score - weighted
                    col = rawcol;
                    break;
                case 3: // z score - unweighted
                    col = rawcol + 1;
                    break;
                case 4: // z score - weighted
                    col = rawcol + 1;
                    break;
                case 5: // unweighted rank
                    col = rawcol + 2;
                    break;
                case 6: // weighted rank
                    col = rawcol + 2;
                    break;
                case 7: // percent correct items
                    col = rawcol;
                    break;
                case 8: // average of letter grades - can't do for grading
                    Application->MessageBox("Not acceptable for letter grading.",
                        "ERROR",MB_OK);
                    return;
                    
            } // end switch
            X = atof(Grid->Cells[col][i].c_str());
            if (gtype == 7) X = (X / tests[testno]->NoItems) * 100.0;
            for (int j = 0; j < 12; j++)
            {
                if ((X >= gbook.Dist[j][0]) &&
                    (X < gbook.Dist[j][1]))
                    Grid->Cells[rawcol+3][i] = LETGRADE[j];
            }
        } // next student
        LtrGrdChkBox->Checked = false;
    }
    if (RawDistChkBox->Checked)
    {
        BarPlot(rawcol, 1);
        RawDistChkBox->Checked = false;
    }
    if (zDistChkBox->Checked)
    {
        BarPlot(rawcol+1, 2);
        zDistChkBox->Checked = false;
    }
    if (GradeDistChkBox->Checked)
    {
        BarPlot(rawcol+3, 3);
        GradeDistChkBox->Checked = false;
    }
    if (RelChkBox->Checked)
    {
        double nitems = tests[testno-1]->NoItems;
        double term = mean - ((mean * mean) / nitems);
        term = 1.0 - (term / (sd * sd));
        term = (nitems / (nitems - 1.0)) * term;
        tests[testno-1]->Reliability = term;
        sprintf(outline,"KR #21 reliability for test %d: = %4.3f",
         testno,term);
        Application->MessageBox(outline,"MESSAGE",MB_OK);
        RelChkBox->Checked = false;
    }
    if (ClsSumryChkBox->Checked)
    {
        FrmOutPut->RichOutPut->Lines->Clear();
        sprintf(outline,"SUMMARY OF TEST RESULTS FOR TEST NUMBER %d",testno);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"LAST NAME           FIRST NAME          MI RAW SCORE Z SCORE   RANK GRADE");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 1; i < Grid->RowCount; i++)
        {
            sprintf(outline,"%-20s%-20s%1s.%9s %7s %6s %6s",
                Grid->Cells[1][i].c_str(),Grid->Cells[2][i].c_str(),
                Grid->Cells[3][i].c_str(),Grid->Cells[rawcol][i].c_str(),
                Grid->Cells[rawcol+1][i].c_str(),Grid->Cells[rawcol+2][i].c_str(),
                Grid->Cells[rawcol+3][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"TEST MEAN = %8.3f",mean);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"TEST STANDARD DEVIATION = %8.3f",sd);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();
        ClsSumryChkBox->Checked = false;
    }
    if (StdRepChkBox->Checked)
    {
        for (int i = 1; i < Grid->RowCount; i++)
        {
            FrmOutPut->RichOutPut->Lines->Clear();
            sprintf(outline,"SUMMARY OF TEST RESULTS FOR TEST NUMBER %d",testno);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(outline,"LAST NAME: %s",Grid->Cells[1][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"FIRST NAME: %s",Grid->Cells[2][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"MIDDLE INITIAL: %s",Grid->Cells[3][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"IDENTIFICATION NUMBER: %s",Grid->Cells[4][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"EMAIL ADDRESS: %s",Grid->Cells[5][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"RAW TEST SCORE: %s",Grid->Cells[rawcol][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"STANDARDIZED Z SCORE: %s",Grid->Cells[rawcol+1][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"RANK IN CLASS: %s",Grid->Cells[rawcol+2][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"GRADE ASSIGNED: %s",Grid->Cells[rawcol+3][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->ShowModal();
        }
        StdRepChkBox->Checked = false;
    }
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::DoClassBtnClick(TObject *Sender)
{
    double total;
    char outline[81];
    int noaugs = 0;
    bool report = false;
    int notests = ((Grid->ColCount - 5) / 4);
    int oldcolcount = Grid->ColCount;
    if (TotRawChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVG. RAW";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 6 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += X;
            }
            sprintf(outline,"%6.3f",total / double(notests));
            Grid->Cells[totpos][i] = outline;
        }
        noaugs++;
        CompRelChkBox->Checked = false;
        report = true;
        TotRawChkBox->Checked = false;
    }

    if (TotZChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVG. Z";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 7 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += X;
            }
            sprintf(outline,"%6.3f",total / double(notests));
            Grid->Cells[totpos][i] = outline;
        }
        noaugs++;
        CompRelChkBox->Checked = false;
        report = true;
        TotZChkBox->Checked = false;
    }

    if (TotRankChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVG.RANK";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 8 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += X;
            }
            sprintf(outline,"%6.3f",total / double(notests));
            Grid->Cells[totpos][i] = outline;
        }
        noaugs++;
        report = true;
        CompRelChkBox->Checked = false;
        TotRankChkBox->Checked = false;
    }

    if (TotWRawChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVG.WGHT RAW";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            double sumweights = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 6 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += (X * tests[j-1]->Weight);
                sumweights += tests[j-1]->Weight;
            }
            sprintf(outline,"%6.3f",total / sumweights);
            Grid->Cells[totpos][i] = outline;
        }
        report = true;
        noaugs++;
        CompRelChkBox->Checked = false;
        TotWRawChkBox->Checked = false;
    }

    if (TotWzChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVE.WGHT Z";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            double sumweights = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 7 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += (X * tests[j-1]->Weight);
                sumweights += tests[j-1]->Weight;
            }
            sprintf(outline,"%6.3f",total / sumweights);
            Grid->Cells[totpos][i] = outline;
        }
        noaugs++;
        CompRelChkBox->Checked = false;
        report = true;
        TotWzChkBox->Checked = false;
    }

    if (TotWRankChkBox->Checked)
    {
        Grid->ColCount++;
        int totpos = Grid->ColCount-1;
        Grid->Cells[totpos][0] = "AVG.WGHT RANK";
        for (int i = 1; i < Grid->RowCount; i++)
        {
            total = 0.0;
            double sumweights = 0.0;
            for (int j = 1; j <= notests; j++)
            {
                int col = 8 + (j * 4) - 4;
                double X = atof(Grid->Cells[col][i].c_str());
                total += (X * tests[j-1]->Weight);
                sumweights += tests[j-1]->Weight;
            }
            sprintf(outline,"%6.3f",total / sumweights);
            Grid->Cells[totpos][i] = outline;
        }
        noaugs++;
        CompRelChkBox->Checked = false;
        report = true;
        TotWRankChkBox->Checked = false;
    }

    if (CompRelChkBox->Checked)
    {
        CompRel();
        CompRelChkBox->Checked = false;
    }
    if (report == true)
    {
        int col; // = Grid->ColCount-1;
        FrmOutPut->RichOutPut->Lines->Clear();
        sprintf(outline,"SUMMARY OF TEST RESULTS FOR TOTALS");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"LAST NAME           FIRST NAME          MI ID NUMBER");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 1; i < Grid->RowCount; i++)
        {
            sprintf(outline,"%-20s%-20s%1s.  %-10s",
                Grid->Cells[1][i].c_str(),Grid->Cells[2][i].c_str(),
                Grid->Cells[3][i].c_str(),Grid->Cells[4][i].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            for (int j = 0; j < noaugs; j++)
            {
                col = Grid->ColCount - noaugs + j;
                sprintf(outline,"%s = %s",
                    Grid->Cells[col][0].c_str(),
                    Grid->Cells[col][i].c_str());
                FrmOutPut->RichOutPut->Lines->Add(outline);
            }
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->ShowModal();
        }
    }
    if (noaugs > 0) Grid->ColCount = oldcolcount;
}
//---------------------------------------------------------------------------

void __fastcall TGradeSysFrm::PrintCases(void)
{
    char outline[101];
    int startcol = 1;
    int endcol;
    bool done = false;
    char cellstring[21];

    FrmOutPut->RichOutPut->Lines->Clear();
    sprintf(outline,"\n\nCASES FOR FILE %s\n",FileName);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    while (!done)
    {
		endcol = startcol + 7;
        if (endcol > Grid->ColCount) endcol = Grid->ColCount;
        for (int i = 0; i < Grid->RowCount; i++)
        {
        	strcpy(outline,"");
        	for (int j = startcol; j < endcol; j++)
            {
                sprintf(cellstring," %10s",Grid->Cells[j][i].c_str());
                strcat(outline,cellstring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        if (endcol == Grid->ColCount) done = true;
        else
        {
            startcol = endcol;
            FrmOutPut->RichOutPut->Lines->Add(" ");
        }
    }
    FrmOutPut->Show();
}
//------------------------------------------------------------------
void __fastcall TGradeSysFrm::BarPlot(int col, int type)
{
    char LETGRADE[12][3] = {"F","D-","D","D+","C-","C","C+","B-","B","B+","A-","A"};
    char outline[81];
    double *BarFreq;
//    double *X = NULL;
    double X, max, min, xrange, increment;
    int nbars;
    int N = Grid->RowCount-1;

    // set up an array for a maximum of 11 bars.  If no. of points is
    // less, set up for no. of points;
    if (type == 1) // raw scores
    {
        min = 0.0;
        int notest = atoi(TestNoEdit->Text.c_str());
        max = tests[notest-1]->NoItems;
        xrange = max - min + 1;
        nbars = xrange;
        if (nbars > 11) nbars = 11;
        increment = xrange / double(nbars);
        strcpy(outline,"RAW SCORE");
    }
    if (type == 2) // z scores
    {
        min = -3.0;
        max = 3.0;
        xrange = max - min;
        nbars = 11;
        increment = xrange / nbars;
        sprintf(outline,"Z SCORES (increment size = %6.3f)",increment);
    }
    if (type == 3) // grades
    {
        min = 0;
        max = 11;
        xrange = max - min;
        nbars = xrange;
        increment = xrange / nbars;
        strcpy(outline,"GRADE (A=11,B+=10,...,F=0)");
    }

    // Allocate space for point sets of means and a temp X array
    try  {
        BarFreq = new double[nbars+1]; // freq. of X scores in each bar category
        GetDblMatMem(GraphForm->Ypoints,1,nbars+1);
        GetDblMatMem(GraphForm->Xpoints,1,nbars+1);
    }
    catch (...)
    {
        Application->MessageBox("Memory Error.","ERROR",MB_OK);
        return;
    }
    for (int i = 0; i < nbars+1; i++) BarFreq[i] = 0.0;
    for (int i = 0; i < nbars+1; i++)
    {
        double lower = min + (i * increment);
        double upper = lower + increment;
        for (int j = 0; j < N; j++)
        {
            if (type != 3) X = atof(Grid->Cells[col][j+1].c_str());
            else
            {
                 for (int k = 0; k < 12; k++)
                 {
                     if (Grid->Cells[col][j+1] == LETGRADE[k]) X = double(k);
                 }
            }
            if ((X >= lower) && (X < upper)) BarFreq[i]++;
        }
    }
    FrmOutPut->RichOutPut->Lines->Clear();
    FrmOutPut->RichOutPut->Lines->Add("FREQUENCY DISTRIBUTION");
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("----SCORE INTERVAL----");
    FrmOutPut->RichOutPut->Lines->Add("LOWER LIMIT UPPER LIMIT  FREQ.");

    // Get maximum mean
    float MaxFreq = 0.0;
    for (int i = 0; i < nbars+1; i++)
        if (BarFreq[i] > MaxFreq) MaxFreq = BarFreq[i];
    GraphForm->miny = 0.0;
    GraphForm->maxy = MaxFreq;
    GraphForm->Heading = "FREQUENCY DISTRIBUTION";
    GraphForm->XTitle = outline;
    GraphForm->YTitle = "FREQUENCY";
    GraphForm->nosets = 1;
    GraphForm->nbars = nbars+1;
    GraphForm->barwideprop = 0.5;
    GraphForm->BackColor = clWhite;
    GraphForm->GraphType = 3; // 3d vertical bars
    GraphForm->PtLabels = false;
    for (int i = 0; i < nbars+1; i++)
    {
        GraphForm->Ypoints[0][i] = BarFreq[i];
        GraphForm->Xpoints[0][i] = min + (i * increment);
    }
    GraphForm->ShowModal();
    for (int i = 0; i < nbars+1; i++)
    {
        sprintf(outline,"   %6.3f     %6.3f   %6.3f",
           min+(i*increment),min+((i+1)*increment),BarFreq[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->ShowModal();
    // clean up the heap
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
    delete[] BarFreq;
}
//------------------------------------------------------------------------

void __fastcall TGradeSysFrm::CompRel(void)
{
    bool done = false;
    char outline[81];
    char cellstring[11];
    double **mat;
    double **matr;
    double *means;
    double *stddevs;
    double *wvector;
    double *LeftProd;
    double N = double(Grid->RowCount - 1);
    int notests = ((Grid->ColCount - 5) / 4);

    try
    {
        mat = new double *[notests];
        for (int i = 0; i < notests; i++) mat[i] = new double[notests];
        matr = new double *[notests];
        for (int i = 0; i < notests; i++) matr[i] = new double[notests];
        means = new double[notests];
        stddevs = new double[notests];
        wvector = new double[notests];
        LeftProd = new double[notests];
    }
    catch (...)
    {
        Application->MessageBox("Mem. error in composite reliability.",
            "ERROR",MB_OK);
        return;
    }
    for (int i = 0; i < notests; i++)
    {
        LeftProd[i] = 0.0;
        wvector[i] = 0.0;
        means[i] = 0.0;
        stddevs[i] = 0.0;
        for (int j = 0; j < notests; j++)
        {
            mat[i][j] = 0.0;
            matr[i][j] = 0.0;
        }
    }
    for (int i = 0; i < Grid->RowCount-1; i++) // students
    {
        for (int j = 0; j < notests; j++)
        {
            int col1 = 6 + (j * 4);
            double X = atof(Grid->Cells[col1][i+1].c_str());
            means[j] += X;
            stddevs[j] += (X * X);
            for (int k = 0; k < notests; k++)
            {
                int col2 = 6 + (k * 4);
                double Y = atof(Grid->Cells[col2][i+1].c_str());
                mat[j][k] += (X * Y);
            }
        }
    }
    for (int i = 0; i < notests; i++)
    {
        for (int j = 0; j < notests; j++)
        {
            mat[i][j] = mat[i][j] - (means[i] * means[j]) / N;
            mat[i][j] = mat[i][j] / (N - 1.0); // covariance
        }
        stddevs[i] = stddevs[i] - (means[i] * means[i]) / N;
        stddevs[i] = stddevs[i] / (N - 1.0); // variances
        stddevs[i] = sqrt(stddevs[i]); // standard deviations
        if (stddevs[i] ==  0.0)
        {
            sprintf(outline,"A zero std. dev. found for test %d!",i+1);
            Application->MessageBox(outline,"ERROR",MB_OK);
        }
    }
    for (int i = 0; i < notests; i++)
    {
        for (int j = 0; j < notests; j++)
        {
            if ((stddevs[i] > 0.0) && (stddevs[j] > 0.0))
            {
                mat[i][j] = mat[i][j] / (stddevs[i] * stddevs[j]);
                matr[i][j] = mat[i][j]; // correlations
            }
        }
        means[i] /= N;
    }
    for (int i = 0; i < notests; i++)
    {
        wvector[i] = tests[i]->Weight;
        matr[i][i] = tests[i]->Reliability;
    }
    double numerator = 0.0;
    double denominator = 0.0;
    double reliability = 0.0;
    for (int j = 0; j < notests; j++) // matrix column index
    {
        LeftProd[j] = 0.0;
        for (int i = 0; i < notests; i++) // row and weight index
        {
            LeftProd[j] += (wvector[i] * matr[i][j]);
        }
    }
    for (int i = 0; i < notests; i++) numerator += (LeftProd[i] * wvector[i]);
    for (int j = 0; j < notests; j++)
    {
        LeftProd[j] = 0.0;
        for (int i = 0; i < notests; i++)
        {
            LeftProd[j] += (wvector[i] * mat[i][j]);
        }
    }
    for (int i = 0; i < notests; i++) denominator += (LeftProd[i] * wvector[i]);
    reliability = numerator / denominator;

    // now show results
    FrmOutPut->RichOutPut->Lines->Clear();
    sprintf(outline,"COMPOSITE TEST RELIABILITY FOR %d TESTS",notests);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("CORRELATION AMONG TESTS MATRIX");
    int first = 0;
    int last = notests;
    if (notests > 7) last = 7;
    strcpy(outline,"          ");
    while (!done)
    {
        for (int i = first; i < last; i++) // do column headings
        {
            int col = 6 + (i * 4); // raw score position for test i's title
            sprintf(cellstring,"%10s",Grid->Cells[col][0].c_str());
            strcat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (int i = 0; i < notests; i++) // matrix rows
        {
            strcpy(outline,"");
            int col = 6 + (i * 4);
            sprintf(cellstring,"%-10s",Grid->Cells[col][0].c_str());
            strcat(outline,cellstring);
            for (int j = first; j < last; j++) // matrix columns
            {
                sprintf(cellstring,"%10.3f",mat[i][j]);
                strcat(outline,cellstring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        strcpy(outline,"MEANS     ");
        for (int i = first; i < last; i++)
        {
            sprintf(cellstring,"%10.3f",means[i]);
            strcat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"STD. DEVS.");
        for (int i = first; i < last; i++)
        {
            sprintf(cellstring,"%10.3f",stddevs[i]);
            strcat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (last == notests) done = true;
        else
        {
            first = last + 1;
            last = first + 7;
            if (last > notests) last = notests;
        }
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"COMPOSITE RELIABILITY = %6.3f",reliability);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // clean up the heap
    delete[] LeftProd;
    delete[] wvector;
    delete[] stddevs;
    delete[] means;
    for (int i = 0; i < notests; i++) delete[] matr[i];
    delete[] matr;
    for (int i = 0; i < notests; i++) delete[] mat[i];
    delete[] mat;
}
//------------------------------------------------------------------------




