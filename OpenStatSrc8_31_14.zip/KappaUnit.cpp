//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "OutPut.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "functions.h"

#include "KappaUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKappaForm *KappaForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TKappaForm::TKappaForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKappaForm::ResetBtnClick(TObject *Sender)
{
     int i;

     CatIn->Visible = true;
     CatOut->Visible = false;
     ObjIn->Visible = true;
     ObjOut->Visible = false;
     RaterIn->Visible = true;
     RaterOut->Visible = false;
     CatEdit->Text = "";
     ObjectEdit->Text = "";
     RaterEdit->Text = "";
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
          VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------


void __fastcall TKappaForm::CatInClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     CatEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     CatIn->Visible = false;
     CatOut->Visible = true;    
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::CatOutClick(TObject *Sender)
{
     VarList->Items->Add(CatEdit->Text);
     CatEdit->Text = "";
     CatIn->Visible = true;
     CatOut->Visible = false;    
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::ObjInClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     ObjectEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ObjIn->Visible = false;
     ObjOut->Visible = true;    
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::ObjOutClick(TObject *Sender)
{
     VarList->Items->Add(ObjectEdit->Text);
     ObjectEdit->Text = "";
     ObjIn->Visible = true;
     ObjOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::RaterInClick(TObject *Sender)
{
     int index = VarList->ItemIndex;

     RaterEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RaterIn->Visible = false;
     RaterOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::RaterOutClick(TObject *Sender)
{
     VarList->Items->Add(RaterEdit->Text);
     RaterEdit->Text = "";
     RaterIn->Visible = true;
     RaterOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TKappaForm::ComputeBtnClick(TObject *Sender)
{
     int CatCol=0, ObjCol=0, RaterCol=0;
     int value, rater, category, object;
     int ***R;
     int frequency;
     double pobs, pchance, kappa, num, denom, partial_pchance, a_priori;
     double *average_frequency;
     char outline[131], astring[21];
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Generalized Kappa Coefficient Procedure");
     FrmOutPut->RichOutPut->Lines->Add("adapted from the program written by Giovanni Flammia");
     FrmOutPut->RichOutPut->Lines->Add("copywritten 1995, M.I.T. Lab. for Computer Science");
     FrmOutPut->RichOutPut->Lines->Add("");

     // get columns for the variables
     for (int i = 0; i < NoVariables; i++)
     {
         if (MainForm->Grid->Cells[i+1][0] == CatEdit->Text) CatCol = i+1;
         if (MainForm->Grid->Cells[i+1][0] == RaterEdit->Text) RaterCol = i+1;
         if (MainForm->Grid->Cells[i+1][0] == ObjectEdit->Text) ObjCol = i+1;
     }
     if ((CatCol == 0) || (RaterCol == 0) || (ObjCol == 0))
     {
         ShowMessage("ERROR!  One or more variables not defined.");
         return;
     }
/*
     // check variable type
     result = VarTypeChk(CatCol,1);
     if (result == 1) return;
     result = VarTypeChk(RaterCol,1);
     if (result == 1) return;
     result = VarTypeChk(ObjCol,1);
     if (result == 1) return;
*/
     // get max no of codes for objects, raters, categories
     NoCats = 0;
     NoObjects = 0;
     NoRaters = 0;
     for (int i = 0; i < NoCases; i++)
     {
         value = floor(StrToFloat(MainForm->Grid->Cells[CatCol][i+1]));
         //result = GetValue(i+1,CatCol,intvalue,dblvalue,strvalue);
         //if (result == 1) value = 0;
         //else value = intvalue;
         if (value > NoCats) NoCats = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[ObjCol][i+1]));
         //result = GetValue(i+1,ObjCol,intvalue,dblvalue,strvalue);
         //if (result == 1) value = 0;
         //else value = intvalue;
         if (value > NoObjects) NoObjects = value;
         value = floor(StrToFloat(MainForm->Grid->Cells[RaterCol][i+1]));
         //result = GetValue(i+1,RaterCol,intvalue,dblvalue,strvalue);
         //if (result == 1) value = 0;
         //else value = intvalue;
         if (value > NoRaters) NoRaters = value;
     }

     sprintf(outline,"%d Raters using %d Categories to rate %d Objects",
         NoRaters, NoCats, NoObjects);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");

     // get memory for R and set to zero
     GetIntCubeMem(R,NoRaters,NoCats,NoObjects);
     for (int i = 0; i < NoRaters; i++)
     {
         for (int k = 0; k < NoCats; k++)
         {
             for (int l = 0; l < NoObjects; l++)
             {
                 R[i][k][l] = 0;
             }
         }
     }

     // get memory for average_frequency
     GetDblVecMem(average_frequency,NoCats);
     for (int k = 0; k < NoCats; k++) average_frequency[k] = 0.0;

     // read data and store in R
     for (int i = 0; i < NoCases; i++)
     {
         rater = floor(StrToFloat(MainForm->Grid->Cells[RaterCol][i+1]));
         object = floor(StrToFloat(MainForm->Grid->Cells[ObjCol][i+1]));
         category = floor(StrToFloat(MainForm->Grid->Cells[CatCol][i+1]));
         R[rater-1][category-1][object-1] = 1;
     }

     //compute chance probability of agreement pchance for all raters
     pchance = 0.0;
     denom = compute_denom(R);
     for (int i = 0; i < NoRaters; i++)
     {
         for (int j = 0; j < NoRaters; j++)
         {
             if (i != j)
             {
                partial_pchance = compute_partial_pchance(R,i,j,denom);
                pchance += partial_pchance;
             }
         }
         for (int k = 0; k < NoCats; k++)
         {
             frequency = 0;
             for (int l = 0; l < NoObjects; l++)
             {
                 frequency += R[i][k][l];
             }
             a_priori = (double) frequency / (double) NoObjects;
             sprintf(outline,"Frequency[%d][%d] = %f",i+1,k+1,a_priori);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
     }

     for (int k = 0; k < NoCats; k++)
     {
         for (int l = 0; l < NoObjects; l++)
         {
             for (int i = 0; i < NoRaters; i++)
             {
                 average_frequency[k] += R[i][k][l];
             }
         }
     }

     for (int k = 0; k < NoCats; k++)
     {
         average_frequency[k] = average_frequency[k] /
             ((double)NoObjects * (double)NoRaters);
         sprintf(outline,"Average_Frequency[%d] = %f",k+1,average_frequency[k]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"PChance = %f",pchance);
     FrmOutPut->RichOutPut->Lines->Add(outline);

     // compute observed probability of agreement among all raters
     num = 0.0;
     for (int k = 0; k < NoCats; k++)
     {
         for (int l = 0; l < NoObjects; l++)
         {
             num += compute_partial_pobs(R,k,l);
         }
     }
     if (denom > 0.0) pobs = num / denom;
     else pobs = 0.0;
     sprintf(outline,"PObs = %f",pobs);
     FrmOutPut->RichOutPut->Lines->Add(outline);

     kappa = (pobs - pchance) / (1.0 - pchance);
     sprintf(outline,"Kappa = %f",kappa);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     double z = KappaVariance(R,NoObjects,NoRaters,NoCats);
     if (z > 0.0) z = kappa / sqrt(z);
//     double z = kappa / sqrt(KappaVariance(R,NoObjects,NoRaters,NoCats));
     sprintf(outline,"z for Kappa = %8.3f with probability > %8.3f",z,1.0-probz(z));
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();

     // clean up space allocated
     delete[] average_frequency;
     ClearIntCubeMem(R,NoRaters,NoCats);
}
//---------------------------------------------------------------------------

double TKappaForm::compute_term1(int ***R, int i, int j, int k)
{
  int ii,jj;         /* range over 0 .. num_coders-1 */
  int kk;            /* range over 0 .. num_categories-1 */
  int l,ll;          /* range over 0 .. num_points-1 */
  int denom_i=0;
  int denom_j=0;
  int num_i=0;
  int num_j=0;

  for(int kk = 0; kk < NoCats; kk++) {
    for(int ll = 0; ll < NoObjects; ll++) {
      denom_i += R[i][kk][ll];
      denom_j += R[j][kk][ll];
    }
  }

  for(int l = 0;l < NoObjects; l++) {
    num_i += R[i][k][l];
    num_j += R[j][k][l];
  }

  return(((double)num_i/(double)denom_i)*((double)num_j/(double)denom_j));
}
//---------------------------------------------------------------------------

double TKappaForm::compute_term2(int ***R, int i, int j, int l)
{
  int sum_i=0;
  int sum_j=0;

  for(int k =0; k < NoCats; k++)
  {
    sum_i += R[i][k][l];
    sum_j += R[j][k][l];
  }

  return( (double)sum_i * (double)sum_j );
}
//---------------------------------------------------------------------------

double TKappaForm::compute_denom(int ***R)
{
  int     *sum;
  double  result=0;

  GetIntVecMem(sum,NoObjects); //  sum = (int *)calloc(num_points,sizeof(int));
  for (int l = 0; l < NoObjects ;l++)
  {
    sum[l] = 0;
    for(int i = 0 ;i < NoRaters ;i++)
    {
      for(int k = 0 ;k < NoCats ;k++)
      {
         sum[l] += R[i][k][l];
      }
    }
  }
  for (int l = 0; l < NoObjects ;l++)
  {
    result += (double)sum[l] * (double)( sum[l] - 1);
  }
  delete[] sum;
  return( result );
}
//---------------------------------------------------------------------------

double TKappaForm::compute_partial_pchance(int ***R, int i, int j, double denom)
{
  double term1=0;
  double term2=0;

  for(int k = 0 ; k < NoCats ;k++)
  {
    term1 += compute_term1(R,i,j,k);
  }

  for(int l = 0; l < NoObjects ; l++)
  {
    term2 += compute_term2(R,i,j,l);
  }
  if (denom > 0.0) return( term1 * ( term2 / denom ) );
  else return (0.0);
}
//---------------------------------------------------------------------------

double TKappaForm::compute_partial_pobs(int ***R, int k, int l)
{
  int sum=0;

  for (int i = 0 ; i < NoRaters ; i++)
  {
    sum += R[i][k][l];
  }

  return( (double)sum * (double)(sum - 1) );
}
//---------------------------------------------------------------------------



void __fastcall TKappaForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

double TKappaForm::KappaVariance(int ***R,int n, int m, int K)
{
       // calculates the variance of Kappa
       // R contains 1's or 0's for raters, categories and objects (row, col, slice)
       // m is number of raters
       // n is number of subjects
       // K is the number of categories

       double xij; // rating by a rater of subject in category
       double*pj; // proportion in category k
       double variance; // calculated variance of Kappa
       double term1 = 0.0, term2 = 0.0;
       int i, j, k;

       GetDblVecMem(pj,K);
       for (j = 0; j < K; j++) pj[j] = 0.0;

       // get proportion of values in each category
       for (j = 0; j < K; j++) // accross categories
       {
           xij = 0.0;
           for (i = 0; i < m; i++) // accross raters
           {
               for (k = 0; k < n; k++) // accross objects
               {
                   xij += (double) R[i][j][k];
               }
           }
           pj[j] += xij;
       }
       for (j = 0; j < K; j++) pj[j] /= (double) (n * m);
       for (j = 0; j < K; j++)
       {
           term1 += (pj[j] * (1.0 - pj[j]));
           term2 += (pj[j] * (1.0 - pj[j]) * (1.0 - 2.0*pj[j]));
       }
       term1 = term1 * term1;
       if ((term1 > 0) && (term2 > 0))
           variance = (2.0 / (n * m * (m-1) * term1)) * (term1 - term2);
       else variance = 0.0;
       delete[] pj;
       return (variance);
}
