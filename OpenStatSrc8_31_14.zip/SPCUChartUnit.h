//---------------------------------------------------------------------------

#ifndef SPCUChartUnitH
#define SPCUChartUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TSPCUChartForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label3;
     TEdit *MeasEdit;
     TRadioGroup *SigmaOpts;
     TEdit *SigmaEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TGroupBox *GroupBox2;
     TEdit *NEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall VarListClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean,
                             TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TSPCUChartForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSPCUChartForm *SPCUChartForm;
//---------------------------------------------------------------------------
#endif
