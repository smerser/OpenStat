//---------------------------------------------------------------------------
#ifndef ChiSqrH
#define ChiSqrH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TChiSFrm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
     TListBox *VarList;
    TLabel *Label2;
    TLabel *Label3;
     TEdit *RowEdit;
     TEdit *ColEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
     TButton *ReturnBtn;
     TLabel *Label4;
     TEdit *DepEdit;
     TRadioGroup *InputGroup;
     TButton *ComputeBtn;
     TLabel *Label5;
     TEdit *NCasesEdit;
     TBitBtn *RowIn;
     TBitBtn *RowOut;
     TBitBtn *ColIn;
     TBitBtn *ColOut;
     TBitBtn *DepIn;
     TBitBtn *DepOut;
     TGroupBox *GroupBox1;
     TCheckBox *ObsChk;
     TCheckBox *ExpChk;
     TCheckBox *PropChk;
     TCheckBox *ChiChk;
     TCheckBox *YatesChk;
     TCheckBox *SaveChk;
    void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall InputGroupClick(TObject *Sender);
     void __fastcall RowInClick(TObject *Sender);
     void __fastcall RowOutClick(TObject *Sender);
     void __fastcall ColInClick(TObject *Sender);
     void __fastcall ColOutClick(TObject *Sender);
     void __fastcall DepInClick(TObject *Sender);
     void __fastcall DepOutClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TChiSFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TChiSFrm *ChiSFrm;
//---------------------------------------------------------------------------
#endif
