//---------------------------------------------------------------------------

#ifndef NestedABUnitH
#define NestedABUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TNestedABForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *VarList;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *FactorAEdit;
    TEdit *FactorBEdit;
    TBitBtn *AInBtn;
    TBitBtn *AOutBtn;
    TBitBtn *BInBtn;
    TBitBtn *BOutBtn;
    TRadioGroup *OptionsBox;
    TMemo *Memo1;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TLabel *Label4;
    TEdit *DepEdit;
    TBitBtn *DepInBtn;
    TBitBtn *DepOutBtn;
    TCheckBox *RandomBChk;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall GetVars(TObject *Sender);
    void __fastcall GetMemory(TObject *Sender);
    void __fastcall GetSums(TObject *Sender);
    void __fastcall AInBtnClick(TObject *Sender);
    void __fastcall BInBtnClick(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall AOutBtnClick(TObject *Sender);
    void __fastcall BOutBtnClick(TObject *Sender);
    void __fastcall DepOutBtnClick(TObject *Sender);
    void __fastcall ShowMeans(TObject *Sender);
    void __fastcall GetResults(TObject *Sender);
    void __fastcall ShowResults(TObject *Sender);
    void __fastcall ReleaseMemory(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall TwoWayPlot(TObject *Sender);
    
private:	// User declarations
    AnsiString DepVar, FactorA, FactorB;
    double SSTot, SumSqrTot, SSA, SumSqrA, SSB, SumSqrB, YValue, TotMean;
    double SSW, MSA, MSB, MSW, MSTot;
    double **SS, **SumSqr, **CellMeans, **CellSDs;
    double *ASS, *BSS, *ASumSqr, *BSumSqr, *AMeans, *BMeans, *ASDs;
    int ACol, BCol, YCol, NoALevels, MinA, MaxA, MinB, MaxB, AValue, BValue;
    int NoBLevels, TotN, celln, dfA, dfBwA, dfwcell, dftotal;
    int **CellCount, *ACount, *BCount;

public:		// User declarations
    __fastcall TNestedABForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TNestedABForm *NestedABForm;
//---------------------------------------------------------------------------
#endif
