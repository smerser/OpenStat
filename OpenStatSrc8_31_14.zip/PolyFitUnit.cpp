//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PolyFitUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPolyRegFitFrm *PolyRegFitFrm;
//---------------------------------------------------------------------------
__fastcall TPolyRegFitFrm::TPolyRegFitFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
