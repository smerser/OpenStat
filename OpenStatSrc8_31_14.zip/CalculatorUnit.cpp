//---------------------------------------------------------------------------

#include <vcl.h>
#include "math.h"
#include "math.hpp"
#pragma hdrstop

#include "CalculatorUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCalculatorForm *CalculatorForm;
//---------------------------------------------------------------------------
__fastcall TCalculatorForm::TCalculatorForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::FormShow(TObject *Sender)
{
        ResultEdit->Text = "";
        MemoryEdit->Text = "";
        ValueEdit->Text = "";
        Result = 0.0;
        Memory = 0.0;
        Value = 0.0;
        Radians = true;
        BtnRadDeg->Caption = "Radians";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn7Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "7";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn8Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "8";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn9Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "9";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn4Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "4";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn5Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "5";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn6Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "6";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn1Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "1";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn2Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "2";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn3Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "3";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::Btn0Click(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + "0";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnPeriodClick(TObject *Sender)
{
        ValueEdit->Text = ValueEdit->Text + ".";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnMemInClick(TObject *Sender)
{
        Memory = Memory + StrToFloat(ValueEdit->Text);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnMemOutClick(TObject *Sender)
{
        ValueEdit->Text = FloatToStr(Memory);
        Memory = 0.0;
        MemoryEdit->Text = "0.0";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnChangeSignClick(TObject *Sender)
{
        ValueEdit->Text = "-" + ValueEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnPlusClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Result = Result + StrToFloat(ValueEdit->Text);
        else Result = Result + Result;
        ResultEdit->Text = FloatToStr(Result);
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnMinusClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Result = Result - StrToFloat(ValueEdit->Text);
        else Result = Result - Result;
        ResultEdit->Text = FloatToStr(Result);
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnTimesClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Result = Result * StrToFloat(ValueEdit->Text);
        else Result = Result * Result;
        ResultEdit->Text = FloatToStr(Result);
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnDivideClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Result = Result / StrToFloat(ValueEdit->Text);
        else Result = Result / Result;
        ResultEdit->Text = FloatToStr(Result);
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnSqrtClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = sqrt(Value);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnTanClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        if (Radians) Value = tan(Value);
        else // first convert degrees to radians and then compute
        {
                Value = DegToRad(Value);
                Value = tan(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnNatLogClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = log(Value);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnArcSinClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = asin(Value);
        if (!Radians) // convert Value to degrees from radians
        {
                Value = RadToDeg(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnLog10Click(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = log10(Value);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnArcCosClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = acos(Value);
        if (!Radians) // convert Value to degrees from radians
        {
                Value = RadToDeg(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnExpClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = exp(Value);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnArcTanClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = atan(Value);
        if (!Radians) // convert Value to degrees from radians
        {
                Value = RadToDeg(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnExpBase10Click(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = pow(10.0,Value);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnRecipClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = 1.0 / Value;
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnSinClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        if (Radians) Value = sin(Value);
        else // first convert degrees to radians and then compute
        {
                Value = DegToRad(Value);
                Value = sin(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnClearClick(TObject *Sender)
{
        MemoryEdit->Text = "0.0";
        Memory = 0.0;}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnCosClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        if (Radians) Value = cos(Value);
        else // first convert degrees to radians and then compute
        {
                Value = DegToRad(Value);
                Value = cos(Value);
        }
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------
void __fastcall TCalculatorForm::BtnPiClick(TObject *Sender)
{
        Value = M_PI;
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtneClick(TObject *Sender)
{
        Value = exp(1.0);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnClrValClick(TObject *Sender)
{
        Value = 0.0;
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnClrResClick(TObject *Sender)
{
        Result = 0.0;
        ResultEdit->Text = "0.0";
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnRadDegClick(TObject *Sender)
{
        if (Radians)
        {
                Radians = false;
                BtnRadDeg->Caption = "Degrees";
        }
        else
        {
                Radians = true;
                BtnRadDeg->Caption = "Radians";
        }
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnSquareClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Value = Value * Value;
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnPowClick(TObject *Sender)
{
        AnsiString Response;
        double Y;

        if (ValueEdit->Text != "") Value = StrToFloat(ValueEdit->Text);
        else Value = Result;
        Response =  InputBox("Raise to Y","Y","");
        Y = StrToFloat(Response);
        if (Y != 0.0) Value = pow(Value,Y);
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnCSCClick(TObject *Sender)
{
        BtnSinClick(this);
        if (Value != 0.0) Value = 1.0 / Value;
        ValueEdit->Text = FloatToStr(Value);
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnSECClick(TObject *Sender)
{
        BtnCosClick(this);
        if (Value != 0.0) Value = 1.0 / Value;
        ValueEdit->Text = FloatToStr(Value);        
}
//---------------------------------------------------------------------------

void __fastcall TCalculatorForm::BtnCOTClick(TObject *Sender)
{
        BtnTanClick(this);
        if (Value != 0.0) Value = 1.0 / Value;
        ValueEdit->Text = FloatToStr(Value);        
}
//---------------------------------------------------------------------------


void __fastcall TCalculatorForm::BtnEqualClick(TObject *Sender)
{
        if (ValueEdit->Text != "") Result = StrToFloat(ValueEdit->Text);
        ResultEdit->Text = FloatToStr(Result);
        ValueEdit->Text = "";
}
//---------------------------------------------------------------------------


