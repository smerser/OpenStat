//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <stdio.h>
#include "MemMgrUnit.h"
//#include "PlotUnit.h"

#include "KMEANSUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKMEANSForm *KMEANSForm;
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TKMEANSForm::TKMEANSForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKMEANSForm::FormShow(TObject *Sender)
{
     AnsiString cellstring;
     
     ListBox1->Clear();
     ListBox2->Clear();
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         ListBox1->Items->Add(cellstring);
     }
     RepChkBox->Checked = false;
     StdChkBox->Checked = true;
     VarOutBtn->Enabled = false;
     DescChkBox->Checked = false;
     NoClustersEdit->Text = "";
     ItersEdit->Text = "100";
}
//---------------------------------------------------------------------------

void __fastcall TKMEANSForm::OKBtnClick(TObject *Sender)
{
     int Ncols = ListBox2->Items->Count;
     if (Ncols <= 0)
     {
        ShowMessage("ERROR!  No variables selected to cluster.");
        return;
     }

     int N = Ncols;
     int M = NoCases;
     int K = atoi(NoClustersEdit->Text.c_str());
     int *IC1, *IC2, *NC, *NCP, *ITRAN, *LIVE;
     int *ColSelected;
     int IFAULT = 0;
     int ITER = atoi(ItersEdit->Text.c_str());
     double **A, *D, **C, *AN1, *AN2, *WSS, *DT;
     char outline[201];
     char strval[21];
     AnsiString *varlabels, *rowlabels;
     AnsiString cellstring;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     varlabels = new AnsiString[Ncols];
     rowlabels = new AnsiString[NoCases];
     ColSelected = new int[Ncols];
     GetDblMatMem(A,M+1,N+1);
     GetDblMatMem(C,K+1,N+1);
     D = new double[M+1];
     AN1 = new double[K+1];
     AN2 = new double[K+1];
     WSS = new double[K+1];
     DT = new double[3];
     IC1 = new int[M+1];
     IC2 = new int[M+1];
     NC = new int[K+1];
     NCP = new int[K+1];
     ITRAN = new int[K+1];
     LIVE = new int[K+1];

     if (K <= 0)
     {
        ShowMessage("ERROR! You must enter the desired number of clusters.");
        goto cleanup;
     }

     // initialize arrays
     for (int i = 1; i <= K; i++)
     {
         AN1[i] = 0.0;
         AN2[i] = 0.0;
         WSS[i] = 0.0;
         NC[i] = 0;
         NCP[i] = 0;
         ITRAN[i] = 0;
         LIVE[i] = 0;
         for (int j = 1; j <= N; j++) C[i][j] = 0.0;
     }
     for (int i = 1; i <= M; i++)
     {
         IC1[i] = 0;
         IC2[i] = 0;
         D[i] = 0.0;
     }

     //Get labels and columns of selected variables
     for (int i = 0; i < Ncols; i++)
     {
        cellstring = ListBox2->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
        {
            if (cellstring == MainForm->Grid->Cells[j+1][0])
            {
                varlabels[i] = cellstring;
                ColSelected[i] = j+1;
                //result = VarTypeChk(j+1,0);
                //if (result == 1) goto cleanup;
            }
        }
     }

     // Get labels of rows
     for (int i = 0; i < NoCases; i++) rowlabels[i] = MainForm->Grid->Cells[0][i+1];

     // read the data
     for (int i = 1; i <= M; i++)
     {
         if (!ValidRecord(i+1,ColSelected,N)) continue;
         for (int j = 1; j <= N; j++)
         {
             int col = ColSelected[j-1];
             A[i][j] = StrToFloat(MainForm->Grid->Cells[col][i]);
             //result = GetValue(i,col,intvalue,dblvalue,strvalue);
             //if (result == 1) A[i][j] = 0.0;
             //else A[i][j] = dblvalue;
         }
     }

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("K-Means Clustering.  Adapted from AS 136  APPL. STATIST. (1979) VOL.28, NO.1");
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"File = %s",MainForm->FileNameEdit->Text.c_str());
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"No. Cases = %d, No. Variables = %d, No. Clusters = %d",M,N,K);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");

     // transform to z scores if needed
     if (StdChkBox->Checked == true)
     {
        for (int j = 1; j <= N; j++)
        {
            double Mean = 0.0;
            double stddev = 0.0;
            for (int i = 1; i <= M; i++)
            {
                Mean += A[i][j];
                stddev += A[i][j] * A[i][j];
            }
            stddev = stddev - Mean * Mean / M;
            stddev /= (M - 1);
            Mean /= M;
            if (DescChkBox->Checked)
            {
               sprintf(outline,"Mean = %8.3f, Std.Dev. = %8.3f for %s",Mean,stddev,varlabels[j-1]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
            }
            for (int i = 1; i <= M; i++)
            {
                A[i][j] = (A[i][j] - Mean) / stddev;
                if (RepChkBox->Checked == true)
                {
                   int col = ColSelected[j-1];
                   sprintf(outline,"%8.5f",A[i][j]);
                   MainForm->Grid->Cells[col][i] = outline;
                }
            }
        }
     }

     // Now enter initial points
     for (int L = 1; L <= K; L++)
     {
         int center = 1 + (L-1) * (M / K); // initial cluster center
         for (int j = 1; j <= N; j++) C[L][j] = A[center][j];
     }

     // do analysis
     KMNS(A,M,N,C,K,IC1,IC2,NC,AN1,AN2,NCP,D,ITRAN,LIVE,ITER,WSS,IFAULT);

     // show results

     // sort subjects by cluster
     for (int i = 1; i <= M; i++) IC2[i] = i; // store ids in here
     for (int i = 1; i < M; i++)
     {
         for (int j = i+1; j <= M; j++)
         {
             if (IC1[i] > IC1[j]) // swap these clusters and ids
             {
                int itemp = IC1[i];
                IC1[i] = IC1[j];
                IC1[j] = itemp;
                itemp = IC2[i];
                IC2[i] = IC2[j];
                IC2[j] = itemp;
             }
         }
     }

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("NUMBER OF SUBJECTS IN EACH CLUSTER");
     for (int i = 1; i <= K; i++)
     {
         sprintf(outline,"Cluster = %d with %d cases.",i,NC[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("PLACEMENT OF SUBJECTS IN CLUSTERS");
     FrmOutPut->RichOutPut->Lines->Add("CLUSTER SUBJECT");
     for (int i = 1; i <= M; i++)
     {
         sprintf(outline,"   %3d    %3d",IC1[i],IC2[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("AVERAGE VARIABLE VALUES BY CLUSTER");
     strcpy(outline,"               VARIABLES");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     strcpy(outline,"CLUSTER");
     for (int j = 1; j <= N; j++)
     {
         sprintf(strval,"  %3d ",j);
         strcat(outline,strval);
     }
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("       ");
     for (int i = 1; i <= K; i++)
     {
         sprintf(outline,"   %3d ",i);
         for (int j = 1; j <= N; j++)
         {
             sprintf(strval,"%5.2f ",C[i][j]);
             strcat(outline,strval);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("WITHIN CLUSTER SUMS OF SQUARES");
     for (int i = 1; i <= K; i++)
     {
         sprintf(outline,"Cluster %d = %6.3f",i,WSS[i]);
         FrmOutPut->RichOutPut->Lines->Add(outline);
     }

     FrmOutPut->ShowModal();

     // cleanup
cleanup:
     delete[] LIVE;
     delete[] ITRAN;
     delete[] NCP;
     delete[] NC;
     delete[] IC2;
     delete[] IC1;
     delete[] DT;
     delete[] WSS;
     delete[] AN2;
     delete[] AN1;
     delete[] D;
     ClearDblMatMem(C,K+1);
     ClearDblMatMem(A,M+1);
     delete[] ColSelected;
     delete[] rowlabels;
     delete[] varlabels;
}
//---------------------------------------------------------------------------

void TKMEANSForm::KMNS(double **A, int M, int N, double **C, int K, int *IC1,
                       int *IC2, int *NC, double *AN1, double *AN2, int *NCP,
                       double *D, int *ITRAN, int *LIVE, int ITER, double *WSS,
                       int IFAULT)
{
      //      SUBROUTINE KMNS(A, M, N, C, K, IC1, IC2, NC, AN1, AN2, NCP, D,
      //     *    ITRAN, LIVE, ITER, WSS, IFAULT)
      //
      //     ALGORITHM AS 136  APPL. STATIST. (1979) VOL.28, NO.1
      //     Divide M points in N-dimensional space into K clusters so that
      //     the within cluster sum of squares is minimized.
      //
      //      INTEGER IC1(M), IC2(M), NC(K), NCP(K), ITRAN(K), LIVE(K)
      //      REAL    A(M,N), D(M), C(K,N), AN1(K), AN2(K), WSS(K), DT(2)
      //      REAL    ZERO, ONE
      //
      //     Define BIG to be a very large positive number
      //
      //      DATA BIG /1.E30/, ZERO /0.0/, ONE /1.0/
      //
      double DT[2];
      double BIG = 1.0e30;
      double ZERO = 0.0;
      double ONE = 1.0;
      double DA, DB, DC, TEMP, AA;
      int L, II, INDX;

      IFAULT = 3;
      if ((K <= 1) || (K >= M))
      {
         ShowMessage("The no. of clusters must be less than the no. of variables.");
         return;
      }

      //     For each point I, find its two closest centres, IC1(I) and
      //     IC2(I).     Assign it to IC1(I).
      //
      for (int I = 1; I <= M; I++) //DO 50 I = 1, M  (each subject)
      {
	      IC1[I] = 1;
	      IC2[I] = 2;
	      for (int IL = 1; IL <= 2; IL++) //DO 10 IL = 1, 2 (initial cluster comparisons)
          {
	          DT[IL] = ZERO;
	          for (int J = 1; J <= N; J++) //DO 10 J = 1, N (variables)
              {
	              DA = A[I][J] - C[IL][J];
	              DT[IL] = DT[IL] + (DA * DA); //(squared difference for this comparison)
              } // 10   CONTINUE
          } // 10 CONTINUE
	      if (DT[1] > DT[2]) // THEN swap
          {
	          IC1[I] = 2;
	          IC2[I] = 1;
	          TEMP = DT[1];
	          DT[1] = DT[2];
	          DT[2] = TEMP;
          } // END IF
	      for (int L = 3; L <= K; L++) // DO 50 L = 3, K  (remaining clusters)
          {
	          DB = ZERO;
	          for (int J = 1; J <= N; J++) // DO 30 J = 1, N (variables)
              {
	              DC = A[I][J] - C[L][J];
	              DB = DB + DC * DC;
	              if (DB >= DT[2]) goto cont50; // GO TO 50 (next case)
              } //30     CONTINUE
	          if (DB < DT[1]) goto cont40; // GO TO 40
	          DT[2] = DB;
	          IC2[I] = L;
	          goto cont50; // GO TO 50 (next case)
cont40:
              DT[2] = DT[1]; // 40
	          IC2[I] = IC1[I];
	          DT[1] = DB;
	          IC1[I] = L;
cont50:
          }
      } // 50 CONTINUE (next case)

      //     Update cluster centres to be the average of points contained
      //     within them.
      //
      for (int L = 1; L <= K; L++) // DO 70 L = 1, K  (clusters)
      {
	      NC[L] = 0;
	      for (int J = 1; J <= N; J++) C[L][J] = ZERO;  //(initialize clusters)
      } // 70 CONTINUE
      for (int I = 1; I <= M; I++) // DO 90 I = 1, M  (subjects)
      {
	      L = IC1[I];  // which cluster the Ith case is in
	      NC[L] = NC[L] + 1; // no. in the cluster L
	      for (int J = 1; J <= N; J++) C[L][J] = C[L][J] + A[I][J]; // sum of var. values in the cluster L
      } // 90 CONTINUE

      //     Check to see if there is any empty cluster at this stage
      //
      for (int L = 1; L <= K; L++) // DO 120 L = 1, K
      {
          if (NC[L] == 0)
          {
	          IFAULT = 1;
              return; // RETURN
          } // END IF
	      AA = NC[L];
	      for (int J = 1; J <= N; J++) C[L][J] = C[L][J] / AA; // average the values in the cluster

          //     Initialize AN1, AN2, ITRAN & NCP
          //     AN1(L) = NC(L) / (NC(L) - 1)
          //     AN2(L) = NC(L) / (NC(L) + 1)
          //     ITRAN(L) = 1 if cluster L is updated in the quick-transfer stage,
          //              = 0 otherwise
          //     In the optimal-transfer stage, NCP(L) stores the step at which
          //     cluster L is last updated.
          //     In the quick-transfer stage, NCP(L) stores the step at which
          //     cluster L is last updated plus M.
          //
	      AN2[L] = AA / (AA + ONE);
	      AN1[L] = BIG;
	      if (AA > ONE) AN1[L] = AA / (AA - ONE);
	      ITRAN[L] = 1;
	      NCP[L] = -1;
      }  // 120 CONTINUE
      INDX = 0;
      for (int IJ = 1; IJ <= ITER; IJ++) //DO 140 IJ = 1, ITER
      {
          //
          //     In this stage, there is only one pass through the data.   Each
          //     point is re-allocated, if necessary, to the cluster that will
          //     induce the maximum reduction in within-cluster sum of squares.
          //
	      OPTRA(A, M, N, C, K, IC1, IC2, NC, AN1, AN2, NCP, D, ITRAN, LIVE, INDX);
          //
          //     Stop if no transfer took place in the last M optimal transfer
          //     steps.
          //
	      if (INDX == M) goto cont150; // GO TO 150
          //
          //     Each point is tested in turn to see if it should be re-allocated
          //     to the cluster to which it is most likely to be transferred,
          //     IC2(I), from its present cluster, IC1(I).   Loop through the
          //     data until no further change is to take place.
          //
	      QTRAN(A, M, N, C, K, IC1, IC2, NC, AN1, AN2, NCP, D, ITRAN, INDX);
          //
          //     If there are only two clusters, there is no need to re-enter the
          //     optimal transfer stage.
          //
	      if (K == 2) goto cont150; // GO TO 150
          //
          //     NCP has to be set to 0 before entering OPTRA.
          //
	      for (int L = 1; L <= K; L++) NCP[L] = 0;
      } // 140 CONTINUE
      //
      //     Since the specified number of iterations has been exceeded, set
      //     IFAULT = 2.   This may indicate unforeseen looping.
      //
      IFAULT = 2;
      //
      //     Compute within-cluster sum of squares for each cluster.
      //
cont150:
      for (int L = 1; L <= K; L++) // DO 160 L = 1, K
      {
	      WSS[L] = ZERO;
	      for (int J = 1; J <= N; J++) C[L][J] = ZERO;
      } // 160 CONTINUE
      for (int I = 1; I <= M; I++) // DO 170 I = 1, M
      {
	      II = IC1[I];
	      for (int J = 1; J <= N; J++) C[II][J] = C[II][J] + A[I][J];
      } // 170 CONTINUE
      for (int J = 1; J <= N; J++) // DO 190 J = 1, N
      {
	      for (int L = 1; L <= K; L++) C[L][J] = C[L][J] / (double)(NC[L]);
	      for (int I = 1; I <= M; I++) // DO 190 I = 1, M
          {
	          II = IC1[I];
	          DA = A[I][J] - C[II][J];
	          WSS[II] = WSS[II] + DA * DA;
          }
      } // 190 CONTINUE
}
//-------------------------------------------------------------------

void TKMEANSForm::OPTRA(double **A, int M, int N, double **C, int K,
                        int *IC1, int *IC2, int *NC, double *AN1,
                        double *AN2, int *NCP, double *D, int *ITRAN,
                        int *LIVE, int INDX)
{
      //      SUBROUTINE OPTRA(A, M, N, C, K, IC1, IC2, NC, AN1, AN2, NCP, D,
      //     *      ITRAN, LIVE, INDX)
      //
      //     ALGORITHM AS 136.1  APPL. STATIST. (1979) VOL.28, NO.1
      //
      //     This is the optimal transfer stage.
      //
      //     Each point is re-allocated, if necessary, to the cluster that
      //     will induce a maximum reduction in the within-cluster sum of
      //     squares.
      //
      //  INTEGER IC1(M), IC2(M), NC(K), NCP(K), ITRAN(K), LIVE(K)
      //  REAL    A(M,N), D(M), C(K,N), AN1(K), AN2(K), ZERO, ONE
      //
      //     Define BIG to be a very large positive number.
      //
      //  DATA BIG /1.0E30/, ZERO /0.0/, ONE/1.0/
      //
      //     If cluster L is updated in the last quick-transfer stage, it
      //     belongs to the live set throughout this stage.   Otherwise, at
      //     each step, it is not in the live set if it has not been updated
      //     in the last M optimal transfer steps.
      //

      double ZERO = 0.0;
      double ONE = 1.0;
      double BIG = 1.0e30;
      double DE, DF, DD, DC, DB, DA, R2, RR, AL1, AL2, ALT, ALW;
      int L1, L2, LL;

      for (int L = 1; L <= K; L++) // DO 10 L = 1, K
      {
	      if (ITRAN[L] == 1) LIVE[L] = M + 1;
      } // 10 CONTINUE

      for (int I = 1; I <= M; I++) // DO 100 I = 1, M
      {
	      INDX = INDX + 1;
	      L1 = IC1[I];
	      L2 = IC2[I];
	      LL = L2;
          //
          //     If point I is the only member of cluster L1, no transfer.
          //
	      if (NC[L1] == 1) goto cont90; // GO TO 90
          //
          //     If L1 has not yet been updated in this stage, no need to
          //     re-compute D(I).
          //
	      if (NCP[L1] == 0) goto cont30; // GO TO 30
	      DE = ZERO;
	      for (int J = 1; J <= N; J++) // DO 20 J = 1, N
          {
	          DF = A[I][J] - C[L1][J];
	          DE = DE + DF * DF;
          } // 20   CONTINUE
	      D[I] = DE * AN1[L1];
          //
          //     Find the cluster with minimum R2.
          //
cont30:
          DA = ZERO;
	      for (int J = 1; J <= N; J++) //DO 40 J = 1, N
          {
	          DB = A[I][J] - C[L2][J];
	          DA = DA + DB * DB;
          } // 40   CONTINUE
	      R2 = DA * AN2[L2];
	      for (int L = 1; L <= K; L++) // DO 60 L = 1, K
          {
              //
              //     If I >= LIVE(L1), then L1 is not in the live set.   If this is
              //     true, we only need to consider clusters that are in the live set
              //     for possible transfer of point I.   Otherwise, we need to consider
              //     all possible clusters.
              //
	          if ((I >= LIVE[L1]) && (I >= LIVE[L]) || (L == L1) || (L == LL)) goto cont60; // GO TO 60
	          RR = R2 / AN2[L];
	          DC = ZERO;
	          for (int J = 1; J <= N; J++) // DO 50 J = 1, N
              {
	              DD = A[I][J] - C[L][J];
	              DC = DC + DD * DD;
	              if (DC >= RR) goto cont60; // GO TO 60
              } // 50     CONTINUE
	          R2 = DC * AN2[L];
	          L2 = L;
cont60:
          } // 60     CONTINUE
	      if (R2 < D[I]) goto cont70; // GO TO 70
          //
          //     If no transfer is necessary, L2 is the new IC2(I).
          //
	      IC2[I] = L2;
	      goto cont90; // GO TO 90
          //
          //     Update cluster centres, LIVE, NCP, AN1 & AN2 for clusters L1 and
          //     L2, and update IC1(I) & IC2(I).
          //
cont70:
          INDX = 0;
	      LIVE[L1] = M + I;
	      LIVE[L2] = M + I;
	      NCP[L1] = I;
	      NCP[L2] = I;
	      AL1 = NC[L1];
	      ALW = AL1 - ONE;
	      AL2 = NC[L2];
	      ALT = AL2 + ONE;
	      for (int J = 1; J <= N; J++) // DO 80 J = 1, N
          {
	          C[L1][J] = (C[L1][J] * AL1 - A[I][J]) / ALW;
	          C[L2][J] = (C[L2][J] * AL2 + A[I][J]) / ALT;
          } // 80     CONTINUE
	      NC[L1] = NC[L1] - 1;
	      NC[L2] = NC[L2] + 1;
	      AN2[L1] = ALW / AL1;
	      AN1[L1] = BIG;
	      if (ALW > ONE) AN1[L1] = ALW / (ALW - ONE);
	      AN1[L2] = ALT / AL2;
	      AN2[L2] = ALT / (ALT + ONE);
	      IC1[I] = L2;
	      IC2[I] = L1;
cont90:
          // 90   CONTINUE
	      if (INDX == M) return; // RETURN
      } // 100 CONTINUE
      for (int L = 1; L <= K; L++) // DO 110 L = 1, K
      {
          //
          //     ITRAN(L) = 0 before entering QTRAN.   Also, LIVE(L) has to be
          //     decreased by M before re-entering OPTRA.
          //
	      ITRAN[L] = 0;
	      LIVE[L] = LIVE[L] - M;
      } // 110 CONTINUE
}
//-------------------------------------------------------------------

void TKMEANSForm::QTRAN(double **A, int M, int N, double **C, int K, int *IC1,
                        int *IC2, int *NC, double *AN1, double *AN2,
                        int *NCP, double *D, int *ITRAN, int INDX)
{
      //      SUBROUTINE QTRAN(A, M, N, C, K, IC1, IC2, NC, AN1, AN2, NCP, D,
      //     *    ITRAN, INDX)
      //
      //     ALGORITHM AS 136.2  APPL. STATIST. (1979) VOL.28, NO.1
      //
      //     This is the quick transfer stage.
      //     IC1(I) is the cluster which point I belongs to.
      //     IC2(I) is the cluster which point I is most likely to be
      //         transferred to.
      //     For each point I, IC1(I) & IC2(I) are switched, if necessary, to
      //     reduce within-cluster sum of squares.  The cluster centres are
      //     updated after each step.
      //
      // INTEGER IC1(M), IC2(M), NC(K), NCP(K), ITRAN(K)
      // REAL    A(M,N), D(M), C(K,N), AN1(K), AN2(K), ZERO, ONE
      //
      //     Define BIG to be a very large positive number
      //
      // DATA BIG /1.0E30/, ZERO /0.0/, ONE /1.0/
      //
      //     In the optimal transfer stage, NCP(L) indicates the step at which
      //     cluster L is last updated.   In the quick transfer stage, NCP(L)
      //     is equal to the step at which cluster L is last updated plus M.
      //
      double BIG = 1.0e30;
      double ZERO = 0.0;
      double ONE = 1.0;
      double DA, DB, DE, DD, R2, AL1, ALW, AL2, ALT;
      int ICOUN, ISTEP, L1, L2;

      ICOUN = 0;
      ISTEP = 0;
cont10:
      for (int I = 1; I <= M; I++) // DO 70 I = 1, M
      {
	      ICOUN = ICOUN + 1;
	      ISTEP = ISTEP + 1;
	      L1 = IC1[I];
	      L2 = IC2[I];
          //
          //     If point I is the only member of cluster L1, no transfer.
          //
	      if (NC[L1] == 1) goto cont60; // GO TO 60
          //
          //     If ISTEP > NCP(L1), no need to re-compute distance from point I to
          //     cluster L1.   Note that if cluster L1 is last updated exactly M
          //     steps ago, we still need to compute the distance from point I to
          //     cluster L1.
          //
	      if (ISTEP > NCP[L1]) goto cont30; // GO TO 30
	      DA = ZERO;
	      for (int J = 1; J <= N; J++) // DO 20 J = 1, N
          {
	          DB = A[I][J] - C[L1][J];
	          DA = DA + DB * DB;
          } // 20   CONTINUE
	      D[I] = DA * AN1[L1];
          //
          //     If ISTEP >= both NCP(L1) & NCP(L2) there will be no transfer of
          //     point I at this step.
          //
cont30:
          if ((ISTEP >= NCP[L1]) && (ISTEP >= NCP[L2])) goto cont60; // GO TO 60
	      R2 = D[I] / AN2[L2];
	      DD = ZERO;
	      for (int J = 1; J <= N; J++) // DO 40 J = 1, N
          {
	          DE = A[I][J] - C[L2][J];
	          DD = DD + DE * DE;
	          if (DD >= R2) goto cont60; // GO TO 60
          } // 40   CONTINUE
          //
          //     Update cluster centres, NCP, NC, ITRAN, AN1 & AN2 for clusters
          //     L1 & L2.   Also update IC1(I) & IC2(I).   Note that if any
          //     updating occurs in this stage, INDX is set back to 0.
          //
	      ICOUN = 0;
	      INDX = 0;
	      ITRAN[L1] = 1;
	      ITRAN[L2] = 1;
	      NCP[L1] = ISTEP + M;
	      NCP[L2] = ISTEP + M;
	      AL1 = NC[L1];
	      ALW = AL1 - ONE;
	      AL2 = NC[L2];
	      ALT = AL2 + ONE;
	      for (int J = 1; J <= N; J++) // DO 50 J = 1, N
          {
	          C[L1][J] = (C[L1][J] * AL1 - A[I][J]) / ALW;
	          C[L2][J] = (C[L2][J] * AL2 + A[I][J]) / ALT;
          } // 50   CONTINUE
	      NC[L1] = NC[L1] - 1;
	      NC[L2] = NC[L2] + 1;
	      AN2[L1] = ALW / AL1;
	      AN1[L1] = BIG;
	      if (ALW > ONE) AN1[L1] = ALW / (ALW - ONE);
	      AN1[L2] = ALT / AL2;
	      AN2[L2] = ALT / (ALT + ONE);
	      IC1[I] = L2;
	      IC2[I] = L1;
          //
          //     If no re-allocation took place in the last M steps, return.
          //
cont60:
          if (ICOUN == M) return; // RETURN
      } // 70 CONTINUE
      goto cont10; // GO TO 10
}
//-------------------------------------------------------------------

void __fastcall TKMEANSForm::VarInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = ListBox1->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (ListBox1->Selected[i])
         {
            cellstring = ListBox1->Items->Strings[i];
            ListBox2->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < ListBox1->Items->Count; i++)
           {
               if (ListBox1->Selected[i])
               {
                  ListBox1->Items->Delete(i);
                  count--;
               }
           }
     }
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TKMEANSForm::VarOutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = ListBox2->ItemIndex;
     cellstring = ListBox2->Items->Strings[index];
     ListBox1->Items->Add(cellstring);
     ListBox2->Items->Delete(index);      
}
//---------------------------------------------------------------------------

void __fastcall TKMEANSForm::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = ListBox1->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = ListBox1->Items->Strings[index];
          ListBox2->Items->Add(cellstring);
     }
     ListBox1->Clear();
     VarOutBtn->Enabled = true;
}
//---------------------------------------------------------------------------

