//---------------------------------------------------------------------------

#ifndef CrossTabsUnitH
#define CrossTabsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TCrossTabForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TListBox *VarList;
    TListBox *SelectedBox;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TMemo *Memo1;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall ReturnBtnClick(TObject *Sender);
private:	// User declarations
    int grandsum, sum, index;
    int no_in_list, length_array, ptr1, ptr2;
    int *var_list, *min_value, *max_value, *levels, *displace, *subscript;
    int *freq;
    double **outgrid;
    AnsiString *rowlabels;
    AnsiString *collabels;
    int *ColNoSelected;
    int NoSelected;

    void GET_LEVELS(TObject *Sender);
    int INDEX_POSITION(int *x, TObject *Sender);
    void TABULATE(TObject *Sender);
    void BREAKDOWN(TObject *Sender);

public:		// User declarations
    __fastcall TCrossTabForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCrossTabForm *CrossTabForm;
//---------------------------------------------------------------------------
#endif
