//---------------------------------------------------------------------------
#ifndef RegSelUnitH
#define RegSelUnitH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TRegSelForm : public TForm
{
__published:	// IDE-managed Components
	TListBox *LstVariables;
	TLabel *Label1;
   TEdit *DepVarEdit;
	TGroupBox *GroupBox1;
	TButton *BtnNext;
	TLabel *LblBlock;
	TBevel *Bevel1;
	TLabel *Label2;
   TListBox *IndepList;
   TBitBtn *DepInBtn;
   TBitBtn *IndInBtn;
	TButton *BtnOK;
	TButton *BtnCancel;
	TButton *BtnReset;
	TGroupBox *GroupBox2;
   TPanel *Panel1;
   TLabel *Label4;
   TEdit *SigInEdit;
   TLabel *Label5;
   TEdit *SigOutEdit;
   TButton *ComputeBtn;
   TEdit *BlkNoEdit;
   TBitBtn *IndOutBtn;
   TCheckBox *SaveRChkBox;
   TCheckBox *ChkDesc;
   TCheckBox *ChkCorrMat;
   TCheckBox *ChkInverse;
   TCheckBox *ChkCoefMat;
   TCheckBox *BPGChk;
   TCheckBox *PredictChk;
   TCheckBox *ShowAllChk;
   TCheckBox *SaveXTXChk;
   TCheckBox *SaveXTYChk;
        TSaveDialog *SaveDialog1;
   void __fastcall DepInBtnClick(TObject *Sender);
   void __fastcall IndInBtnClick(TObject *Sender);
   void __fastcall BtnResetClick(TObject *Sender);
   void __fastcall BtnNextClick(TObject *Sender);
   void __fastcall ComputeBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall IndOutBtnClick(TObject *Sender);
   void __fastcall blkentryreg(void);
   void __fastcall ComputeBPG(TObject *Sender, double *Means, double *Variances,
      double *StdDevs, double *BetaWeights, double *BWeights, double *BStdErrs,
      double *Bttests, double *tProbs, double &BPG, int NCases, int depcol, int index, int *VarsIn,
      AnsiString *VarLabels, bool PrintDesc, bool PrintCorrs, bool PrintInverse,
      bool PrintCoefs, bool SaveCorrs);
   void __fastcall PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars);
   
private:	// User declarations
public:		// User declarations
   int BlkCnt;
   int VarCnt;
   int *NoInBlock;
   AnsiString *BlkVars;
   bool ShowAll, SaveXTX, SaveXTY;

	__fastcall TRegSelForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TRegSelForm *RegSelForm;
//---------------------------------------------------------------------------
#endif
