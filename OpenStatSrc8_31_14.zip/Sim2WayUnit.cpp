//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <Math.hpp>
#include "Sim2WayUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmSim2Way *FrmSim2Way;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern bool openfile;
//---------------------------------------------------------------------------
__fastcall TFrmSim2Way::TFrmSim2Way(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmSim2Way::FormShow(TObject *Sender)
{
    if (MainForm->Grid->ColCount > 2)
    {
        Application->MessageBox("First close existing file.","ERROR!",MB_OK);
        return;
    }
    NoLevAEdit->Text = "";
    NoLevBEdit->Text = "";
    NoPerCellEdit->Text = "";
    PopMeanEdit->Text = "";
    PopStdDevEdit->Text = "";
    ALevEdit->Text = "";
    BLevEdit->Text = "";
    ABLevAEdit->Text = "";
    ABLevBEdit->Text = "";
    AEffEdit->Text = "";
    BEffEdit->Text = "";
    ABEffEdit->Text = "";
    for (int i = 0; i < 10; i++)
    {
        AEffSize[i] = 0.0;
        BEffSize[i] = 0.0;
        for (int j = 0; j < 10; j++) ABEffSize[i][j] = 0.0;
    }
}
//---------------------------------------------------------------------------
void __fastcall TFrmSim2Way::ResetBtnClick(TObject *Sender)
{
    FormShow(this);    
}
//---------------------------------------------------------------------------
void __fastcall TFrmSim2Way::CancelBtnClick(TObject *Sender)
{
    FrmSim2Way->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFrmSim2Way::OKBtnClick(TObject *Sender)
{
    // Generate Simulated 2-way ANOVA data
    char outline[81];
    int rowno = 0;

    NoLevB = atoi(NoLevBEdit->Text.c_str());
    NoPerCell = atoi(NoPerCellEdit->Text.c_str());
    PopMean = atof(PopMeanEdit->Text.c_str());
    PopStdDev = atof(PopStdDevEdit->Text.c_str());
    TotN = NoPerCell * NoLevA * NoLevB;
    MainForm->Grid->ColCount = 4;
    MainForm->Grid->RowCount = TotN+1;
    NoCases = TotN;
    NoVariables = 3;
    MainForm->NoCasesEdit->Text = NoCases;
    MainForm->NoVarsEdit->Text = NoVariables;
/*    for (int col = 1; col <=3; col++)
    {
        NewVar(col,false);
    }
*/
    for (int i = 0; i < TotN; i++)
    {
        sprintf(outline,"CASE%d",i+1);
        MainForm->Grid->Cells[0][i+1] = outline;
    }
    MainForm->Grid->Cells[1][0] = "ATreat.";
    NewVar(1,true);
    MainForm->Grid->Cells[2][0] = "BTreat.";
    NewVar(2,true);
    MainForm->Grid->Cells[3][0] = "YScore";
    NewVar(3,true);
    for (int i = 0; i < NoLevA; i++)
    {
        for (int j = 0; j < NoLevB; j++)
        {
            for (int k = 0; k < NoPerCell; k++)
            {
                rowno++;
                MainForm->Grid->Cells[1][rowno] = i+1;
                MainForm->Grid->Cells[2][rowno] = j+1;
                X =  RandG(PopMean,PopStdDev);
                X += (AEffSize[i] + BEffSize[j] + ABEffSize[i][j]);
                sprintf(outline,"%8.3f",X);
                MainForm->Grid->Cells[3][rowno] = outline;

            }
        }
    }
    // output the results
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("RESULTS FOR SIMULATED TWO-WAY ANOVA DATA");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No. of Treatment Levels for Factor A = %d",NoLevA);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"No. of Treatment Levels for Factor B = %d",NoLevB);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"No. of observations per cell = %d",NoPerCell);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Population Mean Desired = %8.3f",PopMean);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Population Standard Deviation Desired = %8.3f",PopStdDev);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("FACTOR A TREATMENT EFFECTS");
    FrmOutPut->RichOutPut->Lines->Add("Level Effect");
    for (int i = 0; i < NoLevA; i++)
    {
        sprintf(outline,"  %3d  %6.3f",i+1,AEffSize[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("FACTOR B TREATMENT EFFECTS");
    FrmOutPut->RichOutPut->Lines->Add("Level Effect");
    for (int i = 0; i < NoLevB; i++)
    {
        sprintf(outline,"  %3d  %6.3f",i+1,BEffSize[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("TREATMENT INTERACTION EFFECTS");
    FrmOutPut->RichOutPut->Lines->Add("A Level  B Level  Effect");
    for (int i = 0; i < NoLevA; i++)
    {
        for (int j = 0; j < NoLevB; j++)
        {
            sprintf(outline,"  %3d      %3d    %6.3f",i+1,j+1,ABEffSize[i][j]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }
    FrmOutPut->ShowModal();
    openfile = true;
    if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "TwoWayData.TEX";
    FrmSim2Way->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFrmSim2Way::NoLevAEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        NoLevA = atoi(NoLevAEdit->Text.c_str());
        ALevEdit->Text = 1;
        AEffEdit->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::AEffEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        int level = atoi(ALevEdit->Text.c_str());
        AEffSize[level-1] = atof(AEffEdit->Text.c_str());
        if (level < (NoLevA - 1))
        {
            ALevEdit->Text = (level + 1);
            AEffEdit->Text = "";
            AEffEdit->SetFocus();
        }
        else
        {
            double sum = 0.0;
            for (int i = 0; i < NoLevA-1; i++) sum += AEffSize[i];
            AEffSize[NoLevA-1] = -sum;
            NoLevBEdit->SetFocus();
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::NoLevBEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        NoLevB = atoi(NoLevBEdit->Text.c_str());
        BLevEdit->Text = 1;
        BEffEdit->SetFocus();
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::BEffEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        int level = atoi(BLevEdit->Text.c_str());
        BEffSize[level-1] = atof(BEffEdit->Text.c_str());
        if (level < NoLevB-1)
        {
            BLevEdit->Text = (level + 1);
            BEffEdit->Text = "";
            BEffEdit->SetFocus();
        }
        else
        {
            double sum = 0.0;
            for (int i = 0; i < NoLevB-1; i++) sum += BEffSize[i];
            BEffSize[NoLevB-1] = -sum;
            ABLevAEdit->Text = 1;
            ABLevBEdit->Text = 1;
            ABEffEdit->SetFocus();
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::ABEffEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13)
    {
        int levelA = atoi(ABLevAEdit->Text.c_str());
        int levelB = atoi(ABLevBEdit->Text.c_str());
        ABEffSize[levelA-1][levelB-1] = atof(ABEffEdit->Text.c_str());
        if (levelB < NoLevB-1)
        {
            ABLevBEdit->Text = (levelB+1);
            ABEffEdit->Text = "";
            ABEffEdit->SetFocus();
        }
        if (levelA < NoLevA-1)
        {
            ABLevAEdit->Text = (levelA+1);
            ABLevBEdit->Text = 1;
            ABEffEdit->Text = "";
            ABEffEdit->SetFocus();
        }
        if ((levelA == NoLevA-1) && (levelB == NoLevB-1))
        {
            double sum = 0.0;
            for (int i = 0; i < NoLevA-1; i++)
            {
                for (int j = 0; j < NoLevB-1; j++) sum += ABEffSize[i][j];
                ABEffSize[i][NoLevB-1] = -sum;
                sum = 0.0;
            }
            for (int j = 0; j < NoLevB; j++)
            {
                for (int i = 0; i < NoLevA-1; i++) sum += ABEffSize[i][j];
                ABEffSize[NoLevA-1][j] = -sum;
                sum = 0.0;
            }
            NoPerCellEdit->SetFocus();
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::NoPerCellEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) PopMeanEdit->SetFocus();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::PopMeanEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) PopStdDevEdit->SetFocus();    
}
//---------------------------------------------------------------------------

void __fastcall TFrmSim2Way::PopStdDevEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) OKBtn->SetFocus();
}
//---------------------------------------------------------------------------

