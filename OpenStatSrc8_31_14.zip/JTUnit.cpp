//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "math.h"
#include "GraphUnit.h"

#include "JTUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TJTForm *JTForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TJTForm::TJTForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TJTForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Items->Clear();
     TreatVars->Items->Clear();
     DependentEdit->Clear();
     LabelIn->Visible = true;
     LabelOut->Visible = false;
     TrtIn->Visible = true;
     TrtOut->Visible = false;
     for (i = 1; i <= NoVariables; i++)
          VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TJTForm::TrtInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            TreatVars->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     TrtOut->Visible = true;
     if (VarList->Items->Count == 0) TrtIn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TJTForm::TrtOutClick(TObject *Sender)
{
   int index;

   index = TreatVars->ItemIndex;
   if (index < 0)
   {
        TrtOut->Visible = false;
        TrtIn->Visible = true;
        return;
   }
   VarList->Items->Add(TreatVars->Items->Strings[index]);
   TreatVars->Items->Delete(index);
   TrtIn->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TJTForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TJTForm::ComputeBtnClick(TObject *Sender)
{
        double P, Q, S, VarS, zS, Sumt2, Sumt3, Nscores, Nsqr, Ncube, zProb;
        double U2, U3;
        int NoSE, NoSW, i, j, XStart, XTarget, NoVars;
        int StartCol, StartRow, TestCol, RowCount;
        int *RowTotals, *ColTotals, GrandTotal;
        int **Matrix, **Matrix2;
        char outline[121];
        AnsiString astring;

        if (NoVariables < 1) return;
        if (NoCases < 1) return;
        NoVars = TreatVars->Items->Count;

        GetIntVecMem(RowTotals,NoCases);
        GetIntVecMem(ColTotals,NoVars);
        for (i = 0; i < NoCases; i++) RowTotals[i] = 0;
        for (i = 0; i < NoVars; i++) ColTotals[i] = 0;
        GetIntMatMem(Matrix,NoCases+1,NoVars+1);
        GetIntMatMem(Matrix2,NoCases+1,NoVars+1);
        // Note - last row and column of Matrix for totals
        GetIntVecMem(ColPos,NoVariables);
        AnsiString * RowLabels=NULL;
        try {
         RowLabels = new AnsiString [NoCases+1];
         }
        catch (...){
        Application->MessageBox("Out of Memory","ERROR!",MB_OK);
        exit (-1);
        }
        AnsiString * ColLabels=NULL;
        try {
         ColLabels = new AnsiString [NoVars+1];
        }
        catch (...) {
         Application->MessageBox("Out of Memory","ERROR!",MB_OK);
         exit (-1);
        }

        // Get label position and variable positions
        for (i = 1; i <= NoVariables; i++)
        {
                for (j = 0; j < TreatVars->Items->Count; j++)
                {
                        astring = TreatVars->Items->Strings[j];
                        if (MainForm->Grid->Cells[i][0] == astring) ColPos[i-1] = i;
                }
                if (MainForm->Grid->Cells[i][0] == DependentEdit->Text) LabelPos = i;
        }

        // Get row and column labels
        for (i = 1; i <= NoCases; i++) RowLabels[i-1] = MainForm->Grid->Cells[LabelPos][i];
        RowLabels[NoCases] = "Total";
        for (j = 1; j <= NoVars; j++) ColLabels[j-1] = MainForm->Grid->Cells[ColPos[j-1]][0];
        ColLabels[NoVars] = "Total";

        // Store values in the data matrix
        for (i = 1; i <= NoCases; i++)
        {
                for (j = 1; j <= NoVars; j++)
                {
                        Matrix[i-1][j-1] = StrToInt(MainForm->Grid->Cells[ColPos[j-1]][i]);
                        Matrix2[i-1][NoVars-j] = Matrix[i-1][j-1];  // reversed columns
                }
        }

        // Get row and column totals
        for (i = 0; i < NoVars; i++)
        {
                for (j = 0; j < NoCases; j++)
                {
                        ColTotals[i] = ColTotals[i] + StrToInt(MainForm->Grid->Cells[i+1][j+1]);
                        RowTotals[j] = RowTotals[j] + StrToInt(MainForm->Grid->Cells[i+1][j+1]);
                }
        }

        for (i = 0; i < NoCases; i++) Matrix[i][NoVars] = RowTotals[i];
        for (i = 0; i < NoVars; i++) Matrix[NoCases][i] = ColTotals[i];
        for (i = 0; i < NoCases; i++) Matrix2[i][NoVars] = RowTotals[i];
        for (i = 0; i < NoVars; i++) Matrix2[NoCases][i] = ColTotals[i];

        // Get Grand Total
        GrandTotal = 0;
        for (i = 0; i < NoVars; i++) GrandTotal = GrandTotal + ColTotals[i];
        Matrix[NoCases][NoVars] = GrandTotal;
        Matrix2[NoCases][NoVars] = GrandTotal;
        
        // Output data Matrix
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("Jonckheere-Terpstra Test for Ordered Values");
        FrmOutPut->RichOutPut->Lines->Add("");
        IntArrayPrint(Matrix, NoCases+1, NoVars+1, "Variables",RowLabels, ColLabels, "VALUES");
        FrmOutPut->RichOutPut->Lines->Add("");
//        FrmOutPut->ShowModal();

        // Get South-East count first
        NoSE = 0;
        RowCount = 0;
        StartCol = -1;
        StartRow = -1;
Secd:   StartCol = StartCol + 1; // start at the first data matrix column (0)
        TestCol = StartCol + 1; // check values East of starting column
        if (TestCol > (NoVars-1)) goto Next1;
        StartRow = StartCol; // start at row 0
        RowCount = StartRow + 1;
Again:  XStart = Matrix[StartRow][StartCol];
First:  XTarget = Matrix[RowCount][TestCol];
        NoSE = NoSE + (XStart * XTarget);
//        sprintf(outline,"NoSE = %3d for StartRow = %3d, StartCol %3d,    RowCount %3d and Test Col. %3d",
//          NoSE, StartRow, StartCol, RowCount, TestCol);
//        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (RowCount < (NoCases-1))
        {
                RowCount = RowCount + 1;
                goto First;
        }
        else if (TestCol < (NoVars-1))
        {
//               FrmOutPut->RichOutPut->Lines->Add(" ");
                RowCount = StartRow + 1;
                TestCol = TestCol + 1;
                goto Again;
        }
        else if (StartRow < NoCases-2)
        {
//                FrmOutPut->RichOutPut->Lines->Add(" ");
                StartRow = StartRow + 1;
                RowCount = StartRow + 1;
                TestCol = StartCol + 1;
                goto Again;
        }
        else if (StartCol < NoVars-1) goto Secd;
Next1:  P = NoSE;
//        FrmOutPut->ShowModal();
/*
        // Output data Matrix2
        FrmOutPut->RichOutPut->Lines->Add("Test for Reverse-Ordered Values");
        FrmOutPut->RichOutPut->Lines->Add("");
        IntArrayPrint(Matrix2, NoCases+1, NoVars+1, "Variables",RowLabels, ColLabels, "VALUES");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->ShowModal();
*/
        // Get Sourth-West count next
        NoSW = 0;
        RowCount = 0;
        StartCol = -1;
        StartRow = -1;
Secd1:   StartCol = StartCol + 1; // start at the first data matrix column (0)
        TestCol = StartCol + 1; // check values East of starting column
        if (TestCol > (NoVars-1)) goto Next2;
        StartRow = StartCol; // start at row 0
        RowCount = StartRow + 1;
Again1:  XStart = Matrix2[StartRow][StartCol];
First1:  XTarget = Matrix2[RowCount][TestCol];
        NoSW = NoSW + (XStart * XTarget);
//        sprintf(outline,"NoSW = %3d for StartRow = %3d, StartCol %3d,    RowCount %3d and Test Col. %3d",
//          NoSW, StartRow, StartCol, RowCount, TestCol);
//        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (RowCount < (NoCases-1))
        {
                RowCount = RowCount + 1;
                goto First1;
        }
        else if (TestCol < (NoVars-1))
        {
//                FrmOutPut->RichOutPut->Lines->Add(" ");
                RowCount = StartRow + 1;
                TestCol = TestCol + 1;
                goto Again1;
        }
        else if (StartRow < NoCases-2)
        {
//                FrmOutPut->RichOutPut->Lines->Add(" ");
                StartRow = StartRow + 1;
                RowCount = StartRow + 1;
                TestCol = StartCol + 1;
                goto Again1;
        }
        else if (StartCol < NoVars-1) goto Secd1;
Next2:  Q = NoSW;
//        FrmOutPut->ShowModal();

//EndIt:  Q = NoSW;
        S = P - Q;

        // Get Variance and z score for S statistic
        VarS = 0.0;
        Sumt2 = 0.0;
        Sumt3 = 0.0;
        for (i = 0; i < NoCases; i++)
        {
                Sumt2 = Sumt2 + (double) (RowTotals[i] * RowTotals[i]);
                Sumt3 = Sumt3 + (double) (RowTotals[i] * RowTotals[i] * RowTotals[i]);
        }
        Nscores = (double) GrandTotal;
        Nsqr = Nscores * Nscores;
        Ncube = Nsqr * Nscores;
        U2 = 0.0;
        U3 = 0.0;
        for (i = 0; i < NoVars; i++)
        {
                U2 = U2 + (double) (ColTotals[i] * ColTotals[i]);
                U3 = U3 + (double) (ColTotals[i] * ColTotals[i] * ColTotals[i]);
        }

        VarS = ((2.0 * (Ncube - Sumt3 - U3)) + (3.0 * (Nsqr - Sumt2 - U2)) + 5.0 * Nscores) / 18.0;
        VarS = VarS + ((Sumt3-3.0*Sumt2+2.0*Nscores) * (U3-3.0*U2+2.0*Nscores)) /
               (9.0*Nscores * (Nscores-1.0) * (Nscores - 2.0));
        VarS = VarS + ((Sumt2 - Nscores)*(U2 - Nscores)) / ((2.0 * Nscores) * (Nscores - 1.0));
        zS = S / sqrt(VarS);  // S uncorrected for continuity
        zProb = 1.0 - normalprob(zS);

        // Output the results
        sprintf(outline,"P = %8.3f, Q = %8.3f, S = %8.3f",P,Q,S);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Variance of S = %8.3f, z = %8.3f, Probability of greater z = %8.3f",VarS,zS,zProb);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();

        // clean up memory
        delete[] ColLabels;
        delete[] RowLabels;
        ClearIntVecMem(ColPos);
        ClearIntMatMem(Matrix2,NoCases+1);
        ClearIntMatMem(Matrix,NoCases+1);
        ClearIntVecMem(ColTotals);
        ClearIntVecMem(RowTotals);
}
//---------------------------------------------------------------------------


void __fastcall TJTForm::LabelInClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              DependentEdit->Text = VarList->Items->Strings[i];
              LabelPos = i;
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     LabelOut->Visible = true;
     LabelIn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TJTForm::LabelOutClick(TObject *Sender)
{
     VarList->Items->Add(DependentEdit->Text);
     DependentEdit->Text = "";
     LabelPos = 0;
     LabelIn->Visible = true;
     LabelOut->Visible = false;
}
//---------------------------------------------------------------------------

