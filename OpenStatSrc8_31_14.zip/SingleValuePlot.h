//---------------------------------------------------------------------------

#ifndef SingleValuePlotH
#define SingleValuePlotH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSingleValuePlotForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TBitBtn *YInBtn;
        TLabel *Label4;
        TEdit *YEdit;
        TGroupBox *GroupBox1;
        TCheckBox *DescChk;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        TListBox *Varlist;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall YInBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
        void __fastcall plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double Ymean,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N);
public:		// User declarations
        __fastcall TSingleValuePlotForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSingleValuePlotForm *SingleValuePlotForm;
//---------------------------------------------------------------------------
#endif
