//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "VarSelect.h"
#include "MemMgrUnit.h"
#include "MainUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "GumJML.h"
#include <stdio.h>
#include <stdlib.h>
#include "GUM.h"
#include "GraphUnit.h"
#include "DataFuncs.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
extern bool FilterOn;
extern int FilterCol;
extern int NoCases;
extern int NoVariables;

void CleanGrid(int ICUTOFF, int &NoSelected, int *ColNoSelected)
{
    int X, col, count;

    // eliminate cases having scores below the cutoff value
    for (int i = 1; i < MainForm->Grid->RowCount; i++) // subject loop
    {
        count = 0;
        for (int j = 0; j < NoSelected; j++)
        {
            col = ColNoSelected[j];
            X = atoi(MainForm->Grid->Cells[col][i].c_str());
            if ( X >= ICUTOFF) count += X;
        }
        if (count < 1) CutaRow(i); // eliminate this case
    }
    // eliminate items with no responses > 0
    for (int j = 0; j < NoSelected; j++) // item loop
    {
        count = 0;
        col = ColNoSelected[j];
        for (int i = 1; i < MainForm->Grid->RowCount; i++)
        {
            X = atoi(MainForm->Grid->Cells[col][i].c_str());
            if (X > 0) count += X;
        }
        if (count == 0) DeleteaCol(col); // eliminate item (grid column)
    }
}
//---------------------------------------------------------------------------



void GUMIT(void)
{
    int MAXDIT,MAXTIT,NSUBS,NITEMS,IER,TAUITER,MAXTAUIT,DITER,PASS,TITER,
        DONEFLAG,PARM,W,M,NCAT,L,H,V,CL,ICUTOFF,PASSMAX,TAUFLAG,
        FITG,PERFSH,ANYFIT,IC, RCODE, I, J;
    int NoSelected = 0, MaxCat = 0, MinCat = 1000;
    double DELCRIT,TCRIT,ITERCRIT,NITEMSD,MEAND,DER1,DER2,TMD,TAUCRIT,
        ADDIT,STO,DMEANALL,DVAR,TVAR,RESP,TERM1,TERM2,ORIGTHET,MAXCHNG,B,C,D,
        E,F,GAMMA,DM,DW,DNCAT,TERM3,TERM4,TERM5,EXPV,CHECK,TAUSUM,DDEG,ISGCUT,
        PSGCUT,ICHPCT,PCHPCT,LOCFC,SCO1, LAMBDA;
    double *DCORR, *EVAL, **EVEC, **COMP, *PERVAR, *ICL, *CU, *SIGNS,
           *DELTA, **TAU, *THETA, *PNIX, *DELTADIF, **TAUDIF, *DELTALAS,
           **TAULAS, *TAUVAR, *TSTD, *DSTD, **TAUSTD, *INIT, *SINTAU,
           *THETALAS, **U, *DMEAN;
    double **RMat;
    int **ICOUNT, *ColNoSelected;
    char outline[81];
    char value[11];
    AnsiString *RowLabels, *ColLabels;
    FILE * Msgptr;

    Msgptr = fopen("MESSAGE.TXT","wt");  // Message file
    FrmVarSel->LstBoxSelected->Clear();
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->Caption = "General Unfolding Model";
    for (int i = 0; i < NoVariables; i++)
        FrmVarSel->LstBoxVars->Items->Add(MainForm->Grid->Cells[i+1][0]);
    if (FrmVarSel->ShowModal() == mrCancel) return;
    NoSelected = FrmVarSel->LstBoxSelected->Items->Count;
    if (NoSelected < 2)
    {
        ShowMessage("ERROR! Selecte 2 or more variables to analyze.");
        return;
    }
    
    FrmVarSel->ChkBox->Visible = true;

    //Allocate heap storage for work areas
    try  {
        ColNoSelected = new int[NoSelected];
        U = new double *[10];
        for (int i = 0; i < 10; i++) U[i] = new double[10];
        DMEAN = new double [NoSelected+1];
        DSTD = new double [NoSelected+1];
        DCORR = new double [(NoSelected+1)*(NoSelected+2)/2];
        EVAL = new double [NoSelected+1];
        EVEC = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) EVEC[i] = new double[NoSelected+1];
        COMP = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) COMP[i] = new double[NoSelected+1];
        PERVAR = new double [NoSelected+1];
        ICL = new double [NoSelected+1];
        CU = new double [NoSelected+1];
        RMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) RMat[i] = new double[NoSelected+1];
        SIGNS = new double [NoSelected+1];
        DELTA = new double [NoSelected+1];
        TAUSTD = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TAUSTD[i] = new double[10];
        TAULAS = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TAULAS[i] = new double[10];
        TAU = new double * [NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TAU[i] = new double[10];
        THETA = new double [NoCases+1];
        SINTAU = new double [10];
        INIT = new double [NoSelected+1];
        THETALAS = new double [NoCases+1];
        DELTALAS = new double [NoSelected+1];
        DELTADIF = new double [NoSelected+1];
        TAUDIF = new double * [NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TAUDIF[i] = new double [10];
        PNIX = new double [NoSelected+1];
        TSTD = new double [NoCases+1];
        TAUVAR = new double [10];
        ICOUNT = new int * [NoSelected];
        for (int i = 0; i < NoSelected; i++) ICOUNT[i] = new int [11];
        RowLabels = new AnsiString [NoSelected];
        ColLabels = new AnsiString [10];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Initialize arrays
    for (int i = 0; i < 10; i++)
    {
        SINTAU[i] = 0.0;
        TAUVAR[i] = 0.0;
        for (int j = 0; j < 10; j++) U[i][j] = 0.0;
    }
    for (int i = 0; i < NoSelected+1; i++)
    {
        DMEAN[i] = 0.0;
        DSTD[i] = 0.0;
        EVAL[i] = 0.0;
        PERVAR[i] = 0.0;
        ICL[i] = 0.0;
        CU[i] = 0.0;
        SIGNS[i] = 0.0;
        DELTA[i] = 0.0;
        INIT[i] = 0.0;
        DELTALAS[i] = 0.0;
        DELTADIF[i] = 0.0;
        PNIX[i] = 0.0;
        for (int j = 0; j < NoSelected+1; j++)
        {
            EVEC[i][j] = 0.0;
            COMP[i][j] = 0.0;
            RMat[i][j] = 0.0;
        }
        for (int j = 0; j < 10; j++)
        {
            TAUSTD[i][j] = 0.0;
            TAULAS[i][j] = 0.0;
            TAU[i][j] = 0.0;
            TAUDIF[i][j] = 0.0;
        }
    }
    for (int i = 0; i < NoCases+1; i++)
    {
        THETA[i] = 0.0;
        THETALAS[i] = 0.0;
        TSTD[i] = 0.0;
    }
    
    // Get items selected
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            if (FrmVarSel->LstBoxSelected->Items->Strings[i] ==
                MainForm->Grid->Cells[j+1][0])
                ColNoSelected[i] = j+1;
        }
    }

    //Find largest and smallest category values in data
    for (int i = 0; i < NoCases; i++)
    {
        if (FilterOn) // check for data filtering (selection)
           if (MainForm->Grid->Cells[FilterCol][i+1] == "NO") continue;
        for (int j = 0; j < NoSelected; j++)
        {
            int col = ColNoSelected[j];
            int X = atoi(MainForm->Grid->Cells[col][i+1].c_str());
            if (X > MaxCat) MaxCat = X;
            if (X < MinCat) MinCat = X;
        }
    }

    // Get GUM Parameters
    GUMForm->ShowModal();
    NCAT = atoi(GUMForm->NoCatsEdit->Text.c_str());
    fprintf(Msgptr,"NCAT = %d\n",NCAT);
    ICUTOFF = atoi(GUMForm->MaxScrEdit->Text.c_str());
    fprintf(Msgptr,"ICUTOFF = %d\n",ICUTOFF);
    if (GUMForm->RecodeCB->Checked == true) RCODE = 1;
    else RCODE = 0;
    fprintf(Msgptr,"RCODE = %d\n",RCODE);
    if (GUMForm->FitStatsCB->Checked == true) ANYFIT = 1;
    else ANYFIT = 0;
    fprintf(Msgptr,"ANYFIT = %d\n",ANYFIT);
    if (GUMForm->PersonFitCB->Checked == true) PERFSH = 1;
    else PERFSH = 0;
    fprintf(Msgptr,"PERFSH = %d\n",PERFSH);
    if (GUMForm->GridSrchCB->Checked == true) IC = 1;
    else IC = 0;
    fprintf(Msgptr,"IC = %d\n",IC);
    FITG = atoi(GUMForm->NoFitGrpsEdit->Text.c_str());
    fprintf(Msgptr,"FITG = %d\n",FITG);
    ISGCUT = atof(GUMForm->ItemCOEdit->Text.c_str());
    fprintf(Msgptr,"ISGCUT = %10.5f\n",ISGCUT);
    ICHPCT = atof(GUMForm->ItemAlphaEdit->Text.c_str());
    fprintf(Msgptr,"ICHPCT = %10.5f\n",ICHPCT);
    PSGCUT = atof(GUMForm->PersonCOEdit->Text.c_str());
    fprintf(Msgptr,"PSGCUT = %10.5f\n",PSGCUT);
    PCHPCT = atof(GUMForm->PersonAlphaEdit->Text.c_str());
    fprintf(Msgptr,"PCHPCT = %10.5f\n",PCHPCT);
    LOCFC = atof(GUMForm->LocalCOEdit->Text.c_str());
    fprintf(Msgptr,"LOCFC = %10.5f\n",LOCFC);
    DELCRIT = atof(GUMForm->DeltaEndEdit->Text.c_str());
    fprintf(Msgptr,"DELCRIT = %10.5f\n",DELCRIT);
    MAXDIT = atoi(GUMForm->DeltaMaxEdit->Text.c_str());
    fprintf(Msgptr,"MAXDIT = %d\n",MAXDIT);
    TAUCRIT = atof(GUMForm->TauEndEdit->Text.c_str());
    fprintf(Msgptr,"TAUCRIT = %10.5f\n",TAUCRIT);
    MAXTAUIT = atoi(GUMForm->TauMaxEdit->Text.c_str());
    fprintf(Msgptr,"MAXTAUIT = %d\n",MAXTAUIT);
    TCRIT = atof(GUMForm->ThetaEndEdit->Text.c_str());
    fprintf(Msgptr,"TCRIT = %10.5f\n",TCRIT);
    MAXTIT = atoi(GUMForm->ThetaMaxEdit->Text.c_str());
    fprintf(Msgptr,"MAXTIT = %d\n",MAXTIT);
    ITERCRIT = atof(GUMForm->AvgAllEdit->Text.c_str());
    fprintf(Msgptr,"ITERCRIT = %10.5f\n",ITERCRIT);
    PASSMAX = atoi(GUMForm->MaxPassEdit->Text.c_str());
    fprintf(Msgptr,"PASSMAX = %d\n",PASSMAX);

    // delete cases with filter value = "NO"
    if (FilterOn)
    {
       for (int i = 0; i < NoCases; i++)
       {
           if (MainForm->Grid->Cells[FilterCol][i+1] == "NO") // eliminate
              CutaRow(i+1);
       }
       NoCases = MainForm->Grid->RowCount-1;
       MainForm->NoCasesEdit->Text = NoCases;
       Application->MessageBox("Grid has changed. Do not save under same file name.",
           "WARNING!",MB_OK);
    }

    // clean up the grid
    if ((RCODE == 1) || (MinCat > 1)) // make minimum response a 0
    {
        for (int i = 0; i < NoCases; i++) // subject loop
        {
            for (int j = 0; j < NoSelected; j++) // item loop
            {
                int col = ColNoSelected[j];
                int X = atoi(MainForm->Grid->Cells[col][i+1].c_str());
                X = X - MinCat;
                MainForm->Grid->Cells[col][i+1] = X;
            }
        }
    }
    NITEMS = NoSelected;
    CleanGrid(ICUTOFF, NITEMS, ColNoSelected);
    NSUBS = MainForm->Grid->RowCount-1;
    TCursor Save_Cursor = Screen->Cursor; // save current cursor
    Screen->Cursor = crHourGlass;    // Show hourglass cursor

    //Set response category parameters
    DNCAT = double(NCAT);
    M = (NCAT * 2) - 1;
    CL = NCAT - 1;
    DM = double(M);
    IER = 0;

    for (int H = 0; H <= CL; H++)
    {
        for (int V = 0; V <= CL; V++) U[H][V] = 0.0;
        for (int V = 0; V <= H; V++) U[H][V] = 1.0;
    }

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("GUMJML (Adapted from the original FORTRAN program written by James S. Roberts)");
    sprintf(outline,"No. Cases = %d, No. Items = %d",NSUBS,NoSelected);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    IER = Correlations(DMEAN,DSTD,RMat,NoSelected,ColNoSelected,NSUBS,
                       3,false,1);

    if (IER == 1)
    {
        Application->MessageBox("One of the variables has no variance.","ERROR!",MB_OK);
        return;
    }

    // Move correlations up one subscript in array since the roots routine
    // counts from 1, not zero. Store only lower half matrix
    L = 1;
    for (int i = 0; i < NITEMS; i++)
    {
        for (int j = 0; j <= i; j++)
        {
            DCORR[L] = RMat[i][j];
            L++;
        }
    }
    DCORR[0] = 0.0;

    // Get the iegenvalues and vectors of the correlation matrix.
    // EVAL holds the values and EVEC holds the vectors
    ICL[1] = NSUBS;
    OPRINC(DCORR,NITEMS,200,EVAL,EVEC,COMP,PERVAR,ICL,CU,IER);

    // print the eigenvalues and vectors, percent trace
    for (int i = 1; i <= NITEMS; i++)
    {
        fprintf(Msgptr,"Root %d = %8.4f\n",i,EVAL[i]);
    }
    fprintf(Msgptr,"EIGENVECTORS:\n");
    for (int i = 1; i <= NITEMS; i++)
    {
        strcpy(outline,"");
        sprintf(value,"%2d ",i);
        strcat(outline,value);
        for (int j = 1; j <= NITEMS; j++)
        {
            sprintf(value,"%6.3f ",COMP[i][j]);
            strcat(outline,value);
        }
        strcat(outline,"\n");
        fprintf(Msgptr,outline);
    }

    for (int i = 1; i <= NITEMS; i++)
    {
        if (EVEC[i][NITEMS] < 0.0) SIGNS[i] = -1.0;
        if (EVEC[i][NITEMS] >= 0.0) SIGNS[i] = 1.0;
        SIGNS[i] = -1.0 * SIGNS[i];
        DELTA[i] = 0.0;
        DMEAN[i] = 0.0;
        for (int H = 0; H <= CL; H++)
        {
            TAUSTD[i][H] = 0.0;
            TAULAS[i][H] = 0.0;
            TAU[i][H] = 0.0;
        }
    }

    // Compute the initial values for parameter estimates using subroutine
    // INITVAL.  The routine computes a single initial LAMBDA value
    // across all items along with an initial absolute delta value for
    // each item.
    INITVAL(NITEMS, NSUBS, DNCAT, LAMBDA,DMEAN,DELTA,THETA,TAU,U, ColNoSelected);
    NITEMSD = NITEMS;
    // Assign the signs of the initial delta values such that they correspond
    // with the principal components.  Compute the mean signed initial delta
    // values across items and store this value in the meand variable.  Compute
    // the initial tau parameters and store them in vector sintau.  Recenter
    // the initial delta values so that their mean is zero.  Copy the initial
    // delta values into vector init so they can be retained.
    MEAND = 0.0;
    for (int i = 1; i <= NITEMS; i++)
    {
        DELTA[i] *= SIGNS[i];
        MEAND += DELTA[i];
    }
    SINTAU[0] = 0.0;
    SCO1 = double(NCAT) - (floor((DNCAT+1.0) / 2.0));
    for (int H = 1; H <= CL; H++)
        SINTAU[H] = (double(NCAT) - double(H)) * (-2.0 * LAMBDA) / SCO1;
    MEAND /= NITEMSD;
    for (int i = 1; i <= NITEMS; i++) DELTA[i] -= MEAND;
    for (int i = 1; i <= NITEMS; i++) INIT[i] = DELTA[i];

    // Show initial values
    fprintf(Msgptr,"Initial delta values = %10.4f\n", MEAND);
    fprintf(Msgptr,"Initial Tau Parameters\n");
    for (int i = 1; i <= CL; i++) fprintf(Msgptr,"%d %10.4f\n",i,SINTAU[i]);
    fprintf(Msgptr,"Initial Delta Parameters\n");
    for (int i = 1; i <= NITEMS; i++) fprintf(Msgptr,"%d = %10.4f\n",i,INIT[i]);

    // Develop person estimates by computing the mean item location for items
    // that an individual endorsed at or beyond the threshold level.  Store
    // the person estimates in vector theta.
    for (int j = 1; j <= NSUBS; j++)
    {
        MEAND = 0.0;
        THETA[j] = 0.0;
        for (int i = 1; i <= NITEMS; i++)
        {
            int col = ColNoSelected[i-1];
            int X = atoi(MainForm->Grid->Cells[col][j].c_str());
            if (X >= ICUTOFF)
            {
                MEAND += double(X);
                THETA[j] += (double(X) * DELTA[i]);
            }
        }
        THETA[j] /= MEAND;
    }
    fprintf(Msgptr,"Initial Person Estimates (Theta)\n");
    for (int i = 1; i <= NSUBS; i++)
        fprintf(Msgptr,"%d theta = %10.4f\n",i,THETA[i]);

    // Initialize pass counter (variable PASS) and end of estimation flag
    // (variable DONEFLAG)
    PASS = 0;
    DONEFLAG = 0;

    // This section of code defines the start of an (outer cycle) Pass.
    // Begin counting passes.

beginpass:
    PASS++;
    // Begin estimation of TAU  parameters that are constant across items.
    // Note that the single set of TAU values is duplicated int the matrix
    // named TAU.  The previous values of TAU are stored in the matrix
    // called TAULAS.
Label203:
    for (int i = 1; i <=NITEMS; i++)
        for (int H = 0; H <= CL; H++) TAULAS[i][H] = TAU[i][H];

    // Start counting the number of iterations in the Newton-Raphson Tau
    // parameter estimation process.  Store the count in variable TAUITER.
    TAUITER = 0;
    TAUITER++;

    // Next loop (loop 230) cyles for each of the TAU parmeters
    for (V = 1; V <= CL; V++)
    {
        // Begin the Newton-Rhapson estimation process for a give tau
        // parameter.  Compute the first and second derivatives of the
        // log-likelihood function with respect to a given TAU parameter.
        // Store these derivatives in variables DER1 and DER2, respectively.

newton: DER1 = 0.0;
        DER2 = 0.0;
        for (int J = 1; J <= NSUBS; J++)
        {
            double X;
            for (int I = 1; I <= NITEMS; I++)
            {
                TMD = THETA[J] - DELTA[I];
                int col = ColNoSelected[I-1];
                X = atof(MainForm->Grid->Cells[col][J].c_str());
//                RESP = X;
                TERM1 = 0.0;
                TERM2 = 0.0;
                GAMMA = 0.0;
                for (W = 0; W <= CL; W++)
                {
                    TAUSUM = 0.0;
                    for (H = 0; H <= CL; H++)TAUSUM += (U[W][H] * SINTAU[H]);
                    D = exp(-TAUSUM);
                    DW = double(W);
                    E = exp(DW * TMD);
                    F = exp((DM-DW) * TMD);
                    GAMMA += (D * (E + F));
                    TERM1 += (D * (-U[W][V]) * (E + F));
                    TERM2 += (D * SQR(-U[W][V]) * (E + F));
                }
                DER1 -= (U[int(X)][V] + (TERM1 / GAMMA));
                DER2 += (SQR(TERM1 / GAMMA) - (TERM2 / GAMMA));
            } // next i
        } // next j

        // Once the first and second derivatives are computed, calculate
        // the increment for this iteration of the Newton-Rhapson process.
        // Store this increment in variable ADDIT.  It the absolute value
        // of ADDIT is greater than 1, then set the increment equal to 1
        // and retain the direction of the increment (i.e., retain the
        // sign of ADDIT).  Increment the TAU value stored in the SINTAU
        // vector accordingly.
        if (DER2 != 0.0) ADDIT = -DER1 / DER2;
        if (DER2 == 0.0) ADDIT = -DER1 / 1.7e-300;// TINY(SINTAU[1]) ????
        if (fabs(ADDIT) >= 1.0) ADDIT = 1.0 * ADDIT / fabs(ADDIT);
        SINTAU[V] += ADDIT;

        // Check to see if the increment is smaller that the user defined
        // iteration criterion or if the user defined maximum number of
        // iterations have been reached.  If either of these conditions
        // occur, then estimate the next TAU parameter in loop 230.  If the
        // last increment was not small enough and the number of iterations
        // is below the specified maximum, then do another iteration on the
        // current TAU parmeter.
        STO = fabs(ADDIT);
        if ((STO > TAUCRIT) && (TAUITER < MAXTAUIT)) goto newton;
        if (TAUITER >= MAXTAUIT)
            fprintf(Msgptr,"Max. iterations %d reached for TAU values parameter %d\n",
                            MAXTAUIT,V);
    }

    // At this point, all tau parameters have been estimated for the current
    // pass.  Duplicate the tau parameters stored in the SINTAU vector
    // into the TAU matrix.
    for (int I = 1; I <= NITEMS; I++)
        for (H = 0; H <= CL; H++)
            TAU[I][H] = SINTAU[H];

    // Note that the first time that tau parameters are estimated, the
    // estimation process is varied slightly.  Recall that the derivative
    // of TAU[k] depends all TAU[j] where j < k.  Therefore, inaccuracies
    // in an estimate of one tau parameter can adversely affect the
    // estimation of another tau parameter in a very direct way.  Therefore,
    // on the first pass, all the tau parameters are reestimated several
    // timesuntil the change in any of the tau parameters from one
    // estimation to the next is less than .01.  The variable TAUFLAG
    // stores this information.  When TAUFLAG is equal to 0, then little
    // change has occurred, and thus, the estimation of taus on the first
    // pass is considered to be complete.

    TAUFLAG = 0;
    for (H = 0; H <= CL; H++)
        if (fabs(TAULAS[1][H] - TAU[1][H]) > 0.01)TAUFLAG = 1;
    if ((TAUFLAG == 1) && (PASS == 1)) goto Label203;

    // The next section implements the estimation process for DELTA parameters.
    // Write out information about the PASS count.
//    sprintf(outline,"Delta Estimation Phase in Pass %d",PASS);
//    FrmOutPut->RichOutPut->Lines->Add(outline);

    // This loop executes for each item.  The DELTA parameter for a given
    // item is estimated within the loop.  Begin the estimation process
    // for a given item by storing its value from the last iteration in
    // the vector called DELTALAS.  Also, initialize the iteration counter
    // for the given item.

    for (I = 1; I <= NITEMS; I++) // loop 330 start
    {
        DELTALAS[I] = DELTA[I];
        DITER = 0;
        // Iteration within an item starts at the for statement above.
        // Compute the first and second derivatives of the log-liklihood
        // with respect to a given item.  Store this information in
        // variables called DER1 and DER2 respectively.  Increment the
        // iteration counter.

deltaiter:
        DER1 = 0.0;
        DER2 = 0.0;
        DITER++;
        for (J = 1; J <= NSUBS; J++)
        {
            TMD = THETA[J] - DELTA[I];
            int col = ColNoSelected[I-1];
            RESP = atof(MainForm->Grid->Cells[col][J].c_str());
            B = exp(RESP * TMD);
            C = exp((DM - RESP) * TMD);
            TERM1 = 0.0;
            TERM2 = 0.0;
            GAMMA = 0.0;
            for (W = 0; W <= CL; W++)
            {
                TAUSUM = 0.0;
                for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * TAU[I][H]);
                D = exp(-TAUSUM);
                DW = double(W);
                E = exp(DW * TMD);
                F = exp((DM - DW) * TMD);
                GAMMA += (D * (E + F));
                TERM1 += (D * (( E * W) + (F * (DM - DW))));
                TERM2 += (D * (( E * (DW * DW)) + (F * SQR(DM - DW))));
            }
            TERM3 = (RESP * B) + (C * (DM - RESP));
            DER1 = DER1 - ((TERM3 / (B + C)) - (TERM1 / GAMMA));
            TERM4 = (B + C) * (((RESP * RESP) * B) + (SQR(DM - RESP) * C));
            TERM5 = ((GAMMA*TERM2)- SQR(TERM1)) / SQR(GAMMA);
            DER2 = DER2 + ( ((TERM4 - SQR(TERM3)) / SQR(B+C)) - TERM5 );
        }

        // Once the first and second derivatives are computed, calculate
        // the increment for this iteration of the Newton-Rhapson process.
        // Store this increment in variable ADDIT.  If the absolute value
        // of ADDIT is greater than 1, then set the increment equal to 1
        // and retain the direction of the increment (i.e., retain the
        // sign of ADDIT).  Increment the DELTA value stored in the DELTA
        // vector accordingly.
        if (DER2 != 0.0) ADDIT = -DER1 / DER2;
        if (DER2 == 0.0) ADDIT = -DER1 / 1.7e-300; // TINY(DELTA(1))???
        if (fabs(ADDIT) >= 1.0) ADDIT = 1.0 * ADDIT / fabs(ADDIT);
        DELTA[I] = DELTA[I] + ADDIT;

        // Check to see if the increment is smaller than the user defined
        // iteration criterion or if the user defined maximum number of
        // iterations have been reached.  If either of these conditions
        // occur, then estimate the next DELTA parameter in this loop (330).
        // If the last increment was not small enough and the number of
        // iterations is below the specified maximum, then do another
        // iteration on the current DELTA parameter.
        STO = fabs(ADDIT);
        if ((STO > DELCRIT) && (DITER < MAXDIT)) goto deltaiter;
        if (DITER >= MAXDIT)
        {
            fprintf(Msgptr,"The item parameter for item %d did not converge after %d iterations\n",
                                I, DITER);
            fprintf(Msgptr,"in pass %d.  The delta value for this item is currently %16.8f,\n",
                                PASS, DELTA[I]);
            fprintf(Msgptr,"and the tau values are:\n");
            fprintf(Msgptr,"No.     TAU\n");
            for (int j = 0; j <= CL; j++)
                fprintf(Msgptr,"%3d  %16.8f\n",j,TAU[I][j]);
        }
    }
    // end of the (330) loop for deltas

    // At this point, all the delta parameters for the current pass have
    // been estimated.  Recenter the new delta parameters about their
    // mean value.  Compute the sum of the absolute difference between
    // all delta and tau parameters estimated on the previous and the
    // current pass.  Store this sum in variable STO.
    DMEANALL = 0.0;
    for (I = 1; I <= NITEMS; I++) DMEANALL += DELTA[I];
    DMEANALL /= NITEMSD;
    STO = 0.0;
    for (I = 1; I <= NITEMS; I++)
    {
        DELTA[I] -= DMEANALL;
        DELTADIF[I] = DELTALAS[I] - DELTA[I];
        TAUSUM = 0.0;
        for (H = 1; H <= CL; H++)
        {
            TAUDIF[I][H] = TAULAS[I][H] - TAU[I][H];
            TAUSUM += fabs(TAUDIF[I][H]);
        }
        if (I > 1) TAUSUM = 0.0;
        STO += (fabs(DELTADIF[I]) + TAUSUM);
    }

    // Compute the maximum change that occurred for any of the delta
    // and tau parameters.  Store this value in the variable MAXCHNG.
    MAXCHNG = -99999.0;
    for (I = 1; I <= NITEMS; I++)
    {
        if (fabs(DELTADIF[I]) > MAXCHNG)MAXCHNG = fabs(DELTADIF[I]);
        for (H = 1; H <= CL; H++)
        {
            if (fabs(TAUDIF[I][H]) > MAXCHNG) MAXCHNG = fabs(TAUDIF[I][H]);
        }
    }

    // Compute the average absolute deviation of item parameters from the
    // previous pass to the current pass.  Do this by dividing the variable
    // STO by the number of delta and tau parameters estimated.  If this
    // average is less than the user-defined iteration criterion then set
    // the DONEFLAG variable to 1 indicating that the item parameter
    // estimation process is finished.  However, do not conclude the item
    // estimation process before the 6th pass.  This will insure that the
    // grid search on theta parameters that automatically occurs on pass
    // 5 will be performed and that item parameters will be estimated on
    // at least one pass following the grid search.
    STO = STO / (NITEMSD + double(CL));
    if (STO < ITERCRIT) DONEFLAG = 1;
    if (PASS <= 5) DONEFLAG = 0;

    // Write out information about the parameter differences once item
    // parameter estimation has concluded.
    if (DONEFLAG == 1)
    {
        fprintf(Msgptr,"On last pass %d, criterion = %10.6f\n",PASS,STO);
        fprintf(Msgptr,"the differences in successive delta values are:\n");
        fprintf(Msgptr,"ITEM DELTA DIF.\n");
        for (int i = 1; i <= NITEMS; i++)
            fprintf(Msgptr,"%3d %10.6f\n",i,DELTADIF[i]);
        fprintf(Msgptr,"The differences in successive Tau values are:\n");
        fprintf(Msgptr,"No.  TAU DIFFERENCE\n");
        for (int i = 0; i <= CL; i++)
            fprintf(Msgptr,"%3d %10.5f\n",i,TAUDIF[1][i]);
    }

    // The next section of code estimates theta parameters.  Write out
    // information about the pass and criterion.
    fprintf(Msgptr,"Theta estimation phase in pass %d, criterion = %16.8f\n",
                        PASS, STO);

    // The next loop (430) executes for each theta parameter.  Estimates
    // of a given theta are calculated with the loop.  Start by storing
    // the theta estimate from the previous pass in variable ORIGTHETA.
    // Initialize the iteration counter.
    for (J = 1; J <= NSUBS; J++)
    {
        ORIGTHET = THETA[J];
        TITER = 0;
        // Begin the estimation loop for a given theta parameter.  Increment
        // the iteration counter.  Calculate the first and second derivatives
        // of the log-liklihood function with respect to the given theta
        // parameter.  Store these derivatives in DER1 and DER2, respectively.
thetaloop:  TITER++;
        DER1 = 0.0;
        DER2 = 0.0;
        for (I = 1; I <= NITEMS; I++)
        {
            TMD = THETA[J] - DELTA[I];
            int col = ColNoSelected[I-1];
            RESP = atof(MainForm->Grid->Cells[col][J].c_str());
            B = exp(RESP * TMD);
            C = exp((DM - RESP) * TMD);
            TERM1 = 0.0;
            TERM2 = 0.0;
            GAMMA = 0.0;
            for (W = 0; W <= CL; W++)
            {
                TAUSUM = 0.0;
                for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * TAU[I][H]);
                D = exp(-TAUSUM);
                DW = double(W);
                E = exp(DW * TMD);
                F = exp((DM - DW) * TMD);
                GAMMA += (D * (E + F));
                TERM1 += (D * ((E * W) + (F * (DM - DW))));
                TERM2 += (D * ( (E * SQR(DW)) + (F * SQR(DM - DW)) ) );
            }
            TERM3 = (RESP * B) + (C * (DM - RESP));
            DER1 += ((TERM3 / (B + C)) - (TERM1 / GAMMA));
            TERM4 = (B + C) * ( (SQR(RESP) * B) + (SQR(DM-RESP) * C) );
            TERM5 = ( (GAMMA * TERM2) - SQR(TERM1) ) / SQR(GAMMA);
            DER2 += ( (TERM4 - SQR(TERM3)) / (SQR(B + C)) - TERM5 );
        }

        // Compute the increment based on the Newton-Rhapson procedure and
        // store the value in variable ADDIT.  Check to see if the absolute
        // increment is greater than 5 units.  If so, then obtain the theta
        // estimate using a bisection method.  If a bisection is used,
        // then jump to the end of loop (420) and begin the Newton-Rhapson
        // process on the next theta parameter.
        if (DER2 != 0.0) ADDIT = -DER1 / DER2;
        if (DER2 == 0.0) ADDIT = -DER1 / 1.7e-300;// TINY(THETA(1)) ???
        if (fabs(ADDIT) >= 5.0)
                BISTHETA(ORIGTHET,J,M,CL,NITEMS,ICUTOFF,100,DELTA,TAU,U,ColNoSelected);
        if (fabs(ADDIT) >= 5.0) THETA[J] = ORIGTHET;
        if (fabs(ADDIT) >= 5.0)
        {
            fprintf(Msgptr,"Bisecton done for subject = %-s in pass %d \n",
                        MainForm->Grid->Cells[0][J].c_str(), PASS);
            fprintf(Msgptr,"because increment greater than 5 in Newton-Rhapson process.\n");
            fprintf(Msgptr,"After bisection, theta = %10.4f\n",THETA[J]);
        }
        if (fabs(ADDIT) < 5.0)
        {
            if (fabs(ADDIT) >= 1.0) ADDIT = 1.0 * ADDIT / fabs(ADDIT);
            THETA[J] += ADDIT;

            // Check to see if the absolute value of the increment is
            // greater than the user-defined criterion and if the maximum
            // number of theta iterations has not been reached.  If both
            // of these conditions are true, then perform another Newton-
            // Rhapson iteration on the current theta parameter.  If the
            // maximum number of iterations have been performed, then
            // estimate the theta value with the bisection method.  If
            // the absolute value of the Newton-Rhapson increment is less
            // than or equal to the user-defined criterion, then estimation
            // of the current parameter finishes.
            STO = fabs(ADDIT);
            if ((STO > TCRIT) && (TITER < MAXTIT)) goto thetaloop;
            if (TITER >= MAXTIT)
            {
                BISTHETA(ORIGTHET,J,M,CL,NITEMS,ICUTOFF,100,DELTA,TAU,U,ColNoSelected);
                THETA[J] = ORIGTHET;
                fprintf(Msgptr,"The theta parameter for subject %-s did not converge\n",
                    MainForm->Grid->Cells[0][J].c_str());
                fprintf(Msgptr,"after %d iterations during pass %d.\n",
                                TITER,PASS);
                fprintf(Msgptr,"After BISECT was done, the theta value for %-s was %16.8f\n",
                                MainForm->Grid->Cells[0][J].c_str(),THETA[J]);
            }
        } // end if

        // If the pass 5 bisection has been completed and a given theta
        // value deviates substantially from its last saved grid searched
        // estimate, then assume a local maximum has been reached and
        // bisect the theta value.  Conduct the bisection so that the last
        // grid searched estimate is in the middle of the bounded interval
        // and then find the root of the first derivative of the log-
        // liklihood function with respect to theta using the bisection
        // algorithm.  Store the bisection result in array THETALAS for
        // later comparison.  The amount of acceptable absolute deviation
        // is hard-coded as .2 and this value is stored in variable DDEG.
        DDEG = 0.2;
        if ((fabs(THETALAS[J]-THETA[J]) >= DDEG) && (PASS > 5))
        {
            fprintf(Msgptr,"Bisecting theta for %-s due to large theta comparison\n",
                MainForm->Grid->Cells[0][J].c_str());
            BISTHETA(THETALAS[J],J,M,CL,NITEMS,ICUTOFF,100,DELTA,TAU,U,ColNoSelected);
            THETA[J] = THETALAS[J];
            fprintf(Msgptr,"After bisection, theta = %16.4f\n",THETA[J]);
        }
    }

    // get the next theta parameter in loop (430) and begin estimation
    // Note that in order to guard against local maxima, a grid search
    // estimate of each theta parameter is performed after completing the
    // 5th pass.  These estimates are saved in the vector THETALAS.  If a
    // given theta estimate deviates from the corresponding THETALAS value
    // by more than .2 units, then a bisection is performed where the last
    // grid searched valued derived for the subject is used as the midpoint
    // of the bounded interval.
    if (PASS == 5)
    {
        BRUTE(NSUBS,NITEMS,M,CL,ICUTOFF,THETA,DELTA,U,TAU,ColNoSelected);
        for (J = 1; J <= NSUBS; J++) THETALAS[J] = THETA[J];
    }

    // If the iterative criterion has not been reached and the maximum
    // number of passes have not been performed, then jump to the item
    // estimation section and begin estimating the tau parameters.  If
    // the criterion has been reached and the DONEFLAG variable has been
    // set to 1, or if the maximum number of passes have been performed,
    // then end the parameter estimation process.
    if (PASS == PASSMAX) DONEFLAG = 1;
    if (DONEFLAG == 0) goto beginpass;

    // If user wants to perform a grid search for all theta values after the
    // final item estimates are calculated, then compute them now.
    if (IC != 0)
    {
        FrmOutPut->RichOutPut->Lines->Add("Grid search of theta values on final iteration");
        BRUTE(NSUBS,NITEMS,M,CL,ICUTOFF,THETA,DELTA,U,TAU,ColNoSelected);
        for (J = 1; J <= NSUBS; J++) THETALAS[J] = THETA[J];
    }

    // All item and theta parameters have been estimated.  Calculate Std. errors.
    // Calculate standard errors of theta parameters
    for (J = 1; J <= NSUBS; J++)
    {
        TVAR = 0.0;
        for (I = 1; I <= NITEMS; I++)
        {
            TMD = THETA[J] - DELTA[I];
            TERM1 = 0.0;
            TERM2 = 0.0;
            GAMMA = 0.0;
            for (W = 0; W <= CL; W++)
            {
                TAUSUM = 0.0;
                for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * TAU[I][H]);
                D = exp(-TAUSUM);
                DW = double(W);
                E = exp(DW * TMD);
                F = exp((DM - DW) * TMD);
                GAMMA += (D * (E + F));
                PNIX[W] = D * (E + F);
                TERM1 += (D * ((E * W) + (F * (DM - DW))));
                TERM2 += (D * ( (E * SQR(DW)) + (F * SQR(DM - DW)) ));
            } // next W
            CHECK = 0.0;
            EXPV = 0.0;
            for (int X = 0; X <= NCAT-1; X++)
            {
                PNIX[X] = PNIX[X] / GAMMA;
                CHECK += PNIX[X];
                RESP = double(X);
                B = exp(RESP * TMD);
                C = exp((DM - RESP) * TMD);
                TERM3 = (RESP * B) + (C * (DM - RESP));
                TERM4 = (B + C) * ( (SQR(RESP) * B) + (SQR(DM-RESP) * C) );
//                TERM5 = ( (GAMMA * TERM2) - SQR(TERM1) ) / SQR(GAMMA);
                EXPV += ( PNIX[X] *  ( (TERM4 - SQR(TERM3)) / SQR(B + C) ) );
            }
            if (fabs(CHECK-1.0) > 0.00001)
                FrmOutPut->RichOutPut->Lines->Add("There is a problem with the S.E. calculation for theta");
            TERM5 = ( (GAMMA * TERM2) - SQR(TERM1) ) / SQR(GAMMA);
            TVAR += (EXPV - TERM5);
        } // next i
        if (TVAR < 0.0) TSTD[J] = sqrt(-1.0 / TVAR);
        if (TVAR > 0.0) TSTD[J] = sqrt(1.0 / TVAR);
        if (TVAR == 0.0) TSTD[J] = 0.0;
    }

    // Calculate standard errors for delta parameters
    for (I = 1; I <= NITEMS; I++)
    {
        DVAR = 0.0;
        for (J = 1; J <= NSUBS; J++)
        {
            TMD = THETA[J] - DELTA[I];
            TERM1 = 0.0;
            TERM2 = 0.0;
            GAMMA = 0.0;
            for (W = 0; W <= CL; W++)
            {
                TAUSUM = 0.0;
                for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * TAU[I][H]);
                D = exp(-TAUSUM);
                DW = double(W);
                E = exp(DW * TMD);
                F = exp((DM - DW) * TMD);
                GAMMA += (D * (E + F));
                PNIX[W] = D * (E + F);
                TERM1 += (D * ((E * W) + (F * (DM - DW))));
                TERM2 += (D * ( (E * SQR(DW)) + (F * ( SQR(DM-DW))) ));
            }
            CHECK = 0.0;
            EXPV = 0.0;
            for (int X = 0; X <= NCAT-1; X++)
            {
                PNIX[X] /= GAMMA;
                CHECK += PNIX[X];
                RESP = double(X);
                B = exp(RESP * TMD);
                C = exp((DM - RESP) * TMD);
                TERM3 = (RESP * B) + (C * (DM - RESP));
                TERM4 = (B + C) * ( (SQR(RESP) * B) + (SQR(DM-RESP) * C) );
//                TERM5 = ((GAMMA * TERM2) - SQR(TERM1)) / SQR(GAMMA);
                EXPV += ( PNIX[X] *  ( (TERM4 - SQR(TERM3)) / SQR(B + C)) );
            }
            if (fabs(CHECK-1.0) > 0.00001)
                FrmOutPut->RichOutPut->Lines->Add("There is a problem with the S.E. calculation for delta");
            TERM5 = ( (GAMMA * TERM2) - SQR(TERM1) ) / SQR(GAMMA);
            DVAR += (EXPV - TERM5);
        }
        if (DVAR < 0.0) DSTD[I] = sqrt(-1.0 / DVAR);
        if (DVAR > 0.0) DSTD[I] = sqrt(1.0 / DVAR);
        if (DVAR == 0.0) DSTD[I] = 0.0;
    }

    // Calculate standard errors of tau parameters
    for (V = 1; V <= CL; V++)
    {
        TAUVAR[V] = 0.0;
        for (J = 1; J <= NSUBS; J++)
        {
            for (I = 1; I <= NITEMS; I++)
            {
                TMD = THETA[J] - DELTA[I];
                int col = ColNoSelected[I-1];
//                RESP = atof(MainForm->Grid->Cells[col][J].c_str());
                TERM1 = 0.0;
                TERM2 = 0.0;
                GAMMA = 0.0;
                for (W = 0; W <= CL; W++)
                {
                    TAUSUM = 0.0;
                    for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * SINTAU[H]);
                    D = exp(-TAUSUM);
                    DW = double(W);
                    E = exp(DW * TMD);
                    F = exp((DM - DW) * TMD);
                    GAMMA += (D * (E + F));
                    TERM1 += (D * (-U[W][V]) * (E + F));
                    TERM2 += ( D * SQR(-U[W][V]) * (E + F) );
                }
                TAUVAR[V] += ( SQR(TERM1 / GAMMA) - ( TERM2 / GAMMA) );
            } // next I
        } // next J
        if (TAUVAR[V] < 0.0) TAUSTD[1][V] = sqrt( -1.0 / TAUVAR[V]);
        if (TAUVAR[V] > 0.0) TAUSTD[1][V] = sqrt(1.0 / TAUVAR[V]);
        if (TAUVAR[V] == 0.0) TAUSTD[1][V] = 0.0;
        for (I = 1; I <= NITEMS; I++) TAUSTD[I][V] = TAUSTD[1][V];
    }

    // Write out final results
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("FINAL RESULTS");
    sprintf(outline,"%d passes completed.",PASS);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Maximum change in any item parameter between last two iterations = %10.6f",
                     MAXCHNG);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    for (H = 0; H <= CL; H++)
    {
        sprintf(outline,"Constant tau # %2d = %10.5f, Std. Error = %10.5f",
                        H, SINTAU[H], TAUSTD[1][H]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("ITEM      DELTA      STD.ERROR  CLASS      TAU       STD.ERROR");
    for (I = 1; I <= NITEMS; I++)
    {
        sprintf(outline,"%-10s %10.5f %10.5f",MainForm->Grid->Cells[I][0].c_str(), DELTA[I], DSTD[I]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (H = 0; H <= CL; H++)
        {
            sprintf(outline,"                                  %2d   %10.5f %10.5f",
                            H, TAU[I][H],TAUSTD[I][H]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("SUBJECT       THETA      STD.ERROR");
    for (J = 1; J <= NSUBS; J++)
    {
        sprintf(outline,"%-10s %10.5f %10.5f",MainForm->Grid->Cells[0][J].c_str(),
                        THETA[J],TSTD[J]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    // create a frequency table and print it
    for (int i = 0; i < NoSelected; i++)
    {
        int col = ColNoSelected[i];
        RowLabels[i] = MainForm->Grid->Cells[col][0];
        for (int j = 0; j < 10; j++)
        {
            ColLabels[j] = j;
            ICOUNT[i][j] = 0;
        }
    }
    for (int i = 0; i < NITEMS; i++)
    {
        int col = ColNoSelected[i];
        for (int j = 0; j < NSUBS; j++)
        {
            int X = atoi(MainForm->Grid->Cells[col][j+1].c_str());
            ICOUNT[i][X]++;
        }
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    IntArrayPrint(ICOUNT,NITEMS,CL+1,"      RESPONSE VALUES",RowLabels,ColLabels,
                  "RESPONSE FREQUENCIES");

    // If the user has requested fit statistics, then calculate them now.
    // Note that the distribution of these fit statistics are not known.
    if (ANYFIT == 1)
    {
        PARM = 0;
        DIAGNO(PARM,NCAT,NSUBS,NITEMS,M,FITG,PSGCUT,ISGCUT,PERFSH,ICHPCT,
               PCHPCT, CL, LOCFC);
    }
    // end of program

    fclose(Msgptr);
    Screen->Cursor = Save_Cursor;
    FrmOutPut->ShowModal();
    int response = Application->MessageBox("Print these results?","PRINT?",MB_YESNO);
    if (response == IDYES)
    {
        FrmOutPut->RichOutPut->Print("OpenStat.exe - Output");
        FrmOutPut->RichOutPut->Clear();
    }
    response = Application->MessageBox("Examine the MESSAGE.TXT file?","MESSAGES",MB_YESNO);
    if (response == IDYES)
    {
        FrmOutPut->RichOutPut->Clear();
        Msgptr = fopen("MESSAGE.TXT","rt");
        while (!feof(Msgptr))
        {
            fgets(outline,80,Msgptr);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->ShowModal();
        response = Application->MessageBox("Print these results?","PRINT?",MB_YESNO);
        if (response == IDYES)
        {
            FrmOutPut->RichOutPut->Print("OpenStat.exe - Output");
            FrmOutPut->RichOutPut->Clear();
        }
        fclose(Msgptr);
    }
    PlotTheta(THETA,NSUBS);
    PlotDelta(DELTA,NITEMS);
    // Clean up the heap
    delete[] ColLabels;
    delete[] RowLabels;
    for (int i = 0; i < NoSelected; i++) delete[] ICOUNT[i];
    delete[] ICOUNT;
    delete[] TAUVAR;
    delete[] TSTD;
    delete[] PNIX;
    for (int i = 0; i < NoSelected+1; i++) delete[] TAUDIF[i];
    delete[] TAUDIF;
    delete[] DELTADIF;
    delete[] DELTALAS;
    delete[] THETALAS;
    delete[] INIT;
    delete[] SINTAU;
    delete[] THETA;
    for (int i = 0; i < NoSelected+1; i++) delete[] TAU[i];
    delete[] TAU;
    for (int i = 0; i < NoSelected+1; i++) delete[] TAULAS[i];
    delete[] TAULAS;
    for (int i = 0; i < NoSelected+1; i++) delete[] TAUSTD[i];
    delete[] TAUSTD;
    delete[] DELTA;
    delete[] SIGNS;
    for (int i = 0; i < NoSelected+1; i++) delete[] RMat[i];
    delete[] RMat;
    delete[] CU;
    delete[] ICL;
    delete[] PERVAR;
    for (int i = 0; i < NoSelected+1; i++) delete[] COMP[i];
    delete[] COMP;
    for (int i = 0; i < NoSelected+1; i++) delete[] EVEC[i];
    delete[] EVEC;
    delete[] EVAL;
    delete[] DCORR;
    delete[] DSTD;
    delete[] DMEAN;
    for (int i = 0; i < 10; i++) delete[] U[i];
    delete[] U;
    delete[] ColNoSelected;
}
//--------------------------------------------------------------------------
void INITVAL(int NITEMS, int NSUBS, double DNCAT, double &LAMBDA,
             double *DMEAN, double *DELTA, double *THETA, double **TAU,
             double **U, int *ColNoSelected)
{
    //Computes initial values for LAMBDA and DELTA.  LAMBDA corresponds to
    // -2*TAU_B in Roberts and Laughlin (1996).  It is equal to one half the
    // distance between equally distant taus.

    double MAXP, TERM1, A, B, C, TERM2, TERM3, PRED, DIF, MAXPSTO;
    int FLAG;

    // Find the maximum proportion of endorsements for any item.  Store
    // the value in variable MAXP.
    FLAG = 0;
    MAXP = -1.0;
    for (int i = 1; i <= NITEMS; i++)
    {
        DMEAN[i] = 0.0;
        int col = ColNoSelected[i-1];
        for (int j = 1; j <= NSUBS; j++) // subject loop
        {
            double X = atof(MainForm->Grid->Cells[col][j].c_str());
            if (X >= floor((DNCAT+1.0)/2.0)) DMEAN[i] += (1.0 / double(NSUBS));
        }
        if (MAXP < DMEAN[i]) MAXP = DMEAN[i];
    }
    // If the maximum proportion of endorsements is less than .623 or if
    // the maximum proportion is greater than .95, then rescale all
    // proportions so that the maximum value is equal to .623 or .95,
    // respectively.  This will keep lambda within a reasonable interval
    // (i.e. .2 to 1.47).
    MAXPSTO = MAXP;
    if (MAXP < .623) FLAG = 1;
    if ((MAXP < .623)|| (MAXP > 0.95))
    {
        MAXP = -1.0;
        for (int i = 1; i <= NITEMS; i++)
        {
            if (FLAG == 0) DMEAN[i] *= 0.95 / MAXPSTO;
            if (FLAG == 1) DMEAN[i] *= 0.623 / MAXPSTO;
            if (DMEAN[i] > MAXP) MAXP = DMEAN[i];
        }
    }
    // Compute the lambda value based on the (possibly rescaled) maximum
    // proportion of endorsements.
    LAMBDA = 0.5 * log(MAXP * (1.0 / (1.0 - MAXP)));
    // Compute the initial item locations based on the lambda value and
    // the observed proportion of endorsements for the item in question.
    for (int i = 1; i <= NITEMS; i++)
    {
        // If the item corresponds to the maximum number of endorsements,
        // then set its location to zero.
        if (fabs(DMEAN[i] - MAXP) <= 0.01e-12) DELTA[i] = 0.0;
        if (fabs(DMEAN[i] - MAXP) > 0.01e-12)
        {
            A = 0.01e-12;
            B = 25.0;
            do
            {
                C = ((B-A) / 2.0) + A;
                TERM1 = exp((2.0 * LAMBDA) - C);
                TERM2 = exp((2.0 * LAMBDA) - (2.0 * C));
                TERM3 = exp(-3.0*C);
                PRED = (TERM1 + TERM2) / (1.0 + TERM1 + TERM2 + TERM3);
                DIF = PRED - DMEAN[i];
                if (DIF < 0.0) B = C;
                if (DIF >= 0.0) A = C;
            } while (fabs(B-A) > 0.001);
            DELTA[i] = ((B-A) / 2.0) + A;
        }// end if
    } // next i
}
//--------------------------------------------------------------------------

void BISTHETA(double &Root, int J, int M, int CL, int NITEMS,
              int ICUTOFF, int TRIES, double *DELTA, double **TAU, double **U,
              int *ColNoSelected)
{
    int L, I;
    double LOWER, UPPER, DER1, UDER, LDER, OLDLOW,INTERVAL,HALF,BINTV,DEN=0.0,
           LIKELY;
    char outline[81];

    //Find the bounds by spreaking out symetrically from the starting point.
    // The bounds are determined by finding two points fro which the first
    // derivative is opposite in sign.  Spread out in units of .05 as
    // defined by variable BINTV.  Spread out a maximum of tries * BINTV
    // units where variable TRIES is hard-coded as 100 and passed to this
    // subroutine.
    BINTV = 0.05;
    UPPER = LOWER = Root;
    for (L = 1; L <= TRIES; L++)
    {
        //Try the next pair of upper and lower bounds.  Determine the first
        //derivative for the upper and lower bounds and test to see if they
        //are of different signs.  Also, check to make sure that a bound is
        //not a root itself.
        UPPER += BINTV;
        LOWER -= BINTV;
        THETDER1(UPPER, DER1, M, CL, NITEMS, J, LIKELY, DELTA, U, TAU, ColNoSelected);
        UDER = DER1;
        THETDER1(LOWER, DER1, M, CL, NITEMS, J, LIKELY, DELTA, U, TAU, ColNoSelected);
        LDER = DER1;
        if (fabs(UDER) <= 0.001) Root = UPPER;
        if (fabs(LDER) <= 0.001) Root = LOWER;
        if ((Root == UPPER) || (Root == LOWER)) return;
        if ( (UDER * LDER) <= 0.0)
        {
            // If need be, call subroutine SWAP to make the upper bound
            // correspond to the positive first derivative and the lower bound
            // correspond to the negative first derivative.  Jump out of the
            // loop if appropriate bounds are not found.
            if ( (UDER < 0.0) && (LDER > 0.0)) SWAP(UPPER,LOWER);
            goto label20;
        }
    }
    // If appropriate bounds were not found, then use the average
    // item locations associated with endorsed items as the theta
    // estimate and print a messae.
    sprintf(outline,"Bounds for root could not be found in BISECTION for subject %d.",J);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Using weighted average of endorsed items.");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (I = 1; I <= NITEMS; I++)
    {
        int col = ColNoSelected[I-1];
        int X = atoi(MainForm->Grid->Cells[col][J].c_str());
        if (X >= ICUTOFF)
        {
            Root += double(X) * DELTA[I];
            DEN += double(X);
        }
    }
    Root /= DEN;
    sprintf(outline,"Weighted average = %16.8f",Root);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    return;
    // Bisect the interval defined by the bounds.  If the absolute value
    // of the first derivative is less than .001, then declare that bisected
    // value the root.  Also, if half the distance between the upper and
    // lower bound is less than or equal to .001, then declare the upper
    // bound the root.  Maintain the upper and lower bound so that the
    // lower bound corresponds to the negative derivative.  Iterate until
    // a root is declared.
label20:
    INTERVAL = UPPER - LOWER;
    HALF = INTERVAL / 2.0;
    if (fabs(HALF) <= 0.001)
    {
        Root = UPPER;
        return;
    }
    OLDLOW = LOWER;
    LOWER = LOWER + HALF;
    THETDER1(LOWER, DER1, M, CL, NITEMS, J, LIKELY, DELTA, U, TAU, ColNoSelected);
    if (fabs(DER1) <= 0.001)
    {
        Root = LOWER;
        return;
    }
    if (DER1 > 0.0)
    {
        UPPER = LOWER;
        LOWER = OLDLOW;
    }
    goto label20;
}
//--------------------------------------------------------------------------

void SWAP(double &A, double &B)
{
    double C;

    C = A;
    A = B;
    B = C;
}
//--------------------------------------------------------------------------

void THETDER1(double POINT, double &DER1, int M, int CL, int NITEMS, int J,
              double &LIKELY, double *DELTA, double **U, double **TAU,
              int *ColNoSelected)
{
    int I, H, W, X;
    double TMD, RESP, A, B, C, D, E, F, TERM1, TERM3, GAMMA, TAUSUM, DW, DM;

    DER1 = 0.0;
    LIKELY = 0.0;
    DM = double(M);
    for (I = 1; I <= NITEMS; I++)
    {
        TMD = POINT - DELTA[I];
        int col = ColNoSelected[I-1];
        RESP = atof(MainForm->Grid->Cells[col][J].c_str());
        X = int(RESP);
        B = exp(RESP * TMD);
        C = exp((DM - RESP) * TMD);
        TERM1 = 0.0;
        GAMMA = 0.0;
        for (W = 0; W <= CL; W++)
        {
            TAUSUM = 0.0;
            for (H = 0; H <= CL; H++) TAUSUM += (U[W][H] * TAU[I][H]);
            D = exp(-TAUSUM);
            DW = double(W);
            E = exp(DW * TMD);
            F = exp((DM - DW) * TMD);
            GAMMA += (D * (E + F));
            TERM1 += (D * ((E * DW) + (F * (DM - DW))));
        }
        TERM3 = (RESP * B) + (C * (DM - RESP));
        DER1 += ((TERM3 / (B + C)) - (TERM1 / GAMMA));
        TAUSUM = 0.0;
        for (H = 0; H <= CL; H++) TAUSUM += (U[X][H] * TAU[I][H]);
        A = -TAUSUM;
        LIKELY += (A + log(B + C) - log(GAMMA));
    }
}
//--------------------------------------------------------------------------

void BRUTE(int NSUBS, int NITEMS, int M, int CL, int ICUTOFF, double *THETA,
           double *DELTA, double **U, double **TAU, int *ColNoSelected)
{
    int I, J;
    double SCORE, COUNT, LIKELY, TMAX, LMAX, TCOUNT, POINT, DER1, SIGN, T,
           TOP;

    // This function performs a grid search to determine the maximum of the
    // log-liklihood function with respect to theta.  This is done for all
    // theta parameters.  The search is conducted on an interval that contains
    // the weighted average of the scale values of endorsed items where the
    // weights are the graded agree responses.  One side of the interval is
    // defined as two units less than the weighted average, whereas the other
    // side of the interval is defined as twice the absolute value of the
    // largest theta or delta value.  Thus, the probability of finding the
    // maximum of the log-liklihood within this interval is extremely high.
    // The interval is searched using a grid with steps of .05 units.  The
    // result of the grid search is also compared to the last theta estimate
    // derived from the Newton-Rhapson procedure, and the most likely of these
    // two estimates is retained.

    // Find the largest absolute theta estimate in the sample.  Store this
    // maximum in variable TMAX.
    TMAX = 0.0;
    for (J = 1; J <= NSUBS; J++) if (fabs(THETA[J]) > TMAX) TMAX = fabs(THETA[J]);
    // Find the largest absolute delta estimate in the sample.  Compare this
    // maximum to that for theta and retain the largest value in variable
    // TMAX.  Multiply the maximum value in variable TMAX by 2 and then round
    // to the nearest integer.
    for (I = 1; I <= NITEMS; I++) if (fabs(DELTA[I]) > TMAX) TMAX = fabs(DELTA[I]);
    TMAX *= 2.0;
    TMAX = ceil(TMAX);
    // Compute an approximate theta estimated based on a weighted average of
    // delta values associated with endorsed items.  The weights are the actual
    // graded responses.  Store this estimate in variable SCORE.  (Note that
    // in this context, an "endorsed item" is one with a response that is
    // greater than or equal to the user-defined threshold.)
    for (J = 1; J <= NSUBS; J++)
    {
        COUNT = 0.0;
        SCORE = 0.0;
        for (I = 1; I <= NITEMS; I++)
        {
            int col = ColNoSelected[I-1];
            int X = atof(MainForm->Grid->Cells[col][J].c_str());
            if (X >= ICUTOFF)
            {
                SCORE += (double(X) * DELTA[I]);
                COUNT += double(X);
            }
        }
        SCORE /= COUNT;
        // Determine the sign of the score variable.  Store this information
        // in variable SIGN.
        SIGN = 1.0;
        if (SCORE < 0.0) SIGN = -1.0;
        // Define one side of the search interval as 2 units above/below
        // (depending on sign) the score value.  Define the other side of
        // the search interval according to the TMAX variable (i.e., as
        // approximately 2 times the largest absolute theta/delta estimate.
        TCOUNT = floor(SCORE - (SIGN * 2.0));
        TOP = TMAX * SIGN;
        // Store the largest observed log-liklihood value in variable LMAX.
        LMAX = -3.4e1038;  // -HUGE(LMAX) ?????
        // Evaluate the log-liklihood of the score estimate and then do the
        // same forthe theta estimate previously derived with the Newton-
        // Rhapson procedure.  Store the most likely of these two estimates
        // in variable POINT.  Store the log-liklihood associated with this
        // POINT in LMAX.
        T = SCORE;
        THETDER1(T,DER1,M,CL,NITEMS,J,LIKELY,DELTA,U,TAU,ColNoSelected);
        if (LIKELY >= LMAX)
        {
            POINT = T;
            LMAX = LIKELY;
        }
        T = THETA[J];
        THETDER1(T, DER1,M,CL,NITEMS,J,LIKELY,DELTA,U,TAU,ColNoSelected);
        if (LIKELY >= LMAX)
        {
            POINT = T;
            LMAX = LIKELY;
        }
        SIGN = SIGN / 20.0;
        // Determine the log-liklihood of the grid values within the search
        // interval.  If thegrid values exhibit a higher log-liklihood than
        // the current maximum, then store this log-liklihood in variable
        // LMAX and store the grid point in variable POINT.
        for (T = TCOUNT; T == TOP; T=T+SIGN) // do 40 T=TCOUNT,TOP,SIGN ???
        {
           THETDER1(T,DER1,M,CL,NITEMS,J,LIKELY,DELTA,U,TAU,ColNoSelected);
           if (LIKELY >= LMAX)
           {
                POINT = T;
                LMAX = LIKELY;
           }
        }
        // Now, the most likely of 1) the score variable, 2) the previous
        // Newton-Rhapson theta estimate, and 3) the grid points of the
        // search interval have been determined.  Use this most likely estimate
        // as the starting value for a bisection algorithm.  This will yield
        // estimates that are more precise (i.e., estimated to within .002
        // of a maximum) relative to the grid points which were .05 units apart.
        BISTHETA(POINT,J,M,CL,NITEMS,ICUTOFF,100,DELTA,TAU,U,ColNoSelected);
        // Store the result in the theta variable for the given subject.
        THETA[J] = POINT;
    }
}
//--------------------------------------------------------------------------

void DIAGNO(double PARM, int NCAT, int NSUBS, int NITEMS, int M, double FITG,
            double PSGCUT, double ISGCUT, double PERFSH, double ICHPCT,
            double PCHPCT, int CL, double LOCFC)
{
    Application->MessageBox("Person Fit Statistics not available (yet).","SORRY!",MB_OK);
}

//--------------------------------------------------------------------------
void PlotTheta(double *THETA, int NSUBS)
{
    //Get 10 intervals
    double min, max, range, intvl, lower, upper;
    double proportion[10];
    int total = 0;

    for (int i = 0; i < 10; i++) proportion[i] = 0.0;

    min = THETA[1];
    max = THETA[1];
    for (int i = 1; i <= NSUBS; i++)
    {
        if (THETA[i] < min) min = THETA[i];
        if (THETA[i] > max) max = THETA[i];
    }
    range = max - min;
    intvl = range / 10;
    for (int i = 0; i < 10; i++) // proportion slot - get frequencies firts
    {
        lower = min + (intvl * double(i));
        upper = lower + intvl;
        for (int J = 1; J <= NSUBS; J++) // subject score loop
        {
            if ((THETA[J] >= lower) && (THETA[J] < upper))
            {
                proportion[i] += 1.0;
            }
        }
    }
    for (int i = 0; i < 10; i++) total += int(proportion[i]);
    for (int i = 0; i < 10; i++) proportion[i] /= double(total);
    // Allocate space for point sets of means
    try  {
            GetDblMatMem(GraphForm->Xpoints,1,10);
            GetDblMatMem(GraphForm->Ypoints,1,10);
    }
    catch (...)
    {
        ShowMessage("Memory Error.");
        return;
    }
    GraphForm->Heading = "SUBJECT THETA VALUES";
    char Title[80];
    sprintf(Title,"THETA: Min = %6.3f, Max = %6.3f, Interval = %6.3f",
       min, max, intvl);
    GraphForm->XTitle = Title;
    GraphForm->YTitle = "PROPORTION";
    GraphForm->nosets = 1;
    GraphForm->nbars = 10;
    GraphForm->barwideprop = 1.0;
    GraphForm->maxy = min;
    GraphForm->miny = max;
    GraphForm->AutoScale = true;
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clLtGray;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowLeftWall = true;
    GraphForm->ShowRightWall = true;
    GraphForm->ShowBottomWall = true;
    GraphForm->ShowBackWall = true;
    GraphForm->GraphType = 3;  // bar graph
    for (int i = 0; i < 10; i++)
    {
            GraphForm->Ypoints[0][i] = proportion[i];
            GraphForm->Xpoints[0][i] = i+1;
    }
    GraphForm->ShowModal();
    // clean up the heap
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
}
//--------------------------------------------------------------------------

void PlotDelta(double *DELTA, int NITEMS)
{
    //Get 10 intervals
    double min, max, range, intvl, lower, upper;
    double proportion[10];
    int total = 0;

    for (int i = 0; i < 10; i++) proportion[i] = 0.0;

    min = DELTA[1];
    max = DELTA[1];
    for (int i = 1; i <= NITEMS; i++)
    {
        if (DELTA[i] < min) min = DELTA[i];
        if (DELTA[i] > max) max = DELTA[i];
    }
    range = max - min;
    intvl = range / 10;
    for (int i = 0; i < 10; i++) // proportion slot - get frequencies firts
    {
        lower = min + (intvl * double(i));
        upper = lower + intvl;
        for (int J = 1; J <= NITEMS; J++) // subject score loop
        {
            if ((DELTA[J] >= lower) && (DELTA[J] < upper))
            {
                proportion[i] += 1.0;
            }
        }
    }
    for (int i = 0; i < 10; i++) total += int(proportion[i]);
    for (int i = 0; i < 10; i++) proportion[i] /= double(total);

    // Allocate space for point sets of means
    try  {
            GetDblMatMem(GraphForm->Xpoints,1,10);
            GetDblMatMem(GraphForm->Ypoints,1,10);
    }
    catch (...)
    {
        ShowMessage("Memory Error.");
        return;
    }
    GraphForm->Heading = "ITEM DELTA VALUES";
    char Title[80];
    sprintf(Title,"DELTA: Min = %6.3f, Max = %6.3f, Interval = %6.3f",
       min, max, intvl);
    GraphForm->XTitle = Title;
    GraphForm->YTitle = "PROPORTION";
    GraphForm->nosets = 1;
    GraphForm->nbars = 10;
    GraphForm->barwideprop = 1.0;
    GraphForm->miny = min;
    GraphForm->maxy = max;
    GraphForm->AutoScale = true;
    GraphForm->BackColor = clYellow;
    GraphForm->WallColor = clLtGray;
    GraphForm->FloorColor = clLtGray;
    GraphForm->ShowLeftWall = true;
    GraphForm->ShowRightWall = true;
    GraphForm->ShowBottomWall = true;
    GraphForm->ShowBackWall = true;
    GraphForm->GraphType = 3;  // bar graph
    for (int i = 0; i < 10; i++)
    {
        GraphForm->Ypoints[0][i] = proportion[i];
        GraphForm->Xpoints[0][i] = i+1;
    }
    GraphForm->ShowModal();
    // clean up the heap
    ClearDblMatMem(GraphForm->Xpoints,1);
    ClearDblMatMem(GraphForm->Ypoints,1);
}
//--------------------------------------------------------------------------
