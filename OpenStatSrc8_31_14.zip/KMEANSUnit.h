//---------------------------------------------------------------------------

#ifndef KMEANSUnitH
#define KMEANSUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TKMEANSForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ReturnBtn;
    TLabel *Label1;
    TEdit *NoClustersEdit;
    TLabel *Label2;
    TEdit *ItersEdit;
    TLabel *Label3;
    TListBox *ListBox1;
    TLabel *Label4;
    TBitBtn *VarInBtn;
    TBitBtn *VarOutBtn;
    TButton *AllBtn;
    TListBox *ListBox2;
    TGroupBox *GroupBox1;
    TCheckBox *StdChkBox;
    TCheckBox *RepChkBox;
    TCheckBox *DescChkBox;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall VarInBtnClick(TObject *Sender);
    void __fastcall VarOutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
private:	// User declarations
    void KMNS(double **A, int M, int N, double **C, int K, int *IC1, int *IC2, int *NC, double *AN1,
          double *AN2, int *NCP, double *D, int *ITRAN, int *LIVE, int ITER, double *WSS, int IFAULT);
    void OPTRA(double **A, int M, int N, double **C, int K, int *IC1, int *IC2, int *NC,
                 double *AN1, double *AN2, int *NCP, double *D, int *ITRAN, int *LIVE, int INDX);
    void QTRAN(double **A, int M, int N, double **C, int K, int *IC1, int *IC2, int *NC,
           double *AN1, double *AN2, int *NCP, double *D, int *ITRAN, int INDX);

public:		// User declarations
    __fastcall TKMEANSForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKMEANSForm *KMEANSForm;
//---------------------------------------------------------------------------
#endif
