//---------------------------------------------------------------------------

#ifndef ComboPermuteUnitH
#define ComboPermuteUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TComboPermutationsFrm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TEdit *Nedit;
        TEdit *Redit;
        TEdit *Pedit;
        TEdit *Cedit;
        TEdit *Fedit;
        TButton *ClearBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ClearBtnClick(TObject *Sender);
        void __fastcall ReturnBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        double TComboPermutationsFrm::logprods(unsigned __int64 StartAt,
               unsigned __int64 EndAt);

public:		// User declarations
        __fastcall TComboPermutationsFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TComboPermutationsFrm *ComboPermutationsFrm;
//---------------------------------------------------------------------------
#endif
