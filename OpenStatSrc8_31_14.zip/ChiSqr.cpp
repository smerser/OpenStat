//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "DataFuncs.h"
#include "ChiSqr.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TChiSFrm *ChiSFrm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TChiSFrm::TChiSFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TChiSFrm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Clear();
     RowEdit->Text = "";
     ColEdit->Text = "";
     DepEdit->Text = "";
     DepEdit->Visible = false;
     RowIn->Visible = true;
     RowOut->Visible = false;
     ColIn->Visible = true;
     ColOut->Visible = false;
     DepIn->Visible = false;
     DepOut->Visible = false;
     NCasesEdit->Text = "";
     NCasesEdit->Visible = false;
     Label4->Visible = false;
     Label5->Visible = false;
     InputGroup->ItemIndex = 0;
     for (i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TChiSFrm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::InputGroupClick(TObject *Sender)
{
     int index;

     index = InputGroup->ItemIndex;
     if (index == 2)  // only proportions available - get N size
     {
          Label4->Visible = true;
          NCasesEdit->Visible = true;
          NCasesEdit->SetFocus();
          DepIn->Visible = true;
          DepOut->Visible = false;
          DepEdit->Visible = true;
          Label5->Visible = true;
     }
     if (index == 1)  // frequencies available for each row and column combo
     {
         Label4->Visible = true;
         NCasesEdit->Visible = false;
         DepIn->Visible = true;
         DepOut->Visible = false;
         DepEdit->Visible = true;
         Label5->Visible = false;
     }
     if (index == 0)  // have to count cases in each row and col. combination
     {
          NCasesEdit->Visible = false;
          DepIn->Visible = false;
          DepOut->Visible = false;
          DepEdit->Visible = false;
          Label4->Visible = false;
          Label5->Visible = false;
     }
}
//---------------------------------------------------------------------------


void __fastcall TChiSFrm::RowInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     RowEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     RowIn->Visible = false;
     RowOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::RowOutClick(TObject *Sender)
{
     VarList->Items->Add(RowEdit->Text);
     RowEdit->Text = "";
     RowIn->Visible = true;
     RowOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::ColInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     ColEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     ColIn->Visible = false;
     ColOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::ColOutClick(TObject *Sender)
{
     VarList->Items->Add(ColEdit->Text);
     ColEdit->Text = "";
     ColIn->Visible = true;
     ColOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::DepInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     DepEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepIn->Visible = false;
     DepOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::DepOutClick(TObject *Sender)
{
     VarList->Items->Add(DepEdit->Text);
     DepEdit->Text = "";
     DepIn->Visible = true;
     DepOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TChiSFrm::ComputeBtnClick(TObject *Sender)
{
     int i, j, RowNo, ColNo, DepNo, MinRow, MaxRow, MinCol, MaxCol;
     int Row, Col, NoSelected, Ncases, Nrows, Ncols, FObs, df;
     AnsiString *RowLabels, *ColLabels;
     int *ColNoSelected;
     AnsiString cellstring;
     char outline[101];
     int **Freq;
     double **Prop, **Expected, **CellChi;
     double PObs, ChiSquare, ProbChi;
     bool yates;
     AnsiString title;
     AnsiString filename;
     double Adjchisqr, Adjprobchi, G;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     GetIntVecMem(ColNoSelected,NoVariables);
     yates = false;
     RowNo = 0;
     ColNo = 0;
     DepNo = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == RowEdit->Text) RowNo = i;
          if (cellstring == ColEdit->Text) ColNo = i;
          if (cellstring == DepEdit->Text) DepNo = i;
     }
     if ((RowNo == 0) || (ColNo == 0))
     {
        ShowMessage("ERROR! A row, column or variable label not entered.");
        delete[] ColNoSelected;
        return;
     }
/*
     result = VarTypeChk(RowNo,1);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
     result = VarTypeChk(ColNo,1);
     if (result == 1)
     {
        delete[] ColNoSelected;
        return;
     }
*/
     ColNoSelected[0] = RowNo;
     ColNoSelected[1] = ColNo;
     NoSelected = 2;
     if (InputGroup->ItemIndex > 0)  // for reading proportions or frequencies
     {
          NoSelected = 3;
          ColNoSelected[2] = DepNo;
     }
     // get min and max of row and col numbers
     MinRow = 1000;
     MaxRow = 0;
     MinCol = 1000;
     MaxCol = 0;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
          Row = floor(StrToFloat(Trim(MainForm->Grid->Cells[RowNo][i])));
          //result = GetValue(i,RowNo,intvalue,dblvalue,strvalue);
          //if (result == 1) Row = 0;
          //else Row = intvalue;
          Col = floor(StrToFloat(Trim(MainForm->Grid->Cells[ColNo][i])));
          //result = GetValue(i,ColNo,intvalue,dblvalue,strvalue);
          //if (result == 1) Col = 0;
          //else Col = intvalue;
          if (Row > MaxRow) MaxRow = Row;
          if (Row < MinRow) MinRow = Row;
          if (Col > MaxCol) MaxCol = Col;
          if (Col < MinCol) MinCol = Col;
     }
     Nrows = MaxRow - MinRow + 1;
     Ncols = MaxCol - MinCol + 1;

     // allocate and initialize
     GetIntMatMem(Freq,Nrows+1,Ncols+1);
     GetDblMatMem(Prop,Nrows+1,Ncols+1);
     GetDblMatMem(Expected,Nrows,Ncols);
     GetDblMatMem(CellChi,Nrows,Ncols);
     RowLabels = new AnsiString[Nrows+1];
     ColLabels = new AnsiString[Ncols+1];
     for (i = 1; i <= Nrows + 1; i++)
         for (j = 1; j <= Ncols + 1; j++) Freq[i-1][j-1] = 0;
    for (i = 1; i <= Nrows; i++)
    {
        sprintf(outline,"Row %d",i);
        cellstring = outline;
        RowLabels[i-1] = cellstring;
    }
    RowLabels[Nrows] = "Total";
    for (j = 1; j <= Ncols; j++)
    {
        sprintf(outline,"COL. %d",j);
        cellstring = outline;
        ColLabels[j-1] = cellstring;
    }
    ColLabels[Ncols] = "Total";

     // get cell data
     Ncases = 0;
     switch (InputGroup->ItemIndex)
     {
        case 0 :  // count number of cases in each row and column combination
        {
              for (i = 1; i <= NoCases; i++)
              {
                   if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                   Ncases = Ncases + 1;
                   Row = ceil(StrToFloat(Trim(MainForm->Grid->Cells[RowNo][i])));
                   Col = ceil(StrToFloat(Trim(MainForm->Grid->Cells[ColNo][i])));
                   Row = Row - MinRow + 1;
                   Col = Col - MinCol + 1;
                   Freq[Row-1][Col-1] = Freq[Row-1][Col-1] + 1;
              }
              break;
        }
        case 1 :  // read frequencies data from grid
        {
/*              result = VarTypeChk(DepNo,1);
              if (result == 1)
              {
                   delete[] ColNoSelected;
                   return;
              }*/
              for (i = 1; i <= NoCases; i++)
              {
                   if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                   Row = floor(StrToFloat(Trim(MainForm->Grid->Cells[RowNo][i])));
                   Col = floor(StrToFloat(Trim(MainForm->Grid->Cells[ColNo][i])));
                   Row = Row - MinRow + 1;
                   Col = Col - MinCol + 1;
                   FObs = floor(StrToFloat(Trim(MainForm->Grid->Cells[DepNo][i])));
                   //result = GetValue(i,DepNo,intvalue,dblvalue,strvalue);
                   //if (result == 1) FObs = 0;
                   //else FObs = intvalue;
                   Freq[Row-1][Col-1] = Freq[Row-1][Col-1] + FObs;
                   Ncases = Ncases + FObs;
              }
              break;
         }
        case 2 :  // get no. of cases and proportions for each cell
        {
              Ncases = StrToInt(NCasesEdit->Text);
/*
              result = VarTypeChk(DepNo,0);
              if (result == 1)
              {
                   delete[] ColNoSelected;
                   return;
              }
*/
              for (i = 1; i <= NoCases; i++)
              {
                   if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                   Row = floor(StrToFloat(Trim(MainForm->Grid->Cells[RowNo][i])));
                   Col = floor(StrToFloat(Trim(MainForm->Grid->Cells[ColNo][i])));
                   Row = Row - MinRow + 1;
                   Col = Col - MinCol + 1;
                   PObs = StrToFloat(Trim(MainForm->Grid->Cells[DepNo][i]));
                   //result = GetValue(i,DepNo,intvalue,dblvalue,strvalue);
                   //if (result == 1) PObs = 0;
                   //else PObs = dblvalue;
                   int Frq = floor(PObs * Ncases);
                   double Fval = PObs * Ncases;
                   if (Fval - Frq < 0.5) Frq = floor(Fval);
                   else Frq = ceil(Fval);
                   Freq[Row-1][Col-1] = Freq[Row-1][Col-1] + Frq;
              }
         }break;
     } // end switch
     Freq[Nrows][Ncols] = Ncases;

     // Now, calculate expected values
     // Get row totals first
     for (i = 1; i <= Nrows; i++)
     {
          for (j = 1; j <= Ncols; j++)
          {
               Freq[i-1][Ncols] = Freq[i-1][Ncols] + Freq[i-1][j-1];
          }
     }
     // Get col totals next
     for (j = 1; j <= Ncols; j++)
     {
         for (i = 1; i <= Nrows; i++)
         {
             Freq[Nrows][j-1] = Freq[Nrows][j-1] + Freq[i-1][j-1];
         }
     }

     // Then get expected values and cell chi-squares
     ChiSquare = 0.0;
     Adjchisqr = 0.0;
     if ((YatesChk->Checked) && (Nrows == 2) && (Ncols == 2)) yates = true;
     if ((Nrows > 1) && (Ncols > 1))
     {
        for (i = 1; i <= Nrows; i++)
        {
          for (j = 1; j <= Ncols; j++)
          {
               Expected[i-1][j-1] = (double) Freq[Nrows][j-1] * (double) Freq[i-1][Ncols] / (double)Ncases;
               if (Expected[i-1][j-1] > 0.0)
                  CellChi[i-1][j-1] = sqr((double)Freq[i-1][j-1] - Expected[i-1][j-1])
                                    / Expected[i-1][j-1];
               else
               {
                    ShowMessage("ERROR! Zero expected value found.");
                    CellChi[i-1][j-1] = 0.0;
               }
               ChiSquare = ChiSquare + CellChi[i-1][j-1];
          }
        }
        df = (Nrows - 1) * (Ncols - 1);
        if (yates == true)  // 2 x 2 corrected chi-square
        {
          Adjchisqr = fabs((Freq[0][0] * Freq[1][1]) - (Freq[0][1] * Freq[1][0]));
          Adjchisqr = sqr(Adjchisqr - Ncases / 2.0) * Ncases; // numerator
          Adjchisqr = Adjchisqr / (Freq[0][2] * Freq[1][2] * Freq[2][0] * Freq[2][1]);
          Adjprobchi = 1.0 - chisquaredprob(Adjchisqr,df);
        }
     }
     if (Nrows == 1) // equal probability
     {
        for (j = 0; j < Ncols; j++)
        {
                Expected[0][j] = (double) Ncases / (double) Ncols;
                if (Expected[0][j] > 0)
                   CellChi[0][j] = sqr((double)Freq[0][j] - Expected[0][j]) / Expected[0][j];
                ChiSquare += CellChi[0][j];
        }
        df = Ncols - 1;
     }

     if (Ncols == 1) // equal probability
     {
        for (i = 0; i < Nrows; i++)
        {
                Expected[i][0] = (double) Ncases / (double) Nrows;
                if (Expected[i][0] > 0)
                   CellChi[i][0] = sqr((double)Freq[i][0] - Expected[i][0]) / Expected[i][0];
                ChiSquare += CellChi[i][0];
        }
        df = Nrows - 1;
     }

     ProbChi = 1.0 - chisquaredprob(ChiSquare,df); // prob. larger chi

    //Print results to output form
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Chi-square Analysis Results for " + RowEdit->Text + " and " + ColEdit->Text);
    sprintf(outline,"No. of Cases = %d",Ncases);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    // print tables requested by use
    if (ObsChk->Checked)
    {
       IntArrayPrint(Freq, Nrows+1, Ncols+1,"Frequencies",
                     RowLabels, ColLabels,"OBSERVED FREQUENCIES");
    }

    if (ExpChk->Checked)
    {
         strcpy(outline,"EXPECTED FREQUENCIES");
         ArrayPrint(Expected, Nrows, Ncols, "Expected Values", RowLabels, ColLabels,
                    outline);
    }

    if (PropChk->Checked)
    {
         strcpy(outline,"ROW PROPORTIONS");
         for (i = 1; i <= Nrows + 1; i++)
         {
              for (j = 1; j <= Ncols; j++)
              {
                   if (Freq[i-1][Ncols] > 0.0)
                        Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[i-1][Ncols];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[i-1][Ncols] > 0.0)  Prop[i-1][Ncols] = 1.0;
              else Prop[i-1][Ncols] = 0.0;
         }
         ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
         strcpy(outline,"COLUMN PROPORTIONS");
         for (j = 1; j <= Ncols + 1; j++)
         {
              for (i = 1; i <= Nrows; i++)
              {
                   if (Freq[Nrows][j-1] > 0.0)
                       Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double)Freq[Nrows][j-1];
                   else Prop[i-1][j-1] = 0.0;
              }
              if (Freq[Nrows][j-1] > 0.0)  Prop[Nrows][j-1] = 1.0;
              else Prop[Nrows][j-1] = 0.0;
         }
         ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
         strcpy(outline,"PROPORTIONS OF TOTAL N");
         for (i = 1; i <= Nrows + 1; i++)
              for (j = 1; j <= Ncols + 1; j++) Prop[i-1][j-1] = (double) Freq[i-1][j-1] / (double) Ncases;
         Prop[Nrows][Ncols] = 1.0;
         ArrayPrint(Prop, Nrows+1, Ncols+1, "Proportions", RowLabels, ColLabels,
                    outline);
    }

    if (ChiChk->Checked)
    {
         strcpy(outline,"CHI-SQUARED VALUE FOR CELLS");
         ArrayPrint(CellChi, Nrows, Ncols, "Chi-square Values", RowLabels, ColLabels,
                    outline);
    }

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Chi-square = %8.3f with D.F. = %d. Prob. > value = %8.3f",
                    ChiSquare,df,ProbChi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    if (yates == true)
    {
         sprintf(outline,"Chi-square using Yates correction = %8.3f and Prob > value = %8.3f",
                 Adjchisqr,Adjprobchi);
         FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    double liklihood = 0.0;
    for (int i = 0; i < Nrows; i++)
        for (int j = 0; j < Ncols; j++)
             if (Freq[i][j] > 0.0) liklihood += (double)Freq[i][j] * (log(Expected[i][j] / (double)Freq[i][j]));
    liklihood = -2.0 * liklihood;
    double probliklihood = 1.0 - chisquaredprob(liklihood,df);
    sprintf(outline,"Liklihood Ratio = %8.3f with prob. > value = %6.4f",
            liklihood,probliklihood);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    G = 0.0;
    for (int i = 0; i < Nrows; i++)
        for (int j = 0; j < Ncols; j++)
                if (Expected[i][j] > 0) G += (double)Freq[i][j] * (log((double)Freq[i][j] / Expected[i][j]));
    G = 2.0 * G;
    probliklihood = 1.0 - chisquaredprob(G,df);
    sprintf(outline,"G statistic = %8.3f with prob. > value = %6.4f",G,probliklihood);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    if ((Nrows > 1) && (Ncols > 1))
    {
        double phi = sqrt(ChiSquare / (double) Ncases);
        sprintf(outline,"phi correlation = %6.4f",phi);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double pearsonr = 0.0;
        double SumX = 0.0;
        double SumY = 0.0;
        double VarX = 0.0;
        double VarY = 0.0;
        for (int i = 0; i < Nrows; i++) SumX += ( (double)(i+1) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) SumY += ( (double)(j+1) * (double) Freq[Nrows][j] );
        for (int i = 0; i < Nrows; i++) VarX += ( (double)((i+1)*(i+1)) * (double) Freq[i][Ncols] );
        for (int j = 0; j < Ncols; j++) VarY += ( (double)((j+1)*(j+1)) * (double) Freq[Nrows][j] );
        VarX = VarX - ((SumX * SumX) / (double) Ncases);
        VarY = VarY - ((SumY * SumY) / (double) Ncases);
        for (int i = 0; i < Nrows; i++)
                for (int j = 0; j < Ncols; j++)
                        pearsonr += (double) ((i+1)*(j+1) * Freq[i][j]);
        pearsonr = pearsonr - (SumX * SumY / (double) Ncases);
        pearsonr = pearsonr / sqrt(VarX * VarY);
        sprintf(outline,"Pearson Correlation r = %6.4f",pearsonr);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double MantelHaenszel = (double) (Ncases-1) * (pearsonr * pearsonr);
        double MHprob = 1.0 - chisquaredprob(MantelHaenszel,1);
        sprintf(outline,"Mantel-Haenszel Test of Linear Association = %8.3f with probability > value = %6.4f",
            MantelHaenszel, MHprob);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CoefCont = sqrt(ChiSquare / (ChiSquare + (double) Ncases));
        sprintf(outline,"The coefficient of contingency = %8.3f",CoefCont);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");

        double CramerV;
        if (Nrows < Ncols) CramerV = sqrt(ChiSquare / (Ncases * ((double) (Nrows-1))));
        else CramerV = sqrt(ChiSquare / (Ncases * ((double) (Ncols-1))));
        sprintf(outline,"Cramer's V = %8.3f",CramerV);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Clear();

    // save frequency data file if elected
    if ((SaveChk->Checked) && (InputGroup->ItemIndex == 0))
    {
       CloseFile();
       for (int i = 1; i <= 3; i++) NewVar(i,false);
       DictionaryForm->DGrid->Cells[1][1] = "ROW";
       DictionaryForm->DGrid->Cells[1][2] = "COL";
       DictionaryForm->DGrid->Cells[1][3] = "FREQ.";
       MainForm->Grid->Cells[1][0] = "ROW";
       MainForm->Grid->Cells[2][0] = "COL";
       MainForm->Grid->Cells[3][0] = "Freq.";
       int k = 1;
       for (int i = 1; i <= Nrows; i++)
       {
           for (int j = 1; j <= Ncols; j++)
           {
               MainForm->Grid->RowCount = k + 1;
               MainForm->Grid->Cells[1][k] = IntToStr(i);
               MainForm->Grid->Cells[2][k] = IntToStr(j);
               MainForm->Grid->Cells[3][k] = IntToStr(Freq[i-1][j-1]);
               k++;
           }
       }
       for (int i = 1; i < k; i++)
       {
           title = "CASE " + IntToStr(i);
           MainForm->Grid->Cells[0][i] = title;
       }
       title = InputBox("FILE:","File Name:","Frequencies.OS4");
       MainForm->FileNameEdit->Text = title;
       MainForm->NoVarsEdit->Text = IntToStr(3);
       MainForm->NoCasesEdit->Text = k-1;
       NoVariables = 3;
       NoCases = k-1;
       SaveOSFile();
    }

    //clean up
    delete[] ColLabels;
    delete[] RowLabels;
    ClearDblMatMem(CellChi,Nrows);
    ClearDblMatMem(Expected,Nrows);
    ClearDblMatMem(Prop,Nrows+1);
    ClearIntMatMem(Freq,Nrows+1);
    delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

