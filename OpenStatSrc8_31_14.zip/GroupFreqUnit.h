//---------------------------------------------------------------------------

#ifndef GroupFreqUnitH
#define GroupFreqUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TGroupFreqForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *Varlist;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TBitBtn *GrpInBtn;
     TBitBtn *GrpOutBtn;
     TLabel *Label3;
     TEdit *GrpVarEdit;
     TRadioGroup *PlotGrp;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall GrpInBtnClick(TObject *Sender);
     void __fastcall GrpOutBtnClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TGroupFreqForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGroupFreqForm *GroupFreqForm;
//---------------------------------------------------------------------------
#endif
