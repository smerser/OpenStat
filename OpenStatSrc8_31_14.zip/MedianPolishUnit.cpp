//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "OutPut.h"
#include "math.h"
#include "functions.h"
#include "GraphUnit.h"
#include "MedianPolishUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMedianPolishForm *MedianPolishForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TMedianPolishForm::TMedianPolishForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

double TMedianPolishForm::Median(double *X, int size)
{
        int midpt, i;
        double value;

        if (size > 2)
        {
                midpt = size / 2;
                if ((2 * midpt) == size) value = (X[midpt-1] + X[midpt]) / 2.0;
                else value = X[midpt];
        }
        else if (size == 2) value = (X[0] + X[1]) / 2.0;
        return (value);
}
//---------------------------------------------------------------------------

void TMedianPolishForm::PrintObsTable(double **ObsTable, int nrows, int ncols)
{
        char outline[101];
        char cellstring[20];
        int i, j;

        FrmOutPut->RichOutPut->Lines->Add("Observed Data");
        FrmOutPut->RichOutPut->Lines->Add("ROW            COLUMNS");
        StrCopy(outline,"  ");
        for (i = 1; i <= ncols; i++)
        {
                sprintf(cellstring,"%10d",i);
                StrCat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        for (i = 1; i <= nrows; i++)
        {
                sprintf(cellstring,"%3d ",i);
                StrCopy(outline,cellstring);
                for (j = 1; j <= ncols; j++)
                {
                        sprintf(cellstring,"%9.3f ",ObsTable[i-1][j-1]);
                        StrCat(outline,cellstring);
                }
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
}

//----------------------------------------------------------------------------

void TMedianPolishForm::PrintResults(double **ObsTable, double *rowmedian,
             double *rowresid, double *colmedian, double *colresid,
             int nrows, int ncols)
{
        int i, j;
        char cellstring[20];
        char outline[101];

        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Adjusted Data");
        StrCopy(outline,"Median");
        for (i = 1; i <= ncols; i++)
        {
                sprintf(cellstring,"%10d",i);
                StrCat(outline,cellstring);
        }
        StrCat(outline,"      Residuals");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("--------------------------------------------------------------");
        for (i = 0; i < nrows; i++)
        {
                sprintf(cellstring,"%9.3f ",rowmedian[i]);
                StrCopy(outline,cellstring);
                for (j = 0; j < ncols; j++)
                {
                        sprintf(cellstring,"%9.3f ",ObsTable[i][j]);
                        StrCat(outline,cellstring);
                }
                sprintf(cellstring,"%9.3f ",rowresid[i]);
                StrCat(outline,cellstring);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
        StrCopy(outline,"Col.Resid.");
        for (j = 0; j < ncols; j++)
        {
                sprintf(cellstring,"%9.3f ",colresid[j]);
                StrCat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        StrCopy(outline,"Col.Median");
        for (j = 0; j < ncols; j++)
        {
                sprintf(cellstring,"%9.3f ",colmedian[j]);
                StrCat(outline,cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Cumulative absolute value of Row Residuals");
        for (j = 0; j < nrows; j++)
        {
                sprintf(cellstring,"Row = %d  Cum.Residuals = %9.3f",j+1,CumRowResiduals[j]);
                FrmOutPut->RichOutPut->Lines->Add(cellstring);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("Cumulative absolute value of Column Residuals");
        for (j = 0; j < ncols; j++)
        {
                sprintf(outline,"Column = %d  Cum.Residuals = %9.3f",j+1,CumColResiduals[j]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
}

//---------------------------------------------------------------------------

void TMedianPolishForm::sortvalues(double *X, int size)
{
        int i, j;
        double temp;

        for (i = 0; i < size-1; i++)
        {
                for (j = i+1; j < size; j++)
                {
                        if (X[i] > X[j]) // swap
                        {
                                temp = X[i];
                                X[i] = X[j];
                                X[j] = temp;
                        }
                }
        }
}

//----------------------------------------------------------------------------
void __fastcall TMedianPolishForm::ResetBtnClick(TObject *Sender)
{
        int i;

        VarList->Clear();
        for (i = 1; i <= NoVariables; i++)
                VarList->Items->Add(MainForm->Grid->Cells[i][0]);
        DepVar->Text = "";
        Factor1->Text = "";
        Factor2->Text = "";
        DepIn->Visible = true;
        DepOut->Visible = false;
        Fact1In->Visible = true;
        Fact1Out->Visible = false;
        Fact2In->Visible = true;
        Fact2Out->Visible = false;
        ItersBtn->Checked = false;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::DepInClick(TObject *Sender)
{
       int index;

        index = VarList->ItemIndex;
        DepVar->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        DepIn->Visible = false;
        DepOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::DepOutClick(TObject *Sender)
{
        VarList->Items->Add(DepVar->Text);
        DepVar->Text = "";
        DepIn->Visible = true;
        DepOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::Fact1InClick(TObject *Sender)
{
       int index;

        index = VarList->ItemIndex;
        Factor1->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        Fact1In->Visible = false;
        Fact1Out->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::Fact1OutClick(TObject *Sender)
{
       VarList->Items->Add(Factor1->Text);
        Factor1->Text = "";
        Fact1In->Visible = false;
        Fact1Out->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::Fact2InClick(TObject *Sender)
{
       int index;

        index = VarList->ItemIndex;
        Factor2->Text = VarList->Items->Strings[index];
        VarList->Items->Delete(index);
        Fact2In->Visible = false;
        Fact2Out->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::Fact2OutClick(TObject *Sender)
{
       VarList->Items->Add(Factor2->Text);
        Factor2->Text = "";
        Fact2In->Visible = false;
        Fact2Out->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TMedianPolishForm::ComputeBtnClick(TObject *Sender)
{
        int NoSelected, DepVarCol, F1Col, F2Col, i, j, k;
        int NoRows, NoCols, minrow, maxrow, mincol, maxcol;
        int intvalue, xrange, yrange, row, col, N, count;
        double X, Resid, M, sumrowmedians, sumcolmedians;
        int *ColNoSelected;
        double ***Observed, ***Residuals;
        double *RowResiduals, *ColResiduals, *RowMedian, *ColMedian;
        double *RowEffects, *ColEffects;
        int **CellCount;
        double *GroupScores;
        double **ObsTable;
        AnsiString cellstring;
        char outline[101];
        bool single;
        int NoIterations, iteration;
        bool done;
        double Q1,Q3, Qrange1, Qrange2;
        double *WholeTable;

        for (i = 1; i <= NoVariables; i++)
        {
                cellstring = Trim(MainForm->Grid->Cells[i][0]);
                if (cellstring == DepVar->Text) DepVarCol = i;
                if (cellstring == Factor1->Text) F1Col = i;
                if (cellstring == Factor2->Text) F2Col = i;
        }
        NoSelected = 3;
        ColNoSelected = new int[3];
        ColNoSelected[0] = DepVarCol;
        ColNoSelected[1] = F1Col;
        ColNoSelected[2] = F2Col;
        // Get no. of rows and columns in Factors 1 and 2
        mincol = 10000;
        maxcol = 0;
        minrow = 10000;
        maxrow = 0;
        for (i = 1; i <= NoCases; i++)
        {
                intvalue = StrToInt(Trim(MainForm->Grid->Cells[F1Col][i]));
                if (intvalue > maxrow) maxrow = intvalue;
                if (intvalue < minrow) minrow = intvalue;
                intvalue = StrToInt(Trim(MainForm->Grid->Cells[F2Col][i]));
                if (intvalue > maxcol) maxcol = intvalue;
                if (intvalue < mincol) mincol = intvalue;
        }
        xrange = maxrow - minrow + 1;
        yrange = maxcol - mincol + 1;
        // Get no. of observations in each cell
        GetIntMatMem(CellCount,xrange,yrange);
        for (i = 0; i < xrange; i++)
                for (j = 0; j < yrange; j++) CellCount[i][j] = 0;
        count = 0;
        single = false;
        for (i = 1; i <= NoCases; i++)
        {
                row = StrToInt(Trim(MainForm->Grid->Cells[F1Col][i]));
                row = row - minrow;
                col = StrToInt(Trim(MainForm->Grid->Cells[F2Col][i]));
                col = col - mincol;
                CellCount[row][col] = CellCount[row][col] + 1;
                count = count + 1;
        }
        if (count == (xrange * yrange)) single = true;
        GetDblCubeMem(Observed,NoCases,xrange,yrange);
        GetDblCubeMem(Residuals,NoCases,xrange,yrange);
        RowResiduals = new double[xrange];
        ColResiduals = new double[yrange];
        GroupScores = new double[NoCases];
        RowMedian = new double[xrange];
        ColMedian = new double[yrange];
        CumRowResiduals = new double[xrange];
        CumColResiduals = new double[yrange];
        RowEffects = new double[xrange];
        ColEffects = new double[yrange];
        WholeTable = new double[xrange*yrange];

        for (i = 0; i < NoCases; i++)
        {
                for (j = 0; j < xrange; j++)
                {
                        for (k = 0; k < yrange; k++)
                        {
                                Observed[i][j][k] = 0.0;
                                Residuals[i][j][k] = 0.0;
                        }
                }
        }
        for (j = 0; j < xrange; j++)
        {
                RowResiduals[j] = 0.0;
                CumRowResiduals[j] = 0.0;
                RowEffects[j] = 0.0;
        }
        for (j = 0; j < yrange; j++)
        {
                ColResiduals[j] = 0.0;
                CumColResiduals[j] = 0.0;
                ColEffects[j] = 0.0;
        }
        for (i = 0; i < xrange; i++)
                for (j = 0; j < yrange; j++) CellCount[i][j] = 0;
        // Get the observed scores
        for (i = 1; i <= NoCases; i++)
        {
                row = StrToInt(Trim(MainForm->Grid->Cells[F1Col][i]));
                row = row - minrow;
                col = StrToInt(Trim(MainForm->Grid->Cells[F2Col][i]));
                col = col - mincol;
                CellCount[row][col] = CellCount[row][col] + 1;
                N = CellCount[row][col];
                X = StrToFloat(Trim(MainForm->Grid->Cells[DepVarCol][i]));
                Observed[N-1][row][col] = X;
        }
        // if not a single case in each cell, get the median for each cell
        if (!single)
        {
                for (i = 0; i < xrange; i++)
                {
                        for (j = 0; j < yrange; j++)
                        {
                                for (k = 0; k < CellCount[i][j]; k++)
                                        GroupScores[k] = Observed[k][i][j];
                                M = Median(GroupScores,CellCount[i][j]);
                                Observed[0][i][j] = M;
                        }
                }
        }
        GetDblMatMem(ObsTable,xrange,yrange);
        for (i = 0; i < xrange; i++)
                for (j = 0; j < yrange; j++) ObsTable[i][j] = Observed[0][i][j];
        FrmOutPut->RichOutPut->Clear();
        PrintObsTable(ObsTable,xrange,yrange);
        FrmOutPut->ShowModal();
        k = 0;
        for (i = 0; i < xrange; i++)
        {
                for (j = 0; j < yrange; j++)
                {
                        WholeTable[k] = Observed[0][i][j];
                        k = k + 1;
                }
        }
        sortvalues(WholeTable,xrange*yrange);
        Q1 = Quartiles(2,0.25,xrange*yrange,WholeTable);
        Q3 = Quartiles(2,0.75,xrange*yrange,WholeTable);
        Qrange1 = Q3 - Q1;
        sprintf(outline,"Quartiles of original data = %8.3f %8.3f",Q1,Q3);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        iteration = 1;
        NoIterations = StrToInt(MaxEdit->Text);
        done = false;
        while (!done) // Get the residuals from the median for each row
        {
                FrmOutPut->RichOutPut->Lines->Add("");
                sprintf(outline,"Iteration = %d",iteration);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                count = 0;
                for (i = 0; i < xrange; i++)
                {
                        count = 0;
                        for (j = 0; j < yrange; j++)
                        {
                                GroupScores[count] = Observed[0][i][j];
                                count = count + 1;
                        }
                        sortvalues(GroupScores,count);
                        M = Median(GroupScores,count);
                        RowMedian[i] = M;
                        for (j = 0; j < yrange; j++) Observed[0][i][j] = Observed[0][i][j] - M;
                        for (j = 0; j < yrange; j++) RowResiduals[i] = RowResiduals[i] +
                           Observed[0][i][j];
                        CumRowResiduals[i] = CumRowResiduals[i] + fabs(RowResiduals[i]);
                }

                // Get sum of residuals for columns
                count = 0;
                for (i = 0; i < yrange; i++)
                {
                        count = 0;
                        for (j = 0; j < xrange; j++)
                        {
                                GroupScores[count] = Observed[0][j][i];
                                count = count + 1;
                        }
                        sortvalues(GroupScores,count);
                        M = Median(GroupScores,count);
                        ColMedian[i] = M;
                        for (j = 0; j < xrange; j++) Observed[0][j][i] =
                           Observed[0][j][i] - M;
                        for (j = 0; j < xrange; j++) ColResiduals[i] =
                           ColResiduals[i] + Observed[0][j][i];
                        CumColResiduals[i] = CumColResiduals[i] + fabs(ColResiduals[i]);
                }

                // build table of results
                for (i = 0; i < xrange; i++)
                {
                        for (j = 0; j < yrange; j++)
                        {
                                ObsTable[i][j] = Observed[0][i][j];
                        }
                }
//                if (ItersBtn->Checked)
//                {
                        PrintResults(ObsTable,RowMedian,RowResiduals,
                          ColMedian, ColResiduals,xrange,yrange);
                        FrmOutPut->RichOutPut->Lines->Add("");
                        for (i = 0; i < xrange; i++) GroupScores[i] = RowMedian[i];
                        sortvalues(GroupScores,xrange);
                        M = Median(GroupScores,xrange);
                        sprintf(outline,"Overall Median = %8.3f",M);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        for (i = 0; i < xrange; i++)
                        {
                                RowEffects[i] = RowEffects[i] + (RowMedian[i] - M);
                                sprintf(outline,"Row %d Effect = %8.3f",i+1,RowEffects[i]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                        FrmOutPut->RichOutPut->Lines->Add("");
                        FrmOutPut->RichOutPut->Lines->Add("Column Effects");
                        for (j = 0; j < yrange; j++)
                        {
                                ColEffects[j] = ColEffects[j] + ColMedian[j];
                                sprintf(outline,"Col. %d Effect = %8.3f",j+1,ColEffects[j]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
//                        FrmOutPut->ShowModal();
//                        FrmOutPut->RichOutPut->Clear();
//                }
                for (i = 0; i < xrange; i++) RowResiduals[i] = 0.0;
                for (j = 0; j < yrange; j++) ColResiduals[j] = 0.0;
                NoIterations = NoIterations - 1;
                iteration = iteration + 1;
                if (NoIterations = 0) done = true;
                sumrowmedians = 0.0;
                sumcolmedians = 0.0;
                for (i = 0; i < xrange; i++) sumrowmedians = sumrowmedians +
                   RowMedian[i];
                for (i = 0; i < yrange; i++) sumcolmedians = sumcolmedians +
                   ColMedian[i];
                if ((sumrowmedians + sumcolmedians) == 0.0) done = true;
                if (done)
                {
                        FrmOutPut->RichOutPut->Lines->Add("");
                        FrmOutPut->RichOutPut->Lines->Add("SUMMARY");
                        PrintResults(ObsTable,RowMedian,RowResiduals,ColMedian,
                            ColResiduals,xrange,yrange);
                        for (i = 0; i < xrange; i++)
                        {
                                RowEffects[i] = RowEffects[i] + (RowMedian[i] - M);
                                sprintf(outline,"Row %d Effect = %8.3f",i+1,RowEffects[i]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                        FrmOutPut->RichOutPut->Lines->Add("");
                        FrmOutPut->RichOutPut->Lines->Add("Column Effects");
                        for (j = 0; j < yrange; j++)
                        {
                                ColEffects[j] = ColEffects[j] + ColMedian[j];
                                sprintf(outline,"Col. %d Effect = %8.3f",j+1,ColEffects[j]);
                                FrmOutPut->RichOutPut->Lines->Add(outline);
                        }
                        k = 0;
                        FrmOutPut->RichOutPut->Lines->Add("");
                        for (i = 0; i < xrange; i++)
                        {
                                for (j = 0; j < yrange; j++)
                                {
                                        WholeTable[k] = ObsTable[i][j];
                                        k = k + 1;
                                }
                        }
                        sortvalues(WholeTable,xrange*yrange);
                        M = Median(WholeTable,xrange*yrange);
                        Q1 = Quartiles(2,0.25,xrange*yrange,WholeTable);
                        Q3 = Quartiles(2,0.75,xrange*yrange,WholeTable);
                        sprintf(outline,"Quartiles of the residuals = %8.3f %8.3f",
                                Q1, Q3);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        Qrange2 = Q3 - Q1;
                        sprintf(outline,"Original interquartile and final interquartile ranges = %8.3f %8.3f",
                                Qrange1, Qrange2);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        sprintf(outline,"Quality of the additive fit = %8.3f percent",
                                100 * (Qrange1 - Qrange2) / Qrange1);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        FrmOutPut->ShowModal();
                        FrmOutPut->RichOutPut->Clear();
                }
        }
//        if (ItersBtn->Checked)
//        {
                TwoWayPlot(xrange, RowEffects,"Rows","CUMULATIVE ROW EFFECTS");
                TwoWayPlot(yrange, ColEffects,"Columns","CUMULATIVE COL. EFFECTS");
                InteractPlot(xrange, yrange, ObsTable, "Interaction",
                    "RESIDUALS OF ROWS AND COLUMNS");
//        }

        // cleanup
        delete[] WholeTable;
        delete[] ColEffects;
        delete[] RowEffects;
        ClearDblMatMem(ObsTable,xrange);
        delete[] CumColResiduals;
        delete[] CumRowResiduals;
        delete[] ColMedian;
        delete[] RowMedian;
        delete[] GroupScores;
        delete[] ColResiduals;
        delete[] RowResiduals;
        ClearDblCubeMem(Residuals,NoCases,xrange);
        ClearDblCubeMem(Observed,NoCases,xrange);
}
//---------------------------------------------------------------------------

void  TMedianPolishForm::TwoWayPlot(int NF1cells, double *RowSums,
           AnsiString graphtitle, AnsiString Heading)
{
   int i, j;
   double minmean, maxmean, XBar;
   double *XValue;
   AnsiString title;
   int plottype;
   char setstring[11];

     XValue = new double[NF1cells];
     plottype = 3;
     strcpy(setstring,"Group");
     GraphForm->SetLabels[1] = setstring;
     maxmean = -10000.0;
     minmean = 10000.0;
     GetDblMatMem(GraphForm->Xpoints,1,NF1cells);
     GetDblMatMem(GraphForm->Ypoints,1,NF1cells);
     for (i = 1; i <= NF1cells; i++)
     {
          GraphForm->Ypoints[0][i-1] = RowSums[i-1];
          if (RowSums[i-1] > maxmean)  maxmean = RowSums[i-1];
          if (RowSums[i-1] < minmean) minmean = RowSums[i-1];
          XValue[i-1] = i;
          GraphForm->Xpoints[0][i-1] = XValue[i-1];
     }
     GraphForm->nosets = 1;
     GraphForm->nbars = NF1cells;
     GraphForm->Heading = Heading;
     title = graphtitle;
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Y Values";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = minmean;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();
     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,1);
     delete[] XValue;
}
//---------------------------------------------------------------------

void TMedianPolishForm::InteractPlot(int NF1cells, int NF2Cells,
           double **ObsTable, AnsiString graphtitle, AnsiString Heading)
{
   int i, j;
   double minmean, maxmean, XBar;
   double *XValue, *YValue;
   AnsiString title;
   int plottype;
   AnsiString setstring;
   AnsiString astring;

     XValue = new double[NF1cells];
     plottype = 3;
     YValue = new double[NF2Cells];
     GetDblMatMem(GraphForm->Ypoints,NF1cells,NF2Cells);
     GetDblMatMem(GraphForm->Xpoints,1,NF2Cells);
     plottype = 3;
     maxmean = -10000.0;
     minmean = 10000.0;
     for (i = 1; i <= NF1cells; i++)
     {
          setstring = "Row ";
          setstring = setstring + IntToStr(i);
          GraphForm->SetLabels[i] = setstring;
          for (j = 1; j <= NF2Cells; j++)
          {
               XBar = ObsTable[i-1][j-1];
               if (XBar > maxmean) maxmean = XBar;
               if (XBar < minmean) minmean = XBar;
               GraphForm->Ypoints[i-1][j-1] = XBar;
          }
     }
     for (j = 1; j <= NF2Cells; j++)
     {
        XValue[j-1] = j;
        GraphForm->Xpoints[0][j-1] = XValue[j-1];
     }

     GraphForm->nosets = NF1cells;
     GraphForm->nbars = NF2Cells;
     GraphForm->Heading = "Factor X x Factor Y";
     title =  "Column Codes";
     GraphForm->XTitle = title;
     GraphForm->YTitle = "Mean";
     GraphForm->barwideprop = 0.5;
     GraphForm->AutoScale = false;
     GraphForm->miny = minmean;
     GraphForm->maxy = maxmean;
     GraphForm->GraphType = plottype;
     GraphForm->BackColor = clYellow;
     GraphForm->WallColor = clBlack;
     GraphForm->FloorColor = clLtGray;
     GraphForm->ShowBackWall = true;
     GraphForm->ShowModal();

     ClearDblMatMem(GraphForm->Xpoints,1);
     ClearDblMatMem(GraphForm->Ypoints,NF1cells);
     delete[] YValue;
     delete[] XValue;
}

