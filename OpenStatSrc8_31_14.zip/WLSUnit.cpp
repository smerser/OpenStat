//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "PlotUnit.h"
#include "MainUnit.h"
#include "functions.h"
#include "Datafuncs.h"
#include "DictionaryUnit.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "stdio.h"
#include "OutPut.h"
#include "WLSUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWLSForm *WLSForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TWLSForm::TWLSForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 0; i < NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i+1][0]);
     IndVarList->Clear();
     DepVarEdit->Text = "";
     WghtVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
     IndInBtn->Visible = true;
     IndOutBtn->Visible = false;
     WghtInBtn->Visible = true;
     WghtOutBtn->Visible = false;
     OLSChk->Checked = true;
     PlotChk->Checked = true;
     RegResChk->Checked = true;
     WeightChk->Checked = true;
     UserWghtsChk->Checked = false;
     OriginChk->Checked = true;
     Origin2Chk->Checked = true;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);    
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::DepInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     DepVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::DepOutBtnClick(TObject *Sender)
{
     if (DepVarEdit->Text == "") return;
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::IndInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              IndVarList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     IndOutBtn->Visible = true;
     if (VarList->Items->Count < 1) IndInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::IndOutBtnClick(TObject *Sender)
{
     int index = IndVarList->ItemIndex;
     VarList->Items->Add(IndVarList->Items->Strings[index]);
     IndVarList->Items->Delete(index);
     IndInBtn->Visible = true;
     if (IndVarList->Items->Count < 1) IndOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::WghtInBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
     int index = VarList->ItemIndex;
     WghtVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     WghtOutBtn->Visible = true;
     WghtInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::WghtOutBtnClick(TObject *Sender)
{
     if (WghtVarEdit->Text == "") return;
     VarList->Items->Add(WghtVarEdit->Text);
     WghtVarEdit->Text = "";
     WghtInBtn->Visible = true;
     WghtOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TWLSForm::PrelimBtnClick(TObject *Sender)
{
     int Noindep, DepCol, WghtCol, olddepcol, NCases, pos, col, *IndepCols;
     AnsiString *RowLabels;
     double R2, F, stderrest, X, Y, *Means, *Variances, *StdDevs, *BWeights;
     double *BetaWeights, *BStdErrs, *Bttests, *tprobs;
     bool errorcode, PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs;
     int result;

     PrintDesc = true;
     PrintCorrs = true;
     PrintInverse = true;
     PrintCoefs = true;
     SaveCorrs = false;
     Means = new double[NoVariables+2];
     Variances = new double[NoVariables+2];
     StdDevs = new double[NoVariables+2];
     BWeights = new double[NoVariables+2];
     BetaWeights = new double[NoVariables+2];
     BStdErrs = new double[NoVariables+2];
     Bttests = new double[NoVariables+2];
     tprobs = new double[NoVariables+2];
     RowLabels = new AnsiString[NoVariables+2];
     IndepCols = new int[NoVariables+2];

     NCases = NoCases;
     Noindep = IndVarList->Items->Count;
     if (Noindep == 0)
     {
         ShowMessage("ERROR! No independent variables selected.");
         goto cleanup;
     }
     DepCol = 0;
     WghtCol = 0;
     for (int i = 0; i < NoVariables; i++)
     {
         if (MainForm->Grid->Cells[i+1][0] == DepVarEdit->Text) DepCol = i+1;
         if (MainForm->Grid->Cells[i+1][0] == WghtVarEdit->Text) WghtCol = i+1;
         for (int j = 0; j < Noindep; j++)
         {
             if (MainForm->Grid->Cells[i+1][0] == IndVarList->Items->Strings[j])
             {
                IndepCols[j] = i+1;
                RowLabels[j] = IndVarList->Items->Strings[j];
             }
         } // next j
     } // next i
     if (DepCol == 0)
     {
         ShowMessage("ERROR!  No dependent variable selected.");
         goto cleanup;
     }
/*
     // check variable types
     result = VarTypeChk(DepCol,0);
     if (result == 1) goto cleanup;
     if (WghtCol > 0)
     {
        result = VarTypeChk(WghtCol,0);
        if (result == 1) goto cleanup;
     }
     for (int j = 0; j < Noindep; j++)
     {
        result = VarTypeChk(IndepCols[j],0);
        if (result == 1) goto cleanup;
     }
*/
     IndepCols[Noindep] = DepCol;
     olddepcol = DepCol; // save dependent column so we can reuse DepCol

     if (OLSChk->Checked) // Get OLS regression
     {
        FrmOutPut->RichOutPut->Lines->Add("OLS REGRESSION RESULTS");
         mreg(Noindep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);

        // Get predicted z score, residual z score, predicted raw score,
        // residual raw score and squared raw residual score.  Place in the grid
        PredictIt(IndepCols, Noindep+1, Means, StdDevs, BetaWeights, stderrest, Noindep);
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     if (( RegResChk->Checked) && (OLSChk->Checked) )
     {
        // Regress the squared residuals on the predictors
        DepCol = NoVariables;
        FrmOutPut->RichOutPut->Lines->Add("REGRESSION OF SQUARED RESIDUALS ON INDEPENDENT VARIABLES");
        mreg(Noindep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     if ((WeightChk->Checked) && (RegResChk->Checked) )
     {
        // Get predicted squared residuals and save recipricols as weights
        char outval[11];
        int col = NoVariables + 1;
        NewVar(col,false);
        DictionaryForm->DGrid->Cells[1][col] = "PredResid2";
        MainForm->Grid->Cells[col][0] = "PredResid2";
        col = NoVariables + 1;
        NewVar(col,false);
        DictionaryForm->DGrid->Cells[1][col] = "WEIGHT";
        MainForm->Grid->Cells[col][0] = "WEIGHT";
        for (int i = 1; i <= NoCases; i++)
        {
            double predicted;
            if (ValidValue(i,col-2)) // do we have a valid squared OLS residual?
            {
               predicted = 0.0;
               for (int j = 0; j < Noindep; j++)
               {
                   int pos = IndepCols[j];
                   double X = StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                   predicted += BWeights[j] * X;
               }
               predicted += BWeights[Noindep];
               predicted = fabs(predicted);
               sprintf(outval,"%8.3f",predicted);
               MainForm->Grid->Cells[col-1][i] = outval;
               if (predicted > 0.0)
               {
                  predicted = sqrt(predicted);
                  predicted = 1.0 / predicted;
               }
               else predicted = 0.0;
               sprintf(outval,"%8.3f",predicted);
               MainForm->Grid->Cells[col][i] = outval;
            } // if valid case
        } // next i
     } // if regresChk

     // Now, plot squared residuals against each independent variable
     if ((PlotChk->Checked) && (RegResChk->Checked))
     {
        int Xcol = DepCol;
        for (int ii = 0; ii < Noindep; ii++)
        {
            int Ycol = IndepCols[ii];
            int N = 0;
            double *Xpoints,  *Ypoints, *UpConf, *lowConf;
            double Xmax, Xmin, Ymax, Ymin, Xmean, Ymean, Xvariance, Yvariance, R;
            double temp, SEPred, Slope, Intercept, DF, SSx, t, ConfBand, sedata;
            double predicted, X, Y, Xstddev, Ystddev;
            int *ColNoSelected;
            char outline[121];
            AnsiString XLabel, YLabel;
            Xpoints = new double[NoCases + 1];
            Ypoints = new double[NoCases + 1];
            UpConf = new double[NoCases + 1];
            lowConf = new double[NoCases + 1];
            ColNoSelected = new int[2];
            int NoSelected = 2;
            ColNoSelected[0] = Xcol;
            ColNoSelected[1] = Ycol;
            XLabel = MainForm->Grid->Cells[Xcol][0];
            YLabel = MainForm->Grid->Cells[Ycol][0];
            Xmax = -1.0e20;
            Xmin = 1.0e20;
            Ymax = -1.0e20;
            Ymin = 1.0e20;
            Xmean = 0.0;
            Ymean = 0.0;
            Xvariance = 0.0;
            Yvariance = 0.0;
            R = 0.0;
            for (int i = 1; i <= NoCases; i++)
            {
                if (!ValidRecord(i,ColNoSelected,NoSelected)) continue;
                N = N + 1;
                X = StrToFloat(MainForm->Grid->Cells[Xcol][i]);
                Y = StrToFloat(MainForm->Grid->Cells[Ycol][i]);
                Xpoints[N] = X;
                Ypoints[N] = Y;
                if (X > Xmax) Xmax = X;
                if (X < Xmin) Xmin = X;
                if (Y > Ymax) Ymax = Y;
                if (Y < Ymin) Ymin = Y;
                Xmean = Xmean + X;
                Ymean = Ymean + Y;
                Xvariance = Xvariance + (X * X);
                Yvariance = Yvariance + (Y * Y);
                R = R + (X * Y);
            }

            // sort on X
            for (int i = 1; i <= N - 1; i++)
            {
                for (int j = i + 1; j <= N; j++)
                {
                    if (Xpoints[i] > Xpoints[j]) //swap
                    {
                       temp = Xpoints[i];
                       Xpoints[i] = Xpoints[j];
                       Xpoints[j] = temp;
                       temp = Ypoints[i];
                       Ypoints[i] = Ypoints[j];
                       Ypoints[j] = temp;
                    }
                }
            }
            // calculate statistics
            Xvariance = Xvariance - (Xmean * Xmean / N);
            SSx = Xvariance;
            Xvariance = Xvariance / (N - 1);
            Xstddev = sqrt(Xvariance);
            Yvariance = Yvariance - (Ymean * Ymean / N);
            Yvariance = Yvariance / (N - 1);
            Ystddev = sqrt(Yvariance);
            R = R - (Xmean * Ymean / N);
            R = R / (N - 1);
            R = R / (Xstddev * Ystddev);
            SEPred = sqrt(1.0 - (R * R)) * Ystddev;
            SEPred = SEPred * sqrt((N - 1) / (N - 2));
            Xmean = Xmean / N;
            Ymean = Ymean / N;
            Slope = R * Ystddev / Xstddev;
            Intercept = Ymean - Slope * Xmean;
            // Now, print the descriptive statistics if requested
            FrmOutPut->RichOutPut->Lines->Add("X versus Y Plot");
            FrmOutPut->RichOutPut->Lines->Add("");
            sprintf(outline,"X = %s, Y = %s from file: %s",MainForm->Grid->Cells[Xcol][0],
                MainForm->Grid->Cells[Ycol][0],MainForm->FileNameEdit->Text.c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("Variable     Mean   Variance  Std.Dev.");
            sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f",MainForm->Grid->Cells[Xcol][0],Xmean,Xvariance,Xstddev);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"%-10s%8.2f  %8.2f  %8.2f",MainForm->Grid->Cells[Ycol][0],Ymean,Yvariance,Ystddev);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"Correlation = %6.4f, Slope = %8.2f, Intercept = %8.2f",
              R, Slope, Intercept);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"Standard Error of Estimate = %8.2f",SEPred);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"Number of good cases = %d",N);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->ShowModal();
            FrmOutPut->RichOutPut->Clear();
            // get upper and lower confidence points for each X value
            ConfBand = 0.95;
            DF = N - 2;
            t = inverset(ConfBand,DF);
            for (int i = 1; i <= N; i++)
            {
               X = Xpoints[i];
               predicted = Slope * X + Intercept;
               sedata = SEPred * sqrt(1.0 + (1.0 / N) + ((X - Xmean) * (X - Xmean) / SSx));
               UpConf[i] = predicted + (t * sedata);
               lowConf[i] = predicted - (t * sedata);
               if (UpConf[i] > Ymax) Ymax = UpConf[i];
               if (lowConf[i] < Ymin)Ymin = lowConf[i];
            }
            // plot the values (and optional line and confidence band if elected)
            plotxy(Xpoints, Ypoints, UpConf, lowConf, ConfBand, Xmean, Ymean, R,
               Slope, Intercept, Xmax, Xmin, Ymax, Ymin, N, XLabel, YLabel);
            PlotForm->ShowModal();
            // cleanup
            delete[] ColNoSelected;
            delete[] lowConf;
            delete[] UpConf;
            delete[] Ypoints;
            delete[] Xpoints;
        }
     }

     if (UseWeightsChk->Checked)
     {
        // Weight variables and do OLS regression on weighted variables
        DepCol = olddepcol;
        IndepCols[Noindep] = DepCol;
        for (int i = 1; i <= NoCases; i++)
        {
            Y = StrToFloat(Trim(MainForm->Grid->Cells[NoVariables][i])); // weight
            for (int j = 0; j <= Noindep; j++)
            {
                pos = IndepCols[j];
                X = StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                X *= Y;
                MainForm->Grid->Cells[pos][i] = FloatToStr(X);
            }
        }
        if (OriginChk->Checked) // get means of variables and subtract from the values
        {
           for (int j = 0; j <= Noindep; j++)
           {
               Means[j] = 0.0;
               NCases = 0;
               pos = IndepCols[j];
               for (int i = 1; i <= NoCases; i++)
               {
                   if (ValidValue(i,pos))
                   {
                      Means[j] += StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                      NCases++;
                   }
               }
               Means[j] = Means[j] / NCases;
               for (int i = 1; i <= NoCases; i++)
               {
                   if (ValidValue(i,pos))
                   {
                      X = StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                      X = X - Means[j];
                      MainForm->Grid->Cells[pos][i] = FloatToStr(X);
                   }
               }  // next i
           }  // next j
        }  // if origin checked
        FrmOutPut->RichOutPut->Lines->Add("WLS REGRESSION RESULTS");
        mreg(Noindep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
        FrmOutPut->ShowModal();
     } // if useweightschk checked
     else if (UserWghtsChk->Checked) // use the weights entered by the user
     {
        // Weight variables and do OLS regression on weighted variables
        DepCol = olddepcol;
        IndepCols[Noindep] = DepCol;
        for (int i = 1; i <= NoCases; i++)
        {
            Y = StrToFloat(Trim(MainForm->Grid->Cells[WghtCol][i])); // weight
            for (int j = 0; j <= Noindep; j++)
            {
                pos = IndepCols[j];
                X = StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                X *= Y;
                MainForm->Grid->Cells[pos][i] = FloatToStr(X);
            }
        }
        if (OriginChk->Checked) // get means of variables and subtract from the values
        {
           for (int j = 0; j <= Noindep; j++)
           {
               Means[j] = 0.0;
               NCases = 0;
               pos = IndepCols[j];
               for (int i = 1; i <= NoCases; i++)
               {
                   if (ValidValue(i,pos))
                   {
                      Means[j] += StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                      NCases++;
                   }
               }
               Means[j] = Means[j] / NCases;
               for (int i = 1; i <= NoCases; i++)
               {
                   if (ValidValue(i,pos))
                   {
                      X = StrToFloat(Trim(MainForm->Grid->Cells[pos][i]));
                      X = X - Means[j];
                      MainForm->Grid->Cells[pos][i] = FloatToStr(X);
                   }
               }  // next i
           }  // next j
        }  // if origin checked
        FrmOutPut->RichOutPut->Lines->Add("WLS REGRESSION RESULTS");
        mreg(Noindep,IndepCols,DepCol,RowLabels,Means,Variances,StdDevs,BWeights,
             BetaWeights,BStdErrs,Bttests,tprobs,R2,F,stderrest,NCases,errorcode,
              PrintDesc, PrintCorrs, PrintInverse, PrintCoefs, SaveCorrs);
        FrmOutPut->ShowModal();
     }

cleanup:
     delete[] IndepCols;
     delete[] RowLabels;
     delete[] tprobs;
     delete[] Bttests;
     delete[] BStdErrs;
     delete[] BetaWeights;
     delete[] BWeights;
     delete[] StdDevs;
     delete[] Variances;
     delete[] Means;

     // reset the variables for possible second step of WLS
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------

void __fastcall TWLSForm::PredictIt(int *ColNoSelected, int NoVars,
             double *Means, double *StdDevs,double *BetaWeights,
             double StdErrEst,  int NoIndepVars)
{
   // routine obtains predicted raw and standardized scores and their
   // residuals.  It is assumed that the dependent variable is last in the
   // list of variable column pointers stored in the ColNoSelected vector.

   int col, i, j, k, Index, IndexX, IndexY;
   double predicted, zpredicted, z1, z2, resid, Term1, Term2, residsqr;
   double StdErrPredict, t95, Hi95, Low95;
   char astring[121];

   // Get the z predicted score and its residual
   col = NoVariables + 1;
   NewVar(col,false);
   MainForm->Grid->Cells[col][0] = "Pred.z";
   DictionaryForm->DGrid->Cells[1][col] = "Pred.z";
   col = NoVariables + 1;
   NewVar(col,false);
   MainForm->Grid->Cells[col][0] = "z Resid.";
   DictionaryForm->DGrid->Cells[1][col] = "z Resid.";
   MainForm->Grid->ColCount += 2;
   for (i = 1; i <= NoCases; i++)
   {
       zpredicted = 0.0;
       for (j = 0; j < NoIndepVars; j++)
       {
           k = ColNoSelected[j];
           z1 = (StrToFloat(Trim(MainForm->Grid->Cells[k][i])) -
                               Means[j]) / StdDevs[j];
           zpredicted = zpredicted + (z1 * BetaWeights[j]);
       }
       sprintf(astring,"%8.4f",zpredicted);
       MainForm->Grid->Cells[col-1][i] = astring;
       Index = ColNoSelected[NoVars-1];
       z2 = StrToFloat(Trim(MainForm->Grid->Cells[Index][i]));
       z2 = (z2 - Means[NoVars-1]) / StdDevs[NoVars-1]; // z score
       sprintf(astring,"%8.4f",z2 - zpredicted);  // z residual
       MainForm->Grid->Cells[col][i] = astring;
   }

   // Get raw predicted and residuals
   col = NoVariables + 1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "Pred.Raw";
   MainForm->Grid->Cells[col][0] = "Pred.Raw";
   // calculate raw predicted scores and store in grid at col
   for (i = 1; i <= NoCases; i++)
   {   // predicted raw obtained from previously predicted z score
       predicted = StrToFloat(Trim(MainForm->Grid->Cells[col-2][i])) *
                            StdDevs[NoVars-1] + Means[NoVars-1];
       sprintf(astring,"%8.3f",predicted);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // Calculate residuals of predicted raw scores }
   col = NoVariables +1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "Raw Resid.";
   MainForm->Grid->Cells[col][0] = "Raw Resid.";

   for (i = 1; i <= NoCases; i++)
   {
       Index = ColNoSelected[NoVars-1];
//       resid = StrToFloat(Trim(MainForm->Grid->Cells[col-1][i])) -
//                           StrToFloat(Trim(MainForm->Grid->Cells[Index][i]));
       resid = StrToFloat(Trim(MainForm->Grid->Cells[Index][i])) -
                           StrToFloat(Trim(MainForm->Grid->Cells[col-1][i]));
       sprintf(astring,"%8.3f",resid);
       MainForm->Grid->Cells[col][i] = astring;
   }
   // get square of raw residuals
   col = NoVariables + 1;
   NewVar(col,false);
   DictionaryForm->DGrid->Cells[1][col] = "ResidSqr";
   MainForm->Grid->Cells[col][0] = "ResidSqr";
   for (i = 1; i <= NoCases; i++)
   {
       residsqr = StrToFloat(Trim(MainForm->Grid->Cells[col-1][i]));
       residsqr = residsqr * residsqr;
       sprintf(astring,"%8.3f",residsqr);
       MainForm->Grid->Cells[col][i] = astring;
   }
}
//---------------------------------------------------------------------

void __fastcall TWLSForm::plotxy(double *Xpoints,
                                      double *Ypoints,
                                      double *UpConf,
                                      double *LowConf,
                                      double ConfBand,
                                      double Xmean,
                                      double Ymean,
                                      double R,
                                      double Slope,
                                      double Intercept,
                                      double Xmax,
                                      double Xmin,
                                      double Ymax,
                                      double Ymin,
                                      int N,
                                      AnsiString XLabel,
                                      AnsiString YLabel)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];

     Title = "X versus Y PLOT Using File: " + MainForm->FileNameEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw Means
          ypos = ceil(vhi * ( (Ymax - Ymean) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + YLabel;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

          xpos = ceil(hwide * ( (Xmean - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          ypos = vtop;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = vbottom;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          Title = "MEAN ";
          Title = Title + XLabel;
          strhi = PlotForm->Image1->Canvas->TextWidth(Title);
          xpos = xpos - strhi / 2;
          ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw slope line
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          Yvalue = (Xpoints[1] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1]- Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          Yvalue = (Xpoints[N] * Slope) + Intercept; // predicted score
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[N] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XLabel) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XLabel);
     sprintf(outline,"R(X,Y) = %5.3f, Slope = %6.2f, Intercept = %6.2f",
              R,Slope,Intercept);
     Title = outline;
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
     ypos = ypos + 15;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // Draw vertical axis
     Title = YLabel;
//     xpos = hleft - 10 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     xpos = 10;
     ypos = vtop - 8 - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,YLabel);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 1; i <= N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
     }

     // draw confidence bands if requested
     if (ConfBand != 0.0)
     {
          PlotForm->Image1->Canvas->Pen->Color = clRed;
          ypos = ceil(vhi * ((Ymax - UpConf[1]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 2; i <= N; i++)
          {
               ypos = ceil(vhi * ((Ymax - UpConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
          ypos = ceil(vhi * ((Ymax - LowConf[1]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[1] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          for (i = 2; i <= N; i++)
          {
               ypos = ceil(vhi * ((Ymax - LowConf[i]) / (Ymax - Ymin)));
               ypos = ypos + vtop;
               xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
               xpos = xpos + hleft;
               PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          }
     }
}
//-------------------------------------------------------------------


