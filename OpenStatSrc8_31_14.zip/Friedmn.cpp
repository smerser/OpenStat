//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "math.h"
#include "GraphUnit.h"
#include "Friedmn.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFriedmanFrm *FriedmanFrm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TFriedmanFrm::TFriedmanFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFriedmanFrm::OKBtnClick(TObject *Sender)
{
    FriedmanFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFriedmanFrm::CancelBtnClick(TObject *Sender)
{
    FriedmanFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TFriedmanFrm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Items->Clear();
     TreatVars->Items->Clear();
     GrpVar->Text = "";
     for (i = 1; i <= NoVariables; i++)
          VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     GrpIn->Visible = true;
     GrpOut->Visible = false;
     TrtIn->Visible = true;
     TrtOut->Visible = false;
     SaveRanksChk->Checked = false;
     PlotAvgRanksChk->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TFriedmanFrm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TFriedmanFrm::GrpInClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     GrpVar->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     GrpIn->Visible = false;
     GrpOut->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TFriedmanFrm::GrpOutClick(TObject *Sender)
{
     VarList->Items->Add(GrpVar->Text);
     GrpVar->Text = "";
     GrpIn->Visible = true;
     GrpOut->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFriedmanFrm::TrtInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            TreatVars->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
         }
         else i = i + 1;
     }
     TrtOut->Visible = true;
     if (VarList->Items->Count == 0) TrtIn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFriedmanFrm::TrtOutClick(TObject *Sender)
{
   int index;

   index = TreatVars->ItemIndex;
   if (index < 0)
   {
        TrtOut->Visible = false;
        TrtIn->Visible = true;
        return;
   }
   VarList->Items->Add(TreatVars->Items->Strings[index]);
   TreatVars->Items->Delete(index);
   TrtIn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TFriedmanFrm::ComputeBtnClick(TObject *Sender)
{
     int i, j, k, L, col, itemp, GrpCol, CondVar, mingrp, maxgrp;
     int tiestart, tieend, noties, NoSelected, NCases, group, nogrps;
     double s, t, TotRanks, chisqr, probchi, score, correction, groupties;
     double *X, *ColRanks, *temprank;
     double **Ranks, **means;
     AnsiString *RowLabels, *ColLabels;
     int *index;
     int **GrpNo;
     AnsiString cellstring;
     char outline[101];
     AnsiString title;
     bool ties, typeerror = false;
     int *ColNoSelected;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     k = TreatVars->Items->Count;
     if (k < 1)
     {
        ShowMessage("ERROR! Select one or more treatment variables.");
        return;
     }

     NoSelected = k + 1;
     GetIntVecMem(ColNoSelected,NoVariables);
     ColLabels = new AnsiString[NoVariables];

     // get group variable and treatment variables
     GrpCol = 0;
     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GrpVar->Text)
          {
               ColNoSelected[0] = i;
               GrpCol = i;
               //result = VarTypeChk(GrpCol,1);
               //if (result == 1)
               //{
               //    typeerror = true;
               //    break;
               //}
          }
          for (j = 1; j <= k; j++)
          {
               if (cellstring == TreatVars->Items->Strings[j-1])
               {
                    ColNoSelected[j] = i;
                    //result = VarTypeChk(i,0);
                    //if (result == 1)
                    //{
                    //    typeerror = true;
                    //    break;
                    //}
                    ColLabels[j-1] = cellstring;
               }
          }
     }
     if (GrpCol == 0)
     {
        ShowMessage("ERROR!  No group variable selected.");
        delete[] ColNoSelected;
        delete[] ColLabels;
        return;
     }
     if (typeerror)
     {
        delete[] ColLabels;
        delete[] ColNoSelected;
        return;
     }

     // get minimum and maximum group codes
     NCases = 0;
     mingrp = 10000;
     maxgrp = -10000;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
          NCases = NCases + 1;
          group = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpCol][i])));
          //result = GetValue(i,GrpCol,intvalue,dblvalue,strvalue);
          //if (result == 1) group = 0;
          //else group = intvalue;
          if (group > maxgrp) maxgrp = group;
          if (group < mingrp) mingrp = group;
     }
     nogrps = maxgrp - mingrp + 1;

    // Initialize arrays
     RowLabels = new AnsiString[nogrps];
     GetIntVecMem(index,k);
     GetIntMatMem(GrpNo,nogrps,k);
     GetDblMatMem(Ranks,nogrps,k);
     GetDblMatMem(means,nogrps,k);
     GetDblVecMem(X,k);
     GetDblVecMem(ColRanks,k);
     GetDblVecMem(temprank,k);
     for (j = 0; j < k; j++)
     {
        for (i = 0; i < nogrps; i++)
        {
            means[i][j] = 0.0;
            Ranks[i][j] = 0.0;
            GrpNo[i][j] = 0;
        }
        ColRanks[j] = 0.0;
        X[j] = 0.0;
        index[j] = j+1;
     }

     // Initialize labels
     for (i = 1; i <= nogrps; i++)
     {
        sprintf(outline,"Group %d",mingrp + i - 1);
        cellstring = outline;
        RowLabels[i-1] = cellstring;
     }

     // Setup for printing results
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("FRIEDMAN TWO-WAY ANOVA ON RANKS");
     FrmOutPut->RichOutPut->Lines->Add("See pages 166-173 in S. Siegel""s Nonparametric Statistics");
     FrmOutPut->RichOutPut->Lines->Add("for the Behavioral Sciences, McGraw-Hill Book Co., New York, 1956");
     FrmOutPut->RichOutPut->Lines->Add("");

     // Obtain mean score for each cell
     for (i = 1; i <= NoCases; i++)
     {
        if (! ValidRecord(i,ColNoSelected,NoSelected)) continue;
        group = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpCol][i])));
        group = group - mingrp + 1;
        for (j = 1; j <= k; j++) // treatment values
        {
             col = ColNoSelected[j];
             score = StrToFloat(Trim(MainForm->Grid->Cells[col][i]));
             //result = GetValue(i,col,intvalue,dblvalue,strvalue);
             //if (result == 1) score = 0.0;
             //else score = dblvalue;
             means[group-1][j-1] = means[group-1][j-1]  + score;
             GrpNo[group-1][j-1]  = GrpNo[group-1][j-1] + 1;
        }
     }
     for (i = 1; i <= nogrps; i++)
        for (j = 1; j <= k; j++)
            means[i-1][j-1] = means[i-1][j-1] / GrpNo[i-1][j-1];

     // Print means and group size arrays
     title = "Treatment means - values to be ranked.";
     ArrayPrint(means,nogrps,k,"",RowLabels,ColLabels,title.c_str());
     FrmOutPut->RichOutPut->Lines->Add("");
     title = "Number in each group's treatment.";
     IntArrayPrint(GrpNo,nogrps,k,"GROUP",RowLabels,ColLabels,title.c_str());

     // Gather row data in X array and rank within rows
     correction = 0.0;
     for (i = 0; i < nogrps; i++)  // for each row
     {
        groupties = 0.0;
        for (j = 0; j < k; j++)  // across each row
        {
            X[j] = means[i][j];  // temporary storage for this case
            index[j] = j;      // index of original location of values
        }

        //rank scores in this row i
        for (j = 1; j < k; j++)
        {
            for (L = j + 1; L <= k; L++)
            {
                if (X[j-1] > X[L-1])  // arrange in ascending order
                {
                    t = X[j-1];
                    X[j-1] = X[L-1];
                    X[L-1] = t;
                    itemp = index[j-1];
                    index[j-1] = index[L-1];
                    index[L-1] = itemp;
                }
            }
        }

        // create ranks for the sorted raw scores (no ties at this point)
        for (j = 1; j <= k; j++) temprank[j-1] = j;

        //Check for tied scores in X and use average of their ranks
        tiestart = 0;
        tieend = 0;
        j = 1;
        while (j < k)
        {
            ties = false;
            noties = 1;
            for (L = j + 1; L <= k; L++)
            {
                if (X[j-1] == X[L-1])  // match on ranked scores
                {
                    ties = true;
                    noties++;
                    tiestart = j-1;
                    tieend = L-1;
                }
            }
            if (ties == true)
            {   // get sum of ranks for the ranked scores and average
                s = 0.0;
                for (L = tiestart; L <= tieend; L++)
                {
                        s = s + temprank[L];
                }
                for (L = tiestart; L <= tieend; L++)
                {
                        temprank[L] = s / noties;
                }
                j = tieend;
                groupties = groupties + noties;
            }
            j = j + 1;
        } // end while j < k

        // put ranks in position saved in index
        for (L = 0; L < k; L++)
        {
                Ranks[i][index[L]] = temprank[L];
        }
        groupties = pow(groupties,3.0) - groupties;
        correction = correction + groupties;
     } // next group i

     //Get sum of ranks in columns
     for (i = 1; i <= nogrps; i++)
        for (j = 1; j <= k; j++)
            ColRanks[j-1] = ColRanks[j-1] + Ranks[i-1][j-1];

     //Calculate Statistics
     TotRanks = 0;
     for (j = 1; j <= k; j++) TotRanks = TotRanks + (ColRanks[j-1] * ColRanks[j-1]);
     chisqr = TotRanks * 12.0 / (nogrps * k * (k + 1));
     chisqr = chisqr - (3 * nogrps * (k + 1));
     probchi = 1.0 - chisquaredprob(chisqr, k - 1);
     double denominator = (double) nogrps * (double)(( k * k * k) - k);
     correction = 1.0 - correction / denominator;
     //Now, show results
     title = "Score Rankings Within Groups";
     ArrayPrint(Ranks,nogrps,k,"Treatment",RowLabels,ColLabels,title.c_str());
     title = "TOTAL RANKS";
     VPrint(ColRanks,k,ColLabels,title.c_str());
     title = "MEAN RANKS";
     for (i = 0; i < k; i++) ColRanks[i] = ColRanks[i] / NoCases;
     VPrint(ColRanks,k,ColLabels,title.c_str());
     FrmOutPut->RichOutPut->Lines->Add("");
     sprintf(outline,"Chi-square with %d D.F. = %8.3f with probability = %6.4f",
        k-1, chisqr, probchi);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     chisqr = chisqr / correction;
     probchi = 1.0 - chisquaredprob(chisqr,k-1);
     sprintf(outline,"Corrected for ties Chi-square with %d D.F. = %8.3f with probability = %6.4f",
        k-1, chisqr, probchi);
     FrmOutPut->RichOutPut->Lines->Add(outline);


     if ((k < 5) && (nogrps < 10))
     {
        FrmOutPut->RichOutPut->Lines->Add("Chi-square too approximate-use exact table (TABLE N)");
        FrmOutPut->RichOutPut->Lines->Add("page 280-281 in Siegel");
     }
     FrmOutPut->ShowModal();
     FrmOutPut->RichOutPut->Clear();

     // save ranks in the grid if selected
     if (SaveRanksChk->Checked)
     {
        for (i = 1; i <= k; i++)
        {
                title = "Rank " + IntToStr(i);
                int col = NoVariables + 1;
                MainForm->Grid->Cells[col][0] = title;
                NewVar(col,true);
                for (j = 1; j <= NoCases; j++)
                        MainForm->Grid->Cells[col][j] = FloatToStr(Ranks[j-1][i-1]);
        }
     }

     // plot rank means if selected
     if (PlotAvgRanksChk->Checked)
     {
        double *XValue;
        int plottype = 3;

        XValue = new double[k];
        title = "RANKS";
        GraphForm->SetLabels[1] = title;
        GetDblMatMem(GraphForm->Xpoints,1,k);
        GetDblMatMem(GraphForm->Ypoints,1,k);
        for (i = 1; i <= k; i++)
        {
                GraphForm->Ypoints[0][i-1] = ColRanks[i-1];
                XValue[i-1] = i;
                GraphForm->Xpoints[0][i-1] = XValue[i-1];
        }
        GraphForm->nosets = 1;
        GraphForm->nbars = k;
        GraphForm->Heading = "PLOT OF AVERAGE RANKS";
        GraphForm->XTitle = "VARIABLE";
        GraphForm->YTitle = "Mean";
        GraphForm->barwideprop = 0.5;
        GraphForm->AutoScale = false;
        GraphForm->miny = 0.0;
        GraphForm->maxy = k+1;
        GraphForm->GraphType = plottype;
        GraphForm->BackColor = clYellow;
        GraphForm->WallColor = clBlack;
        GraphForm->FloorColor = clLtGray;
        GraphForm->ShowBackWall = true;
        GraphForm->ShowModal();
        delete[] XValue;
        ClearDblMatMem(GraphForm->Xpoints,1);
        ClearDblMatMem(GraphForm->Ypoints,1);
     }
     
     // clean up the heap
     ClearDblVecMem(temprank);
     ClearDblVecMem(ColRanks);
     ClearDblVecMem(X);
     ClearDblMatMem(means,nogrps);
     ClearDblMatMem(Ranks,nogrps);
     ClearIntMatMem(GrpNo,nogrps);
     ClearIntVecMem(index);
     delete[] RowLabels;
     delete[] ColLabels;
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

