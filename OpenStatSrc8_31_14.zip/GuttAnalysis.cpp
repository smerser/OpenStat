//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "GuttAnalysis.h"
#include "VarSelect.h"
#include "MainUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
extern int NoVariables;
extern int NoCases;
extern bool FilterOn;
extern int FilterCol;

void Guttman(void)
{
    int **FreqMat0; // Pointer to array of 0 responses for each item by score group
    int **FreqMat1; // Pointer to array of 1 responses for each item by score group
    int *RowTots; // Pointer to vector of total score frequencies for items
    int **ColTots; // Pointer to array of 0 and 1 column totals
    double *ColProps; // Pointer to array of proportions correct in columns
    int *ColNoSelected; // Pointer to vector of item Grid columns
    int *CaseVector; // Pointer to vector of subject's item responses
    int TotalScore; // Total score of a subject
    int temp; // temporary variable used in sorting
    int *CutScore; // Optimal cut scores for each item
    int **ErrorMat; // matrix of errors above and below cut scores
    int *sequence; // original and sorted sequence no. of items
    int *CaseNo; // ID number for each case
    int **ModalArray; // Array of modal item responses
    int NoSelected;
    char outline[122];
    char astring[41];
    AnsiString *VarLabels;

    //Get variables to use in the analysis
    FrmOutPut->RichOutPut->Clear();
    FrmVarSel->ChkBox->Visible = false;
    FrmVarSel->LstBoxVars->Clear();
    FrmVarSel->LstBoxSelected->Clear();
    FrmVarSel->Caption = "Guttman Scalogram Analysis";
    for (int i = 0; i < NoVariables; i++)
        FrmVarSel->LstBoxVars->Items->Add(MainForm->Grid->Cells[i+1][0]);
    if(FrmVarSel->ShowModal() == mrCancel) return;
    NoSelected = FrmVarSel->LstBoxSelected->Items->Count;
    if (NoSelected < 2)
    {
       ShowMessage("ERROR! Select two or more variables to analyze.");
       return;
    }
    
    //Allocate heap storage for a vector of items selected and a case vector
    try  {
        ColNoSelected = new int[NoSelected];
        VarLabels = new AnsiString[NoSelected];
        sequence = new int[NoSelected];
        CaseNo = new int[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Initialize sequence
    for (int i = 0; i < NoSelected; i++) sequence[i] = i;

    // Get items selected
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            if (FrmVarSel->LstBoxSelected->Items->Strings[i] ==
                MainForm->Grid->Cells[j+1][0])
            {
                ColNoSelected[i] = j+1;
                VarLabels[i] = MainForm->Grid->Cells[j+1][0];
            }
        }
    }

    // Get storage for the work areas
    try  {
        FreqMat0 = new int*[NoCases];
        for (int i = 0; i < NoCases; i++) FreqMat0[i] = new int[NoSelected];
        FreqMat1 = new int*[NoCases];
        for (int i = 0; i < NoCases; i++) FreqMat1[i] = new int[NoSelected];
        RowTots = new int[NoCases];
        ColProps = new double[NoSelected];
        ColTots = new int*[NoSelected];
        for (int i = 0; i < NoSelected; i++) ColTots[i] = new int[2];
        CaseVector = new int[NoCases];
        CutScore = new int[NoCases];
        ErrorMat = new int*[NoSelected];
        for (int i = 0; i < NoSelected; i++) ErrorMat[i] = new int[2];
        ModalArray = new int*[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) ModalArray[i] = new int[NoSelected];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Initialize arrays
    for (int i = 0; i < NoSelected; i++)
    {
        ColTots[i][0] = 0;
        ColTots[i][1] = 0;
        ColProps[i] = 0.0;
        ErrorMat[i][0] = 0;
        ErrorMat[i][1] = 0;
    }
    for (int i = 0; i < NoCases; i++)
    {
        RowTots[i] = 0;
        CutScore[i] = 0;
        CaseNo[i] = i+1;
        for (int j = 0; j < NoSelected; j++)
        {
            FreqMat0[i][j] = 0;
            FreqMat1[i][j] = 0;
        }
    }
    if (NoCases > NoSelected)
    {
        for (int i = 0; i < NoCases; i++)CaseVector[i] = 0;
    }
    else
    {
        for (int i = 0; i < NoSelected; i++)CaseVector[i] = 0;
    }

    // Get data into the frequency matrices of 0 and 1 responses
    for (int i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        TotalScore = 0;
        for (int j = 0; j < NoSelected; j++)
        {
            int col = ColNoSelected[j];
            int X = floor(StrToFloat(MainForm->Grid->Cells[col][i+1]));
            CaseVector[j] = X;
            TotalScore += X;
        }
        for (int j = 0; j < NoSelected; j++)
        {
            if (CaseVector[j] == 0) FreqMat0[i][j] = 1;
            else FreqMat1[i][j]= 1;
        }
    }

    // Get Row Totals for each score group (rows of FreqMat1)
    for (int i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (int j = 0; j < NoSelected; j++)
        {
           RowTots[i] += FreqMat1[i][j];
        }
    }

    // Get Column Totals for item scores of 1 and 0
    for (int i = 0; i < NoSelected; i++) //columns
    {
        for (int j = 0; j < NoCases; j++) // rows
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            ColTots[i][0] += FreqMat0[j][i];
            ColTots[i][1] += FreqMat1[j][i];
        }
    }

    //Sort frequency matrices into descending order
    for (int i = 0; i < NoCases-1; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        for (int j = i+1; j < NoCases; j++)
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            if (RowTots[i] < RowTots[j]) //swap
            {
                for (int k = 0; k < NoSelected; k++)
                { // carry all columns in the swap
                    temp = FreqMat0[i][k];
                    FreqMat0[i][k] = FreqMat0[j][k];
                    FreqMat0[j][k] = temp;
                    temp = FreqMat1[i][k];
                    FreqMat1[i][k] = FreqMat1[j][k];
                    FreqMat1[j][k] = temp;
                }
                // Also swap row totals
                temp = RowTots[i];
                RowTots[i] = RowTots[j];
                RowTots[j] = temp;
                // And case number
                temp = CaseNo[i];
                CaseNo[i] = CaseNo[j];
                CaseNo[j] = temp;
            } // end if
        } // Next j
    } // next i

    // Now sort the columns into ascending order of number right
    for (int i = 0; i < NoSelected-1; i++)
    {
        for (int j = i+1; j < NoSelected; j++)
        {
            if (ColTots[i][1] > ColTots[j][1]) //swap
            {
                for (int k = 0; k < NoCases; k++)
                {
                    if (!ValidRecord(k+1,ColNoSelected,NoSelected)) continue;
                    temp = FreqMat0[k][i];
                    FreqMat0[k][i] = FreqMat0[k][j];
                    FreqMat0[k][j] = temp;
                    temp = FreqMat1[k][i];
                    FreqMat1[k][i] = FreqMat1[k][j];
                    FreqMat1[k][j] = temp;
                } // next k
                // swap column totals also
                temp = ColTots[i][0];
                ColTots[i][0] = ColTots[j][0];
                ColTots[j][0] = temp;
                temp = ColTots[i][1];
                ColTots[i][1] = ColTots[j][1];
                ColTots[j][1] = temp;
                // swap label pointers
                temp = sequence[i];
                sequence[i] = sequence[j];
                sequence[j] = temp;
            } // end if
        } // next j
    } // next i

    //For each item (column), find the optimal cutting value
    for (int i = 0; i < NoSelected; i++)
    {
        CutScore[i] = 0;
        for (int j = 0; j < NoCases; j++) // j is the trial cut point
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            int e0 = 0;
            int e1 = 0;
            //Get errors prior to the cut point
            for (int k = 0; k <= j; k++)
            {
                if (!ValidRecord(k+1,ColNoSelected,NoSelected)) continue;
                if (FreqMat0[k][i] == 1)  e0++;
            }
            //Get errors following the cut point
            for (int k = j+1; k < NoCases; k++)
            {
                if (!ValidRecord(k+1,ColNoSelected,NoSelected)) continue;
                if (FreqMat1[k][i] == 1) e1++;
            }
            //Save errors for each cut
            CaseVector[j] = e0 + e1;
        } // next j
        // Save minimum cut score index
        int e2 = 32000;
        int e3 = 0;
        for (int j = 0; j < NoCases; j++)
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            if (CaseVector[j] < e2)
            {
                e2 = CaseVector[j];
                e3 = j;
            }
        }
        CutScore[i] = e3; //Position of optimal cut for item i
    }

    // Get error counts;
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j <= CutScore[i]; j++)
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            if ((FreqMat0[j][i] > 0) || (FreqMat1[j][i] > 0))
                ErrorMat[i][0] += FreqMat0[j][i];
        }
        for (int j = CutScore[i]+1; j < NoCases; j++)
        {
            if (!ValidRecord(j+1,ColNoSelected,NoSelected)) continue;
            if ((FreqMat0[j][i] > 0) || (FreqMat1[j][i] > 0))
                ErrorMat[i][1] += FreqMat1[j][i];
        }
    }

    // Print results
    FrmOutPut->RichOutPut->Lines->Add("                  GUTTMAN SCALOGRAM ANALYSIS");
    FrmOutPut->RichOutPut->Lines->Add("                        Cornell Method");
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No. of Cases = %3d.  No. of items = %3d",NoCases,NoVariables);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("RESPONSE MATRIX");
    int first = 0;
    int last;
    last = first + 5; // column (item) index
    if (last > NoSelected) last = NoSelected;
    bool done = false;
    do  //loop through all of the score groups
    {
        FrmOutPut->RichOutPut->Lines->Add("Subject Row                    Item Number");
        strcpy(outline,"Label Sum");
        for (int i = first; i < last; i++)
        {
            sprintf(astring,"%10s",VarLabels[sequence[i]].c_str());
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"           ");
        for (int i = first; i < last; i++)
        {
            sprintf(astring,"   0    1 ");
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 0; i < NoCases; i++) // rows
        {
            if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
            sprintf(outline," %3d  %3d  ",CaseNo[i],RowTots[i]);
            for (int j = first; j < last; j++)
            {
                sprintf(astring," %3d  %3d ",FreqMat0[i][j],FreqMat1[i][j]);
                strcat(outline,astring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            strcpy(outline,"           ");
            // check for optimal cut point for this score
            for (int j = first; j < last; j++)
            {
                if (CutScore[j] == i)
                {
                    sprintf(astring,"   -cut-  ");
                    strcat(outline,astring);
                }
                else
                {
                    sprintf(astring,"          ");
                    strcat(outline,astring);
                }
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            strcpy(outline,"");
        } // Next row (score group)
        FrmOutPut->RichOutPut->Lines->Add("");
        strcpy(outline,"TOTALS     ");
        for (int j = first; j < last; j++)
        {
            sprintf(astring," %3d  %3d ",ColTots[j][0],ColTots[j][1]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"ERRORS     ");
        for (int j = first; j < last; j++)
        {
            sprintf(astring," %3d  %3d ",ErrorMat[j][0],ErrorMat[j][1]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        if (last < NoSelected)
        {
            first = last;
            last = first + 5; // column (item) index
            if (last > NoSelected) last = NoSelected;
        }
        else done = true;
        FrmOutPut->RichOutPut->Lines->Add("");
    } while (!done);
    FrmOutPut->RichOutPut->Lines->Add("");
    double CoefRepro = 0.0;
    for (int j = 0; j < NoSelected; j++)
        CoefRepro += ErrorMat[j][0] + ErrorMat[j][1];
    CoefRepro = 1.0 - (CoefRepro / (double(NoCases) * double(NoSelected)));
    sprintf(outline,"Coefficient of Reproducibility = %6.3f",CoefRepro);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    //-----------------------------GOODENOUGH----------------------------------
    // Complete Goodenough method and print results
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("                  GUTTMAN SCALOGRAM ANALYSIS");
    FrmOutPut->RichOutPut->Lines->Add("          Goodenough Modification Using Modal Responses");
    int errors = 0;
    int totalerrors = 0;
    double Min_Coeff = 0.0;
    for (int i = 0; i < NoSelected+1; i++)
        for (int j = 0; j < NoSelected; j++) ModalArray[i][j] = 0;
    for (int i = 0; i < NoSelected; i++) // column
    {
        ColProps[i] = double(ColTots[i][1]) / double(NoCases);
        ErrorMat[i][0] = 0;
        ErrorMat[i][1] = 0;
    }
    // Get the cut scores for each score row based on rounded proportions
    for (int i = 0; i < NoSelected; i++)
    {
        CutScore[i] = floor(ColProps[i] * double(NoSelected+1));
    }
    // Build modal response array for the total scores by items
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("       MODAL ITEM RESPONSES");
    FrmOutPut->RichOutPut->Lines->Add("TOTAL                 ITEMS");
    strcpy(outline,"     ");
    for (int i = 0; i < NoSelected; i++)
    {
        sprintf(astring,"%10s",VarLabels[sequence[i]].c_str());
        strcat(outline,astring);
    }
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (int i = 0; i < NoSelected+1; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            if (CutScore[j] > i) ModalArray[i][j] = 1;
            else ModalArray[i][j] = 0;
        }
        sprintf(astring," %3d ",NoSelected - i);
        strcpy(outline,astring);
        for (int j = 0; j < NoSelected; j++)
        {
            sprintf(astring,"    %3d   ",ModalArray[i][j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No. of Cases = %3d.  No. of items = %3d",NoCases,NoVariables);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("RESPONSE MATRIX");
    first = 0;
    last = first + 5; // column (item) index
    if (last > NoSelected) last = NoSelected;
    done = false;
    do  //loop through all of the score groups
    {
        FrmOutPut->RichOutPut->Lines->Add("Subject Row Error                    Item Number");
        strcpy(outline,"Label  Sum Count");
        for (int i = first; i < last; i++)
        {
            sprintf(astring,"%10s",VarLabels[sequence[i]].c_str());
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        strcpy(outline,"                 ");
        for (int i = first; i < last; i++)
        {
            sprintf(astring,"   0    1 ");
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 0; i < NoCases; i++) // rows
        {
            if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
            errors = 0;
            for (int j = first; j < last; j++)
            {
                int rowno = NoSelected - RowTots[i];
                if (FreqMat1[i][j] != ModalArray[rowno][j]) errors++;
            }

            sprintf(outline," %3d  %3d  %3d   ",CaseNo[i],RowTots[i],errors);
            for (int j = first; j < last; j++)
            {
                sprintf(astring," %3d  %3d ",FreqMat0[i][j],FreqMat1[i][j]);
                strcat(outline,astring);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
            totalerrors += errors;
        } // Next row (score group)
        FrmOutPut->RichOutPut->Lines->Add("");

        strcpy(outline,"TOTALS           ");
        for (int j = first; j < last; j++)
        {
            sprintf(astring," %3d  %3d ",ColTots[j][0],ColTots[j][1]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);

        strcpy(outline,"PROPORTIONS      ");
        for (int j = first; j < last; j++)
        {
            sprintf(astring,"% 4.2f %4.2f",1.0-ColProps[j],ColProps[j]);
            strcat(outline,astring);
        }
        FrmOutPut->RichOutPut->Lines->Add(outline);

        if (last < NoSelected)
        {
            first = last + 1;
            last = first + 5; // column (item) index
            if (last > NoSelected) last = NoSelected;
        }
        else done = true;
        FrmOutPut->RichOutPut->Lines->Add("");
    } while (!done);
    FrmOutPut->RichOutPut->Lines->Add("");
    CoefRepro = 1.0 - (double(totalerrors) / double(NoCases * NoSelected));
    sprintf(outline,"Coefficient of Reproducibility = %6.3f",CoefRepro);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    for (int j = 0; j < NoSelected; j++)
    {
        if (ColProps[j] > (1.0 - ColProps[j])) Min_Coeff += ColProps[j];
        else Min_Coeff += (1.0 - ColProps[j]);
    }
    Min_Coeff /= double(NoSelected);
    sprintf(outline,"Minimal Marginal Reproducibility = %6.3f",Min_Coeff);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // Clean up the heap
    for (int i = 0; i < NoSelected+1; i++) delete[] ModalArray[i];
    delete[] ModalArray;
    for (int i = 0; i < NoSelected; i++) delete[] ErrorMat[i];
    delete[] ErrorMat;
    delete[] CutScore;
    delete[] CaseVector;
    for (int i = 0; i < NoSelected; i++) delete[] ColTots[i];
    delete[] ColTots;
    delete[] ColProps;
    delete[] RowTots;
    for (int i = 0; i < NoCases; i++) delete[] FreqMat1[i];
    delete[] FreqMat1;
    for (int i = 0; i < NoCases; i++) delete[] FreqMat0[i];
    delete[] FreqMat0;
    delete[] CaseNo;
    delete[] sequence;
    delete[] VarLabels;
    delete[] ColNoSelected;

    FrmVarSel->ChkBox->Visible = true;
}
//---------------------------------------------------------------------------

