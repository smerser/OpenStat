//---------------------------------------------------------------------------
#ifndef TransformsH
#define TransformsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>

//---------------------------------------------------------------------------
class TFrmTransform : public TForm
{
__published:	// IDE-managed Components
    TListBox *ListBox1;
    TLabel *Label1;
    TBitBtn *Var1In;
    TBitBtn *Var1Out;
    TBitBtn *Var2In;
    TBitBtn *Var2Out;
    TLabel *Label2;
    TEdit *Var1Edit;
    TLabel *Label3;
    TEdit *Var2Edit;
    TLabel *Label4;
    TEdit *ConstantEdit;
    TLabel *Label5;
    TListBox *TrnsfrmLst;
    TLabel *Label6;
    TEdit *NewEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
    TLabel *Label7;
    TEdit *SelectEdit;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall Var1InClick(TObject *Sender);
    void __fastcall Var1OutClick(TObject *Sender);
    void __fastcall Var2InClick(TObject *Sender);
    void __fastcall Var2OutClick(TObject *Sender);
    void __fastcall TrnsfrmLstClick(TObject *Sender);
private:	// User declarations
    int TIndex;
public:		// User declarations
    __fastcall TFrmTransform(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmTransform *FrmTransform;
//---------------------------------------------------------------------------
#endif
    double * Rank(int v1col);
    double * PRank(int v1col);

