//---------------------------------------------------------------------------

#ifndef VarComboUnitH
#define VarComboUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TVarComboForm : public TForm
{
__published:	// IDE-managed Components
        TRadioGroup *ComboGrp;
        TListBox *VarList;
        TLabel *Label1;
        TBitBtn *Var1In;
        TBitBtn *Var1Out;
        TLabel *Label2;
        TListBox *SelList;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TLabel *Label3;
        TEdit *NewVarEdit;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall Var1InClick(TObject *Sender);
        void __fastcall Var1OutClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TVarComboForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TVarComboForm *VarComboForm;
//---------------------------------------------------------------------------
#endif
