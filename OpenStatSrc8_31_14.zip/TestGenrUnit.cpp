//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <math.h>
#include "Math.hpp"
#include <stdio.h>
#include "DictionaryUnit.h"
#include <stdlib.h>
#include "DataFuncs.h"
#include "TestGenrUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestGenrFrm *TestGenrFrm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
//---------------------------------------------------------------------------
__fastcall TTestGenrFrm::TTestGenrFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::CancelBtnClick(TObject *Sender)
{
    TestGenrFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::ContBtnClick(TObject *Sender)
{
    // Generate item responses for subject items and place in the grid
//    Generate();
    double test_var, true_var, total_item_var, true_item_var;
    double error_item_var, true_score;
    double reliability;
    double test_stddev, test_mean, X, error_score;
    double *random_mean;
    double *item_var;
    double *item_mean;
    long double tempmean;
    int no_cases, no_items, itemtype;
    char outline[121];
    char astring[21];

    if ((NoCases > 0) || (NoVariables > 0))
    {
        Application->MessageBox("You must first close the current file.",
        "ERROR",MB_OK);
        CancelBtnClick(this);
    }

    itemtype = ItemTypeGroup->ItemIndex; // 0=T-F, 1 = MC, 2 = continuous
    test_stddev = atof(StdDevEdit->Text.c_str());
    test_var = test_stddev * test_stddev;
    reliability = atof(RelEdit->Text.c_str());
    true_var = test_var * reliability;
    no_items = atoi(NoItemsEdit->Text.c_str());
    no_cases = atoi(NoCasesEdit->Text.c_str());
    test_mean = atof(MeanEdit->Text.c_str());
    total_item_var = (test_var / double(no_items)) * (1.0 -
        (double(no_items - 1) / no_items) * reliability);
    true_item_var = total_item_var * reliability;
    error_item_var = total_item_var - true_item_var;
    tempmean = test_mean / double(no_items);

    try
    {
        item_mean = new double[no_items];
        item_var = new double[no_items];
        random_mean = new double[no_items];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in test generation","ERROR",MB_OK);
        CancelBtnClick(this);
    }
    MainForm->Grid->RowCount = no_cases + 1;
    MainForm->Grid->ColCount = no_items + 1;
    for (int i = 0; i < no_items; i++)
    {
        sprintf(outline,"Item %d",i+1);
        MainForm->Grid->Cells[i+1][0] = outline;
    }
    for (int i = 0; i < no_cases; i++)
    {
        sprintf(outline,"CASE %d",i+1);
        MainForm->Grid->Cells[0][i+1] = outline;
    }
    for (int i = 0; i < no_items; i++)
    {
        item_mean[i] = 0.0;
        item_var[i] = 0.0;
        random_mean[i] = RandG(tempmean,sqrt(total_item_var));
    }
    for (int k = 0; k < no_cases; k++)
    {
        true_score = RandG(0.0,sqrt(true_var));
        true_score /= double(no_items);
        for (int i = 0; i < no_items; i++)
        {
            error_score = RandG(0.0,sqrt(error_item_var));
            X = true_score + error_score + random_mean[i];
            if (itemtype == 0) // dichotomous item
            {
                if (X >= random_mean[i]) X = 1.0;
                else X = 0.0;
            }
            if (itemtype == 0) sprintf(outline,"%2.0f",X);
            else sprintf(outline,"%6.4f",X);
            MainForm->Grid->Cells[i+1][k+1] = outline;
        } // end item loop
    } // end case loop
    NoCases = no_cases;
    MainForm->NoVarsEdit->Text = no_items;
    MainForm->NoCasesEdit->Text = NoCases;
    MainForm->Grid->Row = 1;
    MainForm->Grid->Col = 1;
    MainForm->RowEdit->Text = 1;
    MainForm->ColEdit->Text = 1;
    for (int col = 1; col <= no_items; col++)
    {
        NewVar(col,false);
        sprintf(astring,"ITEM%d",col);
        DictionaryForm->DGrid->Cells[1][col] = astring;
        MainForm->Grid->Cells[col][0] = astring;
    }
    // clean up the heap
    delete[] random_mean;
    delete[] item_var;
    delete[] item_mean;

    TestGenrFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::NoItemsEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) NoCasesEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::NoCasesEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) MeanEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::MeanEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) StdDevEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::StdDevEditKeyPress(TObject *Sender,
      char &Key)
{
    if (Key == 13) RelEdit->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::RelEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) ContBtn->SetFocus();    
}
//---------------------------------------------------------------------------
void __fastcall TTestGenrFrm::FormShow(TObject *Sender)
{
    NoItemsEdit->Text = "";
    NoCasesEdit->Text = "";
    MeanEdit->Text = "";
    StdDevEdit->Text = "";
    RelEdit->Text = "";
    ItemTypeGroup->ItemIndex = 0;
}
//---------------------------------------------------------------------------

