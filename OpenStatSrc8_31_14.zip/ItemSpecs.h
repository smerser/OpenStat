//---------------------------------------------------------------------------
#ifndef ItemSpecsH
#define ItemSpecsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TItemScoreForm : public TForm
{
__published:	// IDE-managed Components
    TButton *OKBtn;
    TLabel *Label1;
    TEdit *ItemNoEdit;
    TLabel *Label2;
    TEdit *ScaleNoEdit;
    TLabel *Label3;
    TEdit *NoItemsEdit;
    TUpDown *UpDown1;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *CorrectEdit;
    TLabel *Label7;
    TEdit *WeightEdit;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TLabel *Label11;
    void __fastcall UpDown1Click(TObject *Sender, TUDBtnType Button);
    void __fastcall CorrectEditKeyPress(TObject *Sender, char &Key);
    void __fastcall OKBtnClick(TObject *Sender);
    void __fastcall WeightEditKeyPress(TObject *Sender, char &Key);
    
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TItemScoreForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TItemScoreForm *ItemScoreForm;
//---------------------------------------------------------------------------
#endif
