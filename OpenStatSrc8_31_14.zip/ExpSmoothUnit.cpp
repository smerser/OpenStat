//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ExpSmoothUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TExpSmoothFrm *ExpSmoothFrm;
//---------------------------------------------------------------------------
__fastcall TExpSmoothFrm::TExpSmoothFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TExpSmoothFrm::FormShow(TObject *Sender)
{
    AlphaEdit->Text = "0.99";
    AlphaScroll->Position = 99;
    alpha = 0.99;    
}
//---------------------------------------------------------------------------
void __fastcall TExpSmoothFrm::CancelBtnClick(TObject *Sender)
{
    ExpSmoothFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TExpSmoothFrm::AlphaScrollChange(TObject *Sender)
{
    AlphaEdit->Text = AlphaScroll->Position / 100.0;
    alpha = AlphaScroll->Position / 100.0;
}
//---------------------------------------------------------------------------
