//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
// #include "GraphUnit.h"
#include "DiscMano.h"
#include "Discrim.h"
#include "MainUnit.h"
#include "functions.h"
#include "OutPut.h"
#include "MatrixUnit.h"
#include "DataFuncs.h"
#include "DictionaryUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "MemMgrUnit.h"
#include "PlotUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;
extern FileType;
extern struct VarDef *vdef[1000];

void Discriminant(void)
{
    int NoSelected, tempcol;
    int GroupVar;
    int MinGrp;
    int MaxGrp;
    int NoGrps;
    int nowithin;
    int TotalCases = 0;
    int *ColNoSelected;
    int *CaseNo;
    int *NoInGrp;
    int value;
    int grpno;
    AnsiString *VarLabels;
    AnsiString *ColLabels;
    AnsiString GroupLabel;
    AnsiString *GrpNos;
    double X, Y;
    double **WithinMat;
    double **WithinInv;
    double **WinvB;
    double **v; // work area for tridiagonalization in inverse proc
    double **PooledW;
    double **TotalMat;
    double **BetweenMat;
    double **EigenVectors;
    double **EigenTrans;
    double **TempMat;
    double **Theta;
    double **DiagMat;
    double **CoefMat;
    double **RawCMat;
    double **GrpMeans;
    double **GrpSDevs;
    double **Centroids;
    double **Structure;
    double *Constants;
    double *ScoreVar;
    double *Roots;
    double *Pcnts;
    double *TotalMeans;
    double *TotalVariances;
    double *TotalStdDevs;
    double *WithinMeans;
    double *WithinVariances;
    double *WithinStdDevs;
    double *w; // work vector for tridiagonalization in inverse proc
    char outline[121];
    bool errorcode, results;
    AnsiString cellstring;
    int result, intvalue;
    double dblvalue;
    AnsiString strvalue;

    if (FileType == 9) // matrix entered
    {
        Application->MessageBox("Only raw data can be used in this program.","ERROR",MB_OK);
        return;
    }

    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("MULTIVARIATE ANOVA / DISCRIMINANT FUNCTION");
    FrmOutPut->RichOutPut->Lines->Add("Reference: Multiple Regression in Behavioral Research");
    FrmOutPut->RichOutPut->Lines->Add("Elazar J. Pedhazur, 1997, Chapters 20-21");
    FrmOutPut->RichOutPut->Lines->Add("Harcourt Brace College Publishers");
    NoSelected = DiscrimForm->ListBox2->Items->Count;
    if (NoSelected < 2)
    {
        ShowMessage("ERROR! You must initially select 2 or more variables.");
        return;
    }

    try  {
        ColNoSelected = new int[NoSelected+1];
        VarLabels = new AnsiString[NoSelected];
        ColLabels = new AnsiString[NoSelected];
        CaseNo = new int[NoCases];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Get items selected
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoVariables; j++)
        {
            if (DiscrimForm->ListBox2->Items->Strings[i] ==
                MainForm->Grid->Cells[j+1][0])
            {
                ColNoSelected[i] = j+1;
                VarLabels[i] = MainForm->Grid->Cells[j+1][0];
/*
                result = VarTypeChk(j+1,0);
                if (result == 1)
                {
                        delete[] CaseNo;
                        delete[] ColLabels;
                        delete[] VarLabels;
                        delete[] ColNoSelected;
                        return;
                }
*/
            }
        }
    }
    for (int j = 0; j < NoVariables; j++)
    {
            if (DiscrimForm->GroupVar->Text == MainForm->Grid->Cells[j+1][0])
            {
                GroupVar = j+1;
                GroupLabel = MainForm->Grid->Cells[j+1][0];
                ColNoSelected[NoSelected] = j+1;
                // check to see if group variable is a string variable
                cellstring = DictionaryForm->DGrid->Cells[3][GroupVar];
                if (cellstring == "2") // recode into an integer code
                {
                        results = StringsToInt(GroupVar, tempcol, true);
                        GroupVar = NoVariables;
                        ColNoSelected[NoSelected] = GroupVar;
                        GroupLabel = "GroupCode";
                }
            }
    }
/*
    result = VarTypeChk(GroupVar,1);
    if (result == 1)
    {
        delete[] CaseNo;
        delete[] ColLabels;
        delete[] VarLabels;
        delete[] ColNoSelected;
        return;
    }
*/
    //Allocate memory for analyses
    try  {
        WithinMat = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) WithinMat[i] = new double[NoSelected];
        WithinInv = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) WithinInv[i] = new double[NoSelected];
        WinvB = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) WinvB[i] = new double[NoSelected];
        v = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) v[i] = new double[NoSelected+1];
        PooledW = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) PooledW[i] = new double[NoSelected];
        TotalMat = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) TotalMat[i] = new double[NoSelected];
        BetweenMat = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) BetweenMat[i] = new double[NoSelected];
        EigenVectors = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) EigenVectors[i] = new double[NoSelected];
        EigenTrans = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) EigenTrans[i] = new double[NoSelected];
        TempMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TempMat[i] = new double[NoSelected+1];
        Theta = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) Theta[i] = new double[NoSelected];
        DiagMat = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) DiagMat[i] = new double[NoSelected];
        CoefMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) CoefMat[i] = new double[NoSelected+1];
        RawCMat = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) RawCMat[i] = new double[NoSelected];
        Structure = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) Structure[i] = new double[NoSelected];
        Constants = new double[NoSelected];
        ScoreVar = new double[NoSelected];
        Roots = new double[NoSelected];
        Pcnts = new double[NoSelected];
        TotalMeans = new double[NoSelected];
        TotalVariances = new double[NoSelected];
        TotalStdDevs = new double[NoSelected];
        WithinMeans = new double[NoSelected];
        WithinVariances = new double[NoSelected];
        WithinStdDevs = new double[NoSelected];
        w = new double[NoSelected+1];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Initialize arrays
    for (int i = 0; i < NoSelected; i++)
    {
        TotalMeans[i] = 0.0;
        TotalVariances[i] = 0.0;
        WithinMeans[i] = 0.0;
        WithinVariances[i] = 0.0;
        for (int j = 0; j < NoSelected; j++)
        {
            TotalMat[i][j] = 0.0;
            WithinMat[i][j] = 0.0;
            PooledW[i][j] = 0.0;
        }
    }
    oldcolcnt = NoVariables;

    //Get minimum and maximum group numbers (and no. of groups)
    MinGrp = 1000; //atoi(MainForm->Grid->Cells[GroupVar][1].c_str());
    MaxGrp = 0; //MinGrp;
    for (int i = 0; i < NoCases; i++)
    {

        if (ValidRecord(i+1,ColNoSelected,NoSelected+1))
        {
            value = floor(StrToFloat(MainForm->Grid->Cells[GroupVar][i+1]));
            //result = GetValue(i+1,GroupVar,intvalue,dblvalue,strvalue);
            //if (result == 1) value = 0;
            //else value = intvalue;
            if (value < MinGrp) MinGrp = value;
            if (value > MaxGrp) MaxGrp = value;
        }
    } // next case
    NoGrps = MaxGrp - MinGrp + 1;

    //Allocate space for group means, standard deviations and centroids
    try  {
        GrpMeans = new double *[NoGrps];
        for (int i = 0; i < NoGrps; i++) GrpMeans[i] = new double[NoSelected];
        GrpSDevs = new double *[NoGrps];
        for (int i = 0; i < NoGrps; i++) GrpSDevs[i] = new double[NoSelected];
        Centroids = new double *[NoGrps];
        for (int i = 0; i < NoGrps; i++) Centroids[i] = new double[NoSelected];
        GrpNos = new AnsiString [NoGrps];
        NoInGrp = new int[NoGrps];
    }
    catch (...)
    {
        Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    //Initialize group variables
    for (int i = 0; i < NoGrps; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            Centroids[i][j] = 0.0;
            GrpMeans[i][j] = 0.0;
            GrpSDevs[i][j] = 0.0;
        }
    }

    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"Total Cases = %d, Number of Groups = %d",
            NoCases, NoGrps);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");

    //Read the data for each group, accumulating cross-products and sums
    for (int grp = 0; grp < NoGrps; grp++)
    {
        nowithin = 0;
        int grpvalue = MinGrp + grp;
        for (int i = 0; i < NoCases; i++) // data rows
        {
            if (ValidRecord(i+1,ColNoSelected,NoSelected+1))
            {
                grpno = floor(StrToFloat(MainForm->Grid->Cells[GroupVar][i+1]));
                if (grpno == grpvalue) // case belongs to this group
                {
                    GrpNos[grp] = grpno;
                    nowithin++;
                    TotalCases++;
                    for (int j = 0; j < NoSelected; j++) // matrix row
                    {
                        int matrow = ColNoSelected[j];
                        X = StrToFloat(MainForm->Grid->Cells[matrow][i+1]);
                        //result = GetValue(i+1,matrow,intvalue,dblvalue,strvalue);
                        //if (result == 1) X = 0.0;
                        //else X = dblvalue;
                        for (int k = 0; k < NoSelected; k++) // matrix col.
                        {
                            int matcol = ColNoSelected[k];
                            Y = StrToFloat(MainForm->Grid->Cells[matcol][i+1]);
                            //result = GetValue(i+1,matcol,intvalue,dblvalue,strvalue);
                            //if (result == 1) Y = 0.0;
                            //else Y = dblvalue;
                            WithinMat[j][k] += X * Y;
                            TotalMat[j][k] += X * Y;
                        }
                        WithinMeans[j] += X;
                        WithinVariances[j] += (X * X);
                        TotalMeans[j] += X;
                        TotalVariances[j] += (X * X);
                    } // next variable j
                } // if group number match
            } // end if valid record
        } // next case
        // Does user want cross-products matrices ?
        if (DiscrimForm->CheckBox2->Checked == true)
        {
            // print within matrix
            char ColHead[121];
            sprintf(ColHead,"Group %d, N = %d",grpvalue,nowithin);
            char Title[135];
            sprintf(Title,"WITHIN GROUP SUM OF CROSS-PRODUCTS");
            ArrayPrint(WithinMat, NoSelected, NoSelected, ColHead,VarLabels,
                VarLabels, Title);
            FrmOutPut->ShowModal();
        }

        // Convert to deviation cross-products and pool
        for (int j = 0; j < NoSelected; j++)
        {
            for (int k = 0; k < NoSelected; k++)
            {
                WithinMat[j][k] -= (WithinMeans[j] * WithinMeans[k] / double(nowithin));
                PooledW[j][k] += WithinMat[j][k];
            }
        }

        // Does user want deviation cross-products?
        if (DiscrimForm->CheckBox3->Checked == true)
        {
            // print within matrix
            char ColHead[121];
            sprintf(ColHead,"Group %d, N = %d",grpvalue,nowithin);
            char Title[147];
            sprintf(Title,"WITHIN GROUP SUM OF DEVIATION CROSS-PRODUCTS");
            ArrayPrint(WithinMat, NoSelected, NoSelected, ColHead,VarLabels,
                VarLabels, Title);
            FrmOutPut->ShowModal();
        }

        // Compute descriptives from sums and sums of squares
        for (int j = 0; j < NoSelected; j++)
        {
            WithinVariances[j] -= (WithinMeans[j] * WithinMeans[j] / double(nowithin));
            WithinVariances[j] /= double(nowithin-1);
            WithinStdDevs[j] = sqrt(WithinVariances[j]);
            WithinMeans[j] /= double(nowithin);
        }

        // Does user want descriptives ?
        if (DiscrimForm->CheckBox1->Checked == true)
        {
            // print mean, variance and std. dev.s for variables
            sprintf(outline,"MEANS FOR GROUP %d, N = %d",grp+1,nowithin);
            VPrint(WithinMeans, NoSelected, VarLabels, outline);
            sprintf(outline,"VARIANCES FOR GROUP %d",grp+1);
            VPrint(WithinVariances, NoSelected, VarLabels, outline);
            sprintf(outline,"STANDARD DEVIATIONS FOR GROUP %d",grp+1);
            VPrint(WithinStdDevs, NoSelected, VarLabels, outline);
            FrmOutPut->ShowModal();
        }

        // Now initialize for the next group and save descriptives
        for (int j = 0; j < NoSelected; j++)
        {
            GrpMeans[grp][j] = WithinMeans[j];
            WithinMeans[j] = 0.0;
            GrpSDevs[grp][j] = WithinStdDevs[j];
            WithinVariances[j] = 0.0;
            for (int k = 0; k < NoSelected; k++) WithinMat[j][k] = 0.0;
        }
        NoInGrp[grp] = nowithin;
    } // next group

    // Does user want cross-products matrices ?
    if (DiscrimForm->CheckBox2->Checked == true)
    {
        // print Total cross-products matrix
        char ColHead[121];
        sprintf(ColHead,"Variables");
        char Title[135];
        sprintf(Title,"TOTAL SUM OF CROSS-PRODUCTS");
        ArrayPrint(TotalMat, NoSelected, NoSelected, ColHead,VarLabels,
                VarLabels, Title);
        FrmOutPut->ShowModal();
    }

    //Obtain Total deviation cross-products
    for (int j = 0; j < NoSelected; j++)
        for (int k = 0; k < NoSelected; k++)
            TotalMat[j][k] -= (TotalMeans[j] * TotalMeans[k] / double(TotalCases));

    // Does user want deviation cross-products?
    if (DiscrimForm->CheckBox3->Checked == true)
    {
        // print total deviation cross-products matrix
        char ColHead[121];
        sprintf(ColHead,"Variables");
        char Title[147];
        sprintf(Title,"TOTAL SUM OF DEVIATION CROSS-PRODUCTS");
        ArrayPrint(TotalMat, NoSelected, NoSelected, ColHead,VarLabels,
                VarLabels, Title);
        FrmOutPut->ShowModal();
    }
    for (int j = 0; j < NoSelected; j++)
    {
        TotalVariances[j] -= (TotalMeans[j] * TotalMeans[j] / double(TotalCases));
        TotalVariances[j] /= double(TotalCases - 1);
        TotalStdDevs[j] = sqrt(TotalVariances[j]);
        TotalMeans[j] /= double(TotalCases);
    }

    // Does user want descriptives ?
    if (DiscrimForm->CheckBox1->Checked == true)
    {
        // print mean, variance and std. dev.s for variables
        char Title[120];
        strcpy(Title, "MEANS");
        VPrint(TotalMeans, NoSelected, VarLabels, Title);
        strcpy(Title,"VARIANCES");
        VPrint(TotalVariances, NoSelected, VarLabels, Title);
        strcpy(Title,"STANDARD DEVIATIONS");
        VPrint(TotalStdDevs, NoSelected, VarLabels, Title);
        FrmOutPut->ShowModal();
    }

    // Obtain between groups deviation cross-products matrix
    matsub(BetweenMat,TotalMat,PooledW,NoSelected,NoSelected);

    // Does user want deviation cross-products?
    if (DiscrimForm->CheckBox3->Checked == true)
    {
        // print between groups deviation cross-products matrix
        char ColHead[121];
        sprintf(ColHead,"Variables");
        char Title[148];
        sprintf(Title,"BETWEEN GROUPS SUM OF DEVIATION CROSS-PRODUCTS");
        ArrayPrint(BetweenMat, NoSelected, NoSelected, ColHead,VarLabels,
                VarLabels, Title);
        FrmOutPut->ShowModal();
    }

    // Do univariate ANOVA's for each variable
    if (DiscrimForm->CheckBox6->Checked == true)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            sprintf(outline,"UNIVARIATE ANOVA FOR VARIABLE %s",VarLabels[j].c_str());
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("SOURCE    DF       SS        MS        F         PROB > F");
            double GroupSS = BetweenMat[j][j];
            double ErrorSS = PooledW[j][j];
            double TotalSS = TotalMat[j][j];
            double DFGroup = NoGrps - 1;
            double DFError = TotalCases - NoGrps;
            double DFTotal = TotalCases - 1;
            double GroupMS = GroupSS / DFGroup;
            double ErrorMS = ErrorSS / DFError;
            double Fratio  = GroupMS / ErrorMS;
            double probf = ftest(DFGroup,DFError,Fratio);
            sprintf(outline,"BETWEEN   %3.0f%10.3f%10.3f%10.3f%10.3f",
                DFGroup,GroupSS,GroupMS,Fratio,probf);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"ERROR     %3.0f%10.3f%10.3f",DFError,ErrorSS,ErrorMS);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            sprintf(outline,"TOTAL     %3.0f%10.3f",DFTotal,TotalSS);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            FrmOutPut->RichOutPut->Lines->Add("");
        }
        FrmOutPut->ShowModal();
    }

    // Get roots of the product of the within group inverse times between
    // Inverse routine starts at 1, not 0.  Setup temps for inverse
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            TempMat[i+1][j+1] = PooledW[i][j];
    matinv(TempMat,NoSelected,CoefMat,v,w);
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            WithinInv[i][j] = CoefMat[i+1][j+1];

    // Does user want inverse of pooled within deviation cross-products?
    if (DiscrimForm->CheckBox20->Checked == true)
    {
        ArrayPrint(WithinInv, NoSelected, NoSelected, "Variables", VarLabels,
                VarLabels, "Inverse of Pooled Within Deviation Cross-Products Matrix");
        FrmOutPut->ShowModal();
    }

    // Get roots of the W inverse times Betweeen matrices
    MATAxB(WinvB,WithinInv,BetweenMat,NoSelected,NoSelected,NoSelected,NoSelected,errorcode);
    double minroot = 0.0;
    int noroots;
    if (NoGrps <= NoSelected) noroots = NoGrps-1;
    else noroots = NoSelected;
    double trace = 0.0;
    double pcnttrace = 0.0;
    nonsymroots(WinvB,NoSelected,noroots,minroot,EigenVectors,Roots,Pcnts,trace,pcnttrace);
    sprintf(outline,"Number of roots extracted = %d",noroots);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Percent of trace extracted = %10.4f",pcnttrace);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Roots of the W inverse time B Matrix");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No.       Root   Proportion   Canonical R    Chi-Squared  D.F.    Prob.");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    double Lambda = 1.0;
    double ChiSquare = 0.0;
    double Pillia = 0.0;
    for (int i = 0; i < noroots; i++)
    {
        Lambda *= (1.0 / (1.0 + Roots[i]));
        ChiSquare += log(1.0 + Roots[i]);
        Pillia += (Roots[i] / (1.0 + Roots[i]));
    }
    double TotChi = ChiSquare;
    for (int i = 0; i < noroots; i++)
    {
        double p = Roots[i] / trace;
        double Rc = sqrt(Roots[i] / (1.0 + Roots[i]));
        int dfchi = (NoSelected - i) * (NoGrps - i-1);
        double chi = TotChi * (double(TotalCases) - 1.0 - 0.5 * double(NoSelected + NoGrps));
        double chiprob = 1.0 - chisquaredprob(chi,dfchi);
        sprintf(outline,"%2d  %10.4f   %6.4f        %6.4f        %10.4f   %3d    %6.3f",
                i+1,Roots[i],p,Rc,chi,dfchi,chiprob);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        TotChi -= log(1.0 + Roots[i]);
    }
    ChiSquare *= (double(TotalCases - 1) - (0.5 * double(NoSelected + NoGrps)));
    FrmOutPut->ShowModal();

    for (int i = 0; i < noroots; i++) ColLabels[i] = i+1;
    if (DiscrimForm->CheckBox8->Checked == true)
    {
        ArrayPrint(EigenVectors, NoSelected, noroots, "Root No",VarLabels,
                ColLabels, "Eigenvectors of the W inverse x B Matrix");
        FrmOutPut->ShowModal();
    }

    // Now get covariance matrices for the total and within
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            TotalMat[i][j] /= double(TotalCases - 1);
            PooledW[i][j] /= double(TotalCases - NoGrps);
        }
    }

    if (DiscrimForm->CheckBox4->Checked == true)
    {
        ArrayPrint(PooledW,NoSelected,NoSelected,"Variables",VarLabels,
                   VarLabels,"Pooled Within-Groups Covariance Matrix");
        ArrayPrint(TotalMat,NoSelected, NoSelected,"Variables",VarLabels,
                   VarLabels,"Total Covariance Matrix");
        FrmOutPut->ShowModal();
    }

    //Get the pooled within groups variance-covariance of disc. scores matrix v'C v
    MATTRN(EigenTrans,EigenVectors, NoSelected,noroots); // v'
    MATAxB(TempMat,EigenTrans,PooledW,noroots,NoSelected,NoSelected,NoSelected,errorcode);//v'C
    MATAxB(Theta,TempMat,EigenVectors,noroots,NoSelected,NoSelected,noroots,errorcode); //v'C v

    //Create a diagonal matrix with square roots of the diagonal of the Within
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            if (i != j) DiagMat[i][j] = 0.0;
            else DiagMat[i][j] = sqrt(PooledW[i][j]);
        }
    }

    // Get recipricol of standard deviations of each function
    for (int i = 0; i < noroots; i++)
        ScoreVar[i] = 1.0 / sqrt(Theta[i][i]);

    // Divide coefficients by their standard deviations
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < noroots; j++)
        {
            RawCMat[i][j] = EigenVectors[i][j] * ScoreVar[j]; // raw coeff.
            //CoefMat[i][j] *= ScoreVar[j];
            CoefMat[i][j] = RawCMat[i][j] * sqrt(PooledW[i][i]);
        }
    }
    // Get constants for raw score equations
    for (int i = 0; i < noroots; i++)
    {
        Constants[i] = 0.0;
        for (int j = 0; j < NoSelected; j++)
        {
            Constants[i] = Constants[i] - (RawCMat[j][i] * TotalMeans[j]);
        }
    }

    if (DiscrimForm->CheckBox9->Checked == true)
    {
        ArrayPrint(RawCMat,NoSelected, noroots,"Root No",VarLabels,
                   ColLabels,"Raw Discriminant Function Coefficients from Pooled Covariance");
        VPrint(Constants,noroots,ColLabels,"Raw Discriminant Function Constants");
        FrmOutPut->ShowModal();
    }

    //Does user want to classify cases using canonical functions?
    if (DiscrimForm->CheckBox23->Checked == true)
    {
        Classify(PooledW, GrpMeans, ColNoSelected, NoSelected, NoCases,
                 GroupVar, NoGrps, NoInGrp, VarLabels);
        FrmOutPut->ShowModal();
        ClassIt(PooledW,ColNoSelected,GrpMeans,Roots,noroots,GroupVar,
                NoGrps,NoInGrp,NoSelected,NoCases,RawCMat,Constants);
        FrmOutPut->ShowModal();
    }

    // Plot discriminant scores?
    if (DiscrimForm->CheckBox21->Checked == true)
    {
        PlotPts(RawCMat,Constants,ColNoSelected,NoSelected,
            noroots,NoCases,GroupVar,NoGrps,NoInGrp);
    }

    if (DiscrimForm->CheckBox10->Checked == true)
    {
        ArrayPrint(CoefMat,NoSelected,noroots,"Root No",VarLabels,
                   ColLabels,"Standardized Discriminant Function Coefficients from Pooled Covariance");
        FrmOutPut->ShowModal();
    }

    // Calculate centroids
    for (int k = 0; k < NoGrps; k++)
    {
        for (int i = 0; i < noroots; i++)
        {
            for (int j = 0; j < NoSelected; j++)
            {
                Centroids[k][i] += (RawCMat[j][i] * GrpMeans[k][j]);
            }
            Centroids[k][i] += Constants[i];
        }
    }
    if (DiscrimForm->CheckBox11->Checked == true)
    {
        ArrayPrint(Centroids,NoGrps,noroots,"Root No",GrpNos,
                   ColLabels,"Centroids");
        FrmOutPut->ShowModal();
    }

    // Get variance-covariance matrix of functions (theta)
    MATTRN(EigenTrans,EigenVectors,NoSelected,noroots);
    MATAxB(TempMat,EigenTrans,TotalMat,noroots,NoSelected,NoSelected,NoSelected,errorcode);
    MATAxB(Theta,TempMat,EigenVectors,noroots,NoSelected,NoSelected,noroots,errorcode);

    // Create a diagonal matrix with square roots of the Total covariance diagonal
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < NoSelected; j++)
        {
            if (i != j) DiagMat[i][j] = 0.0;
            else DiagMat[i][j] = sqrt(TotalMat[i][j]);
        }
    }

    // Get recipricol of standard deviations of each function
    for (int i = 0; i < noroots; i++) ScoreVar[i] = 1.0 / sqrt(Theta[i][i]);

    // Divide coefficients by score standard deviations
    for (int i = 0; i < NoSelected; i++)
    {
        for (int j = 0; j < noroots; j++)
        {
            RawCMat[i][j] = EigenVectors[i][j] * ScoreVar[j];
            CoefMat[i][j] = RawCMat[i][j] * sqrt(TotalMat[i][i]);
        }
    }

    if (DiscrimForm->CheckBox12->Checked == true)
    {
        ArrayPrint(RawCMat,NoSelected, noroots,"Root No",VarLabels,
                   ColLabels,"Raw Discriminant Function Coefficients from Total Covariance");
        VPrint(Constants,noroots,ColLabels,"Raw Discriminant Function Constants");
        FrmOutPut->ShowModal();
    }

    if (DiscrimForm->CheckBox13->Checked == true)
    {
        ArrayPrint(CoefMat,NoSelected,noroots,"Root No",VarLabels,
                   ColLabels,"Standardized Discriminant Function Coefficients from Total Covariance");
        FrmOutPut->ShowModal();
    }

    // Get correlations from Total covariance matrix
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            TempMat[i][j] = TotalMat[i][j] /
                (TotalStdDevs[i] * TotalStdDevs[j]);

    if (DiscrimForm->CheckBox5->Checked == true)
    {
       ArrayPrint(TempMat,NoSelected,NoSelected,"Variables",VarLabels,
                  VarLabels,"Total Correlation Matrix");
       FrmOutPut->ShowModal();
    }

    // Save rmatrix if checked
    if (DiscrimForm->SaveRMatChkBox->Checked)
    {
        int count = NoCases;
        SaveSqrMat(TempMat, NoSelected, count, ColLabels,TotalMeans, TotalStdDevs);
    }

    // Obtain structure coefficients
    MATAxB(Structure,TempMat,CoefMat,NoSelected,NoSelected,NoSelected,noroots,errorcode);
    ArrayPrint(Structure,NoSelected,noroots,"Root No",VarLabels,ColLabels,
               "Correlations Between Variables and Functions");
    FrmOutPut->ShowModal();

    //Compute and print overall statistics for equal group centroids
    int n2 = NoSelected * NoSelected;
    int k2 = (NoGrps-1) * (NoGrps-1);
    double num = NoSelected * (NoGrps - 1);
    double s = sqrt(double(n2 * k2 - 4)/ double(n2 + k2 - 5));
    double v2 = (num  - 2.0) / 2.0;
    double m = double(2 * NoCases - NoSelected - NoGrps - 2) / 2.0;
    double den = m * s - v2;
    double L2 = pow(Lambda,1.0 / s);
    double F = ((1.0 - L2)/ L2) * (den / num);
    double Fprob = ftest(num,den,F);
    sprintf(outline,"Wilk's Lambda = %10.4f.",Lambda);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"F = %10.4f with D.F. %5.0f and %5.0f .  Prob > F = %6.4f",
            F,num,den,Fprob);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    int dfchi = NoSelected * noroots;
    double probchi = 1.0 - chisquaredprob(ChiSquare,dfchi);
    sprintf(outline,"Bartlett chi-square = %10.4f with %d D.F. and prob. = %6.4f",
                     ChiSquare,dfchi,probchi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Pillai Trace = %10.4f",Pillia);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    // Clean up heap
    delete[] NoInGrp;
    delete[] GrpNos;
    for (int i = 0; i < NoGrps; i++) delete[] Centroids[i];
    delete[] Centroids;
    for (int i = 0; i < NoGrps; i++) delete[] GrpSDevs[i];
    delete[] GrpSDevs;
    for (int i = 0; i < NoGrps; i++) delete[] GrpMeans[i];
    delete[] GrpMeans;
    delete[] w;
    delete[] WithinStdDevs;
    delete[] WithinVariances;
    delete[] WithinMeans;
    delete[] TotalStdDevs;
    delete[] TotalVariances;
    delete[] TotalMeans;
    delete[] Pcnts;
    delete[] Roots;
    delete[] ScoreVar;
    delete[] Constants;
    for (int i = 0; i < NoSelected; i++) delete[] Structure[i];
    delete[] Structure;
    for (int i = 0; i < NoSelected; i++) delete[] RawCMat[i];
    delete[] RawCMat;
    for (int i = 0; i < NoSelected+1; i++) delete[] CoefMat[i];
    delete[] CoefMat;
    for (int i = 0; i < NoSelected; i++) delete[] DiagMat[i];
    delete[] DiagMat;
    for (int i = 0; i < NoSelected; i++) delete[] Theta[i];
    delete[] Theta;
    for (int i = 0; i < NoSelected+1; i++) delete[] TempMat[i];
    delete[] TempMat;
    for (int i = 0; i < NoSelected; i++) delete[] EigenTrans[i];
    delete[] EigenTrans;
    for (int i = 0; i < NoSelected; i++) delete[] EigenVectors[i];
    delete[] EigenVectors;
    for (int i = 0; i < NoSelected; i++) delete[] BetweenMat[i];
    delete[] BetweenMat;
    for (int i = 0; i < NoSelected; i++) delete[] TotalMat[i];
    delete[] TotalMat;
    for (int i = 0; i < NoSelected; i++) delete[] PooledW[i];
    delete[] PooledW;
    for (int i = 0; i < NoSelected+1; i++) delete[] v[i];
    delete[] v;
    for (int i = 0; i < NoSelected; i++) delete[] WinvB[i];
    delete[] WinvB;
    for (int i = 0; i < NoSelected; i++) delete[] WithinInv[i];
    delete[] WithinInv;
    for (int i = 0; i < NoSelected; i++) delete[] WithinMat[i];
    delete[] WithinMat;
    delete[] CaseNo;
    delete[] ColLabels;
    delete[] VarLabels;
    delete[] ColNoSelected;
    if (results == false) DeleteaCol(GroupVar);
}
//---------------------------------------------------------------------------

void PlotPts(double **RawCMat, double *Constants, int *ColNoSelected,
             int NoSelected, int noroots, int NoCases, int GroupVar,
             int NoGrps, int *NoInGrp)
{
    double X, Y, XScore,YScore, Xmin, Xmax, Ymin, Ymax;
    int matrow, group, grpcounter;
    char Title[61];
    char xTitle[31];
    char yTitle[31];
    char outline[81];
    double *Xpoints, *Ypoints;
    AnsiString PtLabels[1000];
    int ngood = 0;

    if (noroots <= 1) return;

    // Plot a chart for each combination of roots
    GetDblVecMem(Xpoints,NoCases);
    GetDblVecMem(Ypoints,NoCases);
    for (int i = 0; i < noroots-1; i++)
    {
        for (int j = i+1; j < noroots; j++)
        {
            // setup the chart parameters
            Ymin = 1.0E+20;
            Ymax = -1.0E+20;
            Xmin = 1.0E+20;
            Xmax = -1.0E+20;
            strcpy(Title,"PLOT OF DISCRIMINANT SCORES");
            sprintf(xTitle,"Function %d",i+1);
            sprintf(yTitle,"Function %d",j+1);

            // find valid cases in each group
            for (int k = 0; k < NoCases; k++)
            {
                if ((FilterOn) && (MainForm->Grid->Cells[FilterCol][i+1] == "NO")) continue;
                ngood++;
                group = floor(StrToFloat(MainForm->Grid->Cells[GroupVar][k+1]));
                matrow = oldcolcnt + i + 1;
                XScore = StrToFloat(MainForm->Grid->Cells[matrow][k+1]);
                matrow = oldcolcnt + j + 1;
                YScore = StrToFloat(MainForm->Grid->Cells[matrow][k+1]);
                if (XScore > Xmax) Xmax = XScore;
                if (XScore < Xmin) Xmin = XScore;
                if (YScore > Ymax) Ymax = YScore;
                if (YScore < Ymin) Ymin = YScore;
                Xpoints[k] = XScore;
                Ypoints[k] = YScore;
                sprintf(outline,"%d",group);
                PtLabels[k] = outline;
            } // next case

            // sort on Xpoints
            for (int k = 0; k < ngood-1; k++)
            {
                for (int n = k+1; n < ngood; n++)
                {
                     if (Xpoints[k] > Xpoints[n])
                     {
                        double temp = Xpoints[k];
                        Xpoints[k] = Xpoints[n];
                        Xpoints[n] = temp;
                        temp = Ypoints[k];
                        Ypoints[k] = Ypoints[n];
                        Ypoints[n] = temp;
                        AnsiString templabel = PtLabels[k];
                        PtLabels[k] = PtLabels[n];
                        PtLabels[n] = templabel;
                     }
                }
            }

            // test values to see if the same as those saved
            AnsiString aline;
            FrmOutPut->RichOutPut->Clear();
            FrmOutPut->RichOutPut->Lines->Add("Plotted Values");
            FrmOutPut->RichOutPut->Lines->Add("GROUP DISC1  DISC2");
            for (int m = 0; m < ngood; m++)
            {
                sprintf(outline,"%5s %6.2f %6.2f",PtLabels[m],Xpoints[m],Ypoints[m]);
                aline = outline;
                FrmOutPut->RichOutPut->Lines->Add(aline);
            }
            FrmOutPut->ShowModal();

            // clean up the heap
            plotxy(Xpoints, Ypoints, Xmax, Xmin, Ymax, Ymin, xTitle, yTitle,
                   PtLabels, NoCases);
            PlotForm->ShowModal();
        } // next i
    }  // next j
    ClearDblVecMem(Xpoints);
    ClearDblVecMem(Ypoints);
}
//---------------------------------------------------------------------------

void Classify(double **PooledW, double **GrpMeans, int *ColNoSelected,
             int NoSelected, int NoCases, int GroupVar, int NoGrps,
             int *NoInGrp, AnsiString *VarLabels)
{
    char outline[81];
    double *Constant;
    double *T;
    double S;
    double **Coeff;
    double **TempMat;
    double **CoefMat;
    double **v;
    double *w;
    double **WithinInv;

    try  {
        Constant = new double[NoGrps];
        T = new double[NoSelected];
        Coeff = new double*[NoGrps];
        for (int i = 0; i < NoGrps; i++) Coeff[i] = new double[NoSelected];
        TempMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TempMat[i] = new double[NoSelected+1];
        CoefMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) CoefMat[i] = new double[NoSelected+1];
        v = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) v[i] = new double[NoSelected+1];
        w = new double[NoSelected+1];
        WithinInv = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) WithinInv[i] = new double[NoSelected];
    }
    catch (...)
    {
       Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Get inverse of pooled within variance-covariance matrix
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            TempMat[i+1][j+1] = PooledW[i][j];
    matinv(TempMat,NoSelected,CoefMat,v,w);
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            WithinInv[i][j] = CoefMat[i+1][j+1];

    // Get Fisher Discrim Functions and probabilities
    FrmOutPut->RichOutPut->Lines->Add("Fisher Discriminant Functions");
    for (int grp = 0; grp < NoGrps; grp++)
    {
        Constant[grp] = 0.0;
        S = 0.0;
        for (int j = 0; j < NoSelected; j++)
            for (int k = 0; k < NoSelected; k++)
                S += WithinInv[j][k] * GrpMeans[grp][j] * GrpMeans[grp][k];
        Constant[grp] = -S / 2.0;
        for (int j = 0; j < NoSelected; j++)
        {
            T[j] = 0.0;
            for (int k = 0; k < NoSelected; k++)
                T[j] += WithinInv[j][k] * GrpMeans[grp][k];
        }
        for (int j = 0; j < NoSelected; j++) Coeff[grp][j] = T[j];
        sprintf(outline,"Group %3d Constant = %6.3f",grp+1,Constant[grp]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("Variable  Coefficient");
        for (int i = 0; i < NoSelected; i++)
        {
            sprintf(outline,"   %3d    %6.3f",i+1,T[i]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
    } // next group

    // clean up the heap
    for (int i = 0; i < NoSelected; i++) delete[] WithinInv[i];
    delete[] WithinInv;
    delete[] w;
    for (int i = 0; i < NoSelected+1; i++) delete[] v[i];
    delete[] v;
    for (int i = 0; i < NoSelected+1; i++) delete[] CoefMat[i];
    delete[] CoefMat;
    for (int i = 0; i < NoSelected+1; i++) delete[] TempMat[i];
    delete[] TempMat;
    for (int i = 0; i < NoGrps; i++) delete[] Coeff[i];
    delete[] Coeff;
    delete[] T;
    delete[] Constant;
//    delete[] GroupScore;
}
//---------------------------------------------------------------------------
void ClassIt(double **PooledW, int *ColNoSelected, double **GrpMeans,
             double *Roots, int noroots, int GroupVar, int NoGrps,
             int *NoInGrp, int NoSelected, int NoCases, double **RawCmat,
             double *Constants)
{
    int **Table;
    double *ProdVec;
    double *Dev;
    double *D2;
    double *Density;
    double SumD2 = 0.0;
    double *ProbGrp;
    double *Apriori;
    double *Discrim;
    double LargestProb;
    double SecdProb;
    double X;
    double Determinant;
    int InGrp;
    int Largest;
    int SecdLarge;
    char outline[81];
    AnsiString *RowLabels;
    AnsiString *ColLabels;
//    oldcolcnt = MainForm->Grid->ColCount;
    AnsiString cellname;
    double **TempMat;
    double **CoefMat;
    double **v;
    double *w;
    double **WithinInv;

    try  {
        Table = new int*[NoGrps+1];
        for (int i = 0; i < NoGrps+1; i++) Table[i] = new int[NoGrps+1];
        ProdVec = new Double[NoSelected];
        Dev = new Double[NoSelected];
        D2 = new double[NoGrps];
        Density = new double[NoGrps];
        ProbGrp = new double[NoGrps];
        Apriori = new double[NoGrps];
        Discrim = new double[NoGrps];
        RowLabels = new AnsiString[NoGrps+1];
        ColLabels = new AnsiString[NoGrps+1];
        TempMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) TempMat[i] = new double[NoSelected+1];
        CoefMat = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) CoefMat[i] = new double[NoSelected+1];
        v = new double *[NoSelected+1];
        for (int i = 0; i < NoSelected+1; i++) v[i] = new double[NoSelected+1];
        w = new double[NoSelected+1];
        WithinInv = new double *[NoSelected];
        for (int i = 0; i < NoSelected; i++) WithinInv[i] = new double[NoSelected];
    }
    catch (...)
    {
       Application->MessageBox("Out of Memory","ERROR",MB_OK);
    }

    // Does user want to save scores?  If yes, add columns to grid
    if (DiscrimForm->CheckBox22->Checked == true)
    {
//        MainForm->Grid->ColCount += noroots;
        //Add grid headings for discrim scores
        for (int j = 0; j < noroots; j++)
        {
            cellname = "Disc ";
            cellname = cellname + (j+1);
            NewVar(oldcolcnt + j + 1 ,false);
            DictionaryForm->DGrid->Cells[1][NoVariables] = cellname;
            MainForm->Grid->Cells[oldcolcnt+j+1][0] = cellname;
        }
    }
     MainForm->NoVarsEdit->Text = NoVariables;

    // Initialize arrays that need it
    for (int i = 0; i < NoSelected; i++) ProdVec[i] = 0.0;
    for (int i = 0; i < NoGrps; i++) D2[i] = 0.0;
    for (int i = 0; i < NoGrps+1; i++)
        for (int j = 0; j < NoGrps+1; j++) Table[i][j] = 0;

    // Get inverse of pooled within variance-covariance matrix
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            TempMat[i+1][j+1] = PooledW[i][j];
    matinv(TempMat,NoSelected,CoefMat,v,w);
    for (int i = 0; i < NoSelected; i++)
        for (int j = 0; j < NoSelected; j++)
            WithinInv[i][j] = CoefMat[i+1][j+1];

    // Calculate determinant (product of roots)
    Determinant = 1.0;
    for (int i = 0; i < noroots; i++) Determinant *= Roots[i];

    int linecount = 0;
    // Print Heading
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"CLASSIFICATION OF CASES");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"SUBJECT ACTUAL HIGH  PROBABILITY   SEC'D HIGH   DISCRIM");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"ID NO.  GROUP  IN    GROUP P(G/D)  GROUP P(G/D) SCORE");
    FrmOutPut->RichOutPut->Lines->Add(outline);
    linecount += 4;

    //Get selected priors
    // Default priors are equal proportions
    for (int j = 0; j < NoGrps; j++)Apriori[j] = 1.0 / double(NoGrps);
    if (DiscrimForm->RadioButton2->Checked == true)
    {
        // Get apriori probabilities
        for (int j = 0; j < NoGrps; j++)
            Apriori[j] = double(NoInGrp[j]) / double(NoCases);
    }
    if (DiscrimForm->RadioButton3->Checked == true)
    {
        for (int j = 0; j < NoGrps; j++)
        {
            AnsiString aprompt = "Group ";
            aprompt = aprompt + (j+1);
            AnsiString avalue = Apriori[j];
            AnsiString number = InputBox("GROUP PROPORTION:",aprompt,avalue);
            Apriori[j] = atof(number.c_str());
        }
    }
    int ngood = 0;
    // Calculate group probabilities for each case
    for (int i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected+1)) continue;
        ngood++;
        if (linecount >= 59)
        {
           FrmOutPut->ShowModal();
           linecount = 0;
        }
        if (!ValidRecord(i+1,ColNoSelected,NoSelected+1)) continue;
        InGrp = floor(StrToFloat(MainForm->Grid->Cells[GroupVar][i+1]));
        for (int grp = 0; grp < NoGrps; grp++) // group loop
        {
            for (int j = 0; j < NoSelected; j++) ProdVec[j] = 0.0;
            D2[grp] = 0.0;
            for (int j = 0; j < NoSelected; j++) // variables loop
            {
                X = StrToFloat(MainForm->Grid->Cells[ColNoSelected[j]][i+1]);
                Dev[j] = X - GrpMeans[grp][j];
            }
            // Get squared distance as [X - M]' * inv[S] * [X - M]
            for (int j = 0; j < NoSelected; j++) // deviation * S inverse
                for (int k = 0; k <NoSelected; k++)
                    ProdVec[j] += (Dev[k] * WithinInv[k][j]);
            for (int j = 0; j < NoSelected; j++) // Product * deviation
                D2[grp] += Dev[j] * ProdVec[j]; // distance from group
            D2[grp] -= 2.0 * log(Apriori[grp]); ///generalized distance
            SumD2 += exp(-0.5 * D2[grp]);
        } // end of group loop
        for (int j = 0; j < NoGrps; j++)
            ProbGrp[j] = exp(-0.5 * D2[j]) / SumD2;

        // Get Discrim functions
        for (int j = 0; j < noroots; j++) Discrim[j] = 0.0;
        for (int j = 0; j < NoSelected; j++) // variables loop
        {
            X = StrToFloat(MainForm->Grid->Cells[ColNoSelected[j]][i+1]);
            for (int j1 = 0; j1 < noroots; j1++)
                Discrim[j1] += X * RawCmat[j][j1];
        }
        for (int j = 0; j < noroots; j++) Discrim[j] += Constants[j];

        // Does user want to save Discrim scores in grid?
        if (DiscrimForm->CheckBox22->Checked == true)
        {
            for (int j = 0; j < noroots; j++)
                MainForm->Grid->Cells[oldcolcnt+j+1][i+1] = Discrim[j];
        }

        // Get largest and next largest group probabilities
        Largest = 0;
        LargestProb = ProbGrp[0];
        for (int grp = 1; grp < NoGrps; grp++)
        {
            if (ProbGrp[grp] > LargestProb)
            {
                Largest = grp;
                LargestProb = ProbGrp[grp];
            }
        }

        ProbGrp[Largest] = 0.0;
        SecdLarge = 0;
        SecdProb = ProbGrp[0];
        for (int grp = 1; grp < NoGrps; grp++)
        {
            if (ProbGrp[grp] > SecdProb)
            {
                SecdLarge = grp;
                SecdProb = ProbGrp[grp];
            }
        }

        // Print results for this case i
        sprintf(outline,"%3d    %3d    %3d      %6.4f      %3d   %6.4f %7.4f",
                i+1,InGrp,Largest+1,LargestProb,SecdLarge+1,SecdProb,
                Discrim[0]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        linecount++;
        for (int j = 1; j < noroots; j++)
        {
            sprintf(outline,"                                                %7.4f",
                    Discrim[j]);
            FrmOutPut->RichOutPut->Lines->Add(outline);
            linecount++;
        }
        Table[InGrp-1][Largest]++;
        // initialize variables for next case
//        SumPosterior = 0.0;
        SumD2 = 0.0;
    } // end of case loop i

    // Get table column and row totals
    for (int i = 0; i < NoGrps; i++) // table rows
        for (int j = 0; j < NoGrps; j++) Table[i][NoGrps] += Table[i][j];
    for (int j = 0; j < NoGrps; j++) // table columns
        for (int i = 0; i < NoGrps; i++) Table[NoGrps][j] += Table[i][j];
    Table[NoGrps][NoGrps] = ngood;

    if (linecount > 0) FrmOutPut->ShowModal();
    // Print table of classifications
    for (int i = 0; i < NoGrps; i++)
    {
        RowLabels[i] = (i+1);
        ColLabels[i] = (i+1);
    }
    RowLabels[NoGrps] = "TOTAL";
    ColLabels[NoGrps] = "TOTAL";
    IntArrayPrint(Table, NoGrps+1,NoGrps+1, "PREDICTED GROUP",
                  RowLabels, ColLabels, "CLASSIFICATION TABLE");

    // Clean up the heap
    for (int i = 0; i < NoSelected; i++) delete[] WithinInv[i];
    delete[] WithinInv;
    delete[] w;
    for (int i = 0; i < NoSelected+1; i++) delete[] v[i];
    delete[] v;
    for (int i = 0; i < NoSelected+1; i++) delete[] CoefMat[i];
    delete[] CoefMat;
    for (int i = 0; i < NoSelected+1; i++) delete[] TempMat[i];
    delete[] TempMat;
    delete[] ColLabels;
    delete[] RowLabels;
    delete[] Discrim;
//    delete[] PostProb;
    delete[] Apriori;
    delete[] ProbGrp;
    delete[] Density;
    delete[] D2;
    delete[] Dev;
    delete[] ProdVec;
    for (int i = 0; i < NoGrps+1; i++) delete[] Table[i];
    delete[] Table;
}
//---------------------------------------------------------------------------

void plotxy(double *Xpoints, double *Ypoints, double Xmax, double Xmin,
            double Ymax, double Ymin, char *xTitle, char *yTitle,
            AnsiString *PtLabels, int N)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];

     Title = "X versus Y PLOT Using File: " + MainForm->FileNameEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (Xmax - Xmin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = Xmin + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     Title = xTitle;
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(Title) / 2);
     ypos = vbottom + 25;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // Draw vertical axis
     Title = yTitle;
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (Ymax - Ymin) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = Ymax - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = Ymax - (valincr * (i-1));
          ypos = ceil(vhi * ( (Ymax - Yvalue) / (Ymax - Ymin)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs
     for (i = 0; i < N; i++)
     {
          ypos = ceil(vhi * ( (Ymax - Ypoints[i]) / (Ymax - Ymin)));
          ypos = ypos + vtop;
          xpos = ceil(hwide * ( (Xpoints[i] - Xmin) / (Xmax - Xmin)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->Brush->Color = clNavy;
          PlotForm->Image1->Canvas->Brush->Style = bsSolid;
          PlotForm->Image1->Canvas->Pen->Color = clNavy;
          PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
          PlotForm->Image1->Canvas->Brush->Color = clWhite;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOutA(xpos+5,ypos-5,PtLabels[i]);
     }
}
//-------------------------------------------------------------------






