//---------------------------------------------------------------------------
#ifndef OutPutH
#define OutPutH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmOutPut : public TForm
{
__published:	// IDE-managed Components
	TRichEdit *RichOutPut;
    TPrintDialog *PrintDialog1;
    TPanel *SpeedBar;
    TSpeedButton *OpenButton;
    TSpeedButton *SaveButton;
    TSpeedButton *PrintButton;
    TSpeedButton *CutButton;
    TSpeedButton *CopyButton;
    TSpeedButton *PasteButton;
    TBevel *Bevel1;
    TSpeedButton *ReturnSpdBtn;
    TOpenDialog *OpenDialog1;
    TSaveDialog *SaveDialog1;
    TFontDialog *FontDialog1;
    TSpeedButton *FontSelSpdBtn;
    void __fastcall ReturnBtnClick(TObject *Sender);
    void __fastcall PrintBtnClick(TObject *Sender);
    void __fastcall PrintButtonClick(TObject *Sender);
    void __fastcall ReturnSpdBtnClick(TObject *Sender);
    void __fastcall FontSelSpdBtnClick(TObject *Sender);
    void __fastcall FontDialog1Apply(TObject *Sender, HWND Wnd);
    void __fastcall OpenButtonClick(TObject *Sender);
    void __fastcall SaveButtonClick(TObject *Sender);
    void __fastcall CutButtonClick(TObject *Sender);
    void __fastcall PasteButtonClick(TObject *Sender);
    void __fastcall CopyButtonClick(TObject *Sender);
private:	// User declarations

public:		// User declarations
	__fastcall TFrmOutPut(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TFrmOutPut *FrmOutPut;
//---------------------------------------------------------------------------
#endif
