//---------------------------------------------------------------------------

#ifndef RescaleUnitH
#define RescaleUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TRescaleForm : public TForm
{
__published:	// IDE-managed Components
   TLabel *Label2;
   TLabel *Label4;
   TLabel *Label5;
   TEdit *AminEdit;
   TEdit *VminEdit;
   TEdit *rEdit;
   TOpenDialog *OpenDialog1;
   TLabel *Label6;
   TEdit *OutFileEdit;
   TButton *FileOpenBtn;
   TButton *ComputeBtn;
   TButton *CancelBtn;
   TButton *ReturnBtn;
   void __fastcall FileOpenBtnClick(TObject *Sender);
   void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TRescaleForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRescaleForm *RescaleForm;
//---------------------------------------------------------------------------
#endif
