//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "OutPut.h"
#include "AnovaUnit.h"
#include "functions.h"
#include "AnovaTestsUnit.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void TUKEY(double error_ms,            //  { mean squared for (residual }
           double error_df,            //  { deg. freem for (residual }
           double value,               //  { size of smallest group }
           double *group_total,        //  { sum of scores in a group }
           double *group_count,        //  { no. of cases in a group }
           int min_grp,                //  { minimum group code }
           int max_grp,                //  { maximum group code }
           double alpha)
{
     bool sig;
     double divisor;
     int df1;
     double contrast, mean1, mean2;
     double q_stat;
     int i,j;
     char outline[121];
     char out2[121];

     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("             Tukey HSD Test for (Differences Between Means");
     sprintf(outline,"                            alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("Groups     Difference  Statistic      Probability  Significant?");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     divisor = sqrt(error_ms / value );
     for (i = min_grp; i <= max_grp-1; i++)
     {
         for (j = i + 1;j <= max_grp; j++)
         {
              sprintf(outline,"%2d - %2d     ",i,j);
              mean1 = group_total[i-1] / group_count[i-1];
              mean2 = group_total[j-1] / group_count[j-1];
              contrast = mean1 - mean2;
              sprintf(out2,"%7.3f     q = ",contrast);
              strcat(outline,out2);
              contrast = fabs(contrast / divisor) ;
              sprintf(out2,"%6.3f  ",contrast);
              strcat(outline,out2);
              df1 = max_grp - min_grp + 1;
              q_stat = STUDENT(contrast,error_df,df1);
              sprintf(out2,"       %6.4f",q_stat);
              strcat(outline,out2);
              if (alpha >= q_stat)  sig = true;
              else sig = false;
              if (sig == true)  strcat(outline,"       YES ");
              else strcat(outline, "       NO");
              FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     }
}
//-------------------------------------------------------------------

void SCHEFFETEST(double error_ms,      // { mean squared residual }
                 double *group_total,  // { sum of scores in a group }
                 double *group_count,  // { count of cases in a group }
                 int min_grp,          // { code of first group }
                 int max_grp,          // { code of last group  }
                 double total_n,       // { total number of cases }
                 double alpha)
{
     double statistic, stat_var, stat_sd;
     double mean1, mean2, difference, prob_scheffe, f_prob, df1, df2;
     char outline[121];
     char out2[121];
     int i, j;

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("                 Scheffe contrasts among pairs of means.");
     sprintf(outline,"                            alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("Group vs Group  Difference   Scheffe    Critical  Significant?");
     FrmOutPut->RichOutPut->Lines->Add("                             Statistic  Value");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------");
     alpha = 1.0 - alpha ;
     for (i= min_grp; i <= max_grp - 1; i++)
     {
         for (j = i + 1; j <= max_grp; j++)
         {
              sprintf(outline,"%2d        %2d      ",i,j);
              mean1 = group_total[i-1] / group_count[i-1];
              mean2 = group_total[j-1] / group_count[j-1];
              difference = mean1 - mean2;
              sprintf(out2,"%8.2f ",difference);
              strcat(outline,out2);
              stat_var = error_ms *
                  ( 1.0 / group_count[i-1] + 1.0 / group_count[j-1]);
              stat_sd = sqrt(stat_var);
              statistic = fabs(difference / stat_sd);
              sprintf(out2,"%8.2f   ",statistic);
              strcat(outline,out2);
              df1 = (double)(max_grp - min_grp);
              df2 = total_n - (df1 + 1.0);
              f_prob = fpercentpoint(alpha,ceil(df1),ceil(df2) );
              prob_scheffe = sqrt(df1 * f_prob);
              sprintf(out2,"%8.3f     ",prob_scheffe);
              strcat(outline,out2);
              if (statistic > prob_scheffe)  strcat(outline,"YES");
              else strcat(outline, "NO");
              FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------");
     }
}
//-------------------------------------------------------------------

void Newman_Keuls(double error_ms,     // { residual mean squared }
                  double error_df,     // { deg. freem for (error }
                  double value,        // { number in smallest group }
                  double *group_total, // { sum of scores in a group }
                  double *group_count, // { count of cases in a group }
                  int min_grp,         // { lowest group code }
                  int max_grp,         // { largest group code }
                  double alpha)
{
      int i, j;
      double temp1, temp2;
      int *groupno;
      double contrast, mean1, mean2;
      double q_stat;
      double divisor;
      int tempno;
      int df1;
      bool sig;
      char outline[121];
      char out2[121];

     groupno = new int[max_grp-min_grp+1];
     for (i = min_grp; i <= max_grp; i++)  groupno[i-1] = i;
     for (i = min_grp;i <= max_grp - 1; i++)
     {
         for (j = i + 1; j <= max_grp; j++)
         {
              if ((group_total[i-1] / group_count[i-1]) > (group_total[j-1] / group_count[j-1]))
              {
                   temp1 = group_total[i-1];
                   temp2 = group_count[i-1];
                   tempno = groupno[i-1];
                   group_total[i-1] = group_total[j-1];
                   group_count[i-1] = group_count[j-1];
                   groupno[i-1] = groupno[j-1];
                   group_total[j-1] = temp1;
                   group_count[j-1] = temp2;
                   groupno[j-1] = tempno;
              }
         }
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("            Neuman-Keuls Test for (Contrasts on Ordered Means");
     sprintf(outline,"                            alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Group     Mean");
     for (i = 1; i <=max_grp; i++)
     {
          sprintf(outline,"%3d  %10.3f",groupno[i-1],group_total[i-1] / group_count[i-1]);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Groups     Difference  Statistic      d.f.   Probability  Significant?");
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     divisor = sqrt(error_ms / value);
     for (i = min_grp; i <= max_grp - 1; i++)
     {
         for (j = i + 1; j <= max_grp; j++)
         {
              sprintf(outline,"%2d - %2d     ",groupno[i-1],groupno[j-1]);
              mean1 = group_total[i-1] / group_count[i-1];
              mean2 = group_total[j-1] / group_count[j-1];
              contrast = mean1 - mean2;
              sprintf(out2,"%7.3f      q = ",contrast);
              strcat(outline,out2);
              contrast = fabs(contrast / divisor );
              df1 = j - i + 1;
              sprintf(out2,"%6.3f   %2d  %3.0f  ",contrast,df1,error_df);
              strcat(outline,out2);
              q_stat = STUDENT(contrast,error_df,df1);
              sprintf(out2,"   %6.4f",q_stat);
              strcat(outline,out2);
              if (alpha > q_stat) sig = true;
              else sig = false;
              if (sig == true)
              {
                  sprintf(out2,"       YES");
                  strcat(outline,out2);
              }
              else
              {
                  sprintf(out2,"       NO");
                  strcat(outline,out2);
              }
              FrmOutPut->RichOutPut->Lines->Add(outline);
         }
     }
     FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------");
     delete[] groupno;
}
//-------------------------------------------------------------------

void TUKEY_KRAMER(double error_ms,     // { residual mean squared }
                  double error_df,     // { deg. freem for (error }
                  double value,        // { number in smallest group }
                  double *group_total, // { sum of scores in group }
                  double *group_count, // { number of caes in group }
                  int min_grp,         // { code of lowest group }
                  int max_grp,         // { code of highst group }
                  double alpha)
{
     bool sig;
     double divisor;
     int df1;
     double contrast, mean1, mean2;
     double q_stat;
     char outline[121];
     char out2[121];
     int i, j;

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("           Tukey-Kramer Test for (Differences Between Means");
     sprintf(outline,"                     alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("Groups     Difference  Statistic      Probability  Significant?");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     for (i = min_grp; i <= max_grp - 1; i++)
         for (j = i + 1; j <= max_grp; j++)
         {
              sprintf(outline,"%2d - %2d    ",i,j);
              mean1 = group_total[i-1] / group_count[i-1];
              mean2 = group_total[j-1] / group_count[j-1];
              contrast = mean1 - mean2;
              sprintf(out2,"%7.3f     q = ",contrast);
              strcat(outline,out2);
              divisor = sqrt(error_ms *
                 ( ( 1.0/group_count[i-1] + 1.0/group_count[j-1] ) / 2.0 ) );
              contrast = fabs(contrast / divisor) ;
              sprintf(out2,"%6.3f  ",contrast);
              strcat(outline,out2);
              df1 = max_grp - min_grp + 1;
              q_stat = STUDENT(contrast,error_df,df1);
              sprintf(out2,"       %6.4f",q_stat);
              strcat(outline,out2);
              if (alpha >= q_stat) sig = true;
              else sig = false;
              if (sig) strcat(outline,"       YES ");
              else strcat(outline,"       NO");
              FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
}
//-------------------------------------------------------------------

void CONTRASTS(double error_ms,        // { residual ms }
               double error_df,        // { residual df }
               double *group_total,    // { group sums  }
               double *group_count,    // { group cases }
               int min_grp,            // { lowest code }
               int max_grp,            // { highest code }
               double overall_probf,   // { prob of overall test }
               double alpha)
{
     int nocontrasts, i, j, k;
     double df1, df2, probstat, statistic;
     double coefficients[20][20];;
     bool nonorthog;
     double weight, sumcross;
     AnsiString response;
     char outline[121];
     char out2[121];
     AnsiString prompt;

     sprintf(outline,"Enter the number of contrasts (less than %2d or 0:",max_grp-min_grp+1);
     response = InputBox("ORTHOGONAL CONTRASTS",outline,"0");
     nocontrasts = StrToInt(response);
     if (nocontrasts > 0)
     {
          for (i = 1; i <= nocontrasts; i++)
          {
               sprintf(outline,"Contrast number %2d",i);
               for (j = 1; j <= (max_grp - min_grp+1); j++)
               {
                    sprintf(out2,"Group %2d coefficient = ",j);
                    prompt = out2;
                    response = InputBox(outline,prompt,"1");
                    coefficients[i-1][j-1] = StrToFloat(response);
               }
          }
          // Check for (orthogonality
          nonorthog = false;
          for (i = 1; i <= nocontrasts - 1; i++)
          {
               for (j = i + 1; j <= nocontrasts; j++)
               {
                    sumcross = 0;
                    for (k = 1; k <= (max_grp - min_grp + 1); k++)
                    {
                         sumcross = sumcross +
                               coefficients[i-1][k-1]*coefficients[j-1][k-1];
                    }
                    if (sumcross != 0) nonorthog = true;
                    if (sumcross != 0)
                    {
                       sprintf(out2,"contrasts %2d and %2d not orthogonal.",i,j);
                       strcpy(outline,"ERROR!");
                       strcat(outline,out2);
                       ShowMessage(outline);
                    }
               }
          }
          if (! nonorthog)
          {
               if (overall_probf > alpha)
               {
                    FrmOutPut->RichOutPut->Lines->Add("No contrasts significant.");
                    return;
               }
               FrmOutPut->RichOutPut->Lines->Add("");
               FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
               FrmOutPut->RichOutPut->Lines->Add("                  ORTHOGONAL CONTRASTS");
               FrmOutPut->RichOutPut->Lines->Add("Contrast  Statistic  Probability  Critical Value  Significant?");
               FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
               for (i = 1; i <= nocontrasts; i++)
               {
                    statistic = 0.0;
                    weight = 0.0;
                    for (j = 1; j <= (max_grp - min_grp + 1); j++)
                    {
                         statistic = statistic + (coefficients[i-1][j-1] *
                            (group_total[j-1] / group_count[j-1]));
                         weight = weight + (sqr(coefficients[i-1][j-1]) /
                            group_count[j-1]);
                    }
                    statistic = sqr(statistic);
                    statistic = statistic / (error_ms * weight);
                    sprintf(outline,"%3d       %9.4f    ",i,statistic);
                    df1 = 1;
                    df2 = error_df;
                    probstat = ftest(ceil(df1),ceil(df2),statistic) / 2.0;
                    sprintf(out2,"%8.3f       %5.2f          ",probstat,alpha);
                    strcat(outline,out2);
                    if (probstat < alpha) strcat(outline,"YES");
                    else strcat(outline,"NO");
                    FrmOutPut->RichOutPut->Lines->Add(outline);
               }
               FrmOutPut->RichOutPut->Lines->Add("");
               FrmOutPut->RichOutPut->Lines->Add("Contrast Coefficients Used:");
               for (i = 1; i <= nocontrasts; i++)
               {
                    sprintf(outline,"Contrast %2d ",i);
                    for (j = 1; j <= (max_grp - min_grp + 1); j++)
                    {
                       sprintf(out2,"%4.1f ",coefficients[i-1][j-1]);
                       strcat(outline,out2);
                    }
                    FrmOutPut->RichOutPut->Lines->Add(outline);
               }
          } // end if orthogonal
          FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     } // end if nocontrasts > 0
}
//-------------------------------------------------------------------

void Bonferroni(double *group_total,   // { sum of scores in group }
                double *group_count,   // { number of caes in group }
                double *group_var,     // { group variances }
                int min_grp,           // { code of lowest group }
                int max_grp,           // { code of highst group }
                double alpha)
{
     int i, j;
     double contrast, mean1, mean2;
     double divisor;
     int df2;
     char outline[121];
     char out2[121];
     double testalpha;
     int NoGrps;
     double prob;
     AnsiString sig;
     double SS1, SS2;

     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("           Bonferroni Test for (Differences Between Means");
     sprintf(outline,"                     Overall alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     NoGrps = max_grp - min_grp + 1;
     testalpha = alpha / ( (NoGrps * (NoGrps-1)) / 2.0 );
     sprintf(outline,"Comparisons made at alpha / no. comparisons = %5.3f",testalpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Groups    Difference  Statistic  Prob > Value  Significant?");
     for (i = 1; i <= NoGrps - 1; i++)
     {
          for (j = i+1; j <= NoGrps; j++)
          {
               mean1 = group_total[i-1] / group_count[i-1];
               mean2 = group_total[j-1] / group_count[j-1];
               SS1 = group_var[i-1] * (group_count[i-1] - 1.0);
               SS2 = group_var[j-1] * (group_count[j-1] - 1.0);
               divisor = (SS1 + SS2) / (group_count[i-1] + group_count[j-1] - 2.0);
               divisor = sqrt(divisor * ( 1.0 / group_count[i-1] + 1.0 / group_count[j-1]));
               contrast = fabs(mean1-mean2) / divisor;
               df2 = ceil(group_count[i-1] + group_count[j-1] - 2.0);
               prob = tprob(contrast,df2);
               if (testalpha >= prob)  sig = "YES";
               else sig = "NO";
               sprintf(outline,"%3d - %3d %10.3f  %10.3f %10.3f        %s",
                           min_grp+i-1,min_grp+j-1,mean1-mean2,contrast,prob,sig.c_str());
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
}
//-------------------------------------------------------------------

void TUKEYBTEST(double ErrorMS,        // { within groups error }
                double ErrorDF,        // { degrees of freem within }
                double *group_total,   // { vector of group sums }
                double *group_count,   // { vector of group n"s }
                int min_grp,           // { smallest group code }
                int max_grp,           // { largest group code }
                double groupsize,      // { size of groups (all equal)
                double alpha)
{
     double divisor, groups, mean1, mean2, contrast, temp1, temp2, tstat, qstat, df1;
     char outline[121];
     int i, j, tempno, NoGrps;
     int *groupno;
     AnsiString sig;
     AnsiString response;

     groupno = new int[max_grp-min_grp+1];
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("           Tukey B Test for (Contrasts on Ordered Means");
     sprintf(outline,"                          alpha selected = %4.2f",alpha);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Groups    Difference  Statistic   d.f.     Prob.>value  Significant?");
     divisor = sqrt(ErrorMS / groupsize);
     NoGrps = max_grp - min_grp + 1;
     for (i = min_grp; i <= max_grp; i++) groupno[i-1] = i;
     for (i = 1; i <= NoGrps - 1; i++)
     {
         for (j = i + 1; j <= NoGrps; j++)
         {
              if ((group_total[i-1] / group_count[i-1]) >
                 (group_total[j-1] / group_count[j-1]))
              {
                   temp1 = group_total[i-1];
                   temp2 = group_count[i-1];
                   tempno = groupno[i-1];
                   group_total[i-1] = group_total[j-1];
                   group_count[i-1] = group_count[j-1];
                   groupno[i-1] = groupno[j-1];
                   group_total[j-1] = temp1;
                   group_count[j-1] = temp2;
                   groupno[j-1] = tempno;
              }
         }
     }

     for (i = 1; i <= NoGrps-1; i++)
     {
          for (j = i+1; j <= NoGrps; j++)
          {
               mean1 = group_total[i-1] / group_count[i-1];
               mean2 = group_total[j-1] / group_count[j-1];
               contrast = fabs((mean1 - mean2) / divisor);
               df1 = (double)(j - i) + 1.0;
               qstat = STUDENT(contrast,ErrorDF,df1);
               groups = NoGrps;
               tstat = STUDENT(contrast,ErrorDF,groups);
               qstat = (qstat + tstat) / 2.0;
               if (alpha >= qstat) sig = "YES";
               else sig = "NO";
               sprintf(outline,"%3d - %3d %10.3f  %10.3f  %4.0f,%4.0f  %5.3f       %s",
                      groupno[i-1],groupno[j-1],
                      mean1-mean2,contrast,df1,ErrorDF,qstat,sig.c_str());
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     delete[] groupno;
}
//-------------------------------------------------------------------

void welchttests(int NoCompares,       // { no. of cells }
                 double *cellsums,     // { sum of values in a cell }
                 double *cellcnts,     // { count of values in a cell }
                 double *cellvars,     // { cell standard deviations }
                 double alpha)        // { alpha test level }
{
        int i, j, v;
        double t, gnu, var1, var2, mean1, mean2, probability;
        double numerator, denominator, term1, term2;
        char outline[121];

        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("---------------------------------------------------------------------");
        FrmOutPut->RichOutPut->Lines->Add("Welch t-tests Among Groups");
        FrmOutPut->RichOutPut->Lines->Add("");
        for (i = 0; i < NoCompares-1; i++)
        {
                for (j = i+1; j < NoCompares; j++)
                {
                        sprintf(outline,"Comparison of group %d with group %d",i+1,j+1);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        mean1 = cellsums[i];
                        mean2 = cellsums[j];
                        var1 = cellvars[i];
                        var2 = cellvars[j];
                        denominator = sqrt((var1 / cellcnts[i]) + (var2 / cellcnts[j]));
                        numerator = mean1 - mean2;
                        t = numerator / denominator;
                        sprintf(outline,"Mean %d = %8.3f, Mean %d = %8.3f",i+1,mean1,j+1,mean2);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        sprintf(outline,"Welch t = %8.3f",t);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        numerator = (var1 / cellcnts[i]) + (var2 / cellcnts[j]);
                        numerator *= numerator;
                        term1 = (var1 * var1) / (cellcnts[i] * cellcnts[i] * (cellcnts[i]-1.0));
                        term2 = (var2 * var2) / (cellcnts[j] * cellcnts[j] * (cellcnts[j]-1.0));
                        denominator = term1 + term2;
                        gnu = numerator / denominator;
                        sprintf(outline,"Degrees of freedom = %8.3f",gnu);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        probability = tprob(t,gnu);
                        sprintf(outline,"Probability > t = %8.3f",probability);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                        FrmOutPut->RichOutPut->Lines->Add("");
                }
        }
}
//-------------------------------------------------------------------

                 
