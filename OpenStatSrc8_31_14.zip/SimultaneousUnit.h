//---------------------------------------------------------------------------

#ifndef SimultaneousUnitH
#define SimultaneousUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TSimultaneousForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label3;
     TListBox *SelList;
     TBitBtn *IndInBtn;
     TBitBtn *IndOutBtn;
     TBitBtn *AllBtn;
     TOpenDialog *OpenDialog1;
     TSaveDialog *SaveDialog1;
     TGroupBox *GroupBox1;
     TCheckBox *MatInChk;
     TCheckBox *SaveCorrsChk;
     TCheckBox *CrossProdChk;
     TCheckBox *CovarChk;
     TCheckBox *CorrsChk;
     TCheckBox *InverseChk;
     TCheckBox *MeansChk;
     TCheckBox *VariancesChk;
     TCheckBox *StdDevsChk;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall IndInBtnClick(TObject *Sender);
     void __fastcall IndOutBtnClick(TObject *Sender);
     void __fastcall AllBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TSimultaneousForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSimultaneousForm *SimultaneousForm;
//---------------------------------------------------------------------------
#endif
