//---------------------------------------------------------------------------

#ifndef ZFunctionUnitH
#define ZFunctionUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TZFunctionsForm : public TForm
{
__published:	// IDE-managed Components
        TRadioGroup *ChoiceGroup;
        TMemo *Memo1;
        TLabel *Label1;
        TEdit *CumzEdit;
        TLabel *Label2;
        TEdit *Z1ProbEdit;
        TLabel *Label3;
        TEdit *Z2ProbEdit;
        TLabel *Label4;
        TEdit *InverseEdit;
        TLabel *Label5;
        TEdit *AnswerEdit;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ChoiceGroupClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TZFunctionsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TZFunctionsForm *ZFunctionsForm;
//---------------------------------------------------------------------------
#endif
