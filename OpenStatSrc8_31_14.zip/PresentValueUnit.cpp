//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PresentValueUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPresentValueFrm *PresentValueFrm;
//---------------------------------------------------------------------------
__fastcall TPresentValueFrm::TPresentValueFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TPresentValueFrm::ResetBtnClick(TObject *Sender)
{
    PresentEdit->Text = "";
    NPeriodsEdit->Text = "";
    RateEdit->Text = "";
    FutureEdit->Text = "0";
    PaymentEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TPresentValueFrm::FormShow(TObject *Sender)
{
    ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TPresentValueFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Rate, Payment, PresentVal, FutureVal, Interest;
     int NPeriods, When;
     TPaymentTime Time;

     When = WhenGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     FutureVal = StrToFloat(FutureEdit->Text);
     Rate = StrToFloat(RateEdit->Text);
     NPeriods = StrToInt(NPeriodsEdit->Text);
     Payment = StrToFloat(PaymentEdit->Text);
     PresentVal = PresentValue(Rate, NPeriods, Payment, FutureVal, Time);
     PresentEdit->Text = FloatToStr(PresentVal);
}
//---------------------------------------------------------------------------
