//---------------------------------------------------------------------------

#ifndef RunsTestUnitH
#define RunsTestUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TRunsTestForm : public TForm
{
__published:	// IDE-managed Components
     TListBox *VarList;
     TBitBtn *InBtn;
     TBitBtn *OutBtn;
     TLabel *Label2;
     TEdit *TestVarEdit;
     TButton *CancelBtn;
     TButton *ResetBtn;
     TButton *PrintBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TGroupBox *GroupBox2;
     TLabel *Label5;
     TLabel *Label6;
     TLabel *Label7;
     TLabel *Label8;
     TEdit *MeanEdit;
     TEdit *StdDevEdit;
     TEdit *StatEdit;
     TEdit *ConclusionEdit;
     TLabel *Label1;
     TEdit *ProbEdit;
     TLabel *Label3;
     TEdit *NUpEdit;
     TLabel *Label4;
     TEdit *NDownEdit;
     TMemo *Memo1;
     TLabel *Label9;
     TLabel *Label10;
     TEdit *NRunsEdit;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall InBtnClick(TObject *Sender);
     void __fastcall OutBtnClick(TObject *Sender);
     void __fastcall PrintBtnClick(TObject *Sender);
private:	// User declarations
	double * values;
	int N, N1, N2, a, i, col, R, Nless, Nmore;
	double Mean, SD, SD1, SD2, SD3, SD4, ExpMean, z, z1, z2, t, p, p1;
	AnsiString astring;
     char outstr[21];

public:		// User declarations
     __fastcall TRunsTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRunsTestForm *RunsTestForm;
//---------------------------------------------------------------------------
#endif
