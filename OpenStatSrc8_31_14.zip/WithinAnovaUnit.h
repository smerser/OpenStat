//---------------------------------------------------------------------------

#ifndef WithinAnovaUnitH
#define WithinAnovaUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmRepAnova : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TListBox *ListBox2;
    TSpeedButton *InBtn;
    TSpeedButton *OutBtn;
    TSpeedButton *AllBtn;
    TGroupBox *GroupBox1;
    TCheckBox *RelEstChkBox;
    TCheckBox *AssumpChkBox;
    TCheckBox *PlotVarsChkBox;
    TButton *CancelBtn;
    TButton *ReturnBtn;
    TButton *ComputeBtn;
   TButton *ResetBtn;
   TMemo *Memo1;
   TRadioGroup *OptionsBox;
    TCheckBox *PostHocChk;
    TLabel *Label3;
    TEdit *AlphaEdit;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
   void __fastcall ResetBtnClick(TObject *Sender);
private:	// User declarations

public:		// User declarations
    __fastcall TFrmRepAnova(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmRepAnova *FrmRepAnova;
//---------------------------------------------------------------------------
#endif
