//---------------------------------------------------------------------------

#ifndef SingleLinkUnitH
#define SingleLinkUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TSingleLinkForm : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TListBox *ListBox1;
    TLabel *Label2;
    TBitBtn *VarInBtn;
    TBitBtn *VarOutBtn;
    TGroupBox *GroupBox1;
    TCheckBox *StdChkBox;
    TCheckBox *RepChkBox;
    TCheckBox *DescChkBox;
    TCheckBox *PlotChkBox;
    TButton *BtnReset;
    TButton *BtnCancel;
    TButton *BtnOk;
    TEdit *VarSelEdit;
    TCheckBox *DendoChk;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall BtnResetClick(TObject *Sender);
    void __fastcall VarOutBtnClick(TObject *Sender);
    void __fastcall VarInBtnClick(TObject *Sender);
    void __fastcall BtnOkClick(TObject *Sender);
private:	// User declarations
    void TreePlot(int **Clusters, int *Lst, int NoPoints);
public:		// User declarations
    __fastcall TSingleLinkForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSingleLinkForm *SingleLinkForm;
//---------------------------------------------------------------------------
#endif
