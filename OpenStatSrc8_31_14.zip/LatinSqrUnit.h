//---------------------------------------------------------------------------

#ifndef LatinSqrUnitH
#define LatinSqrUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TLatinSqrForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TRadioGroup *PlanGrp;
     TButton *CancelBtn;
     TButton *OKBtn;
     void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
     void __fastcall Plan1(TObject *Sender);
     void __fastcall Plan2(TObject *Sender);
     void __fastcall Plan3(TObject *Sender);
     void __fastcall Plan4(TObject *Sender);
     void __fastcall Plan5(TObject *Sender);
     void __fastcall Plan6(TObject *Sender);
     void __fastcall Plan7(TObject *Sender);
     void __fastcall Plan8(TObject *Sender);
     void __fastcall Plan9(TObject *Sender);

public:		// User declarations
     __fastcall TLatinSqrForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLatinSqrForm *LatinSqrForm;
//---------------------------------------------------------------------------
#endif
