//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <Printers.hpp>
#include "testadmunit.h"
#include "TestFrmUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestAdminFrm *TestAdminFrm;
//---------------------------------------------------------------------------
__fastcall TTestAdminFrm::TTestAdminFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestAdminFrm::OpenBtnClick(TObject *Sender)
{
    AnsiString tempfile;

    OpenDialog1->Filter = "Item Bank (*.bnk)|*.BNK|All files (*.*)|*.*";
    OpenDialog1->FilterIndex = 1;
    if ((OpenDialog1->Execute()) == NULL) return;
    tempfile = ExtractFileName(OpenDialog1->FileName);
    strcpy(filename,tempfile.c_str());
    if (FileExists(filename)) // existing bank
    {
        hdrfileptr = fopen(filename,"rb");
        if (hdrfileptr == NULL)
        {
            Application->MessageBox("Could not open old item bank index header.",
                "FILE ERROR!",MB_OK);
            return;
        }
        hdrptr = &bankhdr;
        fread(hdrptr,sizeof(header),1,hdrfileptr);
        NoItems = bankhdr.NoItems;
        strcpy(bankname,bankhdr.bankname);
        if ((bankfileptr = fopen(bankname,"r+b")) == NULL)
        {
            Application->MessageBox("Can't open items file.","FILE ERROR!",MB_OK);
            fclose(hdrfileptr);
            return;
        }
        fileopen = true;
    }
    else
    {
        Application->MessageBox("The file selected does not exist.","FILE MESSAGE",MB_OK);
        return;
    }
    fclose(hdrfileptr);
    parmsptr = &parms;
    strcpy(parmfile,filename);
    strcat(parmfile,".PRM");
    if ((prmfileptr = fopen(parmfile,"rb")) == NULL)
    {
        Application->MessageBox("Could not open test specification file.",
            "FILE ERROR!",MB_OK);
        TestAdminFrm->Hide();
    }
    fread(parmsptr,sizeof(testparms),1,prmfileptr);
    fclose(prmfileptr);
    BankNameEdit->Text = filename;
    if (parms.AdminOpt == 0) MethodEdit->Text = "Printer";
    else MethodEdit->Text = "Computer screen";
    NItemsEdit->Text = parms.noselected;
    NsubsEdit->Text = parms.Ntests;
}
//---------------------------------------------------------------------------

void __fastcall TTestAdminFrm::getitem(int ino)
{
    long int whereat;

    if (fileopen)
    {
        whereat = bankhdr.ItemStart[ino-1];
        fseek(bankfileptr,whereat,0);
        // get fixed values
        descptr = &fixeditem;
        fread(descptr,sizeof(itemdesc),1,bankfileptr);
        itemno = fixeditem.ItemNo;
        NoFoils = fixeditem.nofoils;
        stemlines = fixeditem.stemlines;
        for (int i = 0; i < fixeditem.nofoils; i++)
            foillines[i] = fixeditem.foillines[i];
        for (int i = 0; i < fixeditem.stemlines; i++)
            strcpy(Stem[i],fixeditem.Stem[i]);
        for (int i = 0; i < fixeditem.nofoils; i++)
            for (int j = 0; j < fixeditem.foillines[i]; j++)
                strcpy(Foil[i][j],fixeditem.Foil[i][j]);
    }
    else
    {
        Application->MessageBox("Item file is not open.", "FILE ERROR!",MB_OK);
    }
}
//---------------------------------------------------------------------------

void __fastcall TTestAdminFrm::CancelBtnClick(TObject *Sender)
{
    TestAdminFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TTestAdminFrm::OKBtnClick(TObject *Sender)
{
    char astring[81];
    int page = 1;
    AnsiString response;
    Graphics::TBitmap *Bitmap1 = new Graphics::TBitmap();
    TRect rectangle;

    switch (parms.AdminOpt)
    {
        case 0: //printer administration
        {
            TPrinter *prtr = Printer();
            int LineHeight = prtr->Canvas->TextHeight("A");  // calculate line height
            int picwide = 800;
            int pichigh = 600;
            // includes leading
            int Ypos = prtr->Canvas->Font->PixelsPerInch; // add a one-inch top margin
            int Xpos = prtr->Canvas->Font->PixelsPerInch; // add a one-inch left margin
            Ypos = Xpos; //set X,Y at same pixel location
            prtr->BeginDoc();           // start printing
            for (int j = 0; j < parms.Ntests; j++)
            {
                // print test no., subject id and instructions
                sprintf(astring,"Test No. %d for subject %s, Page %d  YOUR NAME ____________________________",
                    j+1,parms.IDs[j],page);
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += 2*LineHeight;
                sprintf(astring,"DIRECTIONS:");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += LineHeight;
                sprintf(astring,"    If a multiple choice or true-false item, elect the one best answer");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += LineHeight;
                sprintf(astring,"and place the letter of your choice in the blank in front of the item number.");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += LineHeight;
                sprintf(astring,"If a word, phrase or sentence is required, write your answer in the answer blank");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += LineHeight;
                sprintf(astring,"provided following the question.  For essay or sketch questions, write your text on seperate");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += LineHeight;
                sprintf(astring,"pieces of paper provided by your examiner.");
                prtr->Canvas->TextOut(Xpos,Ypos,astring);
                Ypos += 2*LineHeight;
                for (int i = 0; i < parms.noselected; i++)
                {
                    // get an item
                    getitem(parms.selected[i]);
                    if (strlen(fixeditem.BMPfile) > 1) // bitmap file exists - display it first
                    {
                        try
                        {
                            rectangle = Rect(Xpos,Ypos,Xpos+picwide,Ypos+pichigh);
                            prtr->Canvas->FrameRect(rectangle);
                            Bitmap1->LoadFromFile(fixeditem.BMPfile);
                            prtr->Canvas->StretchDraw(rectangle,Bitmap1);
                            Ypos += pichigh + 10;
                        }
                        catch (...)
                        {
                            MessageBeep(0);
                        }
                    }

                    // write the item stem
                    sprintf(astring,"_____ %d",i+1);
                    prtr->Canvas->TextOut(10,Ypos,astring);
                    for (int k = 0; k < stemlines; k++)
                    {
                        // write the text for the next line
                        prtr->Canvas->TextOut(Xpos, Ypos, Stem[k]);
                    }
                    Ypos += LineHeight;
                    if (fixeditem.itemtype < 2) // for MC and TF
                    {
                        // write the choices
                        for (int k = 0; k < NoFoils; k++)
                        {
                            strcpy(astring,"");
                            astring[0] = char('A'+ k);
                            astring[1] = '.';
                            astring[2] = '\0';
                            prtr->Canvas->TextOut(Xpos,Ypos,astring);
                            for (int L = 0; L < foillines[k]; L++)
                            {
                                prtr->Canvas->TextOut(Xpos+Xpos/2, Ypos, Foil[k][L]);
                            }
                            Ypos += LineHeight;
                        } // next choice
                    }
                    if ((fixeditem.itemtype >= 2)&&(fixeditem.itemtype < 6))
                    {
                        Ypos += LineHeight;
                        sprintf(astring,"ANSWER: _________________________________________________________________");
                        prtr->Canvas->TextOut(Xpos,Ypos,astring);
                        Ypos += LineHeight;
                    }

                    Ypos += 2 * LineHeight;
                    if (Ypos > 65*LineHeight)// do we need a new page?
                    {
                        prtr->NewPage();
                        Ypos = prtr->Canvas->Font->PixelsPerInch;
                        page++;
                        sprintf(astring,"Test No. %d for subject %s, Page %d",j+1,parms.IDs[j],page);
                        prtr->Canvas->TextOut(Xpos,Ypos,astring);
                        Ypos += 2*LineHeight;
                    }
                } // next item
                if (parms.Ntests-1 > j )
                {
                    prtr->NewPage();
                    Ypos = prtr->Canvas->Font->PixelsPerInch;
                }
            } // next test
            prtr->EndDoc();    // finish printing
        }
        break;
        case 1: // crt administration
        {
            bool found = false;
            // includes leading
            AnsiString response = InputBox("IDENTIFICATION","Enter your ID:","");
            for (int i = 0; i < parms.Ntests; i++)
            {
                AnsiString ID = parms.IDs[i];
                if (ID == response) found = true;
            }
            if (!found)
            {
                Application->MessageBox("Invalid ID","ERROR",MB_OK);
                TestAdminFrm->Hide();
                return;
            }
            else
            {
                for (int i = 0; i < parms.noselected; i++)
                {
                    getitem(parms.selected[i]);
                    corchoice = fixeditem.correctno;
                    strcpy(BMPfile,fixeditem.BMPfile);
                    TestFrm->itemtype = fixeditem.itemtype;
                    TestFrm->itemno = fixeditem.ItemNo;
                    if (fixeditem.itemtype == 2)
                        strcpy(TestFrm->answer,fixeditem.Foil[0][0]);
                    TestFrm->ShowModal();
                    TotalScore = TestFrm->TotalScore;
                } // next item
                Label5->Visible = true;
                ScoreEdit->Visible = true;
                ScoreEdit->Text = TotalScore;
            } // end else
        }
        break;
    } // end switch
    Bitmap1->Dormant();           // Free up GDI resources
    Bitmap1->FreeImage();         // Free up Memory.
    Bitmap1->ReleaseHandle();       // This will actually lose the bitmap;
    delete Bitmap1;
}
//-------------------------------------------------------------------------

void __fastcall TTestAdminFrm::FormShow(TObject *Sender)
{
    Label5->Visible = false;
    ScoreEdit->Visible = false;
}
//---------------------------------------------------------------------------

