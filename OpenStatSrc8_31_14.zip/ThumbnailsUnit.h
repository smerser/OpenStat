//---------------------------------------------------------------------------

#ifndef ThumbnailsUnitH
#define ThumbnailsUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TThumbnailsForm : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TImage *Image2;
    TImage *Image3;
    TImage *Image4;
    TImage *Image5;
    TImage *Image6;
    TImage *Image7;
    TImage *Image8;
    TImage *Image9;
    TImage *Image10;
    TImage *Image11;
    TImage *Image12;
    TImage *Image13;
    TImage *Image14;
    TImage *Image15;
    TImage *Image16;
    TImage *Image17;
    TImage *Image18;
    TImage *Image19;
    TImage *Image20;
    TImage *Image21;
    TImage *Image22;
    TImage *Image23;
    TImage *Image24;
    TImage *Image25;
    TImage *Image26;
    TImage *Image27;
    TImage *Image28;
    TButton *Button1;
    TButton *Button2;
    TButton *ReturnBtn;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TLabel *Label11;
    TLabel *Label12;
    TLabel *Label13;
    TLabel *Label14;
    TLabel *Label15;
    TLabel *Label16;
    TLabel *Label17;
    TLabel *Label18;
    TLabel *Label19;
    TLabel *Label20;
    TLabel *Label21;
    TLabel *Label22;
    TLabel *Label23;
    TLabel *Label24;
    TLabel *Label25;
    TLabel *Label26;
    TLabel *Label27;
    TLabel *Label28;
    TLabel *Label29;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FillPics(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall Image1Click(TObject *Sender);
    void __fastcall Image2Click(TObject *Sender);
    void __fastcall Image3Click(TObject *Sender);
    void __fastcall Image4Click(TObject *Sender);
    void __fastcall Image5Click(TObject *Sender);
    void __fastcall Image6Click(TObject *Sender);
    void __fastcall Image7Click(TObject *Sender);
    void __fastcall Image8Click(TObject *Sender);
    void __fastcall Image9Click(TObject *Sender);
    void __fastcall Image10Click(TObject *Sender);
    void __fastcall Image11Click(TObject *Sender);
    void __fastcall Image12Click(TObject *Sender);
    void __fastcall Image13Click(TObject *Sender);
    void __fastcall Image14Click(TObject *Sender);
    void __fastcall Image15Click(TObject *Sender);
    void __fastcall Image16Click(TObject *Sender);
    void __fastcall Image17Click(TObject *Sender);
    void __fastcall Image18Click(TObject *Sender);
    void __fastcall Image19Click(TObject *Sender);
    void __fastcall Image20Click(TObject *Sender);
    void __fastcall Image21Click(TObject *Sender);
    void __fastcall Image22Click(TObject *Sender);
    void __fastcall Image23Click(TObject *Sender);
    void __fastcall Image24Click(TObject *Sender);
    void __fastcall Image25Click(TObject *Sender);
    void __fastcall Image26Click(TObject *Sender);
    void __fastcall Image27Click(TObject *Sender);
    void __fastcall Image28Click(TObject *Sender);
    void __fastcall ClearAll(TObject *Sender);
private:	// User declarations
    int NoShowing;
    int NoAvailable;
    int CurrentStart;
    int CurrentEnd;
    AnsiString filename, extension;
    bool goodfile;

public:		// User declarations
    int picno;
    __fastcall TThumbnailsForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TThumbnailsForm *ThumbnailsForm;
//---------------------------------------------------------------------------
#endif
