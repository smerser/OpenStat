//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "PlotUnit.h"
#include "functions.h"
#include "SPCSigmaUnit.h"

extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSPCSigmaForm *SPCSigmaForm;
//---------------------------------------------------------------------------
__fastcall TSPCSigmaForm::TSPCSigmaForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSPCSigmaForm::ResetBtnClick(TObject *Sender)
{
     VarList->Clear();
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     SigmaGroup->ItemIndex = -1;
     ShowUpperChk->Checked = false;
     ShowLowerChk->Checked = false;
     UseTargetChk->Checked = false;
     SigmaEdit->Text = "";
     UpperSpecEdit->Text = "";
     LowerSpecEdit->Text = "";
     TargetSpecEdit->Text = "";
     GroupEdit->Text = "";
     MeasEdit->Text = "";     
}
//---------------------------------------------------------------------------
void __fastcall TSPCSigmaForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);        
}
//---------------------------------------------------------------------------
void __fastcall TSPCSigmaForm::ComputeBtnClick(TObject *Sender)
{
     int i, GrpVar, MeasVar, mingrp, maxgrp, G, range, oldgroupsize, grpsize;
     double X, UCL, LCL, Sigma, UpperSpec, LowerSpec, TargetSpec;
     double GrandMean, GrandSD, semean, D3Value, D4Value;
     double GrandSigma, xmax, xmin, B, C4, gamma;
     double *means, *stddev;
     int *count;
     bool sizeerror = false;
     AnsiString cellstring;
     char outline[101];

     FrmOutPut->RichOutPut->Clear();
     GrpVar = 1;
     MeasVar = 2;
     Sigma = 0.0;
     UpperSpec = 0.0;
     LowerSpec = 0.0;
     TargetSpec = 0.0;
     grpsize = 0;
     oldgroupsize = 0;

     for (i = 1; i <= NoVariables; i++)
     {
          cellstring = MainForm->Grid->Cells[i][0];
          if (cellstring == GroupEdit->Text) GrpVar = i;
          if (cellstring == MeasEdit->Text) MeasVar = i;
     }

     if (UpperSpecEdit->Text != "") UpperSpec = StrToFloat(UpperSpecEdit->Text);
     if (LowerSpecEdit->Text != "") LowerSpec = StrToFloat(LowerSpecEdit->Text);
     if (TargetSpecEdit->Text != "") TargetSpec = StrToFloat(TargetSpecEdit->Text);
     if (SigmaGroup->ItemIndex == 3) Sigma = StrToFloat(SigmaEdit->Text);
     if (SigmaGroup->ItemIndex == 0)  Sigma = 3.0;
     if (SigmaGroup->ItemIndex == 1)  Sigma = 2.0;
     if (SigmaGroup->ItemIndex == 2)  Sigma = 1.0;

     mingrp = 10000;
     maxgrp = -10000;
     for (i = 1; i <= NoCases; i++)
     {
          if (! ValidValue(i,GrpVar)) continue;
          G = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpVar][i])));
          if (G < mingrp) mingrp = G;
          if (G > maxgrp) maxgrp = G;
     }
     range = maxgrp - mingrp + 1;

     GetDblVecMem(means,range);
     GetIntVecMem(count,range);
     GetDblVecMem(stddev,range);
     for (i = 0; i < range; i++)
     {
          count[i] = 0;
          means[i] = 0.0;
          stddev[i] = 0.0;
     }
     semean = 0.0;
     GrandMean = 0.0;
     GrandSigma = 0.0;

     // calculate group ranges, grand mean, group sd's, semeans
     for (int j = 0; j < range; j++)
     {
         xmin = 10000.0;
         xmax = -10000.0;
         for (i = 1; i <= NoCases; i++)
         {
             if (! ValidValue(i,GrpVar)) continue;
             G = floor(StrToFloat(Trim(MainForm->Grid->Cells[GrpVar][i])));
             G = G - mingrp + 1;
             if (G == j+1)
             {
                X = StrToFloat(Trim(MainForm->Grid->Cells[MeasVar][i]));
                if (X > xmax) xmax = X;
                if (X < xmin) xmin = X;
                means[G-1] = means[G-1] + X;
                count[G-1] = count[G-1] + 1;
                stddev[G-1] = stddev[G-1] + (X * X);
                semean = semean + (X * X);
                GrandMean = GrandMean + X;
             }
         }
         grpsize = count[j];
         if (j == 0) oldgroupsize = grpsize;
         if (oldgroupsize != grpsize) sizeerror = true;
     }
     if ((grpsize < 2) || (grpsize > 25) || (sizeerror))
     {
          ShowMessage("ERROR! Group sizes error.");
          goto cleanup;
     }

     for (i = 0; i < range; i++)
     {
          stddev[i] = stddev[i] -((means[i] * means[i]) / count[i]);
          if (count[i] > 1)
          {
               stddev[i] = stddev[i] / (count[i] - 1);
               stddev[i] = sqrt(stddev[i]);
          }
          else stddev[i] = 0.0;
          means[i] = means[i] / count[i];
          GrandSigma += stddev[i];
     }
     semean = semean - ((GrandMean * GrandMean) / NoCases);
     semean = semean / (NoCases - 1);
     semean = sqrt(semean);
     GrandSD = semean;
     semean = semean / sqrt(NoCases);
     GrandMean = GrandMean / NoCases;
     GrandSigma = GrandSigma / range;
     C4 = sqrt(2.0 / (grpsize - 1));
     gamma = exp(gammln(grpsize / 2.0));
     C4 = C4 * gamma;
     gamma = exp(gammln((grpsize-1) / 2.0));
     C4 = C4 / gamma;
     B = GrandSigma * sqrt(1.0 - (C4 * C4)) / C4;
     UCL = GrandSigma + (3.0 * B);
     LCL = GrandSigma - (3.0 * B);
     if (LCL < 0.0) LCL = 0.0;
     if (SigmaGroup->ItemIndex >= 0)
     {
        UCL = GrandSigma + (Sigma * UCL);
        LCL = GrandSigma - (Sigma * LCL);
     }

     // printed results
     FrmOutPut->RichOutPut->Lines->Add("Range Chart Results");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Group Size Mean      Std.Dev.");
     FrmOutPut->RichOutPut->Lines->Add("('_____ ____ _________ ________");
     for (i = 0; i < range; i++)
     {
          sprintf(outline," %3d %3d %8.2f  %8.2f  %8.2f",i+1,count[i],means[i],stddev[i]);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     sprintf(outline,"Grand Mean = %8.2f, Std.Dev. = %8.3f, Standard Error of Mean = %8.2f",
            GrandMean, GrandSD, semean);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Mean Sigma = %8.2f",GrandSigma);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"Lower Control Limit = %8.3f, Upper Control Limit = %8.3f",
            LCL, UCL);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->ShowModal();

     // show graph
     PlotMeans(stddev,range,UCL,LCL,GrandSigma,TargetSpec,LowerSpec, UpperSpec, this);
cleanup:
     ClearDblVecMem(stddev);
     ClearIntVecMem(count);
     ClearDblVecMem(means);
}
//---------------------------------------------------------------------------
void __fastcall TSPCSigmaForm::VarListClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     if (GroupEdit->Text == "") GroupEdit->Text = VarList->Items->Strings[index];
     else MeasEdit->Text = VarList->Items->Strings[index];
}
//---------------------------------------------------------------------------

void __fastcall TSPCSigmaForm::PlotMeans(double *means,
                             int NoGrps,
                             double UCL, double LCL, double GrandMean,
                             double TargetSpec, double LowerSpec, double UpperSpec,
                             TObject *Sender)
{
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi;
     double imagehi, maxval, minval, valincr, Yvalue;
     char Title[101];

     maxval = -10000.0;
     minval = 10000.0;
     for (i = 0; i < NoGrps; i++)
     {
          if (means[i] > maxval)  maxval = means[i];
          if (means[i] < minval)  minval = means[i];
     }
     if (UCL > maxval)  maxval = UCL;
     if (LCL < minval)  minval = LCL;
     if (ShowUpperChk->Checked)
     {
          if (UpperSpec > maxval)  maxval = UpperSpec;
     }
     if (ShowLowerChk->Checked)
     {
          if (LowerSpec < minval)  minval = LowerSpec;
     }
     if (UseTargetChk->Checked)
     {
          if (TargetSpec > maxval)  maxval = TargetSpec;
          if (TargetSpec < minval)  minval = TargetSpec;
     }

     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(hleft,vtop-10,hleft+hwide,vtop+vhi+10);

     // draw Grand Mean
     ypos = ceil(vhi * ( (maxval - GrandMean) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"MEAN");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Canvas->Brush->Color = clLtGray;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // draw horizontal axis
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom + 20);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom + 20);
     for (i = 1; i <= NoGrps; i++)
     {
          ypos = vbottom + 10;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(Title,"%d",i);
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = xpos - offset;
          ypos = ypos + strhi;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = 10;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,"GROUPS:");
     }

     // Draw vertical axis
     valincr = (maxval - minval) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          sprintf(Title,"%8.2f",maxval - ((i-1)*valincr));
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = maxval - (valincr * (i-1));
          ypos = ceil(vhi * ( (maxval - Yvalue) / (maxval - minval)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     // draw lines for means of the groups
     ypos = ceil(vhi * ( (maxval - means[0]) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = ceil((hwide / NoGrps) + hleft);
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     for (i = 2; i <= NoGrps; i++)
     {
          ypos = ceil(vhi * ( (maxval - means[i-1]) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = ceil((hwide / NoGrps)* i + hleft);
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // Draw upper and lower confidence intervals
     ypos = ceil(vhi * ( (maxval - UCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"UCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     ypos = ceil(vhi * ( (maxval - LCL) / (maxval - minval)));
     ypos = ypos + vtop;
     xpos = hleft;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     xpos = hright;
     PlotForm->Image1->Canvas->Pen->Color = clRed;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     strcpy(Title,"LCL");
     strhi = PlotForm->Image1->Canvas->TextHeight(Title);
     ypos = ypos - strhi / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);

     // Draw lines for specified values
     if (ShowUpperChk->Checked)
     {
          ypos = ceil(vhi * ( (maxval - UpperSpec) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          strcpy(Title,"UPPER SPEC");
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     if (ShowLowerChk->Checked)
     {
          ypos = ceil(vhi * ( (maxval - LowerSpec) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clGreen;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          strcpy(Title,"LOWER SPEC");
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }

     if (UseTargetChk->Checked)
     {
          ypos = ceil(vhi * ( (maxval - TargetSpec) / (maxval - minval)));
          ypos = ypos + vtop;
          xpos = hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hright;
          PlotForm->Image1->Canvas->Pen->Color = clBlue;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          strcpy(Title,"TARGET");
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          ypos = ypos - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     strcpy(Title,"SIGMA CHART FOR : ");
     strcat(Title, MainForm->FileNameEdit->Text.c_str());
     ypos = PlotForm->Image1->Height - PlotForm->Image1->Canvas->TextHeight(Title);
     xpos = PlotForm->Image1->Width / 2 - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     PlotForm->ShowModal();
}