//---------------------------------------------------------------------------

#ifndef RootMethodUnitH
#define RootMethodUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFrmRootMethod : public TForm
{
__published:	// IDE-managed Components
     TRadioGroup *RadioGroup1;
     TButton *Cancel;
     TButton *Return;
     void __fastcall RadioGroup1Click(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
   int Choice;
     __fastcall TFrmRootMethod(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmRootMethod *FrmRootMethod;
//---------------------------------------------------------------------------
#endif
