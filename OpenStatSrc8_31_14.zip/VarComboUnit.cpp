//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <math.h>
#include <stdio.h>
#include "functions.h"
#include "DateFunc.h"
#include "DictionaryUnit.h"
#include "DataFuncs.h"
#include "VarComboUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TVarComboForm *VarComboForm;
extern int NoVariables;
extern int NoCases;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TVarComboForm::TVarComboForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TVarComboForm::ResetBtnClick(TObject *Sender)
{
     AnsiString cellstring;

     VarList->Clear();
     SelList->Clear();
     ComboGrp->ItemIndex = 0;
     Var1In->Enabled = true;
     Var1Out->Enabled = false;
     NewVarEdit->Text = "NewVar";
     for (int i = 0; i < NoVariables; i++)
     {
         cellstring = MainForm->Grid->Cells[i+1][0];
         VarList->Items->Add(cellstring);
     }
}
//---------------------------------------------------------------------------
void __fastcall TVarComboForm::Var1InClick(TObject *Sender)
{
     int i, index;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
           if (VarList->Selected[i]) {
              SelList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
              index--;
           }
           else i++;
     }
     Var1Out->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TVarComboForm::Var1OutClick(TObject *Sender)
{
     int index;

     index = SelList->ItemIndex;
     VarList->Items->Add(SelList->Items->Strings[index]);
     SelList->Items->Delete(index);
     Var1In->Enabled = true;
     if (SelList->Items->Count == 0) Var1Out->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TVarComboForm::FormShow(TObject *Sender)
{
 ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TVarComboForm::ComputeBtnClick(TObject *Sender)
{
     AnsiString NewVar, cellstring;
     int combotype = ComboGrp->ItemIndex;;
     double result;
     double value;
     int noselect = SelList->Items->Count;
     int vcol, gridcol;

     if (noselect < 1)
     {
        ShowMessage("Error! No Variables Selected.");
        return;
     }
     // create a new variable
     MainForm->Grid->ColCount++;
     gridcol = NoVariables + 1; // new variable column
     NoVariables++;
     MainForm->NoVarsEdit->Text = NoVariables;
     NewVar = NewVarEdit->Text;
     MainForm->Grid->Cells[gridcol][0] = NewVar;
     // Add definition data
     DictionaryForm->DGrid->Cells[1][gridcol] = NewVar;
     DictionaryForm->DGrid->Cells[2][gridcol] = NewVar;
     DictionaryForm->DGrid->Cells[0][gridcol] = IntToStr(gridcol);
     DictionaryForm->DGrid->Cells[3][gridcol] = ops.format;
     DictionaryForm->DGrid->Cells[4][gridcol] = ops.gridfldwidth;
     DictionaryForm->DGrid->Cells[5][gridcol] = ops.gridnodecimals;
     DictionaryForm->DGrid->Cells[6][gridcol] = ops.missval;
     if (gridcol+1 > DictionaryForm->DGrid->RowCount)
           DictionaryForm->DGrid->RowCount = gridcol + 1;
     NoVariables = DictionaryForm->DGrid->RowCount-1;
     if (NoVariables + 1 > MainForm->Grid->ColCount)
           MainForm->Grid->ColCount = NoVariables + 1;
     MainForm->NoVarsEdit->Text = IntToStr(NoVariables);
     MainForm->Grid->Col = gridcol;

     // do the analysis
     for (int k = 1; k <= NoCases; k++)
     {
         result = 0.0;
         int valcnt = 0;
         for (int j = 0; j < noselect; j++)
         {
             cellstring = SelList->Items->Strings[j];
             for (int i = 1; i <= NoVariables; i++)
             {
                 if (MainForm->Grid->Cells[i][0] == cellstring)
                 {
                    vcol = i; // grid col. of selected variable
                    continue;
                 }
             }
             if (!ValidValue(k,vcol)) continue;
             value = StrToFloat(MainForm->Grid->Cells[vcol][k]);
             valcnt++;
             switch (combotype)
             {
                case 0: // sum values
                {
                     result += value;
                     break;
                }
                case 1: // product of values
                {
                     if (j == 0) result = value; // first item
                     else result *= value;
                     break;
                }
                case 2: // average value
                {
                     result += value;
                     break;
                }
             } // end of switch
         } // next j variable
         // add result to the new item
         if (combotype == 2) result = result / float(valcnt);
         MainForm->Grid->Cells[gridcol][k] = result;
     } // next k case
}
//---------------------------------------------------------------------------
