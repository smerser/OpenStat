//---------------------------------------------------------------------------

#ifndef HyperGeomUnitH
#define HyperGeomUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class THyperGeoForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *SampSizeEdit;
        TEdit *PopSizeEdit;
        TEdit *SampObsEdit;
        TEdit *PopObsEdit;
        TEdit *ProbXEdit;
        TEdit *ProbGTEdit;
        TEdit *ProbLessEdit;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TEdit *ProbGEEdit;
        TLabel *Label8;
        TLabel *Label9;
        TEdit *ProbLTEdit;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
        void __fastcall FisherTable(int A, int B, int C, int D,
                                        double p, double SumP);

private:	// User declarations
public:		// User declarations
        __fastcall THyperGeoForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE THyperGeoForm *HyperGeoForm;
//---------------------------------------------------------------------------
#endif
