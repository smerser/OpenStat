//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MemMgrUnit.h"
#include "PlotUnit.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "math.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "stdio.h"
#include "functions.h"
#include "BubbleUnit.h"

extern int NoCases;
extern int NoVariables;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBubbleForm *BubbleForm;
//---------------------------------------------------------------------------
__fastcall TBubbleForm::TBubbleForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     BubbleEdit->Text = "";
     XEdit->Text = "";
     YEdit->Text = "";
     SizeEdit->Text = "";
     XlabelEdit->Text = "";
     YlabelEdit->Text = "";
     TitleEdit->Text = "";
     BubbleInBtn->Enabled = true;
     BubbleOutBtn->Enabled = false;
     XInBtn->Enabled = true;
     XOutBtn->Enabled = false;
     YInBtn->Enabled = true;
     YOutBtn->Enabled = false;
     SizeInBtn->Enabled = true;
     SizeOutBtn->Enabled = false;
     Transform->Checked = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::BubbleInBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              BubbleEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     BubbleOutBtn->Enabled = true;
     BubbleInBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::BubbleOutBtnClick(TObject *Sender)
{
     int index;

     Varlist->Items->Add(BubbleEdit->Text);
     BubbleEdit->Text = "";
     BubbleInBtn->Enabled = true;
     if (BubbleEdit->Text == "") BubbleOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::XInBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              XEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     XOutBtn->Enabled = true;
     XInBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::XOutBtnClick(TObject *Sender)
{
     int index;

     Varlist->Items->Add(XEdit->Text);
     XEdit->Text = "";
     XInBtn->Enabled = true;
     if (XEdit->Text == "") XOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::YInBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              YEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     YOutBtn->Enabled = true;
     YInBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::YOutBtnClick(TObject *Sender)
{
     int index;

     Varlist->Items->Add(YEdit->Text);
     YEdit->Text = "";
     YInBtn->Enabled = true;
     if (YEdit->Text == "") YOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::SizeInBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              SizeEdit->Text = Varlist->Items->Strings[i];
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     SizeOutBtn->Enabled = true;
     SizeInBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::SizeOutBtnClick(TObject *Sender)
{
     int index;

     Varlist->Items->Add(SizeEdit->Text);
     SizeEdit->Text = "";
     SizeInBtn->Enabled = true;
     if (SizeEdit->Text == "") SizeOutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TBubbleForm::ComputeBtnClick(TObject *Sender)
{
        int BubbleCol, XCol, YCol, SizeCol, i, j, LabelWide, TextHi, Xpos;
        int ImageWide, ImageHi, Xstart, Xend, Ystart, Yend, Yincr, tempcol;
        int Xmin, Xmax, Xrange, Xstep, intcell, noreplications, minrep, maxrep;
        int MaxBubSize, MinBubSize, nobubbles, xprop, yprop, xvalue;
        AnsiString varname, Xlabel, Ylabel, astring, Title, cellstring;
        double Ymin, Ymax, Yrange, Ystep, cellvalue;
        double BubMin, BubMax, BubRange, ratio;
        char valstr[95];
        int Bubcolor;
        TColor Colors[12];
        bool results;
        int result, intvalue;
        double dblvalue;
        AnsiString strvalue;

        Colors[0] = clMaroon;
        Colors[1] = clRed;
        Colors[2] = clBlue;
        Colors[3] = clGreen;
        Colors[4] = clNavy;
        Colors[5] = clTeal;
        Colors[6] = clAqua;
        Colors[7] = clLime;
        Colors[8] = clFuchsia;
        Colors[9] = clGray;
        Colors[10] = clPurple;
        Colors[11] = clOlive;


        BubbleCol = 0;
        XCol = 0;
        YCol = 0;
        SizeCol = 0;
        for (i = 1; i <= NoVariables; i++)
        {
                varname = MainForm->Grid->Cells[i][0];
                if (varname == BubbleEdit->Text) BubbleCol = i;
                if (varname == XEdit->Text) XCol = i;
                if (varname == YEdit->Text) YCol = i;
                if (varname == SizeEdit->Text) SizeCol = i;
        }
        if ((BubbleCol == 0) || (XCol == 0) || (YCol == 0) || (SizeCol == 0))
        {
                ShowMessage("ERROR! One or more variables not found!");
                return;
        }

        // check to see if strcol is a string variable
        cellstring = DictionaryForm->DGrid->Cells[3][BubbleCol];
        if (cellstring == "2") // recode into an integer code
        {
                results = StringsToInt(BubbleCol, tempcol, true);
                BubbleCol = NoVariables;
        }

        // check variable types if strong checking desired
/*        result = VarTypeChk(BubbleCol,1);
        if (result == 1) return;
        result = VarTypeChk(XCol,1);
        if (result == 1) return;
        result = VarTypeChk(YCol,0);
        if (result == 1) return;
        result = VarTypeChk(SizeCol,0);
        if (result == 1) return; */
        PlotForm->Caption = "Bubble Plot of " + MainForm->FileNameEdit->Text;
        Xlabel = XlabelEdit->Text;
        Ylabel = YlabelEdit->Text;
        Title = TitleEdit->Text;
        ImageHi = PlotForm->Image1->Height;
        ImageWide = PlotForm->Image1->Width;
        Xstart = ImageWide / 10;
        Xend = (ImageWide * 9) / 10;
        Ystart = ImageHi / 10;
        Yend = (ImageHi * 9) / 10;
        PlotForm->Image1->Canvas->Pen->Color = clBlack;
        PlotForm->Image1->Canvas->Brush->Color = clWhite;
        PlotForm->Image1->Canvas->Rectangle(0,0,ImageWide,ImageHi);
        PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
        PlotForm->Image1->Canvas->TextOut(Xstart-10,Ystart-30,Ylabel);
        LabelWide = PlotForm->Image1->Canvas->TextWidth(Xlabel);
        PlotForm->Image1->Canvas->TextOut((Xend-Xstart)/2- LabelWide / 2,Yend + 40,Xlabel);
        LabelWide = PlotForm->Image1->Canvas->TextWidth(Title);
        PlotForm->Image1->Canvas->TextOut((Xend-Xstart)/2 - LabelWide / 2, Ystart - 40,Title);

        // draw axis lines
        PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
        PlotForm->Image1->Canvas->LineTo(Xend,Yend);
        PlotForm->Image1->Canvas->MoveTo(Xstart,Yend);
        PlotForm->Image1->Canvas->LineTo(Xstart,Ystart);

        // get number of bubbles and replications per bubble (number of bubble id's)
        minrep = 1000;
        maxrep = -1;
        for (int i = 1; i <= NoCases; i++)
        {
                intcell = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][i]));
                //result = GetValue(i, BubbleCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //intcell = intvalue;
                if (intcell > maxrep) maxrep = intcell;
                if (intcell < minrep) minrep = intcell;
        }
        nobubbles = maxrep - minrep + 1;
        noreplications = 1;
        intcell = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][1]));
        //result = GetValue(1, BubbleCol,intvalue, dblvalue, strvalue);
        //if (result != 0) intcell = 0;
        //intcell = intvalue;
        for (int i = 2; i <= NoCases; i++)
        {
                int cell = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][i]));
                //result = GetValue(i, BubbleCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //int cell = intvalue;
                if (cell == intcell) noreplications++;
        }

        // get min, max and range of Y
        Ymin = 1.0e300;
        Ymax = -1.0e300;
        for (int i = 1; i <= NoCases; i++)
        {
                cellvalue = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                //result = GetValue(i, YCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //cellvalue = dblvalue;
                if (cellvalue > Ymax) Ymax = cellvalue;
                if (cellvalue < Ymin) Ymin = cellvalue;
        }
        Yrange = Ymax - Ymin;
        Ystep = Yrange / 10;

        // get min, max and range of X
        Xmin = 10000;
        Xmax = -1;
        for (int i = 1; i <= NoCases; i++)
        {
                intcell = floor(StrToFloat(MainForm->Grid->Cells[XCol][i]));
                //result = GetValue(i, XCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //intcell = intvalue;
                if (intcell > Xmax) Xmax = intcell;
                if (intcell < Xmin) Xmin = intcell;
        }
        Xrange = Xmax - Xmin;
        Xstep = Xrange / (noreplications-1);

        // get min, max, range, and increment of bubble sizes
        BubMin = 1.0e300;
        BubMax = -1.0e300;
        for (int i = 1; i <= NoCases; i++)
        {
                cellvalue = StrToFloat(MainForm->Grid->Cells[SizeCol][i]);
                //result = GetValue(i, SizeCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //cellvalue = dblvalue;
                if (cellvalue > BubMax) BubMax = cellvalue;
                if (cellvalue < BubMin) BubMin = cellvalue;
        }
        BubRange = BubMax - BubMin;

        // create y axis values
        Yincr = (Yend - Ystart) / 10;
        for (int i = 0; i < 11; i++) // print Y axis values
        {
                int place = Yend - (i * Yincr);
                float value = Ymin + (Ystep * i);
                sprintf(valstr,"%4.2f",value);
                astring = valstr;
                TextHi = PlotForm->Image1->Canvas->TextHeight(astring);
                PlotForm->Image1->Canvas->TextOutA(Xstart-30,place-TextHi,astring);
        }

        // create x axis values
        for (int i = 1; i <= noreplications; i++) // print x axis
        {
                int value = Xmin + ((i-1) * Xstep);
                ratio = (float)i / (float)noreplications;
                Xpos = ratio * (Xend - Xstart);
                sprintf(valstr,"%4d",value);
                astring = valstr;
                PlotForm->Image1->Canvas->TextOutA(Xpos,Yend + 25,astring);
        }

        // Plot the bubbles
        for (int i = 1; i <= NoCases; i++)
        {
                intcell = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][i]));
                //result = GetValue(i, BubbleCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //intcell = intvalue;
                double xvalue = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                //result = GetValue(i, XCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //xvalue = intvalue;
                cellvalue = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                //result = GetValue(i, YCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //cellvalue = dblvalue;
                yprop = Yend - ceil(((cellvalue-Ymin) / Yrange) * (Yend - Ystart));
                PlotForm->Image1->Canvas->MoveTo(xprop,Yend);
                cellvalue = StrToFloat(MainForm->Grid->Cells[SizeCol][i]);
                //result = GetValue(i, SizeCol,intvalue, dblvalue, strvalue);
                //if (result != 0) continue;
                //cellvalue = dblvalue;
                astring = MainForm->Grid->Cells[BubbleCol][i];
                cellvalue = ((cellvalue - BubMin) / BubRange) * 20;
                cellvalue = cellvalue + 10;
                ratio = ((xvalue - Xmin) / Xstep) + 1;
                Xpos = (ratio / noreplications) * (Xend - Xstart);
                Bubcolor = intcell - 1;
                while (Bubcolor > 11) Bubcolor = 12 - Bubcolor;
                PlotForm->Image1->Canvas->Brush->Color = Colors[Bubcolor];
                PlotForm->Image1->Canvas->Ellipse(Xpos-cellvalue,yprop-cellvalue,Xpos+cellvalue,yprop+cellvalue);
                PlotForm->Image1->Canvas->TextOutA(Xpos,yprop,astring);
        }
        PlotForm->ShowModal();

        // Display basic statistics
        int ncases = NoCases / noreplications;
        double GrandYMean = 0.0;
        double GrandSizeMean = 0.0;
        double *Ymeans;
        char outline[121];
        double *CaseYMeans;
        GetDblVecMem(CaseYMeans,ncases);
        double *CaseSizeMeans;
        GetDblVecMem(CaseSizeMeans,ncases);
        GetDblVecMem(Ymeans,noreplications);
        double *SizeMeans;
        GetDblVecMem(SizeMeans,noreplications);
        for (int i = 0; i < ncases; i++)
        {
                CaseYMeans[i] = 0.0;
                CaseSizeMeans[i] = 0.0;
        }
        for (int i = 0; i < noreplications; i++)
        {
                Ymeans[i] = 0.0;
                SizeMeans[i] = 0.0;
        }
        i = 1;

        while ( i <= NoCases)
        {
                for (int j = 1; j <= noreplications; j++)
                {
                        int bubbleID = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][i]));
                        double yvalue = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                        double sizevalue = StrToFloat(MainForm->Grid->Cells[SizeCol][i]);
                        GrandYMean += yvalue;
                        GrandSizeMean += sizevalue;
                        Ymeans[j-1] += yvalue;
                        SizeMeans[j-1] += sizevalue;
                        CaseYMeans[bubbleID-1] += yvalue;
                        CaseSizeMeans[bubbleID-1] += sizevalue;
                        i++;
                }
        }

        GrandYMean /= float(ncases * noreplications);
        GrandSizeMean /= float(ncases * noreplications);
        for (int j = 0; j < noreplications; j++)
        {
                Ymeans[j] /= float(ncases);
                SizeMeans[j] /= float(ncases);
        }
        for (int i = 0; i < ncases; i++)
        {
                CaseYMeans[i] /= float(noreplications);
                CaseSizeMeans[i] /= float(noreplications);
        }

        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("MEANS FOR Y AND SIZE VARIABLES");
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"Grand Mean for Y = %8.3f",GrandYMean);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"Grand Mean for Size = %8.3f",GrandSizeMean);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("REPLICATION MEAN Y VALUES (ACROSS OBJECTS)");
        for (int j = 0; j < noreplications; j++)
        {
                sprintf(outline,"Replication %5d Mean = %8.3f",j+1,Ymeans[j]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("REPLICATION MEAN SIZE VALUES (ACROSS OBJECTS}");
        for (int j = 0; j < noreplications; j++)
        {
                sprintf(outline,"Replication %5d Mean = %8.3f",j+1,SizeMeans[j]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");

        FrmOutPut->RichOutPut->Lines->Add("MEAN Y VALUES FOR EACH BUBBLE (OBJECT)");
        for (int i = 0; i < ncases; i++)
        {
                sprintf(outline,"Object %5d Mean = %8.3f",i+1,CaseYMeans[i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("MEAN SIZE VALUES FOR EACH BUBBLE (OBJECT)");
        for (int i = 0; i < ncases; i++)
        {
                sprintf(outline,"Object %5d Mean = %8.3f",i+1,CaseSizeMeans[i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }

        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();

        ClearDblVecMem(SizeMeans);
        ClearDblVecMem(Ymeans);
        ClearDblVecMem(CaseSizeMeans);
        ClearDblVecMem(CaseYMeans);

        // Transform data matrix if elected
        if (Transform->Checked)
        {
                double **Data;
                int ncases = nobubbles;
                int ncols = noreplications * 3 +1;
                // Note - columns: 1=object ID, 2 to noreplications = X,
                // next noreplications = Y, next noreplications = size
                GetDblMatMem(Data,ncases,ncols);
                int i = 1;
                while (i <= NoCases)
                {
                        for (int j = 1; j <= noreplications; j++)
                        {
                                int bubbleID = floor(StrToFloat(MainForm->Grid->Cells[BubbleCol][i]));
                                double xvalue = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                                double yvalue = StrToFloat(MainForm->Grid->Cells[YCol][i]);
                                double sizevalue = StrToFloat(MainForm->Grid->Cells[SizeCol][i]);
                                Data[bubbleID-1][0] = bubbleID;
                                Data[bubbleID-1][j] = xvalue;
                                Data[bubbleID-1][noreplications+j] = yvalue;
                                Data[bubbleID-1][noreplications*2+j] = sizevalue;
                                i++;
                        }
                }
                AnsiString *labels;
                labels = new AnsiString[NoVariables+1];
                for (int i = 1; i <= NoVariables; i++) labels[i] = MainForm->Grid->Cells[i][0];
                CloseFile();
                MainForm->Grid->RowCount = ncases + 1;
                MainForm->Grid->ColCount = ncols + 1;
                for (int i = 1; i <= ncases; i++)
                {
                        MainForm->Grid->Cells[0][i] = IntToStr(i);
                        for (int j =1; j <= ncols; j++)
                                MainForm->Grid->Cells[j][i] = Data[i-1][j-1];
                }
                MainForm->Grid->Cells[1][0] = labels[1];
                DictionaryForm->DGrid->Cells[1][1] = labels[1];
                for (int j = 1; j <= noreplications; j++)
                {
                        AnsiString astring = labels[2] + IntToStr(j);
                        int newcol = j + 1;
                        MainForm->Grid->Cells[newcol][0] = astring;
                        if (newcol+1 > DictionaryForm->DGrid->RowCount)
                                DictionaryForm->DGrid->RowCount = newcol + 1;
                        DictionaryForm->DGrid->Cells[1][newcol] = astring;
                }
                for (int j = 1; j <= noreplications; j++)
                {
                        AnsiString astring = labels[3] + IntToStr(j);
                        int newcol = j + 1 + noreplications;
                        MainForm->Grid->Cells[newcol][0] = astring;
                        if (newcol+1 > DictionaryForm->DGrid->RowCount)
                                DictionaryForm->DGrid->RowCount = newcol + 1;
                        DictionaryForm->DGrid->Cells[1][newcol] = astring;
                }
                for (int j = 1; j <= noreplications; j++)
                {
                        AnsiString astring = labels[4] + IntToStr(j);
                        int newcol = j + 1 + noreplications * 2;
                        MainForm->Grid->Cells[newcol][0] = astring;
                        if (newcol+1 > DictionaryForm->DGrid->RowCount)
                                DictionaryForm->DGrid->RowCount = newcol + 1;
                        DictionaryForm->DGrid->Cells[1][newcol] = astring;
                }
                NoVariables = ncols;
                NoCases = ncases;
                MainForm->NoCasesEdit->Text = IntToStr(NoCases);
                MainForm->NoVarsEdit->Text = IntToStr(NoVariables);

                for (int col = 1; col <= ncols; col++)
                {
                        DictionaryForm->DGrid->Cells[0][col] = IntToStr(col);
                        DictionaryForm->DGrid->Cells[2][col] = MainForm->Grid->Cells[col][0];
                        DictionaryForm->DGrid->Cells[3][col] = ops.format;
                        DictionaryForm->DGrid->Cells[4][col] = ops.gridfldwidth;
                        DictionaryForm->DGrid->Cells[5][col] = ops.gridnodecimals;
                        DictionaryForm->DGrid->Cells[6][col] = ops.missval;
                }
                ClearDblMatMem(Data,ncases);
                delete[] labels;
        }
        if (results == false) DeleteaCol(NoVariables);
}
//---------------------------------------------------------------------------
