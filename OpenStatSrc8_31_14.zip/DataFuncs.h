#include "system.hpp"

void ImportTabFile(void);
void OpenOSFile(void);
void SaveOSFile(void);
void CloseFile(void);
void CopyIt(void);
void PasteIt(void);
void DeleteIt(void);
void NewVar(int col, bool labels);
void InsertNewCol(int col);
bool ValidRecord(int row, int *ColSelected, int noselected);
int isnumber(char value[]);
int ValidValue(int row, int var);
void GetOptions(void);
void SaveOptions(void);
void PrintCases(void);
void DeleteaCol(int col);
void InsertaRow(int row);
void CutaRow(int row);
void CopyaRow(int row);
void PasteaRow(int row);
void CopyaCol(int col);
void PasteaCol(int col);
void UpdateOps(char FileName[]);
void UpdatePrev(void);
void SaveCSVFile(void);
void SelectCases(void);
void ChangeSeparator(void);
void RowColSwap(void);
void GridSort(void);
void PrintDict(void);
void FormatCells(void);
void FmtCell(int row, int col);
void OpenOS4(void);
void SaveOS4(void);
void OpenEpiDataFile(char FileName[]);
void LoadMatrix(void);
bool LabelOK(AnsiString label);
bool StringsToInt(int strcol, int newcol, bool prompt);
int GetValue(int row, int var, int &intvalue, double &dblvalue, AnsiString &strvalue);
int VarTypeChk(int var, int wanted);


