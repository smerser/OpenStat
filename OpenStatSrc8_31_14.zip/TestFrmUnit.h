//---------------------------------------------------------------------------
#ifndef TestFrmUnitH
#define TestFrmUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTestFrm : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TLabel *Label1;
    TEdit *AnswerEdit;
    TLabel *Label2;
    TEdit *CorrEdit;
    TLabel *Label3;
    TEdit *ScoreEdit;
    TButton *ContBtn;
    TButton *ShowBtn;
    void __fastcall ContBtnClick(TObject *Sender);
    void __fastcall AnswerEditKeyPress(TObject *Sender, char &Key);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ShowBtnClick(TObject *Sender);
    
    void __fastcall FormActivate(TObject *Sender);
private:	// User declarations
    int corchoice;
    char Stem[30][81];
    char Foil[10][10][81];
    int stemlines;
    int nochoices;
    int foillines[10];
    int correctno;

public:		// User declarations
    int itemno;
    int TotalScore;
    int itemtype;
    char BMPFile[81];
    char answer[21];
    __fastcall TTestFrm(TComponent* Owner);
    void __fastcall ShowItem(void);

};
//---------------------------------------------------------------------------
extern PACKAGE TTestFrm *TestFrm;
//---------------------------------------------------------------------------
#endif
