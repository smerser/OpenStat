//---------------------------------------------------------------------------

#ifndef PartialUnitH
#define PartialUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmPartial : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
     TListBox *VarList;
    TLabel *Label2;
    TListBox *Predictors;
    TSpeedButton *PredInBtn;
    TSpeedButton *PredOutBtn;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *Return;
    TLabel *Label3;
    TEdit *DepEdit;
    TSpeedButton *DepInBtn;
    TSpeedButton *CntrlInBtn;
    TSpeedButton *CntrlOutBtn;
    TListBox *Partialled;
    TLabel *Label4;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall DepInBtnClick(TObject *Sender);
    void __fastcall PredInBtnClick(TObject *Sender);
    void __fastcall CntrlInBtnClick(TObject *Sender);
    void __fastcall PredOutBtnClick(TObject *Sender);
    void __fastcall CntrlOutBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ReturnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmPartial(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmPartial *FrmPartial;
//---------------------------------------------------------------------------
#endif
