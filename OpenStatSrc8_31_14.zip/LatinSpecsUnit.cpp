//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "LatinSpecsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLatinSpecsFrm *LatinSpecsFrm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TLatinSpecsFrm::TLatinSpecsFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::FormShow(TObject *Sender)
{
     for (int i = 1; i <= NoVariables; i++)
         VarList->Items->Add(MainForm->Grid->Cells[i][0]);

     NPerCellEdit->Text = "0";

}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::AinBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     ACodeEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     AinBtn->Visible = false;
     AoutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::BinBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     BCodeEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     BinBtn->Visible = false;
     BoutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::CinBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     CCodeEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     CinBtn->Visible = false;
     CoutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::DinBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     DCodeEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DinBtn->Visible = false;
     DoutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::GrpInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     GroupCodeEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     GrpInBtn->Visible = false;
     GrpOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::DataInBtnClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (index < 0) return;
     DepVarEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DataInBtn->Visible = false;
     DataOutBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::AoutBtnClick(TObject *Sender)
{
     if (ACodeEdit->Text == "") return;
     VarList->Items->Add(ACodeEdit->Text);
     ACodeEdit->Text = "";
     AoutBtn->Visible = false;
     AinBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::BoutBtnClick(TObject *Sender)
{
     if (BCodeEdit->Text == "") return;
     VarList->Items->Add(BCodeEdit->Text);
     BCodeEdit->Text = "";
     BoutBtn->Visible = false;
     BinBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::CoutBtnClick(TObject *Sender)
{
     if (CCodeEdit->Text == "") return;
     VarList->Items->Add(CCodeEdit->Text);
     CCodeEdit->Text = "";
     CoutBtn->Visible = false;
     CinBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::DoutBtnClick(TObject *Sender)
{
     if (DCodeEdit->Text == "") return;
     VarList->Items->Add(DCodeEdit->Text);
     DCodeEdit->Text = "";
     DoutBtn->Visible = false;
     DinBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::GrpOutBtnClick(TObject *Sender)
{
     if (GroupCodeEdit->Text == "") return;
     VarList->Items->Add(GroupCodeEdit->Text);
     GroupCodeEdit->Text = "";
     GrpOutBtn->Visible = false;
     GrpInBtn->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TLatinSpecsFrm::DataOutBtnClick(TObject *Sender)
{
     if (DepVarEdit->Text == "") return;
     VarList->Items->Add(DepVarEdit->Text);
     DepVarEdit->Text = "";
     DataOutBtn->Visible = false;
     DataInBtn->Visible = true;
}
//---------------------------------------------------------------------------

