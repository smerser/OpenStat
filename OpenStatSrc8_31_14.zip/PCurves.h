//---------------------------------------------------------------------------
#ifndef PCurvesH
#define PCurvesH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TPowCurvs : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *TxtMean;
    TLabel *Label2;
    TEdit *TxtStdDev;
    TLabel *Label3;
    TEdit *TxtSize;
    TGroupBox *GroupBox1;
    TCheckBox *Chk01;
    TCheckBox *Chk025;
    TCheckBox *Chk05;
    TCheckBox *Chk075;
    TCheckBox *Chk10;
    TCheckBox *Chk20;
    TButton *BtnCancel;
    TButton *BtnOK;
    void __fastcall BtnCancelClick(TObject *Sender);
    void __fastcall BtnOKClick(TObject *Sender);
    void __fastcall TxtMeanPress(TObject *Sender, char &Key);
    void __fastcall TxtSDPress(TObject *Sender, char &Key);
    void __fastcall TxtSizePress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
    __fastcall TPowCurvs(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPowCurvs *PowCurvs;
//---------------------------------------------------------------------------
#endif
