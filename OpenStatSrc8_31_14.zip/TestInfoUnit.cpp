//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "TestInfoUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTestInfoFrm *TestInfoFrm;
//---------------------------------------------------------------------------
__fastcall TTestInfoFrm::TTestInfoFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
