//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NetPresentValueUnit.h"
#include "MainUnit.h"
#include "Math.hpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TNetPresentValueFrm *NetPresentValueFrm;
//---------------------------------------------------------------------------
__fastcall TNetPresentValueFrm::TNetPresentValueFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TNetPresentValueFrm::FormShow(TObject *Sender)
{
     ROREdit->Text = "";
     RateEdit->Text = "";
     FileNameEdit->Text = MainForm->FileNameEdit->Text;
     SizeEdit->Text = MainForm->Grid->RowCount - 1;
}
//---------------------------------------------------------------------------
void __fastcall TNetPresentValueFrm::ComputeBtnClick(TObject *Sender)
{
     Extended ROReturn, Rate;
     int size, Time;
     double *CashFlows;
     TPaymentTime PaymentTime;

     if (FileNameEdit->Text == "")
     {
        ShowMessage("You must first open a cash flow file in the main form!");
        return;
     }

     if (SizeEdit->Text == "")
     {
        ShowMessage("Your file does not contain any row entries in column 1.");
        return;
     }
     else size = StrToInt(SizeEdit->Text);

     if (RateEdit->Text == "")
     {
        ShowMessage("You must enter an interest rate, e.g. 0.05 (5 percent).");
        return;
     }
     else Rate = StrToFloat(RateEdit->Text);

     Time = RadioGroup1->ItemIndex;
     if (Time == 0) PaymentTime = ptStartOfPeriod;
     else PaymentTime = ptEndOfPeriod;

     CashFlows = new double[size];
     for (int i = 0; i < size; i++) CashFlows[i] = StrToFloat(MainForm->Grid->Cells[1][i+1]);

     ROReturn = NetPresentValue(Rate, CashFlows, size, PaymentTime);
     ROREdit->Text = FloatToStr(ROReturn);
     delete[] CashFlows;     
}
//---------------------------------------------------------------------------
