//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "RateOfReturnUnit.h"
#include "MainUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRateReturnFrm *RateReturnFrm;
//---------------------------------------------------------------------------
__fastcall TRateReturnFrm::TRateReturnFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TRateReturnFrm::FormShow(TObject *Sender)
{
     GuessEdit->Text = "";
     ROREdit->Text = "";
     FileNameEdit->Text = MainForm->FileNameEdit->Text;
     SizeEdit->Text = MainForm->Grid->RowCount - 1;
}
//---------------------------------------------------------------------------
void __fastcall TRateReturnFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Guess, ROReturn;
     int size;
     double *CashFlows;

     if (GuessEdit->Text == "")
     {
        ShowMessage("Please enter a guess for the rate of return!");
        return;
     }
     else Guess = StrToFloat(GuessEdit->Text);

     if (FileNameEdit->Text == "")
     {
        ShowMessage("You must first open a cash flow file in the main form!");
        return;
     }

     if (SizeEdit->Text == "")
     {
        ShowMessage("Your file does not contain any row entries in column 1.");
        return;
     }
     else size = StrToInt(SizeEdit->Text);

     CashFlows = new double[size];
     for (int i = 0; i < size; i++) CashFlows[i] = StrToFloat(MainForm->Grid->Cells[1][i+1]);

     ROReturn = InternalRateOfReturn(Guess, CashFlows, size);
     ROREdit->Text = FloatToStr(ROReturn);
     delete[] CashFlows;
}
//---------------------------------------------------------------------------
