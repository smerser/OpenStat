//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "MemMgrUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "functions.h"
#include "MatrixUnit.h"
#include "math.h"
#include "GraphUnit.h"
#include "LTestUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLTestForm *LTestForm;
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern struct Options ops;
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;
//---------------------------------------------------------------------------
__fastcall TLTestForm::TLTestForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLTestForm::ResetBtnClick(TObject *Sender)
{
     int i;

     VarList->Items->Clear();
     TreatVars->Items->Clear();
     for (i = 1; i <= NoVariables; i++)
          VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     PlotRanksChk->Checked = false;
     TheorRankGrid->RowCount = 10;
     for (i = 0; i < 10; i++)
     {
        TheorRankGrid->Cells[0][i] = IntToStr(i+1);
        TheorRankGrid->Cells[1][i] = "";
     }
}
//---------------------------------------------------------------------------
void __fastcall TLTestForm::TrtInClick(TObject *Sender)
{
     int index, i;

     index = VarList->Items->Count;
     i = 0;
     while (i < index)
     {
         if (VarList->Selected[i])
         {
            TreatVars->Items->Add(VarList->Items->Strings[i]);
            VarList->Items->Delete(i);
            index = index - 1;
            i = 0;
            ntreatments = ntreatments + 1;
            TheorRankGrid->RowCount = ntreatments;
         }
         else i = i + 1;
     }
     TrtOut->Visible = true;
     if (VarList->Items->Count == 0) TrtIn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TLTestForm::TrtOutClick(TObject *Sender)
{
   int index;

   index = TreatVars->ItemIndex;
   if (index < 0)
   {
        TrtOut->Visible = false;
        TrtIn->Visible = true;
        return;
   }
   VarList->Items->Add(TreatVars->Items->Strings[index]);
   TreatVars->Items->Delete(index);
   TrtIn->Visible = true;
   if (ntreatments > 0)
   {
        ntreatments = ntreatments - 1;
        TheorRankGrid->RowCount = ntreatments;
   }
}
//---------------------------------------------------------------------------
void __fastcall TLTestForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
        ntreatments = 0;
}
//---------------------------------------------------------------------------
void __fastcall TLTestForm::ComputeBtnClick(TObject *Sender)
{
        int i, j, N, M;
        double **Data;
        double *RankSums, *TheorY;
        double L, chi, prob;
        char outline[101];
        AnsiString title;
        
        N = NoCases;
        M = ntreatments;
        L = 0.0;
        GetDblMatMem(Data,N,M);
        GetDblVecMem(RankSums,M);
        GetDblVecMem(TheorY,M);

        // Get Data from the grid
        for (i = 1; i <= M; i++)
        {
                for (j = 1; j <= N; j++) Data[j-1][i-1] =
                     StrToFloat(MainForm->Grid->Cells[i][j]);
        }
        for (i = 0; i < M; i++) TheorY[i] = StrToFloat(TheorRankGrid->Cells[1][i]);

        // Obtain statistics
        for (i = 0; i < M; i++) RankSums[i] = 0.0;
        for (i = 0; i < M; i++)
        {
                for (j = 0; j < N; j++) RankSums[i] += Data[j][i];
                L += RankSums[i] * TheorY[i];
        }
        chi = sqr(12.0 * L - (3.0 * M * N * sqr(N + 1))) /
              (M * N * N * (N * N - 1.0) * (N + 1.0));
        prob = (1.0 - chisquaredprob(chi, 1));
//        prob /= 2.0;

        // show results
        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("RESULTS FOR THE L ANALYSIS");
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("SUM OF RANKS FOR EACH TREATMENT:");
        for (i = 0; i < M; i++)
        {
                sprintf(outline,"Treatment %d, Sum of Ranks = %8.3f",i+1,RankSums[i]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        sprintf(outline,"L statistic = %8.3f, chisquare with %d D.F. = %8.3f with probability = %6.4f",
        L, 1, chi, prob);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("The chisquare is one-tailed and approximate.");
        FrmOutPut->RichOutPut->Lines->Add("Consult the L table in the original article for details.");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
        
        // Plot treatment mean ranks if elected
        if (PlotRanksChk->Checked)
        {
                for (i = 0; i < M; i++) RankSums[i] /= (float)N;
                double *XValue;
                int plottype = 3;

                XValue = new double[M];
                title = "AVERAGE RANKS";
                GraphForm->SetLabels[1] = title;
                GetDblMatMem(GraphForm->Xpoints,1,M);
                GetDblMatMem(GraphForm->Ypoints,1,M);
                for (i = 1; i <= M; i++)
                {
                        GraphForm->Ypoints[0][i-1] = RankSums[i-1];
                        XValue[i-1] = i;
                        GraphForm->Xpoints[0][i-1] = XValue[i-1];
                }
                GraphForm->nosets = 1;
                GraphForm->nbars = M;
                GraphForm->Heading = "PLOT OF AVERAGE RANKS";
                GraphForm->XTitle = "VARIABLE";
                GraphForm->YTitle = "MEAN";
                GraphForm->barwideprop = 0.5;
                GraphForm->AutoScale = false;
                GraphForm->miny = 0.0;
                GraphForm->maxy = M+1;
                GraphForm->GraphType = plottype;
                GraphForm->BackColor = clYellow;
                GraphForm->WallColor = clBlack;
                GraphForm->FloorColor = clLtGray;
                GraphForm->ShowBackWall = true;
                GraphForm->ShowModal();
                delete[] XValue;
                ClearDblMatMem(GraphForm->Xpoints,1);
                ClearDblMatMem(GraphForm->Ypoints,1);
        }

        // clear memory
        ClearDblVecMem(TheorY);
        ClearDblVecMem(RankSums);
        ClearDblMatMem(Data,N);
}
//---------------------------------------------------------------------------
