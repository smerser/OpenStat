//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "MainUnit.h"
#include "OutPut.h"
#include "DataFuncs.h"
#include <math.h>
#include <Math.hpp>
#include "MultGenUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMultGenFrm *MultGenFrm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern bool openfile;
//---------------------------------------------------------------------------
__fastcall TMultGenFrm::TMultGenFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMultGenFrm::NVarsEditKeyPress(TObject *Sender, char &Key)
{
    double value;
    char valstring[21];

    if (Key == 13) // return
    {
            NoVars = atoi(NVarsEdit->Text.c_str());
            InstructLabel->Enabled = true;
            InstructLabel->Visible = true;
            ContBtn->Enabled = true;
            ContBtn->Visible = true;
            Grid->ColCount = NoVars+1;
            Grid->RowCount = NoVars+3;
            char label[11];
            for (int i = 0; i < NoVars; i++)
            {
                sprintf(label,"VAR. %d",i+1);
                Grid->Cells[i+1][0] = label;
                Grid->Cells[0][i+1] = label;
            }
            sprintf(label,"MEANS:");
            Grid->Cells[0][NoVars+1] = label;
            sprintf(label,"STD.DEV.s");
            Grid->Cells[0][NoVars+2] = label;
            Grid->Row = 1;
            Grid->Col = 1;
            Grid->SetFocus();
    }
}
//---------------------------------------------------------------------------
void __fastcall TMultGenFrm::CancelBtnClick(TObject *Sender)
{
    MultGenFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMultGenFrm::DoneBtnClick(TObject *Sender)
{
    // Allocate space for variable descriptions and set defined to true
    // after completing the descriptions in the main form.
    for (int i = 0; i < NoVars; i++)
    {
        NewVar(i+1,false);
    }
    NoCases = NoObs;
    NoVariables = NoVars;
    MainForm->NoCasesEdit->Text = NoCases;
    MainForm->NoVarsEdit->Text = NoVariables;
    openfile = true;
    if (MainForm->FileNameEdit->Text == "") MainForm->FileNameEdit->Text = "MultVarData.TEX";
    MultGenFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMultGenFrm::ContBtnClick(TObject *Sender)
{
    ObsNoLabel->Enabled = true;
    ObsNoLabel->Visible = true;
    NoObsEdit->Enabled = true;
    NoObsEdit->Visible = true;
    NoObsEdit->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMultGenFrm::NoObsEditKeyPress(TObject *Sender, char &Key)
{
    if (Key == 13) // enter pressed
    {
        NoObs = atoi(NoObsEdit->Text.c_str());
        // Now, generate the data in the main form grid
        MainForm->Grid->ColCount = NoVars+1;
        MainForm->Grid->RowCount = NoObs+1;
        char label[11];
        char outline[81];
        for (int i = 0; i < NoVars; i++)
        {
            sprintf(label,"VAR. %d",i+1);
            MainForm->Grid->Cells[i+1][0] = label;
        }
        for (int i = 0; i < NoObs; i++)
        {
            sprintf(label,"CASE: %d",i+1);
            MainForm->Grid->Cells[0][i+1] = label;
        }

        // allocate space for work arrays
        try  {
            v = new double[NoVars];
            rmatrix = new double *[NoVars];
            for (int i = 0; i < NoVars; i++) rmatrix[i] = new double[NoVars];
            d = new double *[NoVars];
            for (int i = 0; i < NoVars; i++) d[i] = new double[NoVars];
        }
        catch (...)
        {
            Application->MessageBox("Out of memory in Multivariate Generator",
                "ERROR",MB_OK);
            return;
        }

        for (int i = 0; i < NoVars; i++)
        {
            v[i] = 0.0;
            for (int j = 0; j < NoVars; j++)
            {
                rmatrix[i][j] = atof(Grid->Cells[i+1][j+1].c_str());
                double sd1 = atof(Grid->Cells[i+1][NoVars+2].c_str());
                double sd2 = atof(Grid->Cells[j+1][NoVars+2].c_str());
                d[i][j] = rmatrix[i][j] * (sd1 * sd2); // covariance matrix
            }
        }
        // print the population parameters
        FrmOutPut->RichOutPut->Lines->Clear();
        strcpy(outline, "POPULATION CORRELATION MATRIX, MEANS AND STANDARD DEVIATIONS");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 0; i < NoVars+3; i++) // rows
        {
            strcpy(outline,"");
            for (int j = 0; j < Grid->ColCount; j++)
            {
                sprintf(label,"%10s",Grid->Cells[j][i].c_str());
                strcat(outline,label);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add("");
        // print the covariance matrix d
        strcpy(outline, "POPULATION COVARIANCE MATRIX");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->RichOutPut->Lines->Add("");
        for (int i = 0; i < NoVars; i++) // rows
        {
            strcpy(outline,"");
            for (int j = 0; j < NoVars; j++)
            {
                sprintf(label,"%10.3f",d[i][j]);
                strcat(outline,label);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }

        for (int i = 0; i < NoVars; i++)
            for (int j = 0; j < NoVars; j++) rmatrix[i][j] = d[i][j];

        // check for singularity
        int n2 = 1;
        int i1 = 0;
        while (n2 < NoVars)
        {
            for (int i = n2; i < NoVars; i++)
            {
                double n3 = d[i][i1] / d[i1][i1];
                for (int j = n2; j < NoVars; j++) d[i][j] -= (d[i1][j] * n3);
            }
            i1 = n2;
            n2++;
        }
        double determ = 1.0;
        for (int i = 0; i < NoVars; i++) determ *= d[i][i];
        sprintf(outline,"Determinant of your population matrix = %10.4f",determ);
        FrmOutPut->RichOutPut->Lines->Add("");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        FrmOutPut->ShowModal();

        // triangular factorization
        if (fabs(determ) > 0.00001)
        {
            if (rmatrix[0][0] < 0.0) rmatrix[0][0] = 1.0;
            double r1 = sqrt(rmatrix[0][0]);
            for (int i = 0; i < NoVars; i++)
            {
                d[i][0] = rmatrix[i][0] / r1;
                for (int j = 1; j < NoVars; j++) d[i][j] = 0.0;
            }
            for (int i = 1; i < NoVars; i++)
            {
                double s9 = 0.0;
                int k1 = i - 1;
                for (int k = 0; k < k1; k++) s9 += (d[i][k] * d[i][k]);
                double d2 = rmatrix[i][i] - s9;
                if (d2 > 0.0)
                {
                    d[i][i] = sqrt(d2);
                    for (int j = 1; j < i; j++)
                    {
                        if (j != i)
                        {
                            double s8 = 0.0;
                            k1 = j - 1;
                            for (int k = 0; k < k1; k++) s8 += (d[i][k] * d[j][k]);
                            d[i][j] = (rmatrix[i][j] - s8) / d[j][j];
                        }
                    } // end j loop
                } // end if d2 > 0
            } // end i loop

            // Now generate score vectors
            for (int i2 = 0; i2 < NoObs; i2++) // rows
            {
                for (int i = 0; i < NoVars; i++) v[i] = RandG(0.0,1.0);
                for (int i = 0; i < NoVars; i++)
                {
                    double x = 0.0;
                    for (int j = 0; j <= i; j++) x += (d[i][j] * v[j]);
                    double mean = atof(Grid->Cells[i+1][NoVars+1].c_str());
                    sprintf(label,"%10.3f",x+mean);
                    MainForm->Grid->Cells[i+1][i2+1] = label;
                } // next variable
            }  // next observation
        } // end if determ > 0.00001
        // clean up the heap
        for (int i = 0; i < NoVars; i++) delete[] d[i];
        delete[] d;
        for (int i = 0; i < NoVars; i++) delete[] rmatrix[i];
        delete[] rmatrix;
        delete[] v;
        DoneInstruct->Visible = true;
        DoneInstruct->Enabled = true;
        DoneBtn->Enabled = true;
        DoneBtn->Visible = true;
        DoneBtn->SetFocus();
    } // end if Key = 13
}
//---------------------------------------------------------------------------


void __fastcall TMultGenFrm::GridSetEditText(TObject *Sender, int ACol,
      int ARow, const AnsiString Value)
{
    if (ARow > NoVars) return;
    if (ARow == ACol) return;
    Grid->Cells[ARow][ACol] = Value;
}
//---------------------------------------------------------------------------

void __fastcall TMultGenFrm::FormShow(TObject *Sender)
{
    ContBtn->Visible = false;
    InstructLabel->Visible = false;
    ObsNoLabel->Visible = false;
    NoObsEdit->Text = "";
    NoObsEdit->Visible = false;
    DoneInstruct->Visible = false;
    DoneBtn->Visible = false;
    NVarsEdit->Text = "";
    if (NoVars > 0)
    {
        for (int i = 0; i <= NoVars; i++)
            for (int j = 0; j <= NoVars; j++)
                Grid->Cells[i][j] = "";
    }
    Grid->ColCount = 2;
    Grid->RowCount = 2;
    NoVars = 0;
    NoObs = 0;
    NVarsEdit->SetFocus();
}
//---------------------------------------------------------------------------

