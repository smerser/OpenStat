//---------------------------------------------------------------------------

#ifndef CATROCFormH
#define CATROCFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TCatROCFrm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *ScaleInBtn;
        TBitBtn *ScaleOutBtn;
        TLabel *Label2;
        TEdit *CatVarEdit;
        TBitBtn *NormInBtn;
        TBitBtn *NormOutBtn;
        TBitBtn *PosInBtn;
        TBitBtn *PosOutBtn;
        TLabel *NormLabel;
        TLabel *Label3;
        TEdit *NormVarEdit;
        TEdit *PosVarEdit;
        TMemo *Memo1;
        TButton *CancelBtn;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        void __fastcall check(int iclass, int ncats, double *fpf, double *tpf,
                              int icon, int *iary);
        void __fastcall degen(int iclass, int *iary, double *fpf, double *tpf);
        void __fastcall inifit(int ncats, int negcount, int poscount,
                      double *fpf, double *tpf);
        void __fastcall mslop(int LL, double **XP);
        void __fastcall ZDEV(double P, double QF, double D, int IER);
public:		// User declarations
        __fastcall TCatROCFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TCatROCFrm *CatROCFrm;
//---------------------------------------------------------------------------
#endif