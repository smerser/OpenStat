//---------------------------------------------------------------------------
#ifndef testadmunitH
#define testadmunitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <stdio.h>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TTestAdminFrm : public TForm
{
__published:	// IDE-managed Components
    TOpenDialog *OpenDialog1;
    TButton *OpenBtn;
    TLabel *Label1;
    TEdit *BankNameEdit;
    TLabel *Label2;
    TEdit *MethodEdit;
    TLabel *Label3;
    TEdit *NItemsEdit;
    TLabel *Label4;
    TEdit *NsubsEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *DoneBtn;
    TLabel *Label5;
    TEdit *ScoreEdit;
    void __fastcall OpenBtnClick(TObject *Sender);
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);

    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
    struct header  {
        char bankname[81]; // name of file holding items
        char majorfile[81]; // name of file holding major combo codes
        char minorfile[81]; // name of file holding minor combo codes
        unsigned int NoItems;
        long int ItemStart[500];
    };
    header *hdrptr;
    header bankhdr;

    struct itemdesc  { // fixed elements of each item
        unsigned int ItemNo; // no. of the item in the item bank
        int itemtype;      // MC, TF, matching, word, phrase, essay
        int difftype;      // classical or 1, 2, 3 parameter IRT
        int majorcode;     // major code of the item (user supplied)
        int minorcode;     // minor code of the item (user supplied)
        double mean;       // classical theory item mean
        double difficulty; // 1 to 3 parameter IRT item difficulty parameter
        double slope;      // 2 or 3 IRT parameter of item slope
        double chance;     // 3 parameter IRT chance parameter
        int correctno;     // no. of the correct choice (if any)
        int stemlines;     // no. of text lines for the stem
        int nofoils;       // no. of choices for the item
        int foillines[10]; // no. of lines in each foil (up to 10)
        char BMPfile[81];  // file of bitmap image used in the item
        char Stem[30][81];     // up to 30 lines of memo lines for an item stem
        char Foil[10][10][81]; // up to 10 choices of 10 lines for each choice
    };
    itemdesc *descptr;     // pointer to one items fixed elements
    itemdesc fixeditem;    // one item's fixed elements
    FILE *hdrfileptr;      // handle to index file for the item bank
    FILE *bankfileptr;     // handle to item bank definition file
    FILE *majorptr;        // handle to associated major codes combo box
    FILE *minorptr;        // handle to associated minor codes combo box
    FILE *prmfileptr;      // pointer to test administration parameter file
    char filename[81];     // basic name of the item bank header
    char bankname[81];     // name of the header plus .ITM
    char majorfile[81];    // name of the header plus .MAJ
    char minorfile[81];    // name of the header plus .MIN
    int selected[500];
    bool fileopen;
    int itemno;
    int NoItems;
    struct testparms  {
        char bankfilename[81]; // name of item bank header file.
        char itemfilename[81]; // name of file with items in it.
        int AdminOpt;          // Mode of administration (CRT or print)
        int noselected;        // No of items to administer
        int selected[500];     // numbers of items to administer from item bank
        int Ntests;            // no. of subjects to administer the test
        char IDs[100][21];     // subject ID's for test administration
    };
    testparms *parmsptr;
    testparms parms;
    char parmfile[81];
    bool answered;
    void __fastcall getitem(int ino);

public:		// User declarations
    int NoFoils;
    char Stem[30][81];     // up to 30 lines of memo lines for an item stem
    char Foil[10][10][81]; // up to 10 choices of 10 lines for each choice
    int stemlines;         // number of lines in an item stem
    int foillines[10];     // number of lines in an item choice
    int corchoice;         // correct item choice for testfrm
    int TotalScore;        // test subject's total score from testfrm
    int itemtype;          // current item type to transport to testfrm
    char BMPfile[81];      // bitmap file name for transportation to testfrm
    __fastcall TTestAdminFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestAdminFrm *TestAdminFrm;
//---------------------------------------------------------------------------
#endif
