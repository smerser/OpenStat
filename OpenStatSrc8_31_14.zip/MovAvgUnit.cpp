//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "MovAvgUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMoveAvgFrm *MoveAvgFrm;
//---------------------------------------------------------------------------
__fastcall TMoveAvgFrm::TMoveAvgFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::FormShow(TObject *Sender)
{
    OrderEdit->Text = "0";
    ThetaEdit->Text = "";
    ThetaList->Clear();
    currenttheta = -1;
    order = 0;
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::CancelBtnClick(TObject *Sender)
{
    MoveAvgFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::OKBtnClick(TObject *Sender)
{
//    ApplyClick(this);
    MoveAvgFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::OrderEditChange(TObject *Sender)
{
    AnsiString cellstring;
    char value[11];

    ThetaList->Clear();
    order = atoi(OrderEdit->Text.c_str());
    if (order < 1) return;
    for (int i = 0; i <= order; i++)
    {
        cellstring = "Theta(";
        cellstring = cellstring + i;
        cellstring = cellstring + ") = 0.0000";
        ThetaList->Items->Add(cellstring);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::ThetaListClick(TObject *Sender)
{
    int itemindex;
    AnsiString cellstring;

    itemindex = ThetaList->ItemIndex;
    if (itemindex < 0) return;
    cellstring = "Theta(";
    cellstring = cellstring + itemindex;
    cellstring = cellstring + "):";
    ThetaLabel->Caption = cellstring;
    ThetaEdit->Text = 0.0;
    ThetaEdit->SetFocus();
    currenttheta = itemindex;
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::ThetaEditKeyPress(TObject *Sender, char &Key)
{
    AnsiString cellstring;
    char value[11];

    if (Key != 13) return;
    if (currenttheta >= 0) // index of theta value edited
    {
        W[currenttheta] = atof(ThetaEdit->Text.c_str());
        cellstring = "Theta(";
        cellstring = cellstring + currenttheta;
        cellstring = cellstring + ") = ";
        sprintf(value,"%6.4f",W[currenttheta]);
        cellstring = cellstring + value;
        ThetaList->Items->Strings[currenttheta] = cellstring;
    }
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::ApplyClick(TObject *Sender)
{
    double totalw;
    AnsiString cellstring;
    char value[11];

    totalw = W[0];
    for (int i = 1; i <= order; i++) totalw += (2 *W[i]);
    ThetaList->Clear();
    for (int i = 0; i <= order; i++)
    {
        W[i] /= totalw;
        cellstring = "Theta(";
        cellstring = cellstring + i;
        cellstring = cellstring + ") = ";
        sprintf(value,"%6.4f",W[i]);
        cellstring = cellstring + value;
        ThetaList->Items->Add(cellstring);
    }
}
//---------------------------------------------------------------------------
void __fastcall TMoveAvgFrm::ThetaEditExit(TObject *Sender)
{
    AnsiString cellstring;
    char value[11];

    if (currenttheta >= 0) // index of theta value edited
    {
        W[currenttheta] = atof(ThetaEdit->Text.c_str());
        cellstring = "Theta(";
        cellstring = cellstring + currenttheta;
        cellstring = cellstring + ") = ";
        sprintf(value,"%6.4f",W[currenttheta]);
        cellstring = cellstring + value;
        ThetaList->Items->Strings[currenttheta] = cellstring;
    }
}
//---------------------------------------------------------------------------


