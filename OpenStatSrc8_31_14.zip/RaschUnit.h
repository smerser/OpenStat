//---------------------------------------------------------------------------

#ifndef RaschUnitH
#define RaschUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TRaschForm : public TForm
{
__published:	// IDE-managed Components
     TLabel *Label1;
     TLabel *Label2;
     TListBox *VarList;
     TListBox *SelList;
     TBitBtn *VarInBtn;
     TBitBtn *VarOutBtn;
     TButton *BtnAll;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *OKBtn;
     TMemo *Memo1;
     TGroupBox *GroupBox1;
     TCheckBox *ProxChk;
     TCheckBox *PlotItemDifChk;
     TCheckBox *PlotLogAbilityChk;
     TCheckBox *PlotItemInfoChk;
     TCheckBox *PlotTestInfoChk;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall VarInBtnClick(TObject *Sender);
     void __fastcall VarOutBtnClick(TObject *Sender);
     void __fastcall BtnAllClick(TObject *Sender);
     void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TRaschForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRaschForm *RaschForm;
//---------------------------------------------------------------------------
#endif
