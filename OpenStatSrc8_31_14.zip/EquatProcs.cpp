#include "MainUnit.h"
#include <stdio.h>
#include "math.h"
#include "math.hpp"
#include "EquatProcs.h"
extern char FileName[81];
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;

void SubParms(char oldstring[], int NParms, char Parms[], double Parmvalues[])
{
	char tempstr[101];
   char valuestr[21];
   bool done = false;
   bool found;
   int k, count = 0;

   while (!done)
   {
   	for (unsigned int i = 0; i < strlen(oldstring); i++)
      {
         found = false;
      	for (int j = 0; j < NParms; j++)
         {
            if (oldstring[i] != Parms[j]) continue;
            found = true;
            k = j;
         }
         if (!found)
         {
         	tempstr[count] = oldstring[i];
         	count++;
         }
         else // substitute value in the string
         {
            sprintf(valuestr,"%10.6f",Parmvalues[k]);
            for (unsigned int j = 0; j < strlen(valuestr); j++)
            {
            	tempstr[count] = valuestr[j];
               count++;
            }
         }
      } // next i
      tempstr[count] = 0; // terminate string
      strcpy(oldstring,tempstr);
      done = true;
   }
}
//---------------------------------------------------------------------

void SubVars(char oldstring[], int NVars, char Vars[8][3], double Xvalues[])
{
   char tempstr[101];
   char valuestr[21];
   char varstr[3];
   char teststr[3];
   bool done = false;
   bool found;
   int k, count = 0;

   while (!done)
   {
   	for (unsigned int i = 0; i < strlen(oldstring); i++)
      {
         found = false;
      	for (int j = 0; j < NVars; j++)
         {
            sprintf(varstr,"x%1d",j+1);
            teststr[0] = oldstring[i];
            teststr[1] = oldstring[i+1];
            teststr[2] = 0; // terminal null
			if (strcmp(varstr,teststr) != 0) continue;
            found = true;
            k = j;
         }
         if (!found)
         {
         	tempstr[count] = oldstring[i];
         	count++;
         }
         else // substitute value in the string
         {
            sprintf(valuestr,"%10.6f",Xvalues[k]);
            for (unsigned int j = 0; j < strlen(valuestr); j++)
            {
            	tempstr[count] = valuestr[j];
               count++;
            }
         }
      } // next i
      tempstr[count] = 0; // terminate string
      strcpy(oldstring,tempstr);
      done = true;
   }
}
//---------------------------------------------------------------------

double eval(char OpsString[], int NParms, int NVars,
                     double ParmValues[], double Xvalues[])
{
	// Routine to evaluate an expression consisting of values obtained
   // from parameters a-h and values in x1 - x8 as well as numbers,
   // functions and operations.

   char NewString[101];
   char SubString[101];
   double value;
   char Operation;
   int leftparen, rightparen, funcno, length, position;
   bool parfound, opfound;

   // First, remove all blanks
   BlanksOut(OpsString);

   // Next, replace parameters and x values and remove excess blanks
   PutValues(OpsString, NVars, NParms, ParmValues, Xvalues);
   BlanksOut(OpsString);

   // Next, look for first left and right parentheses, if any
again:
   GetParens(OpsString,leftparen,rightparen);
   if ((leftparen > 0) && (rightparen > 0)) parfound = true;
   else parfound = false;

   if (parfound)
   {
   	// now evaluate the expression within parentheses (it may be a compound
   	// expression!)
   	int j = 0; // get the substring to evaluate
   	for (int i = leftparen + 1; i < rightparen; i++)
   	{
      	SubString[j] = OpsString[i];
      	j++;
   	}
   	SubString[j] = 0;

   	MultDiv(SubString, position, Operation);
   	PlusMinus(SubString, position, Operation);
   	// and replace the original substring with the revised one
   	StringSub(OpsString,SubString,leftparen+1,rightparen-1);
   }
   // Next, check for a function to the left of the left parenthesis.
   // If there, evaluate it.
   if (parfound)
   {
   	funcno = GetFunction(OpsString, leftparen, length);
      if (funcno >= 0) // replace function with the value obtained
      {
         CopyFuncValue(OpsString,leftparen,rightparen,funcno,value,length);
      }
   }
   if ((funcno < 0) && (parfound)) // remove parentheses (no function)
   {
   	GetParens(OpsString,leftparen,rightparen); // get location of the parens
   	StringSub(OpsString,"",leftparen,leftparen);
   	StringSub(OpsString,"",rightparen-1,rightparen-1);
   }
   if (parfound) goto again;

   // Now, evaluate the whole expression for / or * or ^ operations
   //multdiv:
   MultDiv(OpsString,position,Operation);
/*
   opfound = FindDivTimes(OpsString, position, Operation);
   if (opfound) // do the operation with values to left and right of the operation
   {
   	DoOperation(OpsString,position,Operation);
   }
   if (opfound) goto multdiv; // check for * or / again
*/
   // And evaluate the whole expression for + or = operations
   //plusminus:
   PlusMinus(OpsString,position,Operation);
/*
	opfound = FindPlusMinus(OpsString, position, Operation);
   if (opfound)
   {
   	// check to see if a value is a sign instead of operation between values
      // if it is, ignore it.
      if (position > 1) // not a leading - or +.  Do the operation
      {
      	DoOperation(OpsString,position,Operation);
      }
   }
   if (opfound) goto plusminus;
*/
   if (parfound) goto again;
   value = atof(OpsString);
   return (value);
}
//---------------------------------------------------------------------

void BlanksOut(char SubString[])
{
   int j=0;
   char tempstr[101];

   for (unsigned int i = 0; i < strlen(SubString); i++)
   {
   	if (SubString[i] != ' ')
      {
      	tempstr[j] = SubString[i];
         j++;
      }
   }
   tempstr[j] = 0; // terminate string
   strcpy(SubString,tempstr);
}
//---------------------------------------------------------------------

void GetParens(char OpsString[], int &leftparen, int &rightparen)
{
   int right = 0;
   int left = 0;
   for (unsigned int i = 0; i < strlen(OpsString); i++)
   {
   	if (OpsString[i] == ')')
      {
      	right = i;
         break;
      }
   }
   for (unsigned int i = right; i > 0; i--)
   {
   	if (OpsString[i] == '(')
      {
      	left = i;
         break;
      }
   }
   leftparen = left;
   rightparen = right;
}
//---------------------------------------------------------------------

int GetFunction(char OpsString[],int leftparen, int &length)
{
	int funcfound = -1;
   char Functions[16][5] = {"sin","cos","tan","asin","acos","atan","ln","log",
        "sinh","cosh","tanh","asinh","acosh","atanh","sqr","sqrt"};
   char funcstr[6];

   if (leftparen > 2) // check for 2 character functions
   {
      funcstr[0] = OpsString[leftparen-2];
      funcstr[1] = OpsString[leftparen-1];
      funcstr[2] = 0;
      if (strcmp(funcstr,Functions[6]) == 0) // match to ln() function
      {
         funcfound = 6;
         length = 2;
      }
   }
   if (leftparen > 3) // check for 3 character functions
   {
   	funcstr[0] = OpsString[leftparen-3];
      funcstr[1] = OpsString[leftparen-2];
      funcstr[2] = OpsString[leftparen-1];
      funcstr[3] = 0;
      if (strcmp(funcstr,Functions[0]) == 0) // match to sin
      {
         length = 3;
         funcfound = 0;
      }
      if (strcmp(funcstr,Functions[1]) == 0) // match to cos
      {
         funcfound = 1;
         length = 3;
      }
      if (strcmp(funcstr,Functions[2]) == 0) // match to tan
      {
         funcfound = 2;
         length = 3;
      }
      if (strcmp(funcstr,Functions[7]) == 0) // match to log
      {
         funcfound = 7;
         length = 3;
      }
      if (strcmp(funcstr,Functions[14]) == 0) // match to sqr
      {
         funcfound = 14;
         length = 3;
      }
   }

	if (leftparen > 4) // check for 4 character functions
   {
   	funcstr[0] = OpsString[leftparen-4];
      funcstr[1] = OpsString[leftparen-3];
      funcstr[2] = OpsString[leftparen-2];
      funcstr[3] = OpsString[leftparen-1];
      funcstr[4] = 0;
      if (strcmp(funcstr,Functions[3]) == 0) // match to asin
      {
         funcfound = 3;
         length = 4;
      }
      if (strcmp(funcstr,Functions[4]) == 0) // match to acos
      {
         funcfound = 4;
         length = 4;
      }
      if (strcmp(funcstr,Functions[5]) == 0) // match to atan
      {
         funcfound = 5;
         length = 4;
      }
      if (strcmp(funcstr,Functions[8]) == 0) // match to sinh
      {
         funcfound = 8;
         length = 4;
      }
      if (strcmp(funcstr,Functions[9]) == 0) // match to cosh
      {
         funcfound = 9;
         length = 4;
      }
      if (strcmp(funcstr,Functions[10]) == 0) // match to tanh
      {
         funcfound = 10;
         length = 4;
      }
      if (strcmp(funcstr,Functions[15]) == 0) // match to sqrt
      {
         funcfound = 15;
         length = 4;
      }
   }

   if (leftparen > 5) // check for 5 character functions
   {
   	  funcstr[0] = OpsString[leftparen-5];
      funcstr[1] = OpsString[leftparen-4];
      funcstr[2] = OpsString[leftparen-3];
      funcstr[3] = OpsString[leftparen-2];
      funcstr[4] = OpsString[leftparen-1];
      funcstr[5] = 0;
      if (strcmp(funcstr,Functions[11]) == 0) // match to asinh
      {
         funcfound = 11;
         length = 5;
      }
      if (strcmp(funcstr,Functions[12]) == 0) // match to atanh
      {
         funcfound = 12;
         length = 5;
      }
      if (strcmp(funcstr,Functions[13]) == 0) // match to acosh
      {
         funcfound = 13;
         length = 5;
      }
   }
   return (funcfound);
}
//---------------------------------------------------------------------

void PutValues(char OpsString[], int NVars, int NParms, double ParmValues[],
               double Xvalues[])
{
   char Parms[8] = {'a','b','c','d','e','f','g','h'};
   char Vars[8][3] = {"x1","x2","x3","x4","x5","x6","x7","x8"};

   // substitute values of parameters, if any in the parsestr
   SubParms(OpsString,NParms,Parms,ParmValues);

   // substitute values of variables, if any in the parsestr
   SubVars(OpsString,NVars,Vars,Xvalues);

}
//---------------------------------------------------------------------

void CopyFuncValue(char SubString[], int leftparen, int rightparen,
                   int funcno, double value, int length)
{
   char newstring[101];
   char valstring[21];
   int stopat, i, j;

   // get value within the parentheses
   j = 0;
   for (i = leftparen+1; i < rightparen; i++)
   {
   	valstring[j] = SubString[i];
      j++;
   }
   valstring[j] = 0; // terminate
   value = atof(valstring);
//   char Functions[16][5] = {"sin","cos","tan","asin","acos","atan","ln","log",
//        "sinh","cosh","tanh","asinh","acosh","atanh","sqr","sqrt"};

   switch (funcno)
   {
      case 0: value = sin(value); break;
   	case 1: value = cos(value); break;
      case 2: value = tan(value); break;
      case 3: value = asin(value); break;
      case 4: value = acos(value); break;
      case 5: value = atan(value); break;
      case 6: value = log(value); break;
      case 7: value = log10(value); break;
      case 8: value = sinh(value); break;
      case 9: value = cosh(value); break;
      case 10: value = tanh(value); break;
      case 11: value = asinh(value); break;
      case 12: value = acosh(value); break;
      case 13: value = atanh(value); break;
      case 14: value = value * value; break;
      case 15: value = sqrt(value); break;
   } // end switch

	// copy up to the leftparen minus the function length
   strcpy(newstring,"");
   stopat = leftparen - length;
   for (i = 0; i < stopat; i++) newstring[i] = SubString[i];
   newstring[i] = 0; // terminate first part
   sprintf(valstring,"%10.6f",value);
   strcat(newstring,valstring);
   int endpt = strlen(newstring);
   j = endpt;
   for (unsigned int i = rightparen+1; i < strlen(SubString); i++)
   {
   	newstring[j] = SubString[i];
      j++;
   }
   newstring[j] = 0;
   strcpy(SubString,newstring);
   BlanksOut(SubString);
}
//---------------------------------------------------------------------

bool FindDivTimes(char SubString[], int &position, char &Operation)
{
	for (unsigned int i = 0; i < strlen(SubString); i++)
   {
   	if (SubString[i] == '/')
      {
      	Operation = '/';
         position = i;
         return (true);
      }
      if (SubString[i] == '*')
      {
      	Operation = '*';
         position = i;
         return (true);
      }
      if (SubString[i] == '^')
      {
      	Operation = '^';
         position = i;
         return (true);
      }
   }
   return (false);
}
//---------------------------------------------------------------------

bool FindPlusMinus(char SubString[], int &position, char &Operation)
{
	for (unsigned int i = 0; i < strlen(SubString); i++)
   {
   	if (SubString[i] == '+')
      {
      	Operation = '+';
         position = i;
         return (true);
      }
      if (SubString[i] == '-')
      {
      	Operation = '-';
         position = i;
         if (i != 0) return (true); // leading - sign
      }
   }
   return (false);
}
//---------------------------------------------------------------------

void DoOperation(char SubString[], int position, char Operation)
{
   double value;
   char valstring[21];  // resulting string
	char leftvalstring[21]; // left operand string
   char rightvalstring[21]; // right operand string
   char newstring[101]; // temporary new OpsString
   int valstart = position-1; // start of left operand string
   int valend; // end of right operand string
   int j;

	// Get value to left of the operation
   for (int i = position-1; i >= 0; i--) // search from position backward
   {
      if (SubString[i] == '+') break;
      if ((SubString[i] == '*') || (SubString[i] == '/') || (SubString[i] == '^'))
          break;
   	if (( isdigit(SubString[i])) || (SubString[i] == '-') ||
          (SubString[i] == '.')) valstart = i;
   }
   if (valstart == position - 1) ShowMessage("ERROR! No left operand found!");
   else
   {
      j = 0;
   	for (int i = valstart; i < position; i++)
      {
      	leftvalstring[j] = SubString[i];
         j++;
      }
      leftvalstring[j] = 0; // terminate
   }

   // Get value to the right of the operation
   valend = position+1;
   for (unsigned int i = position+1; i < strlen(SubString); i++)
   {
      if ((SubString[i] == '+')||(SubString[i] == '*') ||
          (SubString[i] == '/') || (SubString[i] == '^')) break;
   	if (( isdigit(SubString[i])) || (SubString[i] == '-') ||
          (SubString[i] == '.')) valend = i;
   }
   if (valend == position+1) ShowMessage("ERROR! No right operand found.");
   else
   {
      j = 0;
      for (int i = position+1; i <= valend; i++)
      {
      	rightvalstring[j] = SubString[i];
         j++;
      }
      rightvalstring[j] = 0; // terminate string
   }

   // Now, do the operation
   if (Operation == '*') value = atof(leftvalstring) * atof(rightvalstring);
   if (Operation == '/') value = atof(leftvalstring) / atof(rightvalstring);
   if (Operation == '+') value = atof(leftvalstring) + atof(rightvalstring);
   if (Operation == '-') value = atof(leftvalstring) - atof(rightvalstring);
   if (Operation == '^') value = pow(atof(leftvalstring),atof(rightvalstring));

   // Replace operands and Operation with resulting value
	sprintf(valstring,"%10.6f",value);
   j = 0;
   // copy up to the beginning of the left operand string
   for (int i = 0; i < valstart; i++)
   {
   	newstring[j] = SubString[i];
      j++;
   }
   newstring[j] = 0; // terminate first part
   // add the replacement value
   strcat(newstring,valstring);
   // copy rest of string from end of right operand string
   j = strlen(newstring);
   for (unsigned int i = valend+1; i < strlen(SubString); i++)
   {
   	newstring[j] = SubString[i];
      j++;
   }
   newstring[j] = 0; // terminate string
   strcpy(SubString,newstring);
   BlanksOut(SubString);
}
//---------------------------------------------------------------------

double asinh(double x) { return log(x + sqrt(x * x + 1)); }
//-------------------------------------------------------------------------------------

double acosh(double x) { return log(x + sqrt(x * x - 1)); }
//-------------------------------------------------------------------------------------

double atanh(double x) { return 0.5 * log((1 + x) / (1 - x)); }
//-------------------------------------------------------------------------------------

double acoth(double x) { return 0.5 * log((x + 1) / (x - 1)); }
//-------------------------------------------------------------------------------------

void StringSub(char SubString[], char tempstr[],int frompos, int topos)
{
   // This procedure replaces the string section in SubString (from frompos
   // to topos) with the tempstr;
	char newstr[101];
   int j = 0;

   for (int i = 0; i < frompos; i++)
   {
   	newstr[j] = SubString[i];
      j++;
   }
   newstr[j] = 0; // terminate string
   strcat(newstr,tempstr);
   j = strlen(newstr);
   for (unsigned int i = topos+1; i < strlen(SubString); i++)
   {
   	newstr[j] = SubString[i];
      j++;
   }
   newstr[j] = 0;
   strcpy(SubString,newstr);
}
//---------------------------------------------------------------------

void MultDiv(char SubString[], int &position, char &Operation)
{
	bool opfound;
again:
   opfound = FindDivTimes(SubString, position, Operation);
   if (opfound) // do the operation with values to left and right of the operation
   {
   	DoOperation(SubString,position,Operation);
   }
   if (opfound) goto again; // check for * or / again
}
//---------------------------------------------------------------------

void PlusMinus(char SubString[], int &position, char &Operation)
{
	bool opfound;
again:
	opfound = FindPlusMinus(SubString, position, Operation);
   if (opfound)
   {
   	// check to see if a value is a sign instead of operation between values
      // if it is, ignore it.
      if (position > 1) // not a leading - or +.  Do the operation
      {
      	DoOperation(SubString,position,Operation);
      }
   }
   if (opfound) goto again;
}

