//---------------------------------------------------------------------------

#ifndef PolyFitUnitH
#define PolyFitUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TPolyRegFitFrm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TLabel *Label1;
    TEdit *OrderEdit;
    TButton *CancelBtn;
    TButton *OKBtn;
private:	// User declarations
public:		// User declarations
    __fastcall TPolyRegFitFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPolyRegFitFrm *PolyRegFitFrm;
//---------------------------------------------------------------------------
#endif
