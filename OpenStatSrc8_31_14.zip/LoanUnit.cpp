//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LoanUnit.h"
#include "OutPut.h"
#include "stdio.h"
#include "math.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLoanForm *LoanForm;
//---------------------------------------------------------------------------
__fastcall TLoanForm::TLoanForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLoanForm::ResetBtnClick(TObject *Sender)
{
     NameEdit->Text = "";
     MonthEdit->Text = "";
     DayEdit->Text = "";
     YearEdit->Text = "";
     AmountEdit->Text = "";
     InterestEdit->Text = "";
     PayPerYrEdit->Text = "";
     RepayEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TLoanForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TLoanForm::ComputeBtnClick(TObject *Sender)
{
   int no_per_year, year_payed, month_payed, day, month;
   double fraction, interest, numerator, denominator, payment, total_interest;
   double amount, interest_payment, total_payed, pcnt_interest, years, no_years;
   AnsiString name, astring;
   char outline[121];

   name = NameEdit->Text;
   no_per_year = StrToInt(PayPerYrEdit->Text);
   day = StrToInt(DayEdit->Text);
   month = StrToInt(MonthEdit->Text);
   years = StrToFloat(YearEdit->Text);
   amount = StrToFloat(AmountEdit->Text);
   no_years = StrToFloat(RepayEdit->Text);
   pcnt_interest = StrToFloat(InterestEdit->Text);
   FrmOutPut->RichOutPut->Clear();

   if (no_per_year < 12)
      fraction = 12.0 / (double) no_per_year;
   else fraction = 1.0;
   FrmOutPut->RichOutPut->Lines->Add("Payment Schedule Program by W. G. Miller");
   FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------------");
   FrmOutPut->RichOutPut->Lines->Add("");
   astring = "Name of Borrower : ";
   astring = astring + name;
   FrmOutPut->RichOutPut->Lines->Add(astring);
   sprintf(outline,"Amount borrowed = $%12.2f at %5.2f percent over %2.1f years.",
           amount,pcnt_interest,no_years);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   interest = pcnt_interest / 100.0;
   numerator = interest * amount / (double) no_per_year ;
   denominator = 1.0 - (1.0 / pow((interest / (double) no_per_year + 1.0),
                            ((double)no_per_year * no_years) ) );
   payment = numerator / denominator;
   total_interest = 0.0;
   total_payed = 0.0;
   for (int j = 1; j <=no_years; j++)
   {
       Heading();
       for (int k = 1; k <= no_per_year; k++)
       {
          year_payed = ceil(years) + j - 1 ;
          month_payed = ceil((double)k * fraction + (double)month - fraction);
          if (month_payed > 12)
          {
             year_payed = year_payed + 1;
             month_payed = month_payed - 12;
          }
          interest_payment = amount * interest / (double) no_per_year;
          amount = amount - payment + interest_payment;
          total_interest = total_interest + interest_payment;
          total_payed = total_payed + payment;
          sprintf(outline," %2d/%2d/%2d %12.2f %12.2f %12.2f %12.2f %12.2f",
                  month_payed,day,year_payed,payment,interest_payment,
                  amount,total_interest,total_payed);
          FrmOutPut->RichOutPut->Lines->Add(outline);
       }
       FrmOutPut->RichOutPut->Lines->Add("");
   FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------------");
   }
   FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TLoanForm::Heading(void)
{
   FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------------");
   FrmOutPut->RichOutPut->Lines->Add("PAYMENT        PAYMENT      INTEREST      BALANCE      TOTAL           TOTAL");
   FrmOutPut->RichOutPut->Lines->Add("NUMBER         AMOUNT       PAYED         REMAINING    INTEREST        PAID");
   FrmOutPut->RichOutPut->Lines->Add("----------------------------------------------------------------------------");
}
//---------------------------------------------------------------------------
/*
double __fastcall TLoanForm::REALRAISE(double base, double power)
{
     double realraise;

     if (power == 0.0) return (1.0);
     if (power < 0.0) realraise = 1.0 / REALRAISE(base,-power);
     else realraise = exp(power * log(base) );
     return (realraise);
}
*/
