//---------------------------------------------------------------------------

#include <vcl.h>
#include "math.h"
#include "OutPut.h"
#include "stdio.h"
#pragma hdrstop

#include "LoanItMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TLoanItForm *LoanItForm;
//---------------------------------------------------------------------------
__fastcall TLoanItForm::TLoanItForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TLoanItForm::FormShow(TObject *Sender)
{
     // presses the reset button
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TLoanItForm::ResetBtnClick(TObject *Sender)
{
     PrincScroll->Position = 200000;
     APRScroll->Position = 650;
     NoYrsScroll->Position = 30;
     NPerYrScroll->Position = 12;
     PrincEdit->Text = IntToStr(PrincScroll->Position);
     APREdit->Text = FloatToStr((double)APRScroll->Position / 100.0);
     YrsEdit->Text = IntToStr(NoYrsScroll->Position);
     PerYrEdit->Text = IntToStr(NPerYrScroll->Position);
     CalcPayment(this);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::ExitBtnClick(TObject *Sender)
{
//    exit(0);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::PrincScrollChange(TObject *Sender)
{
     CalcPayment(this);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::APRScrollChange(TObject *Sender)
{
     CalcPayment(this);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::NoYrsScrollChange(TObject *Sender)
{
     CalcPayment(this);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::NPerYrScrollChange(TObject *Sender)
{
     CalcPayment(this);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::CalcPayment(TObject *Sender)
{
     // calculate payments

     Principle = (double) PrincScroll->Position;
     Interest = (double) APRScroll->Position / 10000.0;
     Years = (double) NoYrsScroll->Position;
     NoPerYr = (double) NPerYrScroll->Position;
     PrincEdit->Text = IntToStr(PrincScroll->Position);
     APREdit->Text = FloatToStr((double)APRScroll->Position / 100.0);
     YrsEdit->Text = IntToStr(NoYrsScroll->Position);
     PerYrEdit->Text = IntToStr(NPerYrScroll->Position);
     Interest = Interest / NoPerYr;
     numerator = pow((1.0 + Interest),(-NoPerYr * Years));
     numerator = 1.0 - numerator;
     term2 = numerator / Interest;
     Payment = Principle / term2;
     PaymentEdit->Text = FloatToStr(Payment);

}
//---------------------------------------------------------------------------


void __fastcall TLoanItForm::PrincEditKeyPress(TObject *Sender, char &Key)
{
     if (Key == '\r')  PrincScroll->Position = StrToInt(PrincEdit->Text);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::APREditKeyPress(TObject *Sender, char &Key)
{
     if (Key == '\r') APRScroll->Position = (double)(100 * StrToFloat(APREdit->Text));
}
//---------------------------------------------------------------------------


void __fastcall TLoanItForm::YrsEditKeyPress(TObject *Sender, char &Key)
{
     if (Key == '\r') NoYrsScroll->Position = StrToInt(YrsEdit->Text);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::PerYrEditKeyPress(TObject *Sender, char &Key)
{
     if (Key == '\r') NPerYrScroll->Position = StrToInt(PerYrEdit->Text);
}
//---------------------------------------------------------------------------

void __fastcall TLoanItForm::AmortizeBtnClick(TObject *Sender)
{
     char outline[81];
     int Yrs = Years;
     int Per = NoPerYr;
     double Remain = Principle;
     double IntPay, PrincPaid, Accrued = 0.0;

     Principle = (double) PrincScroll->Position;
     Interest = (double) APRScroll->Position / 10000.0;
     Years = (double) NoYrsScroll->Position;
     NoPerYr = (double) NPerYrScroll->Position;
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("AMORTIZATION SCHEDULE");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Principle Borrowed = " + FloatToStr(Principle));
     FrmOutPut->RichOutPut->Lines->Add("Annual Percent Rate = " + FloatToStr(Interest));
     FrmOutPut->RichOutPut->Lines->Add("No. of Years to Repay = " + FloatToStr(Years));
     FrmOutPut->RichOutPut->Lines->Add("No. of Payments Per Year = " + FloatToStr(NoPerYr));
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("YEAR PERIOD     PAYMENT    INTEREST    PRINCIPLE    ACCRUED     BALANCE");
     FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------------------");
     Interest /= NoPerYr;
     for (int i = 1; i <= Yrs; i++)
     {
         for (int j = 1; j <= Per; j++)
         {
             IntPay = Remain * Interest;
             PrincPaid = Payment - IntPay;
             Accrued += PrincPaid;
             Remain = Remain - PrincPaid;
             sprintf(outline,"%3d  %4d    %10.2f  %10.3f   %10.2f %10.2f  %10.2f",
                   i, j, Payment, IntPay, PrincPaid, Accrued, Remain);
             FrmOutPut->RichOutPut->Lines->Add(outline);
         }
         if (Remain > 0.0)
         {
            FrmOutPut->RichOutPut->Lines->Add("");
            FrmOutPut->RichOutPut->Lines->Add("YEAR PERIOD     PAYMENT    INTEREST    PRINCIPLE    ACCRUED     BALANCE");
            FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------------------");
         }
     }
     FrmOutPut->RichOutPut->Lines->Add("-----------------------------------------------------------------------");
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------

