//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "PlotUnit.h"
#include "functions.h"
#include "MemMgrUnit.h"
#include "FreqDistUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include <stdio.h>
#include <stdlib.h>
#include "XvsMultYUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TXvsMultYForm *XvsMultYForm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TXvsMultYForm::TXvsMultYForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     DescChk->Checked = false;
     XEdit->Text = "";
     YBox->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::XInBtnClick(TObject *Sender)
{
     int index = Varlist->ItemIndex;
     XEdit->Text = Varlist->Items->Strings[index];
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::YInBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              YBox->Items->Add(Varlist->Items->Strings[i]);
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::OutBtnClick(TObject *Sender)
{
     int index;

     index = YBox->ItemIndex;
     Varlist->Items->Add(YBox->Items->Strings[index]);
     YBox->Items->Delete(index);
     YInBtn->Enabled = true;
     if (YBox->Items->Count == 0) OutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::XOutBtnClick(TObject *Sender)
{
     Varlist->Items->Add(XEdit->Text);
     XEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TXvsMultYForm::OKBtnClick(TObject *Sender)
{
        int i, j, N, NoY, XCol, NoSelected;
        double **YValues, *XValues, *Means, *StdDevs, **RMatrix;
        double MinX, MaxX, MinY, MaxY, temp;
        AnsiString cellstring;
        int result, intvalue;
        double dblvalue;
        AnsiString strvalue;
        
        NoY = YBox->Items->Count;
        if (NoY < 0)
        {
                ShowMessage("ERROR!  One or more Y variables must be selected.");
                return;
        }
        selected = new int[NoY+1];
        MaxX = -1.0e20;
        MinX = 1.0e20;
        MaxY = -1.0e20;
        MinY = 1.0e20;
        N = 0;

        // Get selected variables
        for (i = 1; i <= NoY; i++)
        {
                cellstring = YBox->Items->Strings[i-1];
                for (j = 1; j <= NoVariables; j++)
                {
                        if (cellstring == MainForm->Grid->Cells[j][0])
                        {
                                selected[i-1] = j;
                                //result = VarTypeChk(j,0);
                                //if (result == 1)
                                //{
                                //        delete[] selected;
                                //        return;
                                //}
                        }
                        if (XEdit->Text == MainForm->Grid->Cells[j][0])
                        {
                                XCol = j;
                                //result = VarTypeChk(j,0);
                                //if (result == 1)
                                //{
                                //        delete[] selected;
                                //        return;
                                //}
                        }
                }
        }
        selected[NoY] = XCol;
        NoSelected = NoY + 1;

        FrmOutPut->RichOutPut->Clear();
        FrmOutPut->RichOutPut->Lines->Add("X VERSUS MULTIPLE Y VALUES PLOT");
        FrmOutPut->RichOutPut->Lines->Add("");
        GetDblMatMem(YValues,NoCases+1,NoY+1);
        GetDblVecMem(XValues,NoCases+1);
        GetDblVecMem(Means,NoSelected);
        GetDblVecMem(StdDevs,NoSelected);
        GetDblMatMem(RMatrix,NoSelected,NoSelected);
        for (i = 0; i < NoSelected; i++)
        {
                Means[i] = 0.0;
                StdDevs[i] = 0.0;
                for (j = 0; j < NoSelected; j++) RMatrix[i][j] = 0.0;
        }
        for (i = 1; i <= NoCases; i++)
        {
                if (!ValidRecord(i,selected,NoSelected)) continue;
                N = N + 1;
                XValues[i-1] = StrToFloat(MainForm->Grid->Cells[XCol][i]);
                //result = GetValue(i, XCol,intvalue, dblvalue, strvalue);
                //if (result != 0) XValues[i-1] = 0.0;
                //XValues[i-1] = dblvalue;
                if (XValues[i-1] > MaxX) MaxX = XValues[i-1];
                if (XValues[i-1] < MinX) MinX = XValues[i-1];
                for (j = 0; j <NoY; j++)
                {
                        YValues[i-1][j] = StrToFloat(MainForm->Grid->Cells[selected[j]][i]);
                        //result = GetValue(i, selected[j], intvalue, dblvalue, strvalue);
                        //if (result != 0) YValues[i-1][j] = 0.0;
                        //YValues[i-1][j] = dblvalue;
                        if (YValues[i-1][j] > MaxY) MaxY = YValues[i-1][j];
                        if (YValues[i-1][j] < MinY) MinY = YValues[i-1][j];
                }
        }

        // get descriptive data
        if (DescChk->Checked)
                Correlations(Means,StdDevs,RMatrix,NoSelected,selected,NoCases,3,false,1);

        // sort on X
        for (i = 0; i < N - 1; i++)
        {
                for (j = i + 1; j < N; j++)
                {
                        if (XValues[i] > XValues[j]) //swap
                        {
                                temp = XValues[i];
                                XValues[i] = XValues[j];
                                XValues[j] = temp;
                                for (int k = 0; k < NoY; k++)
                                {
                                        temp = YValues[i][k];
                                        YValues[i][k] = YValues[j][k];
                                        YValues[j][k] = temp;
                                }
                        }
                }
        }

        plotxy(XValues, YValues, MaxX, MinX, MaxY, MinY, N, NoY);
        PlotForm->ShowModal();

        ClearDblMatMem(RMatrix,NoSelected);
        ClearDblVecMem(StdDevs);
        ClearDblVecMem(Means);
        ClearDblVecMem(XValues);
        ClearDblMatMem(YValues,NoCases+1);
}
//---------------------------------------------------------------------------

void __fastcall TXvsMultYForm::plotxy(double *XValues, double **YValues,
                double MaxX, double MinX, double MaxY, double MinY, int N, int NoY)
{
     // routine to plot X versus multiple Y values
     int i, xpos, ypos, hleft, hright, vtop, vbottom, imagewide;
     int vhi, hwide, offset, strhi, imagehi;
     double maxval, minval, valincr, Yvalue, Xvalue;
     AnsiString Title;
     char outline[121];
     TColor Colors[12];

     Colors[1] = clRed;
     Colors[2] = clBlue;
     Colors[3] = clGreen;
     Colors[4] = clNavy;
     Colors[5] = clTeal;
     Colors[6] = clAqua;
     Colors[7] = clLime;
     Colors[8] = clFuchsia;
     Colors[9] = clGray;
     Colors[10] = clPurple;
     Colors[11] = clOlive;
     Colors[0] = clMaroon;
     Title = PlotTitleEdit->Text;
     PlotForm->Caption = Title;
     imagewide = PlotForm->Image1->Width;
     imagehi = PlotForm->Image1->Height;
     PlotForm->Image1->Canvas->FloodFill(0,0,clWhite,fsBorder);
     vtop = 20;
     vbottom = ceil(imagehi) - 80;
     vhi = vbottom - vtop;
     hleft = 100;
     hright = imagewide - 80;
     hwide = hright - hleft;
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->Brush->Color = clWhite;

     // Draw chart border
     PlotForm->Image1->Canvas->Rectangle(0,0,imagewide,imagehi);

     // draw horizontal axis
     PlotForm->Image1->Canvas->Pen->Color = clBlack;
     PlotForm->Image1->Canvas->MoveTo(hleft,vbottom);
     PlotForm->Image1->Canvas->LineTo(hright,vbottom);
     valincr = (MaxX - MinX) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          ypos = vbottom;
          Xvalue = MinX + valincr * (i - 1);
          xpos = ceil(hwide * ((Xvalue - MinX) / (MaxX - MinX)));
          xpos = xpos + hleft;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          ypos = ypos + 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
          sprintf(outline,"%6.2f",Xvalue);
          Title = outline;
          offset = PlotForm->Image1->Canvas->TextWidth(Title) / 2;
          xpos = xpos - offset;
          PlotForm->Image1->Canvas->Pen->Color = clBlack;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
     xpos = hleft + (hwide / 2) - (PlotForm->Image1->Canvas->TextWidth(XEdit->Text) / 2);
     ypos = vbottom + 20;
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,XEdit->Text);

     // Draw vertical axis
     Title = "Y VALUES";
     xpos = hleft - PlotForm->Image1->Canvas->TextWidth(Title) / 2;
     ypos = vtop - PlotForm->Image1->Canvas->TextHeight(Title);
     PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     xpos = hleft;
     ypos = vtop;
     PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
     ypos = vbottom;
     PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     valincr = (MaxY - MinY) / 10.0;
     for (i = 1; i <= 11; i++)
     {
          double value = MaxY - ((i-1) * valincr);
          sprintf(outline,"%8.2f",value);
          Title = outline;
          strhi = PlotForm->Image1->Canvas->TextHeight(Title);
          xpos = 10;
          Yvalue = MaxY - (valincr * (i-1));
          ypos = ceil(vhi * ( (MaxY - Yvalue) / (MaxY - MinY)));
          ypos = ypos + vtop - strhi / 2;
          PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
          xpos = hleft;
          ypos = ypos + strhi / 2;
          PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
          xpos = hleft - 10;
          PlotForm->Image1->Canvas->LineTo(xpos,ypos);
     }

     // draw points for x and y pairs

     for (int j = 0; j < NoY; j++)
     {
        PlotForm->Image1->Canvas->Brush->Style = bsSolid;
        PlotForm->Image1->Canvas->Brush->Color = Colors[j % 12];
        PlotForm->Image1->Canvas->Pen->Color = Colors[j % 12];
        Title = MainForm->Grid->Cells[selected[j]][0];
        for (int i = 1; i <= N; i++)
        {
                ypos = ceil(vhi * ( (MaxY - YValues[i-1][j]) / (MaxY - MinY)));
                ypos = ypos + vtop;
                xpos = ceil(hwide * ( (XValues[i-1] - MinX) / (MaxX - MinX)));
                xpos = xpos + hleft;
                if (i == 1) PlotForm->Image1->Canvas->MoveTo(xpos,ypos);
                if (LinesBox->Checked) PlotForm->Image1->Canvas->LineTo(xpos,ypos);
                PlotForm->Image1->Canvas->Ellipse(xpos,ypos,xpos+5,ypos+5);
        }
        strhi = PlotForm->Image1->Canvas->TextHeight(Title);
        PlotForm->Image1->Canvas->Brush->Color = clWhite;
        xpos = hwide + hleft;
        PlotForm->Image1->Canvas->MoveTo(xpos,ypos-strhi);
        PlotForm->Image1->Canvas->TextOut(xpos,ypos,Title);
     }
}

