//---------------------------------------------------------------------------
#ifndef PlotH
#define PlotH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Printers.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TFrmPlot : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *BtnPrint;
    TButton *BtnReturn;
     TImage *Image1;
    void __fastcall FrmResize(TObject *Sender);
     void __fastcall BtnPrintClick(TObject *Sender);
private:	// User declarations
    int xcol;
    int ycol;
    int Npts;
    int PlotType;
    double *Xtemp;
    double *Ytemp;
    AnsiString Label1;
    AnsiString Label2;
    AnsiString Label3;

public:		// User declarations
    __fastcall TFrmPlot(TComponent* Owner);
    void __fastcall PlotIt(double *X, double *Y, int NoPts, int Type,
            AnsiString XTitle, AnsiString YTitle, AnsiString Title);
void __fastcall Zdist(void);
void __fastcall Zdistp(void);
void __fastcall Hscale(double Xmin, double Xmax, int Nsteps, TColor color, int FontSize,\
            long int X, long int Y, long int Xlength, char * Label);
void __fastcall Vscale(double Ymin, double Ymax, int Nsteps, TColor color, int FontSize,\
            long int X, long int Y, long int Ylength, char * Label);
void __fastcall NormPts(double zMin, double zMax, int Npts, double realpts[][100]);
void __fastcall PltPts(double realpts[][100], double Xmax, double Xmin, double Ymax, double Ymin,\
            int Npts, long int XaxisStart, long int YaxisStart, long int XaxisRange,
            long int YaxisRange, TColor color);
void __fastcall ChiSqrDist(void);
void __fastcall ChiPts(double cMin, double cMax, int Npts, int df, double realpts[][100]);
void __fastcall Chidistp(void);
void __fastcall Fdistribution(void);
void __fastcall FPts(double FMin, double FMax, int Npts, int df1, int df2, double realpts[][100]);
void __fastcall Fdistp(void);
void __fastcall AltHypothesis(void);

};
//---------------------------------------------------------------------------
extern PACKAGE TFrmPlot *FrmPlot;
//---------------------------------------------------------------------------
#endif

