//---------------------------------------------------------------------------

#ifndef XvsMultYUnitH
#define XvsMultYUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TXvsMultYForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TBitBtn *XInBtn;
        TEdit *XEdit;
        TBitBtn *YInBtn;
        TGroupBox *GroupBox1;
        TCheckBox *DescChk;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        TListBox *YBox;
        TListBox *Varlist;
        TMemo *Memo1;
        TLabel *Label4;
        TEdit *PlotTitleEdit;
        TBitBtn *OutBtn;
        TBitBtn *XOutBtn;
        TCheckBox *LinesBox;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall XInBtnClick(TObject *Sender);
        void __fastcall YInBtnClick(TObject *Sender);
        void __fastcall OutBtnClick(TObject *Sender);
        void __fastcall XOutBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall plotxy(double *XValues, double **YValues,
                double MaxX, double MinX, double MaxY, double MinY, int N, int NoY);
private:	// User declarations
        int *selected;

public:		// User declarations
        __fastcall TXvsMultYForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TXvsMultYForm *XvsMultYForm;
//---------------------------------------------------------------------------
#endif
