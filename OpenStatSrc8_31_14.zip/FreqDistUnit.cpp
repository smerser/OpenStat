//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "FrmFDSpecs.h"
#include "MemMgrUnit.h"
#include "FreqDistUnit.h"
#include "MainUnit.h"
#include "OutPut.h"
#include "math.h"
#include "DataFuncs.h"
#include <stdio.h>
#include <stdlib.h>
// #include "TGraphUnit.h"
#include "GraphUnit.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFreqDistFrm *FreqDistFrm;
extern struct VarDef *vdef[1000];
extern struct VarDef *TempDef;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern int FileType;

//---------------------------------------------------------------------------
__fastcall TFreqDistFrm::TFreqDistFrm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::ResetBtnClick(TObject *Sender)
{
     Varlist->Clear();
     ListBox1->Clear();
     for (int i = 1; i <= NoVariables; i++)
         Varlist->Items->Add(MainForm->Grid->Cells[i][0]);
     PlotGrp->ItemIndex = -1;
     BarTypeGrp->ItemIndex = 0;
     NormDistChk->Checked = false;
     InBtn->Enabled = true;
     OutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::CancelBtnClick(TObject *Sender)
{
     FreqDistFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::InBtnClick(TObject *Sender)
{
     int i, index;

     index = Varlist->Items->Count;
     i = 0;
     while (i < index)
     {
           if (Varlist->Selected[i]) {
              ListBox1->Items->Add(Varlist->Items->Strings[i]);
              Varlist->Items->Delete(i);
              index--;
           }
           else i++;
     }
     OutBtn->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::OutBtnClick(TObject *Sender)
{
     int index;

     index = ListBox1->ItemIndex;
     Varlist->Items->Add(ListBox1->Items->Strings[index]);
     ListBox1->Items->Delete(index);
     InBtn->Enabled = true;
     if (ListBox1->Items->Count == 0) OutBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::AllBtnClick(TObject *Sender)
{
     int count, index;

     count = Varlist->Items->Count;
     for (index = 0; index < count; index++)
         ListBox1->Items->Add(Varlist->Items->Strings[index]);
     Varlist->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::OKBtnClick(TObject *Sender)
{
     int i, j, k, col, NoVars, nints, Ncases, gtype, nosets;
     int *ColNoSelected;
     double *freq;
     double *pcnt;
     double *cumpcnt;
     double *pcntilerank;
     double *cumfreq;
     double *XValue;
     double value, min, max, range, incrsize, nointervals, maxfreq;
     AnsiString CellVal, outline;
     AnsiString ValTitle;
     AnsiString VarName;
     bool NormDist, Histogram;
     double Sumx, Sumx2, Mean, Variance, StdDev, zlow, zhi;
     double X, zproplow, zprophi, zfreq;
     char outstr[120];
     int result, intvalue, noselected;
     double dblvalue;
     AnsiString strvalue;
     
     NoVars = ListBox1->Items->Count;
     if (NoVars <= 0)
     {
        ShowMessage("You must first select one or more variables to analyze");
        return;
     }

     if (BarTypeGrp->ItemIndex == 1) Histogram = true;
     else Histogram = false;
     if (NormDistChk->Checked == true)
     {
        NormDist = true;
        nosets = 2;
     }
     else
     {
         NormDist = false;
         nosets = 1;
     }

     // allocate heap space
     GetIntVecMem(ColNoSelected,1);
     GetDblVecMem(freq,NoCases+2);
     GetDblVecMem(pcnt,NoCases+2);
     GetDblVecMem(cumpcnt,NoCases+2);
     GetDblVecMem(pcntilerank,NoCases+2);
     GetDblVecMem(cumfreq,NoCases+2);
     GetDblVecMem(XValue,NoCases+2);

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("FREQUENCY ANALYSIS BY BILL MILLER");
     FrmOutPut->RichOutPut->Lines->Add("");

     // now, analyze each variable selected by the user
     NoVars = ListBox1->Items->Count;
     for (i = 1; i <= NoVars; i++)
     {
        col = 1;
        CellVal = ListBox1->Items->Strings[i-1];
        VarName = CellVal;
        for (j = 1; j <= NoVariables; j++)
        {
           if (MainForm->Grid->Cells[j][0] == CellVal)
           {
              col = j;
//              result = VarTypeChk(col,0);
//              if (result == 1) return;
              outline = "Frequency Analysis for " + CellVal;
              FrmOutPut->RichOutPut->Lines->Add(outline);
              break;
           }
        }
        ColNoSelected[0] = col;
        noselected = 1;
        // Get min and max values for this variable
        min = 1.0e32;
        max = -1.0e32;
        for (j = 1; j <= NoCases; j++)
        {
            if (! ValidRecord(j,ColNoSelected,noselected) ) continue;
            value = StrToFloat(MainForm->Grid->Cells[col][j]);
//            result = GetValue(j, col,intvalue, dblvalue, strvalue);
//            if (result != 0) value = 0.0;
//            else value = dblvalue;
            if (value > max) max = value;
            if (value < min) min = value;
        }
        range = max - min + 1.0;
        incrsize = 1.0;
        // if too many increments, set increment size for 15 increments
        if (range > 200.0) incrsize = range / 15;
        nointervals = range / incrsize;
        nints = ceil(nointervals);
        // get user approval and / or changes
        FDSpecs->TxtVariable->Text = CellVal;
        FDSpecs->TxtMin->Text = FloatToStr(min);
        FDSpecs->TxtMax->Text = FloatToStr(max);
        FDSpecs->TxtRange->Text = FloatToStr(range);
        FDSpecs->TxtIntSize->Text = FloatToStr(incrsize);
        FDSpecs->TxtNoIntervals->Text = IntToStr(nints);
again:  FDSpecs->ShowModal();
        incrsize = StrToFloat(FDSpecs->TxtIntSize->Text);
        nointervals = StrToFloat(FDSpecs->TxtNoIntervals->Text);
        nints = ceil(nointervals);
        if (nints + 1 > NoCases)
        {
           ShowMessage("Error!  No. of intervals cannot be greater than no. of cases!");
           goto again;
        }

        // create a new variable for coding if selected
        if (GrpCodeChk->Checked)
        {
            CellVal = MainForm->Grid->Cells[col][0];
            CellVal = CellVal + "Grp";
            MainForm->Grid->Cells[NoVariables+1][0] = CellVal;
            NewVar(NoVariables+1,true);
        }

        // Get frequency of cases in each interval
        for (j = 0; j < nints + 1; j++) freq[j] = 0.0;
        Ncases = 0;
        maxfreq = 0.0;
        for (j = 1; j <= NoCases; j++)
        {
           if (! ValidRecord(j,ColNoSelected,noselected)) continue;
           Ncases++;
           value = StrToFloat(MainForm->Grid->Cells[col][j]);
//           result = GetValue(j, col, intvalue, dblvalue, strvalue);
//           if (result != 0) value = 0.0;
//           else value = dblvalue;
           for (k = 1; k <= nints; k++)
           {
              if ((value >= min + ((k-1) * incrsize)) && (value < min + (k * incrsize)))
              {
                 freq[k-1]++;
                 if (freq[k-1] > maxfreq) maxfreq = freq[k-1];
                 if (GrpCodeChk->Checked) MainForm->Grid->Cells[NoVariables][j] = k;
              }
           }
        }
        for (j = 0; j < nints+1; j++) XValue[j] = min + (j * incrsize);

        // get cumulative frequencies and percents to midpoints
        cumfreq[0] = freq[0];
        pcnt[0] = freq[0] / Ncases;
        pcntilerank[0] = (freq[0] / 2.0) / Ncases;
        for (k = 2; k <= nints; k++)
        {
           cumfreq[k-1] = cumfreq[k-2] + freq[k-1];
           pcnt[k-1] = freq[k-1] / Ncases;
           cumpcnt[k-1] = cumfreq[k-1] / Ncases;
           pcntilerank[k-1] = (cumfreq[k-2] + freq[k-1] / 2.0) / Ncases;
           pcntilerank[k-1] *= 100.0;
        }

        // Print results
        FrmOutPut->RichOutPut->Lines->Add("    FROM  UP TO     FREQ.   PCNT    CUM.FREQ.  CUM.PCNT. %ILE RANK");
        FrmOutPut->RichOutPut->Lines->Add("");
        for (k = 1; k <= nints; k++)
        {
            sprintf(outstr,"%8.2f%8.2f%8.0f%8.2f  %8.2f  %8.2f  %8.2f",
               min+(k-1) * incrsize, // from
               min + k * incrsize,   // to
               freq[k-1],            // freq
               pcnt[k-1],            // percent
               cumfreq[k-1],         // cumulative freqency
               cumpcnt[k-1],         // cumulative percent to midpoint
               pcntilerank[k-1]);    // percentile rank
            FrmOutPut->RichOutPut->Lines->Add(outstr);
        }

        GetDblMatMem(GraphForm->Xpoints,nosets,nints+1);
        GetDblMatMem(GraphForm->Ypoints,nosets,nints+1);

        if (NormDist) // get normal distribution frequencies
        {
           FrmOutPut->RichOutPut->Lines->Add("");
           FrmOutPut->RichOutPut->Lines->Add("Interval ND Freq.");
           Sumx = 0.0;
           Sumx2 = 0.0;
           for (k = 1; k <= nints; k++)
           {
               Sumx += XValue[k-1] * freq[k-1];
               Sumx2 += (XValue[k-1] * XValue[k-1]) * freq[k-1];
           }
           Mean = Sumx / Ncases;
           Variance = Sumx2 - ((Sumx * Sumx) / Ncases);
           Variance /= (Ncases - 1);
           StdDev = sqrt(Variance);
           for (k = 1; k <= nints + 1; k++)
           {
               X = XValue[k-1] - (incrsize / 2.0);
               if (StdDev > 0.0) zlow = (X - Mean) / StdDev;
               else zlow = 0.0;
               X = XValue[k-1] + (incrsize / 2.0);
               if (StdDev > 0.0) zhi = (X - Mean) / StdDev;
               else zhi = 0.0;
               // get cum. prop. for this z and translate to frequency
               zproplow = normalprob(zlow);
               zprophi = normalprob(zhi);
               zfreq = Ncases * fabs(zprophi - zproplow);
               GraphForm->Ypoints[1][k-1] = zfreq;
               sprintf(outstr,"    %2d      %6.2f",k,zfreq);
               FrmOutPut->RichOutPut->Lines->Add(outstr);
               ValTitle = XValue[k-1];
           }
        }
        FrmOutPut->ShowModal();

        if (PlotGrp->ItemIndex >= 0)
        {
           GraphForm->GraphType = PlotGrp->ItemIndex;
           GraphForm->nosets = nosets;
           GraphForm->nbars = nints;
           GraphForm->BackColor = clYellow;
           GraphForm->WallColor = clBlue;
           GraphForm->FloorColor = clGray;
           GraphForm->Heading = "Frequency Distribution";
           GraphForm->XTitle = "Values of " + VarName;
           GraphForm->YTitle = "Frequency";
           if ((Histogram)||(PlotGrp->ItemIndex == 7)) GraphForm->barwideprop = 1.0;
           else GraphForm->barwideprop = 0.5;
           GraphForm->AutoScale = false;
           GraphForm->miny = 0.0;
           GraphForm->maxy = maxfreq;
           GraphForm->ShowLeftWall = true;
           GraphForm->ShowRightWall = true;
           GraphForm->ShowBottomWall = true;
           for (k = 1; k <= nints+1; k++)
           {
               GraphForm->Ypoints[0][k-1] = freq[k-1];
               GraphForm->Xpoints[0][k-1] = XValue[k-1];
           }
           GraphForm->ShowModal();
        }
     }
     ClearDblVecMem(XValue);
     ClearDblVecMem(cumfreq);
     ClearDblVecMem(pcntilerank);
     ClearDblVecMem(cumpcnt);
     ClearDblVecMem(pcnt);
     ClearDblVecMem(freq);
     ClearDblMatMem(GraphForm->Xpoints,nosets);
     ClearDblMatMem(GraphForm->Ypoints,nosets);
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------
void __fastcall TFreqDistFrm::FormShow(TObject *Sender)
{
  ResetBtnClick(this);
}
//---------------------------------------------------------------------------



