//---------------------------------------------------------------------------

#ifndef LTestUnitH
#define LTestUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TLTestForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *TrtIn;
        TBitBtn *TrtOut;
        TLabel *Label3;
        TListBox *TreatVars;
        TMemo *Memo1;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *ComputeBtn;
        TButton *OKBtn;
        TLabel *Label2;
        TStringGrid *TheorRankGrid;
        TCheckBox *PlotRanksChk;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall TrtInClick(TObject *Sender);
        void __fastcall TrtOutClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
        int ntreatments;
        
public:		// User declarations
        __fastcall TLTestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLTestForm *LTestForm;
//---------------------------------------------------------------------------
#endif
