//---------------------------------------------------------------------------

#ifndef BrowserUnitH
#define BrowserUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "SHDocVw_OCX.h"
#include <OleCtrls.hpp>
//---------------------------------------------------------------------------
class TBrowserForm : public TForm
{
__published:	// IDE-managed Components
    TCppWebBrowser *CppWebBrowser1;
private:	// User declarations
public:		// User declarations
    __fastcall TBrowserForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBrowserForm *BrowserForm;
//---------------------------------------------------------------------------
#endif
