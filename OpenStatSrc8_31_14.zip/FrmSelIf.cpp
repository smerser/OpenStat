//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "FrmSelIf.h"

extern int NoVariables;
extern struct Options ops;
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TSelIf *SelIf;
//---------------------------------------------------------------------------
__fastcall TSelIf::TSelIf(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnOKClick(TObject *Sender)
{
	SelIf->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnCancelClick(TObject *Sender)
{
	SelIf->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnVarInClick(TObject *Sender)
{
	int index = LstVars->ItemIndex;
    TxtIfExpr->Text = TxtIfExpr->Text + LstVars->Items->Strings[index];
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnPlusClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "+";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnMinusClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "-";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnMultClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "*";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnDivideClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "/";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnPowerClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "^";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnLTClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".LT.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnLEClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".LE.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnEQClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".EQ.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnANDClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".AND.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnApproxClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "(";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnGTClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".GT.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnGEClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".GE.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnApEQClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".NE.";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnORClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".OR .";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnParensClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ")";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnSevenClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "7";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnEightClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "8";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnNineClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "9";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnFourClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "4";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnFiveClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "5";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnSixClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "6";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnOneClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "1";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnTwoClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "2";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnThreeClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "3";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnZeroClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + "0";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnPeriodClick(TObject *Sender)
{
    if (ops.format == 1) TxtIfExpr->Text = TxtIfExpr->Text + ",";
    else TxtIfExpr->Text = TxtIfExpr->Text + ".";
}
//---------------------------------------------------------------------------
void __fastcall TSelIf::BtnDeleteClick(TObject *Sender)
{
    TxtIfExpr->Text = "";
}
//---------------------------------------------------------------------------
/*
void __fastcall TSelIf::BtnFunctionClick(TObject *Sender)
{
	int index = LstFunctions->ItemIndex;
    TxtIfExpr->Text = TxtIfExpr->Text + LstFunctions->Items->Strings[index];
}
//---------------------------------------------------------------------------
*/
void __fastcall TSelIf::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OS4HELP.HLP";
  Application->HelpJump("selectif");

}
//---------------------------------------------------------------------------

void __fastcall TSelIf::NotBtnClick(TObject *Sender)
{
    TxtIfExpr->Text = TxtIfExpr->Text + ".NOT.";
}
//---------------------------------------------------------------------------

void __fastcall TSelIf::FormShow(TObject *Sender)
{
     if (ops.format == 1) BtnPeriod->Caption = ",";
}
//---------------------------------------------------------------------------

