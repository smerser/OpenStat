//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "math.h"
#include "ComboPermuteUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TComboPermutationsFrm *ComboPermutationsFrm;
//---------------------------------------------------------------------------
__fastcall TComboPermutationsFrm::TComboPermutationsFrm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TComboPermutationsFrm::ClearBtnClick(TObject *Sender)
{
        Nedit->Clear();
        Redit->Clear();
        Cedit->Clear();
        Pedit->Clear();
        Fedit->Clear();
        Label5->Visible = false;
        Fedit->Visible = false;        
}
//---------------------------------------------------------------------------
void __fastcall TComboPermutationsFrm::ReturnBtnClick(TObject *Sender)
{
        ComboPermutationsFrm->Hide();        
}
//---------------------------------------------------------------------------

double TComboPermutationsFrm::logprods(unsigned __int64 StartAt,
               unsigned __int64 EndAt)
{
        double  results, logvalue;
        long int  index;

        results = 0;
        for (index = StartAt; index >= EndAt; index--)
        {
                logvalue = log(index);
                results = results + logvalue;
        }
        return (results);
}

//---------------------------------------------------------------------------

void __fastcall TComboPermutationsFrm::ComputeBtnClick(TObject *Sender)
{
        unsigned __int64 N, R, StartAt, EndAt, Index, Value;
        double Num, Den;

        N = StrToInt(Nedit->Text);
        R = StrToInt(Redit->Text);

        // do combinations
        StartAt = N;
        EndAt = N - ((N - R) - 1);
        Num = logprods(StartAt, EndAt);
        StartAt = N - R;
        EndAt = 1;
        Den = logprods(StartAt,EndAt);
        Num = exp(Num);
        Den = exp(Den);
        Value = ceil(Num / Den);
        Cedit->Text = Value;

        // do permutations
        StartAt = N;
        EndAt = 1;
        Num = logprods(StartAt,EndAt);
        StartAt = N - R;
        EndAt = 1;
        Den = logprods(StartAt,EndAt);
        Num = exp(Num);
        Den = exp(Den);
        Value = ceil(Num / Den);
        Pedit->Text = Value;

        // factorial of N
        if (N < 21)
        {
                Label5->Visible = true;
                Fedit->Visible = true;
                Value = ceil(Num);
                Fedit->Text = Value;
        }
}
//---------------------------------------------------------------------------

