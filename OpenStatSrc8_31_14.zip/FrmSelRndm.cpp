//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FrmSelRndm.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TSelRndm *SelRndm;
//---------------------------------------------------------------------------
__fastcall TSelRndm::TSelRndm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelRndm::BtnOKClick(TObject *Sender)
{
	SelRndm->Visible = false;	
}
//---------------------------------------------------------------------------
void __fastcall TSelRndm::BtnCancelClick(TObject *Sender)
{
	SelRndm->Visible = false;	
}
//---------------------------------------------------------------------------
void __fastcall TSelRndm::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OpenStat.hlp";
  Application->HelpJump("selectif");

}
//---------------------------------------------------------------------------
