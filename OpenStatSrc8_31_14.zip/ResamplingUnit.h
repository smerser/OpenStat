//---------------------------------------------------------------------------

#ifndef ResamplingUnitH
#define ResamplingUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TResamplingForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *Memo1;
    TScrollBar *SizeBar;
    TLabel *Label1;
    TEdit *RndSizeEdit;
    TListBox *VarList;
    TLabel *Label2;
    TBitBtn *InBtn;
    TBitBtn *OutBtn;
    TEdit *SelVarEdit;
    TLabel *Label3;
    TGroupBox *GroupBox1;
    TLabel *Label4;
    TEdit *ParMeanEdit;
    TLabel *Label5;
    TEdit *ParSEEdit;
    TGroupBox *GroupBox2;
    TGroupBox *GroupBox3;
    TLabel *Label6;
    TEdit *CIEdit;
    TButton *ResetBtn;
    TButton *CancelBtn;
    TButton *OKBtn;
    TButton *ReturnBtn;
    TLabel *Label7;
    TEdit *ReMeanEdit;
    TLabel *Label8;
    TEdit *ReSEEdit;
    TLabel *Label9;
    TEdit *LowCIEdit;
    TLabel *Label10;
    TEdit *HiCIEdit;
    TLabel *Label11;
    TEdit *ReLowCIEdit;
    TLabel *Label12;
    TEdit *ReHiCIEdit;
    TLabel *Label13;
    TEdit *BSMeanEdit;
    TLabel *Label14;
    TEdit *BSSEEdit;
    TLabel *Label15;
    TEdit *BSLowCIEdit;
    TLabel *Label16;
    TEdit *BSHiCIEdit;
    TGroupBox *GroupBox4;
    TCheckBox *PrintChk;
    TCheckBox *PlotChk;
    void __fastcall SizeBarChange(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InBtnClick(TObject *Sender);
    void __fastcall OutBtnClick(TObject *Sender);
    void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
    void __fastcall PlotDist(int size, double *y, char *title, TObject *Sender);
public:		// User declarations
    __fastcall TResamplingForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TResamplingForm *ResamplingForm;
//---------------------------------------------------------------------------
#endif
