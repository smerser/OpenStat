//---------------------------------------------------------------------------

#ifndef SpearmanBrownUnitH
#define SpearmanBrownUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFrmSB : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TEdit *FirstRelEdit;
    TLabel *Label3;
    TEdit *KEdit;
    TButton *CalcBtn;
    TLabel *Label4;
    TEdit *EstREdit;
    TButton *CancelBtn;
    TButton *ReturnBtn;
    TButton *ResetBtn;
    TGroupBox *GroupBox1;
    TLabel *Label5;
    TEdit *ValidityEdit;
    TLabel *Label6;
    TEdit *EstValEdit;
    void __fastcall FirstRelEditKeyPress(TObject *Sender, char &Key);
    void __fastcall KEditKeyPress(TObject *Sender, char &Key);
    void __fastcall CalcBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmSB(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmSB *FrmSB;
//---------------------------------------------------------------------------
#endif
