//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "GradingUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGradingFrm *GradingFrm;
//---------------------------------------------------------------------------
__fastcall TGradingFrm::TGradingFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TGradingFrm::CancelBtnClick(TObject *Sender)
{
    GradingFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TGradingFrm::OKBtnClick(TObject *Sender)
{
    GradingFrm->Hide();    
}
//---------------------------------------------------------------------------
