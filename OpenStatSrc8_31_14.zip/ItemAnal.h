//---------------------------------------------------------------------------
#ifndef ItemAnalH
#define ItemAnalH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TTestAnalForm : public TForm
{
__published:	// IDE-managed Components
    TListBox *VarListBox;
    TLabel *Label1;
    TListBox *ScaleListBox;
    TLabel *Label2;
    TGroupBox *GroupBox1;
    TCheckBox *CheckBox1;
    TCheckBox *CheckBox2;
    TCheckBox *CheckBox3;
    TCheckBox *CheckBox6;
    TCheckBox *CheckBox8;
    TGroupBox *GroupBox2;
    TCheckBox *CheckBox11;
    TCheckBox *CheckBox12;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TRadioButton *RadioButton5;
    TGroupBox *GroupBox3;
    TCheckBox *CheckBox13;
    TCheckBox *CheckBox14;
    TCheckBox *CheckBox15;
    TCheckBox *CheckBox16;
    TCheckBox *CheckBox17;
    TLabel *Label3;
    TEdit *ScaleNoEdit;
    TLabel *Label4;
    TEdit *ScaleNameEdit;
    TButton *CancelBtn;
     TButton *ComputeBtn;
    TBitBtn *EnterBitBtn;
    TButton *NextScaleBtn;
    TCheckBox *CheckBox18;
    TButton *ResetBtn;
    TButton *AllBtn;
    TButton *NewScaleBtn;
    TCheckBox *PrntScrs;
    TBitBtn *ExitBitBtn;
    TCheckBox *GridScrsChkBox;
     TCheckBox *SimultChk;
     TCheckBox *PlotScoresChk;
     TCheckBox *PlotMeansChk;
     TButton *ReturnBtn;
     TLabel *Label5;
     TEdit *LastNameEdit;
     TLabel *Label6;
     TEdit *FirstNameEdit;
     TLabel *Label7;
     TEdit *IDEdit;
     TBitBtn *LastInBtn;
     TBitBtn *FirstInBtn;
     TBitBtn *IDInBtn;
     TBitBtn *LastOutBtn;
     TBitBtn *FirstOutBtn;
     TBitBtn *IDOutBtn;
    void __fastcall CancelBtnClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall NextScaleBtnClick(TObject *Sender);
    void __fastcall EnterBitBtnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall ScaleNameEditKeyPress(TObject *Sender, char &Key);
    void __fastcall AllBtnClick(TObject *Sender);
    void __fastcall CheckBox11Click(TObject *Sender);
    void __fastcall NewScaleBtnClick(TObject *Sender);
    void __fastcall ExitBitBtnClick(TObject *Sender);
    void __fastcall CheckBox12Click(TObject *Sender);
    void __fastcall CheckBox18Click(TObject *Sender);
     void __fastcall LastInBtnClick(TObject *Sender);
     void __fastcall LastOutBtnClick(TObject *Sender);
     void __fastcall FirstInBtnClick(TObject *Sender);
     void __fastcall FirstOutBtnClick(TObject *Sender);
     void __fastcall IDInBtnClick(TObject *Sender);
     void __fastcall IDOutBtnClick(TObject *Sender);
private:	// User declarations
    int N; // no of cases
    int NoScales;
    int selected;
    int NoItems;
    int MaxScaleItems;
    int **Data;
    double **ScaleScores;
    char **ScaleNamePtr;
    char **Labels;
    int *noselected;
    int *ItemNoArray;
    int **ScaleItems;
    double **Matrix;
    double *Means;
    double *Variances;
    double *StdDevs;
    bool ScoringDefined;
    AnsiString *RowLabels;
    AnsiString *ColLabels;
    int *X;
    int *GroupScore;
    int *GroupFreq;
    double *ScoreGroup;
    void __fastcall Analyze(TObject *Sender);
    void __fastcall ICCurves(int scale,TObject *Sender);
    void __fastcall StepKR(int scale, TObject *Sender);
    void __fastcall SimMR(TObject *Sender);
    void __fastcall PlotScores(TObject *Sender);
    void __fastcall PlotMeans(TObject *Sender);
    void __fastcall ScoreReport(TObject *Sender);

public:		// User declarations
    AnsiString *Key;
    __fastcall TTestAnalForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTestAnalForm *TestAnalForm;
//---------------------------------------------------------------------------
#endif
