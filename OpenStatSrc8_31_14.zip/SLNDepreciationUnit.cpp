//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SLNDepreciationUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSLNDepreciationFrm *SLNDepreciationFrm;
//---------------------------------------------------------------------------
__fastcall TSLNDepreciationFrm::TSLNDepreciationFrm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSLNDepreciationFrm::ResetBtnClick(TObject *Sender)
{
     CostEdit->Text = "";
     SalvageEdit->Text = "";
     LifeEdit->Text = "";
     DepreciationEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TSLNDepreciationFrm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TSLNDepreciationFrm::ComputeBtnClick(TObject *Sender)
{
     Extended Cost, Depreciation, Salvage;
     int Life;

     Cost = StrToFloat(CostEdit->Text);
     Salvage = StrToFloat(SalvageEdit->Text);
     Life = StrToInt(LifeEdit->Text);
     Depreciation = SLNDepreciation(Cost, Salvage, Life);
     DepreciationEdit->Text = FloatToStr(Depreciation);
}
//---------------------------------------------------------------------------
