//---------------------------------------------------------------------------

#ifndef Welch1WayUnitH
#define Welch1WayUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TWelch1wayANOVAForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TListBox *VarList;
        TBitBtn *DepInBtn;
        TBitBtn *DepOutBtn;
        TLabel *Label2;
        TEdit *DepVarEdit;
        TLabel *Label6;
        TEdit *OverAllEdit;
        TLabel *Label7;
        TEdit *PostHocEdit;
        TButton *ResetBtn;
        TButton *CancelBtn;
        TButton *OKBtn;
        TBitBtn *Factor1InBtn;
        TBitBtn *Factor1OutBtn;
        TLabel *Label3;
        TEdit *Factor1Edit;
        TMemo *Memo1;
        TCheckBox *ttestchk;
        TLabel *Label4;
        void __fastcall DepInBtnClick(TObject *Sender);
        void __fastcall DepOutBtnClick(TObject *Sender);
        void __fastcall Factor1InBtnClick(TObject *Sender);
        void __fastcall Factor1OutBtnClick(TObject *Sender);
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall OKBtnClick(TObject *Sender);
private:	// User declarations
        double *cellmeans;
        double *cellcnts;
        double *cellsums;
        double *cellvars;
        double *c1;
        int *ColNoSelected;

public:		// User declarations
        __fastcall TWelch1wayANOVAForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWelch1wayANOVAForm *Welch1wayANOVAForm;
//---------------------------------------------------------------------------
#endif
