//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include <stdio.h>
#include "Output.h"
#include <math.h>
#include "functions.h"
#include "DataFuncs.h"
#include <stdlib.h>
#include "MemMgrUnit.h"
#include "KruskWall.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKWFrm *KWFrm;
extern int NoCases;
extern int NoVariables;
extern bool FilterOn;
extern int FilterCol;

//---------------------------------------------------------------------------
__fastcall TKWFrm::TKWFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TKWFrm::FormShow(TObject *Sender)
{
    AnsiString cellstring;

    ListBox1->Clear();
    for (int i = 0; i < NoVariables; i++)
    {
        cellstring = MainForm->Grid->Cells[i+1][0];
        ListBox1->Items->Add(cellstring);
    }
    GroupEdit->Text = "";
    DependEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TKWFrm::OKBtnClick(TObject *Sender)
{
    int i, j, k, L, ind_var, dep_var, min_grp, max_grp, group, total_n = 0;
    int NoTies, NoTieGroups = 0, nogroups, iTemp, U, N;
    int ColNoSelected[2];
    int NoSelected = 2;
    int *group_count;
    double score, t, SumT = 0.0, Avg, Probchi, H = 0.0, CorrectedH,
           Correction, Temp, TieSum, alpha, z;
    double **Ranks, **X, *RankSums, **original;
    AnsiString cellstring;
    char outline[81];

    // Get column numbers of the independent and dependent variables
    ind_var = 0;
    dep_var = 0;
    for (i = 0; i < NoVariables; i++)
    {
        cellstring = GroupEdit->Text;
        if (cellstring == MainForm->Grid->Cells[i+1][0]) ind_var = i+1;
        cellstring = DependEdit->Text;
        if (cellstring == MainForm->Grid->Cells[i+1][0]) dep_var = i+1;
    }
    if ((ind_var == 0) || (dep_var == 0))
    {
        ShowMessage("ERROR!  A needed variable has not been selected.");
        return;
    }

    ColNoSelected[0] = ind_var;
    ColNoSelected[1] = dep_var;

    //get minimum and maximum group codes
    min_grp = 10000; //atoi(MainForm->Grid->Cells[ind_var][1].c_str());
    max_grp = -10000;
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        group = floor(StrToFloat(MainForm->Grid->Cells[ind_var][i+1]));
        if (group < min_grp) min_grp = group;
        if (group > max_grp) max_grp = group;
    }
    nogroups = max_grp - min_grp + 1;

    // Allocate storage space
    try  {
        Ranks = new double *[NoCases];
        for (i = 0; i < NoCases; i++) Ranks[i] = new double[2];
        X = new double *[NoCases];
        for (i = 0; i < NoCases; i++) X[i] = new double[2];
        group_count = new int[nogroups];
        RankSums = new double[nogroups];
    }
    catch (...)
    {
        Application->MessageBox("Memory error in Kruskal-Wallis.","MEMORY ERROR!",MB_OK);
        return;
    }

    if (MWUChk->Checked) alpha = StrToFloat(AlphaEdit->Text);

    // Initialize arrays
    for (i = 0; i < nogroups; i++)
    {
        group_count[i] = 0;
        RankSums[i] = 0.0;
    }
    for (i = 0; i < NoCases; i++)
    {
        for (j = 0; j < 2; j++)
        {
             Ranks[i][j] = 0.0;
             X[i][j] = 0.0;
        }
    }

    // Setup for printer output
    FrmOutPut->RichOutPut->Clear();
    FrmOutPut->RichOutPut->Lines->Add("Kruskal - Wallis One-Way Analysis of Variance");
    FrmOutPut->RichOutPut->Lines->Add("See pages 184-194 in S. Siegel's Nonparametric Statistics for the Behavioral Sciences");
    FrmOutPut->RichOutPut->Lines->Add("");

    // Get data
    for (i = 0; i < NoCases; i++)
    {
        if (!ValidRecord(i+1,ColNoSelected,NoSelected)) continue;
        score = StrToFloat(MainForm->Grid->Cells[dep_var][i+1]);
        group = floor(StrToFloat(MainForm->Grid->Cells[ind_var][i+1]));
        group_count[group - min_grp]++;
        X[total_n][0] = score;
        X[total_n][1] = float(group - min_grp + 1);
        total_n++;
    }

    //Sort all scores in ascending order
    for (i = 0; i < total_n; i++)
    {
        for (j = i+1; j < total_n; j++)
        {
            if (X[i][0] > X[j][0])
            {
                Temp = X[i][0];
                X[i][0] = X[j][0];
                X[j][0] = Temp;
                Temp = X[i][1];
                X[i][1] = X[j][1];
                X[j][1] = Temp;
            }
        }
    }

    // Store ranks
    for (i = 0; i < total_n; i++)
    {
        Ranks[i][0] = i+1;
        Ranks[i][1] = X[i][1];
    }

    //Check for ties in ranks - replace with average rank and calculate
    //T for each tie and sum of the T's
    for (i = 0; i < total_n-1; i++)
    {
        j = i + 1;
        TieSum = 0.0;
        NoTies = 0;
        while (j < total_n)
        {
            if (X[j][0] > X[i][0]) goto Check1;
            if (X[j][0] == X[i][0]) // match
            {
                TieSum += Ranks[j][0];
                NoTies++;
            }
            j++;
        }
Check1:
        if (NoTies > 0) //At least one tie found
        {
            TieSum += Ranks[i][0];
            NoTies++;
            Avg = TieSum / double(NoTies);
            for (j = i; j < i+NoTies; j++) Ranks[j][0] = Avg;
            t = pow(NoTies,3) - NoTies;
            SumT += t;
            NoTieGroups++;
            i += (NoTies - 1);
        }
    } // next i

    // Calculate sum of ranks in each group
    for (i = 0; i < total_n; i++)
    {
        group = floor(Ranks[i][1]);
        RankSums[group - min_grp] += Ranks[i][0];
    }

    // Calculate statistics
    for (j = 0; j < nogroups; j++) H += (RankSums[j] * RankSums[j] /
        double (group_count[j]));
    H *= (12.0 / ( double(total_n) * double(total_n + 1)) );
    H -= (3.0 * double(total_n + 1));
    Correction = 1.0 - ( SumT / double(pow(total_n,3) - total_n) );
    CorrectedH = H / Correction;
    k = max_grp - min_grp;
    Probchi = 1.0 - chisquaredprob(H, k);

    // Report results
    FrmOutPut->RichOutPut->Lines->Add("     Score     Rank      Group");
    FrmOutPut->RichOutPut->Lines->Add("");
    for (i = 0; i < total_n; i++)
    {
        sprintf(outline,"%10.2f %10.2f %10.0f",
            X[i][0], Ranks[i][0], Ranks[i][1]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
    FrmOutPut->RichOutPut->Lines->Add("");
    FrmOutPut->RichOutPut->Lines->Add("Sum of Ranks in each Group");
    FrmOutPut->RichOutPut->Lines->Add("Group   Sum    No. in Group");
    for (i = 0; i < nogroups; i++)
    {
        sprintf(outline,"%3d  %10.2f %5d", min_grp+i, RankSums[i],group_count[i]);
        FrmOutPut->RichOutPut->Lines->Add(outline);
    }
//    FrmOutPut->ShowModal();
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"No. of tied rank groups = %3d",NoTieGroups);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Statisic H uncorrected for ties = %8.4f",H);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Correction for Ties = %6.4f",Correction);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Statistic H corrected for ties = %8.4f",CorrectedH);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    sprintf(outline,"Corrected H is approx. chi-square with %3d D.F. and probability = %6.4f",k,Probchi);
    FrmOutPut->RichOutPut->Lines->Add(outline);
    FrmOutPut->ShowModal();

    if (MWUChk->Checked)
    {
    int npairs = (nogroups * (nogroups - 1)) / 2;
    alpha = alpha / float(npairs);
    FrmOutPut->RichOutPut->Lines->Add("");
    sprintf(outline,"New alpha for %d paired comparisons = %5.3f",npairs,alpha);
    ShowMessage(outline);
    double fgroup;
    int grpone = 0;
    int grptwo = 0;

    for (int i = 1; i < nogroups; i++)
    {
        for (int j = i + 1; j <= nogroups; j++)
        {
                FrmOutPut->RichOutPut->Clear();
                FrmOutPut->RichOutPut->Lines->Add("");
                sprintf(outline,"MW U test for group %d with group %d",i,j);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                // get pointers to the two groups at i and j
                for (int k = 0; k < total_n; k++)
                {
                        if (floor(Ranks[k][1]) == i) grpone = floor(Ranks[k][1]);
                        if (floor(Ranks[k][1]) == j) grptwo = floor(Ranks[k][1]);
                }
                double **MWRanks, **MWX;
                double *MWRankSums;
                int MWcount = 0;
                int newtotal = group_count[grpone-1] + group_count[grptwo-1];
                GetDblMatMem(MWRanks,newtotal,2);
                GetDblMatMem(MWX,newtotal,2);
                GetDblVecMem(MWRankSums,2);
                // put scores and ranks from the groups into the new arrays
                for (int k = 0; k < total_n; k++)
                {
                   if ((X[k][1]== grpone) || (X[k][1] == grptwo))
                   {
                      MWX[MWcount][0] = X[k][0];
                      MWX[MWcount][1] = X[k][1];
                      MWcount++;
                   }
                }
                // sort and rank the scores in MWX
                for (int k = 0; k < MWcount-1; k++)
                {
                        for (int m = k+1; m < MWcount; m++)
                        {
                                if (MWX[k][0] > MWX[m][0]) // swap
                                {
                                        Temp = MWX[k][0];
                                        MWX[k][0] = MWX[m][0];
                                        MWX[m][0] = Temp;
                                        Temp = MWX[k][1];
                                        MWX[k][1] = MWX[m][1];
                                        MWX[m][1] = Temp;
                                }
                        }
                }
                for (int k = 0; k < MWcount; k++)
                {
                        MWRanks[k][0] = k+1;
                        MWRanks[k][1] = MWX[k][1];
                }

                //get sum of ranks in each group
                MWRankSums[0] = 0.0;
                MWRankSums[1] = 0.0;
                for (int k = 0; k < MWcount; k++)
                {
                   if (MWX[k][1]== grpone) MWRankSums[0] += MWRanks[k][0];
                   else MWRankSums[1] += MWRanks[k][0];
                }

                //Check for ties in ranks - replace with average rank and calculate
                //T for each tie and sum of the T's
                NoTieGroups = 0;
                for (int k = 0; k < MWcount-1; k++)
                {
                        int m = k + 1;
                        TieSum = 0.0;
                        NoTies = 0;
                        while (m < MWcount)
                        {
                                if (MWX[m][0] > MWX[k][0]) goto Check2;
                                if (MWX[m][0] == MWX[k][0]) // match
                                {
                                        TieSum += MWRanks[m][0];
                                        NoTies++;
                                }
                                m++;
                        }
Check2:
                        if (NoTies > 0) //At least one tie found
                        {
                                TieSum += MWRanks[k][0];
                                NoTies++;
                                Avg = TieSum / double(NoTies);
                                for (int m = k; m < k+NoTies; m++) MWRanks[m][0] = Avg;
                                t = pow(NoTies,3) - NoTies;
                                SumT += t;
                                NoTieGroups++;
                                k += (NoTies - 1);
                        }
                } // next k

                //Calculate U for larger and smaller groups
                double U, U2, SD, probz, z;
                int n1 = group_count[grpone-1];
                int n2 = group_count[grptwo-1];
                if (n1 > n2)
                        U = double(n1 * n2) + (double(n1 * (n1 + 1)) / 2.0) - MWRankSums[0];
                else
                        U = double(n1 * n2) + (double(n2 * (n2 + 1)) / 2.0) - MWRankSums[1];
                U2 = double (n1 * n2) - U;
                SD = double(n1 * n2 * (n1 + n2 + 1)) / 12.0;
                SD = sqrt(SD);
                if (U2 > U) z = (U2 - double(n1 * n2 / 2)) / SD;
                else z = (U - double(n1 * n2 / 2)) / SD;
                probz = 1.0 - normalprob(z);

                //Report results
                int largestn;
                FrmOutPut->RichOutPut->Lines->Add("     Score     Rank      Group");
                FrmOutPut->RichOutPut->Lines->Add("");
                for (int k = 0; k < MWcount; k++)
                {
                        sprintf(outline,"%10.2f %10.2f %10.0f",
                            MWX[k][0], MWRanks[k][0], MWX[k][1]);
                        FrmOutPut->RichOutPut->Lines->Add(outline);
                }
                FrmOutPut->RichOutPut->Lines->Add("");
                FrmOutPut->RichOutPut->Lines->Add("Sum of Ranks in each Group");
                FrmOutPut->RichOutPut->Lines->Add("Group   Sum    No. in Group");
                sprintf(outline,"%3d  %10.2f %5d", grpone, MWRankSums[0],group_count[grpone-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"%3d  %10.2f %5d", grptwo, MWRankSums[1],group_count[grptwo-1]);
                FrmOutPut->RichOutPut->Lines->Add(outline);

                FrmOutPut->RichOutPut->Lines->Add("");
                sprintf(outline,"No. of tied rank groups = %3d",NoTieGroups);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                if (n1 > n2) largestn = n1;
                else largestn = n2;
                if (largestn < 20)
                        sprintf(outline,"Statistic U = %8.4f",U);
                else
                {
                        if (U > U2) sprintf(outline,"Statistic U = %8.4f",U);
                        else sprintf(outline,"Statistic U = %8.4f",U2);
                }
                FrmOutPut->RichOutPut->Lines->Add(outline);
                sprintf(outline,"z Statistic (corrected for ties) = %8.4f, Prob. > z = %6.4f",
                     z, probz);
                FrmOutPut->RichOutPut->Lines->Add(outline);
                if (n2 < 20)
                {
                        FrmOutPut->RichOutPut->Lines->Add("z test is approximate.  Use tables of exact probabilities in Siegel.");
                        FrmOutPut->RichOutPut->Lines->Add("(Table J or K, pages 271-277)");
                }
                FrmOutPut->ShowModal();
                ClearDblVecMem(MWRankSums);
                ClearDblMatMem(MWX,newtotal);
                ClearDblMatMem(MWRanks,newtotal);
        } // next j
    } // next i
    } // end if MWU checked

    // Clean up the heap
    delete[] RankSums;
    delete[] group_count;
    for (i = 0; i < NoCases; i++) delete[] X[i];
    delete[] X;
    for (i = 0; i < NoCases; i++) delete[] Ranks[i];
    delete[] Ranks;

    KWFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TKWFrm::CancelBtnClick(TObject *Sender)
{
    KWFrm->Hide();
}
//---------------------------------------------------------------------------
void __fastcall TKWFrm::ResetBtnClick(TObject *Sender)
{
    FormShow(this);    
}
//---------------------------------------------------------------------------
void __fastcall TKWFrm::ListBox1Click(TObject *Sender)
{
    int index;

    index = ListBox1->ItemIndex;
    if (GroupEdit->Text == "") GroupEdit->Text = ListBox1->Items->Strings[index];
    else DependEdit->Text = ListBox1->Items->Strings[index];
}
//---------------------------------------------------------------------------

