//---------------------------------------------------------------------------
#ifndef CanVarsH
#define CanVarsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmCanonical : public TForm
{
__published:	// IDE-managed Components
    TListBox *LstVars;
    TListBox *LstLeftVars;
    TListBox *LstRightVars;
    TLabel *LblDirections;
    TButton *BtnCancel;
    TButton *BtnOK;
    TBitBtn *BtnLeftIn;
    TBitBtn *BtnLeftOut;
    TBitBtn *BtnRightIn;
    TBitBtn *BtnRightOut;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TCheckBox *BtnRedundency;
    TCheckBox *BtnRawCoeffs;
    TCheckBox *BtnRootsVectors;
    TCheckBox *BtnInverses;
    TCheckBox *BtnCorrs;
    TCheckBox *BtnDescriptives;
    TCheckBox *SaveRChkBox;
    void __fastcall BtnOKClick(TObject *Sender);
    void __fastcall BtnLeftInClick(TObject *Sender);
    void __fastcall BtnRightInClick(TObject *Sender);
    void __fastcall BtnLeftOutClick(TObject *Sender);
    void __fastcall BtnRightOutClick(TObject *Sender);
    void __fastcall BtnCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TFrmCanonical(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmCanonical *FrmCanonical;
//---------------------------------------------------------------------------
#endif
