//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "stdlib.h"
#include "stdio.h"
#include "math.h"
#include "functions.h"
#include "OutPut.h"
#include "DictionaryUnit.h"
#include "MatrixUnit.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "MatrixUnit.h"
#include "MemMgrUnit.h"
#include "OLSMRUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOLSMRForm *OLSMRForm;
extern int NoCases;
extern int NoVariables;
extern struct VarDef *vdef[1000];
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TOLSMRForm::TOLSMRForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::DepInBtnClick(TObject *Sender)
{
    int index;

    index = LstVariables->ItemIndex;
    DepVarEdit->Text = LstVariables->Items->Strings[index];
    LstVariables->Items->Delete(index);
    DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::IndInBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstVariables->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstVariables->Selected[i])
         {
            cellstring = LstVariables->Items->Strings[i];
            IndepList->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstVariables->Items->Count; i++)
           {
               if (LstVariables->Selected[i])
               {
                  LstVariables->Items->Delete(i);
                  count--;
               }
           }
     }
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::IndOutBtnClick(TObject *Sender)
{
     int index = IndepList->ItemIndex;
     if (index >= 0)
     {
        LstVariables->Items->Add(IndepList->Items->Strings[index]);
        IndepList->Items->Delete(index);
     }
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::BtnResetClick(TObject *Sender)
{
        DepVarEdit->Text = "";
        LstVariables->Clear();
        DescChk->Checked = false;
        XMatChk->Checked = false;
        XTXChk->Checked = false;
        XTransChk->Checked = false;
        XTXInvChk->Checked = false;
        XTXInvXTChk->Checked = false;
        bVectorChk->Checked = false;
        PredYVecChk->Checked = false;
        ResidVecChk->Checked = false;
        SavePredChk->Checked = false;
        YvsPredYChk->Checked = false;
        YvsResidChk->Checked = false;
        for (int i = 0; i < NoVariables; i++)
                LstVariables->Items->Add(MainForm->Grid->Cells[i+1][0]);
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::FormShow(TObject *Sender)
{
     BtnResetClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TOLSMRForm::ComputeBtnClick(TObject *Sender)
{
     AnsiString cellstring, deplabel;
     int depcol, nopred, P;
     int *predcols;
     AnsiString *VarLabels, *RowLabels;
     char outline[121];
     double *Means, *Variances, *StdDevs, *BWeights, *BetaWeights;
     double *Y, *PREDY, *RESID, *Bttests, *tProbs, *BStdErrs;
     double R2, stderrest;
     double **X, **XT, **XTX, **INVXT, **XTXINV, **HAT;
     double D, Prob, value, SSY, SSres, resvar, SSreg, VarY, SDY, MeanY;
     bool errorcode;
     VarLabels = new AnsiString[NoVariables];
     RowLabels = new AnsiString[NoCases];
     depcol = 0;
     // get column number of the dependent variable Y
     cellstring = DepVarEdit->Text;
     for (int i = 0; i < NoVariables; i++)
     {
         if (cellstring == MainForm->Grid->Cells[i+1][0])
         {
                depcol = i+1;
                deplabel = cellstring;
         }
     }
     if (depcol == 0)
     {
        ShowMessage("No dependent variable found.  Try again.");
        delete[] VarLabels;
        return;
     }
     nopred = IndepList->Items->Count;
     predcols = new int[nopred];
     //  Get labels and column numbers of the predictors
     for (int i = 0; i < nopred; i++)
     {
        cellstring = IndepList->Items->Strings[i];
        for (int j = 0; j < NoVariables; j++)
        {
                if (cellstring == MainForm->Grid->Cells[j+1][0])
                {
                        VarLabels[i+1] = cellstring;
                        predcols[i] = j+1;
                }
        }
     }
     VarLabels[0] = "CONSTANT";
     P = nopred + 1;

     // allocate storage
     GetDblVecMem(Y,NoCases); // Y = new double[NoCases];
     GetDblVecMem(PREDY,NoCases); //PREDY = new double[NoCases];
     GetDblVecMem(RESID,NoCases); //RESID = new double[NoCases];
     GetDblVecMem(Means,P); //Means = new double[nopred + 1];
     GetDblVecMem(Variances,P); //Variances = new double[nopred + 1];
     GetDblVecMem(StdDevs,P); //StdDevs = new double[nopred + 1];
     GetDblVecMem(BWeights,P); // BWeights = new double[nopred + 1];
     GetDblVecMem(BetaWeights,P); // BetaWeights = new double[nopred + 1];
     GetDblVecMem(Bttests,P); // Bttests = new double[nopred + 1];
     GetDblVecMem(tProbs,P); // tProbs = new double[nopred + 1];
     GetDblVecMem(BStdErrs,P); // BStdErrs = new double[nopred + 1];
     GetDblMatMem(X,NoCases,P);
     GetDblMatMem(XT,P,NoCases);
     GetDblMatMem(XTX,P,P);
     GetDblMatMem(XTXINV,P,P);
     GetDblMatMem(INVXT,P,NoCases);
     GetDblMatMem(HAT,NoCases,NoCases);

     // Get values from the Data Grid
     for (int i = 0; i < NoCases; i++)
     {
        RowLabels[i] = MainForm->Grid->Cells[0][i+1];
        Y[i] = StrToFloat(MainForm->Grid->Cells[depcol][i+1]);
        for (int j = 0; j < nopred; j++)
                X[i][j+1] = StrToFloat(MainForm->Grid->Cells[predcols[j]][i+1]);
     }

     // Initialize values
     for (int i = 0; i < P; i++)
     {
        Means[i] = 0.0;
        Variances[i] = 0.0;
        BWeights[i] = 0.0;
        BetaWeights[i] = 0.0;
     }

     // Get means and deviations of X and Y from their means
     for (int i = 0; i < NoCases; i++)
     {
        for (int j = 0; j < nopred; j++)
        {
                Means[j+1] += X[i][j+1];
                Variances[j+1] += (X[i][j+1] * X[i][j+1]);
        }
     }
     for (int i = 0; i < NoCases; i++)
     {
        Means[0] += Y[i];
        Variances[0] += (Y[i] * Y[i]);
     }

     for (int i = 0; i < P; i++)
     {
        Variances[i] = Variances[i] - (Means[i] * Means[i]/ double (NoCases));
        Variances[i] /= double (NoCases - 1);
        StdDevs[i] = sqrt(Variances[i]);
     }
     for (int i = 0; i < P; i++) Means[i] /= double (NoCases);

     //Get deviation scores
     for (int i = 0; i < NoCases; i++)
     {
//        Y[i] = Y[i] - Means[0];
        for (int j = 1; j < P; j++) X[i][j] = X[i][j] - Means[j];
     }

     // Augment the X matrix in first cclumn
     for (int i = 0; i < NoCases; i++) X[i][0] = 1.0;

      // show X matrix if elected
     if (XMatChk->Checked)
     {
        ArrayPrint(X,NoCases,P,"VARIABLES",RowLabels,VarLabels,"X MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Get Transpose of X and show if elected (XT)
     MATTRN(XT,X,NoCases,P);
     if (XTransChk->Checked)
     {
        ArrayPrint(XT,P,NoCases,"VARIABLES",VarLabels,RowLabels,"XT MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }
/*
     // Get means, variances, standard deviations of values and display
     for (int i = 0; i < P; i++)
     {
        Means[i] = 0.0;
        Variances[i] = 0.0;
        BWeights[i] = 0.0;
     }
     MeanY = 0.0;
     SSY = 0.0;
     for (int i = 0; i < NoCases; i++)
     {
        Y[i] = StrToFloat(MainForm->Grid->Cells[depcol][i+1]);
        MeanY += Y[i];
        SSY += (Y[i] * Y[i]);
     }
     MeanY = MeanY / NoCases;
     VarY = SSY - (MeanY * MeanY / NoCases);
     VarY = VarY / (NoCases - 1);
     SDY = sqrt(VarY);

     for (int i = 0; i < NoCases; i++)
     {
        for (int j = 1; j < P; j++)
        {
                Means[j] += X[i][j];
                Variances[j] += (X[i][j] * X[i][j]);
        }
     }
     for (int j = 1; j < P; j++)
     {
        Means[j] = Means[j] / NoCases;
        Variances[j] = Variances[j] - (Means[j] * Means[j] / NoCases);
        Variances[j] = Variances[j] / (NoCases - 1);
        StdDevs[j] = sqrt(Variances[j]);
     }
     Means[0] = MeanY;
     Variances[0] = VarY;
     StdDevs[0] = SDY;
*/
     // Show Y vector and X matrix if elected (Y)
     if (DescChk->Checked)
     {
        FrmOutPut->RichOutPut->Clear();
        VPrint(Means,P,VarLabels,"Means");
//        FrmOutPut->ShowModal();
//        FrmOutPut->RichOutPut->Clear();
        VPrint(Variances,P,VarLabels,"Variances");
//        FrmOutPut->ShowModal();
//        FrmOutPut->RichOutPut->Clear();
        VPrint(StdDevs,P,VarLabels,"Std. Deviations");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Get transpose of X times X and show if elected (XTX)
     MATAxB(XTX,XT,X,P,NoCases,NoCases,P,errorcode);

     if (XTXChk->Checked)
     {
        ArrayPrint(XTX,P,P,"VARIABLE",VarLabels,VarLabels,"XTX MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Get inverse of XTX and show if elected (XTXINV)
     // First copy XTX into XTXINV so as not to destroy XTX
     for (int i = 0; i < P; i++)
     {
        for (int j = 0; j < P; j++)
        {
                XTXINV[i][j] = XTX[i][j];
        }
     }
     SVDinverse(XTXINV,P);

     if (XTXInvChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(XTXINV,P,P,"VARIABLE",VarLabels,VarLabels,"XTX MATRIX INVERSE");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Post multiply XTXINV by XT and show if elected (INVXT)
     MATAxB(INVXT,XTXINV,XT,P,P,P,NoCases,errorcode);
     if (XTXInvChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(INVXT,P,NoCases,"VARIABLE",VarLabels,RowLabels,"XTX INVERSE TIMES XT");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Pre multiply INVXT by X to get HAT and show if elected
     MATAxB(HAT,X,INVXT,NoCases,P,P,NoCases,errorcode);
     if (XTXInvChk->Checked)
     {
        FrmOutPut->RichOutPut->Lines->Add("");
        ArrayPrint(HAT,NoCases,NoCases,"VARIABLE",RowLabels,RowLabels,"HAT MATRIX");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }

     // Get beta weights vector b = INVXT x Y and show if elected
     for (int i = 0; i < P; i++) // outerloop
     {
        for (int j = 0; j < NoCases; j++) // inner loop
        {
                BWeights[i] = BWeights[i] + (INVXT[i][j] * Y[i]);
        }
     }
     if (bVectorChk->Checked)
     {
        VPrint(BWeights,P,VarLabels,"b WEIGHTS");
        FrmOutPut->ShowModal();
        FrmOutPut->RichOutPut->Clear();
     }
     // Get predicted PREDY = HAT times Y and show, save and plot if elected

     // Get residuals RESID = (Y - PREDY) and show, save and plot if elected

     // Get ANOVA results and display them

     // Get variances, std.errors, t tests, etc. for coefficients and display

     // Cleanup storage
     ClearDblMatMem(HAT,NoCases);
     ClearDblMatMem(INVXT,P);
     ClearDblMatMem(XTXINV,P);
     ClearDblMatMem(XTX,P);
     ClearDblMatMem(XT,P);
     ClearDblMatMem(X,NoCases);
     ClearDblVecMem(BStdErrs);
     ClearDblVecMem(tProbs);
     ClearDblVecMem(Bttests);
     ClearDblVecMem(BetaWeights);
     ClearDblVecMem(BWeights);
     ClearDblVecMem(StdDevs);
     ClearDblVecMem(Variances);
     ClearDblVecMem(Means);
     ClearDblVecMem(RESID);
     ClearDblVecMem(PREDY);
     ClearDblVecMem(Y);
     delete[] RowLabels;
     delete[] VarLabels;
}
//---------------------------------------------------------------------------
