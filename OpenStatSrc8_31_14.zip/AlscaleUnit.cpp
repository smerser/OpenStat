//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "OutPut.h"
#include "MemMgrUnit.h"
#include "functions.h"
#include "stdio.h"
#include "AlscaleUnit.h"
extern int NoCases;
extern int NoVariables;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAlscaleForm *AlscaleForm;
//---------------------------------------------------------------------------
__fastcall TAlscaleForm::TAlscaleForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAlscaleForm::ResetBtnClick(TObject *Sender)
{
     MAXSIZE = 38000;
     BLANK = ' ';
     NRowsEdit->Text = "";
     NColsEdit->Text = "";
     NMatricesEdit->Text = "";

}
//---------------------------------------------------------------------------
void __fastcall TAlscaleForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TAlscaleForm::ComputeBtnClick(TObject *Sender)
{
     char outline[101];
//     double PRECISION CUT,STMIN,STMIND;
//     int DEBUG,ICNSTR,NOULB;
     MAXDIM = 6; // DEFINES THE MAXIMUM NUMBER OF DIMENSIONS.
                     // THIS VALUE MAY NOT BE CHANGED.
     BIG = 9.0E20; // DEFINES THE LARGEST NOMINAL OR ORDINAL DATUM ALLOWED.
                          // THIS MAY BE CHANGED.
     EPSID = 0.001; // DEFINES THE DEFAULT ITERATION CONVERGENCE CRITERION.
                           // THIS MAY BE CHANGED.
     MAXITD = 30; // DEFINES THE DEFAULT MAXIMUM NUMBER OF ITERATIONS.
                      // THIS MAY BE CHANGED.
     STMIND = 0.005; // DEFINES THE DEFAULT MINIMUN S-STRESS.
                            // THIS MAY BE CHANGED.
     bool EOJ = false;

//   CALL STEP0()  note: step0 has been inserted here
//     int NROW, NCOL, NS, NDTYP, NSIM, NPS, NWC, NDEG, NDMX;


     NROW = StrToInt(NRowsEdit->Text);
     NCOL = StrToInt(NColsEdit->Text);
     NS = StrToInt(NMatricesEdit->Text);
     NDTYP = MeasLevelGrp->ItemIndex + 1;
     NSIM = DataFormGrp->ItemIndex;
     NPS = MeasProcGrp->ItemIndex + 1;
     NWC = MeasCondGrp->ItemIndex + 1;
     NDEG = StrToInt(DegPolyEdit->Text);
     NDMAX = StrToInt(MaxCatsEdit->Text);
     CUT = StrToFloat(CutoffEdit->Text);

//     DATA SPECIFICATIONS
//     -------------------

//     NROW     NUMBER OF ROW STIMULI (NO MAXIMUM)
//     NCOL     NUMBER OF COLUMN STIMULI (NO MAXIMUM)
//     NS       NUMBER OF MATRICES (NO MAXIMUM)
//     NDTYP    MEASUREMENT LEVEL
//                   =1   RATIO (POLYNOMIAL W/O INTERCEPT)
//                   =2   INTERVAL (POLYNOMIAL WITH INTERCEPT)
//                   =3   ORDINAL(DEFAULT)
//                   =4   NOMINAL
//     NSIM     DATA FORM
//                   =0   SYMMETRIC-DISSIMILARITY(DEFAULT)
//                   =1   SYMMETRIC-SIMILARITY
//                   =2   ASYMMETRIC-DISSIMILARTY
//                   =3   ASYMMETRIC-SIMILARITY
//                   =4   RECTANGULAR-DISSIMILARITY
//                   =5   RECTANGULAR-SIMILARITY
//     NPS      MEASUREMENT PROCESS (ONLY WHEN NDTYP=3)
//                   =1   DISCRETE(DEFAULT)
//                   =2   CONTINUOUS
//     NWC      MEASUREMENT CONDITIONALITY
//                   =1   MATRIX CONDITIONAL(DEFAULT)
//                   =2   ROW CONDITIONAL
//                   =3   UNCONDITIONAL
//     NDEG     DEGREES IN POLYNOMIAL (WHEN NDTYP=1 OR 2)
//     NDMX     MAXIMUM NUMBER OF ORDINAL OBSERVATION CATEGORIES.
//                   (DEFAULT= TOTAL NUMBER OF CELLS, OR 1000,
//                             WHICHEVER IS SMALLER)
//     CUT      CUTOFF FOR MISSING DATA (DEFAULT 0.0)


     sprintf(outline,"��������  ��        ��������  ��������  ��������  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��    ��  ��        ��        ��        ��    ��  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��    ��  ��        ��        ��        ��    ��  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��������  ��        ��������  ��        ��������  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��    ��  ��              ��  ��        ��    ��  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��    ��  ��              ��  ��        ��    ��  ��      ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"��    ��  ��������  ��������  ��������  ��    ��  ��������");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"ALTERNATING  LEAST  SQUARES   SCALING    *    VERSION 84.1");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"BY FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J. LEWYCKYJ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"PC Version by  B. Erichson  &  A. Bischoff  *  February 90");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"COPYRIGHT 1977 BY  F. W. YOUNG, Y. TAKANE & R. J. LEWYCKYJ");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if (NROW < 3)goto pos903;
     if(NS <= 0)goto pos904;
     sprintf(outline,"YOSHIO TAKANE , FORREST W. YOUNG &");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline," A L S C A L  PC ALTERNATING LEAST SQUARES SCALING");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"ROSTYSLAW J. LEWYCKYJ.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline," Adaptation by B. Erichson & A. Bischoff");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"PSYCHOMETRIC LABORATORY");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline," Final change: Febr. 1990");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"THE UNIVERSITY OF NORTH CAROLINA");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"CHAPEL HILL, N.C.  27514");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     NB = NROW ;
     if(NSIM > 3) NB = NB + NCOL;
     NBS = NB * NB;
     NBNBNS = NBS * NS;
     NC = NB * (NB - 1);
     NC2 = NC / 2;
     NDX = min(MAXDIM,NB-2);
     if(NS == 1) strcpy(CCC,"MATRIX");
     else strcpy(CCC, "MATRICES");
     sprintf(outline," DATA SPECIFICATIONS-");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"  NROW - NUMBER OF ROW STIMULI',T50,I5,T58,'ROW STIMULI");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"  NCOL - NUMBER OF COLUMN STIMULI',T50,I5,T58,'COLUMN STIMULI");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"  NS   - NUMBER OF MATRICES");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     NCST = 1;
     if(NDTYP == 1)
     {
        strcpy(CCC,"RATIO");
	   NCST = 0;
     }
     else if(NDTYP == 2) strcpy(CCC,"INTERVAL");
     else if(NDTYP == 4) strcpy(CCC,"NOMINAL");
     else
     {
	    strcpy(CCC,"ORDINAL");
	    NDTYP = 3;
     }
     sprintf(outline,"NDTYP- MEASUREMENT LEVEL %d = %s",NDTYP,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if((NSIM < 0) || (NSIM > 5)) NSIM = 0;
     if (NSIM > 1) NC2 = NBS;
     NT = NC2 * NS;
     if(NSIM == 0) strcpy(CCC,"SYMMETRIC-DISSIMILARITY");
     if(NSIM == 1) strcpy(CCC,"SYMMETRIC-SIMILARITY");
     if(NSIM == 2) strcpy(CCC,"ASYMMETRIC-DISSIMILARITY");
     if(NSIM == 3) strcpy(CCC,"ASYMMETRIC-SIMILARITY");
     if(NSIM == 4) strcpy(CCC,"RECTANGULAR-DISSIMILARITY");
     if(NSIM == 5) strcpy(CCC,"RECTANGULAR-SIMILARITY");
     sprintf(outline,"NSIM- DATA TYPE %d = %s",NSIM,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if(NPS == 2) strcpy(CCC,"CONTINUOUS (UNTIE)");
     else strcpy(CCC,"DISCRETE (TIE)");
	NPS = 1;
     sprintf(outline,"NPS - MEASUREMENT PROCESS %d = %s",NPS,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if ((NPS == 2) && (NDTYP == 4))
     {
/*
	WRITE(LOUT,9910)
	WRITE(LOUT,228)
	WRITE(*,9910)
	WRITE(*,228)
*/
     }
//   CALL HITR

	NPS = 1;
     sprintf(outline,"THE PROGRAM WILL CONTINUE WITH THE DISCRETE MEASUREMENT PROCESS (NPS=1)");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if(NWC == 2) strcpy(CCC,"ROWCONDITIONAL");
     else if(NWC == 3)
     {
            strcpy(CCC,"UNCONDITIONAL");
	       NWC = 0;
     }
     else strcpy(CCC,"MATRIX-CONDITIONAL");
	NWC = 1;
     sprintf(outline,"NWC - MEASUREMENT CONDITIONALITY %d = %s",NWC,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
//-----THE FOLLOWING TWO STATEMENTS ADDED 8/4/82
     sprintf(outline,"CUT - DATA CUTOFF = %13.7f",CUT);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if(NDEG < 1) NDEG = 1;
     if(NDTYP <= 2)
     {
	    if(NDEG <= 1) goto pos813;
	    if(NDEG == 2) strcpy(CCC,"QUADRATIC");
	    else if(NDEG == 3) strcpy(CCC,"CUBIC");
	    else
         {
             strcpy(CCC,"QUARTIC");
	        NDEG = 4;
         }
     }
     sprintf(outline,"NDEG - DEGREES IN POLYNOMIAL %d = %s",NDEG,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
pos813:
     if ((NROW != NCOL) && (NSIM < 4)) goto pos902;
     NWE = AnalysisGrp->ItemIndex;
     NDIM = StrToInt(MaxSolEdit->Text);
     NDMN = StrToInt(MinSolEdit->Text);
//     int NNC;
     if (WghtConstrainedEdit->Text == "No") NNC = 1;
     else NNC = 0;
     MAXIT = StrToInt(MaxItersEdit->Text);
     EPSI = StrToFloat(MaxItersEdit->Text);
     STMIN = StrToFloat(MinStressEdit->Text);
     NDIR = StrToInt(NoDirectsEdit->Text);

//     ANALYSIS SPECIFICATIONS
//     -----------------------
//     NWE      MODEL TYPE
//                   =0   SIMPLE EUCLIDIAN MODEL (DEFAULT)
//                   =1   INDIVIDUAL DIFFERENCES MODEL
//                   =2   MULTIPROCESS ASYMMETRIC MODEL
//                   =3   MULTIPROCESS ASYMMETRIC INDIVIDUAL DIFFERENCES
//                        MODEL
//                   =4   GENERALIZED EUCLIDEAN MODEL
//     NDIM     NUMBER OF DIMENSIONS IN THE SOLUTION  (MAXIMUM)
//     NDMN     NUMBER OF DIMENSIONS IN THE SOLUTION  (MINIMUM)
//     NNC=1    IF WEIGHTS NOT CONSTRAINED TO BE POSITIVE
//              (DEFAULT IS NONNEGATIVITY RESTRICTIONS)
//    MAXIT    MAXIMUM NUMBER OF ITERATIONS (DEFAULT IS 30)
//     EPSI     CONVERGENCE CRITERION (DEFAULT IS 0.001)
//     STMIN    MINIMUM STRESS (DEFAULT IS .005)
//     NDIR     NUMBER OF GEMSCAL DIRECTIONS

//-----STMIN ADDED TO FOLLOWING STATEMENT 7/7/82
//-----NDIR ADDED TO FOLLOWING STATEMENT FOR GEMSCAL 8/5/82

//-----FOLLOWING STATMENT CHANGED FROM NWE.GT.3 FOR GEMSCAL 8/5/82
     if(NWE == 1) strcpy(CCC,"INDIVIDUAL DIFFERENCES (INDSCAL) MODEL");
     if(NWE == 2) strcpy(CCC,"ASYMMETRIC EUCLIDIAN (ASYMSCAL) MODEL");
     if(NWE == 3) strcpy(CCC,"ASYMMETRIC INDSCAL (ASYNDSCAL) MODEL");
     if(NWE == 4) strcpy(CCC,"GENERALIZED EUCLIDEAN (GEMSCAL) MODEL");
     if(NWE == 0) strcpy(CCC,"SIMPLE EUCLIDIAN MODEL (DEFAULT)");
     sprintf(outline,"NWE - MODEL TYPE %d = %s",NWE,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);

//-----FOLLOWING STATMENTS ADDED FOR GEMSCAL 8/5/82
      IFLPDS = 0;
      if (NWE == 4)
      {
         IFLPDS = 1;
	    NWE = 1;
      }
      if ((NWE == 1) && (NS == 1))
      {

//	WRITE(LOUT,9910)
     sprintf(outline,"THE INDIVIDUAL DIFFERENCES OR GENERALIZED EUCLIDEAN MODEL");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"CAN NOT BE USED WITH ONLY ONE MATRIX.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"ANALYSIS CONTINUES WITH EUCLIDEAN MODEL (NWE=0)");
     FrmOutPut->RichOutPut->Lines->Add(outline);
//	CALL HITR
      }
     if ((NWE == 1) && (NS == 1)) NWE = 0;
     if ((NWE == 3) && (NS == 1))
     {
//	   WRITE(LOUT,9910)
        sprintf(outline,"THE INDIVIDUAL DIFFERENCES ASYMMETRIC MODEL CANNOT BE USED WITH ONLY ONE MATRIX.");
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"ANALYSIS CONTINUES WITH THE ASYMMETRIC MODEL (NWE=2)");
        FrmOutPut->RichOutPut->Lines->Add(outline);
//	   CALL HITR
     }
     if ((NWE == 3) && (NS == 1)) NWE = 2;
     if ((NWC != 0) || ((NWE != 0) && (NWE != 2)) || (NS != 1)) goto pos17;
     NWC = 1;
//      WRITE(LOUT,9910)
     sprintf(outline,"PROGRAM WILL CONTINUE TREATING THE DATA AS MATRIX CONDITIONAL (NWC=1)");
     FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(*,9910)
//      CALL HITR
pos17:
     if ((NWE <= 1) || (NSIM > 1)) goto pos20;
     sprintf(outline,"THE ASYMMETRIC MODEL REQUIRES ASYMMETRIC DATA.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"THE MODEL HAS BEEN CHANGED AS FOLLOWS");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     NWE = NWE - 2;
     if(NWE == 0) strcpy(CCC,"SIMPLE EUCLIDIAN MODEL (DEFAULT)");
     else strcpy(CCC,"INDIVIDUAL DIFFERENCES (INDSCAL) MODEL");
     sprintf(outline,"NWE - %d = %s",NWE,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(LOUT,218)NWE,CCC
//      CALL HITR

pos20:
     if((NWC != 2) || (NSIM >= 2)) goto pos22;
     sprintf(outline,"ROW CONDITIONAL DATA ARE NOT PERMITTED WITH SYMMETRIC DATA.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
     sprintf(outline,"THE DATA WILL BE TREATED AS MATRIX CONDITIONAL. (NWC=1)");
     FrmOutPut->RichOutPut->Lines->Add(outline);
//      CALL HITR
     NWC = 1;

pos22:
     if ((NWE > 1) && (NWC == 2))
     {
         sprintf(outline,"ROW CONDITIONAL DATA ARE NOT PERMITTED WITH THE ASYMMETRIC MODELS.");
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"ANALYSIS CONTINUES WITH MATRIX  CONDITIONAL DATA (NWC=1)");
         FrmOutPut->RichOutPut->Lines->Add(outline);
//      CALL HITR
         NWC = 1;
     }
     if ((NWE > 1) && (NDIM > 5)) NDIM = 5;
     if(NDIM == 0) NDIM = 2;
     if(NDIM > NDX)
     {
         sprintf(outline,"THE MAXIMUM DIMENSIONALITY MAY NOT EXCEED %d",NDX);
         FrmOutPut->RichOutPut->Lines->Add(outline);
//	CALL HITR
     }
     if(NDIM > NDX) NDIM = NDX;
     NDX = NDIM;
     NDXS = NDX * NDX;
     NDXP = NDX + 1;
     if ((NDMN <= 0) || (NDMN > NDIM)) NDMN = NDIM;
     if ((NDMN == 1) && (NWE >0))
     {
         sprintf(outline,"ONE-DIMENSIONAL WEIGHTED MODELS NOT PERMITTED.");
         FrmOutPut->RichOutPut->Lines->Add(outline);
         sprintf(outline,"ANALYSIS CONTINUES WITHOUT A ONE-DIMENSIONAL SOLUTION.");
         FrmOutPut->RichOutPut->Lines->Add(outline);
//	CALL HITR
     }
     if ((NDMN == 1) && (NWE > 0) && (NDIM == 1)) NDIM = 2;
     if ((NDMN == 1) && (NWE > 0)) NDMN = 2;
     sprintf(outline,"NDIM - NUMBER OF DIMENSIONS (MAXIMUM) %d and NDMN - NUMBER OF DIMENSIONS (MINIMUM) %d",NDIM,NDMN);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     ND = NDIM - NDMN + 1;
     NSC = 1;
     if (NWC == .0)NSC = 0;
//-----FOLLOWING TWO STATEMENTS ADDED FOR GEMSCAL 8/5/82
     if(IFLPDS == 1)
     {
          sprintf(outline,"NDIR - NUMBER OF GEMSCAL DIRECTIONS %d",NDIR);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     if (NNC == 1)strcpy(CCC,"NEGATIVE WEIGHTS PERMITTED");
     else
     {
          strcpy(CCC,"NEGATIVE WEIGHTS NOT PERMITTED");
	     NNC = 0;
     }
     sprintf(outline,"NNC  - NEGATIVE WEIGHTS PERMITTED %d = %s",NNC,CCC);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     if (PlotChk->Checked) NPT = 1;
     if (Plot2Chk->Checked) NPT = 2;
     INITX = 0;
     INITXC = 0;
     INITW = 0;
     INITWS = 0;

//     I/O OPTIONS
//     -----------
//     NDT      PRINT INPUT DATA
//                  =0 NO
//                  =1 YES
//     NPT      PLOT RESULTS
//                 =0 NO
//                  =1 PLOT SPACES AND OVERALL FIT
//                  =2 ALSO PLOT TRANSFORMATION AND FIT FOR EVERY
//                     PARTITION (CAN BE VERY MANY PAGES OF OUTPUT)
//     NPH      PUNCH RESULTS
//                  =0 DO NOT PUNCH
//                  =1 PUNCH DERIVED CONFIGURATION
//                  =2 PUNCH INITIAL AND DERIVED CONFIGURATION
//    INDATA   DATA INPUT UNIT
//                  =0   DATA READ FROM CARDS
//                  =N   DATA READ FROM UNIT N
//     INITX    INITIAL STIMULUS COORDINATES
//                  =0   COMPUTE
//                  =1   COMPUTE AND PRINT
//                  =2   READ AND PRINT
//                  =3   READ, PRINT AND FIX
//     INITXC   INITIAL COLUMN STIMULUS COORDINATES
//                  =0   COMPUTE
//                  =1   COMPUTE AND PRINT
//                  =2   READ AND PRINT
//                  =3   READ, PRINT AND FIX
//     INITW    INITIAL SUBJECT WEIGHTS
//                  =0   COMPUTE
//                  =1   COMPUTE AND PRINT
//                  =2   READ AND PRINT
//                  =3   READ, PRINT AND FIX
//     INITWS   INITIAL STIMULUS WEIGHTS
//                  =0   COMPUTE
//                  =1   COMPUTE AND PRINT
//                  =2   READ AND PRINT
//                  =3   READ, PRINT AND FIX
//     NOULB    UPPER AND LOWER BOUNDS TO ESTIMATE MISSING DATA
//                  =0   YES (DEFAULT)
//                  =1   NO  (ALSCAL 4 METHOD)
//     ICNSTR   CONSTRAIN MISSING DATA (NOT FULLY IMPLEMENTED)
//     DEBUG    FULL DEBUGGING OUTPUT

//-----NOULB, ICNSTR, AND DEBUG ADDED TO FOLLOWING STATEMENT 7/7/82

//----------------------------------------------------------------------

//     CALCULATION OF STORAGE REQUIREMENTS FOR ARRAYS
//     ----------------------------------------------

//    IN THIS SECTION WE CALCULATE THE NUMBER OF WORDS OF STORAGE
//  REQUIRED FOR VARIOUS ARRAYS USED BY THE PROBLEM. THIS IS DONE
//  BY ARRANGING THE ARRAYS END TO END AND ADDING THEIR LENGTHS
//  TOGETHER. IN THIS PROCESS AT EACH STEP THE STARTING PLACE OF
//  THE NEXT ARRAY IS CALCULATED BY ADDING THE LENGTH OF THE CURRENT
//  ARRAY TO ITS STARTING POINT. THUS THE STARTING POINT OF THE LAST
//  ARRAY PLUS ITS LENGTH GIVES THE SIZE OF THE STORAGE BLOCK NEEDED.
//     AS A CONVENTION THE STARTING POINT OF AN ARRAY IS GIVEN BY
//  THE NAME OF THE ARRAY PREFIXED BY J . THUS
//    JNEXT = JCURR + LCURR;
//  WHERE LCURR IS USUALLY AN EXPRESSION IN THE PARAMETERS OF THE PRO-
//  BLEM. IF MORE THAN ONE ARRAY IS TO SHARE THE SAME STORAGE THEN
//      JNEXT=JCURR + (MAXIMUM OF THE LENGTHS OF ARRAYS SHARING STO-
//   RAGE WITH CURR) SO AS NOT TO OVERWRITE THE NEXT ARRAY.
//     THE STARTING POINTS OF THE ARRAYS ARE STORED IN THE COMMON
//  BLOCK /STARTS/.
//     THE FINAL CALCULATED NUMBER OF WORDS OF STORAGE REQUIRED IS SAVED
//  IN NWORDS.

//----------------------------------------------------------------------

     JX = 1;
//   X IS USED AS A 2*NB*NS ARRAY IN INNER
//     JWA = JX + MAX0(NT,2 * NB * NS);
     JWD = JWA + NBNBNS;
//?     JXX = JWD + MAX0(NT,NDXS * NB,NBS * NDX,2778);
//   XX IS PASSED TO AM IN INIT AND USED THERE AS AN NS*NS ARRAY
//?     JDS = JXX + MAX0(NBS,NS * NS);
     JCFR = JDS + NBS;
     LCFR = NB * NDXP;
     JCFL = JCFR + LCFR;
//  CFL GETS PASSED TO XEQ IN INIT AND FROM THERE IN TWO PIECES
//  TO U AND V IN CJEIG. FOR THIS CALL THE LENGTH OF U+V IS 4*NS.
//  OTHERWISE CFL IS USED AS AN NB*NDXP ARRAY
//?     JW = JCFL + MAX0(4*NS,LCFR);
     JWS = JW + NS * NDXP;
     JZZ = JWS + LCFR;
//  ZZ GETS PASSED FROM INSWM TO CJEIG AS SCRATCH SPACE OF LENGTH 2*NB.
//  OTHERWISE ZZ IS USED AS A SQUARE (NDIM*(NDIM+1))/2 ARRAY.
//?     JU11 = JZZ + MAX0(2 * NB,pow(((NDIM + 1)* NDIM / 2),2));
     JU12 = JU11 + NDXS;
     JU22 = JU12 + NDXS;
     JUB1 = JU22 + NDXS;
     JUB2 = JUB1 + NDIM;
     JXN = JUB2 + NDIM;
     JTR = JXN + NDIM;
//  TR IS USED AS SCRATCH SPACE IN SEVERAL SUBROUTINES
//?     JFK = JTR + MAX0(NB,NS);
     JCV = JFK + NDXP * NDXP;
     LCV = ((NDIM + 1)* NDIM) / 2;
     JCW = JCV + LCV;
//       LCW=LCV
     JPHSUB = JCW + LCV;
     JPHSTI = JPHSUB + NS;
     JNDSR = JPHSTI + NB;
     JNAD = JNDSR;
     if ((NWC == 1) && (NDTYP == 4)) JNAD = JNDSR + NS;
     if ((NWC == 2) && (NDTYP == 4)) JNAD = JNDSR + NS * NB;
     JIX = JNAD;
     if (NWC == 1) JIX = JNAD + NS;
     if (NWC == 2) JIX = JNAD + NS * NB;
//-----IX, IY, AND IZ CHANGED TO INTEGER 7/8/82
//     THUS, THEIR LENGTHS ARE NO LONGER HALF OF THEIR DIMENSIONS.
     JIY = JIX + (NT+1);
     JIZ = JIY + (NDMX+1);
//-----NEXT STATEMENTS ADDED FOR EQUIVALENCE TO SAS VERSION 7/8/82
     JFTLN = JIZ + 1;
     if (NDTYP != 3) goto pos5100;
     if (NWC == 1) JFTLN = JIZ + (NS + 1);
     if (NWC == 2) JFTLN = JIZ + (NB * NS + 1);
//-----SPACE FOR FTLN NOT BEING USED IN VERSION 4.04 AND UP
pos5100:
     JDIST = JFTLN + 2;
     if ((NDTYP != 2) || (NDEG != 1) || (NWC == 0)) goto pos510;
     if (NWC == 1) JDIST = JFTLN + NS * 2;
     if (NWC == 2) JDIST = JFTLN + NS * NB * 2;
//-----FOLLOWING SEVEN STATEMENTS ADDED FOR GEMSCAL 8/5/82
pos510:
     if (IFLPDS != 1) goto pos7381;
     JPIJP = JDIST + NBS;
     JXK = JPIJP + NBS;
     NWORDS = JXK + NB * 6;
//  RETURN
pos7381:
     JPIJP = JDIST;
     JXK = JDIST;
     NWORDS = JDIST;
//  RETURN
//----------------------------------------------------------------------
pos902:
     ShowMessage("NUMBER OF ROWS MUST EQUAL NUMBER OF COLUMNS FOR NON-RECTANGULAR DATA.");
     return;
pos903:
     ShowMessage("NUMBER OF STIMULI LESS THAN 3");
     return;
pos904:
     ShowMessage("TOTAL NUMBER OF MATRICES LESS THAN 1");
     return;
pos905:
     ShowMessage("NORMAL END OF JOB.");
     return;
pos1:
     if(EOJ == true) goto pos99;
     if(PRSIZE > MAXSIZ) goto pos999;
     for (int I = 1; I <= PRSIZE; I++)//  DO 10 I=1,PRSIZE
pos10:
     AREA[I] = 0.0;
     sprintf(outline,"Maximum problem size = %d words, Required problem size = %d",
              MAXSIZ, PRSIZE);
     FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(LOUT,20) MAXSIZ,PRSIZE
//   20 FORMAT(/' MAXIMUM PROBLEM SIZE :',I8,' WORDS',
//     +/       ' REQUIRED PROBLEM SIZE:',I8)
     DRIVER(AREA,EOJ);
     if(EOJ == false) goto pos1;
     goto pos99;
pos999:
     sprintf(outline,"ALSCAL fatal error: Not enough memory available.");
     FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(LOUT,9001)PRSIZE,PRSIZE
//      WRITE(*,9001)PRSIZE,PRSIZE
// 9001 FORMAT(/' ALSCAL FATAL ERROR:  NOT ENOUGH MEMORY AVAILABLE.'/
//     1' *****RECOMPILE PROGRAM SO THAT THE MAIN ROUTINE HAS ITS DIMENSIO
//     2N AND DATA STATEMENTS CHANGED TO READ:'/
//     3/'          DIMENSION AREA(',I7,')'/
//     4 '          DATA MAXSIZ/',I7,'/'/
//     5/' *****RUN ABORTED.')

//-PC-------------------------
pos99:
     FrmOutPut->RichOutPut->Lines->Add("ALSCAL END");
//      WRITE (*,9999)
// 9999 FORMAT (/' ALSCAL END')
//----------------------------
//      STOP
//      END
}

//**********************************************************************
void __fastcall TAlscaleForm::DRIVER(double *AREA, bool EOJ)
{
     int IRET;

//     =================

//COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/08/82

//     THIS SUBROUTINE CONTROLS THE FLOW OF THE PROGRAM

//   THE ARRAY "AREA" IS A BLOCK OF MEMORY WHICH IS ALLOCATED BY THE
//   MAIN ROUTINE, AND IS SUBDIVIDED HERE FOR USE IN THE SUBROUTINES

//----------------------------------------------------------------------
//      int EOJ;
      char COPR[72];
      char outline[101];
//      double *AREA;
//----------------------------------------------------------------------
//     INTEGER*2 IX(8000),IY(3000),IZ(525),ITEM(55,101)
//     DIMENSION TITLE(20),FMT(20)
//     DIMENSION X(8000),WA(8000),WD(8000)
//     DIMENSION UA(875),U11(36),U12(36),U22(36),R(36),UB1(6),
//    1UB2(6),BK(6),WK(6),WK2(6),WK3(36),WK4(6),XN(6)
//     DIMENSION XX(1600),CFR(280),CFL(280),W(280),TR(40),FK(49)
//     DIMENSION WS(280),DS(1600),ZZ(225),CV(15),CW(15),ZX(280)
//     DIMENSION XEQ(160),NDSB(35),NDSR(525),NAD(525),FMRR(40)
//     EQUIVALENCE (UA(1),U11(1)),(UA(37),U12(1)),
//    1(UA(73),U22(1)),(UA(109),R(1)),(UA(145),UB1(1)),(UA(151),UB2(1)),
//    2(UA(157),BK(1)),(UA(163),WK(1)),(UA(169),WK2(1)),(UA(175),WK3(1)),
//    3(UA(211),WK4(1)),(UA(217),XN(1))
//     EQUIVALENCE (WD(1),ITEM(1,1)),(CFL(1),XEQ(1))
//     EQUIVALENCE (TR(1),FMRR(1)),(ZZ(1),ZX(1))
//----------------------------------------------------------------------
/*
      COMMON /CCOPR/COPR
     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
C    +       /BLOCK3/ TITLE,FMT
     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
     +       /STARTS/JX,JWA,JWD,JXX,JDS,JCFR,JCFL,JW,JWS,JZZ,JTR,JFK,
     + JCV,JCW,JU11,JU12,JU22,JUB1,JUB2,
     + JXN,JPHSUB,JPHSTI,JIX,JIY,JIZ,JNDSR,JNAD,
     + JFTLN,JDIST,JPIJP,JXK
C-----JFTLN AND JDIST ADDED TO THE ABOVE STATEMENT 7/8/82
C-----JPIJP AND JXK ADDED 5MAY83 FWY
*/
     STEP1(IX, X, WA, XX, DS, NAD, IER);
     if(IRET == 1)
     {
         EOJ = true;
	    return;
     }
     NPARM = NB;
     if ((NWE == 1) || (NWE == 3)) NPARM = NPARM + NS;
     if(NWE > 1) NPARM = NPARM + NB;
     for (int IJKL = 1; IJKL <= ND; IJKL++)
     {
         NP = NPARM * (NDXP - IJKL);
         if (NP > NT) goto pos7;
         if(NT >= 2.5 * NP) goto pos9;
         if(NDTYP < 3) goto pos9;
         sprintf(outline," ALSCAL WARNING: %d parameters may be too large or %d observations may be too small.",
             NP,NT);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         goto pos9;
pos7:
         sprintf(outline,"ALSCAL FATAL ERROR: THE NUMBER OF PARAMETERS %d > THE NUMBER OF OBSERVATIONS %d.",
                 NP,NT);
         return;

pos9:
/*         STEP2(AREA(JIX),AREA(JIY),AREA(JIZ),AREA(JX),AREA(JWA),
            AREA(JWA),AREA(JWD),AREA(JCFR),AREA(JCFL),AREA(JW),AREA(JTR),
            AREA(JFK),AREA(JXX),AREA(JWS),AREA(JDS),AREA(JZZ),
            AREA(JCV),AREA(JCW),AREA(JNDSR),AREA(JNAD),IJKL);

         STEP3(AREA(JIX),AREA(JIY),AREA(JIZ),AREA(JX),AREA(JWD),
            AREA(JWA),AREA(JWA),AREA(JWA),AREA(JU11),AREA(JU12),AREA(JU22),
            AREA(JUB1),AREA(JUB2),AREA(JXN),AREA(JXX),AREA(JCFL),AREA(JW),
            AREA(JTR),AREA(JFK),AREA(JWS),AREA(JNDSR),AREA(JNAD),IJKL,IRE);
         if(IRE == 1) goto pos10;

         STEP3A(AREA(JIX),AREA(JIY),AREA(JIZ),AREA(JX),AREA(JWA),
            AREA(JWD),AREA(JXX),AREA(JCFL),AREA(JW),
            AREA(JWS),AREA(JNDSR),AREA(JNAD),AREA(JPHSUB),AREA(JPHSTI));

         STEP4(AREA(JX),AREA(JWA),AREA(JXX),AREA(JCFL),
            AREA(JW),AREA(JTR),AREA(JWS),
            AREA(JDIST),AREA(JDS),AREA(JPIJP),AREA(JXK),AREA(JTR),IJKL);
*/
//-----PRECEEDING LINE ADDED 5MAY83 FWY
pos10:
     } // next j
}
//---------------------------------------------------------------------

void __fastcall TAlscaleForm::STEP1(int *IX, double *X, double ***WA, double **XX,
                      double **DS, int **NAD, int IER)
{
//     DATA INPUT        ROUTINE
//      int IX[NT];
//      double X[NT],WA[NB][NB][NS],XX[NB][NB],DS[NB][NB],NAD[NS][NB];
      GetDblVecMem(X,NT+1);
      GetDblCubeMem(WA,NB+1,NB+1,NS+1);
      GetDblMatMem(XX,NB+1,NB+1);
      GetDblMatMem(DS,NB+1,NB+1);
      GetIntMatMem(NAD,NS+1,NB+1);
      GetIntVecMem(IX,NT+1);
      char TITLE[80],COPR[72];
/*
      COMMON /CCOPR/COPR
     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
     +       /BLOCK3/ TITLE,FMT
     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
*/
//-----THE FOLLOWING THREE STATEMENTS ADDED 7/9/82
//      double CUT, STMIN, AX;
//      int DEBUG,ICNSTR,NOULB;
      char outline[101];

//      COMMON /PRMBLK/CUT,STMIN,DEBUG,ICNSTR,NOULB

//  X CONTAINS THE ACTIVE DATA ( WITH THE MISSING DATA FLAGGED)
//  IN STANDARD ORDER WITH SIMILARITIES CONVERTED TO DISSIMILARITIES
//  AND SCALED TO KNOWN UNITS.
//  WA IS THE SAME AS X EXCEPT
//    1) HAS MEANS IN PLACE OF MISSING DATA
//    2) HAS ADDITIVE CONSTANT ESTIMATED
//    3) IS ALWAYS SYMMETRIC
//  DS CONTAINS THE SUM,OVER SUBJECTS, OF INFORMATION IN X
//  IX CONTAINS THE MISSING DATA PATTERN 1=MISSING, 0=ACTIVE
//  XX IS USED AS TEMPORARY SPACE TO CONSTRUCT EACH MATRIX OF
//        DATA TO BE USED BY THE INITIALIZATION ROUTINES.
//        XX IS PROCESSED SO THAT:
//           1) MISSING DATA ESTIMATED BY MEAN UPPER-LOWER BOUND
//           2) ASYMMETRIC DATA ARE SYMMETRIZED
//           3) SIMILARITIES ARE MADE DISSIMILARITIES
//           4) CONDITIONAL DATA ARE NORMALIZED
//  WA CONTAINS THE SAME INFORMATION AS XX, EXCEPT
//           1) FOR ALL MATRICES
//           2) ADDITIVE CONSTANT IS ESTIMATED
//           3) RESULT IS SQUARED

//  CERTAIN IMPORTANT DATA FLAGS AND THEIR VALUES ARE:
//      NSIM: 0,1=SYM 2,3=ASYM 4,5=RECT EVEN=DISSIM ODD=SIMILARITIES
//      NWC:  0=UNCONDITIONAL 1=MATCON 2=ROWCON

/*      IF(NDT.EQ.1) THEN
	CALL PAGE(LOUT)
	WRITE(LOUT,212)
  212   FORMAT(//' INPUT DATA')
      ENDIF
*/
      NAB = 0;
      NX = 2;
      if(NSIM > 1) NX = 1;
      I1 = NB;
      for (int I = NX; I <= NB; I++)
      {
          if(NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++)
          {
              DS[I][J] = 0.0;
          }
      }
      NN = 0;
      IER = 0;

// Read the XX matrix in from the grid

/*
      REWIND NDPP
      DO 10 L=1,NS
C-----THE FOLLOWING TWO STATEMENTS ADDED 7/8/82
      IF(DEBUG.NE.0)WRITE(LOUT,4040)
 4040 FORMAT(/' RAW DATA AS READ FROM DATA SET')
*/
      NTEMP2 = 0;
      XX[1][1] = 0.0;
      for (int I = NX; I <= NB; I++) //DO 11 I=NX,NB
      {
//      NSIM: 0,1=SYM 2,3=ASYM 4,5=RECT EVEN=DISSIM ODD=SIMILARITIES
          if (NSIM <= 1) I1 = I - 1;
          if ((NSIM > 3) && (I <= NCOL)) goto pos7;
          J1 = I1;
          if(NSIM > 3) J1 = NCOL;
          for (int J = 1; J <= J1; J++)
          {
              XX[I][J] = StrToFloat(MainForm->Grid->Cells[J][I]);
          }
//          READ(INDATA,FMT)(XX(I,J),J=1,J1)
/*
C-----THE FOLLOWING TWO STATEMENTS ADDED 7/8/82
          IF(DEBUG.NE.0)WRITE(LOUT,40)(XX(I,J),J=1,J1)
   40 FORMAT(6X,10G12.4)
*/
          if(NSIM < 4)goto pos9;
          J1 = J1 + 1;
          for (int J = J1; J <= I1; J++) // DO 6 J=J1,I1
          {
               XX[I][J] = CUT - 1.0;
          } // 6
          goto pos9; //GOTO 9
pos7:
          for (int J = 1; J <= NB; J++) //DO 8 J=1,NB
          {
              XX[I][J] = CUT - 1.0;
          } // 8
pos9: //    9 WRITE(NDPP)(XX(I,J),J=1,I1)
          if (NSIM > 1) continue; // GOTO 11
          for (int J = 1; J <= I1; J++) //DO 12 J=1,I1
          {
              XX[J][I] = XX[I][J];
          } // 12
      } //   11 CONTINUE
pos21:
      if (NDT == 1) // write out matrix if requested
      {
//         WRITE(LOUT,215) L
//         215 FORMAT(/' MATRIX',I4/)
//         IF(NSIM.LE.1)CALL OUTS(X,NB,1,-1,XX)
//         IF(NSIM.GT.1)CALL OUTA(XX,NB,-1)
       }
//     CHECK FOR MISSING DATA AND REPLACE BY MEANS

pos13:
      for (int I = 1; I <= NB; I++) XX[I][I] = 0.0;
      FMR = 0.0;
      N = NN;
      IFLXER = 0;
//      IF(DEBUG.GT.0)WRITE(LOUT,4848)
// 4848 FORMAT(/' MISSING DATA PATTERN')
      for (int I = NX; I <= NB; I++) // DO 2337 I=NX,NB
      {
          NTEMP1 = 0;
          double T = 0.0;
          int K = N;
          if(NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++) // DO 337 J=1,I1
          {
              N = N + 1;
              if ((XX[I][J] >= CUT) || (I == J)) goto pos338;
              IX[N] = 1;
              if ((ICNSTR != 1) || (NSIM < 4))continue;
              if ((I > NCOL) && (J <= NCOL)) continue;
              IX[N] = 0;
              continue; // goto 337
pos338:
              NTEMP1 = NTEMP1 + 1;
              T = T + XX[I][J];
              IX[N] = 0;
pos337:   }
          if ((NTEMP1 == 1) && (NWC == 2)) IFLXER = 1;
          if ((NTEMP1 == 0) && (NWC == 2))
          {
             sprintf(outline,"ALSCAL WARNING: ALL DATA MISSING FOR MATRIX %d STIMULUS %d",L,I);
             ShowMessage(outline);
          }
          int NTEMP2 = NTEMP2 + NTEMP1;
          FMR = FMR + T;
          if (NWC == 2) NAD[L][I] = NTEMP1;
          if (NWC != 2) continue;
          if ((NWC == 2) && (NTEMP1 == 1)) continue;
          T = T / (NTEMP1 - 1);
          for (int J = 1; J <= I1; J++)
          {
              K = K + 1;
              if (IX[K] != 0) XX[I][J] = T;
          }
      } // 2337 CONTINUE
//      IF(DEBUG.GT.0)WRITE(LOUT,4789)(IX(IIIIII),IIIIII=1,N)
// 4789 FORMAT(10(1X,10I1))
      int NMISS = NC2 - NTEMP2;
      if (NSIM > 3) NMISS = NMISS - NCOL * NB - pow((NB - NCOL),2) + NB;
      if (NMISS > 0)
      {
//         WRITE(LOUT,5318)L,NMISS
// 5318 FORMAT(/' ALSCAL MESSAGE:  MATRIX', I4,' HAS',I5,' MISSING OBSERVA
//     1TIONS.')
//         WRITE(*,5318)L,NMISS
//         CALL HITR
      }
      if (NTEMP2 == 0) goto pos901;
      if (IER != 0) goto pos10;
      NAB = NAB + NTEMP2;
      if (NSIM <= 1) FMR = FMR / NTEMP2;
      if (NSIM > 1) FMR = FMR / (NTEMP2-NB);
      if ((NWC == 2) && (LXER == 0)) goto pos341;
      if (NWC == 2) goto pos342;
      if (NWC == 1) NAD[L][1] = NTEMP2;
      if ((NMISS == 0) && (NSIM < 4)) goto pos341;
      N = NN;
      for (int I = NX; I <= NB; I++) //DO 339 I=NX,NB
      {
          if (NSIM <= 1)I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 339 J=1,I1
          {
              N = N + 1;
              if (IX[N] != 0) XX[I][J] = FMR;
              if ((IX[N] != 0) && (NSIM <= 1)) XX[J][I] = FMR;
          }
      }
      goto pos341;
pos342:
      N = NN;
      for (int I = 1; I <= NB; I++) //DO 343 I=1,NB
      {
          for (int J = 1; J <= NB; J++) //DO 343 J=1,NB
          {
              N = N + 1;
              if (NAD[L][I] > 1) continue;
              if (IX[N] != 0) XX[I][J] = FMR;
          }
      } //pos343:  CONTINUE

//     if  DATA ARE SIMILARITY (NSIM=1 OR 3) CONVERT THEM
//     INTO DISSIMILARITY

pos341:
      if (NSIM / 2 * 2 == NSIM) goto pos114;
      if (NWC == 2) goto pos2005;
      AX = XX[NB][1];
      for (int I = NX; I <= NB; I++)// DO 115 I=NX,NB
      {
          if (NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 115 J=1,I1
          {
              if (XX[I][J] > AX) AX = XX[I][J];
          }
      } // 115
      for (int I = NX; I <= NB; I++) //DO 117 I=NX,NB
      {
          if (NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++)  //DO 116 J=1,I1
              XX[I][J] = AX - XX[I][J];
          XX[I][I] = 0.0;
      }
      XX[1][1] = 0.0;
      goto pos114;
pos2005:
      for (int I = 1; I <= NB; I++) //DO 2006 I=1,NB
      {
          AX = XX[I][1];
          for (int J = 1; J <= NB; J++) //DO 2007 J=1,NB
              if (XX[I][J] > AX) AX = XX[I][J];
          for (int J = 1; J <= NB; J++) //DO 2008 J=1,NB
              XX[I][J] = AX - XX[I][J];
          XX[I][I] = 0.0;
      } // 2006 CONTINUE
//     INITIAL SCALING WITHIN SUBJECT
pos114:
/*
      if (DEBUG == 0)  goto  3200
      WRITE(LOUT,3399)
 3399 FORMAT(/' DATA WITH MISSING ESTIMATED BY ROW OR MATRIX MEAN')
      DO 3388 I=1,NB
 3388 WRITE(LOUT,6789)(XX(I,J),J=1,NB)
*/
pos3200:
      AX = 1.0;
      if (NSC == 0) goto pos5091;
      AX = 0.0;
      for (int I = NX; I <= NB; I++)  //DO 5092 I=NX,NB
      {
          if (NSIM <= 1)I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 5092 J=1,I1
              AX = AX + XX[I][J] * XX[I][J];
      }
      AX =sqrt(AX / NC2);
      for (int I = NX; I <= NB; I++) //DO 5093 I=NX,NB
      {
          if (NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 5093 J=1,I1
              XX[I][J] = XX[I][J] / AX;
      }
      if (NSIM > 1) goto pos5091;
      for (int I = NX; I <= NB; I++)  //DO 5094 I=NX,NB
      {
          I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 5094 J=1,I1
              XX[J][I] = XX[I][J];
      } // 5094
//     STORE ORIGINAL DATA
pos5091:
      for (int I = NX; I <= NB; I++) //DO 4002 I=NX,NB
      {
          if (NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 4002 J=1,I1
              DS[I][J] = DS[I][J] + XX[I][J];
      }
/*
      if (DEBUG == 0)  goto  3210
      WRITE(LOUT,3377)
 3377 FORMAT(/' NORMALIZED DATA AND MEANS')
      DO 3366 I=1,NB
 3366 WRITE(LOUT,6789)(XX(I,J),J=1,NB)
*/
pos3210:
      N = NN;
      for (int I = NX; I <= NB; I++) //DO 2009 I=NX,NB
      {
          if (NSIM <= 1) I1 = I - 1;
          for (int J = 1; J <= I1; J++) //DO 2009 J=1,I1
          {
              N = N + 1;
              X[N] = XX[I][J];
              if (IX[N] != 0) X[N] = BIG;
          }
      } // 2009 CONTINUE

//     CHECK TO SEE if  MISSING DATA EXIST OR IT THE
//     DATA ARE RECTANGULAR (IMPLIED MISSING DATA).  if  SO
//     ESTIMATE BY MEAN OF UPPER AND LOWER BOUNDARIES
//     GENERATED BY LINE OF SIGHT METHOD.

      if ((NSIM > 3) || (NMISS > 0)) goto pos7200;
      if (NSIM <= 1) goto pos3245;

//     COME HERE WHEN THE DATA ARE ASYMMETRIC AND COMPLETE
//     TO GENERATE SYMMETRIC INICON DATA.

      for (int I = 2; I <= NB; I++) //DO 7150 I=2,NB
      {
          IM1 = I - 1;
          for (int J = 1; J <= IM1; J++) //DO 7150 J=1,IM1
          {
              XX[I][J] = (XX[I][J] + XX[J][I]) / 2.0;
              XX[J][I] = XX[I][J];
          }
      }  // 7150
      goto pos3245;

//     COME HERE WHEN THERE IS MISSING DATA OR WHEN THE
//     DATA ARE RECTANGULR TO FLAG THE MISSING CELLS.

pos7200:
      N = NN;
      for (int I = NX; I <= NB; I++)  //DO 135 I=NX,NB
      {
          if (NSIM <= 1) I1 = I-1;
          for (int J = 1; J <= I1; J++)  //DO 135 J=1,I1
          {
              N = N + 1;
              if (IX[N] == 0) continue;
              XX[I][J] = CUT - XX[I][J];
              if (NSIM <= 1) XX[J][I] = XX[I][J];
          }
      } //  135 CONTINUE
      if (NSIM < 4) goto pos130;
      NCOLP1 = NCOL + 1;
      for (int I = NCOLP1; I <= NB; I++) // DO 120 I=NCOLP1,NB
          for (int J = 1; J <= NCOL; J++)  //DO 120 J=1,NCOL
              XX[J][I] = XX[I][J]; // 120

//     SYMMETRIZE THE ASYMMETRIC MATRIX

pos130:
/*  130 if (DEBUG == 0) goto  3211
      WRITE(LOUT,3370)
 3370 FORMAT(/' DATA AFTER MISSING FLAGGED')
      DO 3360 I=1,NB
 3360 WRITE(LOUT,6789)(XX(I,J),J=1,NB)
*/
pos3211:
      if (NSIM <= 1) goto pos2010;
      NA = 2;
      if (NSIM >= 4) NA = NCOL + 2;
      NC = NA - 1;
      for (int I = NA; I <= NB; I++) //DO 2011 I=NA,NB
      {
          IMI = I - 1;
          for (int J = NC; J <= IMI; J++) //DO 2011 J=NC,IMI
          {
              if ((XX[I][J] < CUT) || (XX[J][I] < CUT)) goto pos2002;
pos2001:
              XX[I][J] = (XX[I][J] + XX[J][I]) * 0.5;
              XX[J][I] = XX[I][J];
              goto  pos2011;
pos2002:
              if ((XX[I][J] < CUT) && (XX[J][I] < CUT)) goto pos2001;
              if (XX[I][J] < CUT) XX[I][J] = XX[J][I];
              if (XX[J][I] < CUT) XX[J][I] = XX[I][J];
          }
pos2011:
      } //2011 CONTINUE
pos3821:
/*
      if (DEBUG == 0) goto  2010
      WRITE(LOUT,1355)
 1355 FORMAT(/' SYMMETRIC NORMALIZED DATA')
      DO 232 I=1,NB
  232 WRITE(LOUT,6789)(XX(I,J),J=1,NB)
 6789 FORMAT(1X,15F8.2)
*/
//     UNLESS THE USER HAS REQUESTED, VIA THE NOULB PARAMETER,
//     REPLACE MISSING DATA ESITMATES WITH MEAN OF UPPER AND
//     LOWER BOUNDS ON DISTANCES WHEREVER POSSIBLE.
//     if  NOT POSSIBLE OR if  REQUESTED USE MEAN CALCULATED ABOVE.

pos2010:
      if (NOULB != 0) goto pos1492;
      for (int I = 2; I <= NB; I++)  //DO 150 I=2,NB
      {
          IM1 = I - 1;
          for (int J = 1; J <= IM1; J++) //DO 150 J=1,IM1
          {
              if (XX[J][I] > CUT) goto pos150;
              MISALL = 1;
              BIGDif = 0.0;
              SMLSUM = 10.0E10;
              for (int II = 1; II <= NB; II++) //DO 330 II=1,NB
              {
                  if ((II == I) || (II == J)) continue;
                  IA = I;
                  IB = J;
                  IC = II;
                  ID = II;
                  if (IC < IA)
                  {
                     IA = II;
                     IC = I;
                  }
                  if (ID < IB)
                  {
                     IB = II;
                     ID = J;
                  }
                  if ((XX[IC][IA] <= CUT) || (XX[ID][IB] <= CUT)) continue;
                  MISALL = 0;
                  SUM = XX[IC][IA] + XX[ID][IB];
                  Dif =fabs(XX[IC][IA] - XX[ID][IB]);
                  if (SMLSUM > SUM) SMLSUM = SUM;
                  if (BIGDif < Dif )BIGDif = Dif;
              } // 330 CONTINUE
              if (MISALL == 0) XX[J][I] = (SMLSUM + BIGDif )* 0.5;
          }
pos150:
      }  //150 CONTINUE

pos1492:
      for (int I = 2; I <= NB; I++)  //DO 160 I=2,NB
      {
          IM1 = I - 1;
          for (int J = 1; J <= IM1; J++) //DO 160 J=1,IM1
          {
              if (XX[J][I] < CUT) XX[J][I] = CUT - XX[J][I];
              XX[I][J] = XX[J][I];
          }
      } // 160
      if (DEBUG == 0) goto pos3245;
/*
      WRITE(LOUT,1354)
 1354 FORMAT(/' MISSING DATA NOW ESTIMATED BY MEAN U/L BOUNDS')
      DO 233 I=1,NB
  233 WRITE(LOUT,6789)(XX(I,J),J=1,NB)
//-----END OF ADDED SECTION 7/8/82
*/
//     ESTIMATION OF ADDITIVE CONSTANT

pos3245:
      ALPH1 = 0.0;
      if (NDTYP == 1) goto pos19;
      ALPH1 = XX[2][1];
      for (int I = 2; I <= NB; I++) //DO 14 I=2,NB
      {
          IMI = I - 1;
          for (int J = 1; J <= IMI; J++) // DO 14 J=1,IMI
          {
              if (XX[I][J] < ALPH1) ALPH1 = XX[I][J];
          }
      } // 14
      for (int I = 1; I <= NB; I++) // DO 15 I=1,NB
      {
          for (int J = 2; J <= NB; J++) //DO 15 J=2,NB
          {
              if (J != I)
              {
                 J1 = J - 1;
                 for (int K = 1; K <= J1; K++) // DO 16 K=1,J1
                 {
                     if (K == I) continue;
                     TRAN = XX[I][J] + XX[I][K] - XX[J][K];
                     if (TRAN < ALPH1) ALPH1 = TRAN;
                 } // 16 CONTINUE
              }
          }
      } // 15 CONTINUE

pos19:
      WA[1][1][L] = 0.0;
      for (int I = 2; I <= NB; I++) //DO 18 I=2,NB
      {
          WA[I][I][L] = 0.0;
          IMI = I - 1;
          for (int J = 1; J <= IMI; J++) //DO 18 J=1,IMI
          {
              WA[I][J][L] = pow((XX[I][J] - ALPH1),2);
              WA[J][I][L] = WA[I][J][L];
          }
      } // 18
      if (DEBUG == 0) goto pos10;
/*
      WRITE(LOUT,1382)
 1382 FORMAT(/' DATA SQUARED WITH ADDITIVE CONSTANT ESTIMATED',
     1' (INICON DATA)')
      DO 288 I=1,NB
  288 WRITE(LOUT,6789)(WA(I,J,L),J=1,NB)
       goto  10
  */
pos901:
/*
  901 if (IER == 0)WRITE(LOUT,9900)
      WRITE(LOUT,9002)L
9002  FORMAT(8X,' ALL DATA MISSING FOR MATRIX',I4)
 9900 FORMAT(/' ALSCAL FATAL ERROR:  COMPUTATIONS TERMINATED.')
      WRITE(LOUT,9001)L,I
      IER=1
*/
pos10:
      NN = NN + NC2;
      if (IER != 0) return;
//      REWIND NDP
//      WRITE(NDP)X
//      WRITE(NDP) WA
//      REWIND NDP
      if (ICNSTR == 1) NSIM = NSIM - 2;
      return;
}
//***********************************************************************

void __fastcall TAlscaleForm::OUTS(double *X, int NB, int NS, int NC, double **XX)
{
//     ===============
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 11/13/78
// EQUIVALENT TO ALSCAL82 VERSION (7/9/82)
//     SYMMETRIC MATRIX OUTPUT ROUTINE
//     PRINTS LOWER TRIANGULAR HALF MATRIX
//    ================
//      DIMENSION X(1),XX(NB,1)
      char COPR[72];
      char value[21];
      char outline[101];

//      COMMON /CCOPR/COPR
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA

      int N = 0;
      for (int I = 1; I <= NB; I++) XX[I][I] = 0.0;
      for (int M = 1; M <= NS; M++) //DO 20 M=1,NS
      {
          if (NC <= 0) goto pos12;
          sprintf(outline,"   MATRIX%5d",M);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          for (int I = 2; I <= NB; I++) // DO 11 I=2,NB
          {
              int I1 = I - 1;
              for (int J = 1; J <= I1; J++) //DO 11 J=1,I1
              {
                  N = N + 1;
                  XX[I][J] = X[N];
                  XX[J][I] = X[N];
              }
          } // 11
pos12:
          for (int I1 = 1; I1 <= NB; I1++) // DO 10 I1=1,NB,10
          {
//?              I2 = MIN0(NB,I1+9);
              strcpy(outline,"");
              for (int K = I1; K <= I2; K++)
              {
                  sprintf(value,"%8d",K);
                  strcat(outline,value);
              }
              FrmOutPut->RichOutPut->Lines->Add(outline);
              for (int L = I1; L <= NB; L++) //DO 10 L=I1,NB
              {
//?                  I3 = MIN0(L,I2);
                  strcpy(outline,"");
                  for (int K = I1; K <= I3; K++)
                  {
                      sprintf(value,"%8.3f",XX[L][K]);
                      strcat(outline,value);
                  }
                  FrmOutPut->RichOutPut->Lines->Add(outline);
              }
          } // 10
      } //  20 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::OUTA(double *X, int NB, int NFL)
{
//     ===============
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 11/13/78
// EQUIVALENT TO ALSCAL82 VERSION (7/9/82)

//     ASYMMETRIC AND RECTANGULAR MATRIX OUTPUT ROUTINE
//-----------------------------------------------------------------------

//      DIMENSION  X(NB,NB,1)
      char COPR[72];
      char value[21];
      char outline[101];

//      COMMON /CCOPR/COPR
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA

      int NS = abs(NFL);
      int NA = 1;
      if (NSIM > 3) NA = NCOL + 1;
      int NC = NB;
      if (NSIM > 3) NC = NCOL;
      for (int M = 1; M <= NS; M++) //DO 10 M=1,NS
      {
          if(NFL > 0)
          {
             sprintf(outline,"MATRIX %d",M);
             FrmOutPut->RichOutPut->Lines->Add(outline);
          }
          for (int I1 = 1; I1 <= NC; I1++) // DO 10 I1=1,NC,10
          {
//              I2 = MIN0(NC,I1+9);
              (NC < I1+9) ? I2 = NC : I2 = I1+9;
              strcpy(outline,"");
              for (int K = I1; K <= I2; K++)
              {
                  sprintf(value,"%8d",K);
                  strcat(outline,value);
              }
              FrmOutPut->RichOutPut->Lines->Add(outline);
              int N = 0;
              for (int L = NA; L <= NB; L++) // DO 10 L=NA,NB
              {
                  N = N + 1;
                  strcpy(outline,"");
                  if(NFL < 0)
                  {
                     for (int K = I1; K <= I2; K++)
                     {
                         sprintf(value,"%8.3f",X[L+K+M]);
                         strcat(outline,value);
                     }
                     FrmOutPut->RichOutPut->Lines->Add(outline);
                  }
                  else
                  {
                     for (int K = I1; K <= I2; K++)
                     {
                         sprintf(value,"%8.3f",X[K+L+M]);
                         strcat(outline,value);
                     }
                     FrmOutPut->RichOutPut->Lines->Add(outline);
                  }
              } // next L
          } // next I1
      } // 10 Next M
}
//*********************************************************************
/*
void __fastcall TAlscaleForm::STEP2(int *IX; int *IY; int *IZ; double *X;
                      double ***WA; double *WC; double *WD;
                      double **CFR; double **CFL; double **W;
                      double *TR; double **FK; double **XX;
                      double **WS; double **DS; double **ZZ;
                      double *CV; double *CW; int **NDSR; int **NAD;
                      int IJKL)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/21/82

//  THIS ROUTINE OBTAINS STARTING CONFIGURATIONS AND INITIAL OPTIMAL
//  SCALING TO INITIATE THE ITERATIVE PROCESS

//    WA & WC  REFER TO THE SAME ARRAY IN THE CALLING ROUTINE.
//    THIS  ARRAY  IS  PASSED IN AS DIFFERENT PARAMETERS TO PERMIT
//    REFERENCING THE ARRAYS USING DIFFERENT SHAPE PARAMETERS.

//-----------------------------------------------------------------------

      double T,TT,TRT,RNB,RNS,RNBS;
      char TITLE[80], COPR[72]; outline[101];

//-----THE FOLLOWING STATEMENT WAS CHANGED FROM INTEGER*2 7/8/82
//      INTEGER IX(NT),IY(1),IZ(1)
//      DIMENSION X(NT),WA(NB,NB,NS),WC(1),WD(1),XX(NB,NB)
//      DIMENSION CFR(NB,1),CFL(NB,1),W(NS,1),TR(1),FK(NDXP,1)
//      DIMENSION WS(NB,1),DS(NB,NB),ZZ(1,1),CV(1),CW(1)
//   THE ARRAY ZZ IS NOT USED IN STEP2 BUT PASSED THROUGH TO INSWM
//   AND ITS DIMENSIONS HERE ARE DUMMY.
//      DIMENSION NDSR(NS,NB),NAD(NS,NB)
//      CHARACTER*80,TITLE,FMT,COPR*72
//      COMMON /CCOPR/COPR
//-----THE FOLLOWING THREE STATEMENTS ADDED 7/14/82
//      double CUT,STMIN;
//      int DEBUG,ICNSTR,NOULB;
//      COMMON /PRMBLK/CUT,STMIN,DEBUG,ICNSTR,NOULB
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//     +       /BLOCK3/ TITLE,FMT
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
//     +       /INICON/INITX,INITW,INITWS,INITXC

//----------------------------------------------------------------------

//     COMPUTE INITIAL COORDINATES AND WEIGHTS
//     ---------------------------------------

      ISTFOR = 1;
      if(NSIM > 3)ISTFOR = 2;
      RNS=1./NS
      RNB=1./NB
      RNBS=1./NBS
      STRSO=BIG
      NDIM=NDXP-IJKL

//     IF DESIRED, READ INITIAL STIMULUS COORDINATES

      LLL=0
      IF(NSIM.LT.4)GOTO 3200
      IF(INITX.GE.2.AND.INITXC.GE.2)GOTO 3201
      GOTO 446
 3200 IF(INITX.LT.2)GOTO 446
 3201 READ(IN,447)FMT
  447 FORMAT(A80)
      K=1
      IF(NSIM.GT.3)K=NCOL+1
      DO 448 I=K,NB
  448 READ(IN,FMT)(CFL(I,J),J=1,NDIM)
      GOTO 3026

//     OTHERWISE COMPUTE  PRODUCT MOMENT MATRICES

  446 LLL=LLL+1

      DO 24 J=1,NB
      DO 24 I=J,NB
   24 XX(I,J)=0.0
      TT=0.0
      DO 19 L=1,NS
      TRT=0.0
      DO 20 I=1,NB
      T=0.0
      DO 21 J=1,NB
   21 T=T+WA(J,I,L)
      TRT=TRT+T
   20 TR(I)=T*RNB
      TRT=TRT*RNBS
      T=0.0
//-----THE FOLLOWING TWO STATEMENTS ADDED 7/12/82
      IF(DEBUG.GT.0)WRITE(LOUT,2144)L
 2144 FORMAT(' SCALAR PRODUCTS FOR SUBJECT',I4)
      DO 222 I=2,NB
	DO 22 J=1,I-1
	  WAJIL=(WA(J,I,L)-TR(I)-TR(J)+TRT)*(-.5)
	  WA(J,I,L)=WAJIL
	  WA(I,J,L)=WAJIL
	  T=T+WAJIL*WAJIL*2
   22   CONTINUE
	WAIIL=TR(I)-.5*(WA(I,I,L)+TRT)
	WA(I,I,L)=WAIIL
	T=T+WAIIL*WAIIL
//-----THE FOLLOWING TWO STATEMENTS ADDED 7/12/82
	IF(DEBUG.GT.0)WRITE(LOUT,2145)(WA(I,J,L),J=1,I)
 2145   FORMAT(15F8.2)
  222 CONTINUE
      WA11L=TR(1)-.5*(WA(1,1,L)+TRT)
      WA(1,1,L)=WA11L
      T=T+WA11L*WA11L
      TT=TT+T

//     NORMALIZATION (WITHIN SUBJECT)

      IF(NSC.EQ.0) GOTO 19
//-----THE FOLLOWING TWO STATEMENTS ADDED 7/12/82
      IF(DEBUG.GT.0)WRITE(LOUT,2143)T
 2143 FORMAT(' IN STEP2: T = ',F20.7)
      T=DSQRT(NBS/T)
      DO 122 J=1,NB
      DO 122 I=J,NB
      WA(I,J,L)=WA(I,J,L)*T
      WA(J,I,L)=WA(I,J,L)
  122 XX(I,J)=XX(I,J)+WA(I,J,L)
   19 CONTINUE

//     NORMALIZATION (ACROSS SUBJECTS)

      IF(NSC.NE.0)GOTO 126
      TT=DSQRT(NBNBNS/TT)
      DO 123 L=1,NS
      DO 123 J=1,NB
      DO 123 I=J,NB
      WA(I,J,L)=WA(I,J,L)*TT
      WA(J,I,L)=WA(I,J,L)
  123 XX(I,J)=XX(I,J)+WA(I,J,L)
  126 DO 23 J=1,NB
      DO 23 I=J,NB
      XX(I,J)=XX(I,J)*RNS
   23 XX(J,I)=XX(I,J)
//---NWT AND NWW ARE NOT NEEDED; A LATER IF CHECK IS CHANGED
//     NWT=0
//     NWW=0
      FMX=0.0
      IF(NWE/2*2.EQ.NWE) GOTO 25

//     COMPUTE COORDINATES AND WEIGHTS FOR THE WEIGHTED EUCLIDIAN MODEL
//     BY USING THE SCHONEMANN-DE LEEUW METHOD

      CALL INIT(W,CFL,CFR,NB,NS,NDIM,XX,WA,TR,FK,WD,CFL,XX,WS,NDX,NDXP)

      DO 855 J=1,NDIM
      DO 855 I=1,NS
  855 IF(W(I,J).LT.FMX) FMX=W(I,J)
      IF(FMX.EQ.0.0)GOTO 867
      DO 866 J=1,NDIM
      DO 866 I=1,NS
  866 W(I,J)=W(I,J)-FMX
//--NWT IS NOT NEEDED
//     NWT=1
  867 T=0.0
      DO 517 J=1,NDIM
      DO 517 I=1,NS
  517 T=T+W(I,J)**2
      T=DSQRT((NDIM*NS)/T)
      DO 518 J=1,NDIM
      DO 518 I=1,NS
  518 W(I,J)=W(I,J)*T
      IF(NWE.EQ.3) GOTO 4004
      DO 4005 J=1,NDIM
      DO 4005 I=1,NB
 4005 WS(I,J)=1.0
      GOTO 26

//     COMPUTE COORDINATES FOR THE UNWEIGHTED EUCLIDIAN MODEL
//     BY USING TORGERSON'S METHOD

   25 CALL CJEIG(XX,CFL,CFR,NB,NDIM+1,FK,WS ,TR,1,NDXP)
//   HERE WS IS BEING PASSED TO BE USED AS SCRATCH SPACE IN CJEIG

      DO 41 J=1,NDIM
      TR(J)=SQRT(TR(J))
      DO 4080 I=1,NB
      CFL(I,J)=CFL(I,J)*TR(J)
 4080 WS(I,J)=1.0
      DO 41 I=1,NS
   41 W(I,J)=1.0
      IF(NWE.EQ.0) GOTO 26

//     COMPUTE COORDINATES AND WEIGHTS FOR THE ASYMMETRIC
//     EUCLIDEAN MODEL

      DO 4010 J=1,NDIM
 4010 CW(J)=1.0
      GOTO 4009
 4004 DO 4007 J=1,NDIM
      T=0.0
      DO 4008 I=1,NS
 4008 T=T+W(I,J)
 4007 CW(J)=T*RNS
 4009 DO 4053 I=1,NB
      DS(I,I)=0.0
      IF(NSIM.GT.1) GOTO 4053
      DO 4052 J=1,I
 4052 DS(J,I)=DS(I,J)
 4053 CONTINUE
      CALL INSWM(DS,CFL,CFR,WS,XX,TR,CV,CW,FK,ZZ,WD,NADCT,NB,NDIM,
     1 (NDIM*(NDIM+1))/2,NDX,NDXP,NS)
      DO 4013 J=1,NDIM
      DO 4013 I=1,NB
 4013 IF(WS(I,J).LT.FMX) FMX=WS(I,J)
      IF(FMX.GE.0.0)GOTO 4011
      DO 4014 J=1,NDIM
      DO 4014 I=1,NB
 4014 WS(I,J)=WS(I,J)-FMX
//---NWW IS NOT NEEDED
//     NWW=1
 4011 T=0.0
      DO 4015 J=1,NDIM
      DO 4015 I=1,NB
 4015 T=T+WS(I,J)**2
      T=DSQRT((NDIM*NB)/T)
      DO 4016 J=1,NDIM
      DO 4016 I=1,NB
 4016 WS(I,J)=WS(I,J)*T

//  ALL PATHS OF THE PROGRAM FROM ABOVE COME TOGETHER TO STATEMENTS 26
//     OR 3026

   26 IF(LLL.EQ.2)RETURN

//     READ OR PRINT INITIAL CONFIGURATION AND/OR INITIALIZE
//     INITIAL WEIGHTS WHEN INITIAL COORDINATES HAVE BEEN READ

      IF(INITX.GE.2)GOTO 3201
 3026 IF(LLL.EQ.2)RETURN
      IF(INITXC.LT.2.OR.NSIM.LT.3)GOTO 3126
      READ(IN,447)FMT
      DO 3030 I=1,NCOL
 3030 READ(IN,FMT)(CFL(I,J),J=1,NDIM)
 3126 IF(INITW.LT.2)GOTO 450
      READ(IN,447)FMT
      DO 449 I=1,NS
  449 READ(IN,FMT)(W(I,J),J=1,NDIM)
      GOTO 452
  450 IF(INITX.LT.2)GOTO 452
      DO 451 J=1,NDIM
      DO 451 I=1,NS
  451 W(I,J)=1.0
  452 IF(INITWS.LT.2)GOTO 454
      READ(IN,447)FMT
      DO 453 I=1,NB
  453 READ(IN,FMT)(WS(I,J),J=1,NDIM)
      GOTO 456
  454 IF(INITX.LT.2)GOTO 456
      DO 455 J=1,NDIM
      DO 455 I=1,NB
  455 WS(I,J)=1.0
//---INITXC ADDED TO THE FOLLOWING STATEMENT 7/6/82
  456 IF(INITX.GT.0.OR.INITW.GT.0.OR.INITWS.GT.0.OR.INITXC.GT.0) THEN
	CALL PAGE(LOUT)
	WRITE(LOUT,457)
  457   FORMAT(' INITIAL CONFIGURATION'//)
      ENDIF
//---INITXC ADDED TO THE FOLLOWING STATEMENT 7/6/82
      IF(INITX.EQ.0.AND.INITXC.EQ.0)GOTO 461
      WRITE(LOUT,458)(I,I=1,NDIM)
  458 FORMAT(' INITIAL STIMULUS SPACE'/
     1T29,'DIMENSION'/5X,'STIMULUS',6I12)
      IF(NSIM.GT.3)WRITE(LOUT,470)
  470 FORMAT(/'      COLUMN')
      DO 459 I=1,NB
      M=I
      IF(NSIM.GT.3.AND.I.GT.NCOL)M=I-NCOL
      NCOL1=NCOL+1
      IF(NSIM.GT.3.AND.I.EQ.NCOL1)WRITE(LOUT,471)
  471 FORMAT(/' ',8X,'ROW')
  459 WRITE(LOUT,460)M,(CFL(I,J),J=1,NDIM)
  460 FORMAT(I11,5X,6F12.4)
  461 IF(INITW.EQ.0)GOTO 464
      WRITE(LOUT,462)(I,I=1,NDIM)
  462 FORMAT(/' INITIAL SUBJECT WEIGHTS'/
     1T29,'DIMENSION'/5X,'SUBJECT',6I12)
      DO 463 I=1,NS
  463 WRITE(LOUT,460)I,(W(I,J),J=1,NDIM)
  464 IF(INITWS.EQ.0)GOTO 467
      WRITE(LOUT,465)(I,I=1,NDIM)
  465 FORMAT(/' INITIAL STIMULUS WEIGHTS'/
     1T29,'DIMENSION'/5X,'STIMULUS',6I12)
      DO 466 I=1,NB
  466 WRITE(LOUT,460)I,(WS(I,J),J=1,NDIM)
//
//     PUNCH INITIAL CONFIGURATION IF DESIRED
//
  467 IF(NPH.EQ.2) THEN
	WRITE(NPLT,3001)
 3001   FORMAT('(6F13.9)')
	DO 3002 I=1,NB
 3002   WRITE(NPLT,3003)(CFL(I,J),J=1,NDIM)
 3003   FORMAT(6F13.9)
	IF(NWE/2*2.EQ.NWE)GOTO 3005
	WRITE(NPLT,3001)
	DO 3004 I=1,NS
 3004   WRITE(NPLT,3003)(W(I,J),J=1,NDIM)
 3005   IF(NWE.GE.2) THEN
	  WRITE(NPLT,3001)
	  DO 3006 I=1,NB
 3006     WRITE(NPLT,3003)(WS(I,J),J=1,NDIM)
	END IF
      END IF

//---------------------------------------------------------------------

//     PREPARE QUALITATIVE DATA FOR OPTIMAL SCALING
//     --------------------------------------------

      CALL PAGE(LOUT)
      WRITE(LOUT,320) TITLE,NDIM
  320 FORMAT(A80/
     /' ITERATION HISTORY FOR THE',I2,'  DIMENSIONAL SOLUTION')
//-PC----------------------
      CALL CLEAR
      WRITE(*,321) ISTFOR
//-------------------------
      WRITE(LOUT,321) ISTFOR
  321 FORMAT(
     *' SSTRESS (IN SQUARED DISTANCES) FORMULA',I2,' IS USED.'///
     *6X,'ITERATION',6X,'SSTRESS',6X,'IMPROVEMENT'/)

      IF(IJKL.GT.1)GOTO 30
      IZ(1)=1
      N2=0
      IF(NDTYP-3) 30,31,144
   31 IF(NWC.EQ.1) GOTO 431
      IF(NWC.EQ.2) GOTO 2012

//     UNCONDITIONAL ORDINAL DATA

      DO 33 K=1,NT
      IX(K)=K
   33 WC(K)=X(K)
      CALL SHEL9(WC,IX,NT)
      CALL BLOC2(WC,IY,IZ,NT)
      GOTO 30

//     MATRIX CONDITIONAL ORDINAL DATA

  431 DO 432 L=1,NS
      DO 433 K=1,NC2
      M=N2+K
      IX(M)=K
  433 WC(M)=X(M)
      N=N2+1
      CALL SHEL9(WC(N),IX(N),NC2)
      IF(L.EQ.1)GOTO 524
      IZ(L)=IZ(L-1)
  524 CALL BLOC2(WC(N),IY,IZ(L),NC2)
  432 N2=N2+NC2
      GOTO 30

//     ROW CONDITIONAL ORDINAL DATA

 2012 N1=0
      DO 2013 L=1,NS
      DO 2014 I=1,NB
      DO 2015 J=1,NB
      M=N2+J
      IX(M)=J
 2015 WC(M)=X(M)
      N=N2+1
      CALL SHEL9(WC(N),IX(N),NB)
      N1=N1+1
      IF(N1.EQ.1) GOTO 2016
      IZ(N1)=IZ(N1-1)
 2016 CALL BLOC2(WC(N),IY,IZ(N1),NB)
 2014 N2=N2+NB
 2013 CONTINUE
      GOTO 30

  144 IF(NWC.EQ.1) GOTO 573
      IF(NWC.EQ.2) GOTO 2017

//     UNCONDITIONAL NOMINAL DATA

      NDCT=0
      DO 145 L=1,NT
      IF(IX(L).EQ.1) GOTO 1145
      IF(NDCT.EQ.0) GOTO 1146
      DO 146 K=1,NDCT
      IF(WC(K).EQ.X(L)) GOTO 147
  146 CONTINUE
 1146 NDCT=NDCT+1
      WC(NDCT)=X(L)
      IX(L)=NDCT
      GOTO 145
  147 IX(L)=K
      GOTO 145
 1145 IX(L)=-1
  145 CONTINUE
      IF(NAB.EQ.NT) GOTO 30
      NDCT=NDCT+1
      DO 2310 L=1,NT
 2310 IF(IX(L).EQ.-1) IX(L)=NDCT
      GOTO 30

//     MATRIX CONDITIONAL NOMINAL DATA

  573 DO 574 L=1,NS
      NDSBB=0
      N1=N2+1
      N2=N2+NC2
      DO 575 J=N1,N2
      IF(IX(J).EQ.1) GOTO 1575
      IF(NDSBB.EQ.0) GOTO 1577
      DO 576 K=1,NDSBB
      IF(WC(K).EQ.X(J)) GOTO 577
  576 CONTINUE
 1577 NDSBB=NDSBB+1
      WC(NDSBB)=X(J)
      IX(J)=NDSBB
      GOTO 575
  577 IX(J)=K
      GOTO 575
 1575 IX(J)=-1
  575 CONTINUE
      IF(NAD(L,1).EQ.NC2) GOTO 574
      NDSBB=NDSBB+1
      DO 2311 J=N1,N2
 2311 IF(IX(J).EQ.-1) IX(J)=NDSBB
  574 NDSR(L,1)=NDSBB
      GOTO 30

//     ROW CONDITIONAL NOMINAL DATA

 2017 DO 2018 L=1,NS
      DO 2019 I=1,NB
      NDSRR=0
      N1=N2+1
      N2=N2+NB
      DO 2020 J=N1,N2
      IF(IX(J).EQ.1) GOTO 2021
      IF(NDSRR.EQ.0) GOTO 2022
      DO 2023 K=1,NDSRR
      IF(WC(K).EQ.X(J)) GOTO 2024
 2023 CONTINUE
 2022 NDSRR=NDSRR+1
      WC(NDSRR)=X(J)
      IX(J)=NDSRR
      GOTO 2020
 2024 IX(J)=K
      GOTO 2020
 2021 IX(J)=-1
 2020 CONTINUE
      IF(NAD(L,I).EQ.NB) GOTO 2019
      NDSRR=NDSRR+1
      DO 2025 J=N1,N2
 2025 IF(IX(J).EQ.-1) IX(J)=NDSRR
 2019 NDSR(L,I)=NDSRR
 2018 CONTINUE
   30 CONTINUE

//-----------------------------------------------------------------------

//     PERFORM INITIAL OPTIMAL SCALING
//     -------------------------------

//---THE FOLLOWING TWO STATEMENTS ARE REPLACED BY THE NEXT STATEMENT
//     IF(NWE.EQ.0.AND.NDTYP.NE.1) GOTO 8888
//     IF(NWT.EQ.0.AND.NWW.EQ.0)RETURN
      IF(NWE.EQ.0.AND.NDTYP.EQ.1)RETURN
 8888 CALL DISTP(W,CFL,X,WC,WD,IX,IY,IZ,XX,NDSR,WS,NAD)
      IF(ISTFOR.EQ.2)RETURN
      IF(NWE.EQ.0.AND.STRSS.LT.0.5)RETURN
      IF(INITX.GT.1.OR.INITW.GT.1.OR.INITWS.GT.1.OR.INITXC.GT.1)RETURN
      WRITE(LOUT,8889)STRSS
//-PC--------------------
      WRITE(*,8889)STRSS
//-----------------------
 8889 FORMAT(10X,'0',2X,F15.5)
      N=0
      DO 442 L=1,NS
      IF(NSIM.GT.1) GOTO 2026
      DO 444 I=1,NB
  444 WA(I,I,L)=0.0
      DO 443 I=2,NB
      I1=I-1
      DO 443 J=1,I1
      N=N+1
      WA(I,J,L)=X(N)
      WA(J,I,L)=X(N)
  443 CONTINUE
      GOTO 442
 2026 DO 2027 I=1,NB
      DO 2027 J=1,NB
      N=N+1
 2027 WA(I,J,L)=X(N)
      DO 2028 I=1,NB
      DO 2028 J=1,I
      WA(I,J,L)=(WA(I,J,L)+WA(J,I,L))*.5
      WA(J,I,L)=WA(I,J,L)
 2028 CONTINUE
  442 CONTINUE
      GOTO 446
}
//*********************************************************************

void __fastcall TAlscaleForm::STEP3(IX,IY,IZ,X,G,WA,WB,WC,U11,U12,U22,UB1,UB2,
                      XN,XX,CFL,W,TR,FK,WS,NDSR,NAD,IJKL,IRET)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/08/82

//  THIS IS THE MAJOR COMPUTATIONAL ROUTINE. IT CONTROLS THE FLOW
//  OF THE ITERATIVE MINIMIZATION PROCESS, PERFORMS REGRESSIONS
//  TO CALCULATE WEIGHTS, AND OUTPUTS THE RESULTS

//    WA,WB & WC REFER TO THE SAME ARRAY IN THE CALLING ROUTINE
//    THESE ARRAYS ARE PASSED IN AS DIFFERENT PARAMETERS TO PERMIT
//    REFERENCING THE ARRAYS USING DIFFERENT NUMBERS OF DIMENSIONS

//-----------------------------------------------------------------------

      double T,TT,A,B,C;
//-----THE FOLLOWING STATEMENT WAS CHANGED FROM INTEGER*2 7/8/82
      INTEGER IX(NT),IY(1),IZ(1)
      DIMENSION X(NT),G(NBS,1),WA(NB,NB,NS),WB(NBS,NS),WC(1),
     1 U11(NDX,1),U12(NDX,1),U22(NDX,1),UB1(1),UB2(1),XN(1)
      DIMENSION XX(NB,NB),CFL(NB,1),W(NS,1),TR(1),FK(NDXP,1)
      DIMENSION WS(NB,1),NDSR(NS,NB),NAD(NS,NB)
      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//----- THE FOLLOWING THREE STATEMENTS ADDED 7/7/82
//      DOUBLE PRECISION CUT,STMIN
//      INTEGER DEBUG,ICNSTR,NOULB
//      COMMON /PRMBLK/CUT,STMIN,DEBUG,ICNSTR,NOULB
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//    +       /BLOCK3/ TITLE,FMT
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
//     +       /INICON/INITX,INITW,INITWS,INITXC


//     ITERATION BEGINS HERE
//     ---------------------

      IRET=0
      DO 2 LL=1,MAXIT

//     COMPUTE SQUARED DISTANCES,DISPARITIES AND STRESS

      CALL DISTP(W,CFL,X,WC,G,IX,IY,IZ,XX,NDSR,WS,NAD)

      DIF=STRSO-STRSS
      IF(LL.EQ.1) THEN
	WRITE(LOUT,321)LL,STRSS
//-PC------------------------
	WRITE(*,321)LL,STRSS
//---------------------------
      ELSE
	WRITE(LOUT,321)LL,STRSS,DIF
//-PC----------------------------
	WRITE(*,321)LL,STRSS,DIF
//-------------------------------
      ENDIF
  321 FORMAT(I11,2X,2F15.5)
//     TEST FOR EXIT
      IF(DIF.LT.0.0) GOTO 145
//----- FOLLOWING STATEMENT ADDED 7/7/82 (SAS 10/23/81)
      IF(STRSS.LT.STMIN) GOTO 141
      IF(DIF.LT.EPSI) GOTO 143
      IF(LL.GE.MAXIT) GOTO 3
      STRSO=STRSS

//     SET-UP FOR THE NEXT ITERATION

      A=1./(1.0-STRSS*STRSS)
      IF(NSIM.GT.1) GOTO 2029
//   NSIM <= 1 IMPLIES NC2=NB*(NB-1)/2 THEREFORE
      N=0
      DO 43 L=1,NS
      WA(1,1,L)=0.0
      DO 44 I=2,NB
      I1=I-1
      WA(I,I,L)=0.0
      DO 44 J=1,I1
      N=N+1
      WA(I,J,L)=X(N)*A
   44 WA(J,I,L)=WA(I,J,L)
   43 CONTINUE
      GOTO 2030
 2029 DO 2031 L=1,NBNBNS
 2031 WC(L)=X(L)*A
 2030 CONTINUE
      IF(NWE.EQ.0) GOTO 4017
      L=0
      DO 47 I=1,NB
      DO 47 J=1,NB
      L=L+1
      DO 47 K=1,NDIM
   47 G(L ,K)=(CFL(I,K)-CFL(J,K))**2
      IF(NWE.EQ.2) GOTO 52
      IF(INITW.EQ.3)GOTO 4533

//     (1) ESTIMATE SUBJECT WEIGHTS

      DO 48 I=1,NDIM
      DO 48 J=1,I
      T=0.0
      L=0
      DO 49 KK=1,NB
      TT=WS(KK,I)*WS(KK,J)
      DO 49 K=1,NB
      L=L+1
   49 T=T+G(L,I)*G(L,J)*TT
      FK(I,J)=T
   48 FK(J,I)=T
      CALL MINV(FK,NDIM,NDXP)
      DO 51 J=1,NDIM
      DO 51 I=1,NS
      T=0.0
      DO 50 K=1,NDIM
      L=0
      DO 50 M=1,NB
      TT=WS(M,K)*FK(J,K)
      DO 50 N=1,NB
      L=L+1
   50 T=T+WB(L,I)*G(L,K)*TT
   51 W(I,J)=T

//     CHECK FOR NEGATIVE SUBJECT WEIGHTS

      IF(NNC.EQ.1) GOTO 4533
      DO 471 K=1,NS
      DO 476 J=1,NDIM
  476 TR(J)=W(K,J)
      DO 472 J=1,NDIM
      IF(TR(J).LT.0.0) GOTO 473
  472 CONTINUE
      GOTO 471
  473 TR(J)=0.0
      IF(NDIM.EQ.1) GOTO 4070
      J1=J+1
      IF(J.EQ.NDIM) J1=1
      DO 482 LX=1,20
      DO 478 I=J1,NDIM
      A=0.0
      B=0.0
      DO 477 I1=1,NBS
      KK=(I1-1)/NB+1
      C=WB(I1,K)
      DO 474 I2=1,NDIM
  474 IF(I2.NE.I)C=C-G(I1,I2)*WS(KK,I2)*TR(I2)
      A=A+C*G(I1,I)*WS(KK,I)
  477 B=B+G(I1,I)**2*WS(KK,I)**2
      TR(I)=A/B
  478 IF(TR(I).LT.0.0) TR(I)=0.0
      DO 479 J=1,NDIM
      IF(ABS(TR(J)-W(K,J)).GT.0.0005) GOTO 483
  479 CONTINUE
      GOTO 4070
  483 DO 481 J=1,NDIM
  481 W(K,J)=TR(J)
      J1=1
  482 CONTINUE
      GOTO 471
 4070 DO 484 J=1,NDIM
  484 W(K,J)=TR(J)
  471 CONTINUE
      DO 355 J=1,NDIM
      DO 356 I=1,NS
      IF(W(I,J).NE.0.0) GOTO 355
  356 CONTINUE
      GOTO 4
  355 CONTINUE
 4533 IF(NWE.EQ.1) GOTO 4017
   52 IF(INITWS.EQ.3)GOTO 4017

//     (2) ESTIMATE STIMULUS WEIGHTS

      DO 4022 K=1,NB
      DO 4018 I=1,NDIM
      DO 4018 J=1,I
      T=0.0
      N=(K-1)*NB
      DO 4019 L=1,NB
      N=N+1
      TT=G(N,I)*G(N,J)
      DO 4019 KK=1,NS
 4019 T=T+TT*W(KK,I)*W(KK,J)
      FK(J,I)=T
 4018 FK(I,J)=T
      CALL MINV(FK,NDIM,NDXP)
      DO 4021 J=1,NDIM
      T=0.0
      DO 4020 I=1,NDIM
      KK=(K-1)*NB
      DO 4020 N=1,NB
      KK=KK+1
      TT=G(KK,I)*FK(I,J)
      DO 4020 L=1,NS
 4020 T=T+TT*WB(KK,L)*W(L,I)
 4021 WS(K,J)=T

//     CHECK FOR NEGATIVE STIMULUS WIEGHTS

      IF(NNC.EQ.1) GOTO 4022
      DO 4026 J=1,NDIM
 4026 TR(J)=WS(K,J)
      DO 4023 J=1,NDIM
      IF(TR(J).LT.0.0) GOTO 4024
 4023 CONTINUE
      GOTO 4022
 4024 TR(J)=0.0
      IF(NDIM.EQ.1) GOTO 4071
      J1=J+1
      IF(J.EQ.NDIM) J1=1
      DO 4025 LX=1,20
      DO 4027 I=J1,NDIM
      A=0.0
      B=0.0
      DO 5029 I1=1,NB
      II1=(K-1)*NB+I1
      DO 5029 I11=1,NS
      C=WB(II1,I11)
      DO 4028 I2=1,NDIM
 4028 IF(I2.NE.I)C=C-G(II1,I2)*TR(I2)*W(I11,I2)
      A=A+C*G(II1,I)*W(I11,I)
 5029 B=B+G(II1,I)**2*W(I11,I)**2
      TR(I)=A/B
 4027 IF(TR(I).LT.0.0) TR(I)=0.0
      DO 4030 J=1,NDIM
      IF(ABS(TR(J)-WS(K,J)).GT.0.0005) GOTO 4031
 4030 CONTINUE
      GOTO 4071
 4031 DO 4033 J=1,NDIM
 4033 WS(K,J)=TR(J)
      J1=1
 4025 CONTINUE
      GOTO 4022
 4071 DO 4032 J=1,NDIM
 4032 WS(K,J)=TR(J)
 4022 CONTINUE
      DO 4034 J=1,NDIM
      DO 4035 I=1,NB
      IF(WS(I,J).NE.0.0) GOTO 4034
 4035 CONTINUE
      GOTO 4
 4034 CONTINUE

//     (3) ESTIMATE CONFIGURATION

 4017 IF(INITX.EQ.3.AND.NSIM.LT.4)GOTO 2
      IF(INITX.EQ.3.AND.INITXC.EQ.3.AND.NSIM.GE.4)GOTO 2
      CALL INNER(CFL,W,X,WB,U11,U12,U22,UB1,UB2,XN,NB,NDIM,NS,NDX,NBS,
     1 WS)
    2 CONTINUE

//----------------------------------------------------------------------

    3 WRITE(LOUT,9901)
      WRITE(*,9901)
 9901 FORMAT(/' ALSCAL MESSAGE:  ITERATIONS STOPPED BECAUSE ')
      WRITE(LOUT,299)MAXIT
      WRITE(*,299)MAXIT
  299 FORMAT(T19,'THIS IS ITERATION',I4//)
      STRSS=STRSO
      GOTO 9999
//----- THE FOLLOWING FOUR STATEMENTS ADDED 7/7/82 (SAS 10/23/81)
  141 WRITE(LOUT,9901)
      WRITE(*,9901)
      WRITE(LOUT,142)STMIN
      WRITE(*,142)STMIN
  142 FORMAT(T19,'S-STRESS LESS THAN',F9.6//)
      GOTO 9999
  143 WRITE(LOUT,9901)
      WRITE(*,9901)
      WRITE(LOUT,144)EPSI
      WRITE(*,144)EPSI
  144 FORMAT(T19,'SSTRESS IMPROVEMENT LESS THAN',F9.6//)
      GOTO 9999
  145 WRITE(LOUT,9902)
      WRITE(*,9902)
 9902 FORMAT(/' ALSCAL WARNING:  ITERATIONS TERMINATED BECAUSE OF NEGATI
     *VE SSTRESS IMPROVEMENT.'/18X,'DATA MAY BE ILL-CONDITIONED OR THERE
     * MAY BE A PROGRAM ERROR.'//)
      GOTO 9999
    4 WRITE(LOUT,9900)
      WRITE(*,9900)
 9900 FORMAT(/' ALSCAL WARNING:    COMPUTATIONS INTERRUPTED.')
      WRITE(LOUT,298)
      WRITE(*,298)
  298 FORMAT(8X,'A DIMENSION HAS ONLY ZERO WEIGHTS. SOLUTION SKIPPED')
      IF(IJKL.EQ.ND) GOTO 4099
      IF(NPT.EQ.1.AND.NT.EQ.NAB) GOTO 2899
      REWIND NDP
      READ(NDP) X
 2899 READ(NDP) WA
 4099 REWIND NDP
      IRET=1
      RETURN

//-PC-----------
 9999 CALL HITR
//--------------
}
//***********************************************************************

void __fastcall TAlscaleForm::STEP3A(IX,IY,IZ,X,WC,WD,XX,CFL,W,WS,NDSR,NAD,
                       PHISUB,PHISTI)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 23MAY83

//     SUBROUTINE TO PRINT STRESS AND CORRELATIONS IN DISTANCES
//        NORMALIZES WEIGHTS ACCORDING TO CORRELATION

//-----------------------------------------------------------------------

//----THE FOLLOWING STATEMENT WAS CHANGED FROM INTEGER*2 7/8/82
      INTEGER IX(NT),IY(1),IZ(1)
      DIMENSION X(NT),WC(1),WD(1),XX(NB,NB),CFL(NB,1)
      DIMENSION W(NS,1),WS(NB,1),PHISUB(NS),PHISTI(NB)
      DIMENSION NDSR(NS,NB),NAD(NS,NB)
      CHARACTER*72,COPR,LINE*120
      COMMON /CCOPR/COPR
     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
      COMMON /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA

      LINE=' '
      ISTFOR=1
      IF(NSIM.GT.3)ISTFOR=2

C     STRESS IN DISTANCES

      DO 80 I=1,NT
      IF(X(I).LT.0.0) GOTO 4081
      X(I)=SQRT(X(I))
      GOTO 4082
 4081 X(I)=-SQRT(-X(I))
 4082 IF(WC(I).LT.0.0) GOTO 4083
      WC(I)=SQRT(WC(I))
      GOTO 80
 4083 WC(I)=-SQRT(-WC(I))
   80 CONTINUE
      WRITE(LOUT,8451)
 8451 FORMAT(////' STRESS AND SQUARED CORRELATION (RSQ) IN DISTANCES'/
     /' RSQ VALUES ARE THE PROPORTION OF VARIANCE OF THE SCALED DATA ',
     *'(DISPARITIES) IN THE PARTITION'/' (ROW, MATRIX, OR ENTIRE DATA)',
     *' WHICH IS ACCOUNTED FOR BY THEIR CORRESPONDING DISTANCES.')
      WRITE(LOUT,7483)ISTFOR
C-PC----------------------------------------------------------------
      CALL CLEAR
      WRITE (*,8452)
 8452 FORMAT(/' STRESS AND SQUARED CORRELATION (RSQ) IN DISTANCES'/)
C-------------------------------------------------------------------

 7483 FORMAT(/' KRUSKAL''S STRESS FORMULA',I2,' IS USED.'/)
      IF(NWC-1)8460,8470,8480

C UNCONDITIONAL STRESS OUTPUT

 8460 CALL MSTRS(NT,X,WC,STRSS1,STRSS2)
      PHI=1.0-STRSS2
      STRSS1=SQRT(STRSS1)
      WRITE(LOUT,8461)STRSS1,PHI
      WRITE(*,8461)STRSS1,PHI
 8461 FORMAT(' STRESS = '    ,F5.3,'      RSQ = ',F5.3)
      GOTO 8490

C MATRIX CONDITIONAL STRESS OUTPUT

 8470 STRES1=0.0
      STRES2=0.0
      IF(NS.NE.1)WRITE(LOUT,8473)
 8473 FORMAT(4('   MATRIX     STRESS      RSQ '))
      N=1
      DO 8479 L=1,NS
      CALL MSTRS(NC2,X(N),WC(N),STRSS1,STRSS2)
      STRES1=STRES1+STRSS1
      STRES2=STRES2+STRSS2
      PHISUB(L)=1.0-STRSS2
      STRSS1=SQRT(STRSS1)
      LMOD4=MOD(L-1,4)
      LSTART=5+LMOD4*30
      LEND=LSTART+24
      IF(NS.NE.1)WRITE(LINE(LSTART:LEND),8471)L,STRSS1,PHISUB(L)
 8471 FORMAT(I3,F13.3,F9.3)
      IF(LMOD4.EQ.3)WRITE(LOUT,8475)LINE
 8475 FORMAT(A)
      N=N+NC2
 8479 CONTINUE
      IF(LMOD4.NE.3)WRITE(LOUT,8475)LINE(1:29+LMOD4*30)
      LINE=' '
      PHI=1.0-STRES2/NS
      STRES1=SQRT(STRES1/NS)
      IF(NS.NE.1)WRITE(LOUT,8472)STRES1,PHI
      IF(NS.NE.1)WRITE(LOUT,9472)STRES1,PHI
 8472 FORMAT(/'   OVERALL',F10.3, F9.3/)
      IF(NS.EQ.1)WRITE(LOUT,8461)STRES1,PHI
      IF(NS.EQ.1)WRITE(*,8461)STRES1,PHI
      GOTO 8490

C ROW CONDITIONAL STRESS OUTPUT

 8480 STRES1=0.0
      STRES2=0.0
      DO 8485 J=1,NB
 8485 PHISTI(J)=0.0
      N1=1

C----- THE FOLLOWING TWO STATEMENTS WERE ADDED IN CONJUNCTION
C----- WITH THE ERROR NOTED BELOW. 7/6/82 (SAS CHANGE 12/1/80)

      NBORNR=NB
      IF(NSIM.GT.3)NBORNR=NB-NCOL

      DO 8489 I=1,NS
      WRITE(LOUT,8481) I
 8481 FORMAT(' MATRIX',I4/)
      IF(NSIM.GT.3)WRITE(LOUT,2000)
 2000 FORMAT(' ROW STIMULI')
      WRITE(LOUT,2002)
 2002 FORMAT(4('  STIMULUS    STRESS      RSQ '))
      STR1=0.0
      STR2=0.0
      N=N1
      DO 8488 J=1,NB

C----- THE FOLLOWING STATEMENT WAS MOVED TO CORRECT AND ERROR IN
C----- CALCULATING AVERAGE STRESS AND RSQ INDICES FOR RECTANGULAR
C----- ROW CONDITIONAL DATA. 7/6/82 (SAS CHANGE 12/1/80)
C----- THE ERROR WAS THAT THE PERFECT FIT INDICES FOR COLUMNS
C----- WERE BEING INCLUDED IN THE SUMMATION PROCESS.

      IF(NSIM.GT.3.AND.J.LE.NCOL)GOTO 2001
      CALL MSTRS(NB,X(N), WC(N), STRSS1,STRSS2)
      STR1=STR1+STRSS1
      STR2=STR2+STRSS2
      PHIROW=1.0-STRSS2
      PHISTI(J)=PHISTI(J)+PHIROW
      STRSS1=SQRT(STRSS1)
C     IF(NSIM.GT.3.AND.J.LE.NCOL)GOTO 2001
      K=J
      IF(NSIM.GT.3)K=J-NCOL
      LMOD4=MOD(K-1,4)
      LSTART=5+LMOD4*30
      LEND=LSTART+24
      WRITE(LINE(LSTART:LEND),8471)K,STRSS1,PHIROW
      IF(LMOD4.EQ.3)WRITE(LOUT,8475)LINE
 2001 N=N+NB
 8488 CONTINUE
      IF(LMOD4.NE.3)WRITE(LOUT,8475)LINE(1:29+LMOD4*30)
      LINE=' '
      STRES1=STRES1+STR1
      STRES2=STRES2+STR2

C----- THE FOLLOWING TWO STATEMENTS WERE CHANGED TO COMPUTE
C----- AVERAGE STRESS AND RSQ INDICES CORRECTLY FOR RECTANGULAR
C----- ROW CONDITIONAL DATA.  THE ERROR WAS THAT THE DIVISION
C----- WAS BY THE TOTAL NUMBER OF SIMULI, NOT THE NUMBER OF ROWS.
C----- 7/6/82 (SAS CHANGE 12/1/80)
C     PHISUB(I)=1.0-STR2/NB
C     STR1=SQRT(STR1/NB)

      PHISUB(I)=1.0-STR2/NBORNR
      STR1=SQRT(STR1/NBORNR)
      WRITE(LOUT,8472)STR1,PHISUB(I)
      N1=N1+NC2
 8489 CONTINUE
      IF (NS.EQ.1)GOTO 8490
      WRITE(LOUT,8491)
 8491 FORMAT(/' AVERAGED OVER MATRICES')
      IF(NSIM.LT.4)WRITE(LOUT,8492)
      IF(NSIM.GT.3)WRITE(LOUT,8493)
 8492 FORMAT(/'  STIMULUS',6X,'RSQ')
 8493 FORMAT(/'  ROW STIMULUS  RSQ')
      DO 8486 I=1,NB
      PHISTI(I)=PHISTI(I)/NS
      K=I
      IF(NSIM.GT.3.AND.K.LE.NCOL)GOTO 8486
      IF(NSIM.GT.3)K=I-NCOL
      WRITE(LOUT,8487)K,PHISTI(I)
 8486 CONTINUE
 8487 FORMAT(T5,I3,F13.3,F9.3)
      NA=NB
      IF(NSIM.GT.3)NA=NB-NCOL
      PHI=1.0-STRES2/(NA*NS)
      STRES1=SQRT(STRES1/(NA*NS))
      WRITE(LOUT,9472)STRES1,PHI
      WRITE(*,9472)STRES1,PHI
 9472 FORMAT(/' OVERALL STRESS =',F6.3,' AND RSQ =',F6.3)

C     NORMALIZE DERIVED SOLUTION

 8490 CALL NORMX(CFL,W,NB,NS,NDIM,NWE)

      ICONFL=0
      IF(NWC.EQ.0)ICONFL=1
      IF(NWE.EQ.1.OR.NWE.EQ.3)CALL NORMW(W,NS,NDIM,PHI,PHISUB,ICONFL)
      ICONFL=1
      IF(NWC.EQ.2)ICONFL=0
      IF (NWE.GE.2) CALL NORMW(WS,NB,NDIM,PHI,PHISTI,ICONFL)
      NAD(1,1)=-NAD(1,1)
      CALL DISTP(W,CFL,X,WC,WD,IX,IY,IZ,XX,NDSR,WS,NAD)
C-PC-----------
      CALL HITR
C--------------
}
//*********************************************************************
*/
void __fastcall TAlscaleForm::STEP4(double *X, double *WC, double **DISP,
                double **CFL, double **W, double *TR, double **WS,
                double **DIST, double **DUMMY, double **PIJP, double **XK,
                double *ROW, int IJKL)
{
//-----LINE ABOVE ADDED TO SUBROUTINE STATEMENT FOR GEMSCAL 8/9/82
//-----IJKL MOVED TO PROPER POSITON IN LINE ABOVE 5MAY83 FWY
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 23MAY83 FWY

//                   THIS SUBROUTINE OUTPUTS THE RESULTS

//-----------------------------------------------------------------------

//-----XX CHANGED TO DISP 8/11/82
//    DIMENSION X(NT),WC(NBNBNS),DISP(NB,NB),CFL(NB,1)
//    DIMENSION W(NS,1),TR(1),WS(NB,1)
//    DIMENSION WL(6)
//    CHARACTER*80,TITLE,FMT,COPR*72
//PC------------------------------------------------------------------
//    CHARACTER*1 ALFA(52),ALFAL(26),ALFAS(26),ALFA1*52
//    EQUIVALENCE(ALFA,ALFA1),(ALFA1(1:26),ALFAL),(ALFA1(27:52),ALFAS)
//---------------------------------------------------------------------

//     COMMON /CCOPR/COPR
//-----FOLLOWING THREE STATEMENTS ADDED FOR GEMSCAL 8/9/82
//      DIMENSION DIST(NB,NB),DUMMY(NB,NB),PIJP(NB,NB),XK(NB,6),ROW(NB)
//      COMMON /PDCOM/IFLPDS,NDIR
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//     +       /BLOCK3/ TITLE,FMT
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
//-PC--------------------------------------------------------------------
//      DATA ALFA1/'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'/
//-----------------------------------------------------------------------

	double WL[7];
	char ALFA1[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
   char outline[101];
   char valstr[24];
   int KK, M, DIMNUM, IAX, KNT, JM1, LL, LOC, NPH, NDIM1;
   double TOP, BOT, VAL, WEIRD, XHI, XLO, YHI, YLO, FMW, FMZ, COSMAX, FMU, FMV;
   FILE *NPLT;
   FILE *NDQ;
   FILE *NDPP;
   FILE *NDP;
   NPLT = fopen("NPLT","wt");
   NDQ = fopen("NDQ","w+t");
   NDPP = fopen("NDPP","r+t");
   NDP = fopen("NDP","w+t");

   //-----FOLLOWING FOUR STATEMENTS ADDED 8/9/82
	if (NDIR == 0) NDIR = NDIM;
	//-----FOLLOWING STATEMENT ADDED 19/10/82 FOR GEMSCAL
	int IPLOT = NPT;
   for (int I = 1; I <= NT; I++) // DO 80 I=1,NT
   {
      if (X[I] < 0.0) goto pos4081; // GOTO 4081
      X[I] = sqrt(X[I]);
      goto pos4082; // GOTO 4082
pos4081:
		X[I] = -sqrt(-X[I]);
pos4082:
		if (WC[I] < 0.0) goto pos4083; //  GOTO 4083
      WC[I] = sqrt(WC[I]);
      goto pos80; // GOTO 80
pos4083:
		WC[I] = -sqrt(-WC[I]);
pos80:
	} // CONTINUE

	//      PRINT RESULTS

   if (NDIM > 1) ARNGE(W,CFL,WS,NB,NS,NDIM,TR);
   sprintf(outline," CONFIGURATION DERIVED IN %3d DIMENSIONS",NDIM);
   FrmOutPut->RichOutPut->Lines->Add(outline);
   FrmOutPut->RichOutPut->Lines->Add("STIMULUS COORDINATES");
   strcpy(outline,"                           DIMENSION     STIMULUS  PLOT");
   strcpy(outline,"");
   for (int j = 1; j < NDIM; j++)
   {
   	sprintf(valstr,"%6d",j);
      strcat(outline,valstr);
   }
   FrmOutPut->RichOutPut->Lines->Add(outline);

   FrmOutPut->RichOutPut->Lines->Add("      NUMBER  SYMBOL");
	FrmOutPut->RichOutPut->Lines->Add("");

//-PC------------------------------------------------------
	if (NSIM > 3)
   {
   	FrmOutPut->RichOutPut->Lines->Add("      COLUMN");
		for (int I = 1; I <= NCOL; I++) //DO 6401 I=1,NCOL
   	{
   		KK = fmod(I-1,26)+1;
      	sprintf(outline,"%10d       %c",I,ALFA1[KK]);
      	for (int J = 1; J <= NDIM; J++)
      	{
      		sprintf(valstr,"%10.4f",CFL[I][J]);
         	strcat(outline,valstr);
      	}
		}
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("");
      FrmOutPut->RichOutPut->Lines->Add("        ROW");
		for (int I = NCOL+1; I <= NB; I++) // DO 6402 I=NCOL+1,NB
      {
	   	M = I - NCOL;
	    	KK = fmod(M-1,26)+1;
         sprintf(outline,"%10d       %c",M,ALFA1[KK]);
         for (int J = 1; J <= NDIM; J++)
         {
         	sprintf(valstr,"%10.4f",CFL[I][J]);
            strcat(outline,valstr);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
		}
 	}
   else //ELSE
   {
		for (int I = 1; I <= NB; I++) //DO 64 I=1,NB
      {
	  		KK = fmod(I-1,52) + 1;
         sprintf(outline,"%10d       %c",I,ALFA1[KK]);
         for (int J = 1; J <= NDIM; J++)
         {
            sprintf(valstr,"%10.4f",CFL[I][J]);
            strcat(outline,valstr);
         }
         FrmOutPut->RichOutPut->Lines->Add(outline);
      }
	} //  ENDIF
//---------------------------------------------------------

	if (NWE / 2 * 2 == NWE) goto pos62; // GOTO 62
//-----MOST OF THE STATEMENTS IN THE FOLLOWING SECTION ADDED 8/9/82
	if (NWC != 0)
   {
      FrmOutPut->RichOutPut->Lines->Add("SUBJECT WEIGHTS MEASUE THE IMPORTANCE OF EACH DIMENSION");
      FrmOutPut->RichOutPut->Lines->Add("TO EACH SUBJECT.  SQUARED WEIGHTS SUM TO RSQ.");
      FrmOutPut->RichOutPut->Lines->Add("A SUBJECT WITH WEIGHTS PROPORTIONAL TO THE AVERAGE WEIGHTS");
      FrmOutPut->RichOutPut->Lines->Add("HAS A WEIRDNESS OF ZERO, THE MINIMUM VALUE.");
      FrmOutPut->RichOutPut->Lines->Add("A SUBJECT WITH ONE LARGE WEIGHT AND MANY LOW WEIGHTS HAS");
      FrmOutPut->RichOutPut->Lines->Add("A WEIRDNESS NEAR ONE.  A SUBJECT WITH EXACTLY ONE POSITIVE");
      FrmOutPut->RichOutPut->Lines->Add("WEIGHT HAS A WEIRDNESS OF ONE, THE MAXIMUM VALUE FOR");
      FrmOutPut->RichOutPut->Lines->Add("NONNEGATIVE WEIGHTS.");
	}
   FrmOutPut->RichOutPut->Lines->Add(" SUBJECT WEIGHTS");
   FrmOutPut->RichOutPut->Lines->Add("                                       DIMENSION");
   strcpy(outline,"     SUBJECT   PLOT    WEIRD-");
   for (int J = 1; J <= NDIM; J++)
   {
   	sprintf(valstr,"%12d",J);
      strcat(outline,valstr);
   }
   FrmOutPut->RichOutPut->Lines->Add(outline);
	FrmOutPut->RichOutPut->Lines->Add("      NUMBER  SYMBOL    NESS");
	FrmOutPut->RichOutPut->Lines->Add("");

// CALCULATE WEIRDNESS

	for (int J = 1; J <= NDIM; J++) // DO 1030 J=1,NDIM
   {
      WL[J] = 0.0;
      for (int I = 1; I <= NS; I++) // DO 1030 I=1,NS
 			WL[J] = WL[J] + W[I][J];
 	}  // 1030
   DIMNUM = NDIM;
   COSMAX = 1.0 / sqrt(DIMNUM);
   for (int I = 1; I <= NS; I++) // DO 63 I=1,NS
   {
      TOP = 0.0;
      BOT = 0.0;
      for (int J = 1; J <= NDIM; J++) // DO 1035 J=1,NDIM
      {
      	VAL = W[I][J] / WL[J];
      	TOP = TOP + VAL;
 			BOT = BOT + VAL * VAL;
 		} // 1035
      WEIRD = acos(COSMAX * TOP / sqrt(BOT)) / acos(COSMAX);
      KK = fmod(I-1,52) + 1;
      sprintf(outline,"%10d       %c %10.4f",I,ALFA1[KK],WEIRD);
      for (int J = 1; J <= NDIM; J++)
      {
      		sprintf(valstr,"%10.4f",W[I][J]);
         	strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
	} //63
	for (int J = 1; J <= NDIM; J++) // DO 1020 J=1,NDIM
   {
      WL[J] = 0.0;
      for (int I = 1; I <= NS; I++) // DO 1015 I=1,NS
//----THE FOLLOWING STATEMENT CHANGED FROM ...+W(I,J) 8/9/82
			WL[J] = WL[J] + pow(W[I][J],2); // 1015
 		WL[J] = WL[J] / NS;
	}  // 1020
   FrmOutPut->RichOutPut->Lines->Add("");
   strcpy(outline,"     AVERAGE (RMS)          ");
   for (int J = 1; J <= NDIM; J++)
   {
      sprintf(valstr,"%12.4f",WL[J]);
      strcat(outline,valstr);
   }
   FrmOutPut->RichOutPut->Lines->Add(outline);
//-----END OF SECTION ADDED 8/9/82
pos62:
	if (NWE < 2) goto pos4040; //  GOTO 4040
   FrmOutPut->RichOutPut->Lines->Add(" STIMULUS WEIGHTS");
   FrmOutPut->RichOutPut->Lines->Add("                           DIMENSION");
   strcpy(outline,"     STIMULUS  PLOT");
   for (int J = 1; J <= NDIM; J++)
   {
   	sprintf(valstr,"%12d",J);
      strcat(outline,valstr);
   }
   FrmOutPut->RichOutPut->Lines->Add(outline);
   FrmOutPut->RichOutPut->Lines->Add("      NUMBER  SYMBOL");
	FrmOutPut->RichOutPut->Lines->Add("");
	for (int I = 1; I <= NB; I++) //DO 4042 I=1,NB
   {
   	KK = fmod(I-1,52) + 1;
      sprintf(outline,"%10d       %c",I,ALFA1[KK]);
      for (int J = 1; J <= NDIM; J++)
      {
      		sprintf(valstr,"%10.4f",WS[I][J]);
         	strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
	}
pos4040: // 4040 CONTINUE

//     PLOT RESULTS

pos3321:
	if (NPT == 0) goto pos4043; // GOTO 4043
   XHI = 2.5;
   XLO = -2.5;
   YHI = 2.5;
   YLO = -2.5;
   if (NDIM == 1) goto pos66; // GOTO 66
   for (int I = 2; I <= NDIM; I++) // DO 60 I=2,NDIM
   {
   	I1 = I - 1;
      for (int J = 1; J <= I1; J++) //DO 60 J=1,I1
      {
      	FrmOutPut->RichOutPut->Lines->Add(""); //PAGE(LOUT)
         FrmOutPut->RichOutPut->Lines->Add("      DERIVED STIMULUS CONFIGURATION");
         sprintf(outline,"      DIMENSION %3d (HORIZONTAL) VS DIMENSION %3d (VERTICAL)",J,I);
         FrmOutPut->RichOutPut->Lines->Add(outline);
//			PLOTR(CFL[1][J],CFL[1][I],XHI,YHI,XLO,YLO,NB,LOUT,2,NB);
		} // 60
	}
   goto pos67; // GOTO 67
pos66:
	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("DERIVED STIMULUS CONFIGURATION");
   FrmOutPut->RichOutPut->Lines->Add("      ONE DIMENSIONAL PLOT");
//   PLOTR(CFL,CFL,XHI,YHI,XLO,YLO,NB,LOUT,2,NB);
//-----CODE RELATING TO FMW,FMZ,FMU AND FMV CHANGED 8/10/82
pos67:
	FMW = 0.9;
   FMZ = 0.0;
   if (NNC == 1) FMZ = -FMW;
   FMU = 1.0;
   FMV = 0.0;
   if (NNC == 1) FMV = -FMU;
   IAX = 2;
   if (NNC != 1) IAX = -2;
   if (NWE / 2 * 2 == NWE) goto pos70; // GOTO 70
   for (int I = 2; I <= NDIM; I++) // DO 69 I=2,NDIM
   {
      I1 = I - 1;
      for (int J = 1; J <= I1; J++) // DO 69 J=1,I1
      {
      	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
         FrmOutPut->RichOutPut->Lines->Add("      DERIVED SUBJECT WEIGHTS");
         sprintf(outline,"DIMENSION %3d (HORIZONTAL) VS DIMENSION %3d (VERTICAL)",J,I);
         FrmOutPut->RichOutPut->Lines->Add(outline);
//   		PLOTR(W[1][J],W[1][I],FMU,FMW,FMV,FMZ,NS,LOUT,IAX,NS);
		}
   }  //69
pos70:
	if (NWE < 2) goto pos4043; // GOTO 4043
//-----CODE RELATING TO FMU,...,IAX REPLACED BY CODE ABOVE 8/10/82
	for (int I = 2; I <= NDIM; I++) // DO 4046 I=2,NDIM
   {
      I1 = I - 1;
      for (int J = 1; J <= I1; J++) // DO 4046 J=1,I1
      {
      	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
         FrmOutPut->RichOutPut->Lines->Add("      DERIVED STIMULUS WEIGHTS");
         sprintf(outline,"      DIMENSION %3d (HORIZONTAL) VS DIMENSION %3d (VERTICAL)",J,I);
         FrmOutPut->RichOutPut->Lines->Add(outline);
// 			PLOTR(WS[1][J],WS[1][I],FMU,FMW,FMV,FMZ,NB,LOUT,IAX,NB);
		}
	}  // 4046
pos4043: // CONTINUE

//     FIT GENERALIZED EUCLIDEAN MODEL WEIGHTS

	if ((NDT != 1) && (IFLPDS != 1)) goto pos5099; // GOTO 5099
   KNT = 1;
   for (int I = 1; I <= NS; I++) // DO 5006 I=1,NS
   {
   	if (NDT != 1) goto pos5010; // GOTO 5010
      FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
      sprintf(outline,"OPTIMALLY SCALED DATA (DISPARITIES)    SUBJECT %4d",I);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      if (NSIM < 2) OUTS(X,NB,1,1,DISP);
      if (NSIM > 1) OUTA(X,NB,-1);
pos5010:
 		if (IFLPDS != 1) goto pos5005; //GOTO 5005
      FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
      sprintf(outline,"GENERAL EUCLIDEAN MODEL:   SUBJECT %4d",I);
      FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(LOUT,5002)TITLE,I
// 5002 FORMAT(A80/1X,'GENERAL EUCLIDEAN MODEL:    SUBJECT',I4)
      if (NSIM > 1) goto pos5004; // GOTO 5004

// SYMMETRIC DATA

      DISP[1][1] = 0.0;
      for (int J = 2; J <= NB; J++) // DO 5003 J=2,NB
      {
      	DISP[J][J] = 0.0;
      	JM1 = J - 1;
      	for (int K = 1; K <= JM1; K++) // DO 5003 K=1,JM1
         {
      		DISP[K][J] = X[KNT];
      		DISP[J][K] = X[KNT];
 				KNT = KNT + 1;
         }
      } // 5003
      PDMAIN(CFL,DISP,NB,NDIM,NDIR,I,NSIM,IPLOT,LOUT,DIST,DUMMY,PIJP,XK,ROW);
      goto pos5006; // GOTO 5006

// ASYMMETRIC AND RECTANGULAR DATA

pos5004: // CONTINUE
      PDMAIN(CFL,X,NB,NDIM,NDIR,I,NSIM,IPLOT,LOUT,DIST,DUMMY,PIJP,XK,ROW);
pos5005:
		if (NSIM < 2) KNT = KNT + NB * (NB - 1) / 2;
      if (NSIM > 1) KNT = KNT + NB * NB;
pos5006:
 	} //  5006 CONTINUE
//C-----END OF GEMSCAL SECTION ADDED 8/10/82
pos5099:
	if (NPT == 0) goto pos5265; // GOTO 5265
   FrmOutPut->RichOutPut->Lines->Add(""); //   CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("SCATTERGRAM (PLOT OF LINEAR FIT");
   FrmOutPut->RichOutPut->Lines->Add("      DISTANCES (VERTICAL) VS DISPARITIES (HORIZONTAL)");
   rewind(NDQ); //   REWIND NDQ
   fprintf(NDQ,"10.4f",X); //   WRITE(NDQ) X
	NN = NT;
	if (NSIM < 4) goto pos4065; // GOTO 4065
   L = 0;
   LL = 0;
   for (int K = 1; K <= NS; K++) // DO 4064 K=1,NS
   {
      for (int I = 1; I <= NB; I++) // DO 4064 I=1,NB
      {
      	for (int J = 1; J <= NB; J++) //DO 4064 J=1,NB
         {
      		L = L + 1;
      		if (I <= NCOL) continue; // GOTO 4064
      		if (J > NCOL) continue; // GOTO 4064
      		LL = LL + 1;
      		X[LL] = X[L];
      		WC[LL] = WC[L];
         }
      }
pos4064:
	} // CONTINUE
   NN = LL;
pos4065:
//	PLOTR(X,WC,1.0,1.0,1.0,1.0,NN,LOUT,-1,NT);
	rewind(NDQ);//      REWIND NDQ
	rewind(NDPP); //      REWIND NDPP
	I1 = NB;
   NX = 2;
   if (NSIM > 1) NX = 1;
   L = 0;
   for (int K = 1; K <= NS; K++) // DO 2309 K=1,NS
   {
		for (int I = NX; I <= NB; I++) // DO 2309 I=NX,NB
      {
	  		if (NSIM <= 1) I1 = I - 1;
	  		I2 = L + 1;
	  		L = L + I1;
//	  		READ(NDPP)(X(II),II=I2,L)
      }
   } // 2309 CONTINUE
   if ((NDEG == 1) && (NDTYP <= 2)) goto pos5265; // GOTO 5265
   if (NSIM < 4) goto pos4075; // GOTO  4075
   L = 0;
   LL = 0;
   for (int K = 1; K <= NS; K++) // DO 4074 K=1,NS
   {
      for (int I = 1; I <= NB; I++) // DO 4074 I=1,NB
      {
      	for (int J = 1; J <= NB; J++) // DO 4074 J=1,NB
         {
      		L = L + 1;
      		if (I <= NCOL) continue; // GOTO 4074
      		if (J > NCOL) continue; // GOTO 4074
      		LL = LL + 1;
      		X[LL] = X[L];
         }
      }
   } // 4074 CONTINUE
pos4075:
	if (NWC == 2) goto pos4076; // GOTO 4076
   if ((NWC == 1) && (NS > 1)) goto pos4076; // GOTO 4076
   FrmOutPut->RichOutPut->Lines->Add(""); //   CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("PLOT OF NONLINEAR FIT");
   FrmOutPut->RichOutPut->Lines->Add("      DISTANCES (VERTICAL) VS OBSERVATIONS (HORIZONTAL)");
//	PLOTR(X,WC,1.0,1.0,1.0,1.0,NN, LOUT,-1,NT);
pos4076:
//	READ(NDQ) (WC(I),I=1,NT)
	rewind(NDQ); //   REWIND NDQ
	if (NSIM < 4) goto pos4085; // GOTO 4085
   L = 0;
   LL = 0;
   for (int K = 1; K <= NS; K++) // DO 4084 K=1,NS
   {
      for (int I = 1; I <= NB; I++) // DO 4084 I=1,NB
      {
      	for (int J = 1; J <= NB; J++) //DO 4084 J=1,NB
         {
      		L = L + 1;
      		if (I <= NCOL) continue; // GOTO 4084
      		if (J > NCOL) continue; // GOTO 4084
      		LL = LL + 1;
      		WC[LL] = WC[L];
         }
      }
   } //  4084 CONTINUE

// -----PLOTTING OF TRANSFORMATIONS UPDATED 8/10/82
pos4085:
	if (NWC == 2) goto pos5100; // GOTO 5100
   if ((NWC == 1) && (NS > 1)) goto pos5100; // GOTO 5100

// MAKE ONE PLOT WHEN THERE IS ONE NONLINEAR TRANSFORMATION

	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("PLOT OF TRANSFORMATION");
   FrmOutPut->RichOutPut->Lines->Add("      DISPARITIES (VERTICAL) VS OBSERVATIONS (HORIZONTAL)");
//	PLOTR(X,WC,1.0,1.0,1.0,1.0,NN, LOUT,-1,NT);
pos5100:
	if ((IPLOT <= 1) || (NWC == 0)) goto pos5265; // GOTO 5265
   if ((NWC == 1) && (NS == 1)) goto pos5265; //  GOTO 5265
   LOC = 1;
   if (NWC == 2) goto pos5110; // GOTO 5110

// MAKE SEVERAL PLOTS WHEN FULLPLOT REQUESTED
// AND THERE ARE SEVERAL TRANSFORMATIONS

	for (int K = 1; K <= NS; K++) // DO 5102 K=1,NS
   {
      FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
      sprintf(outline,"PLOT OF TRANSFORMATION     SUBJECT %4d",K);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("      DISPARITIES (VERTICAL) VS OBSERVATIONS (HORIZONTAL)");
//      PLOTR(X[LOC],WC[LOC],1.0,1.0,1.0,1.0,NC2,LOUT,-1,NC2);
		LOC = LOC + NC2;
 	} // 5102
   goto pos5265; // GOTO 5265

// DO FULLPLOT WHEN ROW CONDITIONAL

pos5110:
	for (int K = 1; K <= NS; K++) // DO 5112 K=1,NS
   {
      for (int I = 1; I <= NB; I++) //DO 5112 I=1,NB
      {
      	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
         sprintf(outline,"PLOT OF TRANSFORMATION    SUBJECT %4d ROW %4d",K,I);
         FrmOutPut->RichOutPut->Lines->Add(outline);
         FrmOutPut->RichOutPut->Lines->Add("      	DISPARITIES (VERTICAL) VS OBSERVATIONS (HORIZONTAL)");
//			PLOTR(X[LOC],WC[LOC],1.0,1.0,1.0,1.0,NB,LOUT,-1,NB);
			LOC = LOC + NB;
 		}
	} // 5112

//     PUNCH RESULTS

pos5265:
	if (NPH >= 1) // THEN
   {
		fprintf(NPLT,"%s","(6F13.9)");//	WRITE(NPLT,252)
		for (int I = 1; I <= NB; I++) //DO 71 I=1,NB
      {
      	for (int J = 1; J <= NDIM; J++)
         	fprintf(NPLT,"%13.9f",CFL[I][J]);
				//   71   WRITE(NPLT,251) (CFL(I,J),J=1,NDIM)
		} // 71
//  251   FORMAT(6F13.9)
//  252   FORMAT('(6F13.9)')
		if (NWE / 2 * 2 != NWE) // THEN
      {
	  		fprintf(NPLT,"%c","(6F13.9)"); // WRITE(NPLT,252)
	  		for (int I = 1; I <= NS; I++) // DO 72 I=1,NS
         {
         	for (int J = 1; J <= NDIM; J++)
            	fprintf(NPLT,"13.9f",W[I][J]);
			}
		} // 	END IF
		if (NWE >= 2) // THEN
   	{
			fprintf(NPLT,"c","(6F13.9)"); //	  WRITE(NPLT,252)
			for (int I = 1; I <= NB; I++) // DO 4051 I=1,NB
         {
            for (int J = 1; J <= NDIM; J++)
            	fprintf(NPLT,"13.9f",WS[I][J]);
			}
		} //	END IF
	} // END IF

//-PC----------------------------------------------------
// WRITE FILE "CPLOT.DAT" FOR ROTATION OF CONFIGURATION
//	if (NPH == 1) WPLOT(CFL,W,WS,NWE,NDIM,NB,NS);
// ------------------------------------------------------

	if (IJKL == ND) goto pos4099; // GOTO 4099
	rewind(NDP);//      REWIND NDP
//      READ(NDP) X
//      READ(NDP) WC
pos4099: rewind(NDP); // REWIND NDP

	if (NWE / 2 * 2 == NWE) return; //GOTO 9999
	NDIM1 = NDIM - 1;
   for (int I = 1; I <= NS; I++) //DO 4102 I=1,NS
   {
      SUM = 0.0;
      for (int J = 1; J <= NDIM; J++) //DO 4101 J=1,NDIM
 			SUM = SUM + W[I][J]; // 4101
      for (int J = 1; J <= NDIM1; J++) // DO 4102 J=1,NDIM1
			W[I][J] = W[I][J] / SUM;
 	} // 4102
   for (int J = 1; J <= NDIM1; J++) //DO 4211 J=1,NDIM1
   {
      SUM = 0.0;
      SUMSQ = 0.0;
      for (int I = 1; I <= NS; I++) // DO 4209 I=1,NS
 			SUM = SUM + W[I][J]; // 4209
      SUM = SUM / NS;
      for (int I = 1; I <= NS; I++) // DO 4210 I=1,NS
      {
      	W[I][J] = W[I][J] - SUM;
 			SUMSQ = SUMSQ + W[I][J] * W[I][J];
 		} // 4210
      SUMSQ = sqrt(SUMSQ / NS);
      for (int I = 1; I <= NS; I++) // DO 4211 I=1,NS
 			W[I][J] = W[I][J] / SUMSQ;
	} // 4211
   FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("FLATTENED SUBJECT WEIGHTS");
   strcpy(outline,"      SUBJECT   PLOT");
   for (int J = 1; J <= NDIM1; J++)
   {
   	sprintf(valstr,"%12d",J);
      strcat(outline,valstr);
   }
   FrmOutPut->RichOutPut->Lines->Add(outline);
   FrmOutPut->RichOutPut->Lines->Add("      NUMBER  SYMBOL");
	for (int I = 1; I <= NS; I++) // DO 4104 I=1,NS
   {
      KK = fmod(I-1,52) + 1;
      sprintf(outline,"%10d       %c",I,ALFA1[KK]);
      for (int J = 1; J <= NDIM1; J++)
      {
      		sprintf(valstr,"%10.4f",W[I][J]);
         	strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
 	} // 4104
pos6566:
	if (NPT == 0) return; //  GOTO 9999
   if (NDIM1 == 1) goto pos4108; // GOTO 4108
   for (int I = 2; I <= NDIM1; I++) // DO 4107 I=2,NDIM1
   {
      I1 = I - 1;
      for (int J = 1; J <= I1; J++) //DO 4107 J=1,I1
      {
      	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
         FrmOutPut->RichOutPut->Lines->Add("FLATTENED SUBJECT WEIGHTS");
         sprintf(outline,"      VARIABLE %3d  (HORIZONTAL) VS VARIABLE %3d (VERTICAL)",J,I);
         FrmOutPut->RichOutPut->Lines->Add(outline);
//			PLOTR(W[1][J],W[1][I],XHI,YHI,XLO,YLO,NS,LOUT,2,NS);
		}
	} // 4107
   return; // GOTO 9999
pos4108:
	FrmOutPut->RichOutPut->Lines->Add(""); // CALL PAGE(LOUT)
   FrmOutPut->RichOutPut->Lines->Add("      FLATTENED SUBJECT WEIGHTS");
   FrmOutPut->RichOutPut->Lines->Add("ONE VARIABLE PLOT");
//	PLOTR(W[1][1],W[1][1],XHI,YHI,XLO,YLO,NS,LOUT,2,NS);
   
}
//***********************************************************************

void __fastcall TAlscaleForm::INIT(double **W, double **CFL, double **CFR,
            int NB, int NS, int ND, double **XX, double ***WA, double *TR,
            double **FK, double ***C, double **XEQ, double **AM, double **WS,
            int NDX, int NDXP)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
//   FINAL CHANGE 12/14/77
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     INITIAL CONFIGURATION ESTIMATION IN INDSCAL
//     BY SCHONEMANN-DE LEEUW METHOD

//     YOSHIO TAKANE JULY 1974

//----------------------------------------------------------------------

//      DIMENSION WA(NB,NB,NS),WS(NB,1),CFL(NB,1),CFR(NB,1)
//      DIMENSION C(NDX,NDX,1),XX(NB,NB),TR(1),FK(NDXP,1)
//      DIMENSION AM(NS,1),XEQ(NS,1),W(NS,1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//      DOUBLE PRECISION T1,T2,T3,XM,XS

	double T1, T2, T3, XM, XS, DQ;

   CJEIG(XX,CFR,CFL,NB,ND+1,FK,WS,TR,1, NDXP);
	// WS IS BEING PASSED TO CJEIG FOR USE AS SCRATCH SPACE


   for (int K = 1; K <= NS; K++) //DO 12 K=1,NS
   {
   	for (int K1 = 1; K1 <= ND; K1++) // DO 12 K1=1,ND
      {
   		for (int K2 = 1; K2 <= K1; K2++) // DO 12 K2=1,K1
         {
   			T1 = 0.0;
   			T2 = TR[K1] * TR[K2];
   			T2 = 1.0e0 / sqrt(T2);
   			for (int J = 1; J <= NB; J++) // DO 13 J=1,NB
            {
      			T3 = 0.0;
      			for (int I = 1; I <= NB; I++) //DO 10 I=1,NB
   					T3 = T3 + WA[I][J][K] * CFR[I][K1]; // 10
   				T1 = T1 + T3 * CFR[J][K2];
            } // 13
      		T1 = T1 * T2;
      		C[K1][K2][K] = T1;
   			C[K2][K1][K] = T1;
         }
      }
   } // 12
   for (int J = 1; J <= ND; J++) // DO 50 J=1,ND
   {
   	DQ = sqrt(TR[J]);
      for (int I = 1; I <= NB; I++) // DO 50 I=1,NB
      {
   		CFR[I][J] = CFR[I][J] * DQ;
      }
   } // 50

	//     FIND FEASIBLE WEIGHTS
	//          FORMING A MATRIX

	if (ND <= 1) goto pos301; //GOTO 301
   for (int K = 1; K <= NS; K++) //DO 14 K=1,NS
   {
   	T1 = 0.0;
      for (int J = 1; J <= ND; J++) //DO 17 J=1,ND
      	for (int I = 1; I <= ND; I++) // DO 17 I=1,ND
   			T1 = T1 + C[I][J][K]; // 17
   	TR[K] = T1 / NB;
   } // 14
   for (int I = 1; I <= NS; I++) // DO 15 I=1,NS
   {
      for (int J = 1; J <= I; J++)  // DO 15 J=1,I
      {
      	T1 = 0.0;
      	for (int K = 1; K <= ND; K++) // DO 16 K=1,ND
      		for (int L = 1; L <= ND; L++) // DO 16 L=1,ND
   				T1 = T1 + C[K][L][I] * C[L][K][J]; // 16
      	AM[I][J] = T1 / NB - TR[I] * TR[J];
   		AM[J][I] = AM[I][J];
      }
   } // 15

   CJEIG(AM,XEQ,XEQ,NS,2,FK,W,TR,1,NDXP);

   for (int I = 1; I <= ND; I++) // DO 18 I=1,ND
   {
      for (int J = 1; J <= I; J++) // DO 18 J=1,I
      {
      	T1 = 0.0;
      	for (int K = 1; K <= NS; K++) // DO 19 K=1,NS
   			T1 = T1 + C[I][J][K] * XEQ[K][1]; // 19
      	AM[I][J] = T1;
   		AM[J][I] = T1;
      }
   } // 18

	//     FIND THE TRANSFORMATION MATRIX

   EIGK(AM,TR,ND,NS);

	//     FIND THE INTITIAL CONFIGURATION

   for (int I = 1; I <= NB; I++) // DO 20 I=1,NB
   {
      for (int J = 1; J <= ND; J++) // DO 20 J=1,ND
      {
      	T1 = 0.0;
      	for (int K = 1; K <= ND; K++) // DO 27 K=1,ND
   			T1 = T1 + CFR[I][K] * AM[K][J]; // 27
   		CFL[I][J] = T1;
      }
   } // 20

	//     FIND THE INITIAL WEIGHTS

   for (int I = 1; I <= ND; I++) // DO 22 I=1,ND
   {
      for (int J = 1; J <= I; J++) // DO 22 J=1,I
      {
      	T1 = 0.0;
      	for (int K = 1; K <= NB; K++) // DO 23 K=1,NB
   			T1 = T1 + CFL[K][I] * CFL[K][J]; // 23
      	FK[I][J] = T1;
   		FK[J][I] = T1;
      }
   }

   MINV(FK,ND,NDXP);

   for (int L = 1; L <= NS; L++) // DO 21 L=1,NS
   {
      for (int I = 1; I <= ND; I++) // DO 24 I=1,ND
      {
      	for (int J = 1; J <= I; J++) // DO 24 J=1,I
         {
      		T1 = 0.0;
      		for (int K2 = 1; K2 <= NB; K2++) //DO 251 K2=1,NB
            {
      			T2 = 0.0;
      			for (int K1 = 1; K1 <= NB; K1++) // DO 25 K1=1,NB
   					T2 = T2 + WA[K1][K2][L] * CFL[K1][I]; // 25
  					T1 = T1 + T2 * CFL[K2][J];
            } // 251
      		AM[I][J] = T1;
   			AM[J][I] = T1;
         }
      }
      for (int I = 1; I <= ND; I++) // DO 28 I=1,ND
      {
      	T1 = 0.0;
      	for (int K1 = 1; K1 <= ND; K1++) //DO 26 K1=1,ND
      		for (int K2 = 1; K2 <= ND; K2++) // DO 26 K2=1,ND
   				T1 = T1 + FK[I][K1] * AM[K1][K2] * FK[K2][I]; // 26
   		W[L][I] = T1;
   	} // 28
   } //  21 CONTINUE

	//     NORMALIZATION

   for (int J = 1; J <= ND; J++) // DO 57 J=1,ND
   {
      XM = 0.0;
      XS = 0.0;
      for (int I = 1; I <= NB; I++) // DO 58 I=1,NB
      {
      	XM = XM + CFL[I][J];
   		XS = XS + pow(CFL[I][J],2);
      } // 58
      XM = XM / NB;
      XS = XS / NB - pow(XM,2);
      for (int I = 1; I <= NS; I++) // DO 59 I=1,NS
   		W[I][J] = W[I][J] * XS; // 59
      XS = sqrt(XS);
      for (int I = 1; I <= NB; I++) // DO 60 I=1,NB
   		CFL[I][J] = (CFL[I][J] - XM) / XS; // 60
   } //    57 CONTINUE
   return; // RETURN

pos301:
	for (int L = 1; L <= NS; L++) // DO 302 L=1,NS
  		W[L][1] = C[1][1][L]; // 302
}

//***********************************************************************

void __fastcall TAlscaleForm::INSWM(double **DS,double **CFL, double **CFR,
          double **WS, double **XX, double *TR, double *CV, double *CW,
          double **FK, double **ZZ, double ***C, int NADCT, int NB,
          int NDIM, int ND, int NDX, int NDXP, int NS)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 02/21/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     INITIAL CONFIGURATIONS FOR THE STIMULUS WEIGHTED MODEL

//----------------------------------------------------------------------

//      DIMENSION CFL(NB,1),CFR(NB,1),WS(NB,1),XX(NB,NB)
//      DIMENSION DS(NB,NB),TR(1),CV(1),CW(1)
//      DIMENSION FK(NDXP,1),ZZ(ND,1),C(NDX,NDX,1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//      DOUBLE PRECISION T,TT

      double T, TT;
      int N, NM2;

      if (NADCT == 1) goto pos403; // GOTO 403
      T = 0.0;
      for (int J = 1; J <= NB; J++) // DO 17 J=1,NB
      	for (int I = 1; I <= NB; I++) //DO 17 I=1,NB
   			T = T + (DS[I][J] * DS[I][J]); // 17
      T = T / (pow((NB * NS),2));
      for (int J = 1; J <= NB; J++) // DO 57 J=1,NB
      	for (int I = 1; I <= NB; I++) // DO 57 I=1,NB
   			DS[I][J] /= T; // 57
      NADCT = 1;
pos403: // CONTINUE
      for (int J = 1; J <= NDIM; J++) //DO 65 J=1,NDIM
   		CFR[1][J] = CW[J]; // 65

      for (int I = 1; I <= NB; I++) // DO 20 I=1,NB
      {
      	for (int J = 1; J <= NB; J++) // DO 21 J=1,NB
         {
      		for (int K = 1; K <= NDIM; K++) //DO 22 K=1,NDIM
   				XX[J][K] = pow((CFL[I][K] - CFL[J][K]),2) * CFR[1][K]; // 22
      		if (NDIM == 1) continue; // GOTO 21
      		N = NDIM;
      		for (int K = 2; K <= NDIM; K++) // DO 23 K=2,NDIM
            {
      			NM2 = K - 1;
      			for (int KK = 1; KK <= NM2; KK++) // DO 23 KK=1,NM2
               {
      				N = N + 1;
   					XX[J][N]=(CFL[I][KK] - CFL[J][KK]) * (CFL[I][K] - CFL[J][K]) *
     					2.0 * sqrt(CFR[1][K] * CFR[1][KK]);
               }
            } // 23
         } // 21 CONTINUE
      	for (int K = 1; K <= ND; K++) // DO 24 K=1,ND
         {
      		for (int J = 1; J <= ND; J++) // DO 24 J=1,ND
            {
      			ZZ[J][K] = 0.0;
      			for (int KK = 1; KK <= NB; KK++) //DO 24 KK=1,NB
   				   ZZ[J][K] = ZZ[J][K] + XX[KK][J] * XX[KK][K];
            }
         } // 24

      	MINV(ZZ,ND,ND);

      	for (int J = 1; J <= ND; J++) //DO 25 J=1,ND
         {
      		CW[J] = 0.0;
      		for (int K = 1; K <= NB; K++) // DO 25 K=1,NB
   				CW[J] = CW[J] + XX[K][J] * DS[I][K];
         } // 25
      	for (int J = 1; J <= ND; J++) // DO 26 J=1,ND
         {
         	CV[J] = 0.0;
      		for (int K = 1; K <= ND; K++) // DO 26 K=1,ND
   				CV[J] = CV[J] + ZZ[J][K] * CW[K];
         } // 26
      	for (int J = 1; J <= NDIM; J++) //DO 27 J=1,NDIM
   			C[J][J][I] = CV[J]; // 27
      	if (NDIM == 1) goto pos151; //  GOTO 151
      	N = NDIM;
      	for (int K = 2; K <= NDIM; K++) //DO 28 K=2,NDIM
         {
      		NM2 = K - 1;
      		for (int KK = 1; KK <= NM2; KK++) // DO 28 KK=1,NM2
            {
      			N = N + 1;
      			C[K][KK][I] = CV[N];
   				C[KK][K][I] = CV[N];
            }
         } // 28
pos151: // CONTINUE
		} // 20 CONTINUE

      for (int K = 1; K <= NB; K++) //DO 29 K=1,NB
      {
      	TR[K] = 0.0;
      	for (int J = 1; J <= NDIM; J++) // DO 30 J=1,NDIM
      		for (int I = 1; I <= NDIM; I++) // DO 30 I=1,NDIM
   				TR[K] = TR[K] + C[I][J][K]; // 30
   		TR[K] = TR[K] / NB;
      } // 29
      for (int J = 1; J <= NB; J++) // DO 31 J=1,NB
      {
      	for (int I = 1; I <= NB; I++) // DO 31 I=1,NB
         {
      		T = 0.0;
      		for (int K = 1; K <= NDIM; K++) // DO 32 K=1,NDIM
      			for (int L = 1; L <= NDIM; L++) // DO 32 L=1,NDIM
   					T = T + C[K][L][I] * C[L][K][J]; // 32
   			XX[I][J] = T / NB - TR[I] * TR[J];
         }
      } // 31

      if (NDIM == 1) goto pos130; // GOTO 130
      CJEIG(XX,WS,CFR,NB,2,FK,ZZ,TR,1,NDXP);
      goto pos131; // GOTO 131
pos130:
      for (int K = 1; K <= NB; K++) //DO 132 K=1,NB
  			WS[K][1] = TR[K]; // 132
pos131: // CONTINUE

      for (int J = 1; J <= NDIM; J++) // DO 33 J=1,NDIM
      {
      	for (int I = 1; I <= NDIM; I++) // DO 33 I=1,NDIM
         {
      		XX[I][J] = 0.0;
      		for (int K = 1; K <= NB; K++) // DO 133 K=1,NB
  					XX[I][J] = XX[I][J] + C[I][J][K] * WS[K][1]; // 133
         }
      } // 33 CONTINUE

      EIGK(XX,TR,NDIM,NB);

      for (int J = 1; J <= NDIM; J++) // DO 60 J=1,NDIM
      {
      	for (int I = 1; I <= NB; I++) // DO 64 I=1,NB
         {
      		T = 0.0;
      		for (int K = 1; K <= NDIM; K++) // DO 63 K=1,NDIM
   				T = T + CFL[I][K] * XX[K][J]; // 63
   			CFR[I][J] = T;
         } // 64
      } // 60 CONTINUE
      for (int J = 1; J <= NDIM; J++) // DO 35 J=1,NDIM
      {
      	for (int I = 1; I <= NB; I++) // DO 35 I=1,NB
         {
      		CFL[I][J] = CFR[I][J];
      		T = 0.0;
      		for (int KK = 1; KK <= NDIM; KK++) //DO 36 KK=1,NDIM
            {
      			TT = 0.0;
      			for (int K = 1; K <= NDIM; K++) // DO 37 K=1,NDIM
   					TT = TT + XX[K][J] * C[K][KK][I]; // 37
   				T = T + TT * XX[KK][J];
            } // 36
         	WS[I][J] = T;
         }
      } // 35
}
//**********************************************************************

void __fastcall TAlscaleForm::DISTP(double **W, double **CFL, double *X,
         double *WC, double *WD, int *IX, int *IY, int *IZ, double *XX,
         int **NDSR, double **WS, int **NAD)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/08/82

//  THIS ROUTINE COMPUTES DISTANCES AND DISPARITIES (OPTIMALLY SCALED
//  DATA) FOR A GIVEN SET OF COORDINATES AND WEIGHTS BY THE YOUNG,
//  DE LEEUW AND TAKANE METHOD

//----------------------------------------------------------------------

//      DOUBLE PRECISION S
//-----THE FOLLOWING STATEMENT WAS CHANGED FROM INTEGER*2 7/8/82
//      INTEGER IX,IY,IZ
//      DIMENSION W(NS,1),CFL(NB,1),X(1),WC(1),WD(NT),IX(NT),IY(1),IZ(1),
//     1 XX(1),WS(NB,1),NDSR(NS,NB),NAD(NS,NB)
//      DIMENSION R(5,5),ALPH(5)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//C    +       /BLOCK3/ TITLE,FMT
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA

// ---------------------------------------------------------------------

//     COMPUTE SQUARED DISTANCES
//     -------------------------

      double **R, ALPHA, S, OSEST, STRSS1, WDI, *ALPH;
      int J, LAST, LIN, N, N1, NX, I1, NAB1, NC3, NI, NE, NDCT;
      GetDblMatMem(R,6,6);
      GetDblVecMem(ALPH,6);
      LAST = 0;
      if (NAD[1][1] < 0) LAST = 1; //IF(NAD(1,1).LT.0)LAST=1
      if (NAD[1][1] < 0) NAD[1][1] = -NAD[1][1]; // IF(NAD(1,1).LT.0)NAD(1,1)=-NAD(1,1)
      OSEST = BIG;
      STRSS = 0.0;
      LIN = 0;
      if ((NDEG == 1) && (NCST == 1)) LIN = 1; // IF(NDEG.EQ.1.AND.NCST.EQ.1)LIN=1
      N = 0;
      NX = 2;
      if (NSIM > 1) NX = 1; // IF(NSIM.GT.1) NX=1
      I1 = NB;
      for (int L = 1; L <= NS; L++) // DO 37 L=1,NS
      {
          for (int I = NX; I <= NB; I++) // DO 35 I=NX,NB
          {
              if (NSIM <= 1) I1 = I - 1; // IF(NSIM.LE.1)I1=I-1
              for (int J = 1; J <= I1; J++) //DO 35 J=1,I1
              {
                  N = N + 1;
                  S = 0.0;
                  if ((NWE - 1) == 0) goto pos30; //IF(NWE-1)25,30,38
                  if ((NWE - 1) > 0) goto pos38;
pos25:
                  for (int K = 1; K <= NDIM; K++) //DO 26 K=1,NDIM
                      S = S + (CFL[I][K] - (CFL[J][K] * CFL[J][K])); // 26
                  goto pos34; // GOTO 34
pos30:
                  for (int K = 1; K <= NDIM; K++) //DO 33 K=1,NDIM
                      S = S + W[L][K] * pow((CFL[I][K] - CFL[J][K]),2); // 33
                  goto pos34; // GOTO 34
pos38:
                  for (int K = 1; K <= NDIM; K++) // DO 36 K=1,NDIM
                      S = S + W[L][K] * WS[I][K] * pow((CFL[I][K] - CFL[J][K]),2); // 36
pos34:
                  WC[N] = S;
                  WD[N] = S;
              }
          } // 35 CONTINUE
      } // 37 CONTINUE

//---------------------------------------------------------------------

//     PERFORM OPTIMAL SCALING (COMPUTE DISPARITIES)
//     ---------------------------------------------

      N = 1;
      if (NDTYP - 3 < 0) goto pos134;
      if (NDTYP - 3 > 0) goto pos42; // IF(NDTYP-3) 134,32,42

// -----  ORDINAL DATA  -----
pos32:
      if (NWC == 1) goto pos434; // IF(NWC.EQ.1) GOTO 434
      if (NWC == 2) goto pos506; // IF(NWC.EQ.2) GOTO 506

//     UNCONDITIONAL ORDINAL DATA

      if (NPS != 1) PRS(IX,IY,WC,NAB,XX,IZ,1);
      if (NPS == 1) SES(IX,IY,WD,NAB,IZ,1);
      TRS(WD,X,IX,NAB);
      if (NAB == NT) goto pos150; // IF(NAB.EQ.NT)GOTO 150
      NAB1 = NAB + 1;
      for (int I = NAB1; I <= NT; I++) // DO 151 I=NAB1,NT
      {
          J = IX[I];
          if (LAST == 1) OSEST = WC[J];
          X[J] = OSEST;
      } // 151
pos150:
      if (LAST == 1) return; // IF(LAST.EQ.1)RETURN
      LENGTH(WC,X,NT);
      MSTRS(NT,X,WC,STRSS,STRSS2);
      STRSS = sqrt(STRSS);
      return; // RETURN

//     MATRIX CONDITIONAL ORDINAL DATA

pos434:
      for (int L = 1; L <= NS; L++) // DO 435 L=1,NS
      {
          NC3 = NAD[L][1];
          if(NPS != 1) PRS(IX,IY,WC,NC3,XX,IZ,L);
          if(NPS == 1) SES(IX,IY,WD,NC3,IZ,L);
          TRS(WD,X,IX,NC3);
          if(NC3 >= NC2) goto pos453; // GOTO 453
          NI = N + NC3;
          NE = N + NC2 - 1;
          for (int I = NI; I <= NE; I++) // DO 152 I=NI,NE
          {
              J = IX[I] + N - 1;
              if(LAST == 1) OSEST = WC[J];
              X[J] = OSEST;
          } // 152
pos453:
          if(LAST == 1) goto pos1436; // GOTO 1436
          LENGTH(WC,X,NC2);
          MSTRS(NC2,X,WC,STRSS1,STRSS2);
          STRSS = STRSS + STRSS1;
pos1436:
          N = N + NC2;
      } //  435 CONTINUE
      STRSS = sqrt(STRSS / NS);
      return;

//     ROW CONDITIONAL ORDINAL DATA

pos506:
      N1 = 0;
      for (int L = 1; L <= NS; L++) // DO 507 L=1,NS
      {
          for (int I = 1; I <= NB; I++) // DO 507 I=1,NB
          {
              NC3 = NAD[L][I];
              N1 = N1 + 1;
              if((NSIM > 3) && (I <= NCOL)) goto pos504; // GOTO 504
              if(NPS != 1) PRS(IX,IY,WC,NC3,XX,IZ,N1);
              if(NPS == 1) SES(IX,IY,WD,NC3,IZ,N1);
              TRS(WD,X,IX,NC3);
pos504:
              if(NC3 >= NB) goto pos505; // GOTO 505
              if((NSIM > 3) && (I <= NCOL)) X[N + I - 1] = 0.0;
              NI = N + NC3;
              NE = N + NB - 1;
              for (int J = NI; J <= NE; J++) // DO 508 J=NI,NE
              {
                  int K = IX[J] + N - 1;
                  if(LAST == 1) OSEST = WC[K];
                  X[K] = OSEST;
              }  // 508
pos505:
              if(LAST == 1)goto pos1506; // GOTO 1506
              LENGTH(WC,X,NB);
              MSTRS(NB,X,WC,STRSS1,STRSS2);
              STRSS = STRSS + STRSS1;
pos1506:
              N = N + NB;
          }
      } // 507 CONTINUE
      NA = NB;
      if(NSIM > 3) NA = NB - NCOL;
      STRSS = sqrt(STRSS / (NA * NS));
      return;

//  -----  NOMINAL DATA  -----

pos42:
      if(NWC == 1) goto pos436; // GOTO 436
      if(NWC == 2) goto pos509; // GOTO 509

//     UNCONDITIONAL NOMINAL DATA

      CATSES(WC,X,IX,NT,WD,NDCT);
      if((NAB == NT) || (NPS != 1)) goto pos43; // GOTO 43
      for (int I = 1; I <= NT; I++) // DO 201 I=1,NT
      {
          if(LAST == 1) OSEST = WC[I];
          if(IX[I] == NDCT) X[I] = OSEST;
      } // 201
pos43:
      if(LAST == 1)return;
      LENGTH(WC,X,NT);
      MSTRS(NT,X,WC,STRSS,STRSS2);
      STRSS = sqrt(STRSS);
      return;

//     MATRIX CONDITIONAL NOMINAL DATA

pos436:
      for (int L = 1; L <= NS; L++) // DO 437 L=1,NS
      {
          CATSES(WC,X,IX,NC2,WD,NDSR[L][1]);
          if ((NAD[L][1] == NC2) || (NPS != 1)) goto pos637; // GOTO 637
          NE = N + NC2 - 1;
          for (int I = N; I <= NE; I++) // DO 202 I=N,NE
          {
              if(LAST == 1) OSEST = WC[I];
              if(IX[I] == NDSR[L][1]) X[I] = OSEST;
          } // 202
pos637:
          if(LAST == 1) goto pos2436; // GOTO 2436
          LENGTH(WC,X,NC2);
          MSTRS(NC2,X,WC,STRSS1,STRSS2);
          STRSS = STRSS + STRSS1;
pos2436:
          N = N + NC2;
      } //  437 CONTINUE
      STRSS = sqrt(STRSS / NS);
      return;

//     ROW CONDITIONAL NOMINAL DATA

pos509:
      for (int L = 1; L <= NS; L++) // DO 510 L=1,NS
      {
          for (int I = 1; I <= NB; I++) // DO 510 I=1,NB
          {
              if ((NSIM > 3) && (I <= NCOL)) goto pos503; //GOTO 503
              CATSES(WC,X,IX,NB,WD,NDSR[L][I]);
pos503:
              if ((NAD[L][I] == NB) || (NPS != 1)) goto pos610; // GOTO 610
              if ((NSIM > 3) && (I <= NCOL)) X[N+I-1] = 0.0;
              NE = N + NB - 1;
              for (int J = N; J <= NE; J++) // DO 511 J=N,NE
              {
                  if(LAST == 1) OSEST = WC[J];
                  if(IX[J] == NDSR[L][I]) X[J] = OSEST;
              } // 511
pos610:
              if(LAST == 1) goto pos1510; // GOTO 1510
              LENGTH(WC,X,NB);
              MSTRS(NB,X,WC,STRSS1,STRSS2);
              STRSS = STRSS + STRSS1;
pos1510:
              N = N + NB;
          }
      } //  510 CONTINUE
      NA = NB;
      if(NSIM > 3)NA = NB - NCOL;
      STRSS = sqrt(STRSS / (NA * NS));
      return;

//     NUMERICAL DATA

pos134:
//  134 REWIND NDP
//      READ(NDP)WD
//      REWIND NDP
      if(LIN == 1) goto pos411; // GOTO 411
      for (int I = 1; I <= NT; I++) //DO 400 I=1,NT
      {
	      WDI = WD[I];
	      if(WDI !=BIG) WD[I] = WDI * WDI;
      } //  400 CONTINUE
pos411:
      if(NWC == 1) goto pos310; // GOTO 310
      if(NWC == 2) goto pos512; // GOTO 512

//     UNCONDITIONAL NUMERICAL DATA
//      void __fastcall POLYF(double *DISP, double *DIST, int N,
//                double *OBS, double **R, double *ALPH, int NDEG, int NCST, int NAB);

      POLYF(X,WC,NT,WD,R,ALPH,NDEG,NCST,NAB);
      if(LIN == 1) LINT(X,WC,NT,WD);
      if(LAST != 1)goto pos420; // GOTO 420
      for (int I = 1; I <= NT; I++) // DO 415 I=1,NT
          if(X[I] == BIG) X[I] = WC[I]; // 415
      return;
pos420:
      LENGTH(WC,X,NT);
      MSTRS(NT,X,WC,STRSS,STRSS2);
      STRSS = sqrt(STRSS);
      return;

//     MATRIX CONDITIONAL NUMERICAL DATA

pos310:
      for (L = 1; L <= NS; L++) //DO 311 L=1,NS
      {
          POLYF(X,WC,NC2,WD,R,ALPH,NDEG,NCST,NAD[L][1]);
          if (LIN == 1) LINT(X,WC,NC2,WD);
          if(LAST != 1)goto pos300; // GOTO 300
          for (int I = 1; I <= NC2; I++) // DO 305 I=1,NC2
          {
              NI = N + I - 1;
              if (X[NI] == BIG) X[NI] = WC[NI];
          } // 305
          goto pos1311; // GOTO 1311
pos300:
          LENGTH(WC,X,NC2);
          MSTRS(NC2,X,WC,STRSS1,STRSS2);
          STRSS = STRSS + STRSS1;
pos1311:
          N = N + NC2;
      } // 311 CONTINUE
      STRSS = sqrt(STRSS / NS);
      return;

//     ROW CONDITIONAL NUMERICAL DATA

pos512:
      for (int L = 1; L <= NS; L++)  // DO 513 L=1,NS
      {
          for (int I = 1; I <= NB; I++) //DO 513 I=1,NB
          {
              if ((NSIM > 3) && (I <= NCOL)) goto pos514; //GOTO 514
              if(NAD[L][I] <= 1) goto pos514; // GOTO 514
              POLYF(X,WC,NB,WD,R,ALPH,NDEG,NCST,NAD[L][I]);
              if(LIN == 1) LINT(X,WC,NB,WD);
              goto pos516; // GOTO 516
pos514:
              for (int J = 1; J <= NB; J++) // DO 515 J=1,NB
              {
                  int K = J + N - 1;
                  X[K] = WC[K];
              } // 515
pos516:
              if(LAST != 1) goto pos500; // GOTO 500
              for (int J = 1; J <= NB; J++) // DO 501 J=1,NB
              {
                  NI = N + J - 1;
                  if(X[NI] == BIG) X[NI] = WC[NI];
              } // 501
              goto pos1513; // GOTO 1513
pos500:
              LENGTH(WC,X,NB);
              MSTRS(NB,X,WC,STRSS1,STRSS2);
              STRSS = STRSS + STRSS1;
pos1513:
              N = N + NB;
          }
      } //  513 CONTINUE
      NA = NB;
      if (NSIM > 3) NA = NB - NCOL;
      STRSS = sqrt(STRSS / (NA * NS));
}
//***********************************************************************

void __fastcall TAlscaleForm::PRS(int *IR, int *IBK, double *D, int N,
               double *W, int *IZ, int L)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 08/12/82

//     PREPARES TIES FOR CONTINUOUS ORDINAL TRANSFORMATION
//     ARRANGE TIED OBSERVATIONS IN ORDER OF ESTIMATED VALUES

//-----------------------------------------------------------------------

//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 8/12/82
//      INTEGER IR,IBK,IZ
//      DIMENSION IR(1),IBK(1),D(1),W(1),IZ(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

      int NB, NE, I, J, K;

      NB = 1;
      if (L != 1) NB = IZ[L-1]; // IF(L.NE.1)NB=IZ(L-1)
      NE = IZ[L] - 2;
      if (NE < NB) return; // IF(NE.LT.NB) RETURN
      for (int JJ = NB; JJ <= NE; JJ+=2) // DO 30 JJ=NB,NE,2
      {
          I = IBK[JJ];
          if (I > N) return; // IF(I.GT.N) RETURN
          J = IBK[JJ+1];
          for (int I2 = 1; I2 <= J; I2++) //DO 10 I2=1,J
          {
              K = I + I2 - 1;
              W[I2] = D[IR[K]];
          } //  10 CONTINUE
          SHEL9(W,IR,J); // SHEL9(W[1],IR[I],J);   ?
      } //   30 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::SES(int *IR, int *IBK, double *D,int N, int *IZ, int L)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 08/04/82

//     PREPARES TIES FOR DISCRETE ORDINAL TRANSFORMATION
//     TAKE THE MEAN OF TIED OBSERVATIONS

//-----THE FOLLOWING STATEMENT WAS CHANGED FROM INTEGER*2 8/4/82
//      INTEGER IR,IBK,IZ
//      DIMENSION IR(1),IBK(1),D(1),IZ(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

      int NB, NE, JJ, I, J;
      double S;

      NB = 1;
      if (L != 1) NB = IZ[L-1]; // IF(L.NE.1)NB=IZ(L-1)
      NE = IZ[L] - 2;  // 21
      if (NE < NB) return; // IF(NE.LT.NB) RETURN
      for (int II = NB; II <= NE; II+= 2) //DO 30 II=NB,NE,2
      {
          I = IBK[II];
          if (I > N) return; // IF(I.GT.N) RETURN
          J = IBK[II+1];
          JJ = I + J - 1;
          S = 0.0;
          for (int K = I; K <= JJ; K++) //DO 10 K=I,JJ
              S = S + D[IR[K]]; // 10
          S =S / J;
          for (int K = I; K <= JJ; K++) //DO 12 K=I,JJ
              D[IR[K]] = S; // 12
      } //  30 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::TRS(double *DISP, double *DIST, int *IVEC, int NELE)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/23/82

//     COMPUTE KRUSKAL'S LEAST SQUARES MONOTONIC TRANSFORMATION

//     THIS ROUTINE DESTROYS THE DISTANCES IN DIST, THUS FORCING
//     DOUBLE STORAGE IN THE CALLING ROUTINE

//    WRITTEN BY ROSTYSLAW JAREMA LEWYCKYJ     MAY  1977

//----------------------------------------------------------------------

//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 7/23/82
//      INTEGER IVEC
//      DIMENSION DIST(1),DISP(1),IVEC(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

//     PLACE DISTANCES IN ASCENDING ORDER IN DIST

      int IM1, IMJ;
      double SUM, FN, DISPT;

      for (int I = 1; I <= NELE; I++) //DO 141 I=1,NELE
          DIST[I] = DISP[IVEC[I]]; // 141

//     PERFORM KRUSKAL'S LEAST SQUARES MONOTONIC TRANSFORMATION
//     PLACING RESULTING DISPARITIES IN DISP

      for (int I = 2; I <= NELE; I++) // DO 70 I=2,NELE
      {
          IM1 = I - 1;

//     DETERMINE IF ORDER IS CORRECT

          if (DIST[I] >= DIST[IM1]) continue; //IF(DIST(I).GE.DIST(IM1))GOTO 70
          SUM = DIST[I];
          FN = 1.0;

//     IF NOT DETERMINE BLOCK SIZE

          for (int J = 1; J <= IM1; J++) // DO 10 J=1,IM1
          {
              IMJ = I - J;
              SUM = SUM + DIST[IMJ];
              FN = FN + 1.0;
              DISPT = SUM / FN;
              if (J == IM1) goto pos20; // IF(J.EQ.IM1)GOTO 20
              if (DISPT >= DIST[IMJ - 1]) goto pos20; // IF(DISPT.GE.DIST(IMJ-1))GOTO 20
          } //  10 CONTINUE

//     SET BLOCK OF DISPARITIES EQUAL TO MEAN DISTANCE IN BLOCK
pos20:
          for (int K = IMJ; K <= I; K++) // DO 30 K=IMJ,I
              DIST[K] = DISPT; // 30
      } // 70 CONTINUE

//     PLACE DISPARITIES IN DISP IN STANDARD ORDER

      for (int I = 1; I <= NELE; I++)  // DO 40 I=1,NELE
          DISP[I] = DIST[I]; // 40
      for (int I = 1; I <= NELE; I++) // DO 143 I=1,NELE
          DIST[IVEC[I]] = DISP[I]; // 143
}
//***********************************************************************

void __fastcall TAlscaleForm::LENGTH(double *DIST, double *DISP, int N)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 11/10/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     NORMALIZE LENGTH OF DISPARITIES SO THAT THEY OPTIMIZE
//        NORMALIZED SSTRESS INSTED OF RAW STRESS.
//        ADJUSTMENT IS BASED ONLY ON DISTANCES WHICH CORRESPOND TO
//        ACTIVE DATA.  ADJUSTMENT IS ONLY MADE TO DISPARITIES WHICH
//        CORRESPOND TO ACTIVE DATA.  TYPE OF ADJUSTMENT DEPENDS ON
//        STRESS FORMULA BEING OPTIMIZED.

//-----------------------------------------------------------------------

//      DIMENSION DIST(1),DISP(1)
//      DOUBLE PRECISION SSQ,SPD,RATIO,DISTV,PROD,DISTM,DISPM
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL

      double SSQ, SPD, RATIO, DISTV, PROD, DISTM, DISPM;
      int NACT;

      if (NSIM > 3) goto pos3; // IF(NSIM.GT.3)GOTO 3

//     ADJUSTMENT FOR STRESS FORMULA 1

      SSQ = 0.0;
      SPD = 0.0;
      for (int I = 1; I <= N; I++) //DO 1 I=1,N
      {
          if (DISP[I] == BIG) continue; //IF(DISP(I).EQ.BIG)GOTO 1
          SSQ = SSQ + (DIST[I] * DIST[I]); //*2
          SPD = SPD + DIST[I] * DISP[I];
      } // 1 CONTINUE
      if (SPD == 0.0) return; // IF(SPD.EQ.0.0)RETURN
      RATIO = SSQ / SPD;
      for (int I = 1; I <= N; I++) //DO 2 I=1,N
      {
          if (DISP[I] == BIG) continue; // IF(DISP(I).EQ.BIG)GOTO 2
          DISP[I] = DISP[I] * RATIO;
      } //  2 CONTINUE
      return; // RETURN

//     ADJUSTMENT FOR STRESS FORMULA 2

pos3:
      DISTM = 0.0;
      DISPM = 0.0;
      NACT = 0;
      for (int I = 1; I <= N; I++) //DO 4 I=1,N
      {
          if (DISP[I] == BIG) continue; // IF(DISP(I).EQ.BIG)GOTO 4
          DISTM = DISTM + DIST[I];
          DISPM = DISPM + DISP[I];
          NACT = NACT + 1;
      } //  4 CONTINUE
      DISTM = DISTM / NACT;
      DISPM = DISPM / NACT;
      PROD = 0.0;
      DISTV = 0.0;
      for (int I = 1; I <= N; I++) // DO 5 I=1,N
      {
          if (DISP[I] == BIG) continue; //IF(DISP(I).EQ.BIG)GOTO 5
          DISTV = DISTV + pow((DIST[I] - DISTM),2);
          PROD = PROD + (DIST[I] - DISTM) * (DISP[I] - DISPM);
      } //  5 CONTINUE
      if (PROD == 0.0) return; //IF(PROD.EQ.0.0)RETURN
      RATIO = DISTV / PROD;
      for (int I = 1; I <= N; I++) // DO 6 I=1,N
      {
          if (DISP[I] == BIG) continue; //IF(DISP(I).EQ.BIG)GOTO 6
          DISP[I] = DISP[I] * RATIO + DISTM * (1.0 - RATIO);
      } //  6 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::CATSES(double *WA, double *WC, int *IDY, int N,
                double *CIV, int NCAT)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/23/82

//     ROUTINE TO COMPUTE DISCRETE NOMINAL TRANSFORMATION
//        (DISPARITIES ARE MEANS OF ALL DISTANCES IN CATEGORY)

//-----------------------------------------------------------------------

//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 7/23/82
//      INTEGER IDY(1)
//      DIMENSION WA(1),CIV(1),WC(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

      int I, ID;

      for (I = 1; I <= NCAT; I++) //DO 10 I=1,NCAT
      {
          CIV[I] = 0.0;
          WC[I] = 0.0;
      } // 10

//     AT THIS MOMENT WC IS BEING USED AS SCRATCH SPACE.
//     LATER IT WILL BE ASSIGNED NEW VALUES TO BE RETURNED TO THE
//     CALLING ROUTINE

      for (I = 1; I <= N; I++) // DO 11 I=1,N
      {
          ID = IDY[I];
          CIV[ID] = CIV[ID] + WA[I];
          WC[ID] = WC[ID] + 1.0;
      } // 11
      for (I = 1; I <= NCAT; I++) //DO 12 I=1,NCAT
      {
          CIV[I] = CIV[I] / WC[I];
      } //  12 CONTINUE

//     NOW WC IS ASSIGNED VALUES TO BE RETURNED TO THE CALLER

      for (I = 1; I <= N; I++) // DO 13 I=1,N
          WC[I] = CIV[IDY[I]]; // 13
}
//***********************************************************************

void __fastcall TAlscaleForm::POLYF(double *DISP, double *DIST, int N,
                double *OBS, double **R, double *ALPH, int NDEG, int NCST, int NAB)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/02/82

//     POLYNOMIAL FITTING

//-----------------------------------------------------------------------

//      DIMENSION DISP(1),DIST(1),OBS(1)
//      DIMENSION R(5,5),XY(5),ALPH(5)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSS2,NB,NS,NDTYP,NPS,NWC,MDEG,NT,NBS,NBNBNS

      double *XY;
      int NOR, LIN, I, J, K, L, I1, NOR1, J1;
      double G;

      NOR = NDEG;
      LIN = 0;
      if ((NOR == 1) && (NCST == 1)) LIN = 1;
      if (LIN == 1) NOR = 2;
      NOR1 = NOR + 1;
      for (I = 1; I <= NOR1; I++) // DO 11 I=1,NOR1
      {
          XY[I] = 0.0;
          for (J = 1; J <= I; J++) // DO 11 J=1,I
              R[I][J] = 0.0;
      } //
      R[1][1] = NAB;
      for (K = 1; K <= N; K++) // DO 12 K=1,N
      {
          if (OBS[K] == BIG) continue;  //GOTO 12
          G = 1.0;
          XY[1] = XY[1] + DIST[K];
          L = 0;
          for (I = 2; I <= NOR1; I++) //DO 13 I=2,NOR1
          {
              I1 = I - 1;
              for (J = I1; J <= I; J++) //DO 13 J=I1,I
              {
                  G = G * OBS[K];
                  L = L + 1;
                  R[I][J] = R[I][J] + G;
                  if (L > NOR) continue; // GOTO 13
                  XY[L+1] = XY[L+1] + G * DIST[K];
              }
          } //   13 CONTINUE
      } //  12 CONTINUE
      if (NOR1 < 3) goto pos117; // GOTO 117
      for (I = 3; I <= NOR1; I++) // DO 15 I=3,NOR1
      {
          K = I - 2;
          for (J = 1; J <= K; J++) // DO 15 J=1,K
              R[I][J] = R[I-1][J+1];
      } // 15
pos117: //  117 CONTINUE
      for (I = 1; I <= NOR1; I++) // DO 16 I=1,NOR1
          for (J = 1; J <= I; J++) // DO 16 J=1,I
              R[J][I] = R[I][J]; // 16
      if (NCST == 1) goto pos20; // GOTO 20
      for (I = 2; I <= NOR1; I++) // DO 21 I=2,NOR1
      {
          I1 = I - 1;
          XY[I1] = XY[I];
          for (J = 2; J <= NOR1; J++) // DO 21 J=2,NOR1
          {
              J1 = J - 1;
              R[I1][J1] = R[I][J];
          }
      }
      NOR1 = NOR;
pos20: //  20 CONTINUE
      MINV(R,NOR1,5);
      for (I = 1; I <= NOR1; I++) // DO 17 I=1,NOR1
      {
          ALPH[I] = 0.0;
          for (J = 1; J <= NOR1; J++) //DO 17 J=1,NOR1
              ALPH[I] = ALPH[I] + R[I][J] * XY[J];
      } // 17
      if (LIN == 1) return;
      for (K = 1; K <= N; K++) // DO 25 K=1,N
      {
          if (OBS[K] == BIG) goto pos23; // GOTO 23
          DISP[K] = ALPH[1];
          if (NCST == 0) DISP[K] = ALPH[1] * OBS[K];
          if (NOR1 < 2) goto pos18; // GOTO 18
          G = 1.0;
          if (NCST == 0) G = OBS[K];
          for (I = 2; I <= NOR1; I++) // DO 19 I=2,NOR1
          {
              G = G * OBS[K];
              DISP[K] = DISP[K] + G * ALPH[I];
          } // 19
          goto pos18; // GOTO 18
pos23:
          DISP[K] = BIG;
pos18: // 18 CONTINUE

// THE FOLLOWING LINE HAS BEEN ADDED JULY 1982.  BEFORE THIS CHANGE
// ALL NUMERICAL LEVELS OF MEASUREMENT WERE UNCONSTRAINED EXCEPT
// LINEAR INTERVAL, WHICH WAS CONSTRAINED TO YIELD POSITIVE ESTIMATES.
// AFTER THIS CHANGE ALL NUMERICAL TRANSFORMATIONS EXCEPT LINEAR INTERVAL
// USE PIECE-WISE LINEAR REGRESSION.  NEFATIVELY EXTIMATED DISPARITIES
// ARE REPLACED WITH ZERO ESTIMATES. CHANGE MADE BY YOUNG AND SARLE.
// IMPLEMENTED BY BROOKS.

          if (DISP[K] < 0.0) DISP[K] = 0.0;
      } //  25 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::BLOC2(double *A,int *LL, int IZ, int N)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/23/82

//     FIND BLOCKS OF TIES

//-----------------------------------------------------------------------

//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 7/23/82
//      INTEGER LL,IZ
//      DIMENSION A(N),LL(N)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL

      int II, I, IMI;
      char outline[101];

      II = 1;
pos2:
      I = II;
pos3:
      II = II + 1;
      if (II > N) goto pos7; // GOTO 7
      if (A[I] == A[II]) goto pos3; // GOTO 3
pos7:
      IMI = II - I;
      if (IMI == 1) goto pos10; // GOTO 10
      if (IZ >= NDMX-1) goto pos4; // GOTO 4
      LL[IZ] = I;
      LL[IZ+1] = IMI;
      IZ = IZ + 2;
pos10:
      if (II >= N) return;
      goto pos2; // GOTO 2
pos4:
      FrmOutPut->RichOutPut->Lines->Add(" ALSCAL FATAL ERROR:    COMPUTATIONS TERMINATED!");
      sprintf(outline,"MAXIMUM NUMBER OF TIE-BLOCKS EXCEEDS %6d",NDMX);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->ShowModal();
      
//4 WRITE(LOUT,9900)
//  WRITE(LOUT,200)NDMX
// 9900 FORMAT(/' ALSCAL FATAL ERROR:    COMPUTATIONS TERMINATED')
//  200 FORMAT(8X,'MAXIMUM NUMBER OF TIE-BLOCKS EXCEEDS',I6)
}
//*********************************************************************

void __fastcall TAlscaleForm::INNER(double **CFL, double **W, double *X,
                double **WB, double **U11, double **U12, double **U22,
                double *UB1, double *UB2, double *XN, int NB, int NDIM,
                int NS, int NDX, int NBS,double **WS)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 03/22/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//  THIS ROUTINE COMPUTES STIMULUS COORDINATES

//----------------------------------------------------------------------

//      DIMENSION CFL(NB,1),W(NS,1),WB(NBS,1),X(1),WS(NB,1)
//      DIMENSION U11(NDX,1),U12(NDX,1),U22(NDX,1),UB1(1),UB2(1),XN(1)
//      DOUBLE PRECISION T1,T2,T3,T4,TU11,TU12,TU22
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL
//     +       /INICON/INITX,INITW,INITWS,INITXC

      int NNS, I, J, K, L, M, JK, LJ;
      double T1, T2, T3, T4, TU11, TU12, TU22;

      NNS = NB * NS;
      for (M = 1; M <= NB; M++) //DO 15 M=1,NB
      {
          if((INITX == 3) && (M > NCOL))continue; // GOTO 15
          if ((INITXC == 3) && (M <= NCOL)) continue; // GOTO 15
          for (I = 1; I <= NDIM; I++) // DO 13 I=1,NDIM
          {
              T1 = WS[M][I];
              for (J = 1; J <= NDIM; J++) // DO 13 J=1,NDIM
              {
                  T2 = T1 * WS[M][J];
                  TU11 = 0.0;
                  TU12 = 0.0;
                  TU22 = 0.0;
                  for (L = 1; L <= NB; L++) // DO 14 L=1,NB
                  {
                      if (L == M) continue; // GOTO 14
                      T3 = 0.0;
                      for (K = 1; K <= NS; K++) // DO 24 K=1,NS
                          T3 = T3 + W[K][I] * W[K][J]; // 24
                      if (J > I) goto pos12; // GOTO 12
                      TU22 = TU22 + T3 * T2;
                      TU11 = TU11 + T3 * T2 * CFL[L][I] * CFL[L][J];
pos12:
                      TU12 = TU12 + T3 * T2 * CFL[L][I];
                  } //  14 CONTINUE
                  if (J > I) continue; // GOTO 13
                  U11[I][J] = TU11;
                  U22[I][J] = TU22;
                  U12[I][J] = TU12;
              }
          } // 13
          JK = 0;
          for (K = 1; K <= NS; K++)  // DO 39 K=1,NS
          {
              LJ = (M-1) * NB;
              for (J = 1; J <= NB; J++) //DO 39 J=1,NB
              {
                  JK = JK + 1;
                  LJ = LJ + 1;
                  if (J == M) goto pos153; // GOTO 153
                  T1 = WB[LJ][K];
                  for (I = 1; I <= NDIM; I++) //DO 40 I=1,NDIM
                      T1 = T1 - W[K][I] * pow(CFL[J][I],2) * WS[M][I]; // 40
                  X[JK] = T1;
                  goto pos39; // GOTO 39
pos153:
                  X[JK] = 0.0;
pos39:
              }
          } //  39 CONTINUE
          for (I = 1; I <= NDIM; I++) // DO 16 I=1,NDIM
          {
              T1 = 0.0;
              T2 = 0.0;
              JK = 0;
              for (K = 1; K <= NS; K++) // DO 18 K=1,NS
              {
                  T3 = 0.0;
                  T4 = 0.0;
                  for (J = 1; J <= NB; J++) // DO 17 J=1,NB
                  {
                      JK = JK + 1;
                      T4 = T4 + X[JK];
                      T3 = T3 + CFL[J][I] * X[JK];
                  } // 17
                  T1 = T1 + T3 * W[K][I];
                  T2 = T2 + T4 * W[K][I];
              } // 18
              UB1[I] = T1 * WS[M][I];
              UB2[I] = T2 * WS[M][I];
          } //  16 CONTINUE
          if (NSIM < 2) goto pos50; // GOTO 50
          if (NWE < 2) goto pos80; // GOTO 80
          for (I = 1; I <= NDIM; I++) // DO 84 I=1,NDIM
          {
              for (J = 1; J <= NDIM; J++) // DO 84 J=1,NDIM
              {
                  TU11 = 0.0;
                  TU22 = 0.0;
                  TU12 = 0.0;
                  for (L = 1; L <= NB; L++) // DO 83 L=1,NB
                  {
                      if (L == M) continue; // GOTO 83
                      T1 = 0.0;
                      for (K = 1; K <= NS; K++) //DO 82 K=1,NS
                          T1 = T1 + W[K][I] * W[K][J]; // 82
                      if (J > I) goto pos81; // GOTO 81
                      TU22 = TU22 + T1 * (WS[L][I] * WS[L][J]);
                      TU11 = TU11 + T1 * (WS[L][I] * WS[L][J]) * CFL[L][I] * CFL[L][J];
pos81:
                      TU12 = TU12 + T1 * (WS[L][I] * WS[L][J]) * CFL[L][I];
                  } //  83 CONTINUE
                  if (J > I) goto pos84; // GOTO 84
                  U11[I][J] = (U11[I][J] + TU11) * 0.5;
                  U22[I][J] = (U22[I][J] + TU22) * 0.5;
pos84:
                  U12[I][J] = (U12[I][J] + TU12) * 0.5;
              }
          } //84
pos80: //  80 CONTINUE
          JK = NNS;
          for (K = 1; K <= NS; K++) //DO 59 K=1,NS
          {
              LJ = M - NB;
              for (J = 1; J <= NB; J++) // DO 59 J=1,NB
              {
                  JK = JK + 1;
                  LJ = LJ + NB;
                  if (M == J) goto pos253; //GOTO 253
pos254:
                  T1 = WB[LJ][K];
                  for (I = 1; I <= NDIM; I++) // DO 60 I=1,NDIM
                      T1 = T1 - W[K][I] * pow(CFL[J][I],2) * WS[J][I]; // 60
                  X[JK] = T1;
                  goto pos59; //GOTO 59
pos253:
                  X[JK] = 0.0;
pos59:
              }
          }   //  59 CONTINUE
          for (I = 1; I <= NDIM; I++) //DO 66 I=1,NDIM
          {
              T1 = 0.0;
              T2 = 0.0;
              JK = NNS;
              for (K = 1; K <= NS; K++) // DO 67 K=1,NS
              {
                  T3 = 0.0;
                  T4 = 0.0;
                  for (J = 1; J <= NB; J++) // DO 65 J=1,NB
                  {
                      JK = JK + 1;
                      T3 = T3 + X[JK] * WS[J][I] * CFL[J][I];
                      T4 = T4 + X[JK] * WS[J][I];
                  } // 65
                  T1 = T1 + W[K][I] * T3;
                  T2 = T2 + W[K][I] * T4;
              } // 67
              UB1[I] = (UB1[I] + T1) * 0.5;
              UB2[I] = (UB2[I] + T2) * 0.5;
          } // 66
pos50: //  50 CONTINUE
          for (I = 1; I <= NDIM; I++) // DO 68 I=1,NDIM
          {
              for (J = 1; J <= NDIM; J++) // DO 86 J=1,NDIM
              {
                  if (J > I) goto pos86; // GOTO 86
                  U11[I][J] = 4.0 * U11[I][J];
                  U11[J][I] = U11[I][J];
                  U22[J][I] = U22[I][J];
pos86:
                  U12[I][J] = -2.0 * U12[I][J];
              }
              UB1[I] = -2.0 * UB1[I];
          } // 68

          COEF(U11,U12,U22,UB1,UB2,NDIM,CFL,M,XN,NB,NDX);
      } // 15 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::COEF(double **U11, double **U12, double **U22,
                 double *UB1, double *UB2, int NDIM, double **CFL, int M,
                 double *XN, int NB, int NDX)
{
// COPYRIGHT DECEMBER 1977 BY FORREST W. YOUNG AND ROSTYLWW
// FINAL CHANGE 12/14/77
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     SUBROUTINE TO OBTAIN LEAST SSTRESS COORDINATES
//     BY SOLVING A SYSTEM OF CUBIC EQUATIONS FOR EACH COORDINATE
//     (TAKANE, YOUNG & DE LEEUW, PSYCHOMETRIKA, 1977)

//-----------------------------------------------------------------------

//      DIMENSION U11(NDX,1),U12(NDX,1),U22(NDX,1),CFL(NB,1),
//     *UB1(1),UB2(1),XN(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

      double A, P, Q, R;
      int I, L, LL;

      for (LL = 1; LL <= 30; LL++) // DO 20 LL=1,30
      {
          for (I = 1; I <= NDIM; I++) // DO 9 I=1,NDIM
              XN[I] = CFL[M][I]; // 9
          for (L = 1; L <= NDIM; L++) //DO 10 L=1,NDIM
          {
              A = 2.0 * U22[L][L];
              P = 3.0 * U12[L][L] / A;
              Q = U11[L][L] - 2.0 * UB2[L];
              R = -UB1[L];
              for (I = 1; I <= NDIM; I++) //DO 11 I=1,NDIM
              {
                  if(I == L) continue; // GOTO 11
                  Q = Q + 2.0 * CFL[M][I] * (U12[I][L] + U22[L][I] * CFL[M][I]);
                  R = R + CFL[M][I] * (U11[L][I] + U12[L][I] * CFL[M][I]);
              } //  11 CONTINUE
              Q = Q / A;
              R = R / A;
              SCUBE(P,Q,R,CFL[M][L]);
          } //  10 CONTINUE
          for (L = 1; L <= NDIM; L++) //DO 12 L=1,NDIM
          {
              if(fabs(CFL[M][L] - XN[L]) > 0.0001) goto pos20; //GOTO 20
          } //  12 CONTINUE
          return;
pos20:
      } //  20 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::SCUBE(double P, double Q, double R, double CUBE)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 12/14/77
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     SOLUTION TO A CUBIC EQUATION

//-----------------------------------------------------------------------

//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
      double R3 = 0.33333333;
      double R27 = 3.703704e-2;
//      DATA R3,R27/0.33333333,3.703704E-2/
//      F(X) = (((X * 0.25 + P * R3) * X + Q * 0.5) * X + R) * X;
      double CMAX, A, B, D, E, T3, C1, C2, C3;

      A = (3.0 * Q - P*P) * R3;
      B = (P * P + P * P - 9.0 * Q) * P * R27 + R;
      D = B * B * 0.25 + pow(A,3) * R27;
      if(D < 0.0) goto pos1;
      E = sqrt(D) - 0.5 * B;
      CUBE = SIGN(pow(fabs(E),R3),E) - P * R3;
      E = -(E + B);
      CUBE = SIGN(pow(fabs(E),R3),E) + CUBE;
      return;
pos1: T3 = acos(-B / (2.0 * sqrt(pow(-A,3) * R27))) * R3;
      E = 2.0 * sqrt(-A * R3);
      C1 = cos(T3);
      C2 = cos(T3 + 4.1887902);
      C3 = cos(T3 + 2.0943951);
      CUBE = AMIN1(C1,C2,C3) * E -P * R3;
      CMAX = AMAX1(C1,C2,C3) * E - P * R3;
      if(F(CMAX,P,Q,R) < F(CUBE,P,Q,R)) CUBE = CMAX;
}
//***********************************************************************

void __fastcall TAlscaleForm::MSTRS(int N, double *DISP, double *DIST, double STRSS1, double RESID)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 11/08/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

// ROUTINE TO CALCULATE THE STRESS OF TWO VECTORS
// AND TO ESTIMATE MISSING DATA

//     STRESS 1 OR 2 IS CALCULATED (NORMALIZED BY DISPARITIES, WHICH IS
//        THE SAME AS BY DISTANCES).  THE RESIDUAL VARIANCE (1-RSQ)
//        IS CALCULATED FOR NORMALIZATION OF DERIVED WEIGHTS.

//     ESTIMATES OF MISSING DATA ARE THEIR DISTANCES

//-----------------------------------------------------------------------

//      DIMENSION DISP(1),DIST(1)
//      DOUBLE PRECISION SV4,SV4SQ,SSQ,SXY,S4,S4SQ
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK1/NC,ND,BIG,NC2,NDT,NNC,NPH,NPT,NSC,
//     + EPSI,NDIM,NDX,NDXS,NDXP,MAXIT,NADCT,NDCT,STRSO,
//     + STRSS,STRSSB,NB,NS,NDTYP,NPS,NWC,NDEG,NT,NBS,NBNBNS
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL

      int NACT = 0;
      double SXY = 0.0;
      double S4 = 0.0;
      double S4SQ = 0.0;
      double SV4 = 0.0;
      double SV4SQ = 0.0;
      double SSQ = 0.0;
      double DISPM, SVAR;

      for (int I = 1; I <= N; I++) // DO 110 I=1,N
      {
          if(DISP[I] == BIG) goto pos100; // GOTO 100
          S4 = S4 + DIST[I];
          SV4 = SV4 + DISP[I];
          SV4SQ = SV4SQ + (DISP[I] * DISP[I]);
          S4SQ = S4SQ + (DIST[I] * DIST[I]);
          SXY = SXY + (DIST[I] * DISP[I]);
          SSQ = SSQ + pow((DISP[I] - DIST[I]),2);
          NACT = NACT + 1;
          goto pos110; // GOTO 110
pos100:
          DISP[I] = DIST[I];
pos110:
      } //   110 CONTINUE
      if (NACT <= 1)goto pos120; // GOTO 120
      if (NSIM < 4) goto pos118; // GOTO 118
      SVAR = 0.0;
      DISPM = SV4 / (double) NACT;
      for (int I = 1; I <= N; I++) // DO 117 I=1,N
      {
          if (DISP[I] == BIG) continue; // GOTO 117
          SVAR = SVAR + pow((DISP[I] - DISPM),2);
      } //   117 CONTINUE
      STRSS1 = SSQ / SVAR;
      goto pos119; // GOTO 119
pos118:
      STRSS1 = SSQ / SV4SQ;
pos119:
      RESID = 1.0 - pow((SXY - S4 * SV4 / (double) NACT),2) *
      ((S4SQ - S4 * S4 / (double) NACT) * (SV4SQ - SV4 * SV4 / (double) NACT));
      return;
pos120:
      STRSS1 = 0.0;
      RESID = 0.0;
}
//***********************************************************************

void __fastcall TAlscaleForm::NORMX(double **X, double **W, int NB, int NS, int ND, int NWE)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 02/12/80
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     NORMALIZE CONFIGURATION FOR PRINTING AT END OF JOB

//-----------------------------------------------------------------------

//      DIMENSION X(NB,1),W(NS,1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//      DOUBLE PRECISION SUMSQ,SUM

      double SUMSQ = 0.0;
      double SUM;

      for (int J = 1; J <= ND; J++) // DO 4 J=1,ND
      {
//     CENTER CONFIGURATION AT CENTROID

          SUM = 0.0;
          for (int I = 1; I <= NB; I++) // DO 1 I=1,NB
              SUM = SUM + X[I][J]; // 1
          SUM = SUM / NB;
          for (int I = 1; I <= NB; I++) // DO 2 I=1,NB
          {
              X[I][J] = X[I][J] - SUM;
              SUMSQ = SUMSQ + (X[I][J] * X[I][J]);
          } // 2
          if (NWE == 0 ) continue; //GOTO 4

//     FOR ALL OF THE WEIGHTED MODELS NORMALIZE SO THAT THE LENGTH OF
//     EACH STIMULUS DIMENSION IS UNITY

          SUMSQ = sqrt((double)NB / SUMSQ);
          for (int I = 1; I <= NB; I++) // DO 3 I=1,NB
              X[I][J] = SUMSQ * X[I][J]; // 3
          SUMSQ = 1.0 / (SUMSQ * SUMSQ);
          for (int I = 1; I <= NS; I++) // DO 6 I=1,NS
              W[I][J] = SUMSQ * W[I][J]; // 6
          SUMSQ = 0.0;
      } //  4 CONTINUE
      if (NWE > 0) return;

//     FOR THE UNWEIGHTED MODEL NORMALIZE LENGTH OF THE DIMENSIONS SO
//     THAT THEIR AVERAGE LENGTH IS UNITY.

      SUMSQ = sqrt((double)(NB * ND) / SUMSQ);
      for (int J = 1; J <= ND; J++) //DO 5 J=1,ND
          for (int I = 1; I <= NB; I++) //DO 5 I=1,NB
              X[I][J] = SUMSQ * X[I][J]; // 5
}
//***********************************************************************

void __fastcall TAlscaleForm::NORMW(double **W, int N, int ND,double PHI,double *PHIROW, int ICONFL)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 12/14/77
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     ROUTINE TO NORMALIZE WEIGHT MATRICES FOR OUTPUT

//-----------------------------------------------------------------------

//      DIMENSION W(N,1),PHIROW(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//      DOUBLE PRECISION SUMSQ

//     NORMALIZE EITHER STIMULUS OR SUBJECT WEIGHTS SO THAT THEIR
//     LENGTH CORRESPONDS TO THE PROPORTION  OF VARIANCE IN THE
//     OPTIMALLY SCALED DATA ACCOUNTED FOR BY THE MODEL.

      double SUMSQ = 0.0;

      for (int I = 1; I <= N; I++) // DO 3 I=1,N
      {
          for (int J = 1; J <= ND; J++) // DO 1 J=1,ND
              SUMSQ = SUMSQ + (W[I][J] * W[I][J]); // 1
          if(ICONFL == 1) continue; // GOTO 3

//     COME HERE WHEN CONDITIONALITY IS SUCH THAT EACH ROW OF WEIGHTS
//     IS NORMALIZED SEPARATELY.

          SUMSQ = sqrt(PHIROW[I] / SUMSQ);
          for (int J = 1; J <= ND; J++) // DO 2 J=1,ND
              W[I][J] = SUMSQ * W[I][J]; // 2
          SUMSQ = 0.0;
      } //    3 CONTINUE
      if(ICONFL == 0) return;

//     COME HERE WHEN CONDITIONALITY IS SUCH THAT ROWS ARE
//     NORMALIZED JOINTLY.

      SUMSQ = sqrt(N * PHI / SUMSQ);
      for (int J = 1; J <= ND; J++) //DO 4 J=1,ND
          for (int I = 1; I <= N; I++) //DO 4 I=1,N
              W[I][J] = SUMSQ * W[I][J]; // 4
}
//***********************************************************************

void __fastcall TAlscaleForm::ARNGE(double **W, double **X, double **WS, int NB,
                 int NS, int NDIM, double *TR)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/23/82

//     SUBROUTINE TO REARRANGE WEIGHT AND STIMULUS MATRICES

//-----------------------------------------------------------------------

//      DOUBLE PRECISION T
//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 7/23/82
//      INTEGER NN
//      DIMENSION W(NS,1),X(NB,1),TR(1),NN(6),WS(NB,1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//     +       /BLOCK2/NCST,NSIM,NWE,NDMX,NAB,NCOL

      int *NN;
      int I, J, JJ, K;
      double T, WK;

      NN = new int[NDIM+1];

      NN[1] = 1;
      for (J = 1; J <= NDIM; J++) // DO 11 J=1,NDIM
      {
          T = 0.0;
          if (NWE / 2 * 2 == NWE) goto pos20; // GOTO 20   ?
          for (I = 1; I <= NS; I++) // DO 10 I=1,NS
              T = T + W[I][J]; //  10
          goto pos11; // GOTO 11
pos20:
          if(NWE < 2) goto pos30; // GOTO 30
          for (I = 1; I <= NB; I++) // DO 40 I=1,NB
              T = T + WS[I][J]; // 40
          goto pos11; // GOTO 11
pos30:
          for (I = 1; I <= NB; I++) // 30 DO 22 I=1,NB
              T = T + pow(X[I][J],2); // 22
pos11:
         TR[J] = (-T);
      }
//     SORT TR INTO ASCENDING ORDER BY INSERTION SORT

      for (J = 2; J <= NDIM; J++) // DO 55 J=2,NDIM
      {
          T = TR[J];
          K = J - 1;
pos50:
          if (T >= TR[K])goto pos51; // GOTO 51
          TR[K + 1] = TR[K];
          NN[K + 1] = NN[K];
          K = K - 1;
          if(K >= 1) goto pos50; // GOTO 50
pos51:
          TR[K + 1] = T;
          NN[K+1] = J;
      } //   55 CONTINUE

      for (J = 1; J <= NDIM; J++) // DO 12 J=1,NDIM
      {
          K = NN[J];
          if (J == K) goto pos12; // GOTO 12
          for (I = 1; I <= NB; I++) // DO 13 I=1,NB
          {
              WK = X[I][J];
              X[I][J] = X[I][K];
              X[I][K] = WK;
          }
          if (NWE / 2 * 2 == NWE) goto pos25; // GOTO 25
          for (I = 1; I <= NS; I++) //DO 14 I=1,NS
          {
              WK = W[I][J];
              W[I][J] = W[I][K];
              W[I][K] = WK;
          } // 14
pos25:
          if(NWE < 2) goto pos31; // GOTO 31
          for (I = 1; I <= NB; I++) // DO 32 I=1,NB
          {
              WK = WS[I][J];
              WS[I][J] = WS[I][K];
              WS[I][K] = WK;
          } // 32
pos31:  //  31 CONTINUE
          JJ = J + 1;
          for (I = JJ; I <= NDIM; I++) // DO 15 I=JJ,NDIM
          {
              if(NN[I] == J) goto pos16; // GOTO 16
          } //   15 CONTINUE
          goto pos12; // GOTO 12
pos16:
          NN[I] = K;
pos12:
      } //   12 CONTINUE

      delete[] NN;
}

//***********************************************************************

void __fastcall TAlscaleForm::EIGK(double **A, double *VALUE, int N, int NA)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 02/21/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     EIGEN-ROUTINE BY KAISER (JK METHOD)

//    REF: "THE EIGENVALUES OF A REAL SYMMETRIC MATRIX"
//  BY H.F. KAISER .  IN  THE BRITISH COMPUTER JOURNAL
//  VOL 15 NO 3 PAGES 271-273.

//  THIS ROUTINE FINDS THE EIGENVALUES AND EIGENVECTORS OF A REAL
//  SYMMETRIC MATRIX. THE ABSOLUTE VALUES OF THE EIGENVALUES
//  ORDERED IN DESCENDING ORDER OF SIZE ARE RETURNED IN VALUE.
//  NORMALIZED EIGENVECTORS ARE RETURNED IN CORRESPONDING
//  COLUMNS OF A

//--------------------------------------------------------------------

//      DIMENSION A(NA,1),VALUE(N)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

//      DOUBLE PRECISION Q,HALFP
      double Q, HALFP, EPS, SIN, COS, TAN, CTN, ABSP, ABSQ, TEMP, D, AD, VL1, VL2;
      int NLESS1, NN, NCOUNT, JPLUS1;

      if ((N - 2) < 0) goto pos1;
      if ((N - 2) == 0) goto pos2;
      if ((N - 2) > 0) goto pos3;
pos3: Q = 0.0;
      for (int J = 1; J <= N; J++) // DO 101 J=1,N
      {
          for (int I = 1; I <= N; I++) //DO 101 I=1,N
          {
              Q = Q + A[I][J] * A[I][J];
          }
      } // 101
      EPS = 0.000001 * Q / N;
      NLESS1 = (N - 1);
      NN = (N - 1) * N / 2;
      NCOUNT = NN;
pos116:
      for (int J = 1; J <= NLESS1; J++) // DO 102 J=1,NLESS1
      {
          JPLUS1 = J + 1;
          for (int K = JPLUS1; K <= N; K++) // DO 102 K=JPLUS1,N
          {
              HALFP = 0.0;
              Q = 0.0;
              for (int I = 1; I <= N; I++) // DO 103 I=1,N
              {
                  HALFP = HALFP + A[I][J] * A[I][K];
                  Q = Q + (A[I][J] + A[I][K]) * (A[I][J] - A[I][K]);
              } // 103
              ABSP = fabs(HALFP + HALFP);
              if ((ABSP < EPS) && (Q >= 0.0)) goto pos106;
              ABSQ = fabs(Q);
              if(ABSP > ABSQ) goto pos108;
              TAN = ABSP / ABSQ;
              COS = 1.0 / sqrt(1.0 + TAN * TAN);
              SIN = TAN * COS;
              goto pos109;
pos108:       CTN = ABSQ / ABSP;
              SIN = 1.0 / sqrt(1.0 + CTN * CTN);
              COS = CTN * SIN;
pos109:       COS = sqrt((1.0 + COS) / 2.0);
              SIN = SIN / (COS + COS);
              if (Q >= 0.0) goto pos111;
              TEMP = COS;
              COS = SIN;
              SIN = TEMP;
pos111:       if(HALFP < 0.0) SIN = -SIN;
              for (int I = 1; I <= N; I++) // DO 114 I=1,N
              {
                  TEMP = A[I][J];
                  A[I][J] = TEMP * COS + A[I][K] * SIN;
                  A[I][K] = -TEMP * SIN + A[I][K] * COS;
              } // 114
              NCOUNT = NN;
              goto pos102;
pos106:       NCOUNT = NCOUNT - 1;
              if (NCOUNT <= 0) goto pos115;
pos102:   }
      }
      goto pos116;
pos115:
      for (int J = 1; J <= N; J++) //DO 117 J=1,N
      {
          VALUE[J] = 0.0;
          for (int I = 1; I <= N; I++) // DO 118 I=1,N
          {
              VALUE[J] = VALUE[J] + A[I][J] * A[I][J];
          } // 118
          VALUE[J] = sqrt(VALUE[J]);
      }  // 117
      for (int J = 1; J <= N; J++) // DO 119 J=1,N
      {
          for (int I = 1; I <= N; I++) //DO 119 I=1,N
          {
              A[I][J] = A[I][J] / VALUE[J];
          }
      } // 119
      return;
pos1:
      VALUE[1] = A[1][1];
      A[1][1] = 1.0;
      return;
pos2:
      AD = A[1][1] + A[2][2];
      D = sqrt(AD * AD - 4.0 * (A[1][1] * A[2][2] - A[1][2] * A[2][1]));
      VALUE[1] = (AD + D) * 0.5;
      VALUE[2] = AD - VALUE[1];
      VL1 = 1.0 / sqrt(A[1][2] * A[1][2] + pow((A[1][1] - VALUE[1]),2));
      A[2][1] = (VALUE[1] - A[1][1]) * VL1;
      VL2 = 1.0 / sqrt(A[1][2] * A[1][2] + pow((A[1][1] - VALUE[2]),2));
      A[2][2] = (VALUE[2] - A[1][1]) * VL2;
      A[1][1] = A[1][2] * VL1;
      A[1][2] = A[1][2] * VL2;
}
//***********************************************************************

void __fastcall TAlscaleForm::CJEIG(double **A, double **U,double **V,int N,
                int ND,double **B, double **W, double *ALAM, int NFT, int NB)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 12/14/77
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     EIGENVALUES AND VECTORS OF REAL SYMMETRIC MATRIX
//     BY CLINT AND JENNINGS' METHOD
//        WRITTEN BY YOSHIO TAKANE, 1974

//-----------------------------------------------------------------------

//      DIMENSION A(N ,1),U(N ,1),V(N ,1),B(NB,1),W(N ,1),ALAM(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR
//      DOUBLE PRECISION T1

      double T1;
      int ND1, J1, J2;

      ND1 = ND - 1;
      if (NFT != 1) goto pos11; // GOTO 11
      for (int J = 1; J <= ND; J++) // DO 36 J=1,ND
      {
          for (int I = 1; I <= N; I++) // DO 35 I=1,N
          {
              U[I][J] = 0.0;
          } // 35
          U[J][J] = 1.0;
      } // 36

pos11:
      for (int LL = 1; LL <= 30; LL++) //DO 1  LL=1,30
      {
          if(LL > 30) return;
          for (int I = 1; I <= N; I++) // DO 10 I=1,N
          {
              for (int J = 1; J <= ND; J++) // DO 10 J=1,ND
              {
                  T1 = 0.0;
                  for (int K = 1; K <= N; K++) //DO 9 K=1,N
                      T1 = T1 + A[I][K] * U[K][J]; // 9
                  V[I][J] = T1;
              }
          } // 10
          for (int I = 1; I <= ND; I++) // DO 13 I=1,ND
          {
              for (int J = 1; J <= ND; J++) // DO 13 J=1,ND
              {
                  T1 = 0.0;
                  for (int K = 1; K <= N; K++) // DO 12 K=1,N
                      T1 = T1 + U[K][I] * V[K][J]; // 12
                  B[I][J] = T1;
              }
          } // 13

          EIGK(B,ALAM,ND,NB);

          for (int I = 1; I <= N; I++) // DO 14 I=1,N
          {
              for (int J = 1; J <= ND; J++) // DO 14 J=1,ND
              {
                  T1 = 0.0;
                  for (int K = 1; K <= ND; K++) // DO 41 K=1,ND
                      T1 = T1 + V[I][K] * B[K][J]; // 41
                  W[I][J] = T1;
              }
          } // 14

          for (int I = 1; I <= ND; I++) // DO 15 I=1,ND
          {
              for (int J = 1; J <= ND; J++) //DO 15 J=1,ND
              {
                  T1 = 0.0;
                  for (int K = 1; K <= N; K++) // DO 51 K=1,N
                      T1 = T1 + W[K][I] * W[K][J]; // 51
                  B[I][J] = T1;
              }
          } // 15

//     CHOLESKY FACTORIZATION

          for (int I = 1; I <= ND; I++) // DO 16 I=1,ND
          {
              if(B[I][I] <= 0.0) goto pos18; // GOTO 18
              B[I][I] = sqrt(B[I][I]);
              if (I >= ND) goto pos18; // GOTO 18
              J1 = I + 1;
              for (int J = J1; J <= ND; J++) // DO 16 J=J1,ND
              {
                  B[I][J] = B[I][J] / B[I][I];
                  for (int K = J1; K <= J; K++) // DO 16 K=J1,J
                      B[K][J] = B[K][J] - B[I][J] * B[I][K];
              }
          }  // 16

pos18: // CONTINUE

//     INVERSE OF CHOLESKY FACTOR

          for (int I = 1; I <= ND; I++) // DO 60 I=1,ND
          {
              B[I][I] = 1.0 / B[I][I];
              if (I <= 1) continue; // GOTO 60
              J2 = I - 1;
              for (int J = 1; J <= J2; J++) //DO 62 J=1,J2
              {
                  T1 = 0.0;
                  for (int K = J; K <= J2; K++) // DO 63 K=J,J2
                      T1 = T1 - B[K][I] * B[K][J]; // 63
                  B[I][J] = T1 * B[I][I];
              } //   62 CONTINUE
          } //  60 CONTINUE

          for (int J = 1; J <= ND; J++)  //DO 30 J=1,ND
              for (int I = 1; I <= N; I++) // DO 30 I=1,N
                  V[I][J] = W[I][J]; // 30
          for (int I = 1; I <= N; I++) // DO 19 I=1,N
          {
              for (int J = 1; J <= ND; J++) //DO 19 J=1,ND
              {
                  T1 = 0.0;
                  for (int K = 1; K <= J; K++) // DO 24 K=1,J
                      T1 = T1 + V[I][K] * B[J][K]; // 24
                  W[I][J] = T1;
              }
          } // 19

//     TEST OF CONVERGENCE

          for (int J = 1; J <= ND1; J++) //DO 20 J=1,ND1
          {
              for (int I = 1; I <= N; I++) // DO 20 I=1,N
              {
                  if(fabs(W[I][J] - U[I][J]) > 1.0E-5) goto pos21;
              }
          } // 20
          for (int J = 1; J <= ND; J++) // DO 22 J=1,ND
              for (int I = 1; I <= N; I++) // DO 22 I=1,N
                  U[I][J] = W[I][J]; // 22
          return;
pos21:
          for (int J = 1; J <= ND; J++) // DO 23 J=1,ND
              for (int I = 1; I <= N; I++) // DO 23 I=1,N
                  U[I][J] = W[I][J]; // 23
      } // 1 CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::MINV(double **A1, int N, int NA)
{
// FINAL CHANGE 11/16/78
// EQUIVALENT TO ALSCAL82 VERSION (7/2/82)

//     OBTAIN THE INVERSE OF A SYMMETRIC MATRIX

//-----------------------------------------------------------------------

//      DIMENSION A(1),L(30),M(30)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

//  IF N IS 1 OR 2 INVERT DIRECTLY
      double *A;
      int *L, *M;
      int I, I1, I2, I3, I4, NK, KK, IZ, KI, J, K, JP, JK, JI, IK, IJ, KJ, JQ, JR;
      double C, W, HOLD, BIGA;

      // set up the two-dimensional array as a 1 dimensional array
      int k = 1;
      A = new double[(N+1)*(N+1)];
      for (int i = 1; i <= N; i++)
      {
          for (int j = 1; j <= N; j++)
          {
              k++;
              A[k] = A1[i][j];
          }
      }
      L = new int[(N+1)*(N+1)];
      M = new int[(N+1)*(N+1)];

      if ((N-2) < 0) //IF(N-2)200,300,400
      {
         A[1] = 1.0 / A[1]; // 200
         return;
      }
      if ((N-2) == 0)
      {
         C = 1.0 / (A[1] * A[NA + 2] - A[NA + 1] * A[2]);
         W = A[1];
         A[1] = A[NA + 2] * C;
         A[NA + 2] = W * C;
         A[NA + 1] = -A[NA + 1] * C;
         A[2] = -A[2] * C;
         return;
      }

//  PACK THE MATRIX

      K = N; // 400
      I1 = NA + 1;
      I2 = N * NA;
      for (int I3 = I1; I3 <= I2; I3+NA) // DO 10 I3=I1,I2,NA
      {
          I4 = I3 + N - 1;
          for (int I = I3; I <= I4; I++) //DO 10 I=I3,I4
          {
              K = K + 1;
              A[K] = A[I];
          }
      } // 10

//  SEARCH FOR LARGEST ELEMENT

      NK = -N;
      for (int K = 1; K <= N; K++) //DO 80 K=1,N
      {
          NK = NK + N;
          L[K] = K;
          M[K] = K;
          KK = NK + K;
          BIGA = A[KK];
          for (int J = K; J <= N; J++) //DO 20 J=K,N
          {
              IZ = N * (J - 1);
              for (int I = K; I <= N; I++) // DO 20 I=K,N
              {
                  IJ = IZ + I;
                  if ( fabs(BIGA) < fabs(A[IJ]) ) continue;
                  BIGA = A[IJ];
                  L[K] = I;
                  M[K] = J;
              }
          } //20 CONTINUE

//  INTERCHANGE ROWS

          J = L[K];
          if (J <= K) goto pos35;
          KI = K - N;
          for (int I = 1; I <= N; I++) //DO 30 I=1,N
          {
              KI = KI + N;
              HOLD = -A[KI];
              JI = KI - K + J;
              A[KI] = A[JI];
              A[JI] = HOLD;
          } // 30

//  INTERCHANGE COLUMNS

pos35:    I = M[K];
          if(I <= K) goto pos45; // GOTO 45
          JP = N * (I - 1);
          for (int J = 1; J <= N; J++) //DO 40 J=1,N
          {
              JK = NK + J;
              JI = JP + J;
              HOLD = -A[JK];
              A[JK] = A[JI];
              A[JI] = HOLD;
          } // 40

//  DIVIDE COLUMN BY MINUS PIVOT (VALUE OF PIVOT ELEMENT IS
//  CONTAINED IN BIGA)

pos45:
          if(fabs(BIGA) > 1.0E-20) goto pos48; //GOTO 48
          ShowMessage("ALSCAL FATAL ERROR:  INVERSE OF A SINGULAR MATRIX ATTEMPTED");
          exit(1);
//  900 PRINT 901
//  901 FORMAT(/' ALSCAL FATAL ERROR:  INVERSE OF A SINGULAR MATRIX ATTEMPT
//     *ED.')

//  CALL ERRTRA

//      STOP
pos48:
          for (int I = 1; I <= N; I++) //DO 55 I=1,N
          {
              if(I == K)continue; // GOTO 55
              IK = NK + I;
              A[IK] = A[IK] / (-BIGA);
          } // 55 CONTINUE

//  REDUCE MATRIX

          for (int I = 1; I <= N; I++) // DO 65 I=1,N
          {
              IK = NK + I;
              HOLD = A[IK];
              IJ = I - N;
              for (int J = 1; J <= N; J++) //DO 65 J=1,N
              {
                  IJ = IJ + N;
                  if(I == K) continue; // GOTO 65
                  if(J == K) continue; // GOTO 65
                  KJ = IJ - I + K;
                  A[IJ] = HOLD * A[KJ] + A[IJ];
              }
          } // 65 CONTINUE

//  DIVIDE ROW BY PIVOT

          KJ = K - N;
          for (int J = 1; J <= N; J++) // DO 75 J=1,N
          {
              KJ = KJ + N;
              if (J != K) A[KJ] = A[KJ] / BIGA;
          } //  75 CONTINUE

//  PRODUCT OF PIVOTS
//  REPLACE PIVOT BY RECIPROCAL

          A[KK] = 1.0 / BIGA;
      } // 80 CONTINUE

//  FINAL ROW AND COLUMN INTERCHANGE

      K = N;
pos100:
      K = (K - 1);
      if (K <= 0) goto pos150; //GOTO 150
      I = L[K]; // 105
      if (I <= K) goto pos120; // GOTO 120
      JQ = N * (K - 1); // 108
      JR = N * (I - 1);
      for (int J = 1; J <= N; J++) //DO 110 J=1,N
      {
          JK = JQ + J;
          HOLD = A[JK];
          JI = JR + J;
          A[JK] = -A[JI];
          A[JI] = HOLD;
      } // 110
pos120:
      J = M[K];
      if (J <= K) goto pos100; // GOTO 100
      KI = K - N; // 125
      for (int I = 1; I <= N; I++) // DO 130 I=1,N
      {
          KI = KI + N;
          HOLD = A[KI];
          JI = KI - K + J;
          A[KI] = -A[JI];
          A[JI] = HOLD;
      } // 120
      goto pos100; // GOTO 100

//  UNPACK THE MATRIX

pos150:
      I3 = N * (NA + 1) + 1;
      I4 = N * (N + 1) + 1;
      for (int J = 2; J <= N; J++) //DO 160 J=2,N
      {
          I3 = I3 - NA;
          I4 = I4 - N;
          for (int I = 1; I <= N; I++) // DO 160 I=1,N
          {
              A[I3 - I] = A[I4 - I];
          }
      } // 160
      delete[] M;
      delete[] L;
      delete[] A;
}
//***********************************************************************

void __fastcall TAlscaleForm::SHEL9(double *A, int *C, int NITEM)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/23/82

//     SUBROUTINE SHEL9   RICARDO DOBSON
//     A IS THE KEY VECTOR, C IS THE VECTOR TO SORT ON
//     NITEM IS THE NUMBER OF ITEMS IN THE TWO VECTORS
//     FIRST VECTOR ARGUMENT MUST BE REAL, SECOND VECTOR ARG
//     MUST BE INTEGER
//     SORT WILL BE IN ASCENDING ORDER

//-----------------------------------------------------------------------

//-----THE FOLLOWING STATEMENT CHANGED FROM INTEGER*2 7/23/82
//      INTEGER C(1),KK
//      REAL A(1)
//      CHARACTER*72,COPR
//      COMMON /CCOPR/COPR

      int KK, M, K, I, J, L;
      double B;

      M = NITEM;
pos20:
      M = M / 2;
//      IF (M) 30,40,30
      if (M == 0) goto pos40;
      K = NITEM - M; // 30
      J = 1;
pos41:
      I = J;
pos49:
      L = I + M;
//      IF(A(L)-A(I))50,60,60
      if ((A[L] - A[I]) >= 0.0) goto pos60;
      B = A[I]; // 50
      A[I] = A[L];
      A[L] = B;
      KK = C[I];
      C[I] = C[L];
      C[L] = KK;
      I = I - M;
//      IF (I-1)60,49,49
      if ((I-1) >= 0) goto pos49;
pos60:
      J = J + 1; // 60
//      IF(J-K)41,41,20
      if ((J - K) < 0) goto pos41;
      else goto pos20;
pos40:
//40    CONTINUE
}
//***********************************************************************

void __fastcall TAlscaleForm::LINT(double *DISP, double *DIST, int N, double *OBS)
{
// COPYRIGHT, 1977, FORREST W. YOUNG, YOSHIO TAKANE & ROSTYSLAW J LEWYCKYJ
// FINAL CHANGE 07/14/82

//     ROUTINE TO PERFORM CONSTRAINED LEAST SQUARES LINEAR REGRESSION.
//        IT FINDS THE BEST LINEAR TRANSFORMATION FOR QUANTITATIVE
//        (INTERVAL LEVEL) DATA UNDER THE CONSTRAINT THAT ALL
//        DISPARITIES (PREDICTIONS) BE NON-NEGATIVE.
//        THE NEWTON-RAPHSON METHOD IS USED.

//   ORIGINAL VERSION BY YOSHIO TAKANE AND FORREST YOUNG
//   REWRITTEN BY ROSTYSLAW LEWYCKYJ   MARCH 1977
//   MODIFIED ACCORDING TO SUGGESTIONS BY YOSHIO TAKANE JUNE 1977
//   REWRITTEN IN DOUBLE PRECISION BY YOSHIO TAKANE SEPTEMBER 1978
//   ERRORS CORRECTED BY YOSHIO TAKANE AND FORREST YOUNG, JANUARY 1981
//   ADAPTED FOR STAND ALONE VERSION OF ALSCAL, JULY 1982

//-----------------------------------------------------------------------

//      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
//      REAL DISP(1),DIST(1),OBS(1)
//      DOUBLE PRECISION PRTMSG
//      CHARACTER*72,COPR
//-----THE FOLLOWING STATEMENT IS REPLACED BY A DATA STATEMENT
//     COMMON /SLPMSG/ PRTMSG
//-----THE FOLLOWING STATEMENT WAS PUT IN TO TRY TO FIX UP A LINT PROBLEM
//-----   AND IS NOW TAKEN OUT BECAUSE THE FIX DID NOT WORK
//    +       /ITNUMR/ ITER
//-----THE FOLLOWING STATEMENT REPLACED BY THE NEXT 7/14/82
//    +       /IOUNIT/ LOUT
//      COMMON /CCOPR/COPR
//     +       /IONUMS/IN,NPLT,LOUT,NDP,NDQ,NDR,NDPP,INDATA
//-----THE FOLLOWING THREE STATEMENTS ADDED 7/14/82
//      double CUT,STMIN;
//      INTEGER DEBUG,ICNSTR,NOULB;
//      COMMON /PRMBLK/CUT,STMIN,DEBUG,ICNSTR,NOULB
//      DATA PRTMSG/0.0/
//      DATA BIG/9.0E20/
//---THE FOLLOWING STATEMENT IS SAS ONLY
//     IOPT19=IOPT(19)

      double PRTMSG = 0.0;
      BIG = 9.0E20;
      double FMIN = OBS[1];
      for (int K = 1; K <= N; K++) // DO 10 K=1,N
      {
          if(FMIN > OBS[K]) FMIN = OBS[K];
      } // 10
      double DH = 0.0;
      double ODH = 0.0;
      double O1 = 0.0;
      double O2 = 0.0;
      double O3 = 0.0;
      double O4 = 0.0;
      double DC = 0.0;
      double D0 = 0.0;
      double D1 = 0.0;
      double D2 = 0.0;
      double DI = 0.0;
      double OB1;
      double OB;
      double AO, BO, FO, G1, G2, H11, H22, H12, DET, P, S1, S2, STEP;
      double AN, BN, FN, GN, A, T1, T2, S;
      int LL, LLL;
      char outline[101];

// COMPUTE INITIAL ESTIMATES BY LINEAR REGRESSION

      for (int K = 1; K <= N; K++) //DO 22 K=1,N
      {
          if(OBS[K] == BIG) continue; // GOTO 22
          DI = sqrt(DIST[K]);
          DH = DH + DI;
          OB1 = OBS[K];
          ODH = ODH + OB1 * DI;
          DI = DIST[K];
          O1 = O1 + OB1;
          DC = DC + 1.0;
          D0 = D0 + DI;
          D1 = D1 + OB1 * DI;
          OB = OB1 * OB1;
          O2 = O2 + OB;
          D2 = D2 + OB * DI;
          OB = OB * OB1;
          O3 = O3 + OB;
          O4 = O4 + OB * OB1;
      } //   22 CONTINUE
      AO = (ODH * DC - DH * O1) / (O2 * DC - O1 * O1);
      BO = (DH - AO * O1) / DC;
      FO = AO * AO * AO * AO * O4 + 6.0 * AO * AO * BO * BO * O2 + DC *
           BO * BO * BO * BO - 2.0 * AO * AO * D2 - 4.0 * AO * BO * D1 -
           2.0 * BO * BO * D0 + 4.0 * AO * AO * AO * BO * O3 + 4.0 *
           AO * BO * BO * BO * O1;

// PERFORM UNCONSTRAINED NEWTON-RAPHSON ITERATIONS

pos4:
      LL = 0;
pos1:
      LL = LL + 1;
      if(LL > 50) goto pos2; // GOTO 2
      G1 = ((O4 * AO +3.0 * BO * O3) * AO + 3.0 * BO * BO * O2 - D2) *
            AO + BO * (BO * BO * O1 - D1);
      G2 = ((DC * BO + 3.0 * AO * O1) * BO + 3.0 * AO * AO * O2 - D0) *
            BO + AO * (AO * AO * O3 - D1);
      H11 = D2 - 3.0 * AO * AO * O4 - 6.0 * AO * BO * O3 - 3.0 * BO * BO * O2;
      H22 = D0 - 3.0 * AO * AO * O2 - 6.0 * AO * BO * O1 - 3.0 * BO * BO * DC;
      H12 = D1 - 3.0 * AO * AO * O3 - 6.0 * AO * BO * O2 - 3.0 * BO * BO * O1;
      DET = H11 * H22 - H12 * H12;
      DET = 1.0 / DET;
      H12 = -H12 * DET;
      P = H11;
      H11 = H22 * DET;
      H22 = P * DET;
      S1 = H11 * G1 + H12 * G2;
      S2 = H12 * G1 + H22 * G2;
      STEP = 1.0;
      LLL = 0;
pos3:
      LLL = LLL + 1;
      if (LLL > 20) goto pos2; // GOTO 2
      AN = AO + STEP * S1;
      BN = BO + STEP * S2;
      FN = AN * AN * AN * AN * O4 + 6.0 * AN * AN * BN * BN * O2 + DC * BN *
           BN * BN * BN - 2.0 * AN * AN * D2 - 4.0 * AN * BN * D1 - 2.0 * BN *
           BN * D0 + 4.0 * AN * AN * AN * BN * O3 + 4.0 * AN * BN * BN * BN * O1;
      if (FN < FO) goto pos40; // GOTO 40
      if (FN == FO) goto pos2; // GOTO 2
      STEP = STEP * 0.5;
      goto pos3; // GOTO 3
pos40:
      GN = H11 * G1 * G1 + 2.0 * H12 * G1 * G2 + H22 * G2 * G2;
      GN = sqrt(-GN);
      FO = FN;
      if(GN <= 0.0001) goto pos2; // GOTO 2
      AO = AN;
      BO = BN;
      goto pos1; // GOTO 1

// TEST FOR NEGATIVE SLOPE.

pos2:
      if(AN < 0.0) goto pos50; // GOTO 50

// TEST FOR NEGATIVE ESTIMATES

pos222:
      if ((AN * FMIN + BN) < 0.0) goto pos30; // GOTO 30

// COME HERE WHEN SLOPE AND ESTIMATES ARE POSITIVE

      for (int K = 1; K <= N; K++) // DO 12 K=1,N
      {
          if(OBS[K] == BIG) goto pos13; //GOTO 13
          DISP[K] = (AN * OBS[K] + BN) * (AN * OBS[K] + BN);
          continue; // GOTO 12
pos13:
          DISP[K] = BIG;
      } //  12 CONTINUE

//---THE FOLLOWING STATEMENT IS REPLACED BY THE NEXT
//     IF(IOPT19.EQ.1)WRITE(LOUT,4738)AN,BN

      if (DEBUG > 0)
      {
         sprintf(outline,"LINT: POSITIVE EST+++SLOPE=%15.5f, INTERCEPT = %15.5f",AN, BN);
         FrmOutPut->RichOutPut->Lines->Add(outline);
      }
      return;
//      IF(DEBUG.GT.0)WRITE(LOUT,4738)AN,BN
// 4738 FORMAT(' LINT: POSITIVE EST+++SLOPE=',E15.5,'INTERCEPT=',E15.5)
//      RETURN

// COME HERE WHEN THE SLOPE IS NEGATIVE.  SET THE INTERCEPT TO ZERO
// (RATIO LEVEL), PRINT WARNING, AND SOLVE FOR TRANSFORMATION.

pos50:
      FMIN = 0.0;
      if (PRTMSG == 1) goto pos30; //GOTO 30
      PRTMSG = 1;
      FrmOutPut->RichOutPut->Lines->Add("ALSCAL WARNING: A LINEAR TRANSFORMATION OF YOUR DATA HAS NEGATIVE SLOPE.");
//      WRITE(LOUT,9998)
      FrmOutPut->RichOutPut->Lines->Add("THE MEASUREMENT LEVEL HAS BEEN CHANGED TO RATIO ON");
      FrmOutPut->RichOutPut->Lines->Add("THIS ITERATION AND WILL BE CHANGED BACK TO INTERVAL ON");
      FrmOutPut->RichOutPut->Lines->Add("THE NEXT.  THIS MAY RESULT IN DIVERGENCE.  IF SO");
      FrmOutPut->RichOutPut->Lines->Add("REANALYZE YOUR DATA WITH A DIFFERENT MEASUREMENT LEVEL.");
      FrmOutPut->RichOutPut->Lines->Add("IN ALL CASES YOU SHOULD CHECK THE OPTIONS OF THE");
      FrmOutPut->RichOutPut->Lines->Add("ANALYSIS, PARTICULARLY THE SIMILAR OPTION.");
//      WRITE(LOUT,9995)

// COME HERE WHEN NEGATIVE ESTIMATES DO EXIST AND IMPOSE CONSTRAINT

pos30:
      T1 = 0.0;
      T2 = 0.0;
      for (int K = 1; K <= N; K++) // DO 36 K=1,N
      {
          if (OBS[K] == BIG) continue; // GOTO 36
          S = (OBS[K] - (FMIN * FMIN));
          T1 = T1 + S * DIST[K];
          T2 = T2 + (S * S);
      } //   36 CONTINUE
      A = T1 / T2;
      for (int K = 1; K <= N; K++) // DO 37 K=1,N
      {
          if(OBS[K] == BIG) goto pos38; // GOTO 38
          DISP[K] = A * pow((OBS[K] - FMIN),2);
          continue; // GOTO 37
pos38:
          DISP[K] = BIG;
      } //  37 CONTINUE

//---THE FOLLOWING STATEMENT REPLACED BY THE NEXT 7/14/82
//     IF(IOPT19.EQ.1)WRITE(LOUT,4748)A,FMIN

      if (DEBUG > 0) // WRITE(LOUT,4748)A,FMIN
      {
         sprintf(outline,"LINT: NEGATIVE EST---SLOPE = %15.5f INTERCEPT = %15.5f",A,FMIN);
         FrmOutPut->RichOutPut->Lines->Add(outline);
      }
// 4748 FORMAT(' LINT: NEGATIVE EST---SLOPE=',E15.5,'INTERCEPT=',E15.5)
//      RETURN
// 9995 FORMAT(T18,'THE MEASUREMENT LEVEL HAS BEEN CHANGED TO RATIO ON'/
//     *,T18,'THIS ITERATION AND WILL BE CHANGED BACK TO INTERVAL ON'/
//     *,T18,'THE NEXT.  THIS MAY RESULT IN DIVERGENCE.  IF SO,'/
//     *,T18,'REANALYZE YOUR DATA WITH A DIFFERENT MEASUREMENT LEVEL.'/
//     *,T18,'IN ALL CASES YOU SHOULD CHECK THE OPTIONS OF THE'/
//     *,T18,'ANALYSIS, PARTICULARLY THE SIMILAR OPTION.')
// 9998 FORMAT(/' ALSCAL WARNING: A LINEAR TRANSFORMATION OF YOUR DATA HAS
//     + NEGATIVE SLOPE.')
}
//*********************************************************************

void __fastcall TAlscaleForm::PDMAIN(double **X, double **O, int N, int R,
          int T, int ISUB, int ISYM, int IPLOT, int IOUT,double **D,
          double **UK, double **PIJP, double **XK, double *ROW)
{
//                             SUBROUTINES FOR
//                      PRINCIPAL  DIRECTIONS SCALING

//         PDSCAL82         EVOLVED FROM PDSCAL80          DEC 1981
//                                 14DEC81

//                           FINAL CHANGE 23MAY83

//               AN ALGORITHM TO FIND A SUBSPACE  OF A SPACE
//               SUCH THAT THE SQUARED DISTANCES BETWEEN THE
//               STIMULI IN THE SUBSPACE ARE A LEAST SQUARES
//               FIT TO A  MATRIX  OF  DISSIMILARITIES  DATA

//         COPYRIGHT 1980  BY FORREST W. YOUNG AND  CYNTHIA H. NULL

//         THE DETAILS OF THE ANALYSIS AND ALGORITHM  ARE GIVEN IN:
//         YOUNG, F.W. PRINCIPAL DIRECTIONS SCALING  (NOTES 1,2 AND
//         3) PSYCHOMETRIC LABORATORY, UNIVERSITY OF NORTH CAROLINA
//         1979 (XEROXED ROUGH DRAFTS). CHAPEL HILL, N.C. 27514 USA

//---------------------------------------------------------------------

// INPUT STRUCTURE
// ---------------

// X     =  COMMON STIMULUS SPACE (N BY R)
// O     =  DISPARITIES - SCALED DATA (N BY N) MUST BE SQUARE
// N     =  NUMBER OF STIMULI
// R     =  NUMBER OF DIMENSIONS
// T     =  NUMBER OF PRINCIPAL DIRECTIONS (T.LE.R)
// ISYM  <2 SYMMETRIC DISPARITIES
//       >1 ASYMMETRIC DISPARITIES
// IPLOT =0 FOR NO PLOTS
//       =1 TO PLOT THE SUBJECT SPACE
// IOUT  =  PRINTER LOGICAL UNIT NUMBER

//          THE REMAINING INPUT VARIABLES ARE ALL INTERNAL TO
//          THIS ROUTINE AND ARE IN THE SUBROUTINE STATEMENT
//          SO THAT SPACE CAN BE DYNAMICALLY ALLOCATED FOR THEM


// FIXED VALUES OF INTERNAL VARIABLES
// ----------------------------------

// ITMAX =50    MAXIMUM NUMBER OF ITERATIONS
// CRIT  =.001  UPPER LIMIT ON COEFFICIENT CHANGE TO END ITERATIONS
// IFULL =0     DO NOT PRINT DEBUGGING ITERATION HISTORY
//       =1     DO PRINT DEBUGGING ITERATION HISTORY

//      PARAMETER(ITMAX=50,CRIT=.0005)


//      REAL CK(6,6),A(6,6),XTX(6,6),XTXK(6,6),WK(6,6)
//      REAL O(N,N),D(N,N),PIJP(N,N)
//      REAL X(N,6),XK(N,6),UK(N,6),ROW(N)
//      EQUIVALENCE (A(1,1),CK(1,1))
//      LOGICAL*1 XCEED(6,6)
//      INTEGER R,T
//      LOGICAL IFL,ISIM
//-----THE FOLLOWING THREE STATEMENTS ADDED 8/12/82
//      DOUBLE PRECISION CUT,STMIN
//      INTEGER DEBUG,ICNSTR,NOULB
//      COMMON /PRMBLK/CUT,STMIN,DEBUG,ICNSTR,NOULB

      bool IFL;
      bool ISIM;
      bool IFULL;
      int ITMAX = 50;
      double CRIT = 0.001;

      IFL = false;
      if (ISYM > 1) IFL = true;
      ISIM = false;
      if ((ISYM == 1) || (ISYM == 3) || (ISYM == 5)) ISIM = true;
      IFULL = false;

// MASSAGE AND PRINT DISPARITIES

      PDDISP(O,N,ISIM,IFL,SUMSQ);

// COMPUTE INITIAL SUBSPACE COEFFICIENTS

      PDINWT(X,O,XK,A,D,N,R,T,ROW,XTX,XTXK,IFL);

// COMPUTE OPTIMAL SUBSPACE COEFFICIENTS

      PDSCAL(A,X,O,D,N,R,T,IFL,IOUT,ITMAX,CRIT,PIJP,SUMSQ, XCEED,IFULL);

// CALCULATE, AND PRINT YOUNG'S PRINCIPAL DIRECTIONS SOLUTION,
// INCLUDING THE WEIGHT MATRIX (WK),
// PRINCIPAL DIRECTION COEFFICIENTS (CK),
// AND THE NORMALIZED ORTHOGONAL PERSONAL SUBSPACE (XK).

      PDYUNG(CK,WK,XK,X,N,R,T,ROW);
      PDOUTY(CK,WK,XK,N,R,T,ISUB,IOUT);

// CALCULATE, AND PRINT TUCKER'S OBLIQUE AXES SOLUTION
// INCLUDING THE CORRELATIONS BETWEEN THE OBLIQUE AXES (WK),
// WEIGHTS APLIED TO EACH OBLIQUE AXIS (DIAG(WK)),
// AND THE PROJECTIONS ONTO THE OBLIQUE AXES (UK).

      PDTUCK(WK,X,UK,N,R);
      PDOUTT(WK,UK,N,R,ISUB,IOUT);

// PLOT YOUNG'S PRINCIPAL DIRECTIONS SPACE

//      if (IPLOT != 0) PDPLOT(XK,N,T,IOUT,N);
}
//**********************************************************************

void __fastcall TAlscaleForm::PDINWT(double **X, double **O, double **XK,
               double **A, double **B, int N, int R, int T, double *ROW,
               double **XTX, double **XTXK, bool IFL)
{
// ROUTINE TO OBTAIN AN INITIAL ESTIMATE OF
// THE PRINCIPAL DIRECTION WEIGHTS

//----------------------------------------------------------------------

//        INTEGER R,T
//	REAL A(6,6),XTX(6,6),XTXK(6,6)
//	REAL O(N,N),X(N,6),XK(N,6),ROW(N),B(N,N)
//        LOGICAL IFL

// COMPUTE SCALAR PRODUCTS FROM THIS SUBJECTS DISSIMILARITIES


        double GRAND = 0.0;
        for (int I = 1; I <= N; I++) //DO 20 I=1,N
        {
            ROW[I] = 0.0;
            for (int J = 1; J <= N; J++) // DO 10 J=1,N
                ROW[I] = ROW[I] + O[I][J]; // 10
            ROW[I] = ROW[I] / N;
            GRAND = GRAND + ROW[I];
        } // 20
        GRAND = GRAND / N;
        for (int I = 1; I <= N; I++) // DO 30 I=1,N
            for (int J = 1; J <= N; J++) // DO 30 J=1,N
                B[I][J] = -0.5 * (O[I][J] - ROW[I] - ROW[J] + GRAND); // 30

// SYMMETRIZE ASYMMETRIC SCALAR PRODUCTS

	   if(!IFL) goto pos39;
        for (int I = 2; I <= N; I++) //DO 35 I=2,N
        {
            IM1 = I - 1;
            for (int J = 1; J <= IM1; J++) // DO 35 J=1,IM1
            {
                B[I][J] = (B[I][J] + B[J][I]) * 0.5;
                B[J][I] = B[I][J];
            }
        } // 35

// COMPUTE UNCONSTRAINED PERSONAL SPACE COORDINATES
// BY THE CLASSICAL TORGERSON PROCEDURE

pos39:
        EIGK(B,ROW,N,N);
        for (int J = 1; J <= T; J++) //DO 40 J=1,T
        {
            ROW[J] = sqrt(ROW[J]);
            for (int I = 1; I <= N; I++) // DO 40 I=1,N
                XK[I][J] = B[I][J] * ROW[J];
        } // 40

// COMPUTE LINEAR LEAST SQUARES APPROXIMATION TO
// PRINCIPAL DIRECTION WEIGHTS BY REGRESSION

        for (int I = 1; I <= R; I++) // DO 50 I=1,R
        {
            for (int J = 1; J <= R; J++) //DO 50 J=1,R
            {
                XTX[I][J] = 0.0;
                for (int K = 1; K <= N; K++) // DO 50 K=1,N
                {
                    XTX[I][J] = XTX[I][J] + X[K][I] * X[K][J];
                }
            }
        } // 50
//        CALL MINV(XTX,R,6)
        for (int I = 1; I <= R; I++) //DO 60 I=1,R
        {
            for (int J = 1; J <= T; J++) //DO 60 J=1,T
            {
                XTXK[I][J] = 0.0;
                for (int K = 1; K <= N; K++) //DO 60 K=1,N
                    XTXK[I][J] = XTXK[I][J] + X[K][I] * XK[K][J];
            }
        } // 60
        for (int I = 1; I <= R; I++) // DO 70 I=1,R
        {
            for (int J = 1; J <= T; J++) //DO 70 J=1,T
            {
                A[I][J] = 0.0;
                for (int K = 1; K <= R; K++) //DO 70 K=1,R
                    A[I][J] = A[I][J] + XTX[I][K] * XTXK[K][J];
            }
        }
}
//**********************************************************************

void __fastcall TAlscaleForm::PDSCAL(double **A, double **X, double **O,
            double **D,int N, int R, int T, bool IFL, int IOUT, int ITMAX, double CRIT,
            double **PIJP, double SUMSQ, bool **XCEED, bool IFULL)
{

// SUBROUTINE TO COMPUTE PRINCIPAL DIRECTION WEIGHTS A GIVEN:
//         X:MULTIVARIATE DATA(COMMON SPACE)
//         O:DISSIMILARITY DATA(OR DISPARITIES)
//         D:SQUARED EUCLIDEAN DISTANCES IN THE PRINCIPAL
//           DIRECTIONS SPACE

//         N:NUMBER OF OBSERVATIONS (STIMULI)
//         R:NUMBER OF VARIABLES (ATTRIBUTES)
//         T:NUMBER OF PRINCIPAL DIRECTIONS
//         IFL:TRUE=ASYMMETRIC

// WRITTEN BY FORREST W. YOUNG AND CYNTHIA H. NULL, 11 DEC 79
// FINAL CHANGE 23MAY83 FWY

//----------------------------------------------------------------------

//	INTEGER R,T,Q,P
//	REAL O(N,N),D(N,N),X(N,6),PIJP(N,N),A(6,6)
//        LOGICAL IFL
//        LOGICAL*1 XCEED(6,6)

        char outline[101];
        char valstr[21];
        double FIT, OLDFIT, DIFF, STRESS, STRESK, BIG, FITB4, RSQ, DELTA;
        int KNT, KNTCAL;

        for (int I = 1; I <= N; I++) //DO 20 I=1,N
        {
            for (int J = 1; J <= N; J++) //DO 20 J=1,N
            {
                D[I][J] = 0.0;
            }
        } // 20
        for (int P = 1; P <= R; P++) //DO 22 P=1,R
            for (int Q = 1; Q <= T; Q++) //DO 22 Q=1,T
                XCEED[P][Q] = false; // 22
//        WRITE(IOUT,6)(Q,Q=1,T)
//6       FORMAT(1X,'DERIVATION OF THE GENERALIZED WEIGHT MATRIX.',
//     1  //' INITIAL DIRECTION COEFFICIENTS'/
//     1' DIMENSION        DIRECTION'/
//     23X,(7I10))
        FrmOutPut->RichOutPut->Lines->Add("DERIVATION OF THE GENERALIZED WEIGHT MATRIX");
        FrmOutPut->RichOutPut->Lines->Add("INITIAL DIRECTION COEFFICIENTS");
        FrmOutPut->RichOutPut->Lines->Add("DIMENSION        DIRECTION");

        for (int P = 1; P <= R; P++) // DO 10 P=1,R
        {
            for (int Q = 1; Q <= T; Q++)
            {
                sprintf(outline,"%6d       %10.4f",P,A[P][Q]);
            }
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }
//10      WRITE(IOUT,7)P,(A(P,Q),Q=1,T)
//7       FORMAT(I6,(7F10.4))
        KNT = 1;
	   if(IFULL != true) // THEN
        {
            FrmOutPut->RichOutPut->Lines->Add("HISTORY OF ITERATIONS");
            FrmOutPut->RichOutPut->Lines->Add("    ITER   CHANGE   SSTRESS   IMPROVE");
        }
        else
        {
            FrmOutPut->RichOutPut->Lines->Add("HISTORY OF ITERATIONS");
            sprintf(outline,"    ITER   CHANGE   SSTRESS   IMPROVE  DELTA  Q  P  KNT");
            FrmOutPut->RichOutPut->Lines->Add(outline);
        }

// CALCULATE INITIAL DISTANCES AND SSTRESS

        RSQ = 0.0;
        PDDIST(X,A,N,R,T,D);
        PDSTRS(O,D,N,IFL,OLDFIT,RSQ);
        FITB4 = OLDFIT;
        STRESS = sqrt(OLDFIT / SUMSQ);
        sprintf(outline,"     0   INITIAL %10.5f",STRESS);
        FrmOutPut->RichOutPut->Lines->Add(outline);
//        WRITE(IOUT,55)STRESS
//55      FORMAT(5X,'0',3X,'INITIAL',F10.5)

// PERFORM ALS ITERATIONS

        KNTCAL = 0;
        for (int ITER = 1; ITER <= ITMAX; ITER++) // DO 50 ITER=1,ITMAX
        {
            BIG = 0.0;
            for (int Q = 1; Q <= T; Q++) //DO 40 Q=1,T
            {
                for (int P = 1; P <= R; P++) // DO 30 P=1,R
                {
	               if(XCEED[P][Q]) continue; // GOTO 30
	               PDWGHT(A,X,D,O,N,R,PIJP,P,Q,IFL,DELTA);
                    BIG = (fabs(DELTA) > BIG) ? fabs(DELTA) : DELTA;
//                    BIG = AMAX1(fabs(DELTA),BIG);
                    if(fabs(DELTA) < CRIT) XCEED[P][Q] = true;
	               if(IFULL != true)continue; // GOTO 30
                    KNTCAL = KNTCAL + 1;
                    PDSTRS(O,D,N,IFL,FIT,RSQ);
                    STRESS = sqrt(FIT / SUMSQ);
                    DIFF = FITB4 - FIT;
                    FITB4 = FIT;
                    sprintf(outline,"%6d %10.5f %10.5f %10.5f %10.5f %3d %3d %3d",
                            ITER, BIG, STRESS, DIFF, DELTA, Q, P, KNTCAL);
                    FrmOutPut->RichOutPut->Lines->Add(outline);
                } // 30
            } // 40
            PDSTRS(O,D,N,IFL,FIT,RSQ);
            DIFF = OLDFIT - FIT;
            OLDFIT = FIT;
            STRESS = sqrt(FIT / SUMSQ);
            sprintf(outline,"%6d, %10.5f %10.5f %10.5f",ITER, BIG, STRESS, DIFF);
            FrmOutPut->RichOutPut->Lines->Add(outline);
//        WRITE(IOUT,4)ITER,BIG,STRESS,DIFF
//5       FORMAT(I6,(7F10.5))
//4       FORMAT(I6,3F10.5)
            if (BIG > CRIT) KNT = 0;
	       if (BIG > CRIT) continue; // GOTO 50
            KNT = KNT + 1;
	       if(KNT == 2) goto pos60; // GOTO 60
            for (int P = 1; P <= R; P++) //DO 122 P=1,R
                for (int Q = 1; Q <= T; Q++) // DO 122 Q=1,T
                    XCEED[P][Q] = false; // 122
        }  // 50      CONTINUE
pos60:  RSQ = -1.0;
        PDSTRS(O,D,N,IFL,STRESK,RSQ);
        FrmOutPut->RichOutPut->Lines->Add("FIT MEASURES (OF DISTANCES TO DISPARITIES");
        sprintf(outline,"KRUSKAL'S S STRESS (1) = %6.3f",STRESK);
        FrmOutPut->RichOutPut->Lines->Add(outline);
        sprintf(outline,"SQUARED CORRELATION = %6.3f",RSQ);
        FrmOutPut->RichOutPut->Lines->Add(outline);
//        WRITE(IOUT,11)STRESK,RSQ
//11      FORMAT(/' FIT MEASURES (OF DISTANCES TO DISPARITIES)'/
//     1' KRUSKAL''S STRESS (1) =',F6.3/
//     2' SQUARED CORRELATION  =',F6.3)
}
//**********************************************************************

void __fastcall TAlscaleForm::PDWGHT(double **A, double **X, double **D,
           double **O, int N, int R, double **PIJP, int P,int Q, bool IFL, double DELTA)
{
// SUBROUTINE TO CALCULATE A(P,Q) THE WEIGHT
// OF VARIABLE P ON PRINCIPAL DIRECTION Q.

// WRITTEN BY FORREST W. YOUNG AND CYNTHIA H. NULL, 10 DEC 79

//----------------------------------------------------------------------
// A: PRINCIPAL DIRECTION WEIGHTS
// X: MULTIVARIATE DATA (COMMON SPACE)
// D: DISTANCES IN THE PRINCIPAL DIRECTIONS SPACE
// O: SIMILARITY DATA

// N:NUMBER OF OBSERVATIONS(STIMULI)
// R:NUMBER OF VARIABLES(ATTRIBUTES)
// P:VARIABLE WHOSE WEIGHT IS BEING OBTAINEDED
// Q:PRINCIPAL DIRECTIONS WHOSE WEIGHT IS BEING OBTAINED
// IFL:TRUE=ASYMMETRIC
// DELTA:CHANGE IN VALUE OF A(P,Q) FROM ENTRY TO EXIT

//       LOGICAL IFL
//       INTEGER R,P,Q
//       REAL O(N,N),D(N,N),PIJP(N,N),X(N,6),A(6,6)

       double C0 = 0.0;
       double C1 = 0.0;
       double C2 = 0.0;
       double C3 = 0.0;
       double APQ, DPQK, RPQK;
       int IM1;

       for (int I = 2; I <= N; I++) //DO 20 I=2,N
       {
           IM1 = I - 1;
           for (int J = 1; J <= IM1; J++) //DO 20 J=1,IM1
           {
               PIJP[J][I] = 0.0;
               PIJP[I][J] = X[I][P] - X[J][P];

// COMPUTE SUM IN EQUATION 16 OF NOTE 1
// (UPPER TRIANGLE OF PIJP IS SUM)

               for (int IA = 1; IA <= R; IA++) //DO 10 IA=1,R
               {
                   if(IA == P) continue;
                   PIJP[J][I] = PIJP[J][I] + (X[I][IA] - X[J][IA]) * A[IA][Q];
               } //10     CONTINUE

// COMPUTE EQUATION 16 NOTE 1

               DPQK = 2.0 * PIJP[I][J] * A[P][Q] * PIJP[J][I] +
                      pow(PIJP[I][J],2) * pow(A[P][Q],2);

// COMPUTE EQUATION 18 OF NOTE 1 AS MODIFIED TO PERMIT
// ASYMMETRIC DATA (IFL=.TRUE) (FIXED MAR 1982)

               RPQK = O[I][J] - D[I][J] + DPQK;
               if(IFL) RPQK = (RPQK + O[J][I] - D[I][J] + DPQK) * 0.5;

// COMPUTE CUBIC EQUATION COEFICIENTS AS IN EQ.23 OF NOTE 1

               C0 = C0 + PIJP[I][J] * RPQK * PIJP[J][I];
               C1 = C1 + pow(PIJP[I][J],2) * (RPQK - 2.0 * pow(PIJP[J][I],2));
               C2 = C2 + pow(PIJP[I][J],3) * PIJP[J][I];
               C3 = C3 + pow(PIJP[I][J],4);
           }
       } // 20
       C0 = -C0 / C3;
       C1 = -C1 / C3;
       C2 = 3.0 * C2 / C3;

// SAVE OLD A(P,Q) IN APQ AND SOLVE FOR NEW VALUE

       APQ = A[P][Q];
       SCUBE(C2,C1,C0,A[P][Q]);
       DELTA = A[P][Q] - APQ;

// UPDATE DISTANCE USING CHANGE IN A(P,Q)
// SUBSTITUTED INTO EQUATION 16 OF NOTE 1.

       for (int I = 2; I <= N; I++) //DO 30 I=2,N
       {
           IM1 = I - 1;
           for (int J = 1; J <= IM1; J++) // DO 30 J=1,IM1
           {
               D[I][J] = D[I][J] + 2.0 * PIJP[I][J] * PIJP[J][I] * DELTA -
                         pow(PIJP[I][J],2) * (pow(APQ,2) - pow(A[P][Q],2));
           }
     }
}
//**********************************************************************

void __fastcall TAlscaleForm::PDDIST(double **X, double **A, int N, int R, int T, double **D)
{
// SUBROUTINE TO CALCULATE PRINCIPAL DIRECTION DISTANCES

// WRITTEN BY FORREST W. YOUNG AND CYNTHIA H. NULL, 10 DEC 79

//----------------------------------------------------------------------

// X:MULTIVARIATE DATA(COMMON SPACE)
// A:PRINCIPAL DIRECTION WEIGHTS
// N:NUMBER OF OBSERVATIONS(STIMULI)
// R:NUMBER OF VARIABLES(ATTRIBUTES)
// T:NUMBER OF PRINCIPAL DIRECTIONS
// D:DISTANCES IN THE PRINCIPAL DIRECTIONS SPACE

//       INTEGER R,T
//       REAL X(N,6),A(6,6),D(N,N)
       int IM1;
       double PIJA, PROD;

       for (int I = 2; I <= N; I++) // DO 20 I=2,N
       {
           IM1 = I - 1;
           for (int J = 1; J <= IM1; J++) //DO 20 J=1,IM1
           {
               D[I][J] = 0.0;
               for (int IA = 1; IA <= R; IA++) // DO 10 IA=1,R
               {
                   PIJA = X[I][IA] - X[J][IA];
                   for (int IB = 1; IB <= R; IB++) // DO 10 IB=1,R
                   {
                       PROD = (X[I][IB] - X[J][IB]) * PIJA;
                       for (int IC = 1; IC <= T; IC++) //DO 10 IC=1,T
                       {
                           D[I][J] = D[I][J] + PROD * A[IA][IC] * A[IB][IC];
                       }
                   }
               } // 10
           }  // next J
       } // 20
}
//**********************************************************************

void __fastcall TAlscaleForm::PDDISP(double **O, int N, bool ISIM, bool IFL, double SUMSQ)
{
//      ROUTINE TO PREPARE DISPARITIES FOR PDSCAL

//----------------------------------------------------------------------

//      O:    DISPARITIES (N BY N)
//      IFL:  TRUE=ASYMMETRIC
//      ISIM: TRUE=SIMILARITY
//      SUMSQ:SUMS OF SQUARES OF DISPARITIES AFTER NORMALIZATION

//       REAL O(N,N)
//       LOGICAL IFL,ISIM

       int NB = N;
       int NA = 1;
       int XNUM;
       double TOTAL, SQTOT, XMAX;
       if (!IFL) NA = 2;
pos19: if (!ISIM) goto pos29;

// IF SIMILARITY MAKE DISSIMILARITY

       XMAX = 0.0;
       for (int I = NA; I <= N; I++) // DO 25 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) // DO 25 J=1,NB
           {
               if(XMAX > O[I][J]) continue;
               XMAX = O[I][J];
           }
       } // 25

       for (int I = NA; I <= N; I++) // DO 26 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) // DO 26 J=1,NB
           {
               O[I][J] = XMAX - O[I][J] + 1;
           }
       }  //26     CONTINUE

// SQUARE ALL ENTRIES

pos29:
       for (int I = NA; I <= N; I++) // DO 30 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) //DO 30 J=1,NB
           {
               if (I == J) continue;
               O[I][J] = O[I][J] * O[I][J];
           }
       } // 30    CONTINUE
//       if(1 == 1) goto pos61; // this is really WEIRD!

//      NORMALIZE DISPARITIES SO THAT THE SUM OF
//      SQUARED DISPARITIES EQUALS NUMBER OF ELEMENTS

       TOTAL = 0.0;
       for (int I = NA; I <= N; I++) // DO 50 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) //DO 50 J=1,NB
           {
               if(I == J) continue;
               TOTAL = TOTAL + (O[I][J] * O[I][J]);
           }
       } // 50    CONTINUE
       if (IFL) XNUM = N * (N - 1);
       if (!IFL) XNUM = N * (N - 1) / 2;
       XNUM = sqrt(XNUM);
       SQTOT = sqrt(TOTAL);
       for (int I = NA; I <= N; I++) //DO 60 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) //DO 60 J=1,NB
           {
               if(I == J) continue;
               O[I][J] = O[I][J] * XNUM / SQTOT;
           }
       } // 60    CONTINUE

//       FILL IN UPPER HALF OF SYMMETRIC DATA
//       (ONLY NEEDED FOR INITIALIZATION ROUTINE)

pos61: if (IFL) goto pos80;
       for (int I = 1; I <= N; I++) //DO 70 I=1,N
       {
           O[I][I] = 0.0;
           for (int J = I; J <= N; J++) //DO 70 J=I,N
           {
               O[I][J] = O[J][I];
           }
       } // 70

//      CALCULATE S-STRESS DENOMINATOR

pos80: SUMSQ = 0.0;
       for (int I = NA; I <= N; I++) // DO 90 I=NA,N
       {
           if(!IFL) NB = I - 1;
           for (int J = 1; J <= NB; J++) //DO 90 J=1,NB
           {
               SUMSQ = SUMSQ + pow(O[I][J],2);
           }
       }
}
//**********************************************************************

void __fastcall TAlscaleForm::PDSTRS(double **O, double **D, int N,
                bool IFL, double STRESS, double RSQ)
{
// ROUTINE TO CALCULATE UNNORMALIZED STRESS
//        (FORMULA 1,NOTE 1)
// WRITTEN BY FORREST W. YOUNG, 11 DEC 79
// FINAL CHANGE 23MAY83 FWY

//----------------------------------------------------------------------

// O:DISSIMILARITY DATA(OR DISPARITIES)
// D:DISTANCES IN PRINCIPAL DIRECTION SPACE
// N:NUMBER OF OBSERVATIONS (STIMULI)
// IFL:.TRUE=ASYMMETRIC

//       REAL O(N,N),D(N,N)
//       LOGICAL IFL

// LOWER HALF MATRIX

       double DENOM, PRODOD, SUMO, SUMSQO, SUMD, SUMSQD;
       int NA, NB, NELE;

       STRESS = 0.0;
       NA = 2;
       if (IFL) NA = 1;
       if (RSQ != -1.0) goto pos20;
       for (int I = NA; I <= N; I++) //DO 10 I=NA,N
       {
           NB = I - 1;
           if (IFL) NB = N;
           for (int J = 1; J <= NB; J++) // DO 10 J=1,NB
           {
               if (I == J) continue; // GOTO 10
               if (O[I][J] > 0.0) O[I][J] = sqrt(O[I][J]);
               if (O[I][J] < 0.0) O[I][J] = -sqrt(-O[I][J]);
               if (D[I][J] > 0.0) D[I][J] = sqrt(D[I][J]);
               if (D[I][J] < 0.0) D[I][J] = -sqrt(-D[I][J]);
           }
       } //10     CONTINUE
pos20:
       for (int I = NA; I <= N; I++) // DO 30 I=NA,N
       {
           NB = I - 1;
           if (IFL) NB = N;
           for (int J = 1; J <= NB; J++) //DO 30 J=1,NB
           {
               if(I == J) continue;
               STRESS = STRESS + (O[I][J] - pow(D[I][J],2));
           }
       } // 30     CONTINUE
       if (RSQ != -1.0) return;
       DENOM = 0.0;
       for (int I = NA; I <= N; I++) // DO 35 I=NA,N
       {
           NB = I - 1;
           if (IFL) NB = N;
           for (int J = 1; J <= NB; J++) // DO 35 J=1,NB
           {
               if(I == J) continue;
               DENOM = DENOM + pow(O[I][J],2);
           }
       } //35     CONTINUE
       STRESS = sqrt(STRESS / DENOM);
       NELE = N * (N - 1) / 2;
       if (IFL) NELE = N * (N - 1);
       PRODOD = 0.0;
       SUMO = 0.0;
       SUMSQO = 0.0;
       SUMD = 0.0;
       SUMSQD = 0.0;
       for (int I = NA; I <= N; I++) // DO 40 I=NA,N
       {
           NB = I - 1;
           if (IFL) NB = N;
           for (int J = 1; J <= NB; J++) //DO 40 J=1,NB
           {
               if (I == J) continue;
               SUMD = SUMD + D[I][J];
               SUMO = SUMO + O[I][J];
               SUMSQO = SUMSQO + O[I][J] * O[I][J];
               SUMSQD = SUMSQD + D[I][J] * D[I][J];
               PRODOD = PRODOD + D[I][J] * O[I][J];
           }
       }  //40     CONTINUE
       RSQ = (PRODOD - SUMD * pow((SUMO / NELE),2)) /
                 ((SUMSQD - SUMD * SUMD / NELE) * (SUMSQO - SUMO * SUMO / NELE));
}

//**********************************************************************

void __fastcall TAlscaleForm::PDYUNG(double **CK, double **WK, double **XK,
                double **X, int N, int R, int T, double *ROOTS)
{

//       SUBROUTINE TO OBTAIN YOUNG'S PRINCIPAL DIRECTIONS SOLUTION

//----------------------------------------------------------------------
//       AT ENTRY
//           CK  IS THE (NONORTHOGONAL) OPTIMAL SUBSPACE COEFFICIENTS.
//           X   IS THE GROUP SPACE.
//           N   IS THE NUMBER OF STIMULI.
//           R   IS THE NUMBER OF GROUP SPACE DIMENSIONS.
//           T   IS THE NUMBER OF PRINCIPAL DIRECTIONS
//       AT RETURN
//           CK  IS THE ORTHOGONALIZED OPTIMAL SUBSPACE COEFFICIENTS

//           WK  IS THE SUBJECT'S WEIGHT MATRIX (THE TRANSFORMATION
//               APPLIED TO THE GROUP SPACE TO OBTAIN THE
//               PRINCIPAL DIRECTIONS PERSONAL SUBSPACE).


//        INTEGER R,T
//	REAL XK(N,6),X(N,6),CK(6,6),WK(6,6),ROOTS(6)

// COMPUTE WEIGHTS (TRANSFORMATION) ACCORDING TO EQUATION 4, NOTE 1.

        for (int I = 1; I <= R; I++) // DO 20 I=1,R
        {
            for (int J = I; J <= R; J++) // DO 20 J=I,R
            {
                WK[I][J] = 0.0;
                for (int K = 1; K <= T; K++) //DO 10 K=1,T
                {
                    WK[I][J] = WK[I][J] + CK[I][K] * CK[J][K];
                } // 10
                if (I != J) WK[J][I] = WK[I][J];
            }
        } // 20      CONTINUE

// FIND PRIN. DIR. COEFFICIENTS ACCORDING TO EQUATIONS 5 AND 6, NOTE 1.

        EIGK(WK,ROOTS,R,6);
        for (int I = 1; I <= R; I++) //DO 30 I=1,R
        {
            for (int J = 1; J <= T; J++) //DO 30 J=1,T
            {
                CK[I][J] = WK[I][J] * sqrt(ROOTS[J]);
            }
        } // 30

// RESTORE DESTROYED WEIGHTS

        for (int I = 1; I <= R; I++) //DO 50 I=1,R
        {
            for (int J = I; J <= R; J++) //DO 50 J=I,R
            {
                WK[I][J] = 0.0;
                for (int K = 1; K <= T; K++) //DO 40 K=1,T
                {
                    WK[I][J] = WK[I][J] + CK[I][K] * CK[J][K];
                } // 40
                if (I != J) WK[J][I] = WK[I][J];
            }
        } // 50      CONTINUE

// COMPUTE PRIN. DIR. SUBSPACE ACCORDING TO EQUATION 8, NOTE 1.

        for (int I = 1; I <= N; I++) //DO 60 I=1,N
        {
            for (int J = 1; J <= T; J++) //DO 60 J=1,T
            {
                XK[I][J] = 0.0;
                for (int K = 1; K <= R; K++) //DO 60 K=1,R
                    XK[I][J] = XK[I][J] + X[I][K] * CK[K][J];
            }
        } // 60
}
//**********************************************************************

void __fastcall TAlscaleForm::PDTUCK(double **WK, double **X, double **UK, int N,int R)
{
//     SUBROUTINE TO OBTAIN TUCKER'S OBLIQUE DECOMPOSITION OF WK.

//----------------------------------------------------------------------

//      INTEGER R
//      REAL UK(N,6),X(N,6),WK(6,6)
      int IM1;

      for (int I = 1; I <= R; I++) //DO 10 I=1,R
      {
          WK[I][I] = 1.0 / sqrt(WK[I][I]);
      } // 10

      for (int I = 2; I <= R; I++) //DO 20 I=2,R
      {
          IM1 = I - 1;
          for (int J = 1; J <= IM1; J++) // DO 20 J=1,IM1
          {
              WK[I][J] = WK[I][I] * WK[I][J] * WK[J][J];
              WK[J][I] = WK[I][J];
          }
      } // 20

      for (int J = 1; J <= R; J++) //DO 30 J=1,R
      {
          WK[J][J] = (1.0 / pow(WK[J][J],2));
          for (int I = 1; I <= N; I++) //DO 30 I=1,N
          {
              UK[I][J] = X[I][J] * WK[J][J];
          }
      }
}

//**********************************************************************

void __fastcall TAlscaleForm::PDPLOT(double **XK, int N, int T, int IOUT, int NMAX)
{
//-----FINAL CHANGE 23MAY83

//      PLOTS EACH PAIR OF DIRECTIONS OF XK

//----------------------------------------------------------------------

//      XK:PRINCIPAL DIRECTION SPACE
//      N:NUMBER OF STIMULI
//      T:NUMBER OF PRINCIPAL DIRECTIONS
//      NMAX:NUMBER NUMBER OF STIMULI ALLOWED
//      IOUT:OUT UNIT NUMBER

//      PLOT XK

//       INTEGER T
//       REAL XK(N,6)
//       CHARACTER*80,TITLE,FMT
//-----THE FOLLOWING LINE ADDED 8/13/82
//      COMMON /BLOCK3/TITLE,FMT
//     +       /PAGE/NLINES

      char outline[101];
      int JM1;

      if(T == 1) goto pos200; //GOTO 200
      for (int J = 2; J <= T; J++) //DO 110 J=2,T
      {
          JM1 = J - 1;
          for (int I = 1; I <= JM1; J++) // DO 110 I=1,JM1
          {
              FrmOutPut->RichOutPut->Lines->Add(""); //  CALL PAGE(IOUT)
              sprintf(outline,"PLOT OF PRINCIPAL DIRECTION %2d (HORIZONTAL) VS. %2d (VERTICAL).",I,J);
              FrmOutPut->RichOutPut->Lines->Add(outline);
//?              PLOTR(XK[1][I],XK[1][J],2.5,2.5,-2.5,-2.5,N,IOUT,2,NMAX);
          }
      } // 110
      return;
pos200:
      FrmOutPut->RichOutPut->Lines->Add("");
      FrmOutPut->RichOutPut->Lines->Add("PLOT OF FIRST PRINCIPAL DIRECTION");
//?      PLOTR(XK[1][1],XK[1][1],2.5,2.5,-2.5,-2.5,N,IOUT,2,NMAX);

//              WRITE(IOUT,798)TITLE,I,J
//798    FORMAT(A80//' PLOT OF PRINCIPAL DIRECTION',I2,
//     1' (HORIZONTAL) VS.',1I2,' (VERTICAL).')
//       CALL PLOTR(XK(1,I),XK(1,J),2.5,2.5,-2.5,-2.5,N,IOUT,2,NMAX)
//110    CONTINUE
//       RETURN
//200    CALL PAGE(IOUT)
//       WRITE(IOUT,799)TITLE
//799    FORMAT(A80//' PLOT OF FIRST PRINCIPAL DIRECTION')
//       CALL PLOTR(XK(1,1),XK(1,1),2.5,2.5,-2.5,-2.5,N,IOUT,2,NMAX)
}
//**********************************************************************

void __fastcall TAlscaleForm::PDOUTT(double **WK,double **UK, int N, int R,int ISUB, int IOUT)
{
//-----FINAL CHANGE 23MAY83

//     PRINT TUCKER'S OBLIQUE DECOMPOSITION OF A SUBJECT'S
//               MATRIX OF PRINCIPAL WEIGHTS.

//----------------------------------------------------------------------

//     WK   AXIS CORRELATIONS (OFF DIAGONAL) AND WEIGHTS (ON DIAGONAL)
//     UK   AXIS PROJECTIONS
//     N    STIMULI
//     R    VARIABLES/AXES
//     ISUB SUBJECT NUMBER
//     IOUT OUTPUT UNIT NUMBER

//      INTEGER R
//      REAL UK(N,6),WK(6,6)
//      CHARACTER*80,TITLE,FMT
//-----THE FOLLOWING STATEMENT ADDED 8/13/82
//      COMMON /BLOCK3/TITLE,FMT

      char outline[101];
      char strval[41];
      int I;
      double ONE;

      FrmOutPut->RichOutPut->Lines->Add("");
//      CALL PAGE(IOUT)
      sprintf(outline,"GENERAL EUCLIDEAN MODEL:  SUBJECT %4d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add("TUCKER''S OBLIQUE DECOMPOSITION OF THE GENERALIZED WEIGHT MATRIX.");
      FrmOutPut->RichOutPut->Lines->Add("CORRELATIONS BETWEEN OBLIQUE AXES");
      FrmOutPut->RichOutPut->Lines->Add("    AXIS              AXIS");
      strcpy(outline,"   ");
      for (int I = 1; I <= R; I++)
      {
          sprintf(strval,"%10d",I);
          strcat(outline,strval);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(IOUT,101)TITLE,ISUB,(I,I=1,R)
//101   FORMAT(A80//' GENERAL EUCLIDEAN MODEL:  SUBJECT',I4/
//     11X,'TUCKER''S OBLIQUE DECOMPOSITION OF THE',
//     2' GENERALIZED WEIGHT MATRIX.'/
//     2/' CORRELATIONS BETWEEN OBLIQUE AXES'/'   AXIS',14X,'AXIS'/
//     3 3X,(7I10))
      I = 1;
      ONE = 1.0;
      sprintf(outline,"%6d%10.4f",I,ONE);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      strcpy(outline,"");
      for (int I = 2; I <= R; I++)
      {
          IM1 = I - 1;
          sprintf(strval,"%6d",I);
          strcat(outline,strval);
          for (int J = 1; J <= IM1; J++)
          {
              sprintf(strval,"%10.4f",WK[I][J]);
              strcat(outline,strval);
          }
          sprintf(strval,"%10.4f",ONE);
          strcat(outline,strval);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          strcpy(outline,"");
      }
//      WRITE(IOUT,100)I,ONE
//100   FORMAT(I6,7F10.4)
//      DO 10 I=2,R
//      IM1=I-1
//10    WRITE(IOUT,100)I,(WK(I,J),J=1,IM1),ONE

      sprintf(outline,"WEIGHTS ON OBLIQUE AXES FOR SUBJECT %3d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("SUBJECT             AXIS");
      strcpy(outline,"   ");
      for (int I = 1; I <= R; I++)
      {
          sprintf(strval,"%10d",I);
          strcat(outline,strval);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);

//      WRITE(IOUT,102)ISUB,(I,I=1,R)
//102   FORMAT(/' WEIGHTS ON OBLIQUE AXES FOR SUBJECT',I3/
//     1' SUBJECT',13X,'AXIS'/3X,(7I10))

      sprintf(outline,"%6d",ISUB);
      for (int I = 1; I <= R; I++)
      {
          sprintf(strval,"%10.4f",WK[I][I]);
          strcat(outline,strval);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);

//      WRITE(IOUT,100)ISUB,(WK(I,I),I=1,R)

      sprintf(outline,"OBLIQUE SPACE FOR SUBJECT %3d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("STIMULUS            AXIS");
      strcpy(outline,"   ");
      for (int I = 1; I <= R; I++)
      {
          sprintf(strval,"%10d",I);
          strcat(outline,strval);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);

//      WRITE(IOUT,103)ISUB,(I,I=1,R)
//103   FORMAT(/' OBLIQUE SPACE FOR SUBJECT',I3/
//     1' STIMULUS',12X,'AXIS'/3X,(7I10))

      for (int I = 1; I <= N; I++)
      {
          sprintf(outline,"%6d",I);
          for (int J = 1; J <= R; J++)
          {
              sprintf(strval,"%10.4f",UK[I][J]);
              strcat(outline,strval);
          }
          FrmOutPut->RichOutPut->Lines->Add(outline);
      }
//      DO 20 I=1,N
//20    WRITE(IOUT,100)I,(UK(I,J),J=1,R)
}
//**********************************************************************

void __fastcall TAlscaleForm::PDOUTY(double **CK, double **WK, double **XK,
                                     int N, int R, int T, int ISUB, int IOUT)
{
//-----FINAL CHANGE 23MAY83

//     ROUTINE TO WRITE OUT  CK, WK, AND XK

//---------------------------------------------------------------------

//       CK      PRINCIPAL DIRECTION COEFFICIENTS
//       WK      PRINCIPAL DIRECTION WEIGHTS (TRANSFORMATION)
//       XK      PRINCIPAL DIRECTION SUBSPACE
//       N       NUMBER OF STIMULI
//       R       NUMBER OF PRINCIPAL DIRECTIONS
//       T       NUMBER OF VARIABLES
//       ISUB    SUBJECT NUMBER
//       IOUT    OUTPUT UNIT NUMBER

//      INTEGER R,T
//      REAL XK(N,6),CK(6,6),WK(6,6)
//      CHARACTER*80,TITLE,FMT
//-----FOLLOWING STATEMENT ADDED 8/13/82
//      COMMON /BLOCK3/TITLE,FMT
      char outline[101];
      char valstr[41];

      sprintf(outline,"GENERALIZED WEIGHT MATRIX FOR SUBJECT %3d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("DIMENSION        DIMENSION");
      sprintf(outline,"   ");
      for (int I = 1; I <= R; I++)
      {
          sprintf(valstr,"%10d",I);
          strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);
//      WRITE(IOUT,820)ISUB,(I,I=1,R)
//820   FORMAT(/' GENERALIZED WEIGHT MATRIX FOR SUBJECT',I3/
//     1' DIMENSION',8X,'DIMENSION'/3X,(7I10))

      for (int I = 1; I <= R; I++)
      {
          sprintf(outline,"%6d",I);
          for (int J = 1; J <= R; J++)
          {
              sprintf(valstr,"%10.4f",WK[I][J]);
              strcat(outline,valstr);
          }
          FrmOutPut->RichOutPut->Lines->Add(outline);
      }
//      DO 95 I=1,R
//95    WRITE(IOUT,823)I,(WK(I,J),J=1,R)
//      CALL PAGE(IOUT)
      FrmOutPut->ShowModal();
      FrmOutPut->RichOutPut->Clear();

      sprintf(outline," GENERAL EUCLIDEAN MODEL:  SUBJECT %4d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("YOUNG''S ORTHOGONAL PRINCIPAL DIRECTIONS DECOMPOSITION OF THE GENERALIZED WEIGHT MATRIX.");

//      WRITE(IOUT,8820)TITLE,ISUB
//8820  FORMAT(A80//' GENERAL EUCLIDEAN MODEL:  SUBJECT',I4/
//     11X,' YOUNG''S ORTHOGONAL PRINCIPAL DIRECTIONS',
//     1' DECOMPOSITION OF THE GENERALIZED WEIGHT MATRIX.')
      FrmOutPut->RichOutPut->Lines->Add("ORTHOGONAL PRINCIPAL DIRECTION COEFFICIENTS");
      sprintf(outline,"DIMENSION        DIRECTION ");
      for (int I = 1; I <= T; I++)
      {
          sprintf(valstr,"%10d",I);
          strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);

//100   WRITE(IOUT,822)(I,I=1,T)
//822   FORMAT(/' ORTHOGONAL PRINCIPAL DIRECTION COEFFICIENTS'/
//     1' DIMENSION        DIRECTION'/
//     23X,(7I10))

      for (int J = 1; J <= R; J++) //DO 96 J=1,R
      {
          sprintf(outline,"%6d",J);
          for (int I = 1; I <= T; I++)
          {
              sprintf(valstr,"%10.4f",CK[J][I]);
              strcat(outline,valstr);
          }
          FrmOutPut->RichOutPut->Lines->Add(outline);
      } // 96

//      WRITE(IOUT,823)J,(CK(J,I),I=1,T)
//823   FORMAT(I6,(7F10.4))
//96    CONTINUE

      sprintf(outline,"PERSONAL SUBSPACE FOR SUBJECT %3d",ISUB);
      FrmOutPut->RichOutPut->Lines->Add(outline);
      FrmOutPut->RichOutPut->Lines->Add("STIMULUS         DIRECTION");
      sprintf(outline,"                       ");
      for (int I = 1; I <= T; I++)
      {
          sprintf(valstr,"%10d",I);
          strcat(outline,valstr);
      }
      FrmOutPut->RichOutPut->Lines->Add(outline);

//      WRITE(IOUT,824)ISUB,(I,I=1,T)
//824   FORMAT(/' PERSONAL SUBSPACE FOR SUBJECT',I3/
//     1' STIMULUS         DIRECTION'/
//     23X,(7I10))

      for (int I = 1; I <= N; I++)
      {
          sprintf(outline,"%6d",I);
          for (int J = 1; J <= T; J++)
          {
              sprintf(valstr,"%10.4f",XK[I][J]);
              strcat(outline,valstr);
          }
          FrmOutPut->RichOutPut->Lines->Add(outline);
      }
//      DO 98 I=1,N
//      WRITE(IOUT,823)I,(XK(I,J),J=1,T)
//98    CONTINUE
}
//---------------------------------------------------------------------

double TAlscaleForm::F(double X, double P, double Q, double R)
{
    double F1;
    double R3 = 0.33333333;

    F1 = (((X * 0.25 + P * R3) * X + Q * 0.5) * X + R) * X;
    return F1;
}
//---------------------------------------------------------------------

double TAlscaleForm::SIGN(double A, double B)
{
    double Answer;

    if (A < B) Answer = -1.0;
    if (A > B) Answer = 1.0;
    if (A == B) Answer = 0.0;
    return Answer;
}
//---------------------------------------------------------------------

double TAlscaleForm::AMIN1(double A, double B, double C)
{
    double D;
    if (A < B) D = A;
    else D = B;
    if (D < C) D = C;
    return D;
}
//---------------------------------------------------------------------

double TAlscaleForm::AMAX1(double A, double B, double C)
{
    double D;
    if (A > B) D = A;
    else D = B;
    if (C > D) D = C;
    return D;
}
//---------------------------------------------------------------------








