//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainUnit.h"
#include "functions.h"
#include "DataFuncs.h"
#include "OutPut.h"
#include "stdio.h"
#include "CoxRegUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCoxRegForm *CoxRegForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TCoxRegForm::TCoxRegForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::ResetBtnClick(TObject *Sender)
{
     int i;

     BlockList->Clear();
     VarList->Clear();
     for (i = 1; i <= NoVariables; i++)
     {
          VarList->Items->Add(MainForm->Grid->Cells[i][0]);
     }
     InBtn->Visible = true;
     OutBtn->Visible = false;
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
     ProbsChk->Checked = true;
     DescChk->Checked = true;
     DepVar->Text = "";
     StatusEdit->Text = "";
     StatusInBtn->Visible = true;
     StatusOutBtn->Visible = false;
     MaxItsEdit->Text = "20";
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::InBtnClick(TObject *Sender)
{
     if (VarList->Items->Count < 1) return;
//     int index = VarList->SelCount;
     int i = 0;
     while (i < VarList->Items->Count)
     {
         if (VarList->Selected[i])
         {
              BlockList->Items->Add(VarList->Items->Strings[i]);
              VarList->Items->Delete(i);
//              index--;
              i = 0;
         }
         else i++;
     }
     OutBtn->Visible = true;
     if (VarList->Items->Count < 1) InBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::OutBtnClick(TObject *Sender)
{
     int index = BlockList->ItemIndex;
     VarList->Items->Add(BlockList->Items->Strings[index]);
     BlockList->Items->Delete(index);
     InBtn->Visible = true;
     if (BlockList->Items->Count < 1) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::DepInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     DepVar->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     DepOutBtn->Visible = true;
     DepInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::DepOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(DepVar->Text);
     DepVar->Text = "";
     DepInBtn->Visible = true;
     DepOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::StatusInBtnClick(TObject *Sender)
{
     int index;

     index = VarList->ItemIndex;
     StatusEdit->Text = VarList->Items->Strings[index];
     VarList->Items->Delete(index);
     StatusOutBtn->Visible = true;
     StatusInBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::StatusOutBtnClick(TObject *Sender)
{
     VarList->Items->Add(StatusEdit->Text);
     StatusEdit->Text = "";
     StatusInBtn->Visible = true;
     StatusOutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TCoxRegForm::OKBtnClick(TObject *Sender)
{
     int i, j, k, l, indx, iBig;
     AnsiString title, cellstring;
     char outline[121];
     int nR; // no. independent variables
     int *ColNoSelected;
     int nC; // no. cases
     int nP; // survival time variable
     int nS; // survival status variable
     double zX, v, Eps, LLn, LLp, LL, s0, StatI, Sf, Lo95, Hi95, d;
     AnsiString *RowLabels, *ColLabels;
     double CSq; // chi square statistic
     double prob; // probability of chi square
     double *SurvT, *Stat, *Dupl, *Alpha, *a, *b, *s1, *s2, *s, *Av, *SD, *SE, *x;
     int iters;
     int result, intvalue;
     double dblvalue;
     AnsiString strvalue;

     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("Cox Proportional Hazards Survival Regression Adapted from John C. Pezzullo");
     FrmOutPut->RichOutPut->Lines->Add("Java program at http://members.aol.com/johnp71/prophaz.html");

     // get independent item columns
     nR = BlockList->Items->Count;
     nC = NoCases;

     ColNoSelected = new int[nR + 2];
     RowLabels = new AnsiString[nR + 2];
     ColLabels = new AnsiString[nR + 2];
     if (nR < 1)
     {
          ShowMessage("ERROR! No independent variables selected.");
          goto Cleanup;
     }

     for (i = 1; i <= nR; i++)
     {
         cellstring = BlockList->Items->Strings[i-1];
         for (j = 1; j <= NoVariables; j++)
         {
              if (cellstring == MainForm->Grid->Cells[j][0])
              {
                  ColNoSelected[i-1] = j;
                  RowLabels[i-1] = cellstring;
                  ColLabels[i-1] = cellstring;
              }
         }
     }
/*
     // check for valid variable type
     for (i = 0; i < nR; i++)
     {
        result = VarTypeChk(ColNoSelected[i],0);
        if (result == 1)
        {
                delete[] ColLabels;
                delete[] RowLabels;
                delete[] ColNoSelected;
                return;
        }
     }
*/
     // get survival time variable column and survival status var. column
     if (DepVar->Text == "")
     {
         ShowMessage("Error! No Survival time variable selected.");
         goto Cleanup;
     }
     if (StatusEdit->Text == "")
     {
          ShowMessage("Error! No Survival Status variable selected.");
          goto Cleanup;
     }
     nP = nR + 1;
     nS = nP + 1;
     for (j = 1; j <= NoVariables; j++)
     {
         if (DepVar->Text == MainForm->Grid->Cells[j][0])
         {
             ColNoSelected[nP-1] = j;
             RowLabels[nP-1] = MainForm->Grid->Cells[j][0];
             ColLabels[nP-1] = RowLabels[nP-1];
         }
         if (StatusEdit->Text == MainForm->Grid->Cells[j][0])
         {
              ColNoSelected[nS-1] = j;
              RowLabels[nS-1] = MainForm->Grid->Cells[j][0];
              ColLabels[nS-1] = RowLabels[nS-1];
         }
     }

     SurvT = new double[nC + 1];
     Stat = new double[nC + 1];
     Dupl = new double[nC + 1];
     Alpha = new double[nC + 1];
     x = new double[(nC + 1) * (nR + 1)];
     b = new double[nC + 1];
     a = new double[(nR + 1) * (nR + 1)];
     s1 = new double[nR + 1];
     s2 = new double[(nR + 1) * (nR + 1)];
     s = new double[nR + 1];
     Av = new double[nR + 1];
     SD = new double[nR + 1];
     SE = new double[nR + 1];

     for (i = 0; i < nR+1; i++)
     {
         Av[i] = 0.0;
         SD[i] = 0.0;
         SE[i] = 0.0;
     }

     // get data
     for (i = 0; i < nC; i++)
     {
          if (!ValidRecord(i+1,ColNoSelected,nR)) continue;
          indx = ix(i,0,nR+1);
          x[indx] = 1;
          for (j = 0; j < nR; j++)
          {
               indx = ColNoSelected[j];
               zX = StrToFloat(Trim(MainForm->Grid->Cells[indx][i+1]));
               //result = GetValue(i+1,indx,intvalue,dblvalue,strvalue);
               //if (result == 1) zX = 0.0;
               //else zX = dblvalue;
               indx = ix(i,j,nR);
               x[indx] = zX;
               Av[j] = Av[j] + zX;
               SD[j] = SD[j] + (zX * zX);
          }
          // get survival time
          indx = ColNoSelected[nP-1];
          zX = StrToFloat(Trim(MainForm->Grid->Cells[indx][i+1]));
          //result = GetValue(i+1,indx,intvalue,dblvalue,strvalue);
          //if (result == 1) zX = 0.0;
          //else zX = dblvalue;
          SurvT[i] = zX;
          // get survival status
          indx = ColNoSelected[nS-1];
          zX = StrToFloat(Trim(MainForm->Grid->Cells[indx][i+1]));
          //result = GetValue(i+1,indx,intvalue,dblvalue,strvalue);
          //if (result == 1) zX = 0.0;
          //else zX = dblvalue;
          Stat[i] = zX;
     } // next case i

     // print descriptive statistics
     FrmOutPut->RichOutPut->Lines->Add("");
     if (DescChk->Checked)
     {
          FrmOutPut->RichOutPut->Lines->Add("Descriptive Statistics");
          FrmOutPut->RichOutPut->Lines->Add("Variable  Label            Average     Std.Dev.");
     }
     for (j = 0; j < nR; j++)
     {
          Av[j] = Av[j] / (double)nC;
          SD[j] = SD[j] / (double)nC;
          SD[j] = sqrt( fabs(SD[j] - Av[j] * Av[j]));
          if (DescChk->Checked)
          {
               sprintf(outline,"   %3d %15s %10.4f %10.4f",j+1,RowLabels[j],Av[j],SD[j]);
               FrmOutPut->RichOutPut->Lines->Add(outline);
          }
     }
     FrmOutPut->RichOutPut->Lines->Add("");

     d = 0.0;
     Eps = 1.0 / 1024.0;
     for (i = 0; i < nC-1; i++)
     {
          iBig = i;
          for (j = i+1; j < nC; j++)
          {
               if ((SurvT[j] - Eps * Stat[j]) > (SurvT[iBig]-Eps * Stat[iBig]))
                    iBig = j;
          }
          if (iBig != i)
          {
               v = SurvT[i];
               SurvT[i] = SurvT[iBig];
               SurvT[iBig] = v;
               v = Stat[i];
               Stat[i] = Stat[iBig];
               Stat[iBig] = v;
               for (j = 0; j < nR; j++)
               {
                    v = x[ix(i,j,nR)];
                    x[ix(i,j,nR)] = x[ix(iBig,j,nR)];
                    x[ix(iBig,j,nR)] = v;
               }
          }
     }

     if (Stat[0] > 0)  Stat[0] = Stat[0] + 2;
     for (i = 1; i < nC; i++)
     {
          if ((Stat[i] > 0) && ((Stat[i-1] == 0) || (SurvT[i-1] != SurvT[i])))
               Stat[i] = Stat[i] + 2;
     }
     if (Stat[nC-1] > 0)  Stat[nC-1] = Stat[nC-1] + 4;
     for (i = nC-2; i >= 0; i--)
     {
          if ((Stat[i] > 0) && ((Stat[i+1] == 0) || (SurvT[i+1] != SurvT[i])))
               Stat[i] = Stat[i] + 4;
     }
     for (i = 0; i < nC; i++)
     {
          for (j = 0; j < nR; j++)
          {
               x[ix(i,j,nR)] = (x[ix(i,j,nR)] - Av[j]) / SD[j];
          }
     }
     if (ItersChk->Checked)  FrmOutPut->RichOutPut->Lines->Add("Iteration History...");
     for (j = 0; j < nR; j++) b[j] = 0;
     LLp = 2.0e30;
     LL = 1.0e30;

     // start iterations
     iters = 0;
     while (fabs(LLp-LL) > 0.0001)
     {
          iters = iters + 1;
          if (iters > StrToInt(MaxItsEdit->Text))  break;
          LLp = LL;
          LL = 0.0;
          s0 = 0.0;
          for (j = 0; j < nR; j++)
          {
               s1[j] = 0.0;
               a[ix(j,nR,nR+1)] = 0.0;
               for (k = 0; k < nR; k++)
               {
                    s2[ix(j,k,nR)] = 0.0;
                    a[ix(j,k,nR+1)] = 0.0;
               }
          }
          for (i = 0; i < nC; i++)
          {
               Alpha[i] = 1.0;
               v = 0.0;
               for (j = 0; j < nR; j++) v = v + b[j] * x[ix(i,j,nR)];
               v = exp(v);
               s0 = s0 + v;
               for (j = 0; j < nR; j++)
               {
                    s1[j] = s1[j] + x[ix(i,j,nR)] * v;
                    for (k = 0; k < nR; k++)
                        s2[ix(j,k,nR)] = s2[ix(j,k,nR)] + x[ix(i,j,nR)] * x[ix(i,k,nR)] * v;
               }
               StatI = Stat[i];
               if ((StatI == 2) || (StatI == 3) || (StatI == 6) || (StatI == 7))
               {
                    d = 0.0;
                    for (j = 0; j < nR; j++) s[j] = 0.0;
               }
               if ((StatI == 1) || (StatI == 3) || (StatI == 5) || (StatI == 7))
               {
                    d = d + 1;
                    for (j = 0; j < nR; j++) s[j] = s[j] + x[ix(i,j,nR)];
               }
               if ((StatI == 4) || (StatI == 5) || (StatI == 6) || (StatI == 7))
               {
                    for (j = 0; j < nR; j++)
                    {
                         LL = LL + s[j] * b[j];
                         a[ix(j,nR,nR+1)] = a[ix(j,nR,nR+1)] + s[j] - d * s1[j] / s0;
                         for (k = 0; k < nR; k++)
                         {
                              a[ix(j,k,nR+1)] = a[ix(j,k,nR+1)] + d * (s2[ix(j,k,nR)] / s0 -
                                   s1[j] * s1[k] / (s0 * s0));
                         }
                    }
                    LL = LL - d * log(s0);
                    if (d == 1)  Alpha[i] = pow((1.0 - v / s0),(1.0 / v));
                    else Alpha[i] = exp(-d / s0);
               }
          }
          LL = -2.0 * LL;
          sprintf(outline,"-2 Log Likelihood = %10.4f",LL);
          if (iters == 1)
          {
               LLn = LL;
               if (ItersChk->Checked) strcat(outline," (Null Model)");
          }
          if (ItersChk->Checked) FrmOutPut->RichOutPut->Lines->Add(outline);
          for (i = 0; i < nR; i++)
          {
               v = a[ix(i,i,nR+1)];
               a[ix(i,i,nR+1)] = 1.0;
               for (k = 0; k <= nR; k++) a[ix(i,k,nR+1)] = a[ix(i,k,nR+1)] / v;
               for (j = 0; j < nR; j++)
               {
                    if (i != j)
                    {
                         v = a[ix(j,i,nR+1)];
                         a[ix(j,i,nR+1)] = 0.0;
                         for (k = 0; k <= nR; k++)
                             a[ix(j,k,nR+1)] = a[ix(j,k,nR+1)] - v * a[ix(i,k,nR+1)];
                    }
               }
          }
          for (j = 0; j < nR; j++) b[j] = b[j] + a[ix(j,nR,nR+1)];
     }

     FrmOutPut->RichOutPut->Lines->Add("Converged");
     CSq = LLn - LL;
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Overall Model Fit...");
     if (CSq > 0.0)  prob = ChiSq(CSq,nR);
     else prob = 1.0;
     sprintf(outline,"Chi Square = %8.4f with d.f. %d and probability = %8.4f",CSq,nR,prob);
     FrmOutPut->RichOutPut->Lines->Add(outline);
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Coefficients, Std Errs, Signif, and Confidence Intervals");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Var             Coeff.    StdErr       p      Lo95%    Hi95%");
     for (j = 0; j < nR; j++)
     {
          b[j] = b[j] / SD[j];
          SE[j] = sqrt(a[ix(j,j,nR+1)]) / SD[j];
          prob = Norm(fabs(b[j] / SE[j]));
          Lo95 = b[j] - 1.96 * SE[j];
          Hi95 = b[j] + 1.96 * SE[j];
          sprintf(outline,"%10s %10.4f %10.4f %8.4f %8.4f %8.4f",
                     RowLabels[j].c_str(),b[j],SE[j],prob,Lo95,Hi95);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Risk Ratios and Confidence Intervals");
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("Variable      Risk Ratio   Lo95%     Hi95%");
     for (j = 0; j < nR; j++)
     {
          sprintf(outline,"%10s %10.4f %10.4f %10.4f",
            RowLabels[j].c_str(),exp(b[j]),exp(b[j]-1.96*SE[j]),exp(b[j]+1.96*SE[j]));
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     if (ProbsChk->Checked)
        FrmOutPut->RichOutPut->Lines->Add("Baseline Survivor Function (at predictor means)...");
     Sf = 1.0;
     for (i = nC-1; i >= 0; i--)
     {
          Sf = Sf * Alpha[i];
          if (Alpha[i] < 1.0)
          {
               if (ProbsChk->Checked)
               {
                    sprintf(outline,"%10.4f %10.4f",SurvT[i],Sf);
                    FrmOutPut->RichOutPut->Lines->Add(outline);
               }
          }
     }
     FrmOutPut->ShowModal();

Cleanup:
     delete[] SurvT;
     delete[] Stat;
     delete[] Dupl;
     delete[] Alpha;
     delete[] x;
     delete[] b;
     delete[] a;
     delete[] s1;
     delete[] s2;
     delete[] s;
     delete[] Av;
     delete[] SD;
     delete[] SE;
     delete[] RowLabels;
     delete[] ColLabels;
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------

double __fastcall TCoxRegForm::ChiSq(double x, int n)
{
     // returns the probability of a chi-square statistic with n deg. freem
     double p, t, a;
     int k;

     p = exp(-0.5 * x);
     if (n % 2 == 1)  p = p * sqrt(2 * x / M_PI);
     k = n;
     while (k >= 2)
     {
          p = p * x / k;
          k = k - 2;
     }
     t = p;
     a = n;
     while (t > 0.000001 * p)
     {
          a = a + 2;
          t = t * x / a;
          p = p + t;
     }
     return(1.0 - p);
}
//-------------------------------------------------------------------

double __fastcall TCoxRegForm::Norm(double z)
{
     // returns the chi-square probability of the squared z score
     return(ChiSq(z * z, 1));
}
//-------------------------------------------------------------------

int __fastcall TCoxRegForm::ix(int j, int k, int nCols)
{
     // returns an integer for the subscript
     return(j * nCols + k);
}
//-------------------------------------------------------------------

