//---------------------------------------------------------------------------

#ifndef ThreePFuncsH
#define ThreePFuncsH
//---------------------------------------------------------------------------
#endif


#include "MainUnit.h";
#include <vcl.h>
#include "OutPut.h"
#include <stdio.h>

    double probt(double theta, double a, double b, double c);
    double lik(int ItemCol, double *th, double a, double b, double c, int nobs);
    void calib_theta(double &seeth, double &th, int ii, double *a, double *b,
                     double *c, int subject, int &nvalid, int *ItemCols);
    void Calib_a(double &seea, int ItemCol, double *th, double &a, double &b, double &c, int N);
    void Calib_b(double &seeb, int ItemCol, double *th, double &a, double &b, double &c, int N);
    void Calib_c(double &seec, int ItemCol, double *th, double &a, double &b, double &c, int N);
    void calib_abc(double &seea, double &seeb, double &seec, int ItemCol, double *th,
               double &a, double &b, double &c, int N);
    double mse(int ItemCol, double *th, double a, double b, double c, int N, int &nobs);
    void plotxy(double *Ypoints, double *Xpoints, double Xmax, double Xmin,
                double Ymax, double Ymin, int N, char *Title);
    void ItemFit(double *Parma, double *Parmb,double *Parmc, double *TotScrs,
              double *Theta, int NoItems, int NoCases);
