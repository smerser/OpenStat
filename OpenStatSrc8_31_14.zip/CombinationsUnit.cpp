//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "NonPar.h"
#include "MainUnit.h"
#include "stdio.h"
#include "CombinationsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCombinationsForm *CombinationsForm;
//---------------------------------------------------------------------------
__fastcall TCombinationsForm::TCombinationsForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TCombinationsForm::ResetBtnClick(TObject *Sender)
{
        XEdit->Clear();
        NEdit->Clear();
        CombosEdit->Clear();        
}
//---------------------------------------------------------------------------
void __fastcall TCombinationsForm::ComputeBtnClick(TObject *Sender)
{
        double CombosX, X, N;

        X = StrToFloat(XEdit->Text);
        N = StrToFloat(NEdit->Text);
        CombosX = combos(X,N);
        CombosEdit->Text = FloatToStr(CombosX);
}
//---------------------------------------------------------------------------
void __fastcall TCombinationsForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
