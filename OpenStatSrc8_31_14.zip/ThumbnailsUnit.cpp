//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "PicViewMain.h"
#include "Clipbrd.hpp"
#include "ThumbnailsUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TThumbnailsForm *ThumbnailsForm;
//---------------------------------------------------------------------------
__fastcall TThumbnailsForm::TThumbnailsForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TThumbnailsForm::FormShow(TObject *Sender)
{
     NoAvailable = PicViewForm->FileListBox1->Items->Count;
     CurrentStart = 0;
     if (NoAvailable < 28) CurrentEnd = NoAvailable - 1;
     else CurrentEnd = 27;
     FillPics(this);
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::FillPics(TObject *Sender)
{
     picno = 0;
     int endit = CurrentEnd - CurrentStart;
     for (int i = 1; i <= endit+1; i++)
     {
         filename = PicViewForm->FileListBox1->Items->Strings[i + CurrentStart-1];
         extension = ExtractFileExt(filename);
         if ( (extension == ".jpg") || (extension == ".bmp")
              || (extension == ".JPG") || (extension == ".BMP")
              || (extension == ".wmf") || (extension == ".WMF")
              || (extension == ".ico") || (extension == ".ICO")
              || (extension == ".jpeg") || (extension == ".JPGEG") )
              goodfile = true;
         else
         {
             goodfile = false;
             CurrentEnd--;
         }
         if (goodfile)
         {
            switch (i)
            {
                   case 1:
                   {
                        Image1->Stretch = true;
                        Image1->AutoSize = false;
                        Image1->Picture->LoadFromFile(filename);
                        Label1->Caption = filename;
                   }
                   break;
                   case 2:
                   {
                        Image2->Stretch = true;
                        Image2->AutoSize = false;
                        Image2->Picture->LoadFromFile(filename);
                        Label2->Caption = filename;
                   }
                   break;
                   case 3:
                   {
                        Image3->Stretch = true;
                        Image3->AutoSize = false;
                        Image3->Picture->LoadFromFile(filename);
                        Label3->Caption = filename;
                   }
                   break;
                   case 4:
                   {
                        Image4->Stretch = true;
                        Image4->AutoSize = false;
                        Image4->Picture->LoadFromFile(filename);
                        Label4->Caption = filename;
                   }
                   break;
                   case 5:
                   {
                        Image5->Stretch = true;
                        Image5->AutoSize = false;
                        Image5->Picture->LoadFromFile(filename);
                        Label5->Caption = filename;
                   }
                   break;
                   case 6:
                   {
                        Image6->Stretch = true;
                        Image6->AutoSize = false;
                        Image6->Picture->LoadFromFile(filename);
                        Label6->Caption = filename;
                   }
                   break;
                   case 7:
                   {
                        Image7->Stretch = true;
                        Image7->AutoSize = false;
                        Image7->Picture->LoadFromFile(filename);
                        Label7->Caption = filename;
                   }
                   break;
                   case 8:
                   {
                        Image8->Stretch = true;
                        Image8->AutoSize = false;
                        Image8->Picture->LoadFromFile(filename);
                        Label8->Caption = filename;
                   }
                   break;
                   case 9:
                   {
                        Image9->Stretch = true;
                        Image9->AutoSize = false;
                        Image9->Picture->LoadFromFile(filename);
                        Label9->Caption = filename;
                   }
                   break;
                   case 10:
                   {
                        Image10->Stretch = true;
                        Image10->AutoSize = false;
                        Image10->Picture->LoadFromFile(filename);
                        Label10->Caption = filename;
                   }
                   break;
                   case 11:
                   {
                        Image11->Stretch = true;
                        Image11->AutoSize = false;
                        Image11->Picture->LoadFromFile(filename);
                        Label11->Caption = filename;
                   }
                   break;
                   case 12:
                   {
                        Image12->Stretch = true;
                        Image12->AutoSize = false;
                        Image12->Picture->LoadFromFile(filename);
                        Label12->Caption = filename;
                   }
                   break;
                   case 13:
                   {
                        Image13->Stretch = true;
                        Image13->AutoSize = false;
                        Image13->Picture->LoadFromFile(filename);
                        Label13->Caption = filename;
                   }
                   break;
                   case 14:
                   {
                        Image14->Stretch = true;
                        Image14->AutoSize = false;
                        Image14->Picture->LoadFromFile(filename);
                        Label14->Caption = filename;
                   }
                   break;
                   case 15:
                   {
                        Image15->Stretch = true;
                        Image15->AutoSize = false;
                        Image15->Picture->LoadFromFile(filename);
                        Label15->Caption = filename;
                   }
                   break;
                   case 16:
                   {
                        Image16->Stretch = true;
                        Image16->AutoSize = false;
                        Image16->Picture->LoadFromFile(filename);
                        Label16->Caption = filename;
                   }
                   break;
                   case 17:
                   {
                        Image17->Stretch = true;
                        Image17->AutoSize = false;
                        Image17->Picture->LoadFromFile(filename);
                        Label17->Caption = filename;
                   }
                   break;
                   case 18:
                   {
                        Image18->Stretch = true;
                        Image18->AutoSize = false;
                        Image18->Picture->LoadFromFile(filename);
                        Label18->Caption = filename;
                   }
                   break;
                   case 19:
                   {
                        Image19->Stretch = true;
                        Image19->AutoSize = false;
                        Image19->Picture->LoadFromFile(filename);
                        Label19->Caption = filename;
                   }
                   break;
                   case 20:
                   {
                        Image20->Stretch = true;
                        Image20->AutoSize = false;
                        Image20->Picture->LoadFromFile(filename);
                        Label20->Caption = filename;
                   }
                   break;
                   case 21:
                   {
                        Image21->Stretch = true;
                        Image21->AutoSize = false;
                        Image21->Picture->LoadFromFile(filename);
                        Label21->Caption = filename;
                   }
                   break;
                   case 22:
                   {
                        Image22->Stretch = true;
                        Image22->AutoSize = false;
                        Image22->Picture->LoadFromFile(filename);
                        Label22->Caption = filename;
                   }
                   break;
                   case 23:
                   {
                        Image23->Stretch = true;
                        Image23->AutoSize = false;
                        Image23->Picture->LoadFromFile(filename);
                        Label23->Caption = filename;
                   }
                   break;
                   case 24:
                   {
                        Image24->Stretch = true;
                        Image24->AutoSize = false;
                        Image24->Picture->LoadFromFile(filename);
                        Label24->Caption = filename;
                   }
                   break;
                   case 25:
                   {
                        Image25->Stretch = true;
                        Image25->AutoSize = false;
                        Image25->Picture->LoadFromFile(filename);
                        Label25->Caption = filename;
                   }
                   break;
                   case 26:
                   {
                        Image26->Stretch = true;
                        Image26->AutoSize = false;
                        Image26->Picture->LoadFromFile(filename);
                        Label26->Caption = filename;
                   }
                   break;
                   case 27:
                   {
                        Image27->Stretch = true;
                        Image27->AutoSize = false;
                        Image27->Picture->LoadFromFile(filename);
                        Label27->Caption = filename;
                   }
                   break;
                   case 28:
                   {
                        Image28->Stretch = true;
                        Image28->AutoSize = false;
                        Image28->Picture->LoadFromFile(filename);
                        Label28->Caption = filename;

                   }
                   break;
            }
         }
     }
}
//---------------------------------------------------------------------------


void __fastcall TThumbnailsForm::Button1Click(TObject *Sender)
{
     if (CurrentEnd >= NoAvailable-1) return;
     ClearAll(this);
     CurrentStart = CurrentEnd + 27;
     if (CurrentStart > NoAvailable-1) CurrentStart = CurrentEnd;
     CurrentEnd = CurrentStart + 27;
     if (CurrentEnd > NoAvailable-1) CurrentEnd = NoAvailable-1;
     FillPics(this);
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Button2Click(TObject *Sender)
{
     if (CurrentStart <= 0) return;
     ClearAll(this);
     CurrentStart = CurrentStart - 28;
     if (CurrentStart < 0) CurrentStart = 0;
     CurrentEnd = CurrentStart + 27;
     if (CurrentEnd > NoAvailable) CurrentEnd = NoAvailable-1;
     FillPics(this);
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image1Click(TObject *Sender)
{
     picno = 1 + CurrentStart - 1;
     if (Label1->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image2Click(TObject *Sender)
{
     picno = 2 + CurrentStart - 1;
     if (Label2->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image3Click(TObject *Sender)
{
     picno = 3 + CurrentStart - 1;
     if (Label3->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image4Click(TObject *Sender)
{
     picno = 4 + CurrentStart - 1;
     if (Label4->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image5Click(TObject *Sender)
{
     picno = 5 + CurrentStart - 1;
     if (Label5->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image6Click(TObject *Sender)
{
     picno = 6 + CurrentStart - 1;
     if (Label6->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image7Click(TObject *Sender)
{
     picno = 7 + CurrentStart - 1;
     if (Label7->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image8Click(TObject *Sender)
{
     picno = 8 + CurrentStart - 1;
     if (Label8->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image9Click(TObject *Sender)
{
     picno = 9 + CurrentStart - 1;
     if (Label9->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image10Click(TObject *Sender)
{
     picno = 10 + CurrentStart - 1;
     if (Label10->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image11Click(TObject *Sender)
{
     picno = 11 + CurrentStart - 1;
     if (Label11->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image12Click(TObject *Sender)
{
     picno = 12 + CurrentStart - 1;
     if (Label12->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image13Click(TObject *Sender)
{
     picno = 13 + CurrentStart - 1;
     if (Label13->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image14Click(TObject *Sender)
{
     picno = 14 + CurrentStart - 1;
     if (Label14->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image15Click(TObject *Sender)
{
     picno = 15 + CurrentStart - 1;
     if (Label15->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image16Click(TObject *Sender)
{
     picno = 16 + CurrentStart - 1;
     if (Label16->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image17Click(TObject *Sender)
{
     picno = 17 + CurrentStart - 1;
     if (Label17->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image18Click(TObject *Sender)
{
     picno = 18 + CurrentStart - 1;
     if (Label18->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image19Click(TObject *Sender)
{
     picno = 19 + CurrentStart - 1;
     if (Label19->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image20Click(TObject *Sender)
{
     picno = 20 + CurrentStart - 1;
     if (Label20->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image21Click(TObject *Sender)
{
     picno = 21 + CurrentStart - 1;
     if (Label21->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image22Click(TObject *Sender)
{
     picno = 22 + CurrentStart - 1;
     if (Label22->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image23Click(TObject *Sender)
{
     picno = 23 + CurrentStart - 1;
     if (Label23->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image24Click(TObject *Sender)
{
     picno = 24 + CurrentStart - 1;
     if (Label24->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image25Click(TObject *Sender)
{
     picno = 25 + CurrentStart - 1;
     if (Label25->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image26Click(TObject *Sender)
{
     picno = 26 + CurrentStart - 1;
     if (Label26->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image27Click(TObject *Sender)
{
     picno = 27 + CurrentStart - 1;
     if (Label27->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::Image28Click(TObject *Sender)
{
     picno = 28 + CurrentStart - 1;
     if (Label28->Caption == "") picno = 0;
     ThumbnailsForm->ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TThumbnailsForm::ClearAll(TObject *Sender)
{
     Image1->Picture->Assign(Clipboard());
     Image2->Picture->Assign(Clipboard());
     Image3->Picture->Assign(Clipboard());
     Image4->Picture->Assign(Clipboard());
     Image5->Picture->Assign(Clipboard());
     Image6->Picture->Assign(Clipboard());
     Image7->Picture->Assign(Clipboard());
     Image8->Picture->Assign(Clipboard());
     Image9->Picture->Assign(Clipboard());
     Image10->Picture->Assign(Clipboard());
     Image11->Picture->Assign(Clipboard());
     Image12->Picture->Assign(Clipboard());
     Image13->Picture->Assign(Clipboard());
     Image14->Picture->Assign(Clipboard());
     Image15->Picture->Assign(Clipboard());
     Image16->Picture->Assign(Clipboard());
     Image17->Picture->Assign(Clipboard());
     Image18->Picture->Assign(Clipboard());
     Image19->Picture->Assign(Clipboard());
     Image20->Picture->Assign(Clipboard());
     Image21->Picture->Assign(Clipboard());
     Image22->Picture->Assign(Clipboard());
     Image23->Picture->Assign(Clipboard());
     Image24->Picture->Assign(Clipboard());
     Image25->Picture->Assign(Clipboard());
     Image26->Picture->Assign(Clipboard());
     Image27->Picture->Assign(Clipboard());
     Image28->Picture->Assign(Clipboard());
     Label1->Caption = "";
     Label2->Caption = "";
     Label3->Caption = "";
     Label4->Caption = "";
     Label5->Caption = "";
     Label6->Caption = "";
     Label7->Caption = "";
     Label8->Caption = "";
     Label9->Caption = "";
     Label10->Caption = "";
     Label11->Caption = "";
     Label12->Caption = "";
     Label13->Caption = "";
     Label14->Caption = "";
     Label15->Caption = "";
     Label16->Caption = "";
     Label17->Caption = "";
     Label18->Caption = "";
     Label19->Caption = "";
     Label20->Caption = "";
     Label21->Caption = "";
     Label22->Caption = "";
     Label23->Caption = "";
     Label24->Caption = "";
     Label25->Caption = "";
     Label26->Caption = "";
     Label27->Caption = "";
     Label28->Caption = "";
}
