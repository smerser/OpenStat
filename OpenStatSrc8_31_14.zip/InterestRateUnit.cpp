//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "InterestRateUnit.h"
#include "Math.hpp"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TInterestRateForm *InterestRateForm;
//---------------------------------------------------------------------------
__fastcall TInterestRateForm::TInterestRateForm(TComponent* Owner)
     : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TInterestRateForm::ResetBtnClick(TObject *Sender)
{
     PaymentEdit->Text = "";
     NPayEdit->Text = "";
     PresentValueEdit->Text = "";
     FutureValueEdit->Text = "";
     InterestRateEdit->Text = "";     
}
//---------------------------------------------------------------------------
void __fastcall TInterestRateForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);     
}
//---------------------------------------------------------------------------
void __fastcall TInterestRateForm::Button1Click(TObject *Sender)
{
    int NPeriods, When;
    Extended Payment, PresentValue, FutureValue, Interest;
    TPaymentTime Time;

     When = TimeGroup->ItemIndex;
     if (When == 0) Time = ptStartOfPeriod;
     else Time = ptEndOfPeriod;
     PresentValue = StrToFloat(PresentValueEdit->Text);
     FutureValue = StrToFloat(FutureValueEdit->Text);
     NPeriods = StrToInt(NPayEdit->Text);
     Payment = StrToFloat(PaymentEdit->Text);
     Interest = InterestRate(NPeriods,Payment,PresentValue,FutureValue,Time);
     InterestRateEdit->Text = FloatToStr(Interest);
}
//---------------------------------------------------------------------------
