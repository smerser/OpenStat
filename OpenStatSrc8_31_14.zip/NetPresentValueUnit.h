//---------------------------------------------------------------------------

#ifndef NetPresentValueUnitH
#define NetPresentValueUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TNetPresentValueFrm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TEdit *FileNameEdit;
     TLabel *Label2;
     TEdit *SizeEdit;
     TButton *ComputeBtn;
     TLabel *Label4;
     TEdit *ROREdit;
     TButton *ReturnBtn;
     TRadioGroup *RadioGroup1;
     TLabel *Label3;
     TEdit *RateEdit;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     __fastcall TNetPresentValueFrm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TNetPresentValueFrm *NetPresentValueFrm;
//---------------------------------------------------------------------------
#endif
