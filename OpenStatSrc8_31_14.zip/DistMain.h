//---------------------------------------------------------------------------

#ifndef DistMainH
#define DistMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
//---------------------------------------------------------------------------
class TDistMainForm : public TForm
{
__published:	// IDE-managed Components
     TRadioGroup *CumGroup;
     TRadioGroup *ProbGroup;
     TGroupBox *ParmBox;
     TLabel *ParmLabel1;
     TLabel *ParmLabel2;
     TLabel *ParmLabel3;
     TLabel *ParmLabel4;
     TLabel *ParmLabel5;
     TLabel *ParmLabel6;
     TLabel *ParmLabel7;
     TEdit *ParmEdit1;
     TEdit *ParmEdit2;
     TEdit *ParmEdit3;
     TEdit *ParmEdit4;
     TEdit *ParmEdit5;
     TEdit *ParmEdit6;
     TEdit *ParmEdit7;
     TImage *Image1;
     TButton *CumCompBtn;
     TButton *ExitBtn;
     TButton *ProbCompBtn;
     TLabel *PlotLabel;
     TButton *PrintBtn;
     TMemo *Memo1;
        TGroupBox *ParmBox2;
        TLabel *ParmLabel11;
        TLabel *ParmLabel12;
        TLabel *ParmLabel13;
        TLabel *ParmLabel14;
        TLabel *ParmLabel15;
        TLabel *ParmLabel16;
        TLabel *ParmLabel17;
        TEdit *ParmEdit11;
        TEdit *ParmEdit12;
        TEdit *ParmEdit13;
        TEdit *ParmEdit14;
        TEdit *ParmEdit15;
        TEdit *ParmEdit16;
        TEdit *ParmEdit17;
        TButton *SaveImgBtn;
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ExitBtnClick(TObject *Sender);
     void __fastcall CumCompBtnClick(TObject *Sender);
     void __fastcall ProbCompBtnClick(TObject *Sender);
     void __fastcall CumGroupClick(TObject *Sender);
     void __fastcall ProbGroupClick(TObject *Sender);
     void __fastcall PrintBtnClick(TObject *Sender);
        void __fastcall SaveImgBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
     int ImageHi;
     int ImageWide;
     int Xstart;
     int Xend;
     int Ystart;
     int Yend;
     int Which;
     int Status;
     int selected;
     double P;
     double Q;
     double X;
     double Y;
     double A;
     double B;
     double Bound;
     double Xplot[101];
     double Yplot[101];
     void PlotXY(double *Xplot, double *Yplot, AnsiString Xlabel,
                 AnsiString Ylabel, AnsiString Caption, bool continuous);
     int combinations(int X, int N);
     __fastcall TDistMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDistMainForm *DistMainForm;
//---------------------------------------------------------------------------
#endif
