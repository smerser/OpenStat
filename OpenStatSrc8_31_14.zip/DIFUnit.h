//---------------------------------------------------------------------------

#ifndef DIFUnitH
#define DIFUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TDIFForm : public TForm
{
__published:	// IDE-managed Components
     TMemo *Memo1;
     TLabel *Label1;
     TListBox *VarList;
     TLabel *Label2;
     TListBox *ItemsList;
     TLabel *Label3;
     TEdit *GroupVarEdit;
     TBitBtn *InBtn;
     TBitBtn *OutBtn;
     TBitBtn *AllBtn;
     TBitBtn *GrpInBtn;
     TBitBtn *GrpOutBtn;
     TGroupBox *GroupBox1;
     TCheckBox *ItemStatsChk;
     TCheckBox *TestStatsChk;
     TCheckBox *ItemTestChk;
     TCheckBox *AlphaChk;
     TCheckBox *MHChk;
     TCheckBox *CurvesChk;
     TCheckBox *CountsChk;
     TGroupBox *GroupBox2;
     TLabel *Label4;
     TLabel *Label5;
     TScrollBar *LevelScroll;
     TLabel *Label6;
     TLabel *Label7;
     TLabel *Label8;
     TEdit *LevelNoEdit;
     TEdit *LowBoundEdit;
     TEdit *UpBoundEdit;
     TPanel *Panel1;
     TLabel *Label9;
     TLabel *Label10;
     TLabel *Label11;
     TEdit *RefGrpEdit;
     TEdit *TrgtGrpEdit;
     TEdit *LevelsEdit;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ReturnBtn;
     TButton *ComputeBtn;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall ReturnBtnClick(TObject *Sender);
     void __fastcall InBtnClick(TObject *Sender);
     void __fastcall OutBtnClick(TObject *Sender);
     void __fastcall AllBtnClick(TObject *Sender);
     void __fastcall GrpInBtnClick(TObject *Sender);
     void __fastcall LowBoundEditExit(TObject *Sender);
     void __fastcall UpBoundEditExit(TObject *Sender);
     void __fastcall LevelsEditExit(TObject *Sender);
     void __fastcall LevelScrollScroll(TObject *Sender,
          TScrollCode ScrollCode, int &ScrollPos);
     void __fastcall GrpOutBtnClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall LowBoundEditKeyPress(TObject *Sender, char &Key);
     void __fastcall CancelBtnClick(TObject *Sender);
private:	// User declarations
   int NoItems, nolevels;
   double tmean, tvar, tsd;
   int *ColNoSelected;
   AnsiString *ColLabels, *RowLabels;
   int **Data; //store item scores and total score
   int *Ubounds;     // upper and lower bounds of score groups
   int *Lbounds;
   char *Code; // blank, A, B or C ETS codes
   int **Level10OK;  // check that each item category >= 10
   int **RMHRight;   // no. right for items by score group in reference group
   int **RMHWrong;   // no. wrong for items by score group in reference group
   int **FMHRight;   // no. right for items by score group in focus group
   int **FMHWrong;   // no. wrong for items by score group in focus group
   int **RScrGrpCnt; // total responses for score groups in reference group
   int **FScrGrpCnt; // total responses for score groups in focus group
   int **NT;         // total right and wrong in each category of each item
   double *Alpha, *AlphaNum, *AlphaDen, *MHDiff, **ExpA, **VarA, *SumA;
   double *SumExpA, *SumVarA, *ChiSqr, *Prob, *SEMHDDif, *C;
   AnsiString *Aster;
   char *CodeRF;
   int *Tot;
   void __fastcall ItemCurves(TObject *Sender);

public:		// User declarations
     __fastcall TDIFForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TDIFForm *DIFForm;
//---------------------------------------------------------------------------
#endif
