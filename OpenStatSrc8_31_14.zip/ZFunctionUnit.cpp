//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "functions.h"
#include "ZFunctionUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TZFunctionsForm *ZFunctionsForm;
//---------------------------------------------------------------------------
__fastcall TZFunctionsForm::TZFunctionsForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TZFunctionsForm::ResetBtnClick(TObject *Sender)
{
        CumzEdit->Text = "";
        Z1ProbEdit->Text = "";
        Z2ProbEdit->Text = "";
        InverseEdit->Text = "";
        AnswerEdit->Text = "";
        Label1->Visible = true;
        Label2->Visible = false;
        Label3->Visible = false;
        Label4->Visible = false;
        Z1ProbEdit->Visible = false;
        Z2ProbEdit->Visible = false;
        InverseEdit->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TZFunctionsForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TZFunctionsForm::ChoiceGroupClick(TObject *Sender)
{
        int choice;

        choice = ChoiceGroup->ItemIndex;
        switch (choice) {
        case 0 : ResetBtnClick(this);
                 CumzEdit->Visible = true;
                 break;
        case 1 :  ResetBtnClick(this);
                  Label1->Visible = false;
                  CumzEdit->Visible = false;
                  Label2->Visible = true;
                  Label3->Visible = true;
                  Z1ProbEdit->Visible = true;
                  Z2ProbEdit->Visible = true;
                  break;
        case 2 :  ResetBtnClick(this);
                  Label1->Visible = false;
                  CumzEdit->Visible = false;
                  Label4->Visible = true;
                  InverseEdit->Visible = true;
                  break;
        }
}
//---------------------------------------------------------------------------
void __fastcall TZFunctionsForm::ComputeBtnClick(TObject *Sender)
{
        double answer,z,z1,z2,prob;
        int choice;

        choice = ChoiceGroup->ItemIndex;

        switch (choice)  {
        case 0 :  z = StrToFloat(CumzEdit->Text);
                  answer = probz(z);
                  AnswerEdit->Text = answer;
                  break;
        case 1 :  z1 = StrToFloat(Z1ProbEdit->Text);
                  z2 = StrToFloat(Z2ProbEdit->Text);
                  if (z1 > z2) answer = probz(z1) - probz(z2);
                  else answer = probz(z2) - probz(z1);
                  AnswerEdit->Text = answer;
                  break;
        case 2 :  prob = StrToFloat(InverseEdit->Text);
                  answer = inversez(prob);
                  AnswerEdit->Text = answer;
                  break;
        }
}
//---------------------------------------------------------------------------
