//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "DataFuncs.h"
#include "Math.h"
#include "ChangeValuesUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TChangeValuesForm *ChangeValuesForm;
extern int NoCases;
extern int NoVariables;
extern char FileName[81];
extern bool GridFileOpen;
extern bool FilterOn;
extern int FilterCol;
extern struct Options ops;
//---------------------------------------------------------------------------
__fastcall TChangeValuesForm::TChangeValuesForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TChangeValuesForm::FormShow(TObject *Sender)
{
     ListBox1->Clear();
     ListBox2->Clear();
     for (int i = 1; i <= NoVariables; i++)
     {
        ListBox1->Items->Add(MainForm->Grid->Cells[i][0]);
        ListBox2->Items->Add(MainForm->Grid->Cells[i][0]);
     }
     Value1Edit->Text = "";
     Value2Edit->Text = "";
     ListBox1->ItemIndex = -1;
     ListBox2->ItemIndex = -1;
     OpList->ItemIndex = -1;
     DefaultChk->Checked = false;
     newvariable = false;
}
//---------------------------------------------------------------------------
void __fastcall TChangeValuesForm::ChangeBtnClick(TObject *Sender)
{
        AnsiString FirstValue, SecondValue, Operation, response;
        double value1, Var1value, Var2value;

        if ((Var1Index <= 0) || (Var2Index <= 0))
        {
                response = InputBox("Missing variable choice","Select variable(s)","OK");
                return;
        }
        if (OpIndex < 0)
        {
                response = InputBox("No Operation Chosen","Select an operation.","OK");
                return;
        }
        FirstValue = Value1Edit->Text;
        SecondValue = Value2Edit->Text;
        if ((FirstValue.Length() <= 0) || (SecondValue.Length() <= 0))
        {
                response = InputBox("Missing Value 1 or 2","A value is missing.","OK");
                return;
        }
        value1 = StrToFloat(Trim(Value1Edit->Text));
        if (newvariable)
        {
                for (int i = 1; i <= NoCases; i++) MainForm->Grid->Cells[Var2Index][i] =
                   MainForm->Grid->Cells[Var1Index][i];
        }
         for (int i = 1; i <= NoCases; i++)
        {
                FirstValue = MainForm->Grid->Cells[Var1Index][i];
                if (!newvariable)
                        SecondValue = MainForm->Grid->Cells[Var2Index][i];
                else SecondValue = FirstValue;
                Var1value = StrToFloat(Trim(FirstValue));
                Var2value = StrToFloat(Trim(SecondValue));
                if (OpIndex == 0) // < operation
                {
                        if (Var1value < value1) MainForm->Grid->Cells[Var2Index][i] =
                           Value2Edit->Text;

                }
                if (OpIndex == 1) // = operation
                {
                        if (Var1value == value1) MainForm->Grid->Cells[Var2Index][i] =
                           Value2Edit->Text;

                }
                if (OpIndex == 2)  // > operation
                {
                        if (Var1value > value1) MainForm->Grid->Cells[Var2Index][i] =
                           Value2Edit->Text;

                }
        }
}

//---------------------------------------------------------------------------
void __fastcall TChangeValuesForm::ListBox1Click(TObject *Sender)
{
        Var1Index = ListBox1->ItemIndex + 1;
}
//---------------------------------------------------------------------------

void __fastcall TChangeValuesForm::ListBox2Click(TObject *Sender)
{
        Var2Index = ListBox2->ItemIndex + 1;
}
//---------------------------------------------------------------------------

void __fastcall TChangeValuesForm::OpListClick(TObject *Sender)
{
        OpIndex = OpList->ItemIndex;
}
//---------------------------------------------------------------------------


void __fastcall TChangeValuesForm::DefaultChkClick(TObject *Sender)
{
        if (DefaultChk->Checked) Value2Edit->Text = ops.missval;
        else Value2Edit->Text = "";
}
//---------------------------------------------------------------------------

void __fastcall TChangeValuesForm::NewVarChkClick(TObject *Sender)
{
        AnsiString response;
        int newcol;

        if (NewVarChk->Checked)
        {
                newvariable = true;
                response = InputBox("NAME","Enter a new variable name.","NewVar");
                newcol = MainForm->Grid->ColCount;
                NewVar(newcol,false);
                MainForm->Grid->Cells[newcol][0] = response;
//                ListBox2->Clear();
                ListBox2->Items->Add(response);
        }
        else
        {
                newvariable = false;
                return;
        }
}
//---------------------------------------------------------------------------

