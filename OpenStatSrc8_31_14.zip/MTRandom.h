void r250_521_init(void);
unsigned long r250_521_random(void);
void mt_init(void);
unsigned long mt_random(void);

 