//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "BankUpdate.h"
#include "FileSelUnit.h"
#include "ItemBank.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TItemBankFrm *ItemBankFrm;
extern long int NoVariables;
extern long int NoCases;

//---------------------------------------------------------------------------
__fastcall TItemBankFrm::TItemBankFrm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TItemBankFrm::CancelBtnClick(TObject *Sender)
{
    ItemBankFrm->Hide();    
}
//---------------------------------------------------------------------------
void __fastcall TItemBankFrm::FormShow(TObject *Sender)
{
    BankEdit->Text = "";
}
//---------------------------------------------------------------------------
void __fastcall TItemBankFrm::OpenBtnClick(TObject *Sender)
{
    FileSelFrm->ShowModal();
    BankEdit->Text = FileSelFrm->FileNameEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TItemBankFrm::NewBtnClick(TObject *Sender)
{
    FileSelFrm->ShowModal();
    BankEdit->Text = FileSelFrm->FileNameEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TItemBankFrm::OKBtnClick(TObject *Sender)
{
    if (BankEdit->Text == "")
    {
       ShowMessage("You must first name an existing file or create a new one.");
       return;
    }
    BankUpdate();
    ItemBankFrm->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TItemBankFrm::BankUpdate(void)
{
    BankUpdateFrm->ShowModal();
}
//---------------------------------------------------------------------------


