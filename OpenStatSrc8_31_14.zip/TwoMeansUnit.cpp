//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "stdio.h"
#include "MainUnit.h"
#include "DataFuncs.h"
#include "functions.h"
#include "math.h"
#include "OutPut.h"
#include "TwoMeansUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TTwoMeansForm *TwoMeansForm;
extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
__fastcall TTwoMeansForm::TTwoMeansForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::ResetBtnClick(TObject *Sender)
{
     RadioGroup1->ItemIndex = 0;
     RadioGroup2->ItemIndex = 0;
     Panel1->Visible = true;
     Panel2->Visible = false;
     VarList->Clear();
     Var1->Text = "";
     Var2->Text = "";
     Mean1->Text = "";
     Mean2->Text = "";
     SD1->Text = "";
     SD2->Text = "";
     N1->Text = "";
     N2->Text = "";
     Cor12->Text = "";
     CInterval->Text = "95";
     independent = true;
     griddata = false;
     Grp->Text = "";
     Grp1->Text = "";
     Grp2->Text = "";
     Label14->Visible = false;
     Cor12->Visible = false;
     for (int i = 1; i <= NoVariables; i++)
     	VarList->Items->Add(MainForm->Grid->Cells[i][0]);
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::VarListClick(TObject *Sender)
{
     int index = VarList->ItemIndex;
     if (! independent)
     {
          if (Var1->Text != "")  Var2->Text = VarList->Items->Strings[index];
          else Var1->Text = VarList->Items->Strings[index];
     }
     if (independent)
     {
          if (Var1->Text != "")  Grp->Text = VarList->Items->Strings[index];
          else Var1->Text = VarList->Items->Strings[index];
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::RadioGroup1Click(TObject *Sender)
{
     int index = RadioGroup1->ItemIndex;
     if (index == 0)
     {
          Panel1->Visible = true;
          Panel2->Visible = false;
          griddata = false;
     }
     else
     {
          Panel2->Visible = true;
          Panel1->Visible = false;
          griddata = true;
          if (RadioGroup2->ItemIndex == 1) // dependent means
          {
               independent = false;
               Label11->Visible = true;
               Var2->Visible = true;
               Grp->Visible = false;
               Label12->Visible = false;
               Label7->Visible = false;
               Label8->Visible = false;
               Grp1->Visible = false;
               Grp2->Visible = false;
               Label14->Visible = true;
               Cor12->Visible = true;
          }
          else  // independent means
          {
               independent = true;
               Label11->Visible = false;
               Var2->Visible = false;
               Grp->Visible = true;
               Grp1->Visible = true;
               Grp2->Visible = true;
               Label12->Visible = true;
               Label7->Visible = true;
               Label8->Visible = true;
               Label14->Visible = false;
               Cor12->Visible = false;
          }
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::RadioGroup2Click(TObject *Sender)
{
     int index = RadioGroup2->ItemIndex;
     if (index == 0)  // independent scores
     {
               independent = true;
               Label11->Visible = false;
               Var2->Visible = false;
               Grp->Visible = true;
               Grp1->Visible = true;
               Grp2->Visible = true;
               Label12->Visible = true;
               Label7->Visible = true;
               Label8->Visible = true;
               Label14->Visible = false;
               Cor12->Visible = false;
     }
     else
     {
               independent = false;
               Label11->Visible = true;
               Var2->Visible = true;
               Grp->Visible = false;
               Label12->Visible = false;
               Label7->Visible = false;
               Label8->Visible = false;
               Grp1->Visible = false;
               Grp2->Visible = false;
               Label14->Visible = true;
               Cor12->Visible = true;
     }
}
//---------------------------------------------------------------------------
void __fastcall TTwoMeansForm::ContinueBtnClick(TObject *Sender)
{
   double M1, M2, Dif, stddev1, stddev2, r12, z, stderr1, stderr2;
   double tequal, tunequal, cov12, lowci, hici, F, Fp, df1, df2;
   double tprobability, zprobability, stderrt, stderrz, value1, value2;
   double variance1, variance2, pooled, sedif, df, ConfInt, tconfint;
   double Cohend, stdifscrs;
   int i, j, v1, v2, ncases1, ncases2, NoSelected;
   int group, min, max;
   int *ColNoSelected;
   AnsiString response, cellstring;
   char outline[121], label1[21], label2[21];
   int result, intvalue;
   double dblvalue;
   AnsiString strvalue;

     ColNoSelected = new int[NoVariables];
     ncases1 = 0;
     ncases2 = 0;
     variance1 = 0.0;
     variance2 = 0.0;
     M1 = 0.0;
     M2 = 0.0;
     Dif = 0.0;
     r12 = 0.0;
     v1 = 0;
     v2 = 0;
     stddev1 = 0.0;
     stddev2 = 0.0;

     ConfInt = (100.0 - StrToFloat(CInterval->Text)) / 2.0 ;
     ConfInt = (100.0 - ConfInt) / 100.0; // one tail
     if (independent)  Var2->Text = Grp->Text;
     if (griddata)  // data read from Grid
     {
          for (i = 1; i <= NoVariables; i++)
          {
               if (Var1->Text == MainForm->Grid->Cells[i][0])
               {
                    v1 = i;
                    //result = VarTypeChk(i,0);
                    //if (result == 1)
                    //{
                    //    delete[] ColNoSelected;
                    //    return;
                    //}
                    ColNoSelected[0] = i;
                    strcpy(label1,Var1->Text.c_str());
               }
               if (Var2->Text == MainForm->Grid->Cells[i][0])
               {
                    v2 = i;
                    ColNoSelected[1] = i;
                    strcpy(label2,Var2->Text.c_str());
               }
          } // next variable
          if ((v1 == 0) || (v2 == 0))
          {
                ShowMessage("ERROR! Select a first and second variable.");
                delete[] ColNoSelected;
                return;
          }
          ncases1 = 0;
          ncases2 = 0;
          NoSelected = 2;
          M1 = 0.0;
          M2 = 0.0;
          variance1 = 0.0;
          variance2 = 0.0;
          r12 = 0.0;
          if (! independent)  // correlated data
          {
               for (i = 1; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                    if (!ValidValue(i,v1)) continue;
                    if (!ValidValue(i,v2)) continue;
                    ncases1 = ncases1 + 1;
                    value1 = StrToFloat(Trim(MainForm->Grid->Cells[v1][i]));
                    //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                    //if (result == 1) value1 = 0.0;
                    //else value1 = dblvalue;
                    value2 = StrToFloat(Trim(MainForm->Grid->Cells[v2][i]));
                    //result = GetValue(i,v2,intvalue,dblvalue,strvalue);
                    //if (result == 1) value2 = 0.0;
                    //else value2 = dblvalue;
                    M1 = M1 + value1;
                    M2 = M2 + value2;
                    variance1 = variance1 + (value1 * value1);
                    variance2 = variance2 + (value2 * value2);
                    r12 = r12 + value1 * value2;
               }
               ncases2 = ncases1;
               variance1 = variance1 - ((M1 * M1) / (double) ncases1);
               variance1 = variance1 / (double)(ncases1 - 1);
               stddev1 = sqrt(variance1);
               variance2 = variance2 - ((M2 * M2) / (double) ncases2);
               variance2 = variance2 / (double)(ncases2 - 1);
               stddev2 = sqrt(variance2);
               r12 = r12 - ((M1 * M2) / (double) ncases1);
               r12 = r12 / (double)(ncases1 - 1);
               cov12 = r12;
               r12 = r12 / (stddev1 * stddev2);
               M1 = M1 / (double) ncases1;
               M2 = M2 / (double) ncases2;
               Dif = M1 - M2;
          } //if ! independent
          if (independent)
          {
               min = StrToInt(Grp1->Text);
               max = StrToInt(Grp2->Text);
               for (i = 1; i <= NoCases; i++)
               {
                    if (! ValidRecord(i,ColNoSelected,NoSelected))  continue;
                    if (!ValidValue(i,v1)) continue;
                    if (!ValidValue(i,v2)) continue;
                    value1 = StrToFloat(Trim(MainForm->Grid->Cells[v1][i]));
                    //result = GetValue(i,v1,intvalue,dblvalue,strvalue);
                    //if (result == 1) value1 = 0.0;
                    //else value1 = dblvalue;
                    group = floor(StrToFloat(Trim(MainForm->Grid->Cells[v2][i])));
                    //result = GetValue(i,v2,intvalue,dblvalue,strvalue);
                    //if (result == 1) group = 0;
                    //else group = intvalue;
                    if (group == min)
                    {
                         M1 = M1 + value1;
                         variance1 = variance1 + (value1 * value1);
                         ncases1 = ncases1 + 1;
                    }
                    else if (group == max)
                    {
                         M2 = M2 + value1;
                         variance2 = variance2 + (value1 * value1);
                         ncases2 = ncases2 + 1;
                    }
               } // next case
               variance1 = variance1 - ((M1 * M1) / (double) ncases1);
               variance1 = variance1 / (double)(ncases1 - 1);
               stddev1 = sqrt(variance1);
               variance2 = variance2 - ((M2 * M2) / (double)ncases2);
               variance2 = variance2 / (double)(ncases2 - 1);
               stddev2 = sqrt(variance2);
               M1 = M1 / (double)ncases1;
               M2 = M2 / (double)ncases2;
               Dif = M1 - M2;
               sprintf(outline,"Group %d",min);
               strcpy(label1,outline);
               sprintf(outline,"Group %d",max);
               strcpy(label2,outline);
          } // if independent data
     } // if reading Grid data
     if (! griddata)  // data read from form
     {
          M1 = StrToFloat(Mean1->Text);
          M2 = StrToFloat(Mean2->Text);
          stddev1 = StrToFloat(SD1->Text);
          stddev2 = StrToFloat(SD2->Text);
          ncases1 = ceil(StrToFloat(N1->Text));
          ncases2 = ceil(StrToFloat(N2->Text));
          variance1 = stddev1 * stddev1;
          variance2 = stddev2 * stddev2;
          strcpy(label1,"Group 1");
          strcpy(label2,"Group 2");
          Dif = M1 - M2;
          if (! independent)
          {
               r12 = StrToFloat(Cor12->Text);
               cov12 = r12 * stddev1 * stddev2;
          }
     }

     // Initialize output form
     FrmOutPut->RichOutPut->Clear();
     FrmOutPut->RichOutPut->Lines->Add("COMPARISON OF TWO MEANS");
     FrmOutPut->RichOutPut->Lines->Add("");

     // Calculate pooled and independent t and z values and test statistic
     if (independent)
     {
          stderr1 = sqrt(variance1 / (double)ncases1);
          stderr2 = sqrt(variance2 / (double)ncases2);
          FrmOutPut->RichOutPut->Lines->Add("Variable       Mean    Variance  Std.Dev.  S.E.Mean  N");
          sprintf(outline,"%-10s %8.2f  %8.2f  %8.2f  %8.2f  %d",
                            label1,M1, variance1, stddev1, stderr1, ncases1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"%-10s %8.2f  %8.2f  %8.2f  %8.2f  %d",
                            label2, M2, variance2, stddev2, stderr2, ncases2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          pooled = ((ncases1-1) * variance1) + ((ncases2-1) * variance2);
          pooled = pooled / (double)(ncases1 + ncases2 - 2);
          Cohend = (M1 - M2) / sqrt(pooled);
          pooled = pooled * ( 1.0 / (double)ncases1 + 1.0 / (double)ncases2);
          sedif = sqrt(pooled);
          tequal = Dif / sedif;
          df = (double) (ncases1 + ncases2 - 2);
          tprobability = tprob(tequal,df);
          sprintf(outline,"Cohen's d = %8.3f",Cohend);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Assuming equal variances, t = %8.3f with probability = %6.4f and %3.0f degrees of freedom",
                            tequal, tprobability, df);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference = %8.2f and Standard Error of difference = %8.2f",
               Dif, sedif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          tconfint = inverset(ConfInt,df);
          lowci = Dif - tconfint * sedif;
          hici = Dif + tconfint * sedif;
          sprintf(outline,"Confidence interval = (%8.2f,%8.2f)",lowci,hici);
          FrmOutPut->RichOutPut->Lines->Add(outline);

          // now for unequal variances
          sedif = sqrt((variance1 / (double)ncases1) + (variance2 / (double)ncases2));
          tunequal = Dif / sedif;
          df = sqr((variance1 / (double)ncases1) + (variance2 / (double)ncases2));
          df = df / (sqr(variance1 / (double)ncases1) / (double)(ncases1 - 1) +
                      sqr(variance2 / (double)ncases2) / (double)(ncases2 - 1) );
          tprobability = tprob(tunequal,df);
          sprintf(outline,"Assuming unequal variances, t = %8.3f with probability = %6.4f and %5.2f degrees of freedom",
                            tunequal, tprobability, df);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference = %8.2f and Standard Error of difference = %8.2f",
               Dif, sedif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          tconfint = inverset(ConfInt,df);
          lowci = Dif - tconfint * sedif;
          hici = Dif + tconfint * sedif;
          sprintf(outline,"Confidence interval = (%8.2f,%8.2f)",lowci,hici);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          df1 = ncases1 - 1;
          df2 = ncases2 - 1;
          if (variance1 > variance2)
          {
               F = variance1 / variance2;
               Fp = ftest(df1,df2,F);
          }
          else
          {
               F = variance2 / variance1;
               Fp = ftest(df2,df1,F);
          }
          sprintf(outline,"F test for equal variances = %8.3f, Probability = %6.4f",
               F, Fp);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     else
     {  // dependent t test
          stderr1 = sqrt(variance1 / (double)ncases1);
          stderr2 = sqrt(variance2 / (double)ncases2);
          FrmOutPut->RichOutPut->Lines->Add("Variable    Mean      Variance  Std.Dev.  S.E.Mean  N");
          sprintf(outline,"%-10s %8.2f  %8.2f  %8.2f  %8.2f  %d",
               label1 ,M1, variance1, stddev1, stderr1, ncases1);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"%-10s %8.2f  %8.2f  %8.2f  %8.2f  %d",
               label2,M2, variance2, stddev2, stderr2, ncases2);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sedif = variance1 + variance2 - (2.0 * cov12);
          stdifscrs = sqrt(sedif);
          Cohend = Dif / stdifscrs;
          sedif = sqrt(sedif / (double)ncases1);
          tequal = Dif / sedif;
          df = ncases1 - 1;
          sprintf(outline,"Cohen's d = %8.3f",Cohend);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          tprobability = tprob(tequal,df);
          sprintf(outline,"Assuming dependent samples, t = %8.3f with probability = %6.4f and %3.0f degrees of freedom",
                            tequal, tprobability, df);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Correlation between %s and %s = %6.3f",
               label1,label2,r12);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          sprintf(outline,"Difference = %8.2f and Standard Error of difference = %8.2f",
               Dif, sedif);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          tconfint = inverset(ConfInt,df);
          lowci = Dif - tconfint * sedif;
          hici = Dif + tconfint * sedif;
          sprintf(outline,"Confidence interval = (%8.2f,%8.2f)",
               lowci,hici);
          FrmOutPut->RichOutPut->Lines->Add(outline);
          tequal = variance1 - variance2;
          tequal = tequal / sqrt( (4 * variance1 * variance2)/(ncases1 - 2) *
               (1.0 - sqr(r12)) );
          df = ncases1 - 2;
          tprobability = tprob(tequal,df);
          sprintf(outline,"t for test of equal variances = %8.3f with probability = %6.4f",
               tequal,tprobability);
          FrmOutPut->RichOutPut->Lines->Add(outline);
     }
     FrmOutPut->RichOutPut->Lines->Add("");
     FrmOutPut->RichOutPut->Lines->Add("NOTE: t-tests are two-tailed tests.");
     FrmOutPut->ShowModal();
     delete[] ColNoSelected;
}
//---------------------------------------------------------------------------
