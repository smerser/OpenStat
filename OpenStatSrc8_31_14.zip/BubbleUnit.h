//---------------------------------------------------------------------------

#ifndef BubbleUnitH
#define BubbleUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TBubbleForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TListBox *Varlist;
        TBitBtn *BubbleInBtn;
        TBitBtn *BubbleOutBtn;
        TLabel *Label2;
        TLabel *Label1;
        TBitBtn *XInBtn;
        TBitBtn *XOutBtn;
        TBitBtn *YInBtn;
        TBitBtn *YOutBtn;
        TEdit *BubbleEdit;
        TEdit *XEdit;
        TEdit *YEdit;
        TBitBtn *SizeInBtn;
        TBitBtn *SizeOutBtn;
        TEdit *SizeEdit;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TButton *ResetBtn;
        TButton *ComputeBtn;
        TButton *ReturnBtn;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *XlabelEdit;
        TEdit *YlabelEdit;
        TButton *CancelBtn;
        TLabel *Label8;
        TEdit *TitleEdit;
        TGroupBox *Options;
        TCheckBox *Transform;
        void __fastcall ResetBtnClick(TObject *Sender);
        void __fastcall BubbleInBtnClick(TObject *Sender);
        void __fastcall BubbleOutBtnClick(TObject *Sender);
        void __fastcall XInBtnClick(TObject *Sender);
        void __fastcall XOutBtnClick(TObject *Sender);
        void __fastcall YInBtnClick(TObject *Sender);
        void __fastcall YOutBtnClick(TObject *Sender);
        void __fastcall SizeInBtnClick(TObject *Sender);
        void __fastcall SizeOutBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TBubbleForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBubbleForm *BubbleForm;
//---------------------------------------------------------------------------
#endif
