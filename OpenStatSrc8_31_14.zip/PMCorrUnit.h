//---------------------------------------------------------------------------

#ifndef PMCorrUnitH
#define PMCorrUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TPMCorrForm : public TForm
{
__published:	// IDE-managed Components
   TListBox *VarList;
   TListBox *SelList;
   TLabel *Label1;
   TLabel *Label2;
   TBitBtn *InBtn;
   TBitBtn *OutBtn;
   TBitBtn *BitBtn3;
   TButton *ResetBtn;
   TButton *CancelBtn;
   TButton *ComputeBtn;
   TButton *ReturnBtn;
	TGroupBox *Options;
	TCheckBox *SaveChk;
	TSaveDialog *SaveDialog1;
	TCheckBox *PairWiseChk;
	TCheckBox *CrossProdChk;
	TCheckBox *CovarChk;
	TCheckBox *DescChk;
	TCheckBox *AugmentChk;
	TCheckBox *CorrsChk;
   void __fastcall ResetBtnClick(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall InBtnClick(TObject *Sender);
   void __fastcall OutBtnClick(TObject *Sender);
   void __fastcall BitBtn3Click(TObject *Sender);
   void __fastcall ComputeBtnClick(TObject *Sender);
	void __fastcall PairWiseChkClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TPMCorrForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TPMCorrForm *PMCorrForm;
//---------------------------------------------------------------------------
#endif
