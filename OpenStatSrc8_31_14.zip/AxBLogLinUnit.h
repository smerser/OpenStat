//---------------------------------------------------------------------------

#ifndef AxBLogLinUnitH
#define AxBLogLinUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TAxBLogLinForm : public TForm
{
__published:	// IDE-managed Components
     TRadioGroup *InputGrp;
     TButton *ResetBtn;
     TButton *CancelBtn;
     TButton *ComputeBtn;
     TButton *ReturnBtn;
     TPanel *Panel1;
     TLabel *Label1;
     TEdit *NoRowsEdit;
     TLabel *Label2;
     TEdit *NoColsEdit;
     TStringGrid *Grid;
     TPanel *Panel2;
     TLabel *Label3;
     TListBox *VarList;
     TBitBtn *RowInBtn;
     TBitBtn *RowOutBtn;
     TBitBtn *ColInBtn;
     TBitBtn *ColOutBtn;
     TBitBtn *FreqInBtn;
     TBitBtn *FreqOutBtn;
     TLabel *Label4;
     TEdit *RowEdit;
     TLabel *Label5;
     TEdit *ColEdit;
     TLabel *Label6;
     TEdit *FreqEdit;
     TMemo *Memo1;
     void __fastcall ResetBtnClick(TObject *Sender);
     void __fastcall FormShow(TObject *Sender);
     void __fastcall RowInBtnClick(TObject *Sender);
     void __fastcall RowOutBtnClick(TObject *Sender);
     void __fastcall ColInBtnClick(TObject *Sender);
     void __fastcall ColOutBtnClick(TObject *Sender);
     void __fastcall FreqInBtnClick(TObject *Sender);
     void __fastcall FreqOutBtnClick(TObject *Sender);
     void __fastcall InputGrpClick(TObject *Sender);
     void __fastcall ComputeBtnClick(TObject *Sender);
     void __fastcall NoColsEditKeyPress(TObject *Sender, char &Key);
     void __fastcall NoRowsEditKeyPress(TObject *Sender, char &Key);
private:	// User declarations
void __fastcall PrintTable(int Nrows, int Ncols,
                                    double **Data,
                                    double *RowMarg,
                                    double *ColMarg,
                                    double Total);
void __fastcall Iterate(int Nrows, int Ncols,
                                 double **Data,
                                 double *RowMarg,
                                 double *ColMarg,
                                 double &Total,
                                 double **Expected,
                                 double *NewRowMarg,
                                 double *NewColMarg,
                                 double &NewTotal);
void __fastcall PrintLamdas(int Nrows, int Ncols,
                                     double ***CellLambdas,
                                     double mu);
                                     

public:		// User declarations
     __fastcall TAxBLogLinForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAxBLogLinForm *AxBLogLinForm;
//---------------------------------------------------------------------------
#endif
