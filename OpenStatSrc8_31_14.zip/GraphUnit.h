//---------------------------------------------------------------------------

#ifndef GraphUnitH
#define GraphUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TGraphForm : public TForm
{
__published:	// IDE-managed Components
   TPanel *Panel1;
   TImage *Image1;
   TButton *ReturnBtn;
   TButton *PrintBtn;
   TButton *SaveBtn;
   TSaveDialog *SaveDialog1;
   void __fastcall FormResize(TObject *Sender);
   void __fastcall FormShow(TObject *Sender);
   void __fastcall SaveBtnClick(TObject *Sender);
   void __fastcall PrintBtnClick(TObject *Sender);
private:	// User declarations
    int ImageWidth;
    int ImageHeight;
    int XOffset;
    int YOffset;
    int XAxisLength;
    int YAxisLength;
    int TanAngle;
    int BarWidth;
    int XStart;
    int XEnd;
    int YStart;
    int YEnd;
    int Gtype;
    int NoBars;
    int NSets;
//    int Colors[12];
    TColor Colors[12];
    double DegAngle;
    double RadAngle;
    double YMax;
    double YMin;
    double XProp;

    void __fastcall  Bar2D(TComponent* Owner);
    void __fastcall  Bar3D(TComponent* Owner);
    void __fastcall  Pie2D(TComponent* Owner);
    void __fastcall  Pie3D(TComponent* Owner);
    void __fastcall  Line2D(TComponent* Owner);
    void __fastcall  Line3D(TComponent* Owner);
    void __fastcall  Plot2D(TComponent* Owner);
    void __fastcall  Plot3D(TComponent* Owner);
    void __fastcall  MakeXAxis(TComponent* Owner);
    void __fastcall  MakeYAxis(TComponent* Owner);
    void __fastcall  MakeHXaxis(TComponent* Owner);
    void __fastcall  MakeHYaxis(TComponent* Owner);
    double __fastcall  DegToRad(double Deg, TComponent* Owner);
    void __fastcall  HBar2D(TComponent* Owner);
    void __fastcall  HBar3D(TComponent* Owner);
    void __fastcall  Walls(TComponent* Owner);

public:		// User declarations
    int nosets;                      //number of data sets to plot
    int nbars;                       // maximum number of bars to plot in any set
    AnsiString Heading;                      // Major Heading for graph
    AnsiString XTitle;               // title for x-axis
    AnsiString YTitle;               // title for vertical axis
    double barwideprop;              // proportional width of bar (0 to 1.0)
    int GraphType;  //0=2dHorbar, 1=3dHorbar,2 = 2DVerbar, 3 = 3DVerBar,
                    //4=2dpie, 5=3dpie, 6=2dline, 7=3dline, 8 = 2Dpoint, 9=3Dpoint
    double **Ypoints, **Xpoints;     // DblDyneMat
    AnsiString SetLabels[11];    // labels for multiple sets
    AnsiString PointLabels[1000]; // individual point labels
    bool PtLabels;                   // true to print point labels (for 2D Plot only)
    bool AutoScale;                  // if true, program uses computed min and max values
    bool ShowLeftWall;
    bool ShowRightWall;
    bool ShowBottomWall;
    bool ShowBackWall;
    TColor BackColor;
    TColor WallColor;
    TColor FloorColor;
//    int BackColor;
//    int WallColor;
//    int FloorColor;
    double miny;                     // specified by user if autoscale is false
    double maxy;                     // specified by user if autoscale is false

   __fastcall TGraphForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TGraphForm *GraphForm;
//---------------------------------------------------------------------------
#endif
