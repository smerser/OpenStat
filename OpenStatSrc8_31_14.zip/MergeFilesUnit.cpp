//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "MainUnit.h"
#include "MergeFilesUnit.h"
#include "stdio.h"
#include "DictionaryUnit.h"

extern int NoCases;
extern int NoVariables;

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMergeFilesForm *MergeFilesForm;
//---------------------------------------------------------------------------
__fastcall TMergeFilesForm::TMergeFilesForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMergeFilesForm::ResetBtnClick(TObject *Sender)
{
        VarList->Clear();
        VarList2->Clear();
        SecondFileEdit->Text = "";
        SplitTypeGrp->ItemIndex = 0;
        Panel1->Visible = true;
        Panel2->Visible = false;
        Label3->Visible = true;
        Label4->Visible = false;
        for (int i = 1; i <= NoVariables; i++)
        {
                VarList->Items->Add(MainForm->Grid->Cells[i][0]);
                VarList2->Items->Add(MainForm->Grid->Cells[i][0]);
        }
        FirstFileEdit->Text = MainForm->FileNameEdit->Text;
}
//---------------------------------------------------------------------------

void __fastcall TMergeFilesForm::FormShow(TObject *Sender)
{
        ResetBtnClick(this);        
}
//---------------------------------------------------------------------------

void __fastcall TMergeFilesForm::SplitTypeGrpClick(TObject *Sender)
{
        if (SplitTypeGrp->ItemIndex == 0)
        {
                Panel1->Visible = true;
                Panel2->Visible = false;
                Label3->Visible = true;
                Label4->Visible = false;
        }
        else
        {
                Panel1->Visible = false;
                Panel2->Visible = true;
                Label3->Visible = false;
                Label4->Visible = true;
        }
}
//---------------------------------------------------------------------------

void __fastcall TMergeFilesForm::BrowseBtnClick(TObject *Sender)
{

   MainForm->OpenDialog1->InitialDir = GetCurrentDir();
   MainForm->OpenDialog1->DefaultExt = "TEX";
   MainForm->OpenDialog1->Filter = "OpenStat File (*.tex)|*.TEX|Text files (*.s4u)|*.S4U|All files (*.*)|*.*";
   MainForm->OpenDialog1->FilterIndex = 1;
   if (MainForm->OpenDialog1->Execute())
   {
        FileName = MainForm->OpenDialog1->FileName;
        SecondFileEdit->Text = FileName;
        FileTwo = fopen(FileName.c_str(),"rt");
        fscanf(FileTwo,"%d",&nrows);
        fscanf(FileTwo,"%d",&ncols);
        // get memory for 2nd file's dictionary entries
        DictTwo = new AnsiString *[ncols+1];
        for (int i = 0; i < ncols+1; i++) DictTwo[i] = new AnsiString[7];
        // get dictionary values for second file
        for (int i = 1; i <= ncols; i++)  // dictionary rows
        {
                for (int j = 0; j < 7; j++) // dictionary columns
                {
      		        fscanf(FileTwo,"%s",cellstr);
                        int howlong = strlen(cellstr);
                        cellstr[howlong] = '\0';
                        DictTwo[i][j] = cellstr;
                }
                // Place names in list
                VarList2->Items->Add(DictTwo[i][1]);
        }
   }
}
//---------------------------------------------------------------------------


void __fastcall TMergeFilesForm::ComputeBtnClick(TObject *Sender)
{
        int totalrows = NoCases + nrows + 1;
        MainForm->Grid->RowCount = totalrows;

        if (SplitTypeGrp->ItemIndex == 0) // vertical split
        {
                MainForm->Grid->RowCount = NoCases + nrows+1;
                // do grid row 0 first
                for (int j = 0; j <= ncols; j++)
                {
                        fscanf(FileTwo,"%s",cellstr);
                        int howlong = strlen(cellstr);
                        cellstr[howlong] = '\0';
                        MainForm->Grid->Cells[j][0] = cellstr;
                }
                for (int i = NoCases + 1; i <= totalrows; i++)
                {
                        for (int j = 0; j <= ncols; j++)
                        {
      		                fscanf(FileTwo,"%s",cellstr);
                                int howlong = strlen(cellstr);
                                cellstr[howlong] = '\0';
                                MainForm->Grid->Cells[j][i] = cellstr;
                        }
                }
                MainForm->NoCasesEdit->Text = IntToStr(totalrows-1);
                NoCases = totalrows;
        }
        else // horizontal split
        {
                // read data.  Note that no. of rows & columns & dictionary
                // are already input
                int TotCols = VarList2->Items->Count + 1;
                MainForm->Grid->ColCount = TotCols;
                MainForm->Grid->RowCount = NoCases+1;
                for (int i = 0; i <= NoCases; i++)
                {
                        //skip column 0 in reading data
                        fscanf(FileTwo,"%s",cellstr);
                        for (int j = NoVariables + 1; j < TotCols; j++)
                        {
                                strcpy(cellstr,"");
      		                fscanf(FileTwo,"%s",cellstr);
                                int howlong = strlen(cellstr);
                                cellstr[howlong] = '\0';
                                MainForm->Grid->Cells[j][i] = cellstr;
                        }
                }
                // add dictionary definitions
                DictionaryForm->DGrid->RowCount = DictionaryForm->DGrid->RowCount + ncols;
                for (int i = 0; i < ncols; i++)
                {
                        for (int j = 0; j < 7; j++)
                                DictionaryForm->DGrid->Cells[j][NoVariables + i + 1] = DictTwo[i+1][j];
                }
                MainForm->NoVarsEdit->Text = IntToStr(NoVariables + ncols);
                NoVariables += ncols;
        }
        fclose(FileTwo);
        for (int i = 0; i < ncols + 1; i++) delete[] DictTwo[i];
        delete[] DictTwo;
}
//---------------------------------------------------------------------------

