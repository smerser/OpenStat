//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "VarSelect.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TFrmVarSel *FrmVarSel;
//---------------------------------------------------------------------------
__fastcall TFrmVarSel::TFrmVarSel(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmVarSel::BtnOKClick(TObject *Sender)
{
	FrmVarSel->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmVarSel::BtnResetClick(TObject *Sender)
{
    int noselected;
    AnsiString cellstring;

    noselected = LstBoxSelected->Items->Count;
    if (noselected > 0)
    {
    	for (int i = 0; i < noselected; i++)
        {
            cellstring = LstBoxSelected->Items->Strings[i];
            LstBoxVars->Items->Add(cellstring);
        }
    }
    LstBoxSelected->Clear();
    InBtn->Visible = true;
    OutBtn->Visible = false;
}
//---------------------------------------------------------------------------
void __fastcall TFrmVarSel::InBtnClick(TObject *Sender)
{
     int index, count = 0;
     AnsiString cellstring;

     index = LstBoxVars->Items->Count;
     for (int i = 0; i < index; i++)
     {
         if (LstBoxVars->Selected[i])
         {
            cellstring = LstBoxVars->Items->Strings[i];
            LstBoxSelected->Items->Add(cellstring);
            count++;
         }
     }

     while (count > 0)
     {
           for (int i = 0; i < LstBoxVars->Items->Count; i++)
           {
               if (LstBoxVars->Selected[i])
               {
                  LstBoxVars->Items->Delete(i);
                  count--;
               }
           }
     }
     OutBtn->Visible = true;
     if (LstBoxVars->Items->Count < 1) InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmVarSel::OutBtnClick(TObject *Sender)
{
     int index;
     AnsiString cellstring;

     index = LstBoxSelected->ItemIndex;
     cellstring = LstBoxSelected->Items->Strings[index];
     LstBoxVars->Items->Add(cellstring);
     LstBoxSelected->Items->Delete(index);
     if (LstBoxSelected->Items->Count < 1) OutBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmVarSel::AllBtnClick(TObject *Sender)
{
     int index, noitems;
     AnsiString cellstring;

     noitems = LstBoxVars->Items->Count;
     for (index = 0; index < noitems; index++)
     {
          cellstring = LstBoxVars->Items->Strings[index];
          LstBoxSelected->Items->Add(cellstring);
     }
     LstBoxVars->Clear();
     OutBtn->Visible = true;
     InBtn->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TFrmVarSel::BtnHelpClick(TObject *Sender)
{
  Application->HelpFile = "OpenStat.hlp";
  Application->HelpJump("onettest");

}
//---------------------------------------------------------------------------


void __fastcall TFrmVarSel::FormShow(TObject *Sender)
{
        BtnResetClick(this);        
}
//---------------------------------------------------------------------------

