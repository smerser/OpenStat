//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "OutPut.h"
#include "stdio.h"
#include "math.h"
#include "functions.h"
#include "OneSampOptUnit.h"
#include "OneSampleUnit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TOneSampleForm *OneSampleForm;
//---------------------------------------------------------------------------
__fastcall TOneSampleForm::TOneSampleForm(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOneSampleForm::ResetBtnClick(TObject *Sender)
{
     Statistic->Text = "";
     Parameter->Text = "";
     Size->Text = "";
     CInterval->Text = "95";
     StdDev->Text = "";
     RadioGroup1->ItemIndex = 0;
     FromGrp->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void __fastcall TOneSampleForm::FormShow(TObject *Sender)
{
     ResetBtnClick(this);   
}
//---------------------------------------------------------------------------
void __fastcall TOneSampleForm::RadioGroup1Click(TObject *Sender)
{
     if (RadioGroup1->ItemIndex != 0)
     {
          Label5->Visible = false;
          StdDev->Visible = false;
     }
     else
     {
          Label5->Visible = true;
          StdDev->Visible = true;
     }
     if (RadioGroup1->ItemIndex == 1)
        Label1->Caption = "Sample Frequency";
     else Label1->Caption = "Sample Statistic";
}
//---------------------------------------------------------------------------
void __fastcall TOneSampleForm::ContinueBtnClick(TObject *Sender)
{
   int i, N;
   double sampmean, sampprop, sampcor, sampvar, Confidence, alpha, df;
   double sampsize, popmean, popprop, popcor, popvar, stderror;
   double z, zprobability, zreject, zconf, UCL, LCL, sampsd;
   double t, tprobability, testt;
   double poptrans, samptrans, chisqrval, chiprob, lowchi, hichi, testchi;
   char outline[121];

     // Initialize output form
     FrmOutPut->RichOutPut->Clear();
     N = StrToInt(Size->Text);
     Confidence = StrToFloat(CInterval->Text) / 100.0;
     switch (RadioGroup1->ItemIndex)
     {
        case 0 :
        {
           sampmean = StrToFloat(Statistic->Text);
           popmean = StrToFloat(Parameter->Text);
           sampsd = StrToFloat(StdDev->Text);
           df = N;
           stderror = sampsd / sqrt(df);
           df = N-1;
           t = (sampmean - popmean) / stderror;
           tprobability = tprob(t,df);
           alpha = (1.0 - Confidence) / 2.0;
           testt = inverset((1.0 - alpha),df);
           UCL = sampmean + testt * stderror;
           LCL = sampmean - testt * stderror;
           FrmOutPut->RichOutPut->Lines->Add("ANALYSIS OF A SAMPLE MEAN");
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"Sample Mean = %6.3f",sampmean);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Population Mean = %6.3f",popmean);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Sample Size = %d",N);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Standard error of Mean = %6.3f",stderror);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"t test statistic = %6.3f with probability %6.3f",t,tprobability);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"t value required for rejection = %6.3f",testt);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Confidence Interval = (%6.3f,%6.3f)",LCL,UCL);
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        break;
        case  1 :
        {
           sampprop = StrToFloat(Statistic->Text)/StrToFloat(Size->Text);
           popprop = StrToFloat(Parameter->Text);
           stderror = sqrt((sampprop * (1.0 - sampprop)) / N);
           z = (sampprop - popprop) / stderror;
           zprobability = 1.0 - probz(z);
           zreject = inversez(Confidence) + fabs(inversez(1.0 - Confidence) / 2.0);
           zconf = fabs(inversez((1.0 - Confidence) / 2.0));
           UCL = sampprop + (zconf * stderror);
           LCL = sampprop - (zconf * stderror);
           FrmOutPut->RichOutPut->Lines->Add("ANALYSIS OF A SAMPLE PROPORTION");
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"Two tailed test at the %4.3f confidence level",Confidence);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Sample Proportion = %9.7f",sampprop);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Population Proportion = %9.7f",popprop);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Sample Size = %d",N);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Standard error of sample proportion = %9.7f",stderror);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z test statistic = %6.4f with probability > z = %6.4f",
                z,zprobability);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z test statistic = %6.4f with probability < z = %6.4f",
                z,1.0-zprobability);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z value required for rejection = %6.4f",zreject);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Confidence Interval = (%9.7f,%9.7f)",LCL,UCL);
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        break;
        case 2 :
        {
           sampcor = StrToFloat(Statistic->Text);
           popcor = StrToFloat(Parameter->Text);
           zconf = fabs(inversez((1.0 - Confidence) / 2.0));
           samptrans = log((1.0 + sampcor) / (1.0 - sampcor)) / 2.0;
           poptrans = log((1.0 + popcor) / (1.0 - popcor)) / 2.0;
           stderror = sqrt(1.0 / (N - 3.0));
           z = (samptrans - poptrans) / stderror;
           zprobability = 1.0 - probz(z);
           alpha = (1.0 - Confidence) / 2.0;
           zreject = inversez(1.0 - alpha);
           UCL = samptrans + (zconf * stderror);
           LCL = samptrans - (zconf * stderror);
           UCL = (exp(2.0 * UCL) - 1.0) / (exp(2.0 * UCL) + 1.0);
           LCL = (exp(2.0 * LCL) - 1.0) / (exp(2.0 * LCL) + 1.0);
           FrmOutPut->RichOutPut->Lines->Add("ANALYSIS OF A SAMPLE CORRELATION");
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"Sample Correlation = %6.3f",sampcor);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Population Correlation = %6.3f",popcor);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Sample Size = %d",N);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z Transform of sample correlation = %6.3f",samptrans);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z Transform of population correlation = %6.3f",poptrans);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Standard error of transform = %6.3f",stderror);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z test statistic = %6.3f with probability %6.3f",z,zprobability);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"z value required for rejection = %6.3f",zreject);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Confidence Interval for sample correlation = (%6.3f,%6.3f)",LCL,UCL);
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        break;
        case 3 :
        {
           sampvar = StrToFloat(Statistic->Text);
           popvar = StrToFloat(Parameter->Text);
           alpha = 1.0 - Confidence;
           chisqrval = ((N - 1.0) * sampvar) / popvar;
           chiprob = 1.0 - chisquaredprob(chisqrval,N-1);
           lowchi = inversechi((alpha / 2.0),N-1);
           hichi = inversechi((1.0 - alpha / 2.0),N-1);
              LCL = ((N - 1.0) * sampvar) / hichi;
              UCL = ((N - 1.0) * sampvar) / lowchi;
           if (sampvar > popvar) testchi = hichi;
           else testchi = lowchi;
           FrmOutPut->RichOutPut->Lines->Add("ANALYSIS OF A SAMPLE VARIANCE");
           FrmOutPut->RichOutPut->Lines->Add("");
           sprintf(outline,"Sample Variance = %6.3f",sampvar);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Population Variance = %6.3f",popvar);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Sample Size = %d",N);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           if (sampvar > popvar)
           {
              sprintf(outline,"Chi-square statistic = %6.3f with probability > chisquare = %6.3f and D.F. = %d",
                 chisqrval,chiprob, N-1);
              FrmOutPut->RichOutPut->Lines->Add(outline);
           }
           else
           {
               sprintf(outline,"Chi-square statistic = %6.3f with probability smaller chisquare = %6.3f and D.F. = %d",
                  chisqrval,1.0 - chiprob,N-1);
               FrmOutPut->RichOutPut->Lines->Add(outline);
           }
           sprintf(outline,"Chi-square value required for rejection = %6.3f",testchi);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Chi-square Confidence Interval = (%6.3f,%6.3f)",lowchi,hichi);
           FrmOutPut->RichOutPut->Lines->Add(outline);
           sprintf(outline,"Variance Confidence Interval = (%6.3f,%6.3f)",LCL,UCL);
           FrmOutPut->RichOutPut->Lines->Add(outline);
        }
        break;
     }
     FrmOutPut->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TOneSampleForm::FromGrpClick(TObject *Sender)
{
     if (FromGrp->ItemIndex == 0) return;
     else
     {
         if (RadioGroup1->ItemIndex != 2)
         {
            OneSampOptForm->Label2->Visible = false;
            OneSampOptForm->YVarInBtn->Visible = false;
            OneSampOptForm->YVarOutBtn->Visible = false;
            OneSampOptForm->YVarEdit->Visible = false;
         }
         else
         {
            OneSampOptForm->Label2->Visible = true;
            OneSampOptForm->YVarInBtn->Visible = true;
            OneSampOptForm->YVarOutBtn->Visible = true;
            OneSampOptForm->YVarEdit->Visible = true;
         }
         OneSampOptForm->ShowModal();
     }
}
//---------------------------------------------------------------------------

