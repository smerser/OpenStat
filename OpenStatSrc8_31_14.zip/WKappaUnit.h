//---------------------------------------------------------------------------

#ifndef WKappaUnitH
#define WKappaUnitH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TWKappaForm : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *InputGroup;
    TLabel *Label1;
    TListBox *VarList;
    TBitBtn *RowIn;
    TBitBtn *RowOut;
    TBitBtn *ColIn;
    TBitBtn *ColOut;
    TBitBtn *DepIn;
    TBitBtn *DepOut;
    TButton *ResetBtn;
    TLabel *Label2;
    TEdit *RaterAEdit;
    TLabel *Label3;
    TEdit *RaterBEdit;
    TLabel *Label4;
    TEdit *DepEdit;
    TGroupBox *GroupBox1;
    TCheckBox *ObsChk;
    TCheckBox *ExpChk;
    TCheckBox *PropChk;
    TCheckBox *ChiChk;
    TCheckBox *YatesChk;
    TCheckBox *SaveChk;
    TLabel *Label5;
    TEdit *NCasesEdit;
    TButton *CancelBtn;
    TButton *ComputeBtn;
    TButton *ReturnBtn;
    TMemo *Memo1;
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall InputGroupClick(TObject *Sender);
    void __fastcall RowInClick(TObject *Sender);
    void __fastcall RowOutClick(TObject *Sender);
    void __fastcall ColInClick(TObject *Sender);
    void __fastcall ColOutClick(TObject *Sender);
    void __fastcall DepInClick(TObject *Sender);
    void __fastcall DepOutClick(TObject *Sender);
    void __fastcall ComputeBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TWKappaForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWKappaForm *WKappaForm;
//---------------------------------------------------------------------------
#endif
